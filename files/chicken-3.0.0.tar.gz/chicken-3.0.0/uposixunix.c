/* Generated from posixunix.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:28
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: posixunix.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uposixunix.c
   unit: posix
*/

#include "chicken.h"

#include <signal.h>
#include <errno.h>
#include <math.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

static C_TLS int C_wait_status;

#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <dirent.h>
#include <pwd.h>

#if defined(__sun__) && defined(__svr4__)
# include <sys/tty.h>
#endif

#ifdef HAVE_GRP_H
#include <grp.h>
#endif

#include <sys/mman.h>
#include <time.h>

#ifndef O_FSYNC
# define O_FSYNC O_SYNC
#endif

#ifndef PIPE_BUF
# ifdef __CYGWIN__
#  define PIPE_BUF       _POSIX_PIPE_BUF
# else
#  define PIPE_BUF 1024
# endif
#endif

#ifndef O_BINARY
# define O_BINARY        0
#endif
#ifndef O_TEXT
# define O_TEXT          0
#endif

#ifndef ARG_MAX
# define ARG_MAX 256
#endif

#ifndef MAP_FILE
# define MAP_FILE    0
#endif

#ifndef MAP_ANON
# define MAP_ANON    0
#endif

#if defined(HAVE_CRT_EXTERNS_H)
# include <crt_externs.h>
# define C_getenventry(i)       ((*_NSGetEnviron())[ i ])
#elif defined(C_MACOSX)
# define C_getenventry(i)       NULL
#else
extern char **environ;
# define C_getenventry(i)       (environ[ i ])
#endif

#ifndef ENV_MAX
# define ENV_MAX        1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct utsname C_utsname;
static C_TLS struct flock C_flock;
static C_TLS DIR *temphandle;
static C_TLS struct passwd *C_user;
#ifdef HAVE_GRP_H
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
#endif
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS fd_set C_fd_sets[ 2 ];
static C_TLS struct timeval C_timeval;
static C_TLS char C_hostbuf[ 256 ];
static C_TLS struct stat C_statbuf;

#define C_mkdir(str)        C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#define C_chdir(str)        C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)        C_fix(rmdir(C_c_string(str)))

#define C_opendir(x,h)          C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)           (closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)          C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)        (strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)       (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)                        C_fix(pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_fork              fork
#define C_waitpid(id, o)    C_fix(waitpid(C_unfix(id), &C_wait_status, C_unfix(o)))
#define C_getpid            getpid
#define C_getppid           getppid
#define C_kill(id, s)       C_fix(kill(C_unfix(id), C_unfix(s)))
#define C_getuid            getuid
#define C_getgid            getgid
#define C_geteuid           geteuid
#define C_getegid           getegid
#define C_chown(fn, u, g)   C_fix(chown(C_data_pointer(fn), C_unfix(u), C_unfix(g)))
#define C_chmod(fn, m)      C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_setuid(id)        C_fix(setuid(C_unfix(id)))
#define C_setgid(id)        C_fix(setgid(C_unfix(id)))
#define C_seteuid(id)       C_fix(seteuid(C_unfix(id)))
#define C_setegid(id)       C_fix(setegid(C_unfix(id)))
#define C_setsid(dummy)     C_fix(setsid())
#define C_setpgid(x, y)     C_fix(setpgid(C_unfix(x), C_unfix(y)))
#define C_getpgid(x)        C_fix(getpgid(C_unfix(x)))
#define C_symlink(o, n)     C_fix(symlink(C_data_pointer(o), C_data_pointer(n)))
#define C_readlink(f, b)    C_fix(readlink(C_data_pointer(f), C_data_pointer(b), FILENAME_MAX))
#define C_getpwnam(n)       C_mk_bool((C_user = getpwnam((char *)C_data_pointer(n))) != NULL)
#define C_getpwuid(u)       C_mk_bool((C_user = getpwuid(C_unfix(u))) != NULL)
#ifdef HAVE_GRP_H
#define C_getgrnam(n)       C_mk_bool((C_group = getgrnam((char *)C_data_pointer(n))) != NULL)
#define C_getgrgid(u)       C_mk_bool((C_group = getgrgid(C_unfix(u))) != NULL)
#else
#define C_getgrnam(n)       C_SCHEME_FALSE
#define C_getgrgid(n)       C_SCHEME_FALSE
#endif
#define C_pipe(d)           C_fix(pipe(C_pipefds))
#define C_truncate(f, n)    C_fix(truncate((char *)C_data_pointer(f), C_num_to_int(n)))
#define C_ftruncate(f, n)   C_fix(ftruncate(C_unfix(f), C_num_to_int(n)))
#define C_uname             C_fix(uname(&C_utsname))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)       C_fix(fileno(C_port_file(p)))
#define C_dup(x)            C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)        C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_alarm             alarm
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)     C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_close(fd)         C_fix(close(C_unfix(fd)))
#define C_sleep             sleep

#define C_putenv(s)         C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)          C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_lstat(fn)         C_fix(lstat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)          C_fix(fstat(C_unfix(f), &C_statbuf))

#define C_islink            ((C_statbuf.st_mode & S_IFMT) == S_IFLNK)
#define C_isreg             ((C_statbuf.st_mode & S_IFMT) == S_IFREG)

#ifdef C_GNU_ENV
# define C_setenv(x, y)     C_fix(setenv((char *)C_data_pointer(x), (char *)C_data_pointer(y), 1))
#else
static C_word C_fcall C_setenv(C_word x, C_word y);
C_word C_fcall C_setenv(C_word x, C_word y) {
  char *sx = C_data_pointer(x),
       *sy = C_data_pointer(y);
  int n1 = C_strlen(sx), n2 = C_strlen(sy);
  char *buf = (char *)C_malloc(n1 + n2 + 2);
  if(buf == NULL) return(C_fix(0));
  else {
    C_strcpy(buf, sx);
    buf[ n1 ] = '=';
    C_strcpy(buf + n1 + 1, sy);
    return(C_fix(putenv(buf)));
  }
}
#endif

static void C_fcall C_set_arg_string(char **where, int i, char *a, int len) {
  char *ptr;
  if(a != NULL) {
    ptr = (char *)C_malloc(len + 1);
    C_memcpy(ptr, a, len);
    ptr[ len ] = '\0';
  }
  else ptr = NULL;
  where[ i ] = ptr;
}

static void C_fcall C_free_arg_string(char **where) {
  while((*where) != NULL) C_free(*(where++));
}

static void C_set_timeval(C_word num, struct timeval *tm)
{
  if((num & C_FIXNUM_BIT) != 0) {
    tm->tv_sec = C_unfix(num);
    tm->tv_usec = 0;
  }
  else {
    double i;
    tm->tv_usec = (int)(modf(C_flonum_magnitude(num), &i) * 1000000);
    tm->tv_sec = (int)i;
  }
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_free_exec_args()		C_free_arg_string(C_exec_args)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)
#define C_free_exec_env()		C_free_arg_string(C_exec_env)

#define C_execvp(f)         C_fix(execvp(C_data_pointer(f), C_exec_args))
#define C_execve(f)         C_fix(execve(C_data_pointer(f), C_exec_args, C_exec_env))

#if defined(__FreeBSD__) || defined(C_MACOSX) || defined(__NetBSD__) || defined(__OpenBSD__) || defined(__sgi__) || defined(sgi) || defined(__DragonFly__) || defined(__SUNPRO_C)
static C_TLS int C_uw;
# define C_WIFEXITED(n)      (C_uw = C_unfix(n), C_mk_bool(WIFEXITED(C_uw)))
# define C_WIFSIGNALED(n)    (C_uw = C_unfix(n), C_mk_bool(WIFSIGNALED(C_uw)))
# define C_WIFSTOPPED(n)     (C_uw = C_unfix(n), C_mk_bool(WIFSTOPPED(C_uw)))
# define C_WEXITSTATUS(n)    (C_uw = C_unfix(n), C_fix(WEXITSTATUS(C_uw)))
# define C_WTERMSIG(n)       (C_uw = C_unfix(n), C_fix(WTERMSIG(C_uw)))
# define C_WSTOPSIG(n)       (C_uw = C_unfix(n), C_fix(WSTOPSIG(C_uw)))
#else
# define C_WIFEXITED(n)      C_mk_bool(WIFEXITED(C_unfix(n)))
# define C_WIFSIGNALED(n)    C_mk_bool(WIFSIGNALED(C_unfix(n)))
# define C_WIFSTOPPED(n)     C_mk_bool(WIFSTOPPED(C_unfix(n)))
# define C_WEXITSTATUS(n)    C_fix(WEXITSTATUS(C_unfix(n)))
# define C_WTERMSIG(n)       C_fix(WTERMSIG(C_unfix(n)))
# define C_WSTOPSIG(n)       C_fix(WSTOPSIG(C_unfix(n)))
#endif

#ifdef __CYGWIN__
# define C_mkfifo(fn, m)    C_fix(-1);
#else
# define C_mkfifo(fn, m)    C_fix(mkfifo((char *)C_data_pointer(fn), C_unfix(m)))
#endif

#define C_flock_setup(t, s, n) (C_flock.l_type = C_unfix(t), C_flock.l_start = C_num_to_int(s), C_flock.l_whence = SEEK_SET, C_flock.l_len = C_num_to_int(n), C_SCHEME_UNDEFINED)
#define C_flock_test(p)     (fcntl(fileno(C_port_file(p)), F_GETLK, &C_flock) >= 0 ? (C_flock.l_type == F_UNLCK ? C_fix(0) : C_fix(C_flock.l_pid)) : C_SCHEME_FALSE)
#define C_flock_lock(p)     C_fix(fcntl(fileno(C_port_file(p)), F_SETLK, &C_flock))
#define C_flock_lockw(p)    C_fix(fcntl(fileno(C_port_file(p)), F_SETLKW, &C_flock))

#ifndef FILENAME_MAX
# define FILENAME_MAX          1024
#endif

static C_TLS sigset_t C_sigset;
#define C_sigemptyset(d)    (sigemptyset(&C_sigset), C_SCHEME_UNDEFINED)
#define C_sigaddset(s)      (sigaddset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigdelset(s)      (sigdelset(&C_sigset, C_unfix(s)), C_SCHEME_UNDEFINED)
#define C_sigismember(s)    C_mk_bool(sigismember(&C_sigset, C_unfix(s)))
#define C_sigprocmask_set(d)        C_fix(sigprocmask(SIG_SETMASK, &C_sigset, NULL))
#define C_sigprocmask_block(d)      C_fix(sigprocmask(SIG_BLOCK, &C_sigset, NULL))
#define C_sigprocmask_unblock(d)    C_fix(sigprocmask(SIG_UNBLOCK, &C_sigset, NULL))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)        C_fix(mkstemp(C_c_string(t)))

#define C_ftell(p)            C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)      C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)     C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_zero_fd_set(i)      FD_ZERO(&C_fd_sets[ i ])
#define C_set_fd_set(i, fd)   FD_SET(fd, &C_fd_sets[ i ])
#define C_test_fd_set(i, fd)  FD_ISSET(fd, &C_fd_sets[ i ])
#define C_C_select(m)         C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, NULL))
#define C_C_select_t(m, t)    (C_set_timeval(t, &C_timeval), \
			       C_fix(select(C_unfix(m), &C_fd_sets[ 0 ], &C_fd_sets[ 1 ], NULL, &C_timeval)))

#define C_ctime(n)          (C_secs = (n), ctime(&C_secs))

#if defined(__CYGWIN__) || defined(__SVR4)
/* Seen here: http://lists.samba.org/archive/samba-technical/2002-November/025571.html */

time_t timegm(struct tm *t)
{
  time_t tl, tb;
  struct tm *tg;

  tl = mktime (t);
  if (tl == -1)
    {
      t->tm_hour--;
      tl = mktime (t);
      if (tl == -1)
        return -1; /* can't deal with output from strptime */
      tl += 3600;
    }
  tg = gmtime (&tl);
  tg->tm_isdst = 0;
  tb = mktime (tg);
  if (tb == -1)
    {
      tg->tm_hour--;
      tb = mktime (tg);
      if (tb == -1)
        return -1; /* can't deal with output from gmtime */
      tb += 3600;
    }
  return (tl - (tb - tl));
}
#endif

#if !defined(C_GNU_ENV) || defined(__CYGWIN__) || defined(__uClinux__)
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
# define C_mktime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = mktime(&C_tm)) != -1)
# define C_timegm(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = timegm(&C_tm)) != -1)
#else
# define C_asctime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), asctime(&C_tm) )
# define C_mktime(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), (C_temporary_flonum = mktime(&C_tm)) != -1)
# define C_timegm(v)        (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), C_tm.tm_gmtoff = C_unfix(C_block_item(v, 9)), (C_temporary_flonum = timegm(&C_tm)) != -1)
#endif

static gid_t *C_groups = NULL;

#define C_get_gid(n)      C_fix(C_groups[ C_unfix(n) ])
#define C_set_gid(n, id)  (C_groups[ C_unfix(n) ] = C_unfix(id), C_SCHEME_UNDEFINED)
#define C_set_groups(n)   C_fix(setgroups(C_unfix(n), C_groups))

#ifdef TIOCGWINSZ
static int get_tty_size(int p, int *rows, int *cols)
{
 struct winsize tty_size;
 int r;

 memset(&tty_size, 0, sizeof tty_size);

 r = ioctl(p, TIOCGWINSZ, &tty_size);
 if (r == 0) {
    *rows = tty_size.ws_row;
    *cols = tty_size.ws_col;
 }
 return r;
}
#else
static int get_tty_size(int p, int *rows, int *cols)
{
 *rows = *cols = 0;
 return -1;
}
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[425];
static double C_possibly_force_alignment;


/* from k6415 in set-root-directory! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1243(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1243(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
C_r=C_fix((C_word)chroot(t0));
return C_r;}

/* from sleep in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1016(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1016(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_sleep(t0));
return C_r;}

/* from parent-process-id in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1013(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1013(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getppid());
return C_r;}

/* from current-process-id in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub1011(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub1011(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from freeenv */
static C_word C_fcall stub942(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub942(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_env();
return C_r;}

/* from k5370 */
static C_word C_fcall stub935(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub935(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from freeargs */
static C_word C_fcall stub930(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub930(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_free_exec_args();
return C_r;}

/* from k5362 */
static C_word C_fcall stub923(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub923(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from f_5347 in k5341 in process-fork in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub911(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub911(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from fork */
static C_word C_fcall stub906(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub906(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_fork());
return C_r;}

/* from getit */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub866(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub866(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
if(gethostname(C_hostbuf, 256) == -1) return(NULL);else return(C_hostbuf);
C_ret:
#undef return

return C_r;}

/* from k5159 */
static C_word C_fcall stub852(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub852(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int *t1=(int *)C_c_pointer_nn(C_a1);
int *t2=(int *)C_c_pointer_nn(C_a2);
C_r=C_fix((C_word)get_tty_size(t0,t1,t2));
return C_r;}

/* from ttyname */
static C_word C_fcall stub842(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub842(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)ttyname(t0));
return C_r;}

/* from set-alarm! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub822(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub822(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_alarm(t0));
return C_r;}

/* from ex0 */
static C_word C_fcall stub817(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub817(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub812(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub812(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;

#if !defined(__CYGWIN__) && !defined(__SVR4) && !defined(__uClinux__) && !defined(__hpux__)
time_t clock = (time_t)0;struct tm *ltm = C_localtime(&clock);char *z = ltm ? (char *)ltm->tm_zone : 0;
#else
char *z = (daylight ? tzname[1] : tzname[0]);
#endif
return(z);
C_ret:
#undef return

return C_r;}

/* from asctime */
static C_word C_fcall stub797(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub797(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub788(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub788(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from k4809 */
static C_word C_fcall stub769(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub769(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
C_r=C_fix((C_word)munmap(t0,t1));
return C_r;}

/* from k4751 */
static C_word C_fcall stub744(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5) C_regparm;
C_regparm static C_word C_fcall stub744(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
int t1=(int )C_num_to_int(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
int t5=(int )C_num_to_int(C_a5);
C_r=C_mpointer_or_false(&C_a,(void*)mmap(t0,t1,t2,t3,t4,t5));
return C_r;}

/* from get */
static C_word C_fcall stub726(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub726(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from k3490 in k3486 in file-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub463(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
C_r=C_fix((C_word)link(t0,t1));
return C_r;}

/* from k3210 in initialize-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub403(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)initgroups(t0,t1));
return C_r;}

/* from _ensure-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub376(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub376(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
if(C_groups != NULL) C_free(C_groups);C_groups = (gid_t *)C_malloc(sizeof(gid_t) * n);if(C_groups == NULL) return(0);else return(1);
C_ret:
#undef return

return C_r;}

/* from _get-groups */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub372(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub372(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int n=(int )C_unfix(C_a0);
return(getgroups(n, C_groups));
C_ret:
#undef return

return C_r;}

/* from group-member */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub355(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub355(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int i=(int )C_unfix(C_a0);
return(C_group->gr_mem[ i ]);
C_ret:
#undef return

return C_r;}

/* from a6461 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub342(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub342(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getegid());
return C_r;}

/* from a6479 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub340(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub340(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getgid());
return C_r;}

/* from a6482 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub334(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub334(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_geteuid());
return C_r;}

/* from a6500 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub332(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub332(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getuid());
return C_r;}

/* from fd_test in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub92(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mk_bool(C_test_fd_set(t0,t1));
return C_r;}

/* from fd_set in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub86(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_set_fd_set(t0,t1);
return C_r;}

/* from fd_zero in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_zero_fd_set(t0);
return C_r;}

/* from fcntl */
static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub24(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
long t2=(long )C_num_to_long(C_a2);
C_r=C_fix((C_word)fcntl(t0,t1,t2));
return C_r;}

/* from ##sys#file-select-one in k1503 in k1500 in k1497 in k1494 in k1491 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub17(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub17(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;struct timeval tm;FD_ZERO(&in);FD_SET(fd, &in);tm.tv_sec = tm.tv_usec = 0;if(select(fd + 1, &in, NULL, NULL, &tm) == -1) return(-1);else return(FD_ISSET(fd, &in) ? 1 : 0);
C_ret:
#undef return

return C_r;}

/* from ##sys#file-nonblocking! in k1503 in k1500 in k1497 in k1494 in k1491 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub13(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub13(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from strerror */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6510)
static void C_ccall f_6510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6526)
static void C_ccall f_6526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6514)
static void C_ccall f_6514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6517)
static void C_ccall f_6517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2694)
static void C_ccall f_2694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6504)
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2829)
static void C_ccall f_2829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6501)
static void C_ccall f_6501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6486)
static void C_ccall f_6486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6496)
static void C_ccall f_6496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6483)
static void C_ccall f_6483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6480)
static void C_ccall f_6480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2909)
static void C_ccall f_2909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6465)
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6475)
static void C_ccall f_6475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6462)
static void C_ccall f_6462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6451)
static void C_ccall f_6451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6421)
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6417)
static void C_ccall f_6417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_6163)
static void C_ccall f_6163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_6346)
static void C_fcall f_6346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6352)
static void C_ccall f_6352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6341)
static void C_fcall f_6341(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6336)
static void C_fcall f_6336(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6165)
static void C_fcall f_6165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6331)
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_6172)
static void C_fcall f_6172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6311)
static void C_ccall f_6311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6305)
static void C_ccall f_6305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6182)
static void C_ccall f_6182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6184)
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6285)
static void C_ccall f_6285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6218)
static void C_ccall f_6218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6275)
static void C_ccall f_6275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6238)
static void C_ccall f_6238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6260)
static void C_ccall f_6260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6253)
static void C_ccall f_6253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6250)
static void C_ccall f_6250(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6230)
static void C_ccall f_6230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6228)
static void C_ccall f_6228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6118)
static void C_fcall f_6118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6113)
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6049)
static void C_ccall f_6049r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6061)
static void C_fcall f_6061(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_fcall f_6056(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6051)
static void C_fcall f_6051(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5988)
static void C_fcall f_5988(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6043)
static void C_ccall f_6043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6047)
static void C_ccall f_6047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6012)
static void C_ccall f_6012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5990)
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5999)
static void C_ccall f_5999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5924)
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5936)
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5967)
static void C_ccall f_5967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5947)
static void C_ccall f_5947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5963)
static void C_ccall f_5963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5951)
static void C_ccall f_5951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5959)
static void C_ccall f_5959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_ccall f_5955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_fcall f_5913(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_fcall f_5902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5857)
static void C_fcall f_5857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_5861)
static void C_ccall f_5861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5864)
static void C_ccall f_5864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5867)
static void C_ccall f_5867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5880)
static void C_ccall f_5880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5841)
static C_word C_fcall f_5841(C_word *a,C_word t0);
C_noret_decl(f_5824)
static void C_fcall f_5824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_ccall f_5749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5810)
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_fcall f_5790(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5753)
static void C_fcall f_5753(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_5755)
static void C_ccall f_5755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5697)
static void C_ccall f_5697r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5723)
static void C_ccall f_5723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5727)
static void C_ccall f_5727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5691)
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5682)
static void C_ccall f_5682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5686)
static void C_ccall f_5686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5655)
static void C_ccall f_5655r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5604)
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5509)
static void C_fcall f_5509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_fcall f_5504(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5377)
static void C_fcall f_5377(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5387)
static void C_ccall f_5387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5395)
static void C_fcall f_5395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5441)
static C_word C_fcall f_5441(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5408)
static void C_fcall f_5408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5433)
static void C_ccall f_5433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5411)
static void C_ccall f_5411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5367)
static C_word C_fcall f_5367(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5359)
static C_word C_fcall f_5359(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5343)
static void C_ccall f_5343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5215)
static void C_fcall f_5215(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5246)
static void C_ccall f_5246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5253)
static void C_ccall f_5253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5272)
static void C_ccall f_5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5286)
static void C_ccall f_5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_ccall f_5230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5204)
static void C_ccall f_5204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5143)
static void C_ccall f_5143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_fcall f_5116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5042)
static void C_ccall f_5042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5035)
static void C_ccall f_5035(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4983)
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4916)
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4923)
static void C_ccall f_4923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4929)
static void C_ccall f_4929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4888)
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4892)
static void C_ccall f_4892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4895)
static void C_ccall f_4895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4859)
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t8) C_noret;
C_noret_decl(f_4761)
static void C_ccall f_4761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4767)
static void C_ccall f_4767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4786)
static void C_ccall f_4786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4674)
static void C_ccall f_4674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_fcall f_4680(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_fcall f_4692(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4667)
static void C_ccall f_4667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4642)
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4573)
static void C_ccall f_4573r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4580)
static void C_fcall f_4580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4601)
static void C_ccall f_4601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4527)
static void C_ccall f_4527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4493)
static void C_ccall f_4493r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4497)
static void C_ccall f_4497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4475)
static void C_fcall f_4475(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4404)
static void C_fcall f_4404(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4423)
static void C_ccall f_4423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_fcall f_4429(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4365)
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4393)
static void C_ccall f_4393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4389)
static void C_ccall f_4389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4305)
static void C_fcall f_4305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4295)
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4111)
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4239)
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4249)
static void C_ccall f_4249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4163)
static void C_fcall f_4163(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4199)
static void C_ccall f_4199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4034)
static void C_fcall f_4034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_fcall f_4029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4024)
static void C_fcall f_4024(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4019)
static void C_fcall f_4019(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3678)
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3925)
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3860)
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3812)
static void C_ccall f_3812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3803)
static void C_ccall f_3803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3794)
static void C_ccall f_3794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_fcall f_3712(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3724)
static void C_fcall f_3724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_ccall f_3770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3704)
static C_word C_fcall f_3704(C_word t0);
C_noret_decl(f_3689)
static void C_fcall f_3689(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3656)
static void C_fcall f_3656(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3608)
static void C_ccall f_3608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3626)
static void C_ccall f_3626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3602)
static void C_ccall f_3602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3588)
static void C_ccall f_3588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_fcall f_3561(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3532)
static void C_ccall f_3532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3488)
static void C_ccall f_3488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3492)
static void C_ccall f_3492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_ccall f_3457(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3410)
static void C_ccall f_3410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3389)
static void C_ccall f_3389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3361)
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3337)
static void C_fcall f_3337(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3359)
static void C_ccall f_3359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3355)
static void C_ccall f_3355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3280)
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_fcall f_3159(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3175)
static void C_ccall f_3175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3091)
static void C_ccall f_3091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3097)
static void C_ccall f_3097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_fcall f_3102(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static C_word C_fcall f_3084(C_word t0);
C_noret_decl(f_3009)
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3009)
static void C_ccall f_3009r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_fcall f_3016(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3043)
static void C_ccall f_3043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3053)
static void C_ccall f_3053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_fcall f_2922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2932)
static void C_ccall f_2932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2936)
static void C_ccall f_2936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2948)
static void C_ccall f_2948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2892)
static void C_ccall f_2892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_ccall f_2854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2813)
static void C_ccall f_2813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2754)
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2705)
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2649)
static void C_ccall f_2649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2613)
static void C_ccall f_2613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2623)
static void C_ccall f_2623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2594)
static void C_ccall f_2594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2549)
static void C_ccall f_2549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_fcall f_2452(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static C_word C_fcall f_2440(C_word t0);
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2402)
static void C_ccall f_2402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2388)
static void C_ccall f_2388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2227)
static void C_ccall f_2227r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2332)
static void C_fcall f_2332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2229)
static void C_fcall f_2229(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2326)
static void C_ccall f_2326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2246)
static void C_ccall f_2246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2260)
static void C_fcall f_2260(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2273)
static void C_ccall f_2273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_fcall f_2282(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2106)
static void C_ccall f_2106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2112)
static void C_ccall f_2112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2084)
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2043)
static void C_ccall f_2043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_fcall f_1977(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1785)
static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1807)
static void C_ccall f_1807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1810)
static void C_fcall f_1810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1849)
static void C_fcall f_1849(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_fcall f_1853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1783)
static C_word C_fcall f_1783(C_word t0,C_word t1);
C_noret_decl(f_1781)
static C_word C_fcall f_1781(C_word t0,C_word t1);
C_noret_decl(f_1779)
static C_word C_fcall f_1779(C_word t0);
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1679)
static void C_ccall f_1679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1643)
static void C_ccall f_1643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1630)
static void C_ccall f_1630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1527)
static void C_ccall f_1527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_6346)
static void C_fcall trf_6346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6346(t0,t1);}

C_noret_decl(trf_6341)
static void C_fcall trf_6341(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6341(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6341(t0,t1,t2);}

C_noret_decl(trf_6336)
static void C_fcall trf_6336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6336(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6336(t0,t1,t2,t3);}

C_noret_decl(trf_6165)
static void C_fcall trf_6165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6165(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6165(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6172)
static void C_fcall trf_6172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6172(t0,t1);}

C_noret_decl(trf_6184)
static void C_fcall trf_6184(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6184(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6184(t0,t1,t2,t3);}

C_noret_decl(trf_6118)
static void C_fcall trf_6118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6118(t0,t1);}

C_noret_decl(trf_6113)
static void C_fcall trf_6113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6113(t0,t1,t2);}

C_noret_decl(trf_6108)
static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6108(t0,t1,t2,t3);}

C_noret_decl(trf_6061)
static void C_fcall trf_6061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6061(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6061(t0,t1);}

C_noret_decl(trf_6056)
static void C_fcall trf_6056(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6056(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6056(t0,t1,t2);}

C_noret_decl(trf_6051)
static void C_fcall trf_6051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6051(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6051(t0,t1,t2,t3);}

C_noret_decl(trf_5988)
static void C_fcall trf_5988(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5988(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5988(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5990)
static void C_fcall trf_5990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5990(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5990(t0,t1,t2);}

C_noret_decl(trf_5913)
static void C_fcall trf_5913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5913(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5913(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5902)
static void C_fcall trf_5902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5902(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5902(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_5857)
static void C_fcall trf_5857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5857(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_5857(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_5824)
static void C_fcall trf_5824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5824(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5824(t0,t1,t2,t3,t4);}

C_noret_decl(trf_5810)
static void C_fcall trf_5810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5810(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5810(t0,t1,t2,t3);}

C_noret_decl(trf_5790)
static void C_fcall trf_5790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5790(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5790(t0,t1,t2);}

C_noret_decl(trf_5753)
static void C_fcall trf_5753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5753(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_5753(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_5509)
static void C_fcall trf_5509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5509(t0,t1);}

C_noret_decl(trf_5504)
static void C_fcall trf_5504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5504(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5504(t0,t1,t2);}

C_noret_decl(trf_5377)
static void C_fcall trf_5377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5377(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5377(t0,t1,t2,t3);}

C_noret_decl(trf_5395)
static void C_fcall trf_5395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5395(t0,t1,t2,t3);}

C_noret_decl(trf_5408)
static void C_fcall trf_5408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5408(t0,t1);}

C_noret_decl(trf_5215)
static void C_fcall trf_5215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5215(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5215(t0,t1,t2);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5255(t0,t1,t2);}

C_noret_decl(trf_5116)
static void C_fcall trf_5116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5116(t0,t1,t2);}

C_noret_decl(trf_4680)
static void C_fcall trf_4680(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4680(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4680(t0,t1,t2);}

C_noret_decl(trf_4692)
static void C_fcall trf_4692(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4692(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4692(t0,t1,t2);}

C_noret_decl(trf_4580)
static void C_fcall trf_4580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4580(t0,t1);}

C_noret_decl(trf_4475)
static void C_fcall trf_4475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4475(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4475(t0,t1,t2,t3);}

C_noret_decl(trf_4404)
static void C_fcall trf_4404(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4404(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4404(t0,t1,t2,t3);}

C_noret_decl(trf_4429)
static void C_fcall trf_4429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4429(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4429(t0,t1);}

C_noret_decl(trf_4305)
static void C_fcall trf_4305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4305(t0,t1);}

C_noret_decl(trf_4300)
static void C_fcall trf_4300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4300(t0,t1,t2);}

C_noret_decl(trf_4295)
static void C_fcall trf_4295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4295(t0,t1,t2,t3);}

C_noret_decl(trf_4111)
static void C_fcall trf_4111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4111(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4111(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4239)
static void C_fcall trf_4239(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4239(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4239(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4163)
static void C_fcall trf_4163(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4163(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4163(t0,t1);}

C_noret_decl(trf_4117)
static void C_fcall trf_4117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4117(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4117(t0,t1,t2,t3);}

C_noret_decl(trf_4034)
static void C_fcall trf_4034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4034(t0,t1);}

C_noret_decl(trf_4029)
static void C_fcall trf_4029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4029(t0,t1,t2);}

C_noret_decl(trf_4024)
static void C_fcall trf_4024(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4024(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4024(t0,t1,t2,t3);}

C_noret_decl(trf_4019)
static void C_fcall trf_4019(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4019(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4019(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3678)
static void C_fcall trf_3678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3678(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3678(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3925)
static void C_fcall trf_3925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3925(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3925(t0,t1,t2);}

C_noret_decl(trf_3860)
static void C_fcall trf_3860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3860(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3860(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3712)
static void C_fcall trf_3712(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3712(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3712(t0,t1);}

C_noret_decl(trf_3724)
static void C_fcall trf_3724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3724(t0,t1);}

C_noret_decl(trf_3689)
static void C_fcall trf_3689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3689(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3689(t0,t1);}

C_noret_decl(trf_3656)
static void C_fcall trf_3656(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3656(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3656(t0,t1);}

C_noret_decl(trf_3561)
static void C_fcall trf_3561(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3561(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3561(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3524)
static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3524(t0,t1,t2);}

C_noret_decl(trf_3337)
static void C_fcall trf_3337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3337(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3337(t0,t1,t2,t3);}

C_noret_decl(trf_3159)
static void C_fcall trf_3159(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3159(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3159(t0,t1,t2,t3);}

C_noret_decl(trf_3102)
static void C_fcall trf_3102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3102(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3102(t0,t1,t2);}

C_noret_decl(trf_3016)
static void C_fcall trf_3016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3016(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3016(t0,t1);}

C_noret_decl(trf_3039)
static void C_fcall trf_3039(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3039(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3039(t0,t1,t2);}

C_noret_decl(trf_2922)
static void C_fcall trf_2922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2922(t0,t1);}

C_noret_decl(trf_2766)
static void C_fcall trf_2766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2766(t0,t1,t2,t3);}

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2458(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2452)
static void C_fcall trf_2452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2452(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2452(t0,t1);}

C_noret_decl(trf_2332)
static void C_fcall trf_2332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2332(t0,t1);}

C_noret_decl(trf_2327)
static void C_fcall trf_2327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2327(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2327(t0,t1,t2);}

C_noret_decl(trf_2229)
static void C_fcall trf_2229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2229(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2229(t0,t1,t2,t3);}

C_noret_decl(trf_2260)
static void C_fcall trf_2260(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2260(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2260(t0,t1);}

C_noret_decl(trf_2282)
static void C_fcall trf_2282(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2282(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2282(t0,t1);}

C_noret_decl(trf_1977)
static void C_fcall trf_1977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1977(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1977(t0,t1,t2,t3);}

C_noret_decl(trf_1810)
static void C_fcall trf_1810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1810(t0,t1);}

C_noret_decl(trf_1849)
static void C_fcall trf_1849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1849(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1849(t0,t1);}

C_noret_decl(trf_1853)
static void C_fcall trf_1853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1853(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr7rv)
static void C_fcall tr7rv(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7rv(C_proc7 k){
int n;
C_word *a,t7;
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
n=C_rest_count(0);
a=C_alloc(n+1);
t7=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3150)){
C_save(t1);
C_rereclaim2(3150*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,425);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"string-append");
lf[4]=C_h_intern(&lf[4],15,"\003syssignal-hook");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[6]=C_h_intern(&lf[6],17,"\003syspeek-c-string");
lf[7]=C_h_intern(&lf[7],16,"\003sysupdate-errno");
lf[8]=C_h_intern(&lf[8],15,"\003sysposix-error");
lf[9]=C_h_intern(&lf[9],21,"\003sysfile-nonblocking!");
lf[10]=C_h_intern(&lf[10],19,"\003sysfile-select-one");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"fcntl/dupfd");
lf[13]=C_h_intern(&lf[13],11,"fcntl/getfd");
lf[14]=C_h_intern(&lf[14],11,"fcntl/setfd");
lf[15]=C_h_intern(&lf[15],11,"fcntl/getfl");
lf[16]=C_h_intern(&lf[16],11,"fcntl/setfl");
lf[17]=C_h_intern(&lf[17],11,"open/rdonly");
lf[18]=C_h_intern(&lf[18],11,"open/wronly");
lf[19]=C_h_intern(&lf[19],9,"open/rdwr");
lf[20]=C_h_intern(&lf[20],9,"open/read");
lf[21]=C_h_intern(&lf[21],10,"open/write");
lf[22]=C_h_intern(&lf[22],10,"open/creat");
lf[23]=C_h_intern(&lf[23],11,"open/append");
lf[24]=C_h_intern(&lf[24],9,"open/excl");
lf[25]=C_h_intern(&lf[25],11,"open/noctty");
lf[26]=C_h_intern(&lf[26],13,"open/nonblock");
lf[27]=C_h_intern(&lf[27],10,"open/trunc");
lf[28]=C_h_intern(&lf[28],9,"open/sync");
lf[29]=C_h_intern(&lf[29],10,"open/fsync");
lf[30]=C_h_intern(&lf[30],11,"open/binary");
lf[31]=C_h_intern(&lf[31],9,"open/text");
lf[32]=C_h_intern(&lf[32],10,"perm/irusr");
lf[33]=C_h_intern(&lf[33],10,"perm/iwusr");
lf[34]=C_h_intern(&lf[34],10,"perm/ixusr");
lf[35]=C_h_intern(&lf[35],10,"perm/irgrp");
lf[36]=C_h_intern(&lf[36],10,"perm/iwgrp");
lf[37]=C_h_intern(&lf[37],10,"perm/ixgrp");
lf[38]=C_h_intern(&lf[38],10,"perm/iroth");
lf[39]=C_h_intern(&lf[39],10,"perm/iwoth");
lf[40]=C_h_intern(&lf[40],10,"perm/ixoth");
lf[41]=C_h_intern(&lf[41],10,"perm/irwxu");
lf[42]=C_h_intern(&lf[42],10,"perm/irwxg");
lf[43]=C_h_intern(&lf[43],10,"perm/irwxo");
lf[44]=C_h_intern(&lf[44],10,"perm/isvtx");
lf[45]=C_h_intern(&lf[45],10,"perm/isuid");
lf[46]=C_h_intern(&lf[46],10,"perm/isgid");
lf[47]=C_h_intern(&lf[47],12,"file-control");
lf[48]=C_h_intern(&lf[48],11,"\000file-error");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot control file");
lf[50]=C_h_intern(&lf[50],9,"file-open");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[52]=C_h_intern(&lf[52],17,"\003sysmake-c-string");
lf[53]=C_h_intern(&lf[53],20,"\003sysexpand-home-path");
lf[54]=C_h_intern(&lf[54],10,"file-close");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[56]=C_h_intern(&lf[56],11,"make-string");
lf[57]=C_h_intern(&lf[57],9,"file-read");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[59]=C_h_intern(&lf[59],11,"\000type-error");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[61]=C_h_intern(&lf[61],10,"file-write");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[64]=C_h_intern(&lf[64],12,"file-mkstemp");
lf[65]=C_h_intern(&lf[65],13,"\003syssubstring");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[67]=C_h_intern(&lf[67],11,"file-select");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\006failed");
lf[69]=C_h_intern(&lf[69],12,"\003sysfor-each");
lf[70]=C_h_intern(&lf[70],8,"seek/set");
lf[71]=C_h_intern(&lf[71],8,"seek/end");
lf[72]=C_h_intern(&lf[72],8,"seek/cur");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[76]=C_h_intern(&lf[76],9,"file-stat");
lf[77]=C_h_intern(&lf[77],9,"file-size");
lf[78]=C_h_intern(&lf[78],22,"file-modification-time");
lf[79]=C_h_intern(&lf[79],16,"file-access-time");
lf[80]=C_h_intern(&lf[80],16,"file-change-time");
lf[81]=C_h_intern(&lf[81],10,"file-owner");
lf[82]=C_h_intern(&lf[82],16,"file-permissions");
lf[83]=C_h_intern(&lf[83],13,"regular-file\077");
lf[84]=C_h_intern(&lf[84],14,"symbolic-link\077");
lf[85]=C_h_intern(&lf[85],18,"set-file-position!");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[87]=C_h_intern(&lf[87],6,"stream");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[89]=C_h_intern(&lf[89],5,"port\077");
lf[90]=C_h_intern(&lf[90],13,"\000bounds-error");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[92]=C_h_intern(&lf[92],13,"file-position");
lf[93]=C_h_intern(&lf[93],16,"create-directory");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[95]=C_h_intern(&lf[95],16,"change-directory");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[97]=C_h_intern(&lf[97],16,"delete-directory");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[99]=C_h_intern(&lf[99],10,"string-ref");
lf[100]=C_h_intern(&lf[100],6,"string");
lf[101]=C_h_intern(&lf[101],9,"directory");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[103]=C_h_intern(&lf[103],16,"\003sysmake-pointer");
lf[104]=C_h_intern(&lf[104],17,"current-directory");
lf[105]=C_h_intern(&lf[105],10,"directory\077");
lf[106]=C_h_intern(&lf[106],13,"\003sysfile-info");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[108]=C_h_intern(&lf[108],5,"\000text");
lf[109]=C_h_intern(&lf[109],9,"\003syserror");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[112]=C_h_intern(&lf[112],13,"\003sysmake-port");
lf[113]=C_h_intern(&lf[113],21,"\003sysstream-port-class");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[115]=C_h_intern(&lf[115],15,"open-input-pipe");
lf[116]=C_h_intern(&lf[116],7,"\000binary");
lf[117]=C_h_intern(&lf[117],16,"open-output-pipe");
lf[118]=C_h_intern(&lf[118],16,"close-input-pipe");
lf[119]=C_h_intern(&lf[119],23,"close-input/output-pipe");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[121]=C_h_intern(&lf[121],14,"\003syscheck-port");
lf[122]=C_h_intern(&lf[122],17,"close-output-pipe");
lf[123]=C_h_intern(&lf[123],20,"call-with-input-pipe");
lf[124]=C_h_intern(&lf[124],21,"call-with-output-pipe");
lf[125]=C_h_intern(&lf[125],20,"with-input-from-pipe");
lf[126]=C_h_intern(&lf[126],18,"\003sysstandard-input");
lf[127]=C_h_intern(&lf[127],19,"with-output-to-pipe");
lf[128]=C_h_intern(&lf[128],19,"\003sysstandard-output");
lf[129]=C_h_intern(&lf[129],11,"create-pipe");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/term");
lf[132]=C_h_intern(&lf[132],11,"signal/kill");
lf[133]=C_h_intern(&lf[133],10,"signal/int");
lf[134]=C_h_intern(&lf[134],10,"signal/hup");
lf[135]=C_h_intern(&lf[135],10,"signal/fpe");
lf[136]=C_h_intern(&lf[136],10,"signal/ill");
lf[137]=C_h_intern(&lf[137],11,"signal/segv");
lf[138]=C_h_intern(&lf[138],11,"signal/abrt");
lf[139]=C_h_intern(&lf[139],11,"signal/trap");
lf[140]=C_h_intern(&lf[140],11,"signal/quit");
lf[141]=C_h_intern(&lf[141],11,"signal/alrm");
lf[142]=C_h_intern(&lf[142],13,"signal/vtalrm");
lf[143]=C_h_intern(&lf[143],11,"signal/prof");
lf[144]=C_h_intern(&lf[144],9,"signal/io");
lf[145]=C_h_intern(&lf[145],10,"signal/urg");
lf[146]=C_h_intern(&lf[146],11,"signal/chld");
lf[147]=C_h_intern(&lf[147],11,"signal/cont");
lf[148]=C_h_intern(&lf[148],11,"signal/stop");
lf[149]=C_h_intern(&lf[149],11,"signal/tstp");
lf[150]=C_h_intern(&lf[150],11,"signal/pipe");
lf[151]=C_h_intern(&lf[151],11,"signal/xcpu");
lf[152]=C_h_intern(&lf[152],11,"signal/xfsz");
lf[153]=C_h_intern(&lf[153],11,"signal/usr1");
lf[154]=C_h_intern(&lf[154],11,"signal/usr2");
lf[155]=C_h_intern(&lf[155],12,"signal/winch");
lf[156]=C_h_intern(&lf[156],12,"signals-list");
lf[157]=C_h_intern(&lf[157],18,"\003sysinterrupt-hook");
lf[158]=C_h_intern(&lf[158],14,"signal-handler");
lf[159]=C_h_intern(&lf[159],19,"set-signal-handler!");
lf[160]=C_h_intern(&lf[160],16,"set-signal-mask!");
lf[161]=C_h_intern(&lf[161],14,"\000process-error");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot set signal mask");
lf[163]=C_h_intern(&lf[163],11,"signal-mask");
lf[164]=C_h_intern(&lf[164],14,"signal-masked\077");
lf[165]=C_h_intern(&lf[165],12,"signal-mask!");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot block signal");
lf[167]=C_h_intern(&lf[167],14,"signal-unmask!");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot unblock signal");
lf[169]=C_h_intern(&lf[169],18,"system-information");
lf[170]=C_h_intern(&lf[170],25,"\003syspeek-nonnull-c-string");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system information");
lf[172]=C_h_intern(&lf[172],12,"set-user-id!");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot set user ID");
lf[174]=C_h_intern(&lf[174],15,"current-user-id");
lf[175]=C_h_intern(&lf[175],25,"current-effective-user-id");
lf[176]=C_h_intern(&lf[176],13,"set-group-id!");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\023cannot set group ID");
lf[178]=C_h_intern(&lf[178],16,"current-group-id");
lf[179]=C_h_intern(&lf[179],26,"current-effective-group-id");
lf[180]=C_h_intern(&lf[180],16,"user-information");
lf[181]=C_h_intern(&lf[181],6,"vector");
lf[182]=C_h_intern(&lf[182],4,"list");
lf[183]=C_h_intern(&lf[183],17,"current-user-name");
lf[184]=C_h_intern(&lf[184],27,"current-effective-user-name");
lf[185]=C_h_intern(&lf[185],17,"group-information");
lf[187]=C_h_intern(&lf[187],10,"get-groups");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\047cannot retrieve supplementary group ids");
lf[191]=C_h_intern(&lf[191],11,"set-groups!");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot set supplementary group ids");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\015out of memory");
lf[194]=C_h_intern(&lf[194],17,"initialize-groups");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000)cannot initialize supplementary group ids");
lf[196]=C_h_intern(&lf[196],10,"errno/perm");
lf[197]=C_h_intern(&lf[197],11,"errno/noent");
lf[198]=C_h_intern(&lf[198],10,"errno/srch");
lf[199]=C_h_intern(&lf[199],10,"errno/intr");
lf[200]=C_h_intern(&lf[200],8,"errno/io");
lf[201]=C_h_intern(&lf[201],12,"errno/noexec");
lf[202]=C_h_intern(&lf[202],10,"errno/badf");
lf[203]=C_h_intern(&lf[203],11,"errno/child");
lf[204]=C_h_intern(&lf[204],11,"errno/nomem");
lf[205]=C_h_intern(&lf[205],11,"errno/acces");
lf[206]=C_h_intern(&lf[206],11,"errno/fault");
lf[207]=C_h_intern(&lf[207],10,"errno/busy");
lf[208]=C_h_intern(&lf[208],12,"errno/notdir");
lf[209]=C_h_intern(&lf[209],11,"errno/isdir");
lf[210]=C_h_intern(&lf[210],11,"errno/inval");
lf[211]=C_h_intern(&lf[211],11,"errno/mfile");
lf[212]=C_h_intern(&lf[212],11,"errno/nospc");
lf[213]=C_h_intern(&lf[213],11,"errno/spipe");
lf[214]=C_h_intern(&lf[214],10,"errno/pipe");
lf[215]=C_h_intern(&lf[215],11,"errno/again");
lf[216]=C_h_intern(&lf[216],10,"errno/rofs");
lf[217]=C_h_intern(&lf[217],11,"errno/exist");
lf[218]=C_h_intern(&lf[218],16,"errno/wouldblock");
lf[219]=C_h_intern(&lf[219],10,"errno/2big");
lf[220]=C_h_intern(&lf[220],12,"errno/deadlk");
lf[221]=C_h_intern(&lf[221],9,"errno/dom");
lf[222]=C_h_intern(&lf[222],10,"errno/fbig");
lf[223]=C_h_intern(&lf[223],11,"errno/ilseq");
lf[224]=C_h_intern(&lf[224],11,"errno/mlink");
lf[225]=C_h_intern(&lf[225],17,"errno/nametoolong");
lf[226]=C_h_intern(&lf[226],11,"errno/nfile");
lf[227]=C_h_intern(&lf[227],11,"errno/nodev");
lf[228]=C_h_intern(&lf[228],11,"errno/nolck");
lf[229]=C_h_intern(&lf[229],11,"errno/nosys");
lf[230]=C_h_intern(&lf[230],14,"errno/notempty");
lf[231]=C_h_intern(&lf[231],11,"errno/notty");
lf[232]=C_h_intern(&lf[232],10,"errno/nxio");
lf[233]=C_h_intern(&lf[233],11,"errno/range");
lf[234]=C_h_intern(&lf[234],10,"errno/xdev");
lf[235]=C_h_intern(&lf[235],16,"change-file-mode");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[237]=C_h_intern(&lf[237],17,"change-file-owner");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot change file owner");
lf[239]=C_h_intern(&lf[239],17,"file-read-access\077");
lf[240]=C_h_intern(&lf[240],18,"file-write-access\077");
lf[241]=C_h_intern(&lf[241],20,"file-execute-access\077");
lf[242]=C_h_intern(&lf[242],14,"create-session");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot create session");
lf[244]=C_h_intern(&lf[244],21,"set-process-group-id!");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot set process group ID");
lf[246]=C_h_intern(&lf[246],16,"process-group-id");
lf[247]=C_h_intern(&lf[247],20,"create-symbolic-link");
lf[248]=C_h_intern(&lf[248],18,"create-symbol-link");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create symbolic link");
lf[250]=C_h_intern(&lf[250],9,"substring");
lf[251]=C_h_intern(&lf[251],18,"read-symbolic-link");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot read symbolic link");
lf[253]=C_h_intern(&lf[253],9,"file-link");
lf[254]=C_h_intern(&lf[254],9,"hard-link");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\032could not create hard link");
lf[256]=C_h_intern(&lf[256],12,"fileno/stdin");
lf[257]=C_h_intern(&lf[257],13,"fileno/stdout");
lf[258]=C_h_intern(&lf[258],13,"fileno/stderr");
lf[259]=C_h_intern(&lf[259],7,"\000append");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[267]=C_h_intern(&lf[267],16,"open-input-file*");
lf[268]=C_h_intern(&lf[268],17,"open-output-file*");
lf[269]=C_h_intern(&lf[269],12,"port->fileno");
lf[270]=C_h_intern(&lf[270],6,"socket");
lf[271]=C_h_intern(&lf[271],20,"\003systcp-port->fileno");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[274]=C_h_intern(&lf[274],25,"\003syspeek-unsigned-integer");
lf[275]=C_h_intern(&lf[275],16,"duplicate-fileno");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file-descriptor");
lf[277]=C_h_intern(&lf[277],15,"make-input-port");
lf[278]=C_h_intern(&lf[278],14,"set-port-name!");
lf[279]=C_h_intern(&lf[279],21,"\003syscustom-input-port");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015cannot select");
lf[281]=C_h_intern(&lf[281],17,"\003systhread-yield!");
lf[282]=C_h_intern(&lf[282],25,"\003systhread-block-for-i/o!");
lf[283]=C_h_intern(&lf[283],18,"\003syscurrent-thread");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\013cannot read");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[288]=C_h_intern(&lf[288],17,"\003sysstring-append");
lf[289]=C_h_intern(&lf[289],15,"\003sysmake-string");
lf[290]=C_h_intern(&lf[290],20,"\003sysscan-buffer-line");
lf[291]=C_h_intern(&lf[291],4,"noop");
lf[292]=C_h_intern(&lf[292],16,"make-output-port");
lf[293]=C_h_intern(&lf[293],22,"\003syscustom-output-port");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot write");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\014cannot close");
lf[296]=C_h_intern(&lf[296],13,"file-truncate");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot truncate file");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[299]=C_h_intern(&lf[299],4,"lock");
lf[300]=C_h_intern(&lf[300],9,"file-lock");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[302]=C_h_intern(&lf[302],18,"file-lock/blocking");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot lock file");
lf[304]=C_h_intern(&lf[304],14,"file-test-lock");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[306]=C_h_intern(&lf[306],11,"file-unlock");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot unlock file");
lf[308]=C_h_intern(&lf[308],11,"create-fifo");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create FIFO");
lf[310]=C_h_intern(&lf[310],5,"fifo\077");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\023file does not exist");
lf[312]=C_h_intern(&lf[312],6,"setenv");
lf[313]=C_h_intern(&lf[313],8,"unsetenv");
lf[314]=C_h_intern(&lf[314],19,"current-environment");
lf[315]=C_h_intern(&lf[315],9,"prot/read");
lf[316]=C_h_intern(&lf[316],10,"prot/write");
lf[317]=C_h_intern(&lf[317],9,"prot/exec");
lf[318]=C_h_intern(&lf[318],9,"prot/none");
lf[319]=C_h_intern(&lf[319],9,"map/fixed");
lf[320]=C_h_intern(&lf[320],10,"map/shared");
lf[321]=C_h_intern(&lf[321],11,"map/private");
lf[322]=C_h_intern(&lf[322],13,"map/anonymous");
lf[323]=C_h_intern(&lf[323],8,"map/file");
lf[324]=C_h_intern(&lf[324],18,"map-file-to-memory");
lf[325]=C_h_intern(&lf[325],4,"mmap");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot map file to memory");
lf[327]=C_h_intern(&lf[327],20,"\003syspointer->address");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000)bad argument type - not a foreign pointer");
lf[329]=C_h_intern(&lf[329],16,"\003sysnull-pointer");
lf[330]=C_h_intern(&lf[330],22,"unmap-file-from-memory");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot unmap file from memory");
lf[332]=C_h_intern(&lf[332],26,"memory-mapped-file-pointer");
lf[333]=C_h_intern(&lf[333],19,"memory-mapped-file\077");
lf[334]=C_h_intern(&lf[334],19,"seconds->local-time");
lf[335]=C_h_intern(&lf[335],18,"\003sysdecode-seconds");
lf[336]=C_h_intern(&lf[336],17,"seconds->utc-time");
lf[337]=C_h_intern(&lf[337],15,"seconds->string");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[339]=C_h_intern(&lf[339],12,"time->string");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000$cannot convert time vector to string");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[342]=C_h_intern(&lf[342],19,"local-time->seconds");
lf[343]=C_h_intern(&lf[343],15,"\003syscons-flonum");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[346]=C_h_intern(&lf[346],17,"utc-time->seconds");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[349]=C_h_intern(&lf[349],27,"local-timezone-abbreviation");
lf[350]=C_h_intern(&lf[350],5,"_exit");
lf[351]=C_h_intern(&lf[351],10,"set-alarm!");
lf[352]=C_h_intern(&lf[352],19,"set-buffering-mode!");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[354]=C_h_intern(&lf[354],5,"\000full");
lf[355]=C_h_intern(&lf[355],5,"\000line");
lf[356]=C_h_intern(&lf[356],5,"\000none");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[358]=C_h_intern(&lf[358],14,"terminal-port\077");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000#port is not connected to a terminal");
lf[361]=C_h_intern(&lf[361],13,"terminal-name");
lf[362]=C_h_intern(&lf[362],13,"terminal-size");
lf[363]=C_h_intern(&lf[363],6,"\000error");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\036Unable to get size of terminal");
lf[365]=C_h_intern(&lf[365],17,"\003sysmake-locative");
lf[366]=C_h_intern(&lf[366],8,"location");
lf[367]=C_h_intern(&lf[367],13,"get-host-name");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[369]=C_h_intern(&lf[369],6,"regexp");
lf[370]=C_h_intern(&lf[370],21,"make-anchored-pattern");
lf[371]=C_h_intern(&lf[371],12,"string-match");
lf[372]=C_h_intern(&lf[372],12,"glob->regexp");
lf[373]=C_h_intern(&lf[373],13,"make-pathname");
lf[374]=C_h_intern(&lf[374],18,"decompose-pathname");
lf[375]=C_h_intern(&lf[375],4,"glob");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[378]=C_h_intern(&lf[378],12,"process-fork");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot create child process");
lf[380]=C_h_intern(&lf[380],24,"pathname-strip-directory");
lf[381]=C_h_intern(&lf[381],15,"process-execute");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[383]=C_h_intern(&lf[383],16,"\003sysprocess-wait");
lf[384]=C_h_intern(&lf[384],12,"process-wait");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[386]=C_h_intern(&lf[386],18,"current-process-id");
lf[387]=C_h_intern(&lf[387],17,"parent-process-id");
lf[388]=C_h_intern(&lf[388],5,"sleep");
lf[389]=C_h_intern(&lf[389],14,"process-signal");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000 could not send signal to process");
lf[391]=C_h_intern(&lf[391],17,"\003sysshell-command");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\007/bin/sh");
lf[393]=C_h_intern(&lf[393],6,"getenv");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\005SHELL");
lf[395]=C_h_intern(&lf[395],27,"\003sysshell-command-arguments");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[397]=C_h_intern(&lf[397],11,"process-run");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\025abnormal process exit");
lf[399]=C_h_intern(&lf[399],11,"\003sysprocess");
lf[400]=C_h_intern(&lf[400],19,"\003sysundefined-value");
lf[401]=C_h_intern(&lf[401],7,"process");
lf[402]=C_h_intern(&lf[402],8,"process*");
lf[403]=C_h_intern(&lf[403],10,"find-files");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[407]=C_h_intern(&lf[407],16,"\003sysdynamic-wind");
lf[408]=C_h_intern(&lf[408],13,"pathname-file");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[410]=C_h_intern(&lf[410],7,"regexp\077");
lf[411]=C_h_intern(&lf[411],19,"set-root-directory!");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\037unable to change root directory");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve process group ID");
lf[414]=C_h_intern(&lf[414],18,"getter-with-setter");
lf[415]=C_h_intern(&lf[415],26,"effective-group-id!-setter");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot set effective group ID");
lf[417]=C_h_intern(&lf[417],25,"effective-user-id!-setter");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot set effective user ID");
lf[419]=C_h_intern(&lf[419],23,"\003sysuser-interrupt-hook");
lf[420]=C_h_intern(&lf[420],11,"make-vector");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[423]=C_h_intern(&lf[423],17,"register-feature!");
lf[424]=C_h_intern(&lf[424],5,"posix");
C_register_lf2(lf,425,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1493,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1491 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1494 in k1491 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1497 in k1494 in k1491 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1499,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 431  register-feature! */
t3=*((C_word*)lf[423]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[424]);}

/* k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word ab[67],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1505,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1512,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1,lf[3]);
t5=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1530,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1533,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t8=C_mutate((C_word*)lf[12]+1,C_fix((C_word)F_DUPFD));
t9=C_mutate((C_word*)lf[13]+1,C_fix((C_word)F_GETFD));
t10=C_mutate((C_word*)lf[14]+1,C_fix((C_word)F_SETFD));
t11=C_mutate((C_word*)lf[15]+1,C_fix((C_word)F_GETFL));
t12=C_mutate((C_word*)lf[16]+1,C_fix((C_word)F_SETFL));
t13=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_RDONLY));
t14=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_WRONLY));
t15=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_RDWR));
t16=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_RDONLY));
t17=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_WRONLY));
t18=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_CREAT));
t19=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_APPEND));
t20=C_mutate((C_word*)lf[24]+1,C_fix((C_word)O_EXCL));
t21=C_mutate((C_word*)lf[25]+1,C_fix((C_word)O_NOCTTY));
t22=C_mutate((C_word*)lf[26]+1,C_fix((C_word)O_NONBLOCK));
t23=C_mutate((C_word*)lf[27]+1,C_fix((C_word)O_TRUNC));
t24=C_mutate((C_word*)lf[28]+1,C_fix((C_word)O_FSYNC));
t25=C_mutate((C_word*)lf[29]+1,C_fix((C_word)O_FSYNC));
t26=C_mutate((C_word*)lf[30]+1,C_fix((C_word)O_BINARY));
t27=C_mutate((C_word*)lf[31]+1,C_fix((C_word)O_TEXT));
t28=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IRUSR));
t29=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IWUSR));
t30=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IXUSR));
t31=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IRGRP));
t32=C_mutate((C_word*)lf[36]+1,C_fix((C_word)S_IWGRP));
t33=C_mutate((C_word*)lf[37]+1,C_fix((C_word)S_IXGRP));
t34=C_mutate((C_word*)lf[38]+1,C_fix((C_word)S_IROTH));
t35=C_mutate((C_word*)lf[39]+1,C_fix((C_word)S_IWOTH));
t36=C_mutate((C_word*)lf[40]+1,C_fix((C_word)S_IXOTH));
t37=C_mutate((C_word*)lf[41]+1,C_fix((C_word)S_IRWXU));
t38=C_mutate((C_word*)lf[42]+1,C_fix((C_word)S_IRWXG));
t39=C_mutate((C_word*)lf[43]+1,C_fix((C_word)S_IRWXO));
t40=C_mutate((C_word*)lf[44]+1,C_fix((C_word)S_ISVTX));
t41=C_mutate((C_word*)lf[45]+1,C_fix((C_word)S_ISUID));
t42=C_mutate((C_word*)lf[46]+1,C_fix((C_word)S_ISGID));
t43=C_mutate((C_word*)lf[47]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1574,tmp=(C_word)a,a+=2,tmp));
t44=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRGRP),C_fix((C_word)S_IROTH));
t45=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IRWXU),t44);
t46=C_mutate((C_word*)lf[50]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[54]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1651,tmp=(C_word)a,a+=2,tmp));
t48=*((C_word*)lf[56]+1);
t49=C_mutate((C_word*)lf[57]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=t48,tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1708,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1747,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1779,tmp=(C_word)a,a+=2,tmp);
t53=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1781,tmp=(C_word)a,a+=2,tmp);
t54=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1783,tmp=(C_word)a,a+=2,tmp);
t55=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1785,a[2]=t53,a[3]=t54,a[4]=t52,tmp=(C_word)a,a+=5,tmp));
t56=C_mutate((C_word*)lf[70]+1,C_fix((C_word)SEEK_SET));
t57=C_mutate((C_word*)lf[71]+1,C_fix((C_word)SEEK_END));
t58=C_mutate((C_word*)lf[72]+1,C_fix((C_word)SEEK_CUR));
t59=C_mutate(&lf[73],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1977,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2014,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2039,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[78]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2045,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2051,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[80]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2057,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2063,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[82]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2069,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2075,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2084,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2093,tmp=(C_word)a,a+=2,tmp));
t70=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2153,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t71=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6510,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 736  getter-with-setter */
t72=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t72+1)))(4,t72,t70,t71,*((C_word*)lf[85]+1));}

/* a6509 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6510,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6514,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6526,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 738  port? */
t5=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6524 in a6509 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[87]);
t4=((C_word*)t0)[2];
f_6514(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_6514(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixunix.scm: 743  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[59],lf[92],lf[422],((C_word*)t0)[3]);}}}

/* k6512 in a6509 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6517,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 745  posix-error */
t3=lf[3];
f_1512(6,t3,t2,lf[48],lf[92],lf[421],((C_word*)t0)[2]);}
else{
t3=t2;
f_6517(2,t3,C_SCHEME_UNDEFINED);}}

/* k6515 in k6512 in a6509 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[130],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2153,2,t0,t1);}
t2=C_mutate((C_word*)lf[92]+1,t1);
t3=C_mutate((C_word*)lf[93]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2155,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2179,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[97]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2203,tmp=(C_word)a,a+=2,tmp));
t6=*((C_word*)lf[99]+1);
t7=*((C_word*)lf[56]+1);
t8=*((C_word*)lf[100]+1);
t9=C_mutate((C_word*)lf[101]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2227,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2381,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[56]+1);
t12=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2404,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2440,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2452,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2458,tmp=(C_word)a,a+=2,tmp);
t16=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2473,a[2]=t14,a[3]=t15,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t17=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2509,a[2]=t14,a[3]=t15,a[4]=t13,tmp=(C_word)a,a+=5,tmp));
t18=C_mutate((C_word*)lf[118]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2545,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[122]+1,*((C_word*)lf[118]+1));
t20=*((C_word*)lf[115]+1);
t21=*((C_word*)lf[117]+1);
t22=*((C_word*)lf[118]+1);
t23=*((C_word*)lf[122]+1);
t24=C_mutate((C_word*)lf[123]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2561,a[2]=t20,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[124]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=t21,a[3]=t23,tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[125]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2609,a[2]=t20,a[3]=t22,tmp=(C_word)a,a+=4,tmp));
t27=C_mutate((C_word*)lf[127]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2629,a[2]=t21,a[3]=t23,tmp=(C_word)a,a+=4,tmp));
t28=C_mutate((C_word*)lf[129]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2649,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[131]+1,C_fix((C_word)SIGTERM));
t30=C_mutate((C_word*)lf[132]+1,C_fix((C_word)SIGKILL));
t31=C_mutate((C_word*)lf[133]+1,C_fix((C_word)SIGINT));
t32=C_mutate((C_word*)lf[134]+1,C_fix((C_word)SIGHUP));
t33=C_mutate((C_word*)lf[135]+1,C_fix((C_word)SIGFPE));
t34=C_mutate((C_word*)lf[136]+1,C_fix((C_word)SIGILL));
t35=C_mutate((C_word*)lf[137]+1,C_fix((C_word)SIGSEGV));
t36=C_mutate((C_word*)lf[138]+1,C_fix((C_word)SIGABRT));
t37=C_mutate((C_word*)lf[139]+1,C_fix((C_word)SIGTRAP));
t38=C_mutate((C_word*)lf[140]+1,C_fix((C_word)SIGQUIT));
t39=C_mutate((C_word*)lf[141]+1,C_fix((C_word)SIGALRM));
t40=C_mutate((C_word*)lf[142]+1,C_fix((C_word)SIGVTALRM));
t41=C_mutate((C_word*)lf[143]+1,C_fix((C_word)SIGPROF));
t42=C_mutate((C_word*)lf[144]+1,C_fix((C_word)SIGIO));
t43=C_mutate((C_word*)lf[145]+1,C_fix((C_word)SIGURG));
t44=C_mutate((C_word*)lf[146]+1,C_fix((C_word)SIGCHLD));
t45=C_mutate((C_word*)lf[147]+1,C_fix((C_word)SIGCONT));
t46=C_mutate((C_word*)lf[148]+1,C_fix((C_word)SIGSTOP));
t47=C_mutate((C_word*)lf[149]+1,C_fix((C_word)SIGTSTP));
t48=C_mutate((C_word*)lf[150]+1,C_fix((C_word)SIGPIPE));
t49=C_mutate((C_word*)lf[151]+1,C_fix((C_word)SIGXCPU));
t50=C_mutate((C_word*)lf[152]+1,C_fix((C_word)SIGXFSZ));
t51=C_mutate((C_word*)lf[153]+1,C_fix((C_word)SIGUSR1));
t52=C_mutate((C_word*)lf[154]+1,C_fix((C_word)SIGUSR2));
t53=C_mutate((C_word*)lf[155]+1,C_fix((C_word)SIGWINCH));
t54=(C_word)C_a_i_list(&a,25,*((C_word*)lf[131]+1),*((C_word*)lf[132]+1),*((C_word*)lf[133]+1),*((C_word*)lf[134]+1),*((C_word*)lf[135]+1),*((C_word*)lf[136]+1),*((C_word*)lf[137]+1),*((C_word*)lf[138]+1),*((C_word*)lf[139]+1),*((C_word*)lf[140]+1),*((C_word*)lf[141]+1),*((C_word*)lf[142]+1),*((C_word*)lf[143]+1),*((C_word*)lf[144]+1),*((C_word*)lf[145]+1),*((C_word*)lf[146]+1),*((C_word*)lf[147]+1),*((C_word*)lf[148]+1),*((C_word*)lf[149]+1),*((C_word*)lf[150]+1),*((C_word*)lf[151]+1),*((C_word*)lf[152]+1),*((C_word*)lf[153]+1),*((C_word*)lf[154]+1),*((C_word*)lf[155]+1));
t55=C_mutate((C_word*)lf[156]+1,t54);
t56=*((C_word*)lf[157]+1);
t57=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2694,a[2]=((C_word*)t0)[2],a[3]=t56,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 972  make-vector */
t58=*((C_word*)lf[420]+1);
((C_proc4)(void*)(*((C_word*)t58+1)))(4,t58,t57,C_fix(256),C_SCHEME_FALSE);}

/* k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2694,2,t0,t1);}
t2=C_mutate((C_word*)lf[158]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2696,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[159]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2705,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[157]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[160]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2736,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[163]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2760,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[164]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2792,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[165]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2798,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[167]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2813,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2829,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6504,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1028 set-signal-handler! */
t12=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,*((C_word*)lf[133]+1),t11);}

/* a6503 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6504(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6504,3,t0,t1,t2);}
/* posixunix.scm: 1030 ##sys#user-interrupt-hook */
t3=*((C_word*)lf[419]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2829,2,t0,t1);}
t2=C_mutate((C_word*)lf[169]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2831,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[172]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2869,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6501,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1060 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[172]+1));}

/* a6500 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6501,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub332(C_SCHEME_UNDEFINED));}

/* k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2886,2,t0,t1);}
t2=C_mutate((C_word*)lf[174]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6483,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6486,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1065 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6485 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6486,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_seteuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6496,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1069 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6494 in a6485 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1070 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[417],lf[418],((C_word*)t0)[2]);}

/* a6482 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6483,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub334(C_SCHEME_UNDEFINED));}

/* k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=C_mutate((C_word*)lf[175]+1,t1);
t3=C_mutate((C_word*)lf[176]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2892,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6480,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1080 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,*((C_word*)lf[176]+1));}

/* a6479 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6480,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub340(C_SCHEME_UNDEFINED));}

/* k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2909,2,t0,t1);}
t2=C_mutate((C_word*)lf[178]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6462,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6465,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1085 getter-with-setter */
t6=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a6464 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6465,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setegid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6475,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1089 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6473 in a6464 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1090 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[415],lf[416],((C_word*)t0)[2]);}

/* a6461 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6462,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub342(C_SCHEME_UNDEFINED));}

/* k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=C_mutate((C_word*)lf[179]+1,t1);
t3=C_mutate((C_word*)lf[180]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2915,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[183]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2975,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[184]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2989,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3009,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[186],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3084,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3087,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[191]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3150,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[194]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3216,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[196]+1,C_fix((C_word)EPERM));
t12=C_mutate((C_word*)lf[197]+1,C_fix((C_word)ENOENT));
t13=C_mutate((C_word*)lf[198]+1,C_fix((C_word)ESRCH));
t14=C_mutate((C_word*)lf[199]+1,C_fix((C_word)EINTR));
t15=C_mutate((C_word*)lf[200]+1,C_fix((C_word)EIO));
t16=C_mutate((C_word*)lf[201]+1,C_fix((C_word)ENOEXEC));
t17=C_mutate((C_word*)lf[202]+1,C_fix((C_word)EBADF));
t18=C_mutate((C_word*)lf[203]+1,C_fix((C_word)ECHILD));
t19=C_mutate((C_word*)lf[204]+1,C_fix((C_word)ENOMEM));
t20=C_mutate((C_word*)lf[205]+1,C_fix((C_word)EACCES));
t21=C_mutate((C_word*)lf[206]+1,C_fix((C_word)EFAULT));
t22=C_mutate((C_word*)lf[207]+1,C_fix((C_word)EBUSY));
t23=C_mutate((C_word*)lf[208]+1,C_fix((C_word)ENOTDIR));
t24=C_mutate((C_word*)lf[209]+1,C_fix((C_word)EISDIR));
t25=C_mutate((C_word*)lf[210]+1,C_fix((C_word)EINVAL));
t26=C_mutate((C_word*)lf[211]+1,C_fix((C_word)EMFILE));
t27=C_mutate((C_word*)lf[212]+1,C_fix((C_word)ENOSPC));
t28=C_mutate((C_word*)lf[213]+1,C_fix((C_word)ESPIPE));
t29=C_mutate((C_word*)lf[214]+1,C_fix((C_word)EPIPE));
t30=C_mutate((C_word*)lf[215]+1,C_fix((C_word)EAGAIN));
t31=C_mutate((C_word*)lf[216]+1,C_fix((C_word)EROFS));
t32=C_mutate((C_word*)lf[217]+1,C_fix((C_word)EEXIST));
t33=C_mutate((C_word*)lf[218]+1,C_fix((C_word)EWOULDBLOCK));
t34=C_set_block_item(lf[219],0,C_fix(0));
t35=C_set_block_item(lf[220],0,C_fix(0));
t36=C_set_block_item(lf[221],0,C_fix(0));
t37=C_set_block_item(lf[222],0,C_fix(0));
t38=C_set_block_item(lf[223],0,C_fix(0));
t39=C_set_block_item(lf[224],0,C_fix(0));
t40=C_set_block_item(lf[225],0,C_fix(0));
t41=C_set_block_item(lf[226],0,C_fix(0));
t42=C_set_block_item(lf[227],0,C_fix(0));
t43=C_set_block_item(lf[228],0,C_fix(0));
t44=C_set_block_item(lf[229],0,C_fix(0));
t45=C_set_block_item(lf[230],0,C_fix(0));
t46=C_set_block_item(lf[231],0,C_fix(0));
t47=C_set_block_item(lf[232],0,C_fix(0));
t48=C_set_block_item(lf[233],0,C_fix(0));
t49=C_set_block_item(lf[234],0,C_fix(0));
t50=C_mutate((C_word*)lf[235]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3280,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[237]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3307,tmp=(C_word)a,a+=2,tmp));
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3337,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3361,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t54=C_mutate((C_word*)lf[240]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3367,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t55=C_mutate((C_word*)lf[241]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=t52,tmp=(C_word)a,a+=3,tmp));
t56=C_mutate((C_word*)lf[242]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3379,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[244]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3394,tmp=(C_word)a,a+=2,tmp));
t58=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t59=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6444,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 1312 getter-with-setter */
t60=*((C_word*)lf[414]+1);
((C_proc4)(void*)(*((C_word*)t60+1)))(4,t60,t58,t59,*((C_word*)lf[244]+1));}

/* a6443 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6444,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[246]);
t4=(C_word)C_getpgid(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6451,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t4,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6457,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1317 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_6451(2,t6,C_SCHEME_UNDEFINED);}}

/* k6455 in a6443 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1318 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[246],lf[413],((C_word*)t0)[2]);}

/* k6449 in a6443 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
t2=C_mutate((C_word*)lf[246]+1,t1);
t3=C_mutate((C_word*)lf[247]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3419,tmp=(C_word)a,a+=2,tmp));
t4=*((C_word*)lf[250]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_u_fixnum_plus(C_fix((C_word)FILENAME_MAX),C_fix(1));
/* posixunix.scm: 1339 make-string */
t7=*((C_word*)lf[56]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word ab[187],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=C_mutate((C_word*)lf[251]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[253]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3499,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[256]+1,C_fix((C_word)STDIN_FILENO));
t5=C_mutate((C_word*)lf[257]+1,C_fix((C_word)STDOUT_FILENO));
t6=C_mutate((C_word*)lf[258]+1,C_fix((C_word)STDERR_FILENO));
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3524,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3561,tmp=(C_word)a,a+=2,tmp);
t9=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3576,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[268]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3590,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t11=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3604,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[275]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3649,tmp=(C_word)a,a+=2,tmp));
t13=*((C_word*)lf[277]+1);
t14=*((C_word*)lf[278]+1);
t15=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3676,a[2]=t13,a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[292]+1);
t17=*((C_word*)lf[278]+1);
t18=C_mutate((C_word*)lf[293]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4109,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=C_mutate((C_word*)lf[296]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4365,tmp=(C_word)a,a+=2,tmp));
t20=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4404,tmp=(C_word)a,a+=2,tmp);
t21=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4475,tmp=(C_word)a,a+=2,tmp);
t22=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4493,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4508,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t24=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=t20,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t25=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4545,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4573,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4616,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4642,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4659,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4674,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[315]+1,C_fix((C_word)PROT_READ));
t32=C_mutate((C_word*)lf[316]+1,C_fix((C_word)PROT_WRITE));
t33=C_mutate((C_word*)lf[317]+1,C_fix((C_word)PROT_EXEC));
t34=C_mutate((C_word*)lf[318]+1,C_fix((C_word)PROT_NONE));
t35=C_mutate((C_word*)lf[319]+1,C_fix((C_word)MAP_FIXED));
t36=C_mutate((C_word*)lf[320]+1,C_fix((C_word)MAP_SHARED));
t37=C_mutate((C_word*)lf[321]+1,C_fix((C_word)MAP_PRIVATE));
t38=C_mutate((C_word*)lf[322]+1,C_fix((C_word)MAP_ANON));
t39=C_mutate((C_word*)lf[323]+1,C_fix((C_word)MAP_FILE));
t40=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4757,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4815,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4850,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4859,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4865,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4874,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4888,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4916,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4955,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[346]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4983,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[349]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5011,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[350]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5019,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[351]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5035,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[352]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5038,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[358]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5097,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate(&lf[359],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5116,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[361]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5143,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[362]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5162,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[367]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5197,tmp=(C_word)a,a+=2,tmp));
t59=*((C_word*)lf[369]+1);
t60=*((C_word*)lf[370]+1);
t61=*((C_word*)lf[371]+1);
t62=*((C_word*)lf[372]+1);
t63=*((C_word*)lf[101]+1);
t64=*((C_word*)lf[373]+1);
t65=*((C_word*)lf[374]+1);
t66=C_mutate((C_word*)lf[375]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5209,a[2]=t62,a[3]=t60,a[4]=t59,a[5]=t63,a[6]=t61,a[7]=t64,a[8]=t65,tmp=(C_word)a,a+=9,tmp));
t67=C_mutate((C_word*)lf[378]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5321,tmp=(C_word)a,a+=2,tmp));
t68=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5359,tmp=(C_word)a,a+=2,tmp);
t69=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5367,tmp=(C_word)a,a+=2,tmp);
t70=*((C_word*)lf[380]+1);
t71=C_mutate((C_word*)lf[381]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5375,a[2]=t70,a[3]=t69,a[4]=t68,tmp=(C_word)a,a+=5,tmp));
t72=C_mutate((C_word*)lf[383]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5554,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[384]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5571,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[386]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5646,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[387]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5649,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[388]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5652,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[389]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5655,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[391]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5682,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[395]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5691,tmp=(C_word)a,a+=2,tmp));
t80=*((C_word*)lf[378]+1);
t81=*((C_word*)lf[381]+1);
t82=*((C_word*)lf[393]+1);
t83=C_mutate((C_word*)lf[397]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5697,a[2]=t80,a[3]=t81,tmp=(C_word)a,a+=4,tmp));
t84=*((C_word*)lf[129]+1);
t85=*((C_word*)lf[384]+1);
t86=*((C_word*)lf[378]+1);
t87=*((C_word*)lf[381]+1);
t88=*((C_word*)lf[275]+1);
t89=*((C_word*)lf[54]+1);
t90=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5753,a[2]=t85,tmp=(C_word)a,a+=3,tmp);
t91=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5790,a[2]=t84,tmp=(C_word)a,a+=3,tmp);
t92=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5810,a[2]=t89,tmp=(C_word)a,a+=3,tmp);
t93=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5824,a[2]=t89,tmp=(C_word)a,a+=3,tmp);
t94=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5841,tmp=(C_word)a,a+=2,tmp);
t95=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5857,a[2]=t91,a[3]=t86,a[4]=t93,a[5]=t87,a[6]=t94,tmp=(C_word)a,a+=7,tmp);
t96=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=t92,tmp=(C_word)a,a+=3,tmp);
t97=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5913,a[2]=t92,tmp=(C_word)a,a+=3,tmp);
t98=C_mutate((C_word*)lf[399]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5924,a[2]=t97,a[3]=t90,a[4]=t96,a[5]=t95,tmp=(C_word)a,a+=6,tmp));
t99=*((C_word*)lf[400]+1);
t100=C_mutate((C_word*)lf[401]+1,t99);
t101=*((C_word*)lf[400]+1);
t102=C_mutate((C_word*)lf[402]+1,t101);
t103=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5988,tmp=(C_word)a,a+=2,tmp);
t104=C_mutate((C_word*)lf[401]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6049,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[402]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6106,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t106=*((C_word*)lf[375]+1);
t107=*((C_word*)lf[371]+1);
t108=*((C_word*)lf[373]+1);
t109=*((C_word*)lf[105]+1);
t110=C_mutate((C_word*)lf[403]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6163,a[2]=t109,a[3]=t108,a[4]=t106,a[5]=t107,tmp=(C_word)a,a+=6,tmp));
t111=C_mutate((C_word*)lf[411]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6421,tmp=(C_word)a,a+=2,tmp));
t112=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t112+1)))(2,t112,C_SCHEME_UNDEFINED);}

/* set-root-directory! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6421(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6421,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[411]);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6417,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* ##sys#make-c-string */
t6=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t6=t5;
f_6417(2,t6,C_SCHEME_FALSE);}}

/* k6415 in set-root-directory! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub1243(C_SCHEME_UNDEFINED,t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 2169 posix-error */
t3=lf[3];
f_1512(6,t3,((C_word*)t0)[3],lf[48],lf[411],lf[412],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6163(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_6163r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_6163r(t0,t1,t2,t3,t4);}}

static void C_ccall f_6163r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6336,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6341,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6346,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action11961232 */
t9=t8;
f_6346(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id11971230 */
t11=t7;
f_6341(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit11981227 */
t13=t6;
f_6336(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body11941200 */
t15=t5;
f_6165(t15,t1,t9,t11,t13);}}}}

/* def-action1196 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6346,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6352,tmp=(C_word)a,a+=2,tmp);
/* def-id11971230 */
t3=((C_word*)t0)[2];
f_6341(t3,t1,t2);}

/* a6351 in def-action1196 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6352(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6352,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id1197 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6341(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6341,NULL,3,t0,t1,t2);}
/* def-limit11981227 */
t3=((C_word*)t0)[2];
f_6336(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit1198 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6336(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6336,NULL,4,t0,t1,t2,t3);}
/* body11941200 */
t4=((C_word*)t0)[2];
f_6165(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6165(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6165,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[403]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6172,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t2,a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_6172(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6331,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_6172(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6323,tmp=(C_word)a,a+=2,tmp));}}

/* f_6323 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6323,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_6331 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6331(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6331,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6172,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t2)){
t4=t3;
f_6311(2,t4,t2);}
else{
/* posixunix.scm: 2141 regexp? */
t4=*((C_word*)lf[410]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[11]);}}

/* k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6311,2,t0,t1);}
t2=(C_truep(t1)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6305,a[2]=t3,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2144 make-pathname */
t5=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[409]);}

/* k6303 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2144 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6182,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6184,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_6184(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6184(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6184,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2150 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6203,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2151 pathname-file */
t3=*((C_word*)lf[408]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6291,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2158 pproc */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6289 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6291,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2158 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 2159 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_6184(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k6296 in k6289 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2158 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6184(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6285,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[404]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[405]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixunix.scm: 2151 loop */
t2=((C_word*)((C_word*)t0)[12])[1];
f_6184(t2,((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9]);}
else{
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* posixunix.scm: 2152 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}}

/* k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6218,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[11])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6228,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6230,a[2]=t4,a[3]=((C_word*)t0)[11],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6262,a[2]=t6,a[3]=((C_word*)t0)[11],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2154 ##sys#dynamic-wind */
t11=*((C_word*)lf[407]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6275,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6278,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2157 pproc */
t4=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}}

/* k6276 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2157 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6275(2,t2,((C_word*)t0)[2]);}}

/* k6273 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2157 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6184(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6261 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6262,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[400]+1));}

/* a6237 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6260,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2155 make-pathname */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[6],lf[406]);}

/* k6258 in a6237 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2155 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6244 in a6237 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6250,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2156 pproc */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k6251 in k6244 in a6237 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2156 action */
t2=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_6250(2,t2,((C_word*)t0)[2]);}}

/* k6248 in k6244 in a6237 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6250(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2155 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6184(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6229 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6230,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[400]+1));}

/* k6226 in k6216 in k6283 in k6201 in loop in k6180 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2153 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6184(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_6312 in k6309 in k6170 in body1194 in find-files in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6312,3,t0,t1,t2);}
/* posixunix.scm: 2142 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* process* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6106r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6106r(t0,t1,t2,t3);}}

static void C_ccall f_6106r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6108,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6113,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6118,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11701178 */
t7=t6;
f_6118(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env11711176 */
t9=t5;
f_6113(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body11681173 */
t11=t4;
f_6108(t11,t1,t7,t9);}}}

/* def-args1170 in process* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6118,NULL,2,t0,t1);}
/* def-env11711176 */
t2=((C_word*)t0)[2];
f_6113(t2,t1,C_SCHEME_FALSE);}

/* def-env1171 in process* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6113,NULL,3,t0,t1,t2);}
/* body11681173 */
t3=((C_word*)t0)[2];
f_6108(t3,t1,t2,C_SCHEME_FALSE);}

/* body1168 in process* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6108(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6108,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2119 %process */
f_5988(t1,lf[402],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3);}

/* process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6049(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_6049r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6049r(t0,t1,t2,t3);}}

static void C_ccall f_6049r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6051,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6056,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6061,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args11501158 */
t7=t6;
f_6061(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-env11511156 */
t9=t5;
f_6056(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body11481153 */
t11=t4;
f_6051(t11,t1,t7,t9);}}}

/* def-args1150 in process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6061(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6061,NULL,2,t0,t1);}
/* def-env11511156 */
t2=((C_word*)t0)[2];
f_6056(t2,t1,C_SCHEME_FALSE);}

/* def-env1151 in process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6056(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6056,NULL,3,t0,t1,t2);}
/* body11481153 */
t3=((C_word*)t0)[2];
f_6051(t3,t1,t2,C_SCHEME_FALSE);}

/* body1148 in process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_6051(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6051,NULL,4,t0,t1,t2,t3);}
/* posixunix.scm: 2116 %process */
f_5988(t1,lf[401],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3);}

/* %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5988(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5988,NULL,6,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5990,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t10=(C_word)C_i_check_string_2(((C_word*)t7)[1],t2);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6009,a[2]=t9,a[3]=t1,a[4]=t3,a[5]=t6,a[6]=t8,a[7]=t7,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t8)[1])){
/* posixunix.scm: 2105 chkstrlst */
t12=t9;
f_5990(t12,t11,((C_word*)t8)[1]);}
else{
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6043,a[2]=t11,a[3]=t7,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2107 ##sys#shell-command-arguments */
t13=*((C_word*)lf[395]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,((C_word*)t7)[1]);}}

/* k6041 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6043,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2108 ##sys#shell-command */
t4=*((C_word*)lf[391]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6045 in k6041 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_6009(2,t3,t2);}

/* k6007 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6012,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 2109 chkstrlst */
t3=((C_word*)t0)[2];
f_5990(t3,t2,((C_word*)t0)[5]);}
else{
t3=t2;
f_6012(2,t3,C_SCHEME_UNDEFINED);}}

/* k6010 in k6007 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 2110 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a6022 in k6010 in k6007 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_6023,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixunix.scm: 2112 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixunix.scm: 2113 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a6016 in k6010 in k6007 in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
/* posixunix.scm: 2110 ##sys#process */
t2=*((C_word*)lf[399]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,t1,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[3],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* chkstrlst in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5990(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5990,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5998 in chkstrlst in %process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5999,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5924(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_5924,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5930,a[2]=t8,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t4,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t6,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5936(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_5936,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_not(((C_word*)t0)[9]);
t7=(C_word)C_i_not(((C_word*)t0)[8]);
t8=(C_word)C_i_not(((C_word*)t0)[7]);
t9=(C_word)C_a_i_vector(&a,3,t6,t7,t8);
t10=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5947,a[2]=((C_word*)t0)[8],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],a[12]=t5,a[13]=t1,tmp=(C_word)a,a+=14,tmp);
t11=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5967,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t10,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2086 make-on-close */
t12=((C_word*)t0)[3];
f_5753(t12,t11,((C_word*)t0)[5],t5,t9,C_fix(0),C_fix(1),C_fix(2));}

/* k5965 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2085 input-port */
t2=((C_word*)t0)[7];
f_5902(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5945 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5951,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[12],a[10]=t1,a[11]=((C_word*)t0)[13],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2088 make-on-close */
t4=((C_word*)t0)[6];
f_5753(t4,t3,((C_word*)t0)[10],((C_word*)t0)[12],((C_word*)t0)[5],C_fix(1),C_fix(0),C_fix(2));}

/* k5961 in k5945 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2087 output-port */
t2=((C_word*)t0)[7];
f_5913(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5949 in k5945 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5955,a[2]=((C_word*)t0)[9],a[3]=t1,a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 2091 make-on-close */
t4=((C_word*)t0)[3];
f_5753(t4,t3,((C_word*)t0)[7],((C_word*)t0)[9],((C_word*)t0)[2],C_fix(2),C_fix(0),C_fix(1));}

/* k5957 in k5949 in k5945 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2090 input-port */
t2=((C_word*)t0)[7];
f_5902(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5953 in k5949 in k5945 in a5935 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2084 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5929 in ##sys#process in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5930,2,t0,t1);}
/* posixunix.scm: 2079 spawn */
t2=((C_word*)t0)[8];
f_5857(t2,t1,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5913(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5913,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5917,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2075 connect-parent */
t8=((C_word*)t0)[2];
f_5810(t8,t7,t4,t5);}

/* k5915 in output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2076 ##sys#custom-output-port */
t2=*((C_word*)lf[293]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5902(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5902,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5906,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 2071 connect-parent */
t8=((C_word*)t0)[2];
f_5810(t8,t7,t4,t5);}

/* k5904 in input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixunix.scm: 2072 ##sys#custom-input-port */
t2=*((C_word*)lf[279]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_SCHEME_TRUE,C_fix(256),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5857(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5857,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[4],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=((C_word*)t0)[5],a[12]=t1,a[13]=((C_word*)t0)[6],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2058 needed-pipe */
t9=((C_word*)t0)[2];
f_5790(t9,t8,t6);}

/* k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5864,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2059 needed-pipe */
t3=((C_word*)t0)[2];
f_5790(t3,t2,((C_word*)t0)[5]);}

/* k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_5867,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* posixunix.scm: 2060 needed-pipe */
t3=((C_word*)t0)[2];
f_5790(t3,t2,((C_word*)t0)[6]);}

/* k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5867,2,t0,t1);}
t2=f_5841(C_a_i(&a,3),((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5878,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[10],tmp=(C_word)a,a+=14,tmp);
/* posixunix.scm: 2063 process-fork */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5879 in k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5884,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=t1,a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
/* posixunix.scm: 2065 connect-child */
t3=((C_word*)t0)[7];
f_5824(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],*((C_word*)lf[256]+1));}

/* k5882 in a5879 in k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=f_5841(C_a_i(&a,3),((C_word*)t0)[3]);
/* posixunix.scm: 2066 connect-child */
t4=((C_word*)t0)[5];
f_5824(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[257]+1));}

/* k5885 in k5882 in a5879 in k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=f_5841(C_a_i(&a,3),((C_word*)t0)[4]);
/* posixunix.scm: 2067 connect-child */
t4=((C_word*)t0)[3];
f_5824(t4,t2,t3,((C_word*)t0)[2],*((C_word*)lf[258]+1));}

/* k5888 in k5885 in k5882 in a5879 in k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2068 process-execute */
t2=((C_word*)t0)[6];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5876 in k5865 in k5862 in k5859 in spawn in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2061 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* swapped-ends in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5841(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(1));
t3=(C_word)C_u_i_car(t1);
return((C_word)C_a_i_cons(&a,2,t2,t3));}
else{
return(C_SCHEME_FALSE);}}

/* connect-child in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5824(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5824,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=(C_word)C_u_i_car(t2);
t6=(C_word)C_slot(t2,C_fix(1));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5837,a[2]=t5,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 2049 file-close */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k5835 in connect-child in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5837,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=(C_word)C_eqp(t3,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5749,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2023 duplicate-fileno */
t6=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t3);}}

/* k5747 in k5835 in connect-child in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 2024 file-close */
t2=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* connect-parent in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5810(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5810,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5823,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2043 file-close */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k5821 in connect-parent in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* needed-pipe in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5790(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5790,NULL,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5805,tmp=(C_word)a,a+=2,tmp);
/* posixunix.scm: 2038 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t3,t4);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a5804 in needed-pipe in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5805,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* a5798 in needed-pipe in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
/* posixunix.scm: 2038 create-pipe */
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}

/* make-on-close in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5753(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5753,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5755,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t7,a[6]=t6,a[7]=t5,a[8]=t4,tmp=(C_word)a,a+=9,tmp));}

/* f_5755 in make-on-close in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5755,2,t0,t1);}
t2=(C_word)C_i_set_i_slot(((C_word*)t0)[8],((C_word*)t0)[7],C_SCHEME_TRUE);
t3=(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[6]);
t4=(C_truep(t3)?(C_word)C_slot(((C_word*)t0)[8],((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 2031 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t5,t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* a5775 */
static void C_ccall f_5776(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5776,5,t0,t1,t2,t3,t4);}
if(C_truep(t3)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 2033 ##sys#signal-hook */
t5=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t1,lf[161],((C_word*)t0)[3],lf[398],((C_word*)t0)[2],t4);}}

/* a5769 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5770,2,t0,t1);}
/* posixunix.scm: 2031 process-wait */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* process-run in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5697(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5697r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5697r(t0,t1,t2,t3);}}

static void C_ccall f_5697r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5704,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1987 process-fork */
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k5702 in process-run in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 1989 process-execute */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1991 ##sys#shell-command */
t4=*((C_word*)lf[391]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k5721 in k5702 in process-run in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5727,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1991 ##sys#shell-command-arguments */
t3=*((C_word*)lf[395]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5725 in k5721 in k5702 in process-run in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1991 process-execute */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5691,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[396],t2));}

/* ##sys#shell-command in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5686,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1976 getenv */
t3=*((C_word*)lf[393]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[394]);}

/* k5684 in ##sys#shell-command in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:lf[392]));}

/* process-signal in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5655(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_5655r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_5655r(t0,t1,t2,t3);}}

static void C_ccall f_5655r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_fix((C_word)SIGTERM));
t6=(C_word)C_i_check_exact_2(t2,lf[389]);
t7=(C_word)C_i_check_exact_2(t5,lf[389]);
t8=(C_word)C_kill(t2,t5);
t9=(C_word)C_eqp(t8,C_fix(-1));
if(C_truep(t9)){
/* posixunix.scm: 1973 posix-error */
t10=lf[3];
f_1512(7,t10,t1,lf[161],lf[389],lf[390],t2,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}

/* sleep in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5652,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub1016(C_SCHEME_UNDEFINED,t2));}

/* parent-process-id in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5649,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1013(C_SCHEME_UNDEFINED));}

/* current-process-id in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub1011(C_SCHEME_UNDEFINED));}

/* process-wait in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_5571r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5571r(t0,t1,t2);}}

static void C_ccall f_5571r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(7);
t3=(C_word)C_i_nullp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_u_i_car(t2));
t5=(C_word)C_i_nullp(t2);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t2,C_fix(1)));
t7=(C_word)C_i_nullp(t6);
t8=(C_truep(t7)?C_SCHEME_FALSE:(C_word)C_u_i_car(t6));
t9=(C_word)C_i_nullp(t6);
t10=(C_truep(t9)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t6,C_fix(1)));
t11=(C_truep(t4)?t4:C_fix(-1));
t12=(C_word)C_i_check_exact_2(t11,lf[384]);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5598,a[2]=t8,a[3]=t11,tmp=(C_word)a,a+=4,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5604,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1957 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t13,t14);}

/* a5603 in process-wait in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5604(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5604,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
/* posixunix.scm: 1959 posix-error */
t6=lf[3];
f_1512(6,t6,t1,lf[161],lf[384],lf[385],((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1960 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a5597 in process-wait in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
/* posixunix.scm: 1957 ##sys#process-wait */
t2=*((C_word*)lf[383]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5554,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?C_fix((C_word)WNOHANG):C_fix(0));
t5=(C_word)C_waitpid(t2,t4);
t6=(C_word)C_WIFEXITED(C_fix((C_word)C_wait_status));
t7=(C_truep(t6)?(C_word)C_WEXITSTATUS(C_fix((C_word)C_wait_status)):(C_truep((C_word)C_WIFSIGNALED(C_fix((C_word)C_wait_status)))?(C_word)C_WTERMSIG(C_fix((C_word)C_wait_status)):(C_word)C_WSTOPSIG(C_fix((C_word)C_wait_status))));
/* posixunix.scm: 1944 values */
C_values(5,0,t1,t5,t6,t7);}

/* process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_5375r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5375r(t0,t1,t2,t3);}}

static void C_ccall f_5375r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5504,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5509,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglist951986 */
t7=t6;
f_5509(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-envlist952984 */
t9=t5;
f_5504(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body949954 */
t11=t4;
f_5377(t11,t1,t7,t9);}}}

/* def-arglist951 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5509,NULL,2,t0,t1);}
/* def-envlist952984 */
t2=((C_word*)t0)[2];
f_5504(t2,t1,C_SCHEME_END_OF_LIST);}

/* def-envlist952 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5504(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5504,NULL,3,t0,t1,t2);}
/* body949954 */
t3=((C_word*)t0)[2];
f_5377(t3,t1,t2,C_SCHEME_FALSE);}

/* body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5377(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5377,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(((C_word*)t0)[5],lf[381]);
t5=(C_word)C_i_check_list_2(t2,lf[381]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5387,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1912 pathname-strip-directory */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}

/* k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5387,2,t0,t1);}
t2=(C_word)C_block_size(t1);
t3=f_5359(C_fix(0),t1,t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5395,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5395(t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(1));}

/* do958 in k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5395,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=f_5359(t3,C_SCHEME_FALSE,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5408,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=(C_word)C_i_check_list_2(((C_word*)t0)[5],lf[381]);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5441,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=t5;
f_5408(t8,f_5441(t7,((C_word*)t0)[5],C_fix(0)));}
else{
t6=t5;
f_5408(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,lf[381]);
t6=(C_word)C_block_size(t4);
t7=f_5359(t3,t4,t6);
t8=(C_word)C_slot(t2,C_fix(1));
t9=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t15=t1;
t16=t8;
t17=t9;
t1=t15;
t2=t16;
t3=t17;
goto loop;}}

/* do962 in do958 in k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5441(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
if(C_truep((C_word)C_i_nullp(t1))){
return(f_5367(t2,C_SCHEME_FALSE,C_fix(0)));}
else{
t3=(C_word)C_u_i_car(t1);
t4=(C_word)C_i_check_string_2(t3,lf[381]);
t5=(C_word)C_block_size(t3);
t6=f_5367(t2,t3,t5);
t7=(C_word)C_slot(t1,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t2,C_fix(1));
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k5406 in do958 in k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5433,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1926 ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5431 in k5406 in do958 in k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1926 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5409 in k5406 in do958 in k5385 in body949 in process-execute in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)stub930(C_SCHEME_UNDEFINED);
t5=(C_word)stub942(C_SCHEME_UNDEFINED);
/* posixunix.scm: 1933 posix-error */
t6=lf[3];
f_1512(6,t6,((C_word*)t0)[3],lf[161],lf[381],lf[382],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* setenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5367(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub935(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* setarg in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_5359(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
return((C_word)stub923(C_SCHEME_UNDEFINED,t1,t4,t3));}

/* process-fork in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5321r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5321r(t0,t1,t2);}}

static void C_ccall f_5321r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(3);
t3=(C_word)stub906(C_SCHEME_UNDEFINED);
t4=(C_word)C_eqp(C_fix(-1),t3);
if(C_truep(t4)){
/* posixunix.scm: 1897 posix-error */
t5=lf[3];
f_1512(5,t5,t1,lf[161],lf[378],lf[379]);}
else{
t5=(C_word)C_notvemptyp(t2);
t6=(C_truep(t5)?(C_word)C_eqp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_slot(t2,C_fix(0));
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t3);}}}

/* k5341 in process-fork in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5347,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(0));}

/* f_5347 in k5341 in process-fork in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5347,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub911(C_SCHEME_UNDEFINED,t2));}

/* glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_5209r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5209r(t0,t1,t2);}}

static void C_ccall f_5209r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_5215(t6,t1,t2);}

/* conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5215(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5215,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5230,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5236,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5313,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[377]);
/* posixunix.scm: 1881 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k5311 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1881 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixunix.scm: 1882 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5246,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1883 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5253,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[376]);
/* posixunix.scm: 1884 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k5251 in k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5253,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_5255(t5,((C_word*)t0)[2],t1);}

/* loop in k5251 in k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5255,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixunix.scm: 1885 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_5215(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5272,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixunix.scm: 1886 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k5270 in loop in k5251 in k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5272,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixunix.scm: 1887 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixunix.scm: 1888 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5255(t3,((C_word*)t0)[6],t2);}}

/* k5280 in k5270 in loop in k5251 in k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5286,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1887 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5255(t4,t2,t3);}

/* k5284 in k5280 in k5270 in loop in k5251 in k5244 in k5241 in k5238 in a5235 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5286,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a5229 in conc-loop in glob in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5230,2,t0,t1);}
/* posixunix.scm: 1880 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* get-host-name in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,(C_word)stub866(t3),C_fix(0));}

/* k5199 in get-host-name in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5204,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_5204(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1861 posix-error */
t3=lf[3];
f_1512(5,t3,t2,lf[363],lf[367],lf[368]);}}

/* k5202 in k5199 in get-host-name in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* terminal-size in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5162,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5166,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1842 ##sys#terminal-check */
f_5116(t3,lf[362],t2);}

/* k5164 in terminal-size in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* ##sys#make-locative */
t5=*((C_word*)lf[365]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t2,C_fix(0),C_SCHEME_FALSE,lf[366]);}

/* k5184 in k5164 in terminal-size in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[365]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),C_SCHEME_FALSE,lf[366]);}

/* k5188 in k5184 in k5164 in terminal-size in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_C_fileno(((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=(C_word)C_i_foreign_pointer_argumentp(t3);
t5=(C_word)C_i_foreign_pointer_argumentp(t1);
t6=(C_word)stub852(C_SCHEME_UNDEFINED,t2,t4,t5);
t7=(C_word)C_eqp(C_fix(0),t6);
if(C_truep(t7)){
/* posixunix.scm: 1849 values */
C_values(4,0,((C_word*)t0)[4],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[3]))),C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
/* posixunix.scm: 1850 posix-error */
t8=lf[3];
f_1512(6,t8,((C_word*)t0)[4],lf[363],lf[362],lf[364],((C_word*)t0)[6]);}}

/* terminal-name in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5143,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1834 ##sys#terminal-check */
f_5116(t3,lf[361],t2);}

/* k5145 in terminal-name in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5147,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(C_word)C_C_fileno(((C_word*)t0)[2]);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-nonnull-c-string */
t5=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub842(t4,t3),C_fix(0));}

/* ##sys#terminal-check in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_5116(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5116,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5120,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1826 ##sys#check-port */
t5=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,t2);}

/* k5118 in ##sys#terminal-check in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[4],C_fix(7));
t3=(C_word)C_eqp(lf[87],t2);
t4=(C_truep(t3)?(C_word)C_tty_portp(((C_word*)t0)[4]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1829 ##sys#error */
t5=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[360],((C_word*)t0)[4]);}}

/* terminal-port? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5097,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5101,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1821 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[358]);}

/* k5099 in terminal-port? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1822 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k5102 in k5099 in terminal-port? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(t1,C_fix(0));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:(C_word)C_tty_portp(((C_word*)t0)[2])));}

/* set-buffering-mode! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_5038r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_5038r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5038r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5042,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1806 ##sys#check-port */
t6=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[352]);}

/* k5040 in set-buffering-mode! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5042,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[354]);
if(C_truep(t6)){
t7=t5;
f_5048(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[355]);
if(C_truep(t7)){
t8=t5;
f_5048(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[356]);
if(C_truep(t8)){
t9=t5;
f_5048(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixunix.scm: 1812 ##sys#error */
t9=*((C_word*)lf[109]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[352],lf[357],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k5046 in k5040 in set-buffering-mode! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[352]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[87],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixunix.scm: 1818 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[352],lf[353],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* set-alarm! in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5035(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5035,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub822(C_SCHEME_UNDEFINED,t2));}

/* _exit in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_5019r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_5019r(t0,t1,t2);}}

static void C_ccall f_5019r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub817(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5011,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub812(t2),C_fix(0));}

/* utc-time->seconds in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4983(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4983,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[346]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1773 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[346],lf[348],t2);}
else{
t6=t4;
f_4990(2,t6,C_SCHEME_UNDEFINED);}}

/* k4988 in utc-time->seconds in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_timegm(((C_word*)t0)[3]))){
/* posixunix.scm: 1775 ##sys#cons-flonum */
t2=*((C_word*)lf[343]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1776 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[346],lf[347],((C_word*)t0)[3]);}}

/* local-time->seconds in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4955,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[342]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4962,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1766 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[342],lf[345],t2);}
else{
t6=t4;
f_4962(2,t6,C_SCHEME_UNDEFINED);}}

/* k4960 in local-time->seconds in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixunix.scm: 1768 ##sys#cons-flonum */
t2=*((C_word*)lf[343]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixunix.scm: 1769 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[342],lf[344],((C_word*)t0)[3]);}}

/* time->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4916(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4916,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[339]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4923,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixunix.scm: 1759 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[339],lf[341],t2);}
else{
t6=t4;
f_4923(2,t6,C_SCHEME_UNDEFINED);}}

/* k4921 in time->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub797(t4,t3),C_fix(0));}

/* k4924 in k4921 in time->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4929,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4929(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1761 ##sys#error */
t3=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[339],lf[340],((C_word*)t0)[2]);}}

/* k4927 in k4924 in k4921 in time->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1762 ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4888,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4892,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub788(t5,t4),C_fix(0));}

/* k4890 in seconds->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4892,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4895,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_4895(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1752 ##sys#error */
t3=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[337],lf[338],((C_word*)t0)[2]);}}

/* k4893 in k4890 in seconds->string in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixunix.scm: 1753 ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->utc-time in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4874,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[336]);
/* posixunix.scm: 1746 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4865,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[334]);
/* posixunix.scm: 1742 ##sys#decode-seconds */
t4=*((C_word*)lf[335]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* memory-mapped-file? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4859(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4859,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_structurep(t2,lf[325]));}

/* memory-mapped-file-pointer in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4850,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[325],lf[332]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* unmap-file-from-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4815r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4815r(t0,t1,t2,t3);}}

static void C_ccall f_4815r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
t4=(C_word)C_i_check_structure_2(t2,lf[325],lf[330]);
t5=(C_word)C_notvemptyp(t3);
t6=(C_truep(t5)?(C_word)C_slot(t3,C_fix(0)):(C_word)C_slot(t2,C_fix(2)));
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_truep(t7)?(C_word)C_i_foreign_pointer_argumentp(t7):C_SCHEME_FALSE);
t9=(C_word)stub769(C_SCHEME_UNDEFINED,t8,t6);
t10=(C_word)C_eqp(C_fix(0),t9);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1729 posix-error */
t11=lf[3];
f_1512(7,t11,t1,lf[48],lf[330],lf[331],t2,t6);}}

/* map-file-to-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,...){
C_word tmp;
C_word t7;
va_list v;
C_word *a,c2=c;
C_save_rest(t6,c2,7);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr7rv,(void*)f_4757r,7,t0,t1,t2,t3,t4,t5,t6);}
else{
a=C_alloc((c-7)*3);
t7=C_restore_rest_vector(a,C_rest_count(0));
f_4757r(t0,t1,t2,t3,t4,t5,t6,t7);}}

static void C_ccall f_4757r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(8);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4761,a[2]=t1,a[3]=t6,a[4]=t5,a[5]=t4,a[6]=t3,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
t9=t2;
if(C_truep(t9)){
t10=t8;
f_4761(2,t10,t2);}
else{
/* posixunix.scm: 1714 ##sys#null-pointer */
t10=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t8);}}

/* k4759 in map-file-to-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4761,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[7]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[7],C_fix(0)):C_fix(0));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4767,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(C_truep((C_word)C_blockp(t1))?(C_word)C_specialp(t1):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t4;
f_4767(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1717 ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t4,lf[59],lf[324],lf[328],t1);}}

/* k4765 in k4759 in map-file-to-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4767,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
t8=(C_truep(t2)?(C_word)C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t9=(C_word)stub744(t7,t8,t3,t4,t5,t6,((C_word*)t0)[3]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[7],a[3]=t9,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4786,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t10,tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1719 ##sys#pointer->address */
t12=*((C_word*)lf[327]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t9);}

/* k4784 in k4765 in k4759 in map-file-to-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1720 posix-error */
t3=lf[3];
f_1512(11,t3,((C_word*)t0)[8],lf[48],lf[324],lf[326],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[8];
f_4773(2,t3,C_SCHEME_UNDEFINED);}}

/* k4771 in k4765 in k4759 in map-file-to-memory in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4773,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,3,lf[325],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4674,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4680,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4680(t5,t1,C_fix(0));}

/* loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4680(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4680,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4684,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub726(t5,t4),C_fix(0));}

/* k4682 in loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4692,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4692(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k4682 in loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4692(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4692,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[5],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1681 ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1684 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k4716 in scan in k4682 in loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[2]);
/* posixunix.scm: 1682 ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[2],t3,t4);}

/* k4720 in k4716 in scan in k4682 in loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4722,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4710,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1683 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_4680(t5,t3,t4);}

/* k4708 in k4720 in k4716 in scan in k4682 in loop in current-environment in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4710,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4659,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[313]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4667,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1670 ##sys#make-c-string */
t5=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k4665 in unsetenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4642(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4642,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[312]);
t5=(C_word)C_i_check_string_2(t3,lf[312]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4653,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1665 ##sys#make-c-string */
t7=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k4651 in setenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1665 ##sys#make-c-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4655 in k4651 in setenv in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* fifo? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4616,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[310]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4623,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4640,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1654 ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k4638 in fifo? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1654 ##sys#file-info */
t2=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4621 in fifo? in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(3),t2));}
else{
/* posixunix.scm: 1657 posix-error */
t2=lf[3];
f_1512(6,t2,((C_word*)t0)[3],lf[48],lf[310],lf[311],((C_word*)t0)[2]);}}

/* create-fifo in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4573(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_4573r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_4573r(t0,t1,t2,t3);}}

static void C_ccall f_4573r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_string_2(t2,lf[308]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4580,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_notvemptyp(t3))){
t6=t5;
f_4580(t6,(C_word)C_slot(t3,C_fix(0)));}
else{
t6=(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXG),C_fix((C_word)S_IRWXO));
t7=t5;
f_4580(t7,(C_word)C_u_fixnum_or(C_fix((C_word)S_IRWXU),t6));}}

/* k4578 in create-fifo in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4580,NULL,2,t0,t1);}
t2=(C_word)C_i_check_exact_2(t1,lf[308]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4601,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1648 ##sys#expand-home-path */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k4599 in k4578 in create-fifo in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1648 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4595 in k4578 in create-fifo in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkfifo(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1649 posix-error */
t3=lf[3];
f_1512(7,t3,((C_word*)t0)[3],lf[48],lf[308],lf[309],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* file-unlock in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4545,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[299],lf[306]);
t4=(C_word)C_slot(t2,C_fix(2));
t5=(C_word)C_slot(t2,C_fix(3));
t6=(C_word)C_flock_setup(C_fix((C_word)F_UNLCK),t4,t5);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_flock_lock(t7);
if(C_truep((C_word)C_fixnum_lessp(t8,C_fix(0)))){
/* posixunix.scm: 1638 posix-error */
t9=lf[3];
f_1512(6,t9,t1,lf[48],lf[306],lf[307],t2);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_UNDEFINED);}}

/* file-test-lock in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4523r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4523r(t0,t1,t2,t3);}}

static void C_ccall f_4523r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4527,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1629 setup */
f_4404(t4,t2,t3,lf[304]);}

/* k4525 in file-test-lock in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_flock_test(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=(C_word)C_eqp(t2,C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_FALSE:t2));}
else{
/* posixunix.scm: 1631 err */
f_4475(((C_word*)t0)[3],lf[305],t1,lf[304]);}}

/* file-lock/blocking in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4508r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4508r(t0,t1,t2,t3);}}

static void C_ccall f_4508r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1623 setup */
f_4404(t4,t2,t3,lf[302]);}

/* k4510 in file-lock/blocking in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lockw(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1625 err */
f_4475(((C_word*)t0)[2],lf[303],t1,lf[302]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* file-lock in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4493(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_4493r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4493r(t0,t1,t2,t3);}}

static void C_ccall f_4493r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4497,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1617 setup */
f_4404(t4,t2,t3,lf[300]);}

/* k4495 in file-lock in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_flock_lock(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1619 err */
f_4475(((C_word*)t0)[2],lf[301],t1,lf[300]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* err in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4475(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4475,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_slot(t3,C_fix(2));
t7=(C_word)C_slot(t3,C_fix(3));
/* posixunix.scm: 1614 posix-error */
t8=lf[3];
f_1512(8,t8,t1,lf[48],t4,t2,t5,t6,t7);}

/* setup in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4404(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4404,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_nullp(t3);
t6=(C_truep(t5)?C_fix(0):(C_word)C_u_i_car(t3));
t7=(C_word)C_i_nullp(t3);
t8=(C_truep(t7)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t9=(C_word)C_i_nullp(t8);
t10=(C_truep(t9)?C_SCHEME_TRUE:(C_word)C_u_i_car(t8));
t11=t10;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(C_word)C_i_nullp(t8);
t14=(C_truep(t13)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t8,C_fix(1)));
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4423,a[2]=t1,a[3]=t12,a[4]=t2,a[5]=t4,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1606 ##sys#check-port */
t16=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,t2,t4);}

/* k4421 in setup in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4423,2,t0,t1);}
t2=(C_word)C_i_check_number_2(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t6=t3;
f_4429(t6,t5);}
else{
t5=t3;
f_4429(t5,(C_word)C_i_check_number_2(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[5]));}}

/* k4427 in k4421 in setup in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4429(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4429,NULL,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_truep(t2)?C_fix((C_word)F_RDLCK):C_fix((C_word)F_WRLCK));
t4=(C_word)C_flock_setup(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[299],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]));}

/* file-truncate in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4365(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4365,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_number_2(t3,lf[296]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4382,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4389,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4393,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1589 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_4382(2,t6,(C_word)C_ftruncate(t2,t3));}
else{
/* posixunix.scm: 1591 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[296],lf[298],t2);}}}

/* k4391 in file-truncate in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1589 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4387 in file-truncate in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_4382(2,t2,(C_word)C_truncate(t1,((C_word*)t0)[2]));}

/* k4380 in file-truncate in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1593 posix-error */
t2=lf[3];
f_1512(7,t2,((C_word*)t0)[4],lf[48],lf[296],lf[297],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr5r,(void*)f_4109r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4109r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4109r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(16);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4295,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4305,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?618659 */
t10=t9;
f_4305(t10,t1);}
else{
t10=(C_word)C_u_i_car(t5);
t11=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-bufi619657 */
t12=t8;
f_4300(t12,t1,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
if(C_truep((C_word)C_i_nullp(t13))){
/* def-on-close620654 */
t14=t7;
f_4295(t14,t1,t10,t12);}
else{
t14=(C_word)C_u_i_car(t13);
t15=(C_word)C_slot(t13,C_fix(1));
/* body616622 */
t16=t6;
f_4111(t16,t1,t10,t12,t14);}}}}

/* def-nonblocking?618 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4305,NULL,2,t0,t1);}
/* def-bufi619657 */
t2=((C_word*)t0)[2];
f_4300(t2,t1,C_SCHEME_FALSE);}

/* def-bufi619 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4300,NULL,3,t0,t1,t2);}
/* def-on-close620654 */
t3=((C_word*)t0)[2];
f_4295(t3,t1,t2,C_fix(0));}

/* def-on-close620 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4295,NULL,4,t0,t1,t2,t3);}
/* body616622 */
t4=((C_word*)t0)[2];
f_4111(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4111(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4111,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1531 ##sys#file-nonblocking! */
t6=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t6=t5;
f_4115(2,t6,C_SCHEME_UNDEFINED);}}

/* k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4115,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t3,a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t7=(C_word)C_fixnump(((C_word*)t0)[6]);
t8=(C_truep(t7)?((C_word*)t0)[6]:(C_word)C_block_size(((C_word*)t0)[6]));
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4163,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t10=(C_word)C_eqp(C_fix(0),t8);
if(C_truep(t10)){
t11=t9;
f_4163(t11,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4207,a[2]=t3,tmp=(C_word)a,a+=3,tmp));}
else{
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4221,a[2]=t3,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[6]))){
/* posixunix.scm: 1550 ##sys#make-string */
t12=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[6]);}
else{
t12=t11;
f_4221(2,t12,((C_word*)t0)[6]);}}}

/* k4219 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[4];
f_4163(t4,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4222,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));}

/* f_4222 in k4219 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4222,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4239,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t6,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_4239(t8,t1,t3,C_fix(0),t4);}
else{
if(C_truep((C_word)C_fixnum_lessp(C_fix(0),((C_word*)((C_word*)t0)[4])[1]))){
/* posixunix.scm: 1566 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4117(t3,t1,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}}

/* loop */
static void C_fcall f_4239(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4239,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4249,a[2]=t4,a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1556 poke */
t7=((C_word*)((C_word*)t0)[4])[1];
f_4117(t7,t6,((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_fixnum_lessp(t2,t4))){
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t2,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_difference(t4,t2);
/* posixunix.scm: 1561 loop */
t13=t1;
t14=C_fix(0);
t15=t2;
t16=t7;
t1=t13;
t2=t14;
t3=t15;
t4=t16;
goto loop;}
else{
t6=(C_word)C_substring_copy(((C_word*)t0)[2],((C_word*)t0)[3],t3,t4,((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t4);
t8=C_mutate(((C_word *)((C_word*)t0)[7])+1,t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k4247 in loop */
static void C_ccall f_4249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[6],0,C_fix(0));
/* posixunix.scm: 1558 loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_4239(t3,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* f_4207 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4207,3,t0,t1,t2);}
if(C_truep(t2)){
t3=(C_word)C_block_size(t2);
/* posixunix.scm: 1549 poke */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4117(t4,t1,t2,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4163(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4163,NULL,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4199,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1569 make-output-port */
t9=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t5,t6,t7,t8);}

/* a4198 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4199,2,t0,t1);}
/* posixunix.scm: 1579 store */
t2=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_FALSE);}

/* a4177 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4188,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1576 posix-error */
t3=lf[3];
f_1512(7,t3,t2,lf[48],((C_word*)t0)[3],lf[295],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_4188(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4186 in a4177 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1577 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a4171 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4172,3,t0,t1,t2);}
/* posixunix.scm: 1571 store */
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* k4165 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1580 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k4168 in k4165 in k4161 in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* poke in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4117(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4117,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_write(((C_word*)t0)[5],t2,t3);
t5=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4133,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1539 ##sys#thread-yield! */
t8=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* posixunix.scm: 1541 posix-error */
t7=lf[3];
f_1512(7,t7,t1,((C_word*)t0)[3],lf[48],lf[294],((C_word*)t0)[5],((C_word*)t0)[2]);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t4,t3))){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4152,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1543 ##sys#substring */
t7=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,t2,t4,t3);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4150 in poke in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_u_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* posixunix.scm: 1543 poke */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4117(t3,((C_word*)t0)[2],t1,t2);}

/* k4131 in poke in k4113 in body616 in ##sys#custom-output-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1540 poke */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4117(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+19)){
C_save_and_reclaim((void*)tr5r,(void*)f_3676r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_3676r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_3676r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a=C_alloc(19);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3678,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4024,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4029,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4034,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t5))){
/* def-nonblocking?521597 */
t11=t10;
f_4034(t11,t1);}
else{
t11=(C_word)C_u_i_car(t5);
t12=(C_word)C_slot(t5,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-bufi522595 */
t13=t9;
f_4029(t13,t1,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
if(C_truep((C_word)C_i_nullp(t14))){
/* def-on-close523592 */
t15=t8;
f_4024(t15,t1,t11,t13);}
else{
t15=(C_word)C_u_i_car(t14);
t16=(C_word)C_slot(t14,C_fix(1));
if(C_truep((C_word)C_i_nullp(t16))){
/* def-more?524588 */
t17=t7;
f_4019(t17,t1,t11,t13,t15);}
else{
t17=(C_word)C_u_i_car(t16);
t18=(C_word)C_slot(t16,C_fix(1));
/* body519526 */
t19=t6;
f_3678(t19,t1,t11,t13,t15,t17);}}}}}

/* def-nonblocking?521 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4034,NULL,2,t0,t1);}
/* def-bufi522595 */
t2=((C_word*)t0)[2];
f_4029(t2,t1,C_SCHEME_FALSE);}

/* def-bufi522 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4029,NULL,3,t0,t1,t2);}
/* def-on-close523592 */
t3=((C_word*)t0)[2];
f_4024(t3,t1,t2,C_fix(1));}

/* def-on-close523 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4024(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4024,NULL,4,t0,t1,t2,t3);}
/* def-more?524588 */
t4=((C_word*)t0)[2];
f_4019(t4,t1,t2,t3,*((C_word*)lf[291]+1));}

/* def-more?524 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_4019(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4019,NULL,5,t0,t1,t2,t3,t4);}
/* body519526 */
t5=((C_word*)t0)[2];
f_3678(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3678,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3682,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
/* posixunix.scm: 1420 ##sys#file-nonblocking! */
t7=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[5]);}
else{
t7=t6;
f_3682(2,t7,C_SCHEME_UNDEFINED);}}

/* k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(C_word)C_fixnump(((C_word*)t0)[10]);
t3=(C_truep(t2)?((C_word*)t0)[10]:(C_word)C_block_size(((C_word*)t0)[10]));
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_fixnump(((C_word*)t0)[10]))){
/* posixunix.scm: 1422 ##sys#make-string */
t5=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[10]);}
else{
t5=t4;
f_3688(2,t5,((C_word*)t0)[10]);}}

/* k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3688,2,t0,t1);}
t2=C_fix(0);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3704,a[2]=t1,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3712,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[7],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t3,a[9]=t5,tmp=(C_word)a,a+=10,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3794,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3799,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3812,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=t10,tmp=(C_word)a,a+=7,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3845,a[2]=t8,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3854,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3919,a[2]=t8,a[3]=t1,a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1466 make-input-port */
t18=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t18+1)))(8,t18,t11,t12,t13,t14,t15,t16,t17);}

/* a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3919,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3925,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_3925(t7,t1,C_SCHEME_FALSE);}

/* loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3925,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* posixunix.scm: 1503 ##sys#scan-buffer-line */
t4=*((C_word*)lf[290]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3994,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 1518 fetch */
t4=((C_word*)t0)[3];
f_3712(t4,t3);}}

/* k3992 in loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* posixunix.scm: 1520 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3925(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a3936 in loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3937,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* posixunix.scm: 1506 ##sys#make-string */
t6=*((C_word*)lf[289]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k3939 in a3936 in loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3941,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3951,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1510 fetch */
t6=((C_word*)t0)[3];
f_3712(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* posixunix.scm: 1516 ##sys#string-append */
t8=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k3949 in k3939 in a3936 in loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[287]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixunix.scm: 1513 ##sys#string-append */
t3=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_3967(2,t3,((C_word*)t0)[2]);}}}

/* k3965 in k3949 in k3939 in a3936 in loop in a3918 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1513 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3925(t2,((C_word*)t0)[2],t1);}

/* a3853 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3854,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_3860(t9,t1,t3,C_fix(0),t5);}

/* loop in a3853 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3860(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3860,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* posixunix.scm: 1494 loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3908,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 1496 fetch */
t7=((C_word*)t0)[2];
f_3712(t7,t6);}}}

/* k3906 in loop in a3853 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* posixunix.scm: 1499 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3860(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a3844 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3845,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1484 fetch */
t3=((C_word*)t0)[2];
f_3712(t3,t2);}

/* k3847 in a3844 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1485 peek */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_3704(((C_word*)t0)[2]));}

/* a3823 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
if(C_truep((C_word)C_slot(((C_word*)((C_word*)t0)[6])[1],C_fix(8)))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3834,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(((C_word*)t0)[4]),C_fix(0)))){
/* posixunix.scm: 1481 posix-error */
t3=lf[3];
f_1512(7,t3,t2,lf[48],((C_word*)t0)[3],lf[286],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_3834(2,t3,C_SCHEME_UNDEFINED);}}}

/* k3832 in a3823 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1482 on-close */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a3811 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3812,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* posixunix.scm: 1476 ready? */
t3=((C_word*)t0)[2];
f_3689(t3,t1);}}

/* a3798 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3803,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1468 fetch */
t3=((C_word*)t0)[2];
f_3712(t3,t2);}

/* k3801 in a3798 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=f_3704(((C_word*)t0)[4]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* k3792 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3794,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3797,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1522 set-port-name! */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k3795 in k3792 in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3712(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3712,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3724,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_3724(t5,t1);}
else{
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3724,NULL,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);
t3=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t3)){
t4=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3740,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1443 ##sys#thread-block-for-i/o! */
t6=*((C_word*)lf[282]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[283]+1),((C_word*)t0)[10],C_SCHEME_TRUE);}
else{
/* posixunix.scm: 1446 posix-error */
t5=lf[3];
f_1512(7,t5,t1,lf[48],((C_word*)t0)[6],lf[284],((C_word*)t0)[10],((C_word*)t0)[5]);}}
else{
t4=(C_truep(((C_word*)t0)[4])?(C_word)C_eqp(t2,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* posixunix.scm: 1450 more? */
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t6=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}

/* k3759 in loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1452 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(C_word)C_read(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(((C_word*)t3)[1],C_fix(-1));
if(C_truep(t5)){
t6=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t6)){
t7=C_set_block_item(t3,0,C_fix(0));
t8=t4;
f_3770(2,t8,t7);}
else{
/* posixunix.scm: 1458 posix-error */
t7=lf[3];
f_1512(7,t7,t4,lf[48],((C_word*)t0)[3],lf[285],((C_word*)t0)[8],((C_word*)t0)[2]);}}
else{
t6=t4;
f_3770(2,t6,C_SCHEME_UNDEFINED);}}}

/* k3768 in k3759 in loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)((C_word*)t0)[4])[1]);
t3=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3762 in k3759 in loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1453 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3724(t2,((C_word*)t0)[2]);}

/* k3738 in loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1444 ##sys#thread-yield! */
t3=*((C_word*)lf[281]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3741 in k3738 in loop in fetch in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1445 loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3724(t2,((C_word*)t0)[2]);}

/* peek in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_3704(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
t1=(C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
return((C_truep(t1)?C_SCHEME_END_OF_FILE:(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1])));}

/* ready? in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3689(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3689,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 1428 ##sys#file-select-one */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k3701 in ready? in k3686 in k3680 in body519 in ##sys#custom-input-port in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
/* posixunix.scm: 1429 posix-error */
t3=lf[3];
f_1512(7,t3,((C_word*)t0)[5],lf[48],((C_word*)t0)[4],lf[280],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* duplicate-fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3649r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3649r(t0,t1,t2,t3);}}

static void C_ccall f_3649r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[275]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3656,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_3656(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[275]);
t8=t5;
f_3656(t8,(C_word)C_dup2(t2,t6));}}

/* k3654 in duplicate-fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3656(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3656,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3659,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 1411 posix-error */
t3=lf[3];
f_1512(6,t3,t2,lf[48],lf[275],lf[276],((C_word*)t0)[2]);}
else{
t3=t2;
f_3659(2,t3,C_SCHEME_UNDEFINED);}}

/* k3657 in k3654 in duplicate-fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3608,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1393 ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[269]);}

/* k3606 in port->fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3608,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(lf[270],t2);
if(C_truep(t3)){
/* posixunix.scm: 1394 ##sys#tcp-port->fileno */
t4=*((C_word*)lf[271]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1395 ##sys#peek-unsigned-integer */
t5=*((C_word*)lf[274]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[3],C_fix(0));}}

/* k3641 in k3606 in port->fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3643,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixunix.scm: 1400 posix-error */
t2=lf[3];
f_1512(6,t2,((C_word*)t0)[3],lf[59],lf[269],lf[272],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3626,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1398 posix-error */
t4=lf[3];
f_1512(6,t4,t3,lf[48],lf[269],lf[273],((C_word*)t0)[2]);}
else{
t4=t3;
f_3626(2,t4,C_SCHEME_UNDEFINED);}}}

/* k3624 in k3641 in k3606 in port->fileno in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3590r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3590r(t0,t1,t2,t3);}}

static void C_ccall f_3590r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[268]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3602,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1389 mode */
f_3524(t5,C_SCHEME_FALSE,t3);}

/* k3600 in open-output-file* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3602,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1389 check */
f_3561(((C_word*)t0)[2],lf[268],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3576r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3576r(t0,t1,t2,t3);}}

static void C_ccall f_3576r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[267]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3588,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1385 mode */
f_3524(t5,C_SCHEME_TRUE,t3);}

/* k3586 in open-input-file* in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3588,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixunix.scm: 1385 check */
f_3561(((C_word*)t0)[2],lf[267],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3561(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3561,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 1378 posix-error */
t6=lf[3];
f_1512(6,t6,t1,lf[48],t2,lf[265],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3574,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1379 ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[266],lf[87]);}}

/* k3572 in check in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3524(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3524,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3532,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[259]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixunix.scm: 1372 ##sys#error */
t8=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[260],t5);}
else{
t8=t4;
f_3532(2,t8,lf[261]);}}
else{
/* posixunix.scm: 1373 ##sys#error */
t7=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[262],t5);}}
else{
t5=t4;
f_3532(2,t5,(C_truep(t2)?lf[263]:lf[264]));}}

/* k3530 in mode in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1368 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3499,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[253]);
t5=(C_word)C_i_check_string_2(t3,lf[253]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3488,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_3488(2,t9,C_SCHEME_FALSE);}}

/* k3486 in file-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3492(2,t3,C_SCHEME_FALSE);}}

/* k3490 in k3486 in file-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)stub463(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1353 posix-error */
t3=lf[3];
f_1512(7,t3,((C_word*)t0)[4],lf[48],lf[254],lf[255],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* read-symbolic-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3457(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3457,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[251]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3465,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3481,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1342 ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k3479 in read-symbolic-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1342 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3463 in read-symbolic-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3465,2,t0,t1);}
t2=(C_word)C_readlink(t1,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3468,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1344 posix-error */
t4=lf[3];
f_1512(6,t4,t3,lf[48],lf[251],lf[252],((C_word*)t0)[2]);}
else{
t4=t3;
f_3468(2,t4,C_SCHEME_UNDEFINED);}}

/* k3466 in k3463 in read-symbolic-link in k3454 in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1345 substring */
t2=((C_word*)t0)[5];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* create-symbolic-link in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3419,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[247]);
t5=(C_word)C_i_check_string_2(t3,lf[247]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3440,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3452,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1330 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3450 in create-symbolic-link in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1330 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3438 in create-symbolic-link in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1331 ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3446 in k3438 in create-symbolic-link in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1331 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3442 in k3438 in create-symbolic-link in k3415 in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_symlink(((C_word*)t0)[5],t1);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1333 posix-error */
t3=lf[3];
f_1512(7,t3,((C_word*)t0)[4],lf[48],lf[248],lf[249],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* set-process-group-id! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3394,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[244]);
t5=(C_word)C_i_check_exact_2(t3,lf[244]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setpgid(t2,t3),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3410,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1308 ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* k3408 in set-process-group-id! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1309 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[244],lf[245],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* create-session in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=(C_word)C_setsid(C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3383,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3389,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1300 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3383(2,t4,C_SCHEME_UNDEFINED);}}

/* k3387 in create-session in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1301 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[242],lf[243]);}

/* k3381 in create-session in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-execute-access? in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3373,3,t0,t1,t2);}
/* posixunix.scm: 1295 check */
f_3337(t1,t2,C_fix((C_word)X_OK),lf[241]);}

/* file-write-access? in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3367,3,t0,t1,t2);}
/* posixunix.scm: 1294 check */
f_3337(t1,t2,C_fix((C_word)W_OK),lf[240]);}

/* file-read-access? in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3361(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3361,3,t0,t1,t2);}
/* posixunix.scm: 1293 check */
f_3337(t1,t2,C_fix((C_word)R_OK),lf[239]);}

/* check in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3337(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3337,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3355,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3359,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1290 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3357 in check in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1290 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3353 in check in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3355,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3347,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3347(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1291 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3345 in k3353 in check in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-owner in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3307,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,lf[237]);
t6=(C_word)C_i_check_exact_2(t3,lf[237]);
t7=(C_word)C_i_check_exact_2(t4,lf[237]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3331,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1280 ##sys#expand-home-path */
t10=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}

/* k3333 in change-file-owner in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1280 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3329 in change-file-owner in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chown(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1281 posix-error */
t3=lf[3];
f_1512(8,t3,((C_word*)t0)[3],lf[48],lf[237],lf[238],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* change-file-mode in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3280(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3280,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[235]);
t5=(C_word)C_i_check_exact_2(t3,lf[235]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3301,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3305,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1272 ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k3303 in change-file-mode in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1272 ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3299 in change-file-mode in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
/* posixunix.scm: 1273 posix-error */
t3=lf[3];
f_1512(7,t3,((C_word*)t0)[3],lf[48],lf[235],lf[236],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* initialize-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3216,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[194]);
t5=(C_word)C_i_check_exact_2(t3,lf[194]);
t6=t2;
t7=t3;
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3212,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}
else{
t9=t8;
f_3212(2,t9,C_SCHEME_FALSE);}}

/* k3210 in initialize-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3212,2,t0,t1);}
t2=(C_word)stub403(C_SCHEME_UNDEFINED,t1,((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 1193 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k3230 in k3210 in initialize-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1194 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[194],lf[195],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-groups! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3150,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3154,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_length(t2);
t5=f_3084(t4);
if(C_truep(t5)){
t6=t3;
f_3154(2,t6,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1176 ##sys#error */
t6=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,lf[191],lf[193]);}}

/* k3152 in set-groups! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3159,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3159(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* do390 in k3152 in set-groups! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3159(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3159,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_fixnum_lessp((C_word)C_set_groups(t3),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1181 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_i_check_exact_2(t4,lf[191]);
t6=(C_word)C_set_gid(t3,t4);
t7=(C_word)C_slot(t2,C_fix(1));
t8=(C_word)C_u_fixnum_plus(t3,C_fix(1));
t11=t1;
t12=t7;
t13=t8;
t1=t11;
t2=t12;
t3=t13;
goto loop;}}

/* k3173 in do390 in k3152 in set-groups! in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1182 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[191],lf[192],((C_word*)t0)[2]);}

/* get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3087,2,t0,t1);}
t2=C_fix((C_word)getgroups(0, C_groups));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3091,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3145,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1162 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_3091(2,t4,C_SCHEME_UNDEFINED);}}

/* k3143 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1163 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[190]);}

/* k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=f_3084(((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t2;
f_3094(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 1165 ##sys#error */
t4=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[187],lf[189]);}}

/* k3092 in k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)stub372(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1167 ##sys#update-errno */
t5=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_3097(2,t4,C_SCHEME_UNDEFINED);}}

/* k3124 in k3092 in k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1168 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[187],lf[188]);}

/* k3095 in k3092 in k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3097,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3102(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k3095 in k3092 in k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3102(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3102,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[3]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3116,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixunix.scm: 1172 loop */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3114 in loop in k3095 in k3092 in k3089 in get-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,(C_word)C_get_gid(((C_word*)t0)[2]),t1));}

/* _ensure-groups in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_3084(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub376(C_SCHEME_UNDEFINED,t1));}

/* group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3009(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3009r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3009r(t0,t1,t2,t3);}}

static void C_ccall f_3009r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3016,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_3016(t7,(C_word)C_getgrgid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[185]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3067,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1136 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k3065 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3016(t2,(C_word)C_getgrnam(t1));}

/* k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3016(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3016,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3030,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_group->gr_passwd),C_fix(0));}

/* k3028 in k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3034,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3039,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_3039(t6,t2,C_fix(0));}

/* loop in k3028 in k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_3039(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3039,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3043,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub355(t5,t4),C_fix(0));}

/* k3041 in loop in k3028 in k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3043,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3053,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 1145 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3039(t4,t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* k3051 in k3041 in loop in k3028 in k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3053,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3032 in k3028 in k3024 in k3014 in group-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix((C_word)C_group->gr_gid),t1);}

/* current-effective-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1121 current-effective-user-id */
t4=*((C_word*)lf[175]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2999 in current-effective-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1121 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2995 in current-effective-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* current-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2987,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1118 current-user-id */
t4=*((C_word*)lf[174]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k2985 in current-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1118 user-information */
t2=*((C_word*)lf[180]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2981 in current-user-name in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_u_i_list_ref(t1,C_fix(0)));}

/* user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2915r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2915r(t0,t1,t2,t3);}}

static void C_ccall f_2915r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a=C_alloc(7);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t7=t6;
f_2922(t7,(C_word)C_getpwuid(t2));}
else{
t7=(C_word)C_i_check_string_2(t2,lf[180]);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1106 ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}}

/* k2959 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2922(t2,(C_word)C_getpwnam(t1));}

/* k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2922,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_name),C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2930 in k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2932,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2936,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_passwd),C_fix(0));}

/* k2934 in k2930 in k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2940,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_gecos),C_fix(0));}

/* k2938 in k2934 in k2930 in k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2944,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_dir),C_fix(0));}

/* k2942 in k2938 in k2934 in k2930 in k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2948,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_user->pw_shell),C_fix(0));}

/* k2946 in k2942 in k2938 in k2934 in k2930 in k2920 in user-information in k2911 in k2907 in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[7])?*((C_word*)lf[181]+1):*((C_word*)lf[182]+1));
t3=t2;
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_fix((C_word)C_user->pw_uid),C_fix((C_word)C_user->pw_gid),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* set-group-id! in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2892,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setgid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2902,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1076 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2900 in set-group-id! in k2888 in k2884 in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1077 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[177],((C_word*)t0)[2]);}

/* set-user-id! in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2869,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp((C_word)C_setuid(t2),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2879,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 1056 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2877 in set-user-id! in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1057 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[172],lf[173],((C_word*)t0)[2]);}

/* system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2835,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp(C_fix((C_word)C_uname),C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 1045 ##sys#update-errno */
t4=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2835(2,t3,C_SCHEME_UNDEFINED);}}

/* k2862 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 1046 ##sys#error */
t2=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[169],lf[171]);}

/* k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.sysname),C_fix(0));}

/* k2840 in k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2846,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.nodename),C_fix(0));}

/* k2844 in k2840 in k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.release),C_fix(0));}

/* k2848 in k2844 in k2840 in k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2854,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.version),C_fix(0));}

/* k2852 in k2848 in k2844 in k2840 in k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2858,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ##sys#peek-nonnull-c-string */
t3=*((C_word*)lf[170]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_utsname.machine),C_fix(0));}

/* k2856 in k2852 in k2848 in k2844 in k2840 in k2833 in system-information in k2827 in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* signal-unmask! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2813,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[167]);
t4=(C_word)C_sigdelset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_unblock(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1024 posix-error */
t5=lf[3];
f_1512(5,t5,t1,lf[161],lf[167],lf[168]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-mask! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2798,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[165]);
t4=(C_word)C_sigaddset(t2);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_block(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1018 posix-error */
t5=lf[3];
f_1512(5,t5,t1,lf[161],lf[165],lf[166]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* signal-masked? in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2792,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[164]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigismember(t2));}

/* signal-mask in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2766(t5,t1,*((C_word*)lf[156]+1),C_SCHEME_END_OF_LIST);}

/* loop in signal-mask in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2766,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(C_truep((C_word)C_sigismember(t4))?(C_word)C_a_i_cons(&a,2,t4,t3):t3);
/* posixunix.scm: 1008 loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}

/* set-signal-mask! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2736,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,lf[160]);
t4=(C_word)C_sigemptyset(C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2743,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2754,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t7=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t2);}

/* a2753 in set-signal-mask! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2754(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2754,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[160]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_sigaddset(t2));}

/* k2741 in set-signal-mask! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp((C_word)C_sigprocmask_set(C_fix(0)),C_fix(0)))){
/* posixunix.scm: 1001 posix-error */
t2=lf[3];
f_1512(5,t2,((C_word*)t0)[2],lf[161],lf[160],lf[162]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* ##sys#interrupt-hook in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2718,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2728,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 987  h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixunix.scm: 989  oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2726 in ##sys#interrupt-hook in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 988  ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2705(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2705,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[159]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2692 in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2696,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[158]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2653,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE),C_fix(0)))){
/* posixunix.scm: 904  posix-error */
t3=lf[3];
f_1512(5,t3,t2,lf[48],lf[129],lf[130]);}
else{
t3=t2;
f_2653(2,t3,C_SCHEME_UNDEFINED);}}

/* k2651 in create-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 905  values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2629r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2629r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2629r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[128]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2633,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2631 in with-output-to-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
t2=C_mutate((C_word*)lf[128]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 892  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2638 in k2631 in with-output-to-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2639r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2639r(t0,t1,t2);}}

static void C_ccall f_2639r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2643,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 894  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2641 in a2638 in k2631 in with-output-to-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[128]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2609r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2609r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2609r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[126]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2613,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2611 in with-input-from-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2613,2,t0,t1);}
t2=C_mutate((C_word*)lf[126]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2619,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 882  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2618 in k2611 in with-input-from-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2619r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2619r(t0,t1,t2);}}

static void C_ccall f_2619r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2623,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixunix.scm: 884  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2621 in a2618 in k2611 in with-input-from-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[126]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2585r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2585r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2585r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2589,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2587 in call-with-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2594,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 872  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2599 in k2587 in call-with-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2600r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2600r(t0,t1,t2);}}

static void C_ccall f_2600r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2604,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 875  close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2602 in a2599 in k2587 in call-with-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2593 in k2587 in call-with-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2594,2,t0,t1);}
/* posixunix.scm: 873  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_2561r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2561r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2561r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2565,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k2563 in call-with-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 864  ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2575 in k2563 in call-with-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2576r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2576r(t0,t1,t2);}}

static void C_ccall f_2576r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2580,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 867  close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2578 in a2575 in k2563 in call-with-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2569 in k2563 in call-with-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
/* posixunix.scm: 865  proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2545,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2549,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 851  ##sys#check-port */
t4=*((C_word*)lf[121]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[118]);}

/* k2547 in close-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2549,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2552,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 853  posix-error */
t5=lf[3];
f_1512(6,t5,t3,lf[48],lf[119],lf[120],((C_word*)t0)[3]);}
else{
t5=t3;
f_2552(2,t5,C_SCHEME_UNDEFINED);}}

/* k2550 in k2547 in close-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2509r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2509r(t0,t1,t2,t3);}}

static void C_ccall f_2509r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[117]);
t5=f_2440(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[108]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2530,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 846  ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 847  ##sys#make-c-string */
t10=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 848  badmode */
f_2452(t6,t5);}}}

/* k2538 in open-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2523(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k2528 in open-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2523(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k2521 in open-output-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 842  check */
f_2458(((C_word*)t0)[3],lf[117],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_2473r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2473r(t0,t1,t2,t3);}}

static void C_ccall f_2473r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[115]);
t5=f_2440(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2487,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[108]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 835  ##sys#make-c-string */
t9=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[116]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 836  ##sys#make-c-string */
t10=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixunix.scm: 837  badmode */
f_2452(t6,t5);}}}

/* k2502 in open-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2487(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k2492 in open-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2494,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2487(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k2485 in open-input-pipe in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 831  check */
f_2458(((C_word*)t0)[3],lf[115],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2458(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2458,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_null_pointerp(t5))){
/* posixunix.scm: 823  posix-error */
t6=lf[3];
f_1512(6,t6,t1,lf[48],t2,lf[111],t3);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2471,a[2]=t1,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 824  ##sys#make-port */
t7=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t6,t4,*((C_word*)lf[113]+1),lf[114],lf[87]);}}

/* k2469 in check in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2452(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2452,NULL,2,t1,t2);}
/* posixunix.scm: 820  ##sys#error */
t3=*((C_word*)lf[109]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[110],t2);}

/* mode in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_2440(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[108]));}

/* current-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2404r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2404r(t0,t1,t2);}}

static void C_ccall f_2404r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixunix.scm: 808  change-directory */
t5=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2417,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 809  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k2415 in current-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_curdir(t1);
if(C_truep(t2)){
/* posixunix.scm: 812  ##sys#substring */
t3=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,C_fix(0),t2);}
else{
/* posixunix.scm: 813  posix-error */
t3=lf[3];
f_1512(5,t3,((C_word*)t0)[2],lf[48],lf[104],lf[107]);}}

/* directory? in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2381,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[105]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2388,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2402,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 801  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2400 in directory? in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 801  ##sys#file-info */
t2=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2386 in directory? in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2227(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_2227r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2227r(t0,t1,t2);}}

static void C_ccall f_2227r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(10);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2327,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2332,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec182207 */
t6=t5;
f_2332(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?183205 */
t8=t4;
f_2327(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body180185 */
t10=t3;
f_2229(t10,t1,t6,t8);}}}

/* def-spec182 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2332,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2340,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 774  current-directory */
t3=*((C_word*)lf[104]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2338 in def-spec182 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?183205 */
t2=((C_word*)t0)[3];
f_2327(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?183 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2327(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2327,NULL,3,t0,t1,t2);}
/* body180185 */
t3=((C_word*)t0)[2];
f_2229(t3,t1,t2,C_SCHEME_FALSE);}

/* body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2229(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2229,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[101]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 776  make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 777  ##sys#make-pointer */
t3=*((C_word*)lf[103]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 778  ##sys#make-pointer */
t3=*((C_word*)lf[103]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2326,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 779  ##sys#expand-home-path */
t4=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* k2324 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 779  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2246,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[8]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[8]))){
/* posixunix.scm: 781  posix-error */
t3=lf[3];
f_1512(6,t3,((C_word*)t0)[7],lf[48],lf[101],lf[102],((C_word*)t0)[6]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2260(t6,((C_word*)t0)[7]);}}

/* loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2260(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2260,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[6]))){
t3=(C_word)C_closedir(((C_word*)t0)[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[6],((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* posixunix.scm: 789  ##sys#substring */
t5=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[5],C_fix(0),t3);}}

/* k2268 in loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 790  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,C_fix(0));}

/* k2271 in k2268 in loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(1)))){
/* posixunix.scm: 791  string-ref */
t3=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(1));}
else{
t3=t2;
f_2276(2,t3,C_SCHEME_FALSE);}}

/* k2274 in k2271 in k2268 in loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],C_make_character(46));
if(C_truep(t3)){
t4=(C_word)C_i_not(t1);
if(C_truep(t4)){
t5=t2;
f_2282(t5,t4);}
else{
t5=(C_word)C_eqp(t1,C_make_character(46));
t6=(C_truep(t5)?(C_word)C_eqp(((C_word*)t0)[3],C_fix(2)):C_SCHEME_FALSE);
t7=t2;
f_2282(t7,(C_truep(t6)?t6:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t2;
f_2282(t4,C_SCHEME_FALSE);}}

/* k2280 in k2274 in k2271 in k2268 in loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_2282(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2282,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixunix.scm: 796  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2260(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 797  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2260(t3,t2);}}

/* k2290 in k2280 in k2274 in k2271 in k2268 in loop in k2244 in k2240 in k2237 in k2234 in body180 in directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2292,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* delete-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2203,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[97]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 767  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2223 in delete-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 767  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2219 in delete-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 768  posix-error */
t3=lf[3];
f_1512(6,t3,((C_word*)t0)[3],lf[48],lf[97],lf[98],((C_word*)t0)[2]);}}

/* change-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2179,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[95]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2197,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2201,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 761  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2199 in change-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 761  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2195 in change-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 762  posix-error */
t3=lf[3];
f_1512(6,t3,((C_word*)t0)[3],lf[48],lf[95],lf[96],((C_word*)t0)[2]);}}

/* create-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2155,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[93]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2173,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2177,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 755  ##sys#expand-home-path */
t6=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k2175 in create-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 755  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2171 in create-directory in k2151 in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 756  posix-error */
t3=lf[3];
f_1512(6,t3,((C_word*)t0)[3],lf[48],lf[93],lf[94],((C_word*)t0)[2]);}}

/* set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2093r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2093r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2093r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[85]);
t8=(C_word)C_i_check_exact_2(t6,lf[85]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2106,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixunix.scm: 727  ##sys#signal-hook */
t10=*((C_word*)lf[4]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[90],lf[85],lf[91],t3,t2);}
else{
t10=t9;
f_2106(2,t10,C_SCHEME_UNDEFINED);}}

/* k2104 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2112,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixunix.scm: 728  port? */
t4=*((C_word*)lf[89]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k2116 in k2104 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[87]);
t4=((C_word*)t0)[4];
f_2112(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_2112(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixunix.scm: 732  ##sys#signal-hook */
t2=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[59],lf[85],lf[88],((C_word*)t0)[5]);}}}

/* k2110 in k2104 in set-file-position! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 733  posix-error */
t2=lf[3];
f_1512(7,t2,((C_word*)t0)[4],lf[48],lf[85],lf[86],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* symbolic-link? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2084(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2084,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[84]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 719  ##sys#stat */
f_1977(t4,t2,C_SCHEME_TRUE,lf[84]);}

/* k2089 in symbolic-link? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_islink));}

/* regular-file? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2075,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 714  ##sys#stat */
f_1977(t4,t2,C_SCHEME_TRUE,lf[83]);}

/* k2080 in regular-file? in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_mk_bool(C_isreg));}

/* file-permissions in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2069,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 710  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[82]);}

/* k2071 in file-permissions in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2063(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2063,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2067,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 709  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[81]);}

/* k2065 in file-owner in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2057,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 708  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[80]);}

/* k2059 in file-change-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2061,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2051,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2055,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 707  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[79]);}

/* k2053 in file-access-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2045,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 706  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[78]);}

/* k2047 in file-modification-time in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2039,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2043,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 705  ##sys#stat */
f_1977(t3,t2,C_SCHEME_FALSE,lf[77]);}

/* k2041 in file-size in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2043,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_double_to_num(&a,C_statbuf.st_size));}

/* file-stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2014r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2014r(t0,t1,t2,t3);}}

static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2018,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
/* posixunix.scm: 698  ##sys#stat */
f_1977(t4,t2,t6,lf[76]);}

/* k2016 in file-stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_a_double_to_num(&a,C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_dev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_rdev),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blksize),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_blocks)));}

/* ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1977(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1977,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1981,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t6=t5;
f_1981(2,t6,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2009,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 689  ##sys#expand-home-path */
t8=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}
else{
/* posixunix.scm: 693  ##sys#signal-hook */
t6=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[59],lf[75],t2);}}}

/* k2007 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 689  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2000 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1981(2,t2,(C_truep(((C_word*)t0)[2])?(C_word)C_lstat(t1):(C_word)C_stat(t1)));}

/* k1979 in ##sys#stat in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 695  posix-error */
t2=lf[3];
f_1512(6,t2,((C_word*)t0)[4],lf[48],((C_word*)t0)[3],lf[74],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1785r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1785r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1785r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(15);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_notvemptyp(t4);
t8=(C_truep(t7)?(C_word)C_slot(t4,C_fix(0)):C_SCHEME_FALSE);
t9=f_1779(C_fix(0));
t10=f_1779(C_fix(1));
t11=(C_word)C_i_not(t2);
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t11)){
t13=t12;
f_1801(2,t13,t11);}
else{
if(C_truep((C_word)C_fixnump(t2))){
t13=C_set_block_item(t6,0,t2);
/* posixunix.scm: 618  fd_set */
t14=t12;
f_1801(2,t14,f_1781(C_fix(0),t2));}
else{
t13=(C_word)C_i_check_list_2(t2,lf[67]);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t12,t14,t2);}}}

/* a1957 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1958,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[67]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 625  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1781(C_fix(0),t2));}

/* k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=(C_word)C_i_not(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_1807(2,t4,t2);}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[8]))){
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)t0)[8]);
/* posixunix.scm: 630  fd_set */
t5=t3;
f_1807(2,t5,f_1781(C_fix(1),((C_word*)t0)[8]));}
else{
t4=(C_word)C_i_check_list_2(((C_word*)t0)[8],lf[67]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,((C_word*)t0)[8]);}}}

/* a1931 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1932,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[67]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,(C_word)C_i_fixnum_max(((C_word*)((C_word*)t0)[3])[1],t2));
/* posixunix.scm: 637  fd_set */
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_1781(C_fix(1),t2));}

/* k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1810,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(C_word)C_i_check_number_2(((C_word*)t0)[3],lf[67]);
t4=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t5=t2;
f_1810(t5,(C_word)C_C_select_t(t4,((C_word*)t0)[3]));}
else{
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t4=t2;
f_1810(t4,(C_word)C_C_select(t3));}}

/* k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1810,NULL,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
/* posixunix.scm: 644  posix-error */
t2=lf[3];
f_1512(7,t2,((C_word*)t0)[5],lf[48],lf[67],lf[68],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=(C_word)C_i_pairp(((C_word*)t0)[4]);
t4=(C_truep(t3)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
t5=(C_word)C_i_pairp(((C_word*)t0)[3]);
t6=(C_truep(t5)?C_SCHEME_END_OF_LIST:C_SCHEME_FALSE);
/* posixunix.scm: 645  values */
C_values(4,0,((C_word*)t0)[5],t4,t6);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[4]))){
/* posixunix.scm: 650  fd_test */
t4=t3;
f_1849(t4,f_1783(C_fix(0),((C_word*)t0)[4]));}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1890,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1892,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t8=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[4]);}}
else{
t4=t3;
f_1849(t4,C_SCHEME_FALSE);}}}}

/* a1891 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1892,3,t0,t1,t2);}
t3=f_1783(C_fix(0),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1888 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1849(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1847 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1849(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1849,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1853,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
/* posixunix.scm: 656  fd_test */
t3=t2;
f_1853(t3,f_1783(C_fix(1),((C_word*)t0)[3]));}
else{
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1865,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[69]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,((C_word*)t0)[3]);}}
else{
t3=t2;
f_1853(t3,C_SCHEME_FALSE);}}

/* a1866 in k1847 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1867,3,t0,t1,t2);}
t3=f_1783(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1863 in k1847 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1853(t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k1851 in k1847 in k1808 in k1805 in k1799 in file-select in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_fcall f_1853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 647  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* fd_test in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1783(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub92(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_set in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1781(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub86(C_SCHEME_UNDEFINED,t1,t2));}

/* fd_zero in k1503 in k1500 in k1497 in k1494 in k1491 */
static C_word C_fcall f_1779(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub81(C_SCHEME_UNDEFINED,t1));}

/* file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1747,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[64]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1754,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixunix.scm: 596  ##sys#make-c-string */
t5=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1752 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1754,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(C_word)C_block_size(t1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1760,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
/* posixunix.scm: 600  posix-error */
t6=lf[3];
f_1512(6,t6,t4,lf[48],lf[64],lf[66],((C_word*)t0)[2]);}
else{
t6=t4;
f_1760(2,t6,C_SCHEME_UNDEFINED);}}

/* k1758 in k1752 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1767,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixunix.scm: 601  ##sys#substring */
t4=*((C_word*)lf[65]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1765 in k1758 in k1752 in file-mkstemp in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 601  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1708r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1708r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1708r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[61]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1715,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1715(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 585  ##sys#signal-hook */
t8=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[59],lf[61],lf[63],t3);}}

/* k1713 in file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1715,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[61]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1724,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
/* posixunix.scm: 590  posix-error */
t8=lf[3];
f_1512(7,t8,t6,lf[48],lf[61],lf[62],((C_word*)t0)[3],t3);}
else{
t8=t6;
f_1724(2,t8,C_SCHEME_UNDEFINED);}}

/* k1722 in k1713 in file-write in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1666r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1666r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1666r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[57]);
t6=(C_word)C_i_check_exact_2(t3,lf[57]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1676,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1676(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixunix.scm: 573  make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k1674 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1679(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixunix.scm: 575  ##sys#signal-hook */
t4=*((C_word*)lf[4]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[59],lf[57],lf[60],t1);}}

/* k1677 in k1674 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1679,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1682,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 578  posix-error */
t5=lf[3];
f_1512(7,t5,t3,lf[48],lf[57],lf[58],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t5=t3;
f_1682(2,t5,C_SCHEME_UNDEFINED);}}

/* k1680 in k1677 in k1674 in file-read in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1651,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[54]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
/* posixunix.scm: 566  posix-error */
t4=lf[3];
f_1512(6,t4,t1,lf[48],lf[54],lf[55],t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1613r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1613r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1613r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[50]);
t8=(C_word)C_i_check_exact_2(t3,lf[50]);
t9=(C_word)C_i_check_exact_2(t6,lf[50]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1630,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1643,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixunix.scm: 557  ##sys#expand-home-path */
t12=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1641 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 557  ##sys#make-c-string */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1628 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1630,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
/* posixunix.scm: 559  posix-error */
t5=lf[3];
f_1512(8,t5,t3,lf[48],lf[50],lf[51],((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t5=t3;
f_1633(2,t5,C_SCHEME_UNDEFINED);}}

/* k1631 in k1628 in file-open in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-control in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1574r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1574r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1574r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
t5=(C_word)C_vemptyp(t4);
t6=(C_truep(t5)?C_fix(0):(C_word)C_slot(t4,C_fix(0)));
t7=(C_word)C_i_check_exact_2(t2,lf[47]);
t8=(C_word)C_i_check_exact_2(t3,lf[47]);
t9=t2;
t10=t3;
t11=(C_word)stub24(C_SCHEME_UNDEFINED,t9,t10,t6);
t12=(C_word)C_eqp(t11,C_fix(-1));
if(C_truep(t12)){
/* posixunix.scm: 547  posix-error */
t13=lf[3];
f_1512(7,t13,t1,lf[48],lf[47],lf[49],t2,t3);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t11);}}

/* ##sys#file-select-one in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1533,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub17(C_SCHEME_UNDEFINED,t2));}

/* ##sys#file-nonblocking! in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1530,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub13(C_SCHEME_UNDEFINED,t2));}

/* posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1512r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1512r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1512r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1516,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixunix.scm: 437  ##sys#update-errno */
t7=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1514 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1523,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1527,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub3(t4,t1),C_fix(0));}

/* k1525 in k1514 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixunix.scm: 438  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[5],t1);}

/* k1521 in k1514 in posix-error in k1503 in k1500 in k1497 in k1494 in k1491 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[4]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[528] = {
{"toplevelposixunix.scm",(void*)C_posix_toplevel},
{"f_1493posixunix.scm",(void*)f_1493},
{"f_1496posixunix.scm",(void*)f_1496},
{"f_1499posixunix.scm",(void*)f_1499},
{"f_1502posixunix.scm",(void*)f_1502},
{"f_1505posixunix.scm",(void*)f_1505},
{"f_6510posixunix.scm",(void*)f_6510},
{"f_6526posixunix.scm",(void*)f_6526},
{"f_6514posixunix.scm",(void*)f_6514},
{"f_6517posixunix.scm",(void*)f_6517},
{"f_2153posixunix.scm",(void*)f_2153},
{"f_2694posixunix.scm",(void*)f_2694},
{"f_6504posixunix.scm",(void*)f_6504},
{"f_2829posixunix.scm",(void*)f_2829},
{"f_6501posixunix.scm",(void*)f_6501},
{"f_2886posixunix.scm",(void*)f_2886},
{"f_6486posixunix.scm",(void*)f_6486},
{"f_6496posixunix.scm",(void*)f_6496},
{"f_6483posixunix.scm",(void*)f_6483},
{"f_2890posixunix.scm",(void*)f_2890},
{"f_6480posixunix.scm",(void*)f_6480},
{"f_2909posixunix.scm",(void*)f_2909},
{"f_6465posixunix.scm",(void*)f_6465},
{"f_6475posixunix.scm",(void*)f_6475},
{"f_6462posixunix.scm",(void*)f_6462},
{"f_2913posixunix.scm",(void*)f_2913},
{"f_6444posixunix.scm",(void*)f_6444},
{"f_6457posixunix.scm",(void*)f_6457},
{"f_6451posixunix.scm",(void*)f_6451},
{"f_3417posixunix.scm",(void*)f_3417},
{"f_3456posixunix.scm",(void*)f_3456},
{"f_6421posixunix.scm",(void*)f_6421},
{"f_6417posixunix.scm",(void*)f_6417},
{"f_6163posixunix.scm",(void*)f_6163},
{"f_6346posixunix.scm",(void*)f_6346},
{"f_6352posixunix.scm",(void*)f_6352},
{"f_6341posixunix.scm",(void*)f_6341},
{"f_6336posixunix.scm",(void*)f_6336},
{"f_6165posixunix.scm",(void*)f_6165},
{"f_6323posixunix.scm",(void*)f_6323},
{"f_6331posixunix.scm",(void*)f_6331},
{"f_6172posixunix.scm",(void*)f_6172},
{"f_6311posixunix.scm",(void*)f_6311},
{"f_6305posixunix.scm",(void*)f_6305},
{"f_6182posixunix.scm",(void*)f_6182},
{"f_6184posixunix.scm",(void*)f_6184},
{"f_6203posixunix.scm",(void*)f_6203},
{"f_6291posixunix.scm",(void*)f_6291},
{"f_6298posixunix.scm",(void*)f_6298},
{"f_6285posixunix.scm",(void*)f_6285},
{"f_6218posixunix.scm",(void*)f_6218},
{"f_6278posixunix.scm",(void*)f_6278},
{"f_6275posixunix.scm",(void*)f_6275},
{"f_6262posixunix.scm",(void*)f_6262},
{"f_6238posixunix.scm",(void*)f_6238},
{"f_6260posixunix.scm",(void*)f_6260},
{"f_6246posixunix.scm",(void*)f_6246},
{"f_6253posixunix.scm",(void*)f_6253},
{"f_6250posixunix.scm",(void*)f_6250},
{"f_6230posixunix.scm",(void*)f_6230},
{"f_6228posixunix.scm",(void*)f_6228},
{"f_6312posixunix.scm",(void*)f_6312},
{"f_6106posixunix.scm",(void*)f_6106},
{"f_6118posixunix.scm",(void*)f_6118},
{"f_6113posixunix.scm",(void*)f_6113},
{"f_6108posixunix.scm",(void*)f_6108},
{"f_6049posixunix.scm",(void*)f_6049},
{"f_6061posixunix.scm",(void*)f_6061},
{"f_6056posixunix.scm",(void*)f_6056},
{"f_6051posixunix.scm",(void*)f_6051},
{"f_5988posixunix.scm",(void*)f_5988},
{"f_6043posixunix.scm",(void*)f_6043},
{"f_6047posixunix.scm",(void*)f_6047},
{"f_6009posixunix.scm",(void*)f_6009},
{"f_6012posixunix.scm",(void*)f_6012},
{"f_6023posixunix.scm",(void*)f_6023},
{"f_6017posixunix.scm",(void*)f_6017},
{"f_5990posixunix.scm",(void*)f_5990},
{"f_5999posixunix.scm",(void*)f_5999},
{"f_5924posixunix.scm",(void*)f_5924},
{"f_5936posixunix.scm",(void*)f_5936},
{"f_5967posixunix.scm",(void*)f_5967},
{"f_5947posixunix.scm",(void*)f_5947},
{"f_5963posixunix.scm",(void*)f_5963},
{"f_5951posixunix.scm",(void*)f_5951},
{"f_5959posixunix.scm",(void*)f_5959},
{"f_5955posixunix.scm",(void*)f_5955},
{"f_5930posixunix.scm",(void*)f_5930},
{"f_5913posixunix.scm",(void*)f_5913},
{"f_5917posixunix.scm",(void*)f_5917},
{"f_5902posixunix.scm",(void*)f_5902},
{"f_5906posixunix.scm",(void*)f_5906},
{"f_5857posixunix.scm",(void*)f_5857},
{"f_5861posixunix.scm",(void*)f_5861},
{"f_5864posixunix.scm",(void*)f_5864},
{"f_5867posixunix.scm",(void*)f_5867},
{"f_5880posixunix.scm",(void*)f_5880},
{"f_5884posixunix.scm",(void*)f_5884},
{"f_5887posixunix.scm",(void*)f_5887},
{"f_5890posixunix.scm",(void*)f_5890},
{"f_5878posixunix.scm",(void*)f_5878},
{"f_5841posixunix.scm",(void*)f_5841},
{"f_5824posixunix.scm",(void*)f_5824},
{"f_5837posixunix.scm",(void*)f_5837},
{"f_5749posixunix.scm",(void*)f_5749},
{"f_5810posixunix.scm",(void*)f_5810},
{"f_5823posixunix.scm",(void*)f_5823},
{"f_5790posixunix.scm",(void*)f_5790},
{"f_5805posixunix.scm",(void*)f_5805},
{"f_5799posixunix.scm",(void*)f_5799},
{"f_5753posixunix.scm",(void*)f_5753},
{"f_5755posixunix.scm",(void*)f_5755},
{"f_5776posixunix.scm",(void*)f_5776},
{"f_5770posixunix.scm",(void*)f_5770},
{"f_5697posixunix.scm",(void*)f_5697},
{"f_5704posixunix.scm",(void*)f_5704},
{"f_5723posixunix.scm",(void*)f_5723},
{"f_5727posixunix.scm",(void*)f_5727},
{"f_5691posixunix.scm",(void*)f_5691},
{"f_5682posixunix.scm",(void*)f_5682},
{"f_5686posixunix.scm",(void*)f_5686},
{"f_5655posixunix.scm",(void*)f_5655},
{"f_5652posixunix.scm",(void*)f_5652},
{"f_5649posixunix.scm",(void*)f_5649},
{"f_5646posixunix.scm",(void*)f_5646},
{"f_5571posixunix.scm",(void*)f_5571},
{"f_5604posixunix.scm",(void*)f_5604},
{"f_5598posixunix.scm",(void*)f_5598},
{"f_5554posixunix.scm",(void*)f_5554},
{"f_5375posixunix.scm",(void*)f_5375},
{"f_5509posixunix.scm",(void*)f_5509},
{"f_5504posixunix.scm",(void*)f_5504},
{"f_5377posixunix.scm",(void*)f_5377},
{"f_5387posixunix.scm",(void*)f_5387},
{"f_5395posixunix.scm",(void*)f_5395},
{"f_5441posixunix.scm",(void*)f_5441},
{"f_5408posixunix.scm",(void*)f_5408},
{"f_5433posixunix.scm",(void*)f_5433},
{"f_5411posixunix.scm",(void*)f_5411},
{"f_5367posixunix.scm",(void*)f_5367},
{"f_5359posixunix.scm",(void*)f_5359},
{"f_5321posixunix.scm",(void*)f_5321},
{"f_5343posixunix.scm",(void*)f_5343},
{"f_5347posixunix.scm",(void*)f_5347},
{"f_5209posixunix.scm",(void*)f_5209},
{"f_5215posixunix.scm",(void*)f_5215},
{"f_5236posixunix.scm",(void*)f_5236},
{"f_5313posixunix.scm",(void*)f_5313},
{"f_5240posixunix.scm",(void*)f_5240},
{"f_5243posixunix.scm",(void*)f_5243},
{"f_5246posixunix.scm",(void*)f_5246},
{"f_5253posixunix.scm",(void*)f_5253},
{"f_5255posixunix.scm",(void*)f_5255},
{"f_5272posixunix.scm",(void*)f_5272},
{"f_5282posixunix.scm",(void*)f_5282},
{"f_5286posixunix.scm",(void*)f_5286},
{"f_5230posixunix.scm",(void*)f_5230},
{"f_5197posixunix.scm",(void*)f_5197},
{"f_5201posixunix.scm",(void*)f_5201},
{"f_5204posixunix.scm",(void*)f_5204},
{"f_5162posixunix.scm",(void*)f_5162},
{"f_5166posixunix.scm",(void*)f_5166},
{"f_5186posixunix.scm",(void*)f_5186},
{"f_5190posixunix.scm",(void*)f_5190},
{"f_5143posixunix.scm",(void*)f_5143},
{"f_5147posixunix.scm",(void*)f_5147},
{"f_5116posixunix.scm",(void*)f_5116},
{"f_5120posixunix.scm",(void*)f_5120},
{"f_5097posixunix.scm",(void*)f_5097},
{"f_5101posixunix.scm",(void*)f_5101},
{"f_5104posixunix.scm",(void*)f_5104},
{"f_5038posixunix.scm",(void*)f_5038},
{"f_5042posixunix.scm",(void*)f_5042},
{"f_5048posixunix.scm",(void*)f_5048},
{"f_5035posixunix.scm",(void*)f_5035},
{"f_5019posixunix.scm",(void*)f_5019},
{"f_5011posixunix.scm",(void*)f_5011},
{"f_4983posixunix.scm",(void*)f_4983},
{"f_4990posixunix.scm",(void*)f_4990},
{"f_4955posixunix.scm",(void*)f_4955},
{"f_4962posixunix.scm",(void*)f_4962},
{"f_4916posixunix.scm",(void*)f_4916},
{"f_4923posixunix.scm",(void*)f_4923},
{"f_4926posixunix.scm",(void*)f_4926},
{"f_4929posixunix.scm",(void*)f_4929},
{"f_4888posixunix.scm",(void*)f_4888},
{"f_4892posixunix.scm",(void*)f_4892},
{"f_4895posixunix.scm",(void*)f_4895},
{"f_4874posixunix.scm",(void*)f_4874},
{"f_4865posixunix.scm",(void*)f_4865},
{"f_4859posixunix.scm",(void*)f_4859},
{"f_4850posixunix.scm",(void*)f_4850},
{"f_4815posixunix.scm",(void*)f_4815},
{"f_4757posixunix.scm",(void*)f_4757},
{"f_4761posixunix.scm",(void*)f_4761},
{"f_4767posixunix.scm",(void*)f_4767},
{"f_4786posixunix.scm",(void*)f_4786},
{"f_4773posixunix.scm",(void*)f_4773},
{"f_4674posixunix.scm",(void*)f_4674},
{"f_4680posixunix.scm",(void*)f_4680},
{"f_4684posixunix.scm",(void*)f_4684},
{"f_4692posixunix.scm",(void*)f_4692},
{"f_4718posixunix.scm",(void*)f_4718},
{"f_4722posixunix.scm",(void*)f_4722},
{"f_4710posixunix.scm",(void*)f_4710},
{"f_4659posixunix.scm",(void*)f_4659},
{"f_4667posixunix.scm",(void*)f_4667},
{"f_4642posixunix.scm",(void*)f_4642},
{"f_4653posixunix.scm",(void*)f_4653},
{"f_4657posixunix.scm",(void*)f_4657},
{"f_4616posixunix.scm",(void*)f_4616},
{"f_4640posixunix.scm",(void*)f_4640},
{"f_4623posixunix.scm",(void*)f_4623},
{"f_4573posixunix.scm",(void*)f_4573},
{"f_4580posixunix.scm",(void*)f_4580},
{"f_4601posixunix.scm",(void*)f_4601},
{"f_4597posixunix.scm",(void*)f_4597},
{"f_4545posixunix.scm",(void*)f_4545},
{"f_4523posixunix.scm",(void*)f_4523},
{"f_4527posixunix.scm",(void*)f_4527},
{"f_4508posixunix.scm",(void*)f_4508},
{"f_4512posixunix.scm",(void*)f_4512},
{"f_4493posixunix.scm",(void*)f_4493},
{"f_4497posixunix.scm",(void*)f_4497},
{"f_4475posixunix.scm",(void*)f_4475},
{"f_4404posixunix.scm",(void*)f_4404},
{"f_4423posixunix.scm",(void*)f_4423},
{"f_4429posixunix.scm",(void*)f_4429},
{"f_4365posixunix.scm",(void*)f_4365},
{"f_4393posixunix.scm",(void*)f_4393},
{"f_4389posixunix.scm",(void*)f_4389},
{"f_4382posixunix.scm",(void*)f_4382},
{"f_4109posixunix.scm",(void*)f_4109},
{"f_4305posixunix.scm",(void*)f_4305},
{"f_4300posixunix.scm",(void*)f_4300},
{"f_4295posixunix.scm",(void*)f_4295},
{"f_4111posixunix.scm",(void*)f_4111},
{"f_4115posixunix.scm",(void*)f_4115},
{"f_4221posixunix.scm",(void*)f_4221},
{"f_4222posixunix.scm",(void*)f_4222},
{"f_4239posixunix.scm",(void*)f_4239},
{"f_4249posixunix.scm",(void*)f_4249},
{"f_4207posixunix.scm",(void*)f_4207},
{"f_4163posixunix.scm",(void*)f_4163},
{"f_4199posixunix.scm",(void*)f_4199},
{"f_4178posixunix.scm",(void*)f_4178},
{"f_4188posixunix.scm",(void*)f_4188},
{"f_4172posixunix.scm",(void*)f_4172},
{"f_4167posixunix.scm",(void*)f_4167},
{"f_4170posixunix.scm",(void*)f_4170},
{"f_4117posixunix.scm",(void*)f_4117},
{"f_4152posixunix.scm",(void*)f_4152},
{"f_4133posixunix.scm",(void*)f_4133},
{"f_3676posixunix.scm",(void*)f_3676},
{"f_4034posixunix.scm",(void*)f_4034},
{"f_4029posixunix.scm",(void*)f_4029},
{"f_4024posixunix.scm",(void*)f_4024},
{"f_4019posixunix.scm",(void*)f_4019},
{"f_3678posixunix.scm",(void*)f_3678},
{"f_3682posixunix.scm",(void*)f_3682},
{"f_3688posixunix.scm",(void*)f_3688},
{"f_3919posixunix.scm",(void*)f_3919},
{"f_3925posixunix.scm",(void*)f_3925},
{"f_3994posixunix.scm",(void*)f_3994},
{"f_3937posixunix.scm",(void*)f_3937},
{"f_3941posixunix.scm",(void*)f_3941},
{"f_3951posixunix.scm",(void*)f_3951},
{"f_3967posixunix.scm",(void*)f_3967},
{"f_3854posixunix.scm",(void*)f_3854},
{"f_3860posixunix.scm",(void*)f_3860},
{"f_3908posixunix.scm",(void*)f_3908},
{"f_3845posixunix.scm",(void*)f_3845},
{"f_3849posixunix.scm",(void*)f_3849},
{"f_3824posixunix.scm",(void*)f_3824},
{"f_3834posixunix.scm",(void*)f_3834},
{"f_3812posixunix.scm",(void*)f_3812},
{"f_3799posixunix.scm",(void*)f_3799},
{"f_3803posixunix.scm",(void*)f_3803},
{"f_3794posixunix.scm",(void*)f_3794},
{"f_3797posixunix.scm",(void*)f_3797},
{"f_3712posixunix.scm",(void*)f_3712},
{"f_3724posixunix.scm",(void*)f_3724},
{"f_3761posixunix.scm",(void*)f_3761},
{"f_3770posixunix.scm",(void*)f_3770},
{"f_3764posixunix.scm",(void*)f_3764},
{"f_3740posixunix.scm",(void*)f_3740},
{"f_3743posixunix.scm",(void*)f_3743},
{"f_3704posixunix.scm",(void*)f_3704},
{"f_3689posixunix.scm",(void*)f_3689},
{"f_3703posixunix.scm",(void*)f_3703},
{"f_3649posixunix.scm",(void*)f_3649},
{"f_3656posixunix.scm",(void*)f_3656},
{"f_3659posixunix.scm",(void*)f_3659},
{"f_3604posixunix.scm",(void*)f_3604},
{"f_3608posixunix.scm",(void*)f_3608},
{"f_3643posixunix.scm",(void*)f_3643},
{"f_3626posixunix.scm",(void*)f_3626},
{"f_3590posixunix.scm",(void*)f_3590},
{"f_3602posixunix.scm",(void*)f_3602},
{"f_3576posixunix.scm",(void*)f_3576},
{"f_3588posixunix.scm",(void*)f_3588},
{"f_3561posixunix.scm",(void*)f_3561},
{"f_3574posixunix.scm",(void*)f_3574},
{"f_3524posixunix.scm",(void*)f_3524},
{"f_3532posixunix.scm",(void*)f_3532},
{"f_3499posixunix.scm",(void*)f_3499},
{"f_3488posixunix.scm",(void*)f_3488},
{"f_3492posixunix.scm",(void*)f_3492},
{"f_3457posixunix.scm",(void*)f_3457},
{"f_3481posixunix.scm",(void*)f_3481},
{"f_3465posixunix.scm",(void*)f_3465},
{"f_3468posixunix.scm",(void*)f_3468},
{"f_3419posixunix.scm",(void*)f_3419},
{"f_3452posixunix.scm",(void*)f_3452},
{"f_3440posixunix.scm",(void*)f_3440},
{"f_3448posixunix.scm",(void*)f_3448},
{"f_3444posixunix.scm",(void*)f_3444},
{"f_3394posixunix.scm",(void*)f_3394},
{"f_3410posixunix.scm",(void*)f_3410},
{"f_3379posixunix.scm",(void*)f_3379},
{"f_3389posixunix.scm",(void*)f_3389},
{"f_3383posixunix.scm",(void*)f_3383},
{"f_3373posixunix.scm",(void*)f_3373},
{"f_3367posixunix.scm",(void*)f_3367},
{"f_3361posixunix.scm",(void*)f_3361},
{"f_3337posixunix.scm",(void*)f_3337},
{"f_3359posixunix.scm",(void*)f_3359},
{"f_3355posixunix.scm",(void*)f_3355},
{"f_3347posixunix.scm",(void*)f_3347},
{"f_3307posixunix.scm",(void*)f_3307},
{"f_3335posixunix.scm",(void*)f_3335},
{"f_3331posixunix.scm",(void*)f_3331},
{"f_3280posixunix.scm",(void*)f_3280},
{"f_3305posixunix.scm",(void*)f_3305},
{"f_3301posixunix.scm",(void*)f_3301},
{"f_3216posixunix.scm",(void*)f_3216},
{"f_3212posixunix.scm",(void*)f_3212},
{"f_3232posixunix.scm",(void*)f_3232},
{"f_3150posixunix.scm",(void*)f_3150},
{"f_3154posixunix.scm",(void*)f_3154},
{"f_3159posixunix.scm",(void*)f_3159},
{"f_3175posixunix.scm",(void*)f_3175},
{"f_3087posixunix.scm",(void*)f_3087},
{"f_3145posixunix.scm",(void*)f_3145},
{"f_3091posixunix.scm",(void*)f_3091},
{"f_3094posixunix.scm",(void*)f_3094},
{"f_3126posixunix.scm",(void*)f_3126},
{"f_3097posixunix.scm",(void*)f_3097},
{"f_3102posixunix.scm",(void*)f_3102},
{"f_3116posixunix.scm",(void*)f_3116},
{"f_3084posixunix.scm",(void*)f_3084},
{"f_3009posixunix.scm",(void*)f_3009},
{"f_3067posixunix.scm",(void*)f_3067},
{"f_3016posixunix.scm",(void*)f_3016},
{"f_3026posixunix.scm",(void*)f_3026},
{"f_3030posixunix.scm",(void*)f_3030},
{"f_3039posixunix.scm",(void*)f_3039},
{"f_3043posixunix.scm",(void*)f_3043},
{"f_3053posixunix.scm",(void*)f_3053},
{"f_3034posixunix.scm",(void*)f_3034},
{"f_2989posixunix.scm",(void*)f_2989},
{"f_3001posixunix.scm",(void*)f_3001},
{"f_2997posixunix.scm",(void*)f_2997},
{"f_2975posixunix.scm",(void*)f_2975},
{"f_2987posixunix.scm",(void*)f_2987},
{"f_2983posixunix.scm",(void*)f_2983},
{"f_2915posixunix.scm",(void*)f_2915},
{"f_2961posixunix.scm",(void*)f_2961},
{"f_2922posixunix.scm",(void*)f_2922},
{"f_2932posixunix.scm",(void*)f_2932},
{"f_2936posixunix.scm",(void*)f_2936},
{"f_2940posixunix.scm",(void*)f_2940},
{"f_2944posixunix.scm",(void*)f_2944},
{"f_2948posixunix.scm",(void*)f_2948},
{"f_2892posixunix.scm",(void*)f_2892},
{"f_2902posixunix.scm",(void*)f_2902},
{"f_2869posixunix.scm",(void*)f_2869},
{"f_2879posixunix.scm",(void*)f_2879},
{"f_2831posixunix.scm",(void*)f_2831},
{"f_2864posixunix.scm",(void*)f_2864},
{"f_2835posixunix.scm",(void*)f_2835},
{"f_2842posixunix.scm",(void*)f_2842},
{"f_2846posixunix.scm",(void*)f_2846},
{"f_2850posixunix.scm",(void*)f_2850},
{"f_2854posixunix.scm",(void*)f_2854},
{"f_2858posixunix.scm",(void*)f_2858},
{"f_2813posixunix.scm",(void*)f_2813},
{"f_2798posixunix.scm",(void*)f_2798},
{"f_2792posixunix.scm",(void*)f_2792},
{"f_2760posixunix.scm",(void*)f_2760},
{"f_2766posixunix.scm",(void*)f_2766},
{"f_2736posixunix.scm",(void*)f_2736},
{"f_2754posixunix.scm",(void*)f_2754},
{"f_2743posixunix.scm",(void*)f_2743},
{"f_2718posixunix.scm",(void*)f_2718},
{"f_2728posixunix.scm",(void*)f_2728},
{"f_2705posixunix.scm",(void*)f_2705},
{"f_2696posixunix.scm",(void*)f_2696},
{"f_2649posixunix.scm",(void*)f_2649},
{"f_2653posixunix.scm",(void*)f_2653},
{"f_2629posixunix.scm",(void*)f_2629},
{"f_2633posixunix.scm",(void*)f_2633},
{"f_2639posixunix.scm",(void*)f_2639},
{"f_2643posixunix.scm",(void*)f_2643},
{"f_2609posixunix.scm",(void*)f_2609},
{"f_2613posixunix.scm",(void*)f_2613},
{"f_2619posixunix.scm",(void*)f_2619},
{"f_2623posixunix.scm",(void*)f_2623},
{"f_2585posixunix.scm",(void*)f_2585},
{"f_2589posixunix.scm",(void*)f_2589},
{"f_2600posixunix.scm",(void*)f_2600},
{"f_2604posixunix.scm",(void*)f_2604},
{"f_2594posixunix.scm",(void*)f_2594},
{"f_2561posixunix.scm",(void*)f_2561},
{"f_2565posixunix.scm",(void*)f_2565},
{"f_2576posixunix.scm",(void*)f_2576},
{"f_2580posixunix.scm",(void*)f_2580},
{"f_2570posixunix.scm",(void*)f_2570},
{"f_2545posixunix.scm",(void*)f_2545},
{"f_2549posixunix.scm",(void*)f_2549},
{"f_2552posixunix.scm",(void*)f_2552},
{"f_2509posixunix.scm",(void*)f_2509},
{"f_2540posixunix.scm",(void*)f_2540},
{"f_2530posixunix.scm",(void*)f_2530},
{"f_2523posixunix.scm",(void*)f_2523},
{"f_2473posixunix.scm",(void*)f_2473},
{"f_2504posixunix.scm",(void*)f_2504},
{"f_2494posixunix.scm",(void*)f_2494},
{"f_2487posixunix.scm",(void*)f_2487},
{"f_2458posixunix.scm",(void*)f_2458},
{"f_2471posixunix.scm",(void*)f_2471},
{"f_2452posixunix.scm",(void*)f_2452},
{"f_2440posixunix.scm",(void*)f_2440},
{"f_2404posixunix.scm",(void*)f_2404},
{"f_2417posixunix.scm",(void*)f_2417},
{"f_2381posixunix.scm",(void*)f_2381},
{"f_2402posixunix.scm",(void*)f_2402},
{"f_2388posixunix.scm",(void*)f_2388},
{"f_2227posixunix.scm",(void*)f_2227},
{"f_2332posixunix.scm",(void*)f_2332},
{"f_2340posixunix.scm",(void*)f_2340},
{"f_2327posixunix.scm",(void*)f_2327},
{"f_2229posixunix.scm",(void*)f_2229},
{"f_2236posixunix.scm",(void*)f_2236},
{"f_2239posixunix.scm",(void*)f_2239},
{"f_2242posixunix.scm",(void*)f_2242},
{"f_2326posixunix.scm",(void*)f_2326},
{"f_2246posixunix.scm",(void*)f_2246},
{"f_2260posixunix.scm",(void*)f_2260},
{"f_2270posixunix.scm",(void*)f_2270},
{"f_2273posixunix.scm",(void*)f_2273},
{"f_2276posixunix.scm",(void*)f_2276},
{"f_2282posixunix.scm",(void*)f_2282},
{"f_2292posixunix.scm",(void*)f_2292},
{"f_2203posixunix.scm",(void*)f_2203},
{"f_2225posixunix.scm",(void*)f_2225},
{"f_2221posixunix.scm",(void*)f_2221},
{"f_2179posixunix.scm",(void*)f_2179},
{"f_2201posixunix.scm",(void*)f_2201},
{"f_2197posixunix.scm",(void*)f_2197},
{"f_2155posixunix.scm",(void*)f_2155},
{"f_2177posixunix.scm",(void*)f_2177},
{"f_2173posixunix.scm",(void*)f_2173},
{"f_2093posixunix.scm",(void*)f_2093},
{"f_2106posixunix.scm",(void*)f_2106},
{"f_2118posixunix.scm",(void*)f_2118},
{"f_2112posixunix.scm",(void*)f_2112},
{"f_2084posixunix.scm",(void*)f_2084},
{"f_2091posixunix.scm",(void*)f_2091},
{"f_2075posixunix.scm",(void*)f_2075},
{"f_2082posixunix.scm",(void*)f_2082},
{"f_2069posixunix.scm",(void*)f_2069},
{"f_2073posixunix.scm",(void*)f_2073},
{"f_2063posixunix.scm",(void*)f_2063},
{"f_2067posixunix.scm",(void*)f_2067},
{"f_2057posixunix.scm",(void*)f_2057},
{"f_2061posixunix.scm",(void*)f_2061},
{"f_2051posixunix.scm",(void*)f_2051},
{"f_2055posixunix.scm",(void*)f_2055},
{"f_2045posixunix.scm",(void*)f_2045},
{"f_2049posixunix.scm",(void*)f_2049},
{"f_2039posixunix.scm",(void*)f_2039},
{"f_2043posixunix.scm",(void*)f_2043},
{"f_2014posixunix.scm",(void*)f_2014},
{"f_2018posixunix.scm",(void*)f_2018},
{"f_1977posixunix.scm",(void*)f_1977},
{"f_2009posixunix.scm",(void*)f_2009},
{"f_2002posixunix.scm",(void*)f_2002},
{"f_1981posixunix.scm",(void*)f_1981},
{"f_1785posixunix.scm",(void*)f_1785},
{"f_1958posixunix.scm",(void*)f_1958},
{"f_1801posixunix.scm",(void*)f_1801},
{"f_1932posixunix.scm",(void*)f_1932},
{"f_1807posixunix.scm",(void*)f_1807},
{"f_1810posixunix.scm",(void*)f_1810},
{"f_1892posixunix.scm",(void*)f_1892},
{"f_1890posixunix.scm",(void*)f_1890},
{"f_1849posixunix.scm",(void*)f_1849},
{"f_1867posixunix.scm",(void*)f_1867},
{"f_1865posixunix.scm",(void*)f_1865},
{"f_1853posixunix.scm",(void*)f_1853},
{"f_1783posixunix.scm",(void*)f_1783},
{"f_1781posixunix.scm",(void*)f_1781},
{"f_1779posixunix.scm",(void*)f_1779},
{"f_1747posixunix.scm",(void*)f_1747},
{"f_1754posixunix.scm",(void*)f_1754},
{"f_1760posixunix.scm",(void*)f_1760},
{"f_1767posixunix.scm",(void*)f_1767},
{"f_1708posixunix.scm",(void*)f_1708},
{"f_1715posixunix.scm",(void*)f_1715},
{"f_1724posixunix.scm",(void*)f_1724},
{"f_1666posixunix.scm",(void*)f_1666},
{"f_1676posixunix.scm",(void*)f_1676},
{"f_1679posixunix.scm",(void*)f_1679},
{"f_1682posixunix.scm",(void*)f_1682},
{"f_1651posixunix.scm",(void*)f_1651},
{"f_1613posixunix.scm",(void*)f_1613},
{"f_1643posixunix.scm",(void*)f_1643},
{"f_1630posixunix.scm",(void*)f_1630},
{"f_1633posixunix.scm",(void*)f_1633},
{"f_1574posixunix.scm",(void*)f_1574},
{"f_1533posixunix.scm",(void*)f_1533},
{"f_1530posixunix.scm",(void*)f_1530},
{"f_1512posixunix.scm",(void*)f_1512},
{"f_1516posixunix.scm",(void*)f_1516},
{"f_1527posixunix.scm",(void*)f_1527},
{"f_1523posixunix.scm",(void*)f_1523},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
