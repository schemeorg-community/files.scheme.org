/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:31
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: c-backend.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[812];
static double C_possibly_force_alignment;


/* from getsize in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1048(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1048(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

/* from getbits in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1044(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1044(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8762)
static void C_ccall f_8762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_ccall f_8758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1138)
static void C_ccall f_1138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8750)
static void C_ccall f_8750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8577)
static void C_fcall f_8577(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8710)
static void C_ccall f_8710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8680)
static void C_ccall f_8680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8641)
static void C_ccall f_8641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8527)
static void C_ccall f_8527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8474)
static C_word C_fcall f_8474(C_word *a,C_word t0);
C_noret_decl(f_8471)
static C_word C_fcall f_8471(C_word t0);
C_noret_decl(f_8468)
static C_word C_fcall f_8468(C_word t0);
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7778)
static void C_fcall f_7778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7859)
static void C_ccall f_7859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8294)
static void C_fcall f_8294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8236)
static void C_fcall f_8236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8200)
static void C_fcall f_8200(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8165)
static void C_fcall f_8165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8117)
static void C_fcall f_8117(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8069)
static void C_fcall f_8069(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8021)
static void C_fcall f_8021(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_fcall f_7986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_fcall f_7950(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7914)
static void C_fcall f_7914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_fcall f_7892(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7887)
static void C_fcall f_7887(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7882)
static void C_fcall f_7882(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_fcall f_7693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6858)
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6888)
static void C_fcall f_6888(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6915)
static void C_fcall f_6915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7110)
static void C_fcall f_7110(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7119)
static void C_fcall f_7119(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7516)
static void C_fcall f_7516(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_fcall f_7483(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7493)
static void C_ccall f_7493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7451)
static void C_fcall f_7451(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_fcall f_7416(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7346)
static void C_fcall f_7346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7301)
static void C_fcall f_7301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7269)
static void C_fcall f_7269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_fcall f_7237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7205)
static void C_fcall f_7205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7173)
static void C_fcall f_7173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7151)
static void C_fcall f_7151(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6860)
static void C_fcall f_6860(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5641)
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5718)
static void C_fcall f_5718(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_fcall f_5820(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5853)
static void C_fcall f_5853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_fcall f_5949(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6581)
static void C_fcall f_6581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_fcall f_6601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6614)
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6612)
static void C_ccall f_6612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6608)
static void C_ccall f_6608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6535)
static void C_fcall f_6535(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6548)
static void C_ccall f_6548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_fcall f_6485(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6435)
static void C_fcall f_6435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6396)
static void C_fcall f_6396(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6406)
static void C_ccall f_6406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6357)
static void C_fcall f_6357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6367)
static void C_ccall f_6367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_fcall f_6318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6279)
static void C_fcall f_6279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6289)
static void C_ccall f_6289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6219)
static void C_fcall f_6219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6236)
static void C_ccall f_6236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6246)
static void C_ccall f_6246(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6240)
static void C_ccall f_6240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6232)
static void C_ccall f_6232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6180)
static void C_fcall f_6180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6190)
static void C_ccall f_6190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_fcall f_6108(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6072)
static void C_fcall f_6072(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6036)
static void C_fcall f_6036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6010)
static void C_fcall f_6010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6018)
static void C_ccall f_6018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_fcall f_6001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6009)
static void C_ccall f_6009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5996)
static void C_fcall f_5996(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5648)
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5643)
static void C_fcall f_5643(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5576)
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5580)
static void C_ccall f_5580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5583)
static void C_ccall f_5583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5589)
static void C_ccall f_5589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5639)
static void C_ccall f_5639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5598)
static void C_ccall f_5598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5627)
static void C_ccall f_5627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_ccall f_5610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5155)
static void C_ccall f_5155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5158)
static void C_ccall f_5158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5164)
static void C_ccall f_5164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5511)
static void C_ccall f_5511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5529)
static void C_ccall f_5529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5532)
static void C_ccall f_5532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5538)
static void C_ccall f_5538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5182)
static void C_fcall f_5182(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5191)
static void C_fcall f_5191(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_fcall f_5203(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5215)
static void C_fcall f_5215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4912)
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4918)
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4922)
static void C_ccall f_4922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4925)
static void C_ccall f_4925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5143)
static void C_ccall f_5143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_ccall f_4946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4952)
static void C_ccall f_4952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4955)
static void C_ccall f_4955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4958)
static void C_ccall f_4958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4961)
static void C_ccall f_4961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5132)
static void C_ccall f_5132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4967)
static void C_ccall f_4967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4985)
static void C_ccall f_4985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5110)
static void C_ccall f_5110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5080)
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5088)
static void C_ccall f_5088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5096)
static void C_ccall f_5096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4991)
static void C_ccall f_4991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5062)
static void C_ccall f_5062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5033)
static void C_ccall f_5033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4994)
static void C_ccall f_4994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4904)
static void C_ccall f_4904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4852)
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4859)
static void C_fcall f_4859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4879)
static void C_ccall f_4879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4731)
static void C_fcall f_4731(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4760)
static void C_fcall f_4760(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4770)
static void C_ccall f_4770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_fcall f_4763(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4747)
static void C_fcall f_4747(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4649)
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4667)
static void C_fcall f_4667(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4683)
static void C_ccall f_4683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4686)
static void C_ccall f_4686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4656)
static void C_ccall f_4656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4659)
static void C_ccall f_4659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_4616)
static void C_ccall f_4616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4632)
static void C_ccall f_4632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4638)
static void C_ccall f_4638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3869)
static void C_fcall f_3869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4613)
static void C_ccall f_4613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_fcall f_3897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3915)
static void C_ccall f_3915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_ccall f_3918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_ccall f_3930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4582)
static void C_ccall f_4582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4543)
static void C_ccall f_4543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4546)
static void C_ccall f_4546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4549)
static void C_ccall f_4549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4565)
static void C_ccall f_4565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4568)
static void C_ccall f_4568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3942)
static void C_ccall f_3942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4515)
static void C_fcall f_4515(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_fcall f_3963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_ccall f_3966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4477)
static void C_fcall f_4477(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4487)
static void C_ccall f_4487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_fcall f_4420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4435)
static void C_ccall f_4435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4441)
static void C_fcall f_4441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4342)
static void C_ccall f_4342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4351)
static void C_fcall f_4351(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_ccall f_4354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4360)
static void C_fcall f_4360(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4281)
static void C_ccall f_4281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4287)
static void C_ccall f_4287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4305)
static void C_fcall f_4305(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4293)
static void C_ccall f_4293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4264)
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_ccall f_4195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4201)
static void C_ccall f_4201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4204)
static void C_ccall f_4204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4207)
static void C_ccall f_4207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4210)
static void C_ccall f_4210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_fcall f_3995(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4130)
static void C_ccall f_4130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4133)
static void C_ccall f_4133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4136)
static void C_ccall f_4136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4025)
static void C_ccall f_4025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_ccall f_4028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4034)
static void C_ccall f_4034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3975)
static void C_ccall f_3975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3985)
static void C_ccall f_3985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3506)
static void C_ccall f_3506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3580)
static void C_ccall f_3580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3598)
static void C_ccall f_3598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3605)
static void C_ccall f_3605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3537)
static void C_ccall f_3537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_fcall f_3456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3462)
static void C_fcall f_3462(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3658)
static void C_fcall f_3658(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3778)
static void C_ccall f_3778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_fcall f_3665(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3727)
static void C_ccall f_3727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_fcall f_3493(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3795)
static void C_fcall f_3795(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3811)
static void C_fcall f_3811(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_fcall f_3857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3867)
static void C_ccall f_3867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_fcall f_3170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3341)
static void C_ccall f_3341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3350)
static void C_ccall f_3350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3353)
static void C_ccall f_3353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_ccall f_3454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_fcall f_3356(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3359)
static void C_fcall f_3359(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3365)
static void C_ccall f_3365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_fcall f_3405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3419)
static void C_ccall f_3419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3371)
static void C_ccall f_3371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3380)
static void C_ccall f_3380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3393)
static void C_ccall f_3393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3289)
static void C_ccall f_3289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3312)
static void C_ccall f_3312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3315)
static void C_ccall f_3315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3318)
static void C_ccall f_3318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3324)
static void C_ccall f_3324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3306)
static void C_ccall f_3306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_ccall f_3295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3302)
static void C_ccall f_3302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_fcall f_3209(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3215)
static void C_ccall f_3215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3227)
static void C_ccall f_3227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3233)
static void C_ccall f_3233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3236)
static void C_ccall f_3236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3173)
static void C_fcall f_3173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_fcall f_3186(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3177)
static void C_ccall f_3177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_fcall f_2919(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2923)
static void C_ccall f_2923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2954)
static void C_ccall f_2954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2957)
static void C_fcall f_2957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2960)
static void C_ccall f_2960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2963)
static void C_ccall f_2963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2969)
static void C_ccall f_2969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2972)
static void C_ccall f_2972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2975)
static void C_ccall f_2975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3146)
static void C_ccall f_3146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_fcall f_2978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_ccall f_2984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3077)
static void C_ccall f_3077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2987)
static void C_ccall f_2987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2990)
static void C_ccall f_2990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_fcall f_3043(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2996)
static void C_ccall f_2996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3031)
static void C_ccall f_3031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3014)
static void C_ccall f_3014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2945)
static void C_ccall f_2945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2938)
static void C_ccall f_2938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_fcall f_2778(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_ccall f_2818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2851)
static void C_ccall f_2851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2821)
static void C_ccall f_2821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2612)
static void C_fcall f_2612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2770)
static void C_ccall f_2770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2638)
static void C_fcall f_2638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2715)
static void C_ccall f_2715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_ccall f_2719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2745)
static void C_ccall f_2745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2737)
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2735)
static void C_ccall f_2735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2731)
static void C_ccall f_2731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2656)
static void C_ccall f_2656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2704)
static void C_ccall f_2704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2671)
static void C_ccall f_2671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2674)
static void C_ccall f_2674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_fcall f_2615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2629)
static void C_ccall f_2629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1185)
static void C_fcall f_1185(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2580)
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1188)
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2545)
static void C_ccall f_2545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2554)
static void C_ccall f_2554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_ccall f_2468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2481)
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_ccall f_2507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2510)
static void C_ccall f_2510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2491)
static void C_ccall f_2491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_ccall f_2494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2431)
static void C_ccall f_2431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2409)
static void C_ccall f_2409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2398)
static void C_ccall f_2398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2361)
static void C_ccall f_2361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_ccall f_2364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2270)
static void C_ccall f_2270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_ccall f_2194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2127)
static void C_ccall f_2127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2114)
static void C_ccall f_2114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2089)
static void C_ccall f_2089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2105)
static void C_ccall f_2105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2092)
static void C_ccall f_2092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1832)
static void C_fcall f_1832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_fcall f_1838(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2022)
static void C_ccall f_2022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_fcall f_1989(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_ccall f_1977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1884)
static void C_ccall f_1884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1856)
static void C_ccall f_1856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1786)
static void C_ccall f_1786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1742)
static void C_ccall f_1742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1665)
static void C_ccall f_1665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1636)
static void C_ccall f_1636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1500)
static void C_ccall f_1500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1509)
static void C_ccall f_1509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1470)
static void C_ccall f_1470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1324)
static void C_ccall f_1324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_fcall f_1143(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_8577)
static void C_fcall trf_8577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8577(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8577(t0,t1);}

C_noret_decl(trf_7778)
static void C_fcall trf_7778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7778(t0,t1);}

C_noret_decl(trf_8294)
static void C_fcall trf_8294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8294(t0,t1);}

C_noret_decl(trf_8236)
static void C_fcall trf_8236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8236(t0,t1);}

C_noret_decl(trf_8200)
static void C_fcall trf_8200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8200(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8200(t0,t1);}

C_noret_decl(trf_8165)
static void C_fcall trf_8165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8165(t0,t1);}

C_noret_decl(trf_8117)
static void C_fcall trf_8117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8117(t0,t1);}

C_noret_decl(trf_8069)
static void C_fcall trf_8069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8069(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8069(t0,t1);}

C_noret_decl(trf_8021)
static void C_fcall trf_8021(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8021(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8021(t0,t1);}

C_noret_decl(trf_7986)
static void C_fcall trf_7986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7986(t0,t1);}

C_noret_decl(trf_7950)
static void C_fcall trf_7950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7950(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7950(t0,t1);}

C_noret_decl(trf_7914)
static void C_fcall trf_7914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7914(t0,t1);}

C_noret_decl(trf_7892)
static void C_fcall trf_7892(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7892(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7892(t0,t1);}

C_noret_decl(trf_7887)
static void C_fcall trf_7887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7887(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7887(t0,t1);}

C_noret_decl(trf_7882)
static void C_fcall trf_7882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7882(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7882(t0,t1);}

C_noret_decl(trf_7693)
static void C_fcall trf_7693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7693(t0,t1);}

C_noret_decl(trf_6888)
static void C_fcall trf_6888(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6888(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6888(t0,t1);}

C_noret_decl(trf_6915)
static void C_fcall trf_6915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6915(t0,t1);}

C_noret_decl(trf_7110)
static void C_fcall trf_7110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7110(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7110(t0,t1);}

C_noret_decl(trf_7119)
static void C_fcall trf_7119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7119(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7119(t0,t1);}

C_noret_decl(trf_7516)
static void C_fcall trf_7516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7516(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7516(t0,t1);}

C_noret_decl(trf_7483)
static void C_fcall trf_7483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7483(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7483(t0,t1);}

C_noret_decl(trf_7451)
static void C_fcall trf_7451(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7451(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7451(t0,t1);}

C_noret_decl(trf_7416)
static void C_fcall trf_7416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7416(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7416(t0,t1);}

C_noret_decl(trf_7346)
static void C_fcall trf_7346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7346(t0,t1);}

C_noret_decl(trf_7301)
static void C_fcall trf_7301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7301(t0,t1);}

C_noret_decl(trf_7269)
static void C_fcall trf_7269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7269(t0,t1);}

C_noret_decl(trf_7237)
static void C_fcall trf_7237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7237(t0,t1);}

C_noret_decl(trf_7205)
static void C_fcall trf_7205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7205(t0,t1);}

C_noret_decl(trf_7173)
static void C_fcall trf_7173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7173(t0,t1);}

C_noret_decl(trf_7151)
static void C_fcall trf_7151(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7151(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7151(t0,t1);}

C_noret_decl(trf_6860)
static void C_fcall trf_6860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6860(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6860(t0,t1);}

C_noret_decl(trf_5718)
static void C_fcall trf_5718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5718(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5718(t0,t1);}

C_noret_decl(trf_5820)
static void C_fcall trf_5820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5820(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5820(t0,t1);}

C_noret_decl(trf_5853)
static void C_fcall trf_5853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5853(t0,t1);}

C_noret_decl(trf_5949)
static void C_fcall trf_5949(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5949(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5949(t0,t1);}

C_noret_decl(trf_6581)
static void C_fcall trf_6581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6581(t0,t1);}

C_noret_decl(trf_6601)
static void C_fcall trf_6601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6601(t0,t1);}

C_noret_decl(trf_6535)
static void C_fcall trf_6535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6535(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6535(t0,t1);}

C_noret_decl(trf_6485)
static void C_fcall trf_6485(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6485(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6485(t0,t1);}

C_noret_decl(trf_6435)
static void C_fcall trf_6435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6435(t0,t1);}

C_noret_decl(trf_6396)
static void C_fcall trf_6396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6396(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6396(t0,t1);}

C_noret_decl(trf_6357)
static void C_fcall trf_6357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6357(t0,t1);}

C_noret_decl(trf_6318)
static void C_fcall trf_6318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6318(t0,t1);}

C_noret_decl(trf_6279)
static void C_fcall trf_6279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6279(t0,t1);}

C_noret_decl(trf_6219)
static void C_fcall trf_6219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6219(t0,t1);}

C_noret_decl(trf_6180)
static void C_fcall trf_6180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6180(t0,t1);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6144(t0,t1);}

C_noret_decl(trf_6108)
static void C_fcall trf_6108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6108(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6108(t0,t1);}

C_noret_decl(trf_6072)
static void C_fcall trf_6072(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6072(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6072(t0,t1);}

C_noret_decl(trf_6036)
static void C_fcall trf_6036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6036(t0,t1);}

C_noret_decl(trf_6010)
static void C_fcall trf_6010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6010(t0,t1,t2);}

C_noret_decl(trf_6001)
static void C_fcall trf_6001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6001(t0,t1,t2);}

C_noret_decl(trf_5996)
static void C_fcall trf_5996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5996(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5996(t0,t1);}

C_noret_decl(trf_5648)
static void C_fcall trf_5648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5648(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5648(t0,t1,t2);}

C_noret_decl(trf_5643)
static void C_fcall trf_5643(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5643(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5643(t0,t1);}

C_noret_decl(trf_5182)
static void C_fcall trf_5182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5182(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5182(t0,t1);}

C_noret_decl(trf_5191)
static void C_fcall trf_5191(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5191(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5191(t0,t1);}

C_noret_decl(trf_5203)
static void C_fcall trf_5203(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5203(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5203(t0,t1);}

C_noret_decl(trf_5215)
static void C_fcall trf_5215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5215(t0,t1);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5255(t0,t1);}

C_noret_decl(trf_4859)
static void C_fcall trf_4859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4859(t0,t1);}

C_noret_decl(trf_4731)
static void C_fcall trf_4731(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4731(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4731(t0,t1,t2);}

C_noret_decl(trf_4760)
static void C_fcall trf_4760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4760(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4760(t0,t1);}

C_noret_decl(trf_4763)
static void C_fcall trf_4763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4763(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4763(t0,t1);}

C_noret_decl(trf_4747)
static void C_fcall trf_4747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4747(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4747(t0,t1);}

C_noret_decl(trf_4667)
static void C_fcall trf_4667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4667(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4667(t0,t1,t2);}

C_noret_decl(trf_3869)
static void C_fcall trf_3869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3869(t0,t1);}

C_noret_decl(trf_3897)
static void C_fcall trf_3897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3897(t0,t1);}

C_noret_decl(trf_4515)
static void C_fcall trf_4515(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4515(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4515(t0,t1);}

C_noret_decl(trf_3963)
static void C_fcall trf_3963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3963(t0,t1);}

C_noret_decl(trf_4477)
static void C_fcall trf_4477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4477(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4477(t0,t1,t2,t3);}

C_noret_decl(trf_4420)
static void C_fcall trf_4420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4420(t0,t1);}

C_noret_decl(trf_4441)
static void C_fcall trf_4441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4441(t0,t1);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4384(t0,t1);}

C_noret_decl(trf_4351)
static void C_fcall trf_4351(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4351(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4351(t0,t1);}

C_noret_decl(trf_4360)
static void C_fcall trf_4360(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4360(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4360(t0,t1);}

C_noret_decl(trf_4305)
static void C_fcall trf_4305(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4305(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4305(t0,t1);}

C_noret_decl(trf_3995)
static void C_fcall trf_3995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3995(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3995(t0,t1);}

C_noret_decl(trf_4055)
static void C_fcall trf_4055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4055(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4055(t0,t1,t2,t3);}

C_noret_decl(trf_3627)
static void C_fcall trf_3627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3627(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3627(t0,t1,t2,t3);}

C_noret_decl(trf_3456)
static void C_fcall trf_3456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3456(t0,t1);}

C_noret_decl(trf_3462)
static void C_fcall trf_3462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3462(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3462(t0,t1,t2,t3);}

C_noret_decl(trf_3658)
static void C_fcall trf_3658(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3658(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3658(t0,t1,t2,t3);}

C_noret_decl(trf_3665)
static void C_fcall trf_3665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3665(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3665(t0,t1);}

C_noret_decl(trf_3493)
static void C_fcall trf_3493(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3493(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3493(t0,t1);}

C_noret_decl(trf_3780)
static void C_fcall trf_3780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3780(t0,t1,t2);}

C_noret_decl(trf_3795)
static void C_fcall trf_3795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3795(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3795(t0,t1,t2,t3);}

C_noret_decl(trf_3811)
static void C_fcall trf_3811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3811(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3811(t0,t1);}

C_noret_decl(trf_3857)
static void C_fcall trf_3857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3857(t0,t1,t2,t3);}

C_noret_decl(trf_3170)
static void C_fcall trf_3170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3170(t0,t1);}

C_noret_decl(trf_3356)
static void C_fcall trf_3356(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3356(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3356(t0,t1);}

C_noret_decl(trf_3359)
static void C_fcall trf_3359(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3359(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3359(t0,t1);}

C_noret_decl(trf_3405)
static void C_fcall trf_3405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3405(t0,t1);}

C_noret_decl(trf_3209)
static void C_fcall trf_3209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3209(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3209(t0,t1,t2);}

C_noret_decl(trf_3173)
static void C_fcall trf_3173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3173(t0,t1);}

C_noret_decl(trf_3186)
static void C_fcall trf_3186(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3186(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3186(t0,t1,t2,t3);}

C_noret_decl(trf_2919)
static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2919(t0,t1);}

C_noret_decl(trf_2957)
static void C_fcall trf_2957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2957(t0,t1);}

C_noret_decl(trf_2978)
static void C_fcall trf_2978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2978(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2978(t0,t1);}

C_noret_decl(trf_3043)
static void C_fcall trf_3043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3043(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3043(t0,t1);}

C_noret_decl(trf_2778)
static void C_fcall trf_2778(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2778(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2778(t0,t1);}

C_noret_decl(trf_2799)
static void C_fcall trf_2799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2799(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2799(t0,t1,t2,t3);}

C_noret_decl(trf_2860)
static void C_fcall trf_2860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2860(t0,t1,t2);}

C_noret_decl(trf_2841)
static void C_fcall trf_2841(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2841(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2841(t0,t1,t2);}

C_noret_decl(trf_2612)
static void C_fcall trf_2612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2612(t0,t1);}

C_noret_decl(trf_2638)
static void C_fcall trf_2638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2638(t0,t1);}

C_noret_decl(trf_2615)
static void C_fcall trf_2615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2615(t0,t1);}

C_noret_decl(trf_1185)
static void C_fcall trf_1185(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1185(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1185(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2580)
static void C_fcall trf_2580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2580(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2580(t0,t1,t2,t3);}

C_noret_decl(trf_1188)
static void C_fcall trf_1188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1188(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1188(t0,t1,t2,t3);}

C_noret_decl(trf_2481)
static void C_fcall trf_2481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2481(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2481(t0,t1,t2,t3);}

C_noret_decl(trf_1832)
static void C_fcall trf_1832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1832(t0,t1);}

C_noret_decl(trf_1838)
static void C_fcall trf_1838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1838(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1838(t0,t1);}

C_noret_decl(trf_1989)
static void C_fcall trf_1989(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1989(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1989(t0,t1);}

C_noret_decl(trf_1370)
static void C_fcall trf_1370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1370(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1370(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1143)
static void C_fcall trf_1143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1143(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1143(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2336)){
C_save(t1);
C_rereclaim2(2336*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,812);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],15,"\010compileroutput");
lf[2]=C_h_intern(&lf[2],12,"\010compilergen");
lf[3]=C_h_intern(&lf[3],7,"newline");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_h_intern(&lf[5],12,"\003sysfor-each");
lf[6]=C_h_intern(&lf[6],17,"\010compilergen-list");
lf[7]=C_h_intern(&lf[7],11,"intersperse");
lf[8]=C_h_intern(&lf[8],18,"\010compilerunique-id");
lf[9]=C_h_intern(&lf[9],22,"\010compilergenerate-code");
lf[10]=C_h_intern(&lf[10],13,"\010compilerbomb");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[12]=C_h_intern(&lf[12],17,"lambda-literal-id");
lf[13]=C_h_intern(&lf[13],4,"find");
lf[14]=C_h_intern(&lf[14],14,"\004coreimmediate");
lf[15]=C_h_intern(&lf[15],4,"bool");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[18]=C_h_intern(&lf[18],4,"char");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[20]=C_h_intern(&lf[20],3,"nil");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[22]=C_h_intern(&lf[22],3,"fix");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[24]=C_h_intern(&lf[24],3,"eof");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[27]=C_h_intern(&lf[27],12,"\004coreliteral");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[31]=C_h_intern(&lf[31],2,"if");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[35]=C_h_intern(&lf[35],9,"\004coreproc");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[37]=C_h_intern(&lf[37],9,"\004corebind");
lf[38]=C_h_intern(&lf[38],8,"\004coreref");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[41]=C_h_intern(&lf[41],10,"\004coreunbox");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[44]=C_h_intern(&lf[44],13,"\004coreupdate_i");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[46]=C_h_intern(&lf[46],11,"\004coreupdate");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[50]=C_h_intern(&lf[50],16,"\004coreupdatebox_i");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[53]=C_h_intern(&lf[53],14,"\004coreupdatebox");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[56]=C_h_intern(&lf[56],12,"\004coreclosure");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[61]=C_h_intern(&lf[61],8,"for-each");
lf[62]=C_h_intern(&lf[62],4,"iota");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[64]=C_h_intern(&lf[64],8,"\004corebox");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[67]=C_h_intern(&lf[67],10,"\004corelocal");
lf[68]=C_h_intern(&lf[68],13,"\004coresetlocal");
lf[69]=C_h_intern(&lf[69],11,"\004coreglobal");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[74]=C_h_intern(&lf[74],21,"\010compilerc-ify-string");
lf[75]=C_h_intern(&lf[75],14,"symbol->string");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\016C_retrieve(lf[");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[80]=C_h_intern(&lf[80],14,"\004coresetglobal");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1,");
lf[85]=C_h_intern(&lf[85],16,"\004coresetglobal_i");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\004],0,");
lf[90]=C_h_intern(&lf[90],14,"\004coreundefined");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[92]=C_h_intern(&lf[92],9,"\004corecall");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[98]=C_h_intern(&lf[98],26,"lambda-literal-temporaries");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_h_intern(&lf[100],22,"lambda-literal-looping");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[104]=C_h_intern(&lf[104],6,"unsafe");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\021C_retrieve_proc(t");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[109]=C_h_intern(&lf[109],19,"no-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[112]=C_h_intern(&lf[112],24,"\010compileremit-trace-info");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[115]=C_h_intern(&lf[115],16,"string-translate");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[118]=C_h_intern(&lf[118],8,"->string");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[121]=C_h_intern(&lf[121],17,"string-translate*");
lf[122]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[123]=C_h_intern(&lf[123],27,"lambda-literal-closure-size");
lf[124]=C_h_intern(&lf[124],28,"\010compilersource-info->string");
lf[125]=C_h_intern(&lf[125],12,"\004corerecurse");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[129]=C_h_intern(&lf[129],16,"\004coredirect_call");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[131]=C_h_intern(&lf[131],13,"\004corecallunit");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[136]=C_h_intern(&lf[136],11,"\004corereturn");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[139]=C_h_intern(&lf[139],11,"\004coreinline");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[141]=C_h_intern(&lf[141],20,"\004coreinline_allocate");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[144]=C_h_intern(&lf[144],15,"\004coreinline_ref");
lf[145]=C_h_intern(&lf[145],34,"\010compilerforeign-result-conversion");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[147]=C_h_intern(&lf[147],18,"\004coreinline_update");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[150]=C_h_intern(&lf[150],36,"\010compilerforeign-argument-conversion");
lf[151]=C_h_intern(&lf[151],33,"\010compilerforeign-type-declaration");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[153]=C_h_intern(&lf[153],19,"\004coreinline_loc_ref");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[159]=C_h_intern(&lf[159],22,"\004coreinline_loc_update");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[165]=C_h_intern(&lf[165],11,"\004coreswitch");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[170]=C_h_intern(&lf[170],9,"\004corecond");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[174]=C_h_intern(&lf[174],13,"pair-for-each");
lf[175]=C_h_intern(&lf[175],13,"string-append");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[177]=C_h_intern(&lf[177],30,"\010compilerexternal-protos-first");
lf[178]=C_h_intern(&lf[178],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[179]=C_h_intern(&lf[179],22,"foreign-callback-stubs");
lf[180]=C_h_intern(&lf[180],29,"\010compilerforeign-declarations");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[183]=C_h_intern(&lf[183],28,"\010compilertarget-include-file");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[185]=C_h_intern(&lf[185],18,"\010compilerunit-name");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[187]=C_h_intern(&lf[187],19,"\010compilerused-units");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[189]=C_h_intern(&lf[189],27,"\010compilercompiler-arguments");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[195]=C_h_intern(&lf[195],18,"string-intersperse");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[199]=C_h_intern(&lf[199],7,"\003sysmap");
lf[200]=C_h_intern(&lf[200],12,"string-split");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[202]=C_h_intern(&lf[202],15,"chicken-version");
lf[203]=C_h_intern(&lf[203],15,"\003sysmatch-error");
lf[204]=C_h_intern(&lf[204],18,"\003sysdecode-seconds");
lf[205]=C_h_intern(&lf[205],15,"current-seconds");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[210]=C_h_intern(&lf[210],23,"\003syslambda-info->string");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[220]=C_h_intern(&lf[220],9,"make-list");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[224]=C_h_intern(&lf[224],4,"none");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[235]=C_h_intern(&lf[235],8,"toplevel");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[238]=C_h_intern(&lf[238],27,"\010compileremit-unsafe-marker");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\0001C_externexport void C_dynamic_and_unsafe(void) {}");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[251]=C_h_intern(&lf[251],21,"small-parameter-limit");
lf[252]=C_h_intern(&lf[252],11,"lset-adjoin");
lf[253]=C_h_intern(&lf[253],1,"=");
lf[254]=C_h_intern(&lf[254],32,"lambda-literal-callee-signatures");
lf[255]=C_h_intern(&lf[255],24,"lambda-literal-allocated");
lf[256]=C_h_intern(&lf[256],21,"lambda-literal-direct");
lf[257]=C_h_intern(&lf[257],33,"lambda-literal-rest-argument-mode");
lf[258]=C_h_intern(&lf[258],28,"lambda-literal-rest-argument");
lf[259]=C_h_intern(&lf[259],27,"\010compilermake-variable-list");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[261]=C_h_intern(&lf[261],27,"lambda-literal-customizable");
lf[262]=C_h_intern(&lf[262],29,"lambda-literal-argument-count");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[269]=C_h_intern(&lf[269],27,"\010compilermake-argument-list");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[309]=C_h_intern(&lf[309],6,"vector");
lf[310]=C_h_intern(&lf[310],23,"lambda-literal-external");
lf[311]=C_h_intern(&lf[311],14,"\003syscopy-bytes");
lf[312]=C_h_intern(&lf[312],11,"make-string");
lf[313]=C_h_intern(&lf[313],6,"modulo");
lf[314]=C_h_intern(&lf[314],3,"fx/");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[328]=C_h_intern(&lf[328],23,"\010compilerencode-literal");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[330]=C_h_intern(&lf[330],32,"\010compilerblock-variable-literal\077");
lf[331]=C_h_intern(&lf[331],20,"\010compilerbig-fixnum\077");
lf[332]=C_h_intern(&lf[332],7,"sprintf");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\006lf[~s]");
lf[334]=C_h_intern(&lf[334],25,"\010compilerwords-per-flonum");
lf[335]=C_h_intern(&lf[335],6,"reduce");
lf[336]=C_h_intern(&lf[336],1,"+");
lf[337]=C_h_intern(&lf[337],12,"vector->list");
lf[338]=C_h_intern(&lf[338],14,"\010compilerwords");
lf[339]=C_h_intern(&lf[339],15,"\003sysbytevector\077");
lf[340]=C_h_intern(&lf[340],19,"\010compilerimmediate\077");
lf[341]=C_h_intern(&lf[341],19,"lambda-literal-body");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[352]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[354]=C_h_intern(&lf[354],4,"list");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000*=C_restore_rest_vector(a,C_rest_count(0));");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[371]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[373]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[393]=C_h_intern(&lf[393],26,"\010compilertarget-stack-size");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[396]=C_h_intern(&lf[396],30,"\010compilertarget-heap-shrinkage");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[398]=C_h_intern(&lf[398],27,"\010compilertarget-heap-growth");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[400]=C_h_intern(&lf[400],33,"\010compilertarget-initial-heap-size");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[403]=C_h_intern(&lf[403],25,"\010compilertarget-heap-size");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[407]=C_h_intern(&lf[407],40,"\010compilerdisable-stack-overflow-checking");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[413]=C_h_intern(&lf[413],4,"fold");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[416]=C_h_intern(&lf[416],28,"\010compilerinsert-timer-checks");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[421]=C_h_intern(&lf[421],14,"no-argc-checks");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[430]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[433]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[437]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[443]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[446]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[451]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[468]=C_h_intern(&lf[468],16,"\010compilercleanup");
lf[469]=C_h_intern(&lf[469],18,"\010compilerdebugging");
lf[470]=C_h_intern(&lf[470],1,"o");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[476]=C_h_intern(&lf[476],18,"\010compilerreal-name");
lf[477]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[478]=C_h_intern(&lf[478],25,"emit-procedure-table-info");
lf[479]=C_h_intern(&lf[479],31,"generate-foreign-callback-stubs");
lf[480]=C_h_intern(&lf[480],31,"\010compilergenerate-foreign-stubs");
lf[481]=C_h_intern(&lf[481],29,"\010compilerforeign-lambda-stubs");
lf[482]=C_h_intern(&lf[482],36,"\010compilergenerate-external-variables");
lf[483]=C_h_intern(&lf[483],27,"\010compilerexternal-variables");
lf[484]=C_h_intern(&lf[484],1,"p");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[505]=C_h_intern(&lf[505],11,"string-copy");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[507]=C_h_intern(&lf[507],13,"list-tabulate");
lf[508]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[509]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[510]=C_h_intern(&lf[510],41,"\010compilergenerate-foreign-callback-header");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[513]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[516]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[518]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[519]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[520]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[521]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[522]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[523]=C_h_intern(&lf[523],4,"void");
lf[524]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\003t~a");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[542]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[546]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[548]=C_h_intern(&lf[548],21,"foreign-stub-callback");
lf[549]=C_h_intern(&lf[549],16,"foreign-stub-cps");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[551]=C_h_intern(&lf[551],27,"foreign-stub-argument-names");
lf[552]=C_h_intern(&lf[552],17,"foreign-stub-body");
lf[553]=C_h_intern(&lf[553],17,"foreign-stub-name");
lf[554]=C_h_intern(&lf[554],24,"foreign-stub-return-type");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[557]=C_h_intern(&lf[557],27,"foreign-stub-argument-types");
lf[558]=C_h_intern(&lf[558],19,"\010compilerreal-name2");
lf[559]=C_h_intern(&lf[559],15,"foreign-stub-id");
lf[560]=C_h_intern(&lf[560],5,"float");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[562]=C_h_intern(&lf[562],8,"c-string");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[564]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[566]=C_h_intern(&lf[566],16,"nonnull-c-string");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[569]=C_h_intern(&lf[569],3,"ref");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[571]=C_h_intern(&lf[571],5,"const");
lf[572]=C_h_intern(&lf[572],7,"pointer");
lf[573]=C_h_intern(&lf[573],9,"c-pointer");
lf[574]=C_h_intern(&lf[574],15,"nonnull-pointer");
lf[575]=C_h_intern(&lf[575],17,"nonnull-c-pointer");
lf[576]=C_h_intern(&lf[576],8,"function");
lf[577]=C_h_intern(&lf[577],8,"instance");
lf[578]=C_h_intern(&lf[578],16,"nonnull-instance");
lf[579]=C_h_intern(&lf[579],12,"instance-ref");
lf[580]=C_h_intern(&lf[580],18,"\003syshash-table-ref");
lf[581]=C_h_intern(&lf[581],27,"\010compilerforeign-type-table");
lf[582]=C_h_intern(&lf[582],17,"nonnull-c-string*");
lf[583]=C_h_intern(&lf[583],25,"nonnull-unsigned-c-string");
lf[584]=C_h_intern(&lf[584],26,"nonnull-unsigned-c-string*");
lf[585]=C_h_intern(&lf[585],6,"symbol");
lf[586]=C_h_intern(&lf[586],9,"c-string*");
lf[587]=C_h_intern(&lf[587],17,"unsigned-c-string");
lf[588]=C_h_intern(&lf[588],18,"unsigned-c-string*");
lf[589]=C_h_intern(&lf[589],6,"double");
lf[590]=C_h_intern(&lf[590],16,"unsigned-integer");
lf[591]=C_h_intern(&lf[591],18,"unsigned-integer32");
lf[592]=C_h_intern(&lf[592],4,"long");
lf[593]=C_h_intern(&lf[593],7,"integer");
lf[594]=C_h_intern(&lf[594],9,"integer32");
lf[595]=C_h_intern(&lf[595],13,"unsigned-long");
lf[596]=C_h_intern(&lf[596],6,"number");
lf[597]=C_h_intern(&lf[597],9,"integer64");
lf[598]=C_h_intern(&lf[598],13,"c-string-list");
lf[599]=C_h_intern(&lf[599],14,"c-string-list*");
lf[600]=C_h_intern(&lf[600],3,"int");
lf[601]=C_h_intern(&lf[601],5,"int32");
lf[602]=C_h_intern(&lf[602],5,"short");
lf[603]=C_h_intern(&lf[603],14,"unsigned-short");
lf[604]=C_h_intern(&lf[604],13,"scheme-object");
lf[605]=C_h_intern(&lf[605],13,"unsigned-char");
lf[606]=C_h_intern(&lf[606],12,"unsigned-int");
lf[607]=C_h_intern(&lf[607],14,"unsigned-int32");
lf[608]=C_h_intern(&lf[608],4,"byte");
lf[609]=C_h_intern(&lf[609],13,"unsigned-byte");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[611]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[612]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[613]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[614]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[615]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[616]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[617]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[618]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[619]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[620]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[621]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[622]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[623]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[624]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[625]=C_h_intern(&lf[625],36,"foreign-callback-stub-argument-types");
lf[626]=C_h_intern(&lf[626],33,"foreign-callback-stub-return-type");
lf[627]=C_h_intern(&lf[627],24,"foreign-callback-stub-id");
lf[628]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[629]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[630]=C_h_intern(&lf[630],32,"foreign-callback-stub-qualifiers");
lf[631]=C_h_intern(&lf[631],26,"foreign-callback-stub-name");
lf[632]=C_h_intern(&lf[632],4,"quit");
lf[633]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[634]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[635]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[636]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[637]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[638]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[639]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[640]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[641]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[642]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[643]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[644]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[645]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[646]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[647]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[648]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[652]=C_h_intern(&lf[652],11,"byte-vector");
lf[653]=C_h_intern(&lf[653],19,"nonnull-byte-vector");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[655]=C_h_intern(&lf[655],4,"blob");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[657]=C_h_intern(&lf[657],9,"u16vector");
lf[658]=C_h_intern(&lf[658],17,"nonnull-u16vector");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[660]=C_h_intern(&lf[660],8,"s8vector");
lf[661]=C_h_intern(&lf[661],16,"nonnull-s8vector");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[663]=C_h_intern(&lf[663],9,"u32vector");
lf[664]=C_h_intern(&lf[664],17,"nonnull-u32vector");
lf[665]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[666]=C_h_intern(&lf[666],9,"s16vector");
lf[667]=C_h_intern(&lf[667],17,"nonnull-s16vector");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[669]=C_h_intern(&lf[669],9,"s32vector");
lf[670]=C_h_intern(&lf[670],17,"nonnull-s32vector");
lf[671]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[672]=C_h_intern(&lf[672],9,"f32vector");
lf[673]=C_h_intern(&lf[673],17,"nonnull-f32vector");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[675]=C_h_intern(&lf[675],9,"f64vector");
lf[676]=C_h_intern(&lf[676],17,"nonnull-f64vector");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[683]=C_h_intern(&lf[683],8,"template");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[690]=C_h_intern(&lf[690],6,"struct");
lf[691]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[692]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[693]=C_h_intern(&lf[693],5,"union");
lf[694]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[696]=C_h_intern(&lf[696],4,"enum");
lf[697]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[699]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[700]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[702]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[703]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[705]=C_h_intern(&lf[705],3,"...");
lf[706]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[708]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[709]=C_h_intern(&lf[709],12,"nonnull-blob");
lf[710]=C_h_intern(&lf[710],8,"u8vector");
lf[711]=C_h_intern(&lf[711],16,"nonnull-u8vector");
lf[712]=C_h_intern(&lf[712],14,"scheme-pointer");
lf[713]=C_h_intern(&lf[713],22,"nonnull-scheme-pointer");
lf[714]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[715]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[740]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[745]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[747]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[748]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[749]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[750]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[751]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[752]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[753]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[754]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[755]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[756]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[757]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\015C_flonum(&~a,");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\015C_number(&~a,");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\026C_a_double_to_num(&~a,");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\032C_unsigned_int_to_num(&~a,");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\022C_long_to_num(&~a,");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\033C_unsigned_long_to_num(&~a,");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~a,(void*)");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\037C_mpointer_or_false(&~A,(void*)");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~A,(void*)");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\027C_mpointer(&~A,(void*)&");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\026C_mpointer(&~a,(void*)");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\021C_int_to_num(&~a,");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000 invalid literal - can not encode");
lf[806]=C_h_intern(&lf[806],17,"\003sysstring-append");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[808]=C_h_intern(&lf[808],5,"cons*");
lf[809]=C_h_intern(&lf[809],29,"\010compilerstring->c-identifier");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\010C_~X_~A_");
lf[811]=C_h_intern(&lf[811],6,"random");
C_register_lf2(lf,812,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1087,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1085 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1087,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1090,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1088 in k1085 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1091 in k1088 in k1085 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1093,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_set_block_item(lf[1],0,C_SCHEME_FALSE);
t4=C_mutate((C_word*)lf[2]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1099,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[6]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1120,tmp=(C_word)a,a+=2,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8758,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8762,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 108  random */
t9=C_retrieve(lf[811]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_fix(16777216));}

/* k8760 in k1091 in k1088 in k1085 */
static void C_ccall f_8762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8766,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 108  current-seconds */
t3=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k8764 in k8760 in k1091 in k1088 in k1085 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 108  sprintf */
t2=C_retrieve(lf[332]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[810],((C_word*)t0)[2],t1);}

/* k8756 in k1091 in k1088 in k1085 */
static void C_ccall f_8758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 107  string->c-identifier */
t2=C_retrieve(lf[809]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1138,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1,t1);
t3=C_mutate((C_word*)lf[9]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1140,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[478]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4649,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[468]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4722,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[259]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4811,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4827,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[482]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4843,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[178]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4894,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[480]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4912,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[479]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5145,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[510]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5576,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[151]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5641,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[150]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6858,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7691,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8465,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[23],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8465,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8468,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8471,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8474,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8527,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t7)){
t8=t6;
f_8527(2,t8,lf[795]);}
else{
t8=(C_word)C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t8)){
t9=t6;
f_8527(2,t9,lf[796]);}
else{
if(C_truep((C_word)C_charp(t2))){
t9=(C_word)C_fix((C_word)C_character_code(t2));
t10=f_8474(C_a_i(&a,4),t9);
/* c-backend.scm: 1362 string-append */
t11=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t6,lf[797],t10);}
else{
if(C_truep((C_word)C_i_nullp(t2))){
t9=t6;
f_8527(2,t9,lf[798]);}
else{
if(C_truep((C_word)C_eofp(t2))){
t9=t6;
f_8527(2,t9,lf[799]);}
else{
t9=C_retrieve(lf[0]);
t10=(C_word)C_eqp(t9,t2);
if(C_truep(t10)){
t11=t6;
f_8527(2,t11,lf[800]);}
else{
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8577,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8750,a[2]=t11,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1366 big-fixnum? */
t13=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t13))(3,t13,t12,t2);}
else{
t12=t11;
f_8577(t12,C_SCHEME_FALSE);}}}}}}}}

/* k8748 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_8577(t2,(C_word)C_i_not(t1));}

/* k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8577(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8577,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(24));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(16));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_shift_right(((C_word*)t0)[6],C_fix(8));
t9=(C_word)C_fixnum_and(C_fix(255),t8);
t10=(C_word)C_make_character((C_word)C_unfix(t9));
t11=(C_word)C_fixnum_and(C_fix(255),((C_word*)t0)[6]);
t12=(C_word)C_make_character((C_word)C_unfix(t11));
t13=(C_word)C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm: 1367 string-append */
t14=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t14))(4,t14,((C_word*)t0)[5],lf[801],t13);}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8641,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1374 number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[6]))){
t2=(C_word)C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_word)C_i_string_length(t2);
t4=f_8474(C_a_i(&a,4),t3);
/* c-backend.scm: 1377 string-append */
t5=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,((C_word*)t0)[5],lf[804],t4,t2);}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[6]))){
/* c-backend.scm: 1382 bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[5],lf[805],((C_word*)t0)[6]);}
else{
if(C_truep((C_word)C_byteblockp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8680,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=f_8468(((C_word*)t0)[6]);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_a_i_string(&a,1,t4);
t6=f_8471(((C_word*)t0)[6]);
t7=f_8474(C_a_i(&a,4),t6);
/* c-backend.scm: 1385 string-append */
t8=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t8))(4,t8,t2,t5,t7);}
else{
t2=f_8471(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8710,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=f_8468(((C_word*)t0)[6]);
t5=(C_word)C_make_character((C_word)C_unfix(t4));
t6=(C_word)C_a_i_string(&a,1,t5);
t7=f_8474(C_a_i(&a,4),t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8722,a[2]=t7,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8724,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1395 list-tabulate */
t10=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t2,t9);}}}}}}

/* a8723 in k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8724,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm: 1395 encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* k8720 in k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1392 cons* */
t2=C_retrieve(lf[808]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8708 in k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1391 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[807]);}

/* k8678 in k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1384 ##sys#string-append */
t2=C_retrieve(lf[806]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8639 in k8575 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1374 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[802],t1,lf[803]);}

/* k8525 in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_8527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8527,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(C_word)C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm: 1358 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static C_word C_fcall f_8474(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=(C_word)C_fixnum_shift_right(t1,C_fix(16));
t3=(C_word)C_fixnum_and(C_fix(255),t2);
t4=(C_word)C_make_character((C_word)C_unfix(t3));
t5=(C_word)C_fixnum_shift_right(t1,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_make_character((C_word)C_unfix(t6));
t8=(C_word)C_fixnum_and(C_fix(255),t1);
t9=(C_word)C_make_character((C_word)C_unfix(t8));
return((C_word)C_a_i_string(&a,3,t4,t7,t9));}

/* getsize in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static C_word C_fcall f_8471(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1048(C_SCHEME_UNDEFINED,t1));}

/* getbits in ##compiler#encode-literal in k1136 in k1091 in k1088 in k1085 */
static C_word C_fcall f_8468(C_word t1){
C_word tmp;
C_word t2;
C_stack_check;
return((C_word)stub1044(C_SCHEME_UNDEFINED,t1));}

/* ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7691,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7693,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t5,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t5,lf[601]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[770]);}
else{
t10=(C_word)C_eqp(t5,lf[606]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[607]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[771]);}
else{
t12=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[772]);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[773]);}
else{
t14=(C_word)C_eqp(t5,lf[608]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[774]);}
else{
t15=(C_word)C_eqp(t5,lf[609]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[775]);}
else{
t16=(C_word)C_eqp(t5,lf[560]);
t17=(C_truep(t16)?t16:(C_word)C_eqp(t5,lf[589]));
if(C_truep(t17)){
/* c-backend.scm: 1296 sprintf */
t18=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t1,lf[776],t3);}
else{
t18=(C_word)C_eqp(t5,lf[596]);
if(C_truep(t18)){
/* c-backend.scm: 1297 sprintf */
t19=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t19))(4,t19,t1,lf[777],t3);}
else{
t19=(C_word)C_eqp(t5,lf[566]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7778,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_7778(t21,t19);}
else{
t21=(C_word)C_eqp(t5,lf[562]);
if(C_truep(t21)){
t22=t20;
f_7778(t22,t21);}
else{
t22=(C_word)C_eqp(t5,lf[575]);
if(C_truep(t22)){
t23=t20;
f_7778(t23,t22);}
else{
t23=(C_word)C_eqp(t5,lf[586]);
if(C_truep(t23)){
t24=t20;
f_7778(t24,t23);}
else{
t24=(C_word)C_eqp(t5,lf[582]);
if(C_truep(t24)){
t25=t20;
f_7778(t25,t24);}
else{
t25=(C_word)C_eqp(t5,lf[587]);
if(C_truep(t25)){
t26=t20;
f_7778(t26,t25);}
else{
t26=(C_word)C_eqp(t5,lf[588]);
if(C_truep(t26)){
t27=t20;
f_7778(t27,t26);}
else{
t27=(C_word)C_eqp(t5,lf[583]);
if(C_truep(t27)){
t28=t20;
f_7778(t28,t27);}
else{
t28=(C_word)C_eqp(t5,lf[584]);
if(C_truep(t28)){
t29=t20;
f_7778(t29,t28);}
else{
t29=(C_word)C_eqp(t5,lf[585]);
if(C_truep(t29)){
t30=t20;
f_7778(t30,t29);}
else{
t30=(C_word)C_eqp(t5,lf[598]);
t31=t20;
f_7778(t31,(C_truep(t30)?t30:(C_word)C_eqp(t5,lf[599])));}}}}}}}}}}}}}}}}}}}}

/* k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7778,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1301 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],lf[778],((C_word*)t0)[5]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t2)){
/* c-backend.scm: 1302 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],lf[779],((C_word*)t0)[5]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t4)){
/* c-backend.scm: 1303 sprintf */
t5=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[6],lf[780],((C_word*)t0)[5]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t5)){
/* c-backend.scm: 1304 sprintf */
t6=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[6],lf[781],((C_word*)t0)[5]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
/* c-backend.scm: 1305 sprintf */
t8=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t8))(4,t8,((C_word*)t0)[6],lf[782],((C_word*)t0)[5]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t8)){
/* c-backend.scm: 1306 sprintf */
t9=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[6],lf[783],((C_word*)t0)[5]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t9)){
/* c-backend.scm: 1307 sprintf */
t10=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t10))(4,t10,((C_word*)t0)[6],lf[784],((C_word*)t0)[5]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[785]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[523]);
t12=(C_truep(t11)?t11:(C_word)C_eqp(((C_word*)t0)[4],lf[604]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[786]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7859,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1311 ##sys#hash-table-ref */
t14=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t14=t13;
f_7859(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_7859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[69],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7859,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1313 foreign-result-conversion */
t4=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7882,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7887,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7892,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7914,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7914(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7914(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[575]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7950,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7950(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7950(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[569]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7986,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7986(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7986(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8021,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_8021(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_8021(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_8021(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8069,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_8069(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_8069(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_8069(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[579]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8117,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t19))){
t20=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t21=t17;
f_8117(t21,(C_word)C_i_nullp(t20));}
else{
t20=t17;
f_8117(t20,C_SCHEME_FALSE);}}
else{
t19=t17;
f_8117(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8165,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_8165(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_8165(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[572]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8200,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_8200(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_8200(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[573]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8236,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_8236(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_8236(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[3]);
t24=(C_word)C_eqp(t23,lf[576]);
if(C_truep(t24)){
t25=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t25))){
t26=(C_word)C_i_cadr(((C_word*)t0)[3]);
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* c-backend.scm: 1315 sprintf */
t28=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t28))(4,t28,((C_word*)t0)[5],lf[793],((C_word*)t0)[4]);}
else{
/* c-backend.scm: 1315 g1019 */
t26=t2;
f_7882(t26,((C_word*)t0)[5]);}}
else{
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8294,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(((C_word*)t0)[3]);
t27=(C_word)C_eqp(t26,lf[696]);
if(C_truep(t27)){
t28=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[3]);
t30=t25;
f_8294(t30,(C_word)C_i_nullp(t29));}
else{
t29=t25;
f_8294(t29,C_SCHEME_FALSE);}}
else{
t28=t25;
f_8294(t28,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1315 g1019 */
t5=t2;
f_7882(t5,((C_word*)t0)[5]);}}
else{
/* c-backend.scm: 1332 err */
t2=((C_word*)t0)[2];
f_7693(t2,((C_word*)t0)[5]);}}}

/* k8292 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[794],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k8234 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 g1016 */
t3=((C_word*)t0)[4];
f_7887(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[3]);}}

/* k8198 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8200(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 g1016 */
t3=((C_word*)t0)[4];
f_7887(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[3]);}}

/* k8163 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k8115 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[792],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k8067 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8069(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[791],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k8019 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_8021(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 sprintf */
t4=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[4],lf[790],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k7984 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1319 sprintf */
t3=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],lf[789],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[4]);}}

/* k7948 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7950(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 g1010 */
t3=((C_word*)t0)[4];
f_7892(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[3]);}}

/* k7912 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1315 g1010 */
t3=((C_word*)t0)[4];
f_7892(t3,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1315 g1019 */
t2=((C_word*)t0)[2];
f_7882(t2,((C_word*)t0)[3]);}}

/* g1010 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7892(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7892,NULL,2,t0,t1);}
/* c-backend.scm: 1317 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[788],((C_word*)t0)[2]);}

/* g1016 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7887(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7887,NULL,2,t0,t1);}
/* c-backend.scm: 1328 sprintf */
t2=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[787],((C_word*)t0)[2]);}

/* g1019 in k7857 in k7776 in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7882(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7882,NULL,2,t0,t1);}
/* c-backend.scm: 1331 err */
t2=((C_word*)t0)[2];
f_7693(t2,t1);}

/* err in ##compiler#foreign-result-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7693,NULL,2,t0,t1);}
/* c-backend.scm: 1287 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[768],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6860,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(C_word)C_eqp(t4,lf[604]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[715]);}
else{
t6=(C_word)C_eqp(t4,lf[18]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t4,lf[605]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[716]);}
else{
t8=(C_word)C_eqp(t4,lf[608]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6888,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_6888(t10,t8);}
else{
t10=(C_word)C_eqp(t4,lf[600]);
if(C_truep(t10)){
t11=t9;
f_6888(t11,t10);}
else{
t11=(C_word)C_eqp(t4,lf[606]);
if(C_truep(t11)){
t12=t9;
f_6888(t12,t11);}
else{
t12=(C_word)C_eqp(t4,lf[607]);
t13=t9;
f_6888(t13,(C_truep(t12)?t12:(C_word)C_eqp(t4,lf[609])));}}}}}}

/* k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6888(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6888,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[717]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[602]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[718]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[603]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[719]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[595]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[720]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[589]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_6915(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[4],lf[596]);
t8=t6;
f_6915(t8,(C_truep(t7)?t7:(C_word)C_eqp(((C_word*)t0)[4],lf[560])));}}}}}}

/* k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6915,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[721]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[593]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[4],lf[594]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[722]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[597]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[723]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[592]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[724]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[590]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[591]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[725]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[4],lf[572]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[726]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[4],lf[574]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[727]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[728]);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[4],lf[713]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[729]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[4],lf[573]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[730]);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[4],lf[575]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[731]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[4],lf[655]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[732]);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[733]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[4],lf[652]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[734]);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[4],lf[653]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[735]);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[4],lf[710]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[736]);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[737]);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[4],lf[657]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[738]);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[4],lf[658]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[739]);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[4],lf[663]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[740]);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[4],lf[664]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[741]);}
else{
t24=(C_word)C_eqp(((C_word*)t0)[4],lf[660]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[742]);}
else{
t25=(C_word)C_eqp(((C_word*)t0)[4],lf[661]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[743]);}
else{
t26=(C_word)C_eqp(((C_word*)t0)[4],lf[666]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[744]);}
else{
t27=(C_word)C_eqp(((C_word*)t0)[4],lf[667]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[745]);}
else{
t28=(C_word)C_eqp(((C_word*)t0)[4],lf[669]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[746]);}
else{
t29=(C_word)C_eqp(((C_word*)t0)[4],lf[670]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[747]);}
else{
t30=(C_word)C_eqp(((C_word*)t0)[4],lf[672]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[748]);}
else{
t31=(C_word)C_eqp(((C_word*)t0)[4],lf[673]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[749]);}
else{
t32=(C_word)C_eqp(((C_word*)t0)[4],lf[675]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[750]);}
else{
t33=(C_word)C_eqp(((C_word*)t0)[4],lf[676]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[751]);}
else{
t34=(C_word)C_eqp(((C_word*)t0)[4],lf[562]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_7110(t36,t34);}
else{
t36=(C_word)C_eqp(((C_word*)t0)[4],lf[586]);
if(C_truep(t36)){
t37=t35;
f_7110(t37,t36);}
else{
t37=(C_word)C_eqp(((C_word*)t0)[4],lf[587]);
t38=t35;
f_7110(t38,(C_truep(t37)?t37:(C_word)C_eqp(((C_word*)t0)[4],lf[588])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7110(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7110,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[752]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_7119(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_7119(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_7119(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_7119(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7119(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7119,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[753]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[15]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[754]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1263 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_7128(2,t4,C_SCHEME_FALSE);}}}}

/* k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1265 foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[4],t3);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7151,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(t3,lf[572]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7173,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_cddr(((C_word*)t0)[3]);
t8=t5;
f_7173(t8,(C_word)C_i_nullp(t7));}
else{
t7=t5;
f_7173(t7,C_SCHEME_FALSE);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_eqp(t5,lf[574]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7205,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[3]);
t10=t7;
f_7205(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_7205(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=(C_word)C_eqp(t7,lf[573]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7237,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[3]);
t12=t9;
f_7237(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_7237(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[3]);
t10=(C_word)C_eqp(t9,lf[575]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7269,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[3]);
t14=t11;
f_7269(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_7269(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[3]);
t12=(C_word)C_eqp(t11,lf[577]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7301,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t15))){
t16=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t17=t13;
f_7301(t17,(C_word)C_i_nullp(t16));}
else{
t16=t13;
f_7301(t16,C_SCHEME_FALSE);}}
else{
t15=t13;
f_7301(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[3]);
t14=(C_word)C_eqp(t13,lf[578]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7346,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t19=t15;
f_7346(t19,(C_word)C_i_nullp(t18));}
else{
t18=t15;
f_7346(t18,C_SCHEME_FALSE);}}
else{
t17=t15;
f_7346(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[3]);
t16=(C_word)C_eqp(t15,lf[576]);
if(C_truep(t16)){
t17=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t17))){
t18=(C_word)C_i_cadr(((C_word*)t0)[3]);
t19=(C_word)C_i_cddr(((C_word*)t0)[3]);
t20=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[761]);}
else{
/* c-backend.scm: 1267 g946 */
t18=t2;
f_7151(t18,((C_word*)t0)[4]);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[3]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7416,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[3]);
t22=t19;
f_7416(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_7416(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[3]);
t20=(C_word)C_eqp(t19,lf[696]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7451,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[3]);
t24=t21;
f_7451(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_7451(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[3]);
t22=(C_word)C_eqp(t21,lf[569]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7483,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[3]);
t26=t23;
f_7483(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_7483(t25,C_SCHEME_FALSE);}}
else{
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7516,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t24=(C_word)C_i_car(((C_word*)t0)[3]);
t25=(C_word)C_eqp(t24,lf[579]);
if(C_truep(t25)){
t26=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t27))){
t28=(C_word)C_i_cdddr(((C_word*)t0)[3]);
t29=t23;
f_7516(t29,(C_word)C_i_nullp(t28));}
else{
t28=t23;
f_7516(t28,C_SCHEME_FALSE);}}
else{
t27=t23;
f_7516(t27,C_SCHEME_FALSE);}}
else{
t26=t23;
f_7516(t26,C_SCHEME_FALSE);}}}}}}}}}}}}
else{
/* c-backend.scm: 1267 g946 */
t3=t2;
f_7151(t3,((C_word*)t0)[4]);}}
else{
/* c-backend.scm: 1281 err */
t2=((C_word*)t0)[2];
f_6860(t2,((C_word*)t0)[4]);}}}

/* k7514 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7516(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 1267 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],lf[766],t2,lf[767]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7481 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7483(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7483,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7493,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1267 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[765]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7491 in k7481 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_7493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1267 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[763],t1,lf[764]);}

/* k7449 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7451(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7414 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7416(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1267 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7344 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[760]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7299 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[759]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7267 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[758]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7235 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[757]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7203 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[756]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* k7171 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[755]);}
else{
/* c-backend.scm: 1267 g946 */
t2=((C_word*)t0)[2];
f_7151(t2,((C_word*)t0)[3]);}}

/* g946 in k7126 in k7117 in k7108 in k6913 in k6886 in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_7151(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7151,NULL,2,t0,t1);}
/* c-backend.scm: 1280 err */
t2=((C_word*)t0)[2];
f_6860(t2,t1);}

/* err in ##compiler#foreign-argument-conversion in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6860(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6860,NULL,2,t0,t1);}
/* c-backend.scm: 1217 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[714],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5641,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5643,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5648,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=(C_word)C_eqp(t6,lf[604]);
if(C_truep(t7)){
/* c-backend.scm: 1137 str */
t8=t5;
f_5648(t8,t1,lf[635]);}
else{
t8=(C_word)C_eqp(t6,lf[18]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(t6,lf[608]));
if(C_truep(t9)){
/* c-backend.scm: 1138 str */
t10=t5;
f_5648(t10,t1,lf[636]);}
else{
t10=(C_word)C_eqp(t6,lf[605]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t6,lf[609]));
if(C_truep(t11)){
/* c-backend.scm: 1139 str */
t12=t5;
f_5648(t12,t1,lf[637]);}
else{
t12=(C_word)C_eqp(t6,lf[606]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(t6,lf[590]));
if(C_truep(t13)){
/* c-backend.scm: 1140 str */
t14=t5;
f_5648(t14,t1,lf[638]);}
else{
t14=(C_word)C_eqp(t6,lf[607]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(t6,lf[591]));
if(C_truep(t15)){
/* c-backend.scm: 1141 str */
t16=t5;
f_5648(t16,t1,lf[639]);}
else{
t16=(C_word)C_eqp(t6,lf[600]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5718,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5718(t18,t16);}
else{
t18=(C_word)C_eqp(t6,lf[593]);
t19=t17;
f_5718(t19,(C_truep(t18)?t18:(C_word)C_eqp(t6,lf[15])));}}}}}}}

/* k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5718(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5718,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1142 str */
t2=((C_word*)t0)[7];
f_5648(t2,((C_word*)t0)[6],lf[640]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[601]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[594]));
if(C_truep(t3)){
/* c-backend.scm: 1143 str */
t4=((C_word*)t0)[7];
f_5648(t4,((C_word*)t0)[6],lf[641]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t4)){
/* c-backend.scm: 1144 str */
t5=((C_word*)t0)[7];
f_5648(t5,((C_word*)t0)[6],lf[642]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t5)){
/* c-backend.scm: 1145 str */
t6=((C_word*)t0)[7];
f_5648(t6,((C_word*)t0)[6],lf[643]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t6)){
/* c-backend.scm: 1146 str */
t7=((C_word*)t0)[7];
f_5648(t7,((C_word*)t0)[6],lf[644]);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[603]);
if(C_truep(t7)){
/* c-backend.scm: 1147 str */
t8=((C_word*)t0)[7];
f_5648(t8,((C_word*)t0)[6],lf[645]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t8)){
/* c-backend.scm: 1148 str */
t9=((C_word*)t0)[7];
f_5648(t9,((C_word*)t0)[6],lf[646]);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
if(C_truep(t9)){
/* c-backend.scm: 1149 str */
t10=((C_word*)t0)[7];
f_5648(t10,((C_word*)t0)[6],lf[647]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[596]));
if(C_truep(t11)){
/* c-backend.scm: 1150 str */
t12=((C_word*)t0)[7];
f_5648(t12,((C_word*)t0)[6],lf[648]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[572]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[574]));
if(C_truep(t13)){
/* c-backend.scm: 1152 str */
t14=((C_word*)t0)[7];
f_5648(t14,((C_word*)t0)[6],lf[649]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_5820(t16,t14);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t16)){
t17=t15;
f_5820(t17,t16);}
else{
t17=(C_word)C_eqp(((C_word*)t0)[5],lf[712]);
t18=t15;
f_5820(t18,(C_truep(t17)?t17:(C_word)C_eqp(((C_word*)t0)[5],lf[713])));}}}}}}}}}}}}}

/* k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5820(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5820,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1153 str */
t2=((C_word*)t0)[7];
f_5648(t2,((C_word*)t0)[6],lf[650]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[599]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[651]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[652]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[653]));
if(C_truep(t5)){
/* c-backend.scm: 1156 str */
t6=((C_word*)t0)[7];
f_5648(t6,((C_word*)t0)[6],lf[654]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[655]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5853(t8,t6);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[709]);
if(C_truep(t8)){
t9=t7;
f_5853(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[710]);
t10=t7;
f_5853(t10,(C_truep(t9)?t9:(C_word)C_eqp(((C_word*)t0)[5],lf[711])));}}}}}}

/* k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5853,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1157 str */
t2=((C_word*)t0)[7];
f_5648(t2,((C_word*)t0)[6],lf[656]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[657]);
t3=(C_truep(t2)?t2:(C_word)C_eqp(((C_word*)t0)[5],lf[658]));
if(C_truep(t3)){
/* c-backend.scm: 1158 str */
t4=((C_word*)t0)[7];
f_5648(t4,((C_word*)t0)[6],lf[659]);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[660]);
t5=(C_truep(t4)?t4:(C_word)C_eqp(((C_word*)t0)[5],lf[661]));
if(C_truep(t5)){
/* c-backend.scm: 1159 str */
t6=((C_word*)t0)[7];
f_5648(t6,((C_word*)t0)[6],lf[662]);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[663]);
t7=(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[664]));
if(C_truep(t7)){
/* c-backend.scm: 1160 str */
t8=((C_word*)t0)[7];
f_5648(t8,((C_word*)t0)[6],lf[665]);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[666]);
t9=(C_truep(t8)?t8:(C_word)C_eqp(((C_word*)t0)[5],lf[667]));
if(C_truep(t9)){
/* c-backend.scm: 1161 str */
t10=((C_word*)t0)[7];
f_5648(t10,((C_word*)t0)[6],lf[668]);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[669]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(((C_word*)t0)[5],lf[670]));
if(C_truep(t11)){
/* c-backend.scm: 1162 str */
t12=((C_word*)t0)[7];
f_5648(t12,((C_word*)t0)[6],lf[671]);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[672]);
t13=(C_truep(t12)?t12:(C_word)C_eqp(((C_word*)t0)[5],lf[673]));
if(C_truep(t13)){
/* c-backend.scm: 1163 str */
t14=((C_word*)t0)[7];
f_5648(t14,((C_word*)t0)[6],lf[674]);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[675]);
t15=(C_truep(t14)?t14:(C_word)C_eqp(((C_word*)t0)[5],lf[676]));
if(C_truep(t15)){
/* c-backend.scm: 1164 str */
t16=((C_word*)t0)[7];
f_5648(t16,((C_word*)t0)[6],lf[677]);}
else{
t16=(C_word)C_eqp(((C_word*)t0)[5],lf[566]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_5949(t18,t16);}
else{
t18=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
if(C_truep(t18)){
t19=t17;
f_5949(t19,t18);}
else{
t19=(C_word)C_eqp(((C_word*)t0)[5],lf[582]);
if(C_truep(t19)){
t20=t17;
f_5949(t20,t19);}
else{
t20=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t20)){
t21=t17;
f_5949(t21,t20);}
else{
t21=(C_word)C_eqp(((C_word*)t0)[5],lf[583]);
if(C_truep(t21)){
t22=t17;
f_5949(t22,t21);}
else{
t22=(C_word)C_eqp(((C_word*)t0)[5],lf[584]);
if(C_truep(t22)){
t23=t17;
f_5949(t23,t22);}
else{
t23=(C_word)C_eqp(((C_word*)t0)[5],lf[588]);
t24=t17;
f_5949(t24,(C_truep(t23)?t23:(C_word)C_eqp(((C_word*)t0)[5],lf[585])));}}}}}}}}}}}}}}}

/* k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5949(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5949,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1167 str */
t2=((C_word*)t0)[7];
f_5648(t2,((C_word*)t0)[6],lf[678]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t2)){
/* c-backend.scm: 1168 str */
t3=((C_word*)t0)[7];
f_5648(t3,((C_word*)t0)[6],lf[679]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm: 1170 ##sys#hash-table-ref */
t4=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_retrieve(lf[581]),((C_word*)t0)[3]);}
else{
t4=t3;
f_5964(2,t4,C_SCHEME_FALSE);}}}}

/* k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word ab[93],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5964,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1172 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[6],t3,((C_word*)t0)[5]);}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm: 1173 str */
t2=((C_word*)t0)[3];
f_5648(t2,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5996,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6010,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(C_word)C_eqp(t5,lf[572]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6036,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t8))){
t9=(C_word)C_i_cddr(((C_word*)t0)[4]);
t10=t7;
f_6036(t10,(C_word)C_i_nullp(t9));}
else{
t9=t7;
f_6036(t9,C_SCHEME_FALSE);}}
else{
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_eqp(t7,lf[574]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6072,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t10=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t10))){
t11=(C_word)C_i_cddr(((C_word*)t0)[4]);
t12=t9;
f_6072(t12,(C_word)C_i_nullp(t11));}
else{
t11=t9;
f_6072(t11,C_SCHEME_FALSE);}}
else{
t9=(C_word)C_i_car(((C_word*)t0)[4]);
t10=(C_word)C_eqp(t9,lf[573]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6108,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t12))){
t13=(C_word)C_i_cddr(((C_word*)t0)[4]);
t14=t11;
f_6108(t14,(C_word)C_i_nullp(t13));}
else{
t13=t11;
f_6108(t13,C_SCHEME_FALSE);}}
else{
t11=(C_word)C_i_car(((C_word*)t0)[4]);
t12=(C_word)C_eqp(t11,lf[575]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6144,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t14=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t14))){
t15=(C_word)C_i_cddr(((C_word*)t0)[4]);
t16=t13;
f_6144(t16,(C_word)C_i_nullp(t15));}
else{
t15=t13;
f_6144(t15,C_SCHEME_FALSE);}}
else{
t13=(C_word)C_i_car(((C_word*)t0)[4]);
t14=(C_word)C_eqp(t13,lf[569]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6180,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t16=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t16))){
t17=(C_word)C_i_cddr(((C_word*)t0)[4]);
t18=t15;
f_6180(t18,(C_word)C_i_nullp(t17));}
else{
t17=t15;
f_6180(t17,C_SCHEME_FALSE);}}
else{
t15=(C_word)C_i_car(((C_word*)t0)[4]);
t16=(C_word)C_eqp(t15,lf[683]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6219,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t18=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t18))){
t19=(C_word)C_i_cddr(((C_word*)t0)[4]);
t20=t17;
f_6219(t20,(C_word)C_i_listp(t19));}
else{
t19=t17;
f_6219(t19,C_SCHEME_FALSE);}}
else{
t17=(C_word)C_i_car(((C_word*)t0)[4]);
t18=(C_word)C_eqp(t17,lf[571]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6279,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t20=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t20))){
t21=(C_word)C_i_cddr(((C_word*)t0)[4]);
t22=t19;
f_6279(t22,(C_word)C_i_nullp(t21));}
else{
t21=t19;
f_6279(t21,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_i_car(((C_word*)t0)[4]);
t20=(C_word)C_eqp(t19,lf[690]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6318,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t22=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t22))){
t23=(C_word)C_i_cddr(((C_word*)t0)[4]);
t24=t21;
f_6318(t24,(C_word)C_i_nullp(t23));}
else{
t23=t21;
f_6318(t23,C_SCHEME_FALSE);}}
else{
t21=(C_word)C_i_car(((C_word*)t0)[4]);
t22=(C_word)C_eqp(t21,lf[693]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6357,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t24=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t24))){
t25=(C_word)C_i_cddr(((C_word*)t0)[4]);
t26=t23;
f_6357(t26,(C_word)C_i_nullp(t25));}
else{
t25=t23;
f_6357(t25,C_SCHEME_FALSE);}}
else{
t23=(C_word)C_i_car(((C_word*)t0)[4]);
t24=(C_word)C_eqp(t23,lf[696]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6396,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t26))){
t27=(C_word)C_i_cddr(((C_word*)t0)[4]);
t28=t25;
f_6396(t28,(C_word)C_i_nullp(t27));}
else{
t27=t25;
f_6396(t27,C_SCHEME_FALSE);}}
else{
t25=(C_word)C_i_car(((C_word*)t0)[4]);
t26=(C_word)C_eqp(t25,lf[577]);
if(C_truep(t26)){
t27=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6435,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t28=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t28))){
t29=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t29))){
t30=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t31=t27;
f_6435(t31,(C_word)C_i_nullp(t30));}
else{
t30=t27;
f_6435(t30,C_SCHEME_FALSE);}}
else{
t29=t27;
f_6435(t29,C_SCHEME_FALSE);}}
else{
t27=(C_word)C_i_car(((C_word*)t0)[4]);
t28=(C_word)C_eqp(t27,lf[578]);
if(C_truep(t28)){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6485,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=t3,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t30=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t30))){
t31=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t31))){
t32=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t33=t29;
f_6485(t33,(C_word)C_i_nullp(t32));}
else{
t32=t29;
f_6485(t32,C_SCHEME_FALSE);}}
else{
t31=t29;
f_6485(t31,C_SCHEME_FALSE);}}
else{
t29=(C_word)C_i_car(((C_word*)t0)[4]);
t30=(C_word)C_eqp(t29,lf[579]);
if(C_truep(t30)){
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6535,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t32))){
t33=(C_word)C_i_cddr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t33))){
t34=(C_word)C_i_cdddr(((C_word*)t0)[4]);
t35=t31;
f_6535(t35,(C_word)C_i_nullp(t34));}
else{
t34=t31;
f_6535(t34,C_SCHEME_FALSE);}}
else{
t33=t31;
f_6535(t33,C_SCHEME_FALSE);}}
else{
t31=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6581,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t32=(C_word)C_i_car(((C_word*)t0)[4]);
t33=(C_word)C_eqp(t32,lf[576]);
if(C_truep(t33)){
t34=(C_word)C_i_cdr(((C_word*)t0)[4]);
if(C_truep((C_word)C_i_pairp(t34))){
t35=(C_word)C_i_cddr(((C_word*)t0)[4]);
t36=t31;
f_6581(t36,(C_word)C_i_pairp(t35));}
else{
t35=t31;
f_6581(t35,C_SCHEME_FALSE);}}
else{
t34=t31;
f_6581(t34,C_SCHEME_FALSE);}}}}}}}}}}}}}}}
else{
/* c-backend.scm: 1175 g869 */
t5=t2;
f_5996(t5,((C_word*)t0)[6]);}}
else{
/* c-backend.scm: 1211 err */
t2=((C_word*)t0)[2];
f_5643(t2,((C_word*)t0)[6]);}}}}

/* k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6581(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6581,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(C_word)C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6597,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1175 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[708]);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6595 in k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t3=(C_word)C_i_car(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=(C_word)C_i_stringp(t3);
t5=t2;
f_6601(t5,(C_truep(t4)?t3:C_SCHEME_FALSE));}
else{
t4=t2;
f_6601(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_6601(t3,C_SCHEME_FALSE);}}

/* k6599 in k6595 in k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6601,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[700]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6608,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6612,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6614,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a6613 in k6599 in k6595 in k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6614,3,t0,t1,t2);}
t3=(C_word)C_eqp(lf[705],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[706]);}
else{
/* c-backend.scm: 1175 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[707]);}}

/* k6610 in k6599 in k6595 in k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[704]);}

/* k6606 in k6599 in k6595 in k6579 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[701],((C_word*)t0)[2],lf[702],t1,lf[703]);}

/* k6533 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6535(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6535,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 ->string */
t5=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6546 in k6533 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[699],((C_word*)t0)[2]);}

/* k6483 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6485(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g866 */
t4=((C_word*)t0)[4];
f_6001(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6433 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g866 */
t4=((C_word*)t0)[4];
f_6001(t4,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6394 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6396(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6396,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6406,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6404 in k6394 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[697],t1,lf[698],((C_word*)t0)[2]);}

/* k6355 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6367,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6365 in k6355 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[694],t1,lf[695],((C_word*)t0)[2]);}

/* k6316 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6318,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6326 in k6316 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],lf[691],t1,lf[692],((C_word*)t0)[2]);}

/* k6277 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6279,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6289,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1175 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6287 in k6277 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[689],t1);}

/* k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6219,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6236,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1175 foreign-type-declaration */
t6=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,lf[688]);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6234 in k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6240,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6244,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6246,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a6245 in k6234 in k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6246(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6246,3,t0,t1,t2);}
/* ##compiler#foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[687]);}

/* k6242 in k6234 in k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[686]);}

/* k6238 in k6234 in k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[684],t1,lf[685]);}

/* k6230 in k6217 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1175 str */
t2=((C_word*)t0)[3];
f_5648(t2,((C_word*)t0)[2],t1);}

/* k6178 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6180(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6180,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6190,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1179 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[682],((C_word*)t0)[3]);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[4]);}}

/* k6188 in k6178 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1179 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6142 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g856 */
t3=((C_word*)t0)[4];
f_6010(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6106 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6108(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g856 */
t3=((C_word*)t0)[4];
f_6010(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6070 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6072(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g856 */
t3=((C_word*)t0)[4];
f_6010(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* k6034 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm: 1175 g856 */
t3=((C_word*)t0)[4];
f_6010(t3,((C_word*)t0)[3],t2);}
else{
/* c-backend.scm: 1175 g869 */
t2=((C_word*)t0)[2];
f_5996(t2,((C_word*)t0)[3]);}}

/* g856 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6010,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6018,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1177 string-append */
t4=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[681],((C_word*)t0)[2]);}

/* k6016 in g856 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1177 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g866 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_6001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6001,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6009,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1191 ->string */
t4=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k6007 in g866 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_6009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1191 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],t1,lf[680],((C_word*)t0)[2]);}

/* g869 in k5962 in k5947 in k5851 in k5818 in k5716 in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5996(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5996,NULL,2,t0,t1);}
/* c-backend.scm: 1210 err */
t2=((C_word*)t0)[2];
f_5643(t2,t1);}

/* str in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5648(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5648,NULL,3,t0,t1,t2);}
/* c-backend.scm: 1135 string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,t2,lf[634],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5643(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5643,NULL,2,t0,t1);}
/* c-backend.scm: 1134 quit */
t2=C_retrieve(lf[632]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[633],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5576,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5580,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1116 foreign-callback-stub-name */
t5=C_retrieve(lf[631]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5583,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1117 foreign-callback-stub-qualifiers */
t3=C_retrieve(lf[630]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5586,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1118 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5589,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1119 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5589,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1121 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[629]);}

/* k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5598,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1122 foreign-type-declaration */
t4=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[628]);}

/* k5637 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1122 gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k5596 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5601,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5606,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1123 pair-for-each */
t4=C_retrieve(lf[174]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5605 in k5596 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5606(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5606,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5610,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5627,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(C_word)C_i_car(t3);
t7=(C_word)C_i_car(t2);
/* c-backend.scm: 1125 foreign-type-declaration */
t8=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t5,t6,t7);}

/* k5625 in a5605 in k5596 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1125 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5608 in a5605 in k5596 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
/* c-backend.scm: 1126 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k5599 in k5596 in k5593 in k5587 in k5584 in k5581 in k5578 in ##compiler#generate-foreign-callback-header in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1128 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5145,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5151,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5151,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5155,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1063 foreign-callback-stub-id */
t4=C_retrieve(lf[627]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5158,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1064 real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5161,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1065 foreign-callback-stub-return-type */
t3=C_retrieve(lf[626]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1066 foreign-callback-stub-argument-types */
t3=C_retrieve(lf[625]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5164,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1068 make-argument-list */
t4=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t2,lf[624]);}

/* k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5172,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1095 fold */
t6=C_retrieve(lf[413]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t3)[1],lf[623],((C_word*)t0)[4],t1);}

/* k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5514,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1096 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5574,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1098 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_5517(2,t3,C_SCHEME_UNDEFINED);}}

/* k5572 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1098 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[621],t1,lf[622]);}

/* k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5520,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1099 generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[620],((C_word*)t0)[2]);}

/* k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5523,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1100 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[618],((C_word*)t0)[2],lf[619]);}

/* k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5526,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 1101 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[617]);}

/* k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5526,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5529,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5559,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm: 1102 for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5558 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5559,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1104 foreign-result-conversion */
t5=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,lf[616]);}

/* k5565 in a5558 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1104 gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[613],t1,((C_word*)t0)[2],lf[614],C_SCHEME_TRUE,lf[615]);}

/* k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5529,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_5532(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1109 foreign-argument-conversion */
t5=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[4]);}}

/* k5555 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1109 gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[612],t1);}

/* k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5535,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 1110 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[611],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5538,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_eqp(lf[523],((C_word*)t0)[2]);
if(C_truep(t3)){
t4=t2;
f_5538(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1111 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5536 in k5533 in k5530 in k5527 in k5524 in k5521 in k5518 in k5515 in k5512 in k5509 in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1112 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[610]);}

/* compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5172,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=(C_word)C_eqp(t5,lf[18]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5182,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_5182(t8,t6);}
else{
t8=(C_word)C_eqp(t5,lf[600]);
if(C_truep(t8)){
t9=t7;
f_5182(t9,t8);}
else{
t9=(C_word)C_eqp(t5,lf[601]);
if(C_truep(t9)){
t10=t7;
f_5182(t10,t9);}
else{
t10=(C_word)C_eqp(t5,lf[602]);
if(C_truep(t10)){
t11=t7;
f_5182(t11,t10);}
else{
t11=(C_word)C_eqp(t5,lf[15]);
if(C_truep(t11)){
t12=t7;
f_5182(t12,t11);}
else{
t12=(C_word)C_eqp(t5,lf[523]);
if(C_truep(t12)){
t13=t7;
f_5182(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[603]);
if(C_truep(t13)){
t14=t7;
f_5182(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[604]);
if(C_truep(t14)){
t15=t7;
f_5182(t15,t14);}
else{
t15=(C_word)C_eqp(t5,lf[605]);
if(C_truep(t15)){
t16=t7;
f_5182(t16,t15);}
else{
t16=(C_word)C_eqp(t5,lf[606]);
if(C_truep(t16)){
t17=t7;
f_5182(t17,t16);}
else{
t17=(C_word)C_eqp(t5,lf[607]);
if(C_truep(t17)){
t18=t7;
f_5182(t18,t17);}
else{
t18=(C_word)C_eqp(t5,lf[608]);
t19=t7;
f_5182(t19,(C_truep(t18)?t18:(C_word)C_eqp(t5,lf[609])));}}}}}}}}}}}}

/* k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5182(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5182,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[560]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5191(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[589]);
if(C_truep(t4)){
t5=t3;
f_5191(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[573]);
if(C_truep(t5)){
t6=t3;
f_5191(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[590]);
if(C_truep(t6)){
t7=t3;
f_5191(t7,t6);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[5],lf[591]);
if(C_truep(t7)){
t8=t3;
f_5191(t8,t7);}
else{
t8=(C_word)C_eqp(((C_word*)t0)[5],lf[592]);
if(C_truep(t8)){
t9=t3;
f_5191(t9,t8);}
else{
t9=(C_word)C_eqp(((C_word*)t0)[5],lf[593]);
if(C_truep(t9)){
t10=t3;
f_5191(t10,t9);}
else{
t10=(C_word)C_eqp(((C_word*)t0)[5],lf[594]);
if(C_truep(t10)){
t11=t3;
f_5191(t11,t10);}
else{
t11=(C_word)C_eqp(((C_word*)t0)[5],lf[595]);
if(C_truep(t11)){
t12=t3;
f_5191(t12,t11);}
else{
t12=(C_word)C_eqp(((C_word*)t0)[5],lf[575]);
if(C_truep(t12)){
t13=t3;
f_5191(t13,t12);}
else{
t13=(C_word)C_eqp(((C_word*)t0)[5],lf[596]);
if(C_truep(t13)){
t14=t3;
f_5191(t14,t13);}
else{
t14=(C_word)C_eqp(((C_word*)t0)[5],lf[597]);
if(C_truep(t14)){
t15=t3;
f_5191(t15,t14);}
else{
t15=(C_word)C_eqp(((C_word*)t0)[5],lf[598]);
t16=t3;
f_5191(t16,(C_truep(t15)?t15:(C_word)C_eqp(((C_word*)t0)[5],lf[599])));}}}}}}}}}}}}}}

/* k5189 in k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5191(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5191,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1077 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[561]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[562]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_5203(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[586]);
if(C_truep(t4)){
t5=t3;
f_5203(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
if(C_truep(t5)){
t6=t3;
f_5203(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[587]);
t7=t3;
f_5203(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[5],lf[588])));}}}}}

/* k5201 in k5189 in k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5203(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5203,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1079 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[563],((C_word*)t0)[5],lf[564],((C_word*)t0)[5],lf[565]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[566]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5215(t4,t2);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[4],lf[582]);
if(C_truep(t4)){
t5=t3;
f_5215(t5,t4);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[4],lf[583]);
if(C_truep(t5)){
t6=t3;
f_5215(t6,t5);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[4],lf[584]);
t7=t3;
f_5215(t7,(C_truep(t6)?t6:(C_word)C_eqp(((C_word*)t0)[4],lf[585])));}}}}}

/* k5213 in k5201 in k5189 in k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5215,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 1081 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[567],((C_word*)t0)[4],lf[568]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm: 1083 ##sys#hash-table-ref */
t3=C_retrieve(lf[580]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[581]),((C_word*)t0)[2]);}
else{
t3=t2;
f_5221(2,t3,C_SCHEME_FALSE);}}}

/* k5219 in k5213 in k5201 in k5189 in k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vectorp(t1);
t3=(C_truep(t2)?(C_word)C_i_vector_ref(t1,C_fix(0)):t1);
/* c-backend.scm: 1085 compute-size */
t4=((C_word*)((C_word*)t0)[6])[1];
f_5172(5,t4,((C_word*)t0)[5],t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_eqp(t2,lf[569]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_5255(t5,t3);}
else{
t5=(C_word)C_eqp(t2,lf[572]);
if(C_truep(t5)){
t6=t4;
f_5255(t6,t5);}
else{
t6=(C_word)C_eqp(t2,lf[573]);
if(C_truep(t6)){
t7=t4;
f_5255(t7,t6);}
else{
t7=(C_word)C_eqp(t2,lf[574]);
if(C_truep(t7)){
t8=t4;
f_5255(t8,t7);}
else{
t8=(C_word)C_eqp(t2,lf[575]);
if(C_truep(t8)){
t9=t4;
f_5255(t9,t8);}
else{
t9=(C_word)C_eqp(t2,lf[576]);
if(C_truep(t9)){
t10=t4;
f_5255(t10,t9);}
else{
t10=(C_word)C_eqp(t2,lf[577]);
if(C_truep(t10)){
t11=t4;
f_5255(t11,t10);}
else{
t11=(C_word)C_eqp(t2,lf[578]);
t12=t4;
f_5255(t12,(C_truep(t11)?t11:(C_word)C_eqp(t2,lf[579])));}}}}}}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k5253 in k5219 in k5213 in k5201 in k5189 in k5180 in compute-size in k5168 in k5162 in k5159 in k5156 in k5153 in a5150 in generate-foreign-callback-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_5255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 1090 string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[570]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[571]);
if(C_truep(t2)){
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 1091 compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5172(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4912,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4918,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4918,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 996  foreign-stub-id */
t4=C_retrieve(lf[559]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4925,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 997  real-name2 */
t3=C_retrieve(lf[558]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 998  foreign-stub-argument-types */
t3=C_retrieve(lf[557]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5143,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1000 make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,lf[556]);}

/* k5141 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5143,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,lf[555],t1);
/* c-backend.scm: 1000 intersperse */
t3=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 1001 foreign-stub-return-type */
t3=C_retrieve(lf[554]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 1002 foreign-stub-name */
t3=C_retrieve(lf[553]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 1003 foreign-stub-body */
t3=C_retrieve(lf[552]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1004 foreign-stub-argument-names */
t3=C_retrieve(lf[551]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_4949(2,t3,t1);}
else{
/* c-backend.scm: 1004 make-list */
t3=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 1005 foreign-result-conversion */
t3=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[9],lf[550]);}

/* k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1006 foreign-stub-cps */
t3=C_retrieve(lf[549]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm: 1007 foreign-stub-callback */
t3=C_retrieve(lf[548]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm: 1008 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4964,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5132,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1010 cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4964(2,t3,C_SCHEME_UNDEFINED);}}

/* k5130 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1010 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[546],t1,lf[547]);}

/* k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm: 1012 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[544],((C_word*)t0)[6],lf[545]);}
else{
t3=t2;
f_4967(2,t3,C_SCHEME_UNDEFINED);}}

/* k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1015 gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t2,C_SCHEME_TRUE,lf[539],((C_word*)t0)[2],lf[540],C_SCHEME_TRUE,lf[541],((C_word*)t0)[2],lf[542]);}
else{
/* c-backend.scm: 1017 gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[543],((C_word*)t0)[2],C_make_character(40));}}

/* k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[3]);}

/* k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm: 1020 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[534],C_SCHEME_TRUE,lf[535],((C_word*)t0)[2],lf[536]);}
else{
/* c-backend.scm: 1021 gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[537],C_SCHEME_TRUE,lf[538],((C_word*)t0)[2],C_make_character(40));}}

/* k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4979,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1023 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[533]);}

/* k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 1024 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[532]);}

/* k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5080,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1033 iota */
t5=C_retrieve(lf[62]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[6]);}

/* k5108 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1025 for-each */
t2=*((C_word*)lf[61]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5079 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5080,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5088,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5100,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* c-backend.scm: 1030 symbol->string */
t7=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t4);}
else{
/* c-backend.scm: 1030 sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[531],t3);}}

/* k5098 in a5079 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1028 foreign-type-declaration */
t2=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5086 in a5079 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1031 foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[530]);}

/* k5090 in k5086 in a5079 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5096,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 1032 foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k5094 in k5090 in k5086 in a5079 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1027 gen */
t2=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t2))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[527],((C_word*)t0)[3],C_make_character(41),t1,lf[528],((C_word*)t0)[2],lf[529]);}

/* k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm: 1034 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[526]);}
else{
t3=t2;
f_4991(2,t3,C_SCHEME_UNDEFINED);}}

/* k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5000,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1036 gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[517]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5021,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_eqp(((C_word*)t0)[5],lf[523]);
if(C_truep(t4)){
/* c-backend.scm: 1047 gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm: 1046 gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,C_SCHEME_TRUE,lf[525],((C_word*)t0)[2]);}}}

/* k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 1048 gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5062,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 1049 make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[524]);}

/* k5060 in k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1049 intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5056 in k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k5025 in k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[523]);
if(C_truep(t3)){
t4=t2;
f_5030(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 1050 gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(41));}}

/* k5028 in k5025 in k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1051 gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[522]);}

/* k5031 in k5028 in k5025 in k5022 in k5019 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1053 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[518],C_SCHEME_TRUE,lf[519]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1055 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[520]);}
else{
/* c-backend.scm: 1056 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[521]);}}}

/* k4998 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 1038 gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[516],C_SCHEME_TRUE);}

/* k5001 in k4998 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 1040 gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[512],C_SCHEME_TRUE,lf[513]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 1042 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[514]);}
else{
/* c-backend.scm: 1043 gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[515]);}}}

/* k4992 in k4989 in k4986 in k4983 in k4980 in k4977 in k4974 in k4971 in k4968 in k4965 in k4962 in k4959 in k4956 in k4953 in k4950 in k4947 in k4944 in k4941 in k4938 in k4935 in k4932 in k4926 in k4923 in k4920 in a4917 in ##compiler#generate-foreign-stubs in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 1057 gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4900,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a4899 in ##compiler#generate-foreign-callback-stub-prototypes in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4904,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 988  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4902 in a4899 in ##compiler#generate-foreign-callback-stub-prototypes in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 989  generate-foreign-callback-header */
t3=C_retrieve(lf[510]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[511],((C_word*)t0)[2]);}

/* k4905 in k4902 in a4899 in ##compiler#generate-foreign-callback-stub-prototypes in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 990  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* ##compiler#generate-external-variables in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4843,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4847,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 975  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k4845 in ##compiler#generate-external-variables in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4852,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a4851 in k4845 in ##compiler#generate-external-variables in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4859,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_vectorp(t2))){
t4=(C_word)C_i_vector_length(t2);
t5=t3;
f_4859(t5,(C_word)C_eqp(t4,C_fix(3)));}
else{
t4=t3;
f_4859(t4,C_SCHEME_FALSE);}}

/* k4857 in a4851 in k4845 in ##compiler#generate-external-variables in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4859,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(0));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(1));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(2));
t5=(C_truep(t4)?lf[508]:lf[509]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4879,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 979  foreign-type-declaration */
t7=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t3,t2);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4877 in k4857 in a4851 in k4845 in ##compiler#generate-external-variables in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 979  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* ##compiler#make-argument-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4827,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4833,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 967  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4832 in ##compiler#make-argument-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4833,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 969  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4839 in a4832 in ##compiler#make-argument-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 969  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4811,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4817,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 962  list-tabulate */
t5=C_retrieve(lf[507]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t4);}

/* a4816 in ##compiler#make-variable-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 964  number->string */
C_number_to_string(3,0,t3,t2);}

/* k4823 in a4816 in ##compiler#make-variable-list in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 964  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[506],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4722,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4731,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4731(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4731(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4731,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[5]))){
t4=((C_word*)((C_word*)t0)[4])[1];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:((C_word*)t0)[3]));}
else{
t4=(C_word)C_i_string_ref(((C_word*)t0)[3],t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4747,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_fixnum_lessp(t4,C_make_character(32));
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4760,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t6)){
t8=t7;
f_4760(t8,t6);}
else{
t8=(C_word)C_fixnum_greaterp(t4,C_make_character(126));
if(C_truep(t8)){
t9=t7;
f_4760(t9,t8);}
else{
t9=(C_word)C_eqp(t4,C_make_character(42));
if(C_truep(t9)){
t10=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t11=t2;
if(C_truep((C_word)C_fixnum_lessp(t11,t10))){
t12=(C_word)C_fixnum_increase(t2);
t13=(C_word)C_i_string_ref(((C_word*)t0)[3],t12);
t14=t7;
f_4760(t14,(C_word)C_eqp(C_make_character(47),t13));}
else{
t12=t7;
f_4760(t12,C_SCHEME_FALSE);}}
else{
t10=t7;
f_4760(t10,C_SCHEME_FALSE);}}}}}

/* k4758 in loop in ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4760(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4760,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=t2;
f_4763(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4770,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 953  string-copy */
t4=C_retrieve(lf[505]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[6];
f_4747(t2,(C_truep(((C_word*)((C_word*)t0)[5])[1])?(C_word)C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],((C_word*)t0)[2]):C_SCHEME_UNDEFINED));}}

/* k4768 in k4758 in loop in ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4763(t3,t2);}

/* k4761 in k4758 in loop in ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4763(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
f_4747(t2,(C_word)C_i_string_set(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_make_character(126)));}

/* k4745 in loop in ##compiler#cleanup in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4747(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* c-backend.scm: 956  loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4731(t3,((C_word*)t0)[2],t2);}

/* emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4649(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4649,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4653,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_length(t2);
t6=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 918  gen */
t7=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t7))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[502],C_SCHEME_TRUE,lf[503],t6,lf[504]);}

/* k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4656,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4667,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4667(t6,t2,((C_word*)t0)[2]);}

/* do570 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4667(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4667,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
/* c-backend.scm: 922  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,lf[495]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
/* c-backend.scm: 923  lambda-literal-id */
t5=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}}

/* k4678 in do570 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4683,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 924  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,lf[500],t1,((C_word*)t0)[2],lf[501]);}

/* k4681 in k4678 in do570 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 927  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[496],C_retrieve(lf[185]),lf[497]);}
else{
/* c-backend.scm: 928  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[498]);}}
else{
/* c-backend.scm: 929  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],lf[499]);}}

/* k4684 in k4681 in k4678 in do570 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_4667(t3,((C_word*)t0)[2],t2);}

/* k4654 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 930  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[494]);}

/* k4657 in k4654 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 931  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[493]);}

/* k4660 in k4657 in k4654 in k4651 in emit-procedure-table-info in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 932  gen */
t2=C_retrieve(lf[2]);
((C_proc15)C_retrieve_proc(t2))(15,t2,((C_word*)t0)[2],lf[486],C_SCHEME_TRUE,lf[487],C_SCHEME_TRUE,lf[488],C_SCHEME_TRUE,lf[489],C_SCHEME_TRUE,lf[490],C_SCHEME_TRUE,lf[491],C_SCHEME_TRUE,lf[492]);}

/* ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[60],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_1140,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1143,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1185,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2612,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2919,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3170,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3857,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3780,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3493,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3658,a[2]=t16,a[3]=t17,tmp=(C_word)a,a+=4,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t2,a[3]=t18,tmp=(C_word)a,a+=4,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3499,a[2]=t17,a[3]=t21,tmp=(C_word)a,a+=4,tmp));
t23=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3869,a[2]=t4,a[3]=t8,a[4]=t21,a[5]=t19,a[6]=t2,a[7]=t10,tmp=(C_word)a,a+=8,tmp);
t24=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4616,a[2]=t11,a[3]=t12,a[4]=t13,a[5]=t8,a[6]=t14,a[7]=t23,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 901  debugging */
t25=C_retrieve(lf[469]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t24,lf[484],lf[485]);}

/* k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4616,2,t0,t1);}
t2=C_mutate((C_word*)lf[1]+1,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4620,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 903  header */
t4=((C_word*)t0)[2];
f_2612(t4,t3);}

/* k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4623,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 904  declarations */
t3=((C_word*)t0)[2];
f_2778(t3,t2);}

/* k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 905  generate-external-variables */
t3=C_retrieve(lf[482]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[483]));}

/* k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4629,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 906  generate-foreign-stubs */
t3=C_retrieve(lf[480]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[481]),((C_word*)t0)[3]);}

/* k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4629,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4632,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 907  prototypes */
t3=((C_word*)t0)[2];
f_2919(t3,t2);}

/* k4630 in k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4635,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 908  generate-foreign-callback-stubs */
t3=C_retrieve(lf[479]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[179]),((C_word*)t0)[2]);}

/* k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4638,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 909  trampolines */
t3=((C_word*)t0)[2];
f_3170(t3,t2);}

/* k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 910  procedures */
t3=((C_word*)t0)[2];
f_3869(t3,t2);}

/* k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 911  emit-procedure-table-info */
t3=C_retrieve(lf[478]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4642 in k4639 in k4636 in k4633 in k4630 in k4627 in k4624 in k4621 in k4618 in k4614 in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm: 483  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,lf[477],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3869,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3875,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3879,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 725  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3879,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 726  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 727  real-name */
t3=C_retrieve(lf[476]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3888,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 728  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[6]);}

/* k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3891,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 729  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}

/* k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 730  lambda-literal-customizable */
t5=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[8]);}

/* k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4613,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 731  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_3897(t3,C_SCHEME_FALSE);}}

/* k4611 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3897(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3897,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_fix(1):C_fix(0));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[13],t2);
t4=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 733  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[13],lf[475]);}

/* k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3906,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm: 734  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[13],lf[474]);}

/* k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3909,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 735  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3909,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3912,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[4])?(C_word)C_i_cdr(((C_word*)t0)[2]):((C_word*)t0)[2]);
/* c-backend.scm: 736  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,C_make_character(44));}

/* k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3915,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm: 737  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[12]);}

/* k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm: 738  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[13]);}

/* k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm: 739  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_3924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm: 740  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[15]);}

/* k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3924,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t1,a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm: 741  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[16]);}

/* k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 743  string-append */
t3=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_retrieve(lf[185]),lf[472]);}
else{
t3=t2;
f_3930(2,t3,lf[473]);}}

/* k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3933,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 745  debugging */
t3=C_retrieve(lf[469]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[470],lf[471],((C_word*)t0)[14]);}
else{
t3=t2;
f_3933(2,t3,C_SCHEME_UNDEFINED);}}

/* k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_3936,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm: 746  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4582,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 747  cleanup */
t4=C_retrieve(lf[468]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k4580 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 747  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],lf[466],t1,lf[467],C_SCHEME_TRUE);}

/* k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3942,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4565,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 756  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[460]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4543,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[14],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 749  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[465]);}}

/* k4541 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[463]:lf[464]);
/* c-backend.scm: 750  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k4544 in k4541 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4549,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 752  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[461]);}
else{
/* c-backend.scm: 753  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[462]);}}

/* k4547 in k4544 in k4541 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 754  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4563 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4568(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 758  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[459]);}}

/* k4566 in k4563 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 759  gen */
t2=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t2))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[453],C_SCHEME_TRUE,lf[454],C_SCHEME_TRUE,lf[455],C_SCHEME_TRUE,lf[456],((C_word*)t0)[2],lf[457],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[458],((C_word*)t0)[2]);}

/* k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 764  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)t0)[10])){
t3=t2;
f_3948(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 765  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[452]);}}

/* k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4515,a[2]=t2,a[3]=((C_word*)t0)[15],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
t4=(C_word)C_eqp(((C_word*)t0)[17],C_fix(0));
t5=t3;
f_4515(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4515(t4,C_SCHEME_FALSE);}}

/* k4513 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4515(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4515,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 767  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[451]);}
else{
t2=((C_word*)t0)[2];
f_3951(2,t2,C_SCHEME_UNDEFINED);}}

/* k4516 in k4513 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 768  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_3951(2,t2,C_SCHEME_UNDEFINED);}}

/* k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[15]);}

/* k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 770  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[450]);}
else{
t3=t2;
f_3957(2,t3,C_SCHEME_UNDEFINED);}}

/* k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 771  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[449]);}

/* k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[13],lf[224]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[21],0,C_SCHEME_FALSE);
t5=t2;
f_3963(t5,t4);}
else{
t4=t2;
f_3963(t4,C_SCHEME_UNDEFINED);}}

/* k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3963,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm: 773  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[448]);}

/* k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_3969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
/* c-backend.scm: 775  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[446],((C_word*)t0)[20],C_make_character(59));}
else{
t3=(C_truep(((C_word*)t0)[2])?(C_word)C_fixnum_decrease(((C_word*)t0)[20]):C_fix(0));
t4=(C_word)C_fixnum_plus(((C_word*)t0)[16],t3);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4477,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4477(t8,t2,((C_word*)t0)[20],t4);}}

/* do457 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4477(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4477,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4487,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 779  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[447],t2,C_make_character(59));}}

/* k4485 in do457 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4477(t4,((C_word*)t0)[2],t2,t3);}

/* k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3972,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[18],a[13]=((C_word*)t0)[19],a[14]=((C_word*)t0)[20],a[15]=((C_word*)t0)[21],a[16]=((C_word*)t0)[22],tmp=(C_word)a,a+=17,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4189,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4264,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 781  fold */
t6=C_retrieve(lf[413]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[7]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4278,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 815  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_SCHEME_TRUE,lf[427]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4342,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[17],a[8]=((C_word*)t0)[2],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4420,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[17],a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t6=((C_word*)t0)[9];
if(C_truep(t6)){
t7=t5;
f_4420(t7,C_SCHEME_FALSE);}
else{
t7=((C_word*)t0)[17];
t8=t5;
f_4420(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}

/* k4418 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4420,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[5])){
/* c-backend.scm: 829  gen */
t2=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t2))(10,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[437],C_SCHEME_TRUE,lf[438],C_SCHEME_TRUE,lf[439],((C_word*)t0)[3],lf[440]);}
else{
/* c-backend.scm: 832  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[441],((C_word*)t0)[3],lf[442]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4432(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 834  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[445]);}}}

/* k4430 in k4418 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4435,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 835  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[444]);}
else{
t3=t2;
f_4435(2,t3,C_SCHEME_UNDEFINED);}}

/* k4433 in k4430 in k4418 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4441,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_retrieve(lf[104]);
t4=t2;
f_4441(t4,(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_i_not(C_retrieve(lf[407]))));}
else{
t3=t2;
f_4441(t3,C_SCHEME_FALSE);}}

/* k4439 in k4433 in k4430 in k4418 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 837  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[443]);}
else{
t2=((C_word*)t0)[2];
f_4342(2,t2,C_SCHEME_UNDEFINED);}}

/* k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4345,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4384,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4384(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
t6=t3;
f_4384(t6,(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_4384(t4,C_SCHEME_FALSE);}}

/* k4382 in k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[4],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(2)))){
/* c-backend.scm: 841  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,((C_word*)t0)[2],C_SCHEME_TRUE,lf[431],((C_word*)t0)[3],lf[432],((C_word*)t0)[3],lf[433]);}
else{
t4=((C_word*)t0)[2];
f_4345(2,t4,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm: 842  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[434],((C_word*)t0)[3],lf[435],((C_word*)t0)[3],lf[436]);}}
else{
t2=((C_word*)t0)[2];
f_4345(2,t2,C_SCHEME_UNDEFINED);}}

/* k4343 in k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4351,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_4351(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=t2;
f_4351(t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[4];
t5=t2;
f_4351(t5,(C_word)C_fixnum_greaterp(t4,C_fix(0)));}}}

/* k4349 in k4343 in k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4351(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4351,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 844  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[430]);}
else{
t3=t2;
f_4354(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[4];
f_3972(2,t2,C_SCHEME_UNDEFINED);}}

/* k4352 in k4349 in k4343 in k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=((C_word*)t0)[2];
t4=t2;
f_4360(t4,(C_word)C_fixnum_greaterp(t3,C_fix(0)));}
else{
t3=t2;
f_4360(t3,C_SCHEME_FALSE);}}

/* k4358 in k4352 in k4349 in k4343 in k4340 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4360(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 846  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[428]);}
else{
/* c-backend.scm: 847  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[429]);}}

/* k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 816  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[426]);}

/* k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 817  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[425]);}

/* k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
t4=(C_word)C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 819  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(116),t4);}
else{
/* c-backend.scm: 820  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,lf[424]);}}

/* k4285 in k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4290,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 821  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[422],((C_word*)t0)[3],lf[423]);}

/* k4288 in k4285 in k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4293,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4305,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve(lf[104]);
if(C_truep(t4)){
t5=t3;
f_4305(t5,C_SCHEME_FALSE);}
else{
t5=C_retrieve(lf[421]);
if(C_truep(t5)){
t6=t3;
f_4305(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)t0)[3];
t7=(C_word)C_fixnum_greaterp(t6,C_fix(2));
t8=t3;
f_4305(t8,(C_truep(t7)?(C_word)C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k4303 in k4288 in k4285 in k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4305(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 823  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[418],((C_word*)t0)[2],lf[419],((C_word*)t0)[2],lf[420]);}
else{
t2=((C_word*)t0)[3];
f_4293(2,t2,C_SCHEME_UNDEFINED);}}

/* k4291 in k4288 in k4285 in k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[416]))){
/* c-backend.scm: 824  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[417]);}
else{
t3=t2;
f_4296(2,t3,C_SCHEME_UNDEFINED);}}

/* k4294 in k4291 in k4288 in k4285 in k4282 in k4279 in k4276 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 825  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[414],((C_word*)t0)[2],lf[415]);}

/* a4263 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4264(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4264,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4272,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 781  literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3499(3,t5,t4,t2);}

/* k4270 in a4263 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4195,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 783  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[409],C_SCHEME_TRUE,lf[410],C_SCHEME_TRUE,lf[411],((C_word*)t0)[2],lf[412]);}

/* k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[407]))){
/* c-backend.scm: 787  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[408]);}
else{
t3=t2;
f_4198(2,t3,C_SCHEME_UNDEFINED);}}

/* k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4201,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve(lf[185]))){
t3=t2;
f_4201(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4232,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[400]))){
/* c-backend.scm: 790  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[401],C_retrieve(lf[400]),lf[402]);}
else{
if(C_truep(C_retrieve(lf[403]))){
/* c-backend.scm: 792  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t3,C_SCHEME_TRUE,lf[404],C_retrieve(lf[403]),lf[405],C_SCHEME_TRUE,lf[406]);}
else{
t4=t3;
f_4232(2,t4,C_SCHEME_UNDEFINED);}}}}

/* k4230 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[398]))){
/* c-backend.scm: 795  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[399],C_retrieve(lf[398]),C_make_character(59));}
else{
t3=t2;
f_4235(2,t3,C_SCHEME_UNDEFINED);}}

/* k4233 in k4230 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[396]))){
/* c-backend.scm: 797  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[397],C_retrieve(lf[396]),C_make_character(59));}
else{
t3=t2;
f_4238(2,t3,C_SCHEME_UNDEFINED);}}

/* k4236 in k4233 in k4230 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[393]))){
/* c-backend.scm: 799  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[394],C_retrieve(lf[393]),lf[395]);}
else{
t2=((C_word*)t0)[2];
f_4201(2,t2,C_SCHEME_UNDEFINED);}}

/* k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4204,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 800  gen */
t3=C_retrieve(lf[2]);
((C_proc16)C_retrieve_proc(t3))(16,t3,t2,C_SCHEME_TRUE,lf[386],((C_word*)t0)[3],lf[387],C_SCHEME_TRUE,lf[388],((C_word*)t0)[3],lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],C_SCHEME_TRUE,lf[392]);}

/* k4202 in k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 805  gen */
t3=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t3))(14,t3,t2,C_SCHEME_TRUE,lf[380],((C_word*)t0)[2],lf[381],C_SCHEME_TRUE,lf[382],C_SCHEME_TRUE,lf[383],((C_word*)t0)[2],lf[384],C_SCHEME_TRUE,lf[385]);}

/* k4205 in k4202 in k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 809  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[378],((C_word*)t0)[2],lf[379]);}

/* k4208 in k4205 in k4202 in k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4210,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[4],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3972(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 811  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[376],((C_word*)t0)[4],lf[377]);}}

/* k4217 in k4208 in k4205 in k4202 in k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 812  literal-frame */
t3=((C_word*)t0)[2];
f_3456(t3,t2);}

/* k4220 in k4217 in k4208 in k4205 in k4202 in k4199 in k4196 in k4193 in k4187 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 813  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[374],((C_word*)t0)[2],lf[375]);}

/* k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3975,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[16],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3995,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=t2,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[15],tmp=(C_word)a,a+=13,tmp);
t4=(C_word)C_eqp(lf[235],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=t3;
f_3995(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_3995(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[15])[1];
if(C_truep(t6)){
t7=t3;
f_3995(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=t3;
f_3995(t7,((C_word*)t0)[2]);}
else{
t7=((C_word*)t0)[11];
t8=t3;
f_3995(t8,(C_word)C_fixnum_greaterp(t7,C_fix(0)));}}}}}

/* k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3995(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3995,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[12])[1])){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[365]:lf[366]);
/* c-backend.scm: 858  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,t2,C_SCHEME_TRUE,t4,lf[367],((C_word*)t0)[9],C_make_character(114));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4130,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_fixnum_greaterp(((C_word*)t0)[4],C_fix(0));
t4=(C_truep(t3)?lf[371]:lf[372]);
/* c-backend.scm: 884  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,C_SCHEME_TRUE,t4,lf[373]);}}
else{
t2=((C_word*)t0)[10];
f_3975(2,t2,C_SCHEME_UNDEFINED);}}

/* k4128 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4133,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm: 886  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[369]);}
else{
/* c-backend.scm: 887  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],lf[370],((C_word*)t0)[3]);}}

/* k4131 in k4128 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4136,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 889  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4136(2,t3,C_SCHEME_UNDEFINED);}}

/* k4143 in k4131 in k4128 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4134 in k4131 in k4128 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 891  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[368]);}

/* k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[4],lf[309]);
if(C_truep(t3)){
/* c-backend.scm: 859  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,C_make_character(118));}
else{
t4=t2;
f_4004(2,t4,C_SCHEME_UNDEFINED);}}

/* k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 860  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[363],((C_word*)t0)[5],lf[364]);}

/* k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep((C_word)C_fixnum_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 862  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_4010(2,t3,C_SCHEME_UNDEFINED);}}

/* k4109 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 864  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,lf[359],C_SCHEME_TRUE,lf[360],C_SCHEME_TRUE,lf[361],((C_word*)t0)[6],lf[362]);}

/* k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],lf[354]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[2],C_SCHEME_FALSE));
if(C_truep(t4)){
/* c-backend.scm: 868  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,C_SCHEME_TRUE,lf[355],((C_word*)t0)[6],lf[356]);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[2],lf[309]);
if(C_truep(t5)){
/* c-backend.scm: 869  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t2,C_SCHEME_TRUE,lf[357],((C_word*)t0)[6],lf[358]);}
else{
t6=t2;
f_4016(2,t6,C_SCHEME_UNDEFINED);}}}

/* k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 870  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[353]);}

/* k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4080,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4084,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 871  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[352]);}

/* k4082 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 871  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4078 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4025,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 872  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[350],((C_word*)t0)[5],lf[351]);}

/* k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4028,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 874  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[348],((C_word*)t0)[2],lf[349]);}

/* k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 876  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[346],((C_word*)t0)[3],lf[347]);}

/* k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 877  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[345]);}

/* k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4040,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4055(t7,t2,t3,((C_word*)t0)[2]);}

/* do501 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4055,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4065,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 881  gen */
t6=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,C_SCHEME_TRUE,lf[344],t2,C_make_character(59));}}

/* k4063 in do501 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4055(t4,((C_word*)t0)[2],t2,t3);}

/* k4038 in k4035 in k4032 in k4029 in k4026 in k4023 in k4020 in k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3993 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
/* c-backend.scm: 882  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[342],((C_word*)t0)[3],lf[343]);}
else{
t3=((C_word*)t0)[2];
f_3975(2,t3,C_SCHEME_UNDEFINED);}}

/* k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3978,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3985,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 893  lambda-literal-body */
t4=C_retrieve(lf[341]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3983 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(C_word)C_fixnum_increase(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 892  expression */
t3=((C_word*)t0)[4];
f_1185(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k3976 in k3973 in k3970 in k3967 in k3964 in k3961 in k3958 in k3955 in k3952 in k3949 in k3946 in k3943 in k3940 in k3937 in k3934 in k3931 in k3928 in k3925 in k3922 in k3919 in k3916 in k3913 in k3910 in k3907 in k3904 in k3901 in k3895 in k3892 in k3889 in k3886 in k3883 in k3880 in k3877 in a3874 in procedures in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 898  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3499,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 661  immediate? */
t4=C_retrieve(lf[340]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3506,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_stringp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_i_numberp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[334]));}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 665  literal-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3499(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_i_vectorp(((C_word*)t0)[4]))){
t2=(C_word)C_i_vector_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3566,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3574,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 666  vector->list */
t6=*((C_word*)lf[337]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 667  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}}}}

/* k3578 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3580,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[4]))){
/* c-backend.scm: 668  bad-literal */
f_3493(((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep((C_word)C_lambdainfop(((C_word*)t0)[4]))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3598,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 670  ##sys#bytevector? */
t3=*((C_word*)lf[339]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}}}

/* k3596 in k3578 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3598,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_block_size(((C_word*)t0)[4]);
/* c-backend.scm: 670  words */
t4=C_retrieve(lf[338]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
if(C_truep((C_word)C_structurep(((C_word*)t0)[4]))){
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(C_word)C_fixnum_plus(C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_3627(t7,((C_word*)t0)[5],C_fix(0),t3);}
else{
/* c-backend.scm: 677  bad-literal */
f_3493(((C_word*)t0)[5],((C_word*)t0)[4]);}}}

/* loop in k3596 in k3578 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3627,NULL,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t4,((C_word*)t0)[5]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t5=(C_word)C_fixnum_increase(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3649,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm: 676  literal-size */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3499(3,t8,t6,t7);}}

/* k3647 in loop in k3596 in k3578 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[5],t1);
/* c-backend.scm: 676  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3627(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3603 in k3596 in k3578 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus(C_fix(2),t1));}

/* k3572 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3568 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 666  reduce */
t2=C_retrieve(lf[335]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],*((C_word*)lf[336]+1),C_fix(0),t1);}

/* k3564 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(1),((C_word*)t0)[2]),t1));}

/* k3535 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3541,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm: 665  literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3499(3,t4,t2,t3);}

/* k3539 in k3535 in k3504 in literal-size in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_plus((C_word)C_fixnum_plus(C_fix(3),((C_word*)t0)[2]),t1));}

/* literal-frame in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3456,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3462,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3462(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* do389 in literal-frame in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3462(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3462,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3491,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 655  sprintf */
t7=C_retrieve(lf[332]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,lf[333],t2);}}

/* k3489 in do389 in literal-frame in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 655  gen-lit */
t2=((C_word*)t0)[4];
f_3658(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3470 in do389 in literal-frame in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3462(t4,((C_word*)t0)[2],t2,t3);}

/* gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3658(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3658,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3778,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 681  big-fixnum? */
t6=C_retrieve(lf[331]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t2);}
else{
t5=t4;
f_3665(t5,C_SCHEME_FALSE);}}

/* k3776 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3665(t2,(C_word)C_i_not(t1));}

/* k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3665(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3665,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm: 682  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[5],lf[316],((C_word*)t0)[4],lf[317]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 683  block-variable-literal? */
t3=C_retrieve(lf[330]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}}

/* k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3671,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_retrieve(lf[0]);
t3=(C_word)C_eqp(((C_word*)t0)[5],t2);
if(C_truep(t3)){
/* c-backend.scm: 685  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[318]);}
else{
if(C_truep((C_word)C_booleanp(((C_word*)t0)[5]))){
t4=(C_truep(((C_word*)t0)[5])?lf[319]:lf[320]);
/* c-backend.scm: 687  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(61),t4,C_make_character(59));}
else{
if(C_truep((C_word)C_charp(((C_word*)t0)[5]))){
t4=(C_word)C_fix((C_word)C_character_code(((C_word*)t0)[5]));
/* c-backend.scm: 689  gen */
t5=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[321],t4,lf[322]);}
else{
if(C_truep((C_word)C_i_symbolp(((C_word*)t0)[5]))){
t4=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 692  c-ify-string */
t6=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[5]))){
/* c-backend.scm: 697  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[6],C_SCHEME_TRUE,((C_word*)t0)[4],lf[326]);}
else{
if(C_truep((C_word)C_immp(((C_word*)t0)[5]))){
/* c-backend.scm: 698  bad-literal */
f_3493(((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t4=(C_word)C_lambdainfop(((C_word*)t0)[5]);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3754,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 701  gen */
t6=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,C_SCHEME_TRUE,((C_word*)t0)[4],lf[329]);}}}}}}}}}

/* k3752 in k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3764,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 702  encode-literal */
t4=C_retrieve(lf[328]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3762 in k3752 in k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 702  gen-string-constant */
t2=((C_word*)t0)[3];
f_3780(t2,((C_word*)t0)[2],t1);}

/* k3755 in k3752 in k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 703  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[327]);}

/* k3719 in k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3727,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 694  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[325]);}

/* k3725 in k3719 in k3669 in k3663 in gen-lit in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 695  gen */
t2=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[5],lf[323],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[324]);}

/* bad-literal in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3493(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3493,NULL,2,t1,t2);}
/* c-backend.scm: 658  bomb */
t3=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,lf[315],t2);}

/* gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3780,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3787,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 707  fx/ */
t5=*((C_word*)lf[314]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t3,C_fix(80));}

/* k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3790,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 708  modulo */
t3=*((C_word*)lf[313]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3795,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3795(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3795(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3795,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(C_word)C_eqp(((C_word*)t0)[6],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3811,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3811(t7,t5);}
else{
t7=(C_word)C_eqp(((C_word*)t0)[3],C_fix(0));
t8=t6;
f_3811(t8,(C_word)C_i_not(t7));}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3832,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3851,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(t3,C_fix(80));
/* c-backend.scm: 714  string-like-substring */
f_3857(t7,((C_word*)t0)[4],t3,t8);}}

/* k3849 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 714  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3845 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 714  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k3830 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3795(t4,((C_word*)t0)[2],t2,t3);}

/* k3809 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3811(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3811,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3818,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3822,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 713  string-like-substring */
f_3857(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3820 in k3809 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 713  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3816 in k3809 in do418 in k3788 in k3785 in gen-string-constant in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 713  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* string-like-substring in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3857(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3857,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_fixnum_difference(t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3864,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 718  make-string */
t7=*((C_word*)lf[312]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k3862 in string-like-substring in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3867,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 719  ##sys#copy-bytes */
t3=C_retrieve(lf[311]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k3865 in k3862 in string-like-substring in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3170,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3173,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3289,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t9,a[6]=t7,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3337,a[2]=t3,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t12=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,((C_word*)t0)[2]);}

/* a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3337(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3337,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3341,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 614  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3341,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 615  lambda-literal-rest-argument */
t5=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 616  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3350,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 617  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3353,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 618  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3454,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 619  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_3356(t3,C_SCHEME_FALSE);}}

/* k3452 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3356(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3356(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3356,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3359,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_decrease(((C_word*)((C_word*)t0)[10])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[10])+1,t3);
t5=t2;
f_3359(t5,t4);}
else{
t3=t2;
f_3359(t3,C_SCHEME_UNDEFINED);}}

/* k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3359(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3359,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3365,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 621  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3365,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[12];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
if(C_truep(((C_word*)t0)[11])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3371,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[12],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 623  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[305],((C_word*)t0)[9],lf[306],C_SCHEME_TRUE,lf[307],((C_word*)t0)[9],lf[308]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3399(2,t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 631  lambda-literal-allocated */
t4=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k3441 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_3399(2,t3,t2);}
else{
/* c-backend.scm: 631  lambda-literal-external */
t3=C_retrieve(lf[310]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k3397 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_eqp(((C_word*)t0)[8],lf[224]);
t4=t2;
f_3405(t4,(C_word)C_i_not(t3));}
else{
t3=t2;
f_3405(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3403 in k3397 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3405,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 634  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3419,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 635  lset-adjoin */
t4=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[4])[1]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 636  lset-adjoin */
t3=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3421 in k3403 in k3397 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3417 in k3403 in k3397 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3413 in k3403 in k3397 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 625  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[303],((C_word*)t0)[3],lf[304]);}

/* k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 626  restore */
f_3173(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3375 in k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3380,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 627  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k3378 in k3375 in k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3383,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 628  make-argument-list */
t3=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[302]);}

/* k3381 in k3378 in k3375 in k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3393,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 629  intersperse */
t4=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,t1,C_make_character(44));}

/* k3391 in k3381 in k3378 in k3375 in k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3384 in k3381 in k3378 in k3375 in k3372 in k3369 in k3363 in k3357 in k3354 in k3351 in k3348 in k3345 in k3342 in k3339 in a3336 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 630  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[301]);}

/* k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3292,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3308,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3308(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3308,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3312,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 640  gen */
t4=C_retrieve(lf[2]);
((C_proc13)C_retrieve_proc(t4))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[296],t2,lf[297],C_SCHEME_TRUE,lf[298],t2,lf[299],t2,lf[300]);}

/* k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 642  gen */
t3=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t3))(8,t3,t2,C_SCHEME_TRUE,lf[293],((C_word*)t0)[3],lf[294],((C_word*)t0)[3],lf[295]);}

/* k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3318,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 643  restore */
f_3173(t2,((C_word*)t0)[3]);}

/* k3316 in k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 644  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],C_make_character(44));}

/* k3319 in k3316 in k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3324,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3331,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3335,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 645  make-argument-list */
t5=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[291]);}

/* k3333 in k3319 in k3316 in k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 645  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3329 in k3319 in k3316 in k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3322 in k3319 in k3316 in k3313 in k3310 in a3307 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 646  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[290]);}

/* k3290 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3306,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 648  emitter */
t4=((C_word*)t0)[3];
f_3209(t4,t3,C_SCHEME_FALSE);}

/* k3304 in k3290 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3293 in k3290 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 649  emitter */
t3=((C_word*)t0)[2];
f_3209(t3,t2,C_SCHEME_TRUE);}

/* k3300 in k3293 in k3290 in k3287 in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* emitter in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3209(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3209,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_3211 in emitter in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3211,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[285]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[286]);
/* c-backend.scm: 592  gen */
t6=C_retrieve(lf[2]);
((C_proc14)C_retrieve_proc(t6))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[287],t2,C_make_character(114),t4,lf[288],C_SCHEME_TRUE,lf[289],t2,C_make_character(114),t5);}

/* k3213 */
static void C_ccall f_3215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 594  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[283],((C_word*)t0)[4],lf[284]);}

/* k3216 in k3213 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 595  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[282],((C_word*)t0)[4],C_make_character(114));}

/* k3219 in k3216 in k3213 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm: 596  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_3224(2,t3,C_SCHEME_UNDEFINED);}}

/* k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3227,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 597  gen */
t3=C_retrieve(lf[2]);
((C_proc11)C_retrieve_proc(t3))(11,t3,t2,lf[278],((C_word*)t0)[4],lf[279],C_SCHEME_TRUE,lf[280],C_SCHEME_TRUE,lf[281],((C_word*)t0)[4],C_make_character(59));}

/* k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3227,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 600  restore */
f_3173(t2,((C_word*)t0)[4]);}

/* k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 601  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[277]);}

/* k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 603  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[275]);}
else{
/* c-backend.scm: 604  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[276]);}}

/* k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 605  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[274]);}

/* k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 606  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[273]);}
else{
t3=t2;
f_3242(2,t3,C_SCHEME_UNDEFINED);}}

/* k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 607  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[272]);}

/* k3243 in k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 608  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[271]);}

/* k3246 in k3243 in k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3251,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3258,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
/* c-backend.scm: 609  make-argument-list */
t6=C_retrieve(lf[269]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,lf[270]);}

/* k3260 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 609  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k3256 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k3249 in k3246 in k3243 in k3240 in k3237 in k3234 in k3231 in k3228 in k3225 in k3222 in k3219 in k3216 in k3213 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 610  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[268]);}

/* restore in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3173(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3173,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_fixnum_difference(t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3186,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_3186(t8,t3,t4,C_fix(0));}

/* do338 in restore in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3186(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3186,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3196,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 587  gen */
t5=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t5))(8,t5,t4,C_SCHEME_TRUE,lf[265],t2,lf[266],t3,lf[267]);}}

/* k3194 in do338 in restore in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_difference(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3186(t4,((C_word*)t0)[2],t2,t3);}

/* k3175 in restore in trampolines in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 588  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[263],((C_word*)t0)[2],lf[264]);}

/* prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2919(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2919,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2923,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 516  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2947,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2951,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 519  lambda-literal-argument-count */
t4=C_retrieve(lf[262]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 520  lambda-literal-customizable */
t3=C_retrieve(lf[261]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3168,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 521  lambda-literal-closure-size */
t4=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_2957(t3,C_SCHEME_FALSE);}}

/* k3166 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2957(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2957,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(t1)?(C_word)C_fixnum_decrease(((C_word*)t0)[5]):((C_word*)t0)[5]);
/* c-backend.scm: 522  make-variable-list */
t5=C_retrieve(lf[259]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,lf[260]);}

/* k3152 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 522  intersperse */
t2=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 523  lambda-literal-id */
t3=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 524  lambda-literal-rest-argument */
t3=C_retrieve(lf[258]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 525  lambda-literal-rest-argument-mode */
t3=C_retrieve(lf[257]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 526  lambda-literal-direct */
t3=C_retrieve(lf[256]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 527  lambda-literal-allocated */
t3=C_retrieve(lf[255]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t3=((C_word*)t0)[8];
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3146,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(((C_word*)t0)[8]);
/* c-backend.scm: 529  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[3])[1],t6);}
else{
t5=t2;
f_2978(t5,C_SCHEME_UNDEFINED);}}

/* k3144 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2978(t3,t2);}

/* k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2978(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2978,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm: 530  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3139,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 535  lambda-literal-callee-signatures */
t5=C_retrieve(lf[254]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k3137 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3119 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3120,3,t0,t1,t2);}
t3=t2;
t4=C_retrieve(lf[251]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3131,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_fixnum_increase(t2);
/* c-backend.scm: 534  lset-adjoin */
t7=C_retrieve(lf[252]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t5,*((C_word*)lf[253]+1),((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* k3129 in a3119 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_eqp(lf[235],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 545  string-append */
t5=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[185]),lf[242]);}
else{
t5=t4;
f_3096(2,t5,lf[243]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 537  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[249],((C_word*)t0)[5],lf[250],C_SCHEME_TRUE);}}

/* k3069 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 538  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[248]);}

/* k3072 in k3069 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3074,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(((C_word*)t0)[2])?lf[246]:lf[247]);
/* c-backend.scm: 539  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k3075 in k3072 in k3069 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm: 541  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[244]);}
else{
/* c-backend.scm: 542  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[245]);}}

/* k3078 in k3075 in k3072 in k3069 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 543  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3094 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3099,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 546  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,lf[240],t1,lf[241],C_SCHEME_TRUE);}

/* k3097 in k3094 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve(lf[238]))){
/* c-backend.scm: 548  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[239],C_SCHEME_TRUE);}
else{
t3=t2;
f_3102(2,t3,C_SCHEME_UNDEFINED);}}

/* k3100 in k3097 in k3094 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 549  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[237]);}

/* k3103 in k3100 in k3097 in k3094 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 550  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[236],((C_word*)t0)[2]);}

/* k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 551  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(40));}

/* k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2993(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 552  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[234]);}}

/* k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2996,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3043,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
t5=t3;
f_3043(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_3043(t4,C_SCHEME_FALSE);}}

/* k3041 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_3043(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3043,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 554  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[233]);}
else{
t2=((C_word*)t0)[2];
f_2996(2,t2,C_SCHEME_UNDEFINED);}}

/* k3044 in k3041 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 555  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2996(2,t2,C_SCHEME_UNDEFINED);}}

/* k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[4]);}

/* k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 558  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[231]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3031,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 566  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(41));}}

/* k3029 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3034(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 568  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[232]);}}

/* k3032 in k3029 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 569  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3003 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],lf[224]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3014,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 561  gen */
t4=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t4))(10,t4,t3,C_SCHEME_TRUE,lf[227],((C_word*)t0)[2],lf[228],C_SCHEME_TRUE,lf[229],((C_word*)t0)[2],lf[230]);}}

/* k3012 in k3003 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3017,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,C_retrieve(lf[2]),((C_word*)t0)[2]);}

/* k3015 in k3012 in k3003 in k2997 in k2994 in k2991 in k2988 in k2985 in k2982 in k2979 in k2976 in k2973 in k2970 in k2967 in k2964 in k2961 in k2958 in k2955 in k2952 in k2949 in a2946 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* c-backend.scm: 564  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[225],t2,lf[226]);}

/* k2924 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2931,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a2930 in k2924 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2931,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2935,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 573  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,lf[222],t2,lf[223]);}

/* k2933 in a2930 in k2924 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2938,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 574  make-list */
t4=C_retrieve(lf[220]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[221]);}

/* k2943 in k2933 in a2930 in k2924 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_retrieve(lf[2]),t1);}

/* k2936 in k2933 in a2930 in k2924 in k2921 in prototypes in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 575  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[219]);}

/* declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2778(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2778,NULL,2,t0,t1);}
t2=(C_word)C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 487  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[218]);}

/* k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2788,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2913,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[187]));}

/* a2912 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2913,3,t0,t1,t2);}
/* c-backend.scm: 490  gen */
t3=C_retrieve(lf[2]);
((C_proc10)C_retrieve_proc(t3))(10,t3,t1,C_SCHEME_TRUE,lf[214],t2,lf[215],C_SCHEME_TRUE,lf[216],t2,lf[217]);}

/* k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_eqp(((C_word*)t0)[2],C_fix(0));
if(C_truep(t3)){
t4=t2;
f_2791(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 494  gen */
t4=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[212],((C_word*)t0)[2],lf[213]);}}

/* k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 495  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_SCHEME_TRUE,lf[211]);}

/* k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2799,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2799(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2799(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2799,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2809,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* c-backend.scm: 499  ##sys#lambda-info->string */
t6=C_retrieve(lf[210]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}}

/* k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(C_word)C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2815,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_fixnum_shift_right(t2,C_fix(16));
t5=(C_word)C_fixnum_shift_right(t2,C_fix(8));
t6=(C_word)C_fixnum_and(C_fix(255),t5);
t7=(C_word)C_fixnum_and(C_fix(255),t2);
/* c-backend.scm: 501  gen */
t8=C_retrieve(lf[2]);
((C_proc12)C_retrieve_proc(t8))(12,t8,t3,C_SCHEME_TRUE,lf[208],((C_word*)t0)[5],lf[209],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2860(t6,t2,C_fix(0));}

/* do274 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2860(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2860,NULL,3,t0,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2870,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_string_ref(((C_word*)t0)[2],t2);
t6=(C_word)C_fix((C_word)C_character_code(t5));
/* c-backend.scm: 508  gen */
t7=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,C_make_character(44),t6);}}

/* k2868 in do274 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2860(t3,((C_word*)t0)[2],t2);}

/* k2816 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2821,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_fixnum_modulo(((C_word*)t0)[2],C_fix(8));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2841,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_2841(t7,t2,t3);}

/* do279 in k2816 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2841(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2841,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2851,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 511  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[207]);}}

/* k2849 in do279 in k2816 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2841(t3,((C_word*)t0)[2],t2);}

/* k2819 in k2816 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 512  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[206]);}

/* k2822 in k2819 in k2816 in k2813 in k2807 in do268 in k2792 in k2789 in k2786 in k2783 in declarations in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2799(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2612,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2615,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2632,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2770,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 457  current-seconds */
t5=C_retrieve(lf[205]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k2768 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 457  ##sys#decode-seconds */
t2=C_retrieve(lf[204]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2632,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2638,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_2638(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_2638(t3,C_SCHEME_FALSE);}}

/* k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2638,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(2));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t5=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t6=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2656,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_fixnum_plus(C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2715,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(C_word)C_fixnum_increase(t5);
/* c-backend.scm: 461  pad0 */
f_2615(t9,t10);}
else{
/* ##sys#match-error */
t2=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 461  pad0 */
f_2615(t2,((C_word*)t0)[2]);}

/* k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2719,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 461  pad0 */
f_2615(t2,((C_word*)t0)[2]);}

/* k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2727,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 461  pad0 */
f_2615(t2,((C_word*)t0)[2]);}

/* k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2727,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2731,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2735,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2737,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2745,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2749,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 464  chicken-version */
t7=C_retrieve(lf[202]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_TRUE);}

/* k2747 in k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 464  string-split */
t2=C_retrieve(lf[200]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[201]);}

/* k2743 in k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[199]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2736 in k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2737(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2737,3,t0,t1,t2);}
/* string-append */
t3=*((C_word*)lf[175]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t1,lf[197],t2,lf[198]);}

/* k2733 in k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 462  string-intersperse */
t2=C_retrieve(lf[195]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[196]);}

/* k2729 in k2725 in k2721 in k2717 in k2713 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 459  gen */
t2=C_retrieve(lf[2]);
((C_proc21)C_retrieve_proc(t2))(21,t2,((C_word*)t0)[8],lf[190],((C_word*)t0)[7],lf[191],C_SCHEME_TRUE,lf[192],C_SCHEME_TRUE,lf[193],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[194]);}

/* k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 467  gen-list */
t3=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[189]));}

/* k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 468  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_SCHEME_TRUE);}

/* k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[185]))){
/* c-backend.scm: 469  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[186],C_retrieve(lf[185]));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 471  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[188]);}}

/* k2702 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 472  gen-list */
t2=C_retrieve(lf[6]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[187]));}

/* k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 473  gen */
t3=C_retrieve(lf[2]);
((C_proc9)C_retrieve_proc(t3))(9,t3,t2,C_SCHEME_TRUE,lf[181],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[182],C_retrieve(lf[183]),lf[184]);}

/* k2666 in k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve(lf[177]))){
/* c-backend.scm: 475  generate-foreign-callback-stub-prototypes */
t3=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_retrieve(lf[179]));}
else{
t3=t2;
f_2671(2,t3,C_SCHEME_UNDEFINED);}}

/* k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2671,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2674,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[180])))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2686,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 477  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=t2;
f_2674(2,t3,C_SCHEME_UNDEFINED);}}

/* k2684 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2691,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[180]));}

/* a2690 in k2684 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2691(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2691,3,t0,t1,t2);}
/* c-backend.scm: 478  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,C_SCHEME_TRUE,t2);}

/* k2672 in k2669 in k2666 in k2663 in k2660 in k2657 in k2654 in k2636 in k2630 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve(lf[177]))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 480  generate-foreign-callback-stub-prototypes */
t2=C_retrieve(lf[178]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_retrieve(lf[179]));}}

/* pad0 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2615(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2615,NULL,2,t1,t2);}
t3=t2;
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(10)))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2629,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 455  number->string */
C_number_to_string(3,0,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* k2627 in pad0 in header in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 455  string-append */
t2=*((C_word*)lf[175]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[176],t1);}

/* expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1185(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1185,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1188,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm: 450  expr */
t11=((C_word*)t6)[1];
f_1188(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2580(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2580,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2586,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 444  pair-for-each */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t2);}

/* a2585 in expr-args in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2586,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=t3;
f_2590(2,t5,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 446  gen */
t5=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,C_make_character(44));}}

/* k2588 in a2585 in expr-args in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 447  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1188(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word ab[209],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1188,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(3));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[14]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t11,lf[15]);
if(C_truep(t12)){
t13=(C_word)C_i_cadr(t7);
t14=(C_truep(t13)?lf[16]:lf[17]);
/* c-backend.scm: 135  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,t14);}
else{
t13=(C_word)C_eqp(t11,lf[18]);
if(C_truep(t13)){
t14=(C_word)C_i_cadr(t7);
t15=(C_word)C_fix((C_word)C_character_code(t14));
/* c-backend.scm: 136  gen */
t16=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t1,lf[19],t15,C_make_character(41));}
else{
t14=(C_word)C_eqp(t11,lf[20]);
if(C_truep(t14)){
/* c-backend.scm: 137  gen */
t15=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t1,lf[21]);}
else{
t15=(C_word)C_eqp(t11,lf[22]);
if(C_truep(t15)){
t16=(C_word)C_i_cadr(t7);
/* c-backend.scm: 138  gen */
t17=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t17))(5,t17,t1,lf[23],t16,C_make_character(41));}
else{
t16=(C_word)C_eqp(t11,lf[24]);
if(C_truep(t16)){
/* c-backend.scm: 139  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[25]);}
else{
/* c-backend.scm: 140  bomb */
t17=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t1,lf[26]);}}}}}}
else{
t11=(C_word)C_eqp(t9,lf[27]);
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_vectorp(t12))){
t13=(C_word)C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm: 145  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[28],t13,lf[29]);}
else{
t13=(C_word)C_i_car(t7);
/* c-backend.scm: 146  gen */
t14=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t1,lf[30],t13,C_make_character(93));}}
else{
t12=(C_word)C_eqp(t9,lf[31]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1312,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 149  gen */
t14=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t13,C_SCHEME_TRUE,lf[34]);}
else{
t13=(C_word)C_eqp(t9,lf[35]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
/* c-backend.scm: 158  gen */
t15=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,lf[36],t14);}
else{
t14=(C_word)C_eqp(t9,lf[37]);
if(C_truep(t14)){
t15=(C_word)C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_1370(t19,t1,t5,t3,t15);}
else{
t15=(C_word)C_eqp(t9,lf[38]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1421,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 170  gen */
t17=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t17))(3,t17,t16,lf[40]);}
else{
t16=(C_word)C_eqp(t9,lf[41]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1448,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 175  gen */
t18=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t18))(3,t18,t17,lf[43]);}
else{
t17=(C_word)C_eqp(t9,lf[44]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1467,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 180  gen */
t19=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,lf[45]);}
else{
t18=(C_word)C_eqp(t9,lf[46]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1500,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 187  gen */
t20=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t19,lf[49]);}
else{
t19=(C_word)C_eqp(t9,lf[50]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1537,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 194  gen */
t21=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t21))(3,t21,t20,lf[52]);}
else{
t20=(C_word)C_eqp(t9,lf[53]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1566,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 201  gen */
t22=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[55]);}
else{
t21=(C_word)C_eqp(t9,lf[56]);
if(C_truep(t21)){
t22=(C_word)C_i_car(t7);
t23=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1598,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t22,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 209  gen */
t24=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t24))(5,t24,t23,lf[63],t22,C_make_character(44));}
else{
t22=(C_word)C_eqp(t9,lf[64]);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1633,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 219  gen */
t24=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t24))(3,t24,t23,lf[66]);}
else{
t23=(C_word)C_eqp(t9,lf[67]);
if(C_truep(t23)){
t24=(C_word)C_i_car(t7);
/* c-backend.scm: 223  gen */
t25=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t25))(4,t25,t1,C_make_character(116),t24);}
else{
t24=(C_word)C_eqp(t9,lf[68]);
if(C_truep(t24)){
t25=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1665,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t26=(C_word)C_i_car(t7);
/* c-backend.scm: 226  gen */
t27=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t27))(5,t27,t25,C_make_character(116),t26,C_make_character(61));}
else{
t25=(C_word)C_eqp(t9,lf[69]);
if(C_truep(t25)){
t26=(C_word)C_i_car(t7);
t27=(C_word)C_i_cadr(t7);
if(C_truep((C_word)C_i_caddr(t7))){
if(C_truep(t27)){
/* c-backend.scm: 235  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[70],t26,lf[71]);}
else{
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1707,a[2]=t26,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1711,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
t30=(C_word)C_i_cadddr(t7);
/* c-backend.scm: 236  symbol->string */
t31=*((C_word*)lf[75]+1);
((C_proc3)C_retrieve_proc(t31))(3,t31,t29,t30);}}
else{
if(C_truep(t27)){
/* c-backend.scm: 237  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[76],t26,lf[77]);}
else{
/* c-backend.scm: 238  gen */
t28=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t28))(5,t28,t1,lf[78],t26,lf[79]);}}}
else{
t26=(C_word)C_eqp(t9,lf[80]);
if(C_truep(t26)){
t27=(C_word)C_i_car(t7);
t28=(C_word)C_i_cadr(t7);
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1739,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t28)){
/* c-backend.scm: 244  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[81],t27,lf[82]);}
else{
/* c-backend.scm: 245  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[83],t27,lf[84]);}}
else{
t27=(C_word)C_eqp(t9,lf[85]);
if(C_truep(t27)){
t28=(C_word)C_i_car(t7);
if(C_truep((C_word)C_i_cadr(t7))){
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1773,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 253  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[86],t28,lf[87]);}
else{
t29=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1786,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 257  gen */
t30=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t30))(5,t30,t29,lf[88],t28,lf[89]);}}
else{
t28=(C_word)C_eqp(t9,lf[90]);
if(C_truep(t28)){
/* c-backend.scm: 261  gen */
t29=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t29))(3,t29,t1,lf[91]);}
else{
t29=(C_word)C_eqp(t9,lf[92]);
if(C_truep(t29)){
t30=(C_word)C_i_cdr(t5);
t31=(C_word)C_i_length(t30);
t32=t3;
t33=(C_word)C_fixnum_increase(t31);
t34=(C_word)C_i_cdr(t7);
t35=(C_word)C_i_pairp(t34);
t36=(C_truep(t35)?(C_word)C_i_cadr(t7):C_SCHEME_FALSE);
t37=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1829,a[2]=t35,a[3]=((C_word*)t0)[2],a[4]=t36,a[5]=t32,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t31,a[9]=t33,a[10]=t3,a[11]=t30,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm: 270  source-info->string */
t38=C_retrieve(lf[124]);
((C_proc3)C_retrieve_proc(t38))(3,t38,t37,t36);}
else{
t30=(C_word)C_eqp(t9,lf[125]);
if(C_truep(t30)){
t31=(C_word)C_i_length(t5);
t32=(C_word)C_fixnum_increase(t31);
t33=(C_word)C_i_car(t7);
t34=(C_word)C_i_cadr(t7);
t35=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2140,a[2]=t34,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t32,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t31,a[10]=t1,a[11]=t33,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm: 327  lambda-literal-closure-size */
t36=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t36))(3,t36,t35,((C_word*)t0)[3]);}
else{
t31=(C_word)C_eqp(t9,lf[129]);
if(C_truep(t31)){
t32=(C_word)C_i_cdr(t5);
t33=(C_word)C_i_length(t32);
t34=(C_word)C_fixnum_increase(t33);
t35=(C_word)C_i_caddr(t7);
t36=(C_word)C_i_cadddr(t7);
t37=(C_word)C_eqp(t36,C_fix(0));
t38=(C_word)C_i_not(t37);
t39=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2225,a[2]=t35,a[3]=t36,a[4]=t38,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t32,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t40=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=t39,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 355  find-lambda */
t41=((C_word*)t0)[2];
f_1143(t41,t40,t35);}
else{
t32=(C_word)C_eqp(t9,lf[131]);
if(C_truep(t32)){
t33=(C_word)C_i_length(t5);
t34=(C_word)C_fixnum_plus(t33,C_fix(1));
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2248,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 372  gen */
t37=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t37))(8,t37,t35,C_SCHEME_TRUE,lf[133],t36,lf[134],t34,lf[135]);}
else{
t33=(C_word)C_eqp(t9,lf[136]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2267,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 377  gen */
t35=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t35))(4,t35,t34,C_SCHEME_TRUE,lf[138]);}
else{
t34=(C_word)C_eqp(t9,lf[139]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2286,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t36=(C_word)C_i_car(t7);
/* c-backend.scm: 382  gen */
t37=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t37))(5,t37,t35,lf[140],t36,C_make_character(40));}
else{
t35=(C_word)C_eqp(t9,lf[141]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2305,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=(C_word)C_i_car(t7);
t38=(C_word)C_i_length(t5);
/* c-backend.scm: 387  gen */
t39=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t39))(6,t39,t36,lf[142],t37,lf[143],t38);}
else{
t36=(C_word)C_eqp(t9,lf[144]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t38=(C_word)C_i_cadr(t7);
/* c-backend.scm: 395  foreign-result-conversion */
t39=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t39))(4,t39,t37,t38,lf[146]);}
else{
t37=(C_word)C_eqp(t9,lf[147]);
if(C_truep(t37)){
t38=(C_word)C_i_cadr(t7);
t39=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2361,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2379,a[2]=t38,a[3]=t40,a[4]=t39,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 399  foreign-type-declaration */
t42=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t38,lf[152]);}
else{
t38=(C_word)C_eqp(t9,lf[153]);
if(C_truep(t38)){
t39=(C_word)C_i_car(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2395,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2409,a[2]=t39,a[3]=t40,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 405  foreign-result-conversion */
t42=C_retrieve(lf[145]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,t39,lf[158]);}
else{
t39=(C_word)C_eqp(t9,lf[159]);
if(C_truep(t39)){
t40=(C_word)C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2425,a[2]=t40,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t42=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=t41,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 411  foreign-type-declaration */
t43=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t43))(4,t43,t42,t40,lf[164]);}
else{
t40=(C_word)C_eqp(t9,lf[165]);
if(C_truep(t40)){
t41=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2462,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 418  gen */
t42=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t42))(4,t42,t41,C_SCHEME_TRUE,lf[169]);}
else{
t41=(C_word)C_eqp(t9,lf[170]);
if(C_truep(t41)){
t42=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2545,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 433  gen */
t43=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t43))(3,t43,t42,lf[172]);}
else{
/* c-backend.scm: 441  bomb */
t42=C_retrieve(lf[10]);
((C_proc3)C_retrieve_proc(t42))(3,t42,t1,lf[173]);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 434  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2546 in k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 435  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[171]);}

/* k2549 in k2546 in k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2554,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 436  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2552 in k2549 in k2546 in k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 437  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2555 in k2552 in k2549 in k2546 in k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2560,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 438  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2558 in k2555 in k2552 in k2549 in k2546 in k2543 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 439  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 419  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1188(t4,t2,t3,((C_word*)t0)[3]);}

/* k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 420  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[168]);}

/* k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2468,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2481,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2481(t7,((C_word*)t0)[2],t2,t3);}

/* do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_2481(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2481,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2491,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 424  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[166]);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 427  gen */
t6=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,C_SCHEME_TRUE,lf[167]);}}

/* k2502 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* c-backend.scm: 428  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2505 in k2502 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 429  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(58));}

/* k2508 in k2505 in k2502 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2513,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm: 430  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2511 in k2508 in k2505 in k2502 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t3=(C_word)C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_2481(t4,((C_word*)t0)[2],t2,t3);}

/* k2489 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2494,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 425  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2492 in k2489 in do215 in k2466 in k2463 in k2460 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 426  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k2451 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 411  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[162],t1,lf[163]);}

/* k2423 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2425,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2428,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 412  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1188(t4,t2,t3,((C_word*)t0)[3]);}

/* k2426 in k2423 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2445,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 413  foreign-argument-conversion */
t4=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k2443 in k2426 in k2423 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 413  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[161],t1);}

/* k2429 in k2426 in k2423 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2431,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 414  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2432 in k2429 in k2426 in k2423 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 415  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[160]);}

/* k2407 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2413,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 405  foreign-type-declaration */
t3=C_retrieve(lf[151]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[157]);}

/* k2411 in k2407 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 405  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}

/* k2393 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2398,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 406  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2396 in k2393 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 407  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[154]);}

/* k2377 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2383,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 399  foreign-argument-conversion */
t3=C_retrieve(lf[150]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k2381 in k2377 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 399  gen */
t2=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[149],((C_word*)t0)[2],C_make_character(41),t1);}

/* k2359 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2361,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 400  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2362 in k2359 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 401  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[148]);}

/* k2339 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* c-backend.scm: 395  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k2303 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 390  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_make_character(44));}
else{
t3=t2;
f_2308(2,t3,C_SCHEME_UNDEFINED);}}

/* k2315 in k2303 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 391  expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2580(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2306 in k2303 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 392  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2284 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 383  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2287 in k2284 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 384  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2265 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2270,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 378  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k2268 in k2265 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 379  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[137]);}

/* k2246 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 373  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2249 in k2246 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 374  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[132]);}

/* k2227 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 355  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(C_word)C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 357  gen */
t5=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2206,a[2]=t2,a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 359  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[130],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_2176(2,t3,C_SCHEME_UNDEFINED);}}

/* k2204 in k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_not(((C_word*)t0)[4]);
t3=(C_truep(t2)?t2:(C_word)C_i_pairp(((C_word*)t0)[3]));
if(C_truep(t3)){
/* c-backend.scm: 360  gen */
t4=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_make_character(44));}
else{
t4=((C_word*)t0)[2];
f_2176(2,t4,C_SCHEME_UNDEFINED);}}

/* k2174 in k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_2179(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2194,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 362  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k2192 in k2174 in k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm: 363  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=((C_word*)t0)[2];
f_2179(2,t2,C_SCHEME_UNDEFINED);}}

/* k2177 in k2174 in k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm: 364  expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2580(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t3=t2;
f_2182(2,t3,C_SCHEME_UNDEFINED);}}

/* k2180 in k2177 in k2174 in k2171 in k2223 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 365  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 329  lambda-literal-temporaries */
t4=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2124,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 342  gen */
t4=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k2122 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2127,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_2127(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 343  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[128]);}}

/* k2125 in k2122 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 344  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2128 in k2125 in k2122 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 345  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[2]);
/* c-backend.scm: 330  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2089,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 331  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a2106 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2107,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 333  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2109 in a2106 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2114,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 334  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2112 in k2109 in a2106 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 335  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2087 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2092,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2097,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2105,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 339  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2103 in k2087 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 337  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a2096 in k2087 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2097,4,t0,t1,t2,t3);}
/* c-backend.scm: 338  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[127],t2,C_make_character(59));}

/* k2090 in k2087 in k2084 in k2081 in k2138 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 340  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[126]);}

/* k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1832,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(C_word)C_i_cddr(((C_word*)t0)[15]);
t4=(C_word)C_i_pairp(t3);
t5=t2;
f_1832(t5,(C_truep(t4)?(C_word)C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_1832(t3,C_SCHEME_FALSE);}}

/* k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1832,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2033,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 273  find-lambda */
t6=((C_word*)t0)[2];
f_1143(t6,t5,t1);}
else{
t4=t3;
f_1838(t4,C_SCHEME_FALSE);}}

/* k2031 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 273  lambda-literal-closure-size */
t2=C_retrieve(lf[123]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2027 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1838(t2,(C_word)C_eqp(t1,C_fix(0)));}

/* k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1838(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1838,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(C_retrieve(lf[112]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2015,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 122  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2022,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1183,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 123  ->string */
t7=C_retrieve(lf[118]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}}
else{
t4=t3;
f_1844(2,t4,C_SCHEME_UNDEFINED);}}

/* k1181 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 123  string-translate* */
t2=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[122]);}

/* k2020 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 278  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[119],t1,lf[120]);}

/* k1171 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 122  string-translate */
t2=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,lf[116],lf[117]);}

/* k2013 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 277  gen */
t2=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[113],t1,lf[114]);}

/* k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1844,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[15],C_fix(1));
t3=(C_word)C_eqp(lf[35],t2);
if(C_truep(t3)){
t4=(C_word)C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1856,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t4);
/* c-backend.scm: 281  gen */
t7=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t7))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[94]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 285  lambda-literal-id */
t6=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm: 311  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],C_make_character(61));}}}

/* k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1971,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 312  expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1188(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 313  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[110],((C_word*)t0)[4],lf[111]);}

/* k1972 in k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1974,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1977,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_retrieve(lf[104]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1989(t5,t3);}
else{
t5=C_retrieve(lf[109]);
t6=t4;
f_1989(t6,(C_truep(t5)?t5:(C_word)C_i_car(((C_word*)t0)[2])));}}

/* k1987 in k1972 in k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1989(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm: 316  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[105],((C_word*)t0)[2],lf[106]);}
else{
/* c-backend.scm: 317  gen */
t2=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[107],((C_word*)t0)[2],lf[108]);}}

/* k1975 in k1972 in k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1977,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1980,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 318  gen */
t3=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t3))(7,t3,t2,lf[102],((C_word*)t0)[3],lf[103],((C_word*)t0)[2],C_make_character(44));}

/* k1978 in k1975 in k1972 in k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 319  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1981 in k1978 in k1975 in k1972 in k1969 in k1966 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 320  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[101]);}

/* k1963 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm: 286  lambda-literal-looping */
t3=C_retrieve(lf[100]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_1875(2,t3,C_SCHEME_FALSE);}}

/* k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1875,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1878,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm: 287  lambda-literal-temporaries */
t3=C_retrieve(lf[98]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_1925(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 302  gen */
t4=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k1947 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 303  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1950 in k1947 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 304  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1923 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1928,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm: 305  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k1926 in k1923 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1931,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1931(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 306  gen */
t3=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k1929 in k1926 in k1923 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1934(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 307  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* k1932 in k1929 in k1926 in k1923 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 308  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1935 in k1932 in k1929 in k1926 in k1923 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 309  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_fixnum_plus(t1,((C_word*)t0)[6]);
/* c-backend.scm: 288  iota */
t4=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1884,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 289  for-each */
t4=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],t1);}

/* a1907 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1908,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 291  gen */
t5=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k1910 in a1907 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 292  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1913 in k1910 in a1907 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 293  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1882 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1887,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1898,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 297  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k1904 in k1882 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 295  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1897 in k1882 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1898,4,t0,t1,t2,t3);}
/* c-backend.scm: 296  gen */
t4=C_retrieve(lf[2]);
((C_proc8)C_retrieve_proc(t4))(8,t4,t1,C_SCHEME_TRUE,C_make_character(116),t3,lf[97],t2,C_make_character(59));}

/* k1885 in k1882 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1890(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm: 298  gen */
t3=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t3))(6,t3,t2,C_SCHEME_TRUE,lf[96],((C_word*)t0)[2],C_make_character(59));}}

/* k1888 in k1885 in k1882 in k1879 in k1876 in k1873 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 299  gen */
t2=C_retrieve(lf[2]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[95]);}

/* k1854 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 282  expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2580(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1857 in k1854 in k1842 in k1836 in k1830 in k1827 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 283  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[93]);}

/* k1784 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1789,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 258  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1787 in k1784 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 259  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1771 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 254  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1774 in k1771 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 255  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k1737 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1742,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 246  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1740 in k1737 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 247  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1709 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 236  c-ify-string */
t2=C_retrieve(lf[74]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1705 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 236  gen */
t2=C_retrieve(lf[2]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[3],lf[72],((C_word*)t0)[2],lf[73],t1,C_make_character(41));}

/* k1663 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 227  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1631 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1633,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1636,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 220  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1634 in k1631 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 221  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[65]);}

/* k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm: 215  iota */
t5=C_retrieve(lf[62]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k1622 in k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 210  for-each */
t2=*((C_word*)lf[61]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1609 in k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1610,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 212  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,lf[59],t3,lf[60]);}

/* k1612 in a1609 in k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 213  expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1188(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1615 in k1612 in a1609 in k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 214  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k1599 in k1596 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* c-backend.scm: 216  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[2],lf[57],t2,lf[58]);}

/* k1564 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 202  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1567 in k1564 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 203  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[54]);}

/* k1570 in k1567 in k1564 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 204  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1573 in k1570 in k1567 in k1564 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 205  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1535 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 195  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1538 in k1535 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 196  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[51]);}

/* k1541 in k1538 in k1535 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 197  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1544 in k1541 in k1538 in k1535 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 198  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1498 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 188  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1188(t4,t2,t3,((C_word*)t0)[3]);}

/* k1501 in k1498 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
t4=(C_word)C_fixnum_plus(t3,C_fix(1));
/* c-backend.scm: 189  gen */
t5=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,lf[47],t4,lf[48]);}

/* k1504 in k1501 in k1498 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1509,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 190  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1507 in k1504 in k1501 in k1498 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 191  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1465 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[5]);
/* c-backend.scm: 181  expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1188(t4,t2,t3,((C_word*)t0)[3]);}

/* k1468 in k1465 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* c-backend.scm: 182  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k1471 in k1468 in k1465 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 183  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1474 in k1471 in k1468 in k1465 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 184  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k1446 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 176  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1449 in k1446 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 177  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[42]);}

/* k1419 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 171  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1422 in k1419 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_car(((C_word*)t0)[3]);
t3=(C_word)C_fixnum_plus(t2,C_fix(1));
/* c-backend.scm: 172  gen */
t4=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[2],lf[39],t3,C_make_character(93));}

/* loop in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1370(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1370,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep((C_word)C_fixnum_greaterp(t5,C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm: 163  gen */
t7=C_retrieve(lf[2]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t6,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t6=(C_word)C_i_car(t2);
/* c-backend.scm: 167  expr */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1188(t7,t1,t6,t3);}}

/* k1378 in loop in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[7]);
/* c-backend.scm: 164  expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1188(t4,t2,t3,((C_word*)t0)[6]);}

/* k1381 in k1378 in loop in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm: 165  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_make_character(59));}

/* k1384 in k1381 in k1378 in loop in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[6]);
t3=(C_word)C_fixnum_increase(((C_word*)t0)[5]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[4]);
/* c-backend.scm: 166  loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1370(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* c-backend.scm: 150  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1313 in k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 151  gen */
t3=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[33]);}

/* k1316 in k1313 in k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm: 152  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1319 in k1316 in k1313 in k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1324,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm: 153  gen */
t3=C_retrieve(lf[2]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[32]);}

/* k1322 in k1319 in k1316 in k1313 in k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm: 154  expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1188(t4,t2,t3,((C_word*)t0)[2]);}

/* k1325 in k1322 in k1319 in k1316 in k1313 in k1310 in expr in expression in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm: 155  gen */
t2=C_retrieve(lf[2]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_fcall f_1143(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1143,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1147,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1155,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm: 119  find */
t5=C_retrieve(lf[13]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a1154 in find-lambda in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1155,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1163,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 119  lambda-literal-id */
t4=C_retrieve(lf[12]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k1161 in a1154 in find-lambda in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],t1));}

/* k1145 in find-lambda in ##compiler#generate-code in k1136 in k1091 in k1088 in k1085 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* c-backend.scm: 120  bomb */
t2=C_retrieve(lf[10]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[11],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1091 in k1088 in k1085 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1126,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1134,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm: 101  intersperse */
t5=C_retrieve(lf[7]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,C_make_character(32));}

/* k1132 in ##compiler#gen-list in k1091 in k1088 in k1085 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a1125 in ##compiler#gen-list in k1091 in k1088 in k1085 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1126,3,t0,t1,t2);}
/* c-backend.scm: 100  display */
t3=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,C_retrieve(lf[1]));}

/* ##compiler#gen in k1091 in k1088 in k1085 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+2)){
C_save_and_reclaim((void*)tr2r,(void*)f_1099r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1099r(t0,t1,t2);}}

static void C_ccall f_1099r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(2);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1105,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a1104 in ##compiler#gen in k1091 in k1088 in k1085 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1105,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t3)){
/* c-backend.scm: 94   newline */
t4=*((C_word*)lf[3]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_retrieve(lf[1]));}
else{
/* c-backend.scm: 95   display */
t4=*((C_word*)lf[4]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve(lf[1]));}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[671] = {
{"toplevelc-backend.scm",(void*)C_backend_toplevel},
{"f_1087c-backend.scm",(void*)f_1087},
{"f_1090c-backend.scm",(void*)f_1090},
{"f_1093c-backend.scm",(void*)f_1093},
{"f_8762c-backend.scm",(void*)f_8762},
{"f_8766c-backend.scm",(void*)f_8766},
{"f_8758c-backend.scm",(void*)f_8758},
{"f_1138c-backend.scm",(void*)f_1138},
{"f_8465c-backend.scm",(void*)f_8465},
{"f_8750c-backend.scm",(void*)f_8750},
{"f_8577c-backend.scm",(void*)f_8577},
{"f_8724c-backend.scm",(void*)f_8724},
{"f_8722c-backend.scm",(void*)f_8722},
{"f_8710c-backend.scm",(void*)f_8710},
{"f_8680c-backend.scm",(void*)f_8680},
{"f_8641c-backend.scm",(void*)f_8641},
{"f_8527c-backend.scm",(void*)f_8527},
{"f_8474c-backend.scm",(void*)f_8474},
{"f_8471c-backend.scm",(void*)f_8471},
{"f_8468c-backend.scm",(void*)f_8468},
{"f_7691c-backend.scm",(void*)f_7691},
{"f_7778c-backend.scm",(void*)f_7778},
{"f_7859c-backend.scm",(void*)f_7859},
{"f_8294c-backend.scm",(void*)f_8294},
{"f_8236c-backend.scm",(void*)f_8236},
{"f_8200c-backend.scm",(void*)f_8200},
{"f_8165c-backend.scm",(void*)f_8165},
{"f_8117c-backend.scm",(void*)f_8117},
{"f_8069c-backend.scm",(void*)f_8069},
{"f_8021c-backend.scm",(void*)f_8021},
{"f_7986c-backend.scm",(void*)f_7986},
{"f_7950c-backend.scm",(void*)f_7950},
{"f_7914c-backend.scm",(void*)f_7914},
{"f_7892c-backend.scm",(void*)f_7892},
{"f_7887c-backend.scm",(void*)f_7887},
{"f_7882c-backend.scm",(void*)f_7882},
{"f_7693c-backend.scm",(void*)f_7693},
{"f_6858c-backend.scm",(void*)f_6858},
{"f_6888c-backend.scm",(void*)f_6888},
{"f_6915c-backend.scm",(void*)f_6915},
{"f_7110c-backend.scm",(void*)f_7110},
{"f_7119c-backend.scm",(void*)f_7119},
{"f_7128c-backend.scm",(void*)f_7128},
{"f_7516c-backend.scm",(void*)f_7516},
{"f_7483c-backend.scm",(void*)f_7483},
{"f_7493c-backend.scm",(void*)f_7493},
{"f_7451c-backend.scm",(void*)f_7451},
{"f_7416c-backend.scm",(void*)f_7416},
{"f_7346c-backend.scm",(void*)f_7346},
{"f_7301c-backend.scm",(void*)f_7301},
{"f_7269c-backend.scm",(void*)f_7269},
{"f_7237c-backend.scm",(void*)f_7237},
{"f_7205c-backend.scm",(void*)f_7205},
{"f_7173c-backend.scm",(void*)f_7173},
{"f_7151c-backend.scm",(void*)f_7151},
{"f_6860c-backend.scm",(void*)f_6860},
{"f_5641c-backend.scm",(void*)f_5641},
{"f_5718c-backend.scm",(void*)f_5718},
{"f_5820c-backend.scm",(void*)f_5820},
{"f_5853c-backend.scm",(void*)f_5853},
{"f_5949c-backend.scm",(void*)f_5949},
{"f_5964c-backend.scm",(void*)f_5964},
{"f_6581c-backend.scm",(void*)f_6581},
{"f_6597c-backend.scm",(void*)f_6597},
{"f_6601c-backend.scm",(void*)f_6601},
{"f_6614c-backend.scm",(void*)f_6614},
{"f_6612c-backend.scm",(void*)f_6612},
{"f_6608c-backend.scm",(void*)f_6608},
{"f_6535c-backend.scm",(void*)f_6535},
{"f_6548c-backend.scm",(void*)f_6548},
{"f_6485c-backend.scm",(void*)f_6485},
{"f_6435c-backend.scm",(void*)f_6435},
{"f_6396c-backend.scm",(void*)f_6396},
{"f_6406c-backend.scm",(void*)f_6406},
{"f_6357c-backend.scm",(void*)f_6357},
{"f_6367c-backend.scm",(void*)f_6367},
{"f_6318c-backend.scm",(void*)f_6318},
{"f_6328c-backend.scm",(void*)f_6328},
{"f_6279c-backend.scm",(void*)f_6279},
{"f_6289c-backend.scm",(void*)f_6289},
{"f_6219c-backend.scm",(void*)f_6219},
{"f_6236c-backend.scm",(void*)f_6236},
{"f_6246c-backend.scm",(void*)f_6246},
{"f_6244c-backend.scm",(void*)f_6244},
{"f_6240c-backend.scm",(void*)f_6240},
{"f_6232c-backend.scm",(void*)f_6232},
{"f_6180c-backend.scm",(void*)f_6180},
{"f_6190c-backend.scm",(void*)f_6190},
{"f_6144c-backend.scm",(void*)f_6144},
{"f_6108c-backend.scm",(void*)f_6108},
{"f_6072c-backend.scm",(void*)f_6072},
{"f_6036c-backend.scm",(void*)f_6036},
{"f_6010c-backend.scm",(void*)f_6010},
{"f_6018c-backend.scm",(void*)f_6018},
{"f_6001c-backend.scm",(void*)f_6001},
{"f_6009c-backend.scm",(void*)f_6009},
{"f_5996c-backend.scm",(void*)f_5996},
{"f_5648c-backend.scm",(void*)f_5648},
{"f_5643c-backend.scm",(void*)f_5643},
{"f_5576c-backend.scm",(void*)f_5576},
{"f_5580c-backend.scm",(void*)f_5580},
{"f_5583c-backend.scm",(void*)f_5583},
{"f_5586c-backend.scm",(void*)f_5586},
{"f_5589c-backend.scm",(void*)f_5589},
{"f_5595c-backend.scm",(void*)f_5595},
{"f_5639c-backend.scm",(void*)f_5639},
{"f_5598c-backend.scm",(void*)f_5598},
{"f_5606c-backend.scm",(void*)f_5606},
{"f_5627c-backend.scm",(void*)f_5627},
{"f_5610c-backend.scm",(void*)f_5610},
{"f_5601c-backend.scm",(void*)f_5601},
{"f_5145c-backend.scm",(void*)f_5145},
{"f_5151c-backend.scm",(void*)f_5151},
{"f_5155c-backend.scm",(void*)f_5155},
{"f_5158c-backend.scm",(void*)f_5158},
{"f_5161c-backend.scm",(void*)f_5161},
{"f_5164c-backend.scm",(void*)f_5164},
{"f_5170c-backend.scm",(void*)f_5170},
{"f_5511c-backend.scm",(void*)f_5511},
{"f_5514c-backend.scm",(void*)f_5514},
{"f_5574c-backend.scm",(void*)f_5574},
{"f_5517c-backend.scm",(void*)f_5517},
{"f_5520c-backend.scm",(void*)f_5520},
{"f_5523c-backend.scm",(void*)f_5523},
{"f_5526c-backend.scm",(void*)f_5526},
{"f_5559c-backend.scm",(void*)f_5559},
{"f_5567c-backend.scm",(void*)f_5567},
{"f_5529c-backend.scm",(void*)f_5529},
{"f_5557c-backend.scm",(void*)f_5557},
{"f_5532c-backend.scm",(void*)f_5532},
{"f_5535c-backend.scm",(void*)f_5535},
{"f_5538c-backend.scm",(void*)f_5538},
{"f_5172c-backend.scm",(void*)f_5172},
{"f_5182c-backend.scm",(void*)f_5182},
{"f_5191c-backend.scm",(void*)f_5191},
{"f_5203c-backend.scm",(void*)f_5203},
{"f_5215c-backend.scm",(void*)f_5215},
{"f_5221c-backend.scm",(void*)f_5221},
{"f_5255c-backend.scm",(void*)f_5255},
{"f_4912c-backend.scm",(void*)f_4912},
{"f_4918c-backend.scm",(void*)f_4918},
{"f_4922c-backend.scm",(void*)f_4922},
{"f_4925c-backend.scm",(void*)f_4925},
{"f_4928c-backend.scm",(void*)f_4928},
{"f_5143c-backend.scm",(void*)f_5143},
{"f_4934c-backend.scm",(void*)f_4934},
{"f_4937c-backend.scm",(void*)f_4937},
{"f_4940c-backend.scm",(void*)f_4940},
{"f_4943c-backend.scm",(void*)f_4943},
{"f_4946c-backend.scm",(void*)f_4946},
{"f_4949c-backend.scm",(void*)f_4949},
{"f_4952c-backend.scm",(void*)f_4952},
{"f_4955c-backend.scm",(void*)f_4955},
{"f_4958c-backend.scm",(void*)f_4958},
{"f_4961c-backend.scm",(void*)f_4961},
{"f_5132c-backend.scm",(void*)f_5132},
{"f_4964c-backend.scm",(void*)f_4964},
{"f_4967c-backend.scm",(void*)f_4967},
{"f_4970c-backend.scm",(void*)f_4970},
{"f_4973c-backend.scm",(void*)f_4973},
{"f_4976c-backend.scm",(void*)f_4976},
{"f_4979c-backend.scm",(void*)f_4979},
{"f_4982c-backend.scm",(void*)f_4982},
{"f_4985c-backend.scm",(void*)f_4985},
{"f_5110c-backend.scm",(void*)f_5110},
{"f_5080c-backend.scm",(void*)f_5080},
{"f_5100c-backend.scm",(void*)f_5100},
{"f_5088c-backend.scm",(void*)f_5088},
{"f_5092c-backend.scm",(void*)f_5092},
{"f_5096c-backend.scm",(void*)f_5096},
{"f_4988c-backend.scm",(void*)f_4988},
{"f_4991c-backend.scm",(void*)f_4991},
{"f_5021c-backend.scm",(void*)f_5021},
{"f_5024c-backend.scm",(void*)f_5024},
{"f_5062c-backend.scm",(void*)f_5062},
{"f_5058c-backend.scm",(void*)f_5058},
{"f_5027c-backend.scm",(void*)f_5027},
{"f_5030c-backend.scm",(void*)f_5030},
{"f_5033c-backend.scm",(void*)f_5033},
{"f_5000c-backend.scm",(void*)f_5000},
{"f_5003c-backend.scm",(void*)f_5003},
{"f_4994c-backend.scm",(void*)f_4994},
{"f_4894c-backend.scm",(void*)f_4894},
{"f_4900c-backend.scm",(void*)f_4900},
{"f_4904c-backend.scm",(void*)f_4904},
{"f_4907c-backend.scm",(void*)f_4907},
{"f_4843c-backend.scm",(void*)f_4843},
{"f_4847c-backend.scm",(void*)f_4847},
{"f_4852c-backend.scm",(void*)f_4852},
{"f_4859c-backend.scm",(void*)f_4859},
{"f_4879c-backend.scm",(void*)f_4879},
{"f_4827c-backend.scm",(void*)f_4827},
{"f_4833c-backend.scm",(void*)f_4833},
{"f_4841c-backend.scm",(void*)f_4841},
{"f_4811c-backend.scm",(void*)f_4811},
{"f_4817c-backend.scm",(void*)f_4817},
{"f_4825c-backend.scm",(void*)f_4825},
{"f_4722c-backend.scm",(void*)f_4722},
{"f_4731c-backend.scm",(void*)f_4731},
{"f_4760c-backend.scm",(void*)f_4760},
{"f_4770c-backend.scm",(void*)f_4770},
{"f_4763c-backend.scm",(void*)f_4763},
{"f_4747c-backend.scm",(void*)f_4747},
{"f_4649c-backend.scm",(void*)f_4649},
{"f_4653c-backend.scm",(void*)f_4653},
{"f_4667c-backend.scm",(void*)f_4667},
{"f_4680c-backend.scm",(void*)f_4680},
{"f_4683c-backend.scm",(void*)f_4683},
{"f_4686c-backend.scm",(void*)f_4686},
{"f_4656c-backend.scm",(void*)f_4656},
{"f_4659c-backend.scm",(void*)f_4659},
{"f_4662c-backend.scm",(void*)f_4662},
{"f_1140c-backend.scm",(void*)f_1140},
{"f_4616c-backend.scm",(void*)f_4616},
{"f_4620c-backend.scm",(void*)f_4620},
{"f_4623c-backend.scm",(void*)f_4623},
{"f_4626c-backend.scm",(void*)f_4626},
{"f_4629c-backend.scm",(void*)f_4629},
{"f_4632c-backend.scm",(void*)f_4632},
{"f_4635c-backend.scm",(void*)f_4635},
{"f_4638c-backend.scm",(void*)f_4638},
{"f_4641c-backend.scm",(void*)f_4641},
{"f_4644c-backend.scm",(void*)f_4644},
{"f_3869c-backend.scm",(void*)f_3869},
{"f_3875c-backend.scm",(void*)f_3875},
{"f_3879c-backend.scm",(void*)f_3879},
{"f_3882c-backend.scm",(void*)f_3882},
{"f_3885c-backend.scm",(void*)f_3885},
{"f_3888c-backend.scm",(void*)f_3888},
{"f_3891c-backend.scm",(void*)f_3891},
{"f_3894c-backend.scm",(void*)f_3894},
{"f_4613c-backend.scm",(void*)f_4613},
{"f_3897c-backend.scm",(void*)f_3897},
{"f_3903c-backend.scm",(void*)f_3903},
{"f_3906c-backend.scm",(void*)f_3906},
{"f_3909c-backend.scm",(void*)f_3909},
{"f_3912c-backend.scm",(void*)f_3912},
{"f_3915c-backend.scm",(void*)f_3915},
{"f_3918c-backend.scm",(void*)f_3918},
{"f_3921c-backend.scm",(void*)f_3921},
{"f_3924c-backend.scm",(void*)f_3924},
{"f_3927c-backend.scm",(void*)f_3927},
{"f_3930c-backend.scm",(void*)f_3930},
{"f_3933c-backend.scm",(void*)f_3933},
{"f_3936c-backend.scm",(void*)f_3936},
{"f_4582c-backend.scm",(void*)f_4582},
{"f_3939c-backend.scm",(void*)f_3939},
{"f_4543c-backend.scm",(void*)f_4543},
{"f_4546c-backend.scm",(void*)f_4546},
{"f_4549c-backend.scm",(void*)f_4549},
{"f_4565c-backend.scm",(void*)f_4565},
{"f_4568c-backend.scm",(void*)f_4568},
{"f_3942c-backend.scm",(void*)f_3942},
{"f_3945c-backend.scm",(void*)f_3945},
{"f_3948c-backend.scm",(void*)f_3948},
{"f_4515c-backend.scm",(void*)f_4515},
{"f_4518c-backend.scm",(void*)f_4518},
{"f_3951c-backend.scm",(void*)f_3951},
{"f_3954c-backend.scm",(void*)f_3954},
{"f_3957c-backend.scm",(void*)f_3957},
{"f_3960c-backend.scm",(void*)f_3960},
{"f_3963c-backend.scm",(void*)f_3963},
{"f_3966c-backend.scm",(void*)f_3966},
{"f_4477c-backend.scm",(void*)f_4477},
{"f_4487c-backend.scm",(void*)f_4487},
{"f_3969c-backend.scm",(void*)f_3969},
{"f_4420c-backend.scm",(void*)f_4420},
{"f_4432c-backend.scm",(void*)f_4432},
{"f_4435c-backend.scm",(void*)f_4435},
{"f_4441c-backend.scm",(void*)f_4441},
{"f_4342c-backend.scm",(void*)f_4342},
{"f_4384c-backend.scm",(void*)f_4384},
{"f_4345c-backend.scm",(void*)f_4345},
{"f_4351c-backend.scm",(void*)f_4351},
{"f_4354c-backend.scm",(void*)f_4354},
{"f_4360c-backend.scm",(void*)f_4360},
{"f_4278c-backend.scm",(void*)f_4278},
{"f_4281c-backend.scm",(void*)f_4281},
{"f_4284c-backend.scm",(void*)f_4284},
{"f_4287c-backend.scm",(void*)f_4287},
{"f_4290c-backend.scm",(void*)f_4290},
{"f_4305c-backend.scm",(void*)f_4305},
{"f_4293c-backend.scm",(void*)f_4293},
{"f_4296c-backend.scm",(void*)f_4296},
{"f_4264c-backend.scm",(void*)f_4264},
{"f_4272c-backend.scm",(void*)f_4272},
{"f_4189c-backend.scm",(void*)f_4189},
{"f_4195c-backend.scm",(void*)f_4195},
{"f_4198c-backend.scm",(void*)f_4198},
{"f_4232c-backend.scm",(void*)f_4232},
{"f_4235c-backend.scm",(void*)f_4235},
{"f_4238c-backend.scm",(void*)f_4238},
{"f_4201c-backend.scm",(void*)f_4201},
{"f_4204c-backend.scm",(void*)f_4204},
{"f_4207c-backend.scm",(void*)f_4207},
{"f_4210c-backend.scm",(void*)f_4210},
{"f_4219c-backend.scm",(void*)f_4219},
{"f_4222c-backend.scm",(void*)f_4222},
{"f_3972c-backend.scm",(void*)f_3972},
{"f_3995c-backend.scm",(void*)f_3995},
{"f_4130c-backend.scm",(void*)f_4130},
{"f_4133c-backend.scm",(void*)f_4133},
{"f_4145c-backend.scm",(void*)f_4145},
{"f_4136c-backend.scm",(void*)f_4136},
{"f_4001c-backend.scm",(void*)f_4001},
{"f_4004c-backend.scm",(void*)f_4004},
{"f_4007c-backend.scm",(void*)f_4007},
{"f_4111c-backend.scm",(void*)f_4111},
{"f_4010c-backend.scm",(void*)f_4010},
{"f_4013c-backend.scm",(void*)f_4013},
{"f_4016c-backend.scm",(void*)f_4016},
{"f_4019c-backend.scm",(void*)f_4019},
{"f_4084c-backend.scm",(void*)f_4084},
{"f_4080c-backend.scm",(void*)f_4080},
{"f_4022c-backend.scm",(void*)f_4022},
{"f_4025c-backend.scm",(void*)f_4025},
{"f_4028c-backend.scm",(void*)f_4028},
{"f_4031c-backend.scm",(void*)f_4031},
{"f_4034c-backend.scm",(void*)f_4034},
{"f_4037c-backend.scm",(void*)f_4037},
{"f_4055c-backend.scm",(void*)f_4055},
{"f_4065c-backend.scm",(void*)f_4065},
{"f_4040c-backend.scm",(void*)f_4040},
{"f_3975c-backend.scm",(void*)f_3975},
{"f_3985c-backend.scm",(void*)f_3985},
{"f_3978c-backend.scm",(void*)f_3978},
{"f_3499c-backend.scm",(void*)f_3499},
{"f_3506c-backend.scm",(void*)f_3506},
{"f_3580c-backend.scm",(void*)f_3580},
{"f_3598c-backend.scm",(void*)f_3598},
{"f_3627c-backend.scm",(void*)f_3627},
{"f_3649c-backend.scm",(void*)f_3649},
{"f_3605c-backend.scm",(void*)f_3605},
{"f_3574c-backend.scm",(void*)f_3574},
{"f_3570c-backend.scm",(void*)f_3570},
{"f_3566c-backend.scm",(void*)f_3566},
{"f_3537c-backend.scm",(void*)f_3537},
{"f_3541c-backend.scm",(void*)f_3541},
{"f_3456c-backend.scm",(void*)f_3456},
{"f_3462c-backend.scm",(void*)f_3462},
{"f_3491c-backend.scm",(void*)f_3491},
{"f_3472c-backend.scm",(void*)f_3472},
{"f_3658c-backend.scm",(void*)f_3658},
{"f_3778c-backend.scm",(void*)f_3778},
{"f_3665c-backend.scm",(void*)f_3665},
{"f_3671c-backend.scm",(void*)f_3671},
{"f_3754c-backend.scm",(void*)f_3754},
{"f_3764c-backend.scm",(void*)f_3764},
{"f_3757c-backend.scm",(void*)f_3757},
{"f_3721c-backend.scm",(void*)f_3721},
{"f_3727c-backend.scm",(void*)f_3727},
{"f_3493c-backend.scm",(void*)f_3493},
{"f_3780c-backend.scm",(void*)f_3780},
{"f_3787c-backend.scm",(void*)f_3787},
{"f_3790c-backend.scm",(void*)f_3790},
{"f_3795c-backend.scm",(void*)f_3795},
{"f_3851c-backend.scm",(void*)f_3851},
{"f_3847c-backend.scm",(void*)f_3847},
{"f_3832c-backend.scm",(void*)f_3832},
{"f_3811c-backend.scm",(void*)f_3811},
{"f_3822c-backend.scm",(void*)f_3822},
{"f_3818c-backend.scm",(void*)f_3818},
{"f_3857c-backend.scm",(void*)f_3857},
{"f_3864c-backend.scm",(void*)f_3864},
{"f_3867c-backend.scm",(void*)f_3867},
{"f_3170c-backend.scm",(void*)f_3170},
{"f_3337c-backend.scm",(void*)f_3337},
{"f_3341c-backend.scm",(void*)f_3341},
{"f_3344c-backend.scm",(void*)f_3344},
{"f_3347c-backend.scm",(void*)f_3347},
{"f_3350c-backend.scm",(void*)f_3350},
{"f_3353c-backend.scm",(void*)f_3353},
{"f_3454c-backend.scm",(void*)f_3454},
{"f_3356c-backend.scm",(void*)f_3356},
{"f_3359c-backend.scm",(void*)f_3359},
{"f_3365c-backend.scm",(void*)f_3365},
{"f_3443c-backend.scm",(void*)f_3443},
{"f_3399c-backend.scm",(void*)f_3399},
{"f_3405c-backend.scm",(void*)f_3405},
{"f_3423c-backend.scm",(void*)f_3423},
{"f_3419c-backend.scm",(void*)f_3419},
{"f_3415c-backend.scm",(void*)f_3415},
{"f_3371c-backend.scm",(void*)f_3371},
{"f_3374c-backend.scm",(void*)f_3374},
{"f_3377c-backend.scm",(void*)f_3377},
{"f_3380c-backend.scm",(void*)f_3380},
{"f_3383c-backend.scm",(void*)f_3383},
{"f_3393c-backend.scm",(void*)f_3393},
{"f_3386c-backend.scm",(void*)f_3386},
{"f_3289c-backend.scm",(void*)f_3289},
{"f_3308c-backend.scm",(void*)f_3308},
{"f_3312c-backend.scm",(void*)f_3312},
{"f_3315c-backend.scm",(void*)f_3315},
{"f_3318c-backend.scm",(void*)f_3318},
{"f_3321c-backend.scm",(void*)f_3321},
{"f_3335c-backend.scm",(void*)f_3335},
{"f_3331c-backend.scm",(void*)f_3331},
{"f_3324c-backend.scm",(void*)f_3324},
{"f_3292c-backend.scm",(void*)f_3292},
{"f_3306c-backend.scm",(void*)f_3306},
{"f_3295c-backend.scm",(void*)f_3295},
{"f_3302c-backend.scm",(void*)f_3302},
{"f_3209c-backend.scm",(void*)f_3209},
{"f_3211c-backend.scm",(void*)f_3211},
{"f_3215c-backend.scm",(void*)f_3215},
{"f_3218c-backend.scm",(void*)f_3218},
{"f_3221c-backend.scm",(void*)f_3221},
{"f_3224c-backend.scm",(void*)f_3224},
{"f_3227c-backend.scm",(void*)f_3227},
{"f_3230c-backend.scm",(void*)f_3230},
{"f_3233c-backend.scm",(void*)f_3233},
{"f_3236c-backend.scm",(void*)f_3236},
{"f_3239c-backend.scm",(void*)f_3239},
{"f_3242c-backend.scm",(void*)f_3242},
{"f_3245c-backend.scm",(void*)f_3245},
{"f_3248c-backend.scm",(void*)f_3248},
{"f_3262c-backend.scm",(void*)f_3262},
{"f_3258c-backend.scm",(void*)f_3258},
{"f_3251c-backend.scm",(void*)f_3251},
{"f_3173c-backend.scm",(void*)f_3173},
{"f_3186c-backend.scm",(void*)f_3186},
{"f_3196c-backend.scm",(void*)f_3196},
{"f_3177c-backend.scm",(void*)f_3177},
{"f_2919c-backend.scm",(void*)f_2919},
{"f_2923c-backend.scm",(void*)f_2923},
{"f_2947c-backend.scm",(void*)f_2947},
{"f_2951c-backend.scm",(void*)f_2951},
{"f_2954c-backend.scm",(void*)f_2954},
{"f_3168c-backend.scm",(void*)f_3168},
{"f_2957c-backend.scm",(void*)f_2957},
{"f_3154c-backend.scm",(void*)f_3154},
{"f_2960c-backend.scm",(void*)f_2960},
{"f_2963c-backend.scm",(void*)f_2963},
{"f_2966c-backend.scm",(void*)f_2966},
{"f_2969c-backend.scm",(void*)f_2969},
{"f_2972c-backend.scm",(void*)f_2972},
{"f_2975c-backend.scm",(void*)f_2975},
{"f_3146c-backend.scm",(void*)f_3146},
{"f_2978c-backend.scm",(void*)f_2978},
{"f_2981c-backend.scm",(void*)f_2981},
{"f_3139c-backend.scm",(void*)f_3139},
{"f_3120c-backend.scm",(void*)f_3120},
{"f_3131c-backend.scm",(void*)f_3131},
{"f_2984c-backend.scm",(void*)f_2984},
{"f_3071c-backend.scm",(void*)f_3071},
{"f_3074c-backend.scm",(void*)f_3074},
{"f_3077c-backend.scm",(void*)f_3077},
{"f_3080c-backend.scm",(void*)f_3080},
{"f_3096c-backend.scm",(void*)f_3096},
{"f_3099c-backend.scm",(void*)f_3099},
{"f_3102c-backend.scm",(void*)f_3102},
{"f_3105c-backend.scm",(void*)f_3105},
{"f_2987c-backend.scm",(void*)f_2987},
{"f_2990c-backend.scm",(void*)f_2990},
{"f_2993c-backend.scm",(void*)f_2993},
{"f_3043c-backend.scm",(void*)f_3043},
{"f_3046c-backend.scm",(void*)f_3046},
{"f_2996c-backend.scm",(void*)f_2996},
{"f_2999c-backend.scm",(void*)f_2999},
{"f_3031c-backend.scm",(void*)f_3031},
{"f_3034c-backend.scm",(void*)f_3034},
{"f_3005c-backend.scm",(void*)f_3005},
{"f_3014c-backend.scm",(void*)f_3014},
{"f_3017c-backend.scm",(void*)f_3017},
{"f_2926c-backend.scm",(void*)f_2926},
{"f_2931c-backend.scm",(void*)f_2931},
{"f_2935c-backend.scm",(void*)f_2935},
{"f_2945c-backend.scm",(void*)f_2945},
{"f_2938c-backend.scm",(void*)f_2938},
{"f_2778c-backend.scm",(void*)f_2778},
{"f_2785c-backend.scm",(void*)f_2785},
{"f_2913c-backend.scm",(void*)f_2913},
{"f_2788c-backend.scm",(void*)f_2788},
{"f_2791c-backend.scm",(void*)f_2791},
{"f_2794c-backend.scm",(void*)f_2794},
{"f_2799c-backend.scm",(void*)f_2799},
{"f_2809c-backend.scm",(void*)f_2809},
{"f_2815c-backend.scm",(void*)f_2815},
{"f_2860c-backend.scm",(void*)f_2860},
{"f_2870c-backend.scm",(void*)f_2870},
{"f_2818c-backend.scm",(void*)f_2818},
{"f_2841c-backend.scm",(void*)f_2841},
{"f_2851c-backend.scm",(void*)f_2851},
{"f_2821c-backend.scm",(void*)f_2821},
{"f_2824c-backend.scm",(void*)f_2824},
{"f_2612c-backend.scm",(void*)f_2612},
{"f_2770c-backend.scm",(void*)f_2770},
{"f_2632c-backend.scm",(void*)f_2632},
{"f_2638c-backend.scm",(void*)f_2638},
{"f_2715c-backend.scm",(void*)f_2715},
{"f_2719c-backend.scm",(void*)f_2719},
{"f_2723c-backend.scm",(void*)f_2723},
{"f_2727c-backend.scm",(void*)f_2727},
{"f_2749c-backend.scm",(void*)f_2749},
{"f_2745c-backend.scm",(void*)f_2745},
{"f_2737c-backend.scm",(void*)f_2737},
{"f_2735c-backend.scm",(void*)f_2735},
{"f_2731c-backend.scm",(void*)f_2731},
{"f_2656c-backend.scm",(void*)f_2656},
{"f_2659c-backend.scm",(void*)f_2659},
{"f_2662c-backend.scm",(void*)f_2662},
{"f_2704c-backend.scm",(void*)f_2704},
{"f_2665c-backend.scm",(void*)f_2665},
{"f_2668c-backend.scm",(void*)f_2668},
{"f_2671c-backend.scm",(void*)f_2671},
{"f_2686c-backend.scm",(void*)f_2686},
{"f_2691c-backend.scm",(void*)f_2691},
{"f_2674c-backend.scm",(void*)f_2674},
{"f_2615c-backend.scm",(void*)f_2615},
{"f_2629c-backend.scm",(void*)f_2629},
{"f_1185c-backend.scm",(void*)f_1185},
{"f_2580c-backend.scm",(void*)f_2580},
{"f_2586c-backend.scm",(void*)f_2586},
{"f_2590c-backend.scm",(void*)f_2590},
{"f_1188c-backend.scm",(void*)f_1188},
{"f_2545c-backend.scm",(void*)f_2545},
{"f_2548c-backend.scm",(void*)f_2548},
{"f_2551c-backend.scm",(void*)f_2551},
{"f_2554c-backend.scm",(void*)f_2554},
{"f_2557c-backend.scm",(void*)f_2557},
{"f_2560c-backend.scm",(void*)f_2560},
{"f_2462c-backend.scm",(void*)f_2462},
{"f_2465c-backend.scm",(void*)f_2465},
{"f_2468c-backend.scm",(void*)f_2468},
{"f_2481c-backend.scm",(void*)f_2481},
{"f_2504c-backend.scm",(void*)f_2504},
{"f_2507c-backend.scm",(void*)f_2507},
{"f_2510c-backend.scm",(void*)f_2510},
{"f_2513c-backend.scm",(void*)f_2513},
{"f_2491c-backend.scm",(void*)f_2491},
{"f_2494c-backend.scm",(void*)f_2494},
{"f_2453c-backend.scm",(void*)f_2453},
{"f_2425c-backend.scm",(void*)f_2425},
{"f_2428c-backend.scm",(void*)f_2428},
{"f_2445c-backend.scm",(void*)f_2445},
{"f_2431c-backend.scm",(void*)f_2431},
{"f_2434c-backend.scm",(void*)f_2434},
{"f_2409c-backend.scm",(void*)f_2409},
{"f_2413c-backend.scm",(void*)f_2413},
{"f_2395c-backend.scm",(void*)f_2395},
{"f_2398c-backend.scm",(void*)f_2398},
{"f_2379c-backend.scm",(void*)f_2379},
{"f_2383c-backend.scm",(void*)f_2383},
{"f_2361c-backend.scm",(void*)f_2361},
{"f_2364c-backend.scm",(void*)f_2364},
{"f_2341c-backend.scm",(void*)f_2341},
{"f_2305c-backend.scm",(void*)f_2305},
{"f_2317c-backend.scm",(void*)f_2317},
{"f_2308c-backend.scm",(void*)f_2308},
{"f_2286c-backend.scm",(void*)f_2286},
{"f_2289c-backend.scm",(void*)f_2289},
{"f_2267c-backend.scm",(void*)f_2267},
{"f_2270c-backend.scm",(void*)f_2270},
{"f_2248c-backend.scm",(void*)f_2248},
{"f_2251c-backend.scm",(void*)f_2251},
{"f_2229c-backend.scm",(void*)f_2229},
{"f_2225c-backend.scm",(void*)f_2225},
{"f_2173c-backend.scm",(void*)f_2173},
{"f_2206c-backend.scm",(void*)f_2206},
{"f_2176c-backend.scm",(void*)f_2176},
{"f_2194c-backend.scm",(void*)f_2194},
{"f_2179c-backend.scm",(void*)f_2179},
{"f_2182c-backend.scm",(void*)f_2182},
{"f_2140c-backend.scm",(void*)f_2140},
{"f_2124c-backend.scm",(void*)f_2124},
{"f_2127c-backend.scm",(void*)f_2127},
{"f_2130c-backend.scm",(void*)f_2130},
{"f_2083c-backend.scm",(void*)f_2083},
{"f_2086c-backend.scm",(void*)f_2086},
{"f_2107c-backend.scm",(void*)f_2107},
{"f_2111c-backend.scm",(void*)f_2111},
{"f_2114c-backend.scm",(void*)f_2114},
{"f_2089c-backend.scm",(void*)f_2089},
{"f_2105c-backend.scm",(void*)f_2105},
{"f_2097c-backend.scm",(void*)f_2097},
{"f_2092c-backend.scm",(void*)f_2092},
{"f_1829c-backend.scm",(void*)f_1829},
{"f_1832c-backend.scm",(void*)f_1832},
{"f_2033c-backend.scm",(void*)f_2033},
{"f_2029c-backend.scm",(void*)f_2029},
{"f_1838c-backend.scm",(void*)f_1838},
{"f_1183c-backend.scm",(void*)f_1183},
{"f_2022c-backend.scm",(void*)f_2022},
{"f_1173c-backend.scm",(void*)f_1173},
{"f_2015c-backend.scm",(void*)f_2015},
{"f_1844c-backend.scm",(void*)f_1844},
{"f_1968c-backend.scm",(void*)f_1968},
{"f_1971c-backend.scm",(void*)f_1971},
{"f_1974c-backend.scm",(void*)f_1974},
{"f_1989c-backend.scm",(void*)f_1989},
{"f_1977c-backend.scm",(void*)f_1977},
{"f_1980c-backend.scm",(void*)f_1980},
{"f_1983c-backend.scm",(void*)f_1983},
{"f_1965c-backend.scm",(void*)f_1965},
{"f_1875c-backend.scm",(void*)f_1875},
{"f_1949c-backend.scm",(void*)f_1949},
{"f_1952c-backend.scm",(void*)f_1952},
{"f_1925c-backend.scm",(void*)f_1925},
{"f_1928c-backend.scm",(void*)f_1928},
{"f_1931c-backend.scm",(void*)f_1931},
{"f_1934c-backend.scm",(void*)f_1934},
{"f_1937c-backend.scm",(void*)f_1937},
{"f_1878c-backend.scm",(void*)f_1878},
{"f_1881c-backend.scm",(void*)f_1881},
{"f_1908c-backend.scm",(void*)f_1908},
{"f_1912c-backend.scm",(void*)f_1912},
{"f_1915c-backend.scm",(void*)f_1915},
{"f_1884c-backend.scm",(void*)f_1884},
{"f_1906c-backend.scm",(void*)f_1906},
{"f_1898c-backend.scm",(void*)f_1898},
{"f_1887c-backend.scm",(void*)f_1887},
{"f_1890c-backend.scm",(void*)f_1890},
{"f_1856c-backend.scm",(void*)f_1856},
{"f_1859c-backend.scm",(void*)f_1859},
{"f_1786c-backend.scm",(void*)f_1786},
{"f_1789c-backend.scm",(void*)f_1789},
{"f_1773c-backend.scm",(void*)f_1773},
{"f_1776c-backend.scm",(void*)f_1776},
{"f_1739c-backend.scm",(void*)f_1739},
{"f_1742c-backend.scm",(void*)f_1742},
{"f_1711c-backend.scm",(void*)f_1711},
{"f_1707c-backend.scm",(void*)f_1707},
{"f_1665c-backend.scm",(void*)f_1665},
{"f_1633c-backend.scm",(void*)f_1633},
{"f_1636c-backend.scm",(void*)f_1636},
{"f_1598c-backend.scm",(void*)f_1598},
{"f_1624c-backend.scm",(void*)f_1624},
{"f_1610c-backend.scm",(void*)f_1610},
{"f_1614c-backend.scm",(void*)f_1614},
{"f_1617c-backend.scm",(void*)f_1617},
{"f_1601c-backend.scm",(void*)f_1601},
{"f_1566c-backend.scm",(void*)f_1566},
{"f_1569c-backend.scm",(void*)f_1569},
{"f_1572c-backend.scm",(void*)f_1572},
{"f_1575c-backend.scm",(void*)f_1575},
{"f_1537c-backend.scm",(void*)f_1537},
{"f_1540c-backend.scm",(void*)f_1540},
{"f_1543c-backend.scm",(void*)f_1543},
{"f_1546c-backend.scm",(void*)f_1546},
{"f_1500c-backend.scm",(void*)f_1500},
{"f_1503c-backend.scm",(void*)f_1503},
{"f_1506c-backend.scm",(void*)f_1506},
{"f_1509c-backend.scm",(void*)f_1509},
{"f_1467c-backend.scm",(void*)f_1467},
{"f_1470c-backend.scm",(void*)f_1470},
{"f_1473c-backend.scm",(void*)f_1473},
{"f_1476c-backend.scm",(void*)f_1476},
{"f_1448c-backend.scm",(void*)f_1448},
{"f_1451c-backend.scm",(void*)f_1451},
{"f_1421c-backend.scm",(void*)f_1421},
{"f_1424c-backend.scm",(void*)f_1424},
{"f_1370c-backend.scm",(void*)f_1370},
{"f_1380c-backend.scm",(void*)f_1380},
{"f_1383c-backend.scm",(void*)f_1383},
{"f_1386c-backend.scm",(void*)f_1386},
{"f_1312c-backend.scm",(void*)f_1312},
{"f_1315c-backend.scm",(void*)f_1315},
{"f_1318c-backend.scm",(void*)f_1318},
{"f_1321c-backend.scm",(void*)f_1321},
{"f_1324c-backend.scm",(void*)f_1324},
{"f_1327c-backend.scm",(void*)f_1327},
{"f_1143c-backend.scm",(void*)f_1143},
{"f_1155c-backend.scm",(void*)f_1155},
{"f_1163c-backend.scm",(void*)f_1163},
{"f_1147c-backend.scm",(void*)f_1147},
{"f_1120c-backend.scm",(void*)f_1120},
{"f_1134c-backend.scm",(void*)f_1134},
{"f_1126c-backend.scm",(void*)f_1126},
{"f_1099c-backend.scm",(void*)f_1099},
{"f_1105c-backend.scm",(void*)f_1105},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
