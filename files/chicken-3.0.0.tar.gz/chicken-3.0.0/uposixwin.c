/* Generated from posixwin.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:28
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: posixwin.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file uposixwin.c
   unit: posix
*/

#include "chicken.h"

#ifndef WIN32_LEAN_AND_MEAN
# define WIN32_LEAN_AND_MEAN
#endif

/*
MinGW should have winsock2.h and ws2tcpip.h as well.
The CMake build will set HAVE_WINSOCK2_H and HAVE_WS2TCPIP_H.
However, the _MSC_VER test is still needed for vcbuild.bat.
./configure doesn't test for these.  It should, for MinGW.
*/
#if (_MSC_VER > 1300) || (defined(HAVE_WINSOCK2_H) && defined(HAVE_WS2TCPIP_H))
# include <winsock2.h>
# include <ws2tcpip.h>
#else
# include <winsock.h>
#endif

#include <signal.h>
#include <errno.h>
#include <io.h>
#include <stdio.h>
#include <process.h>

static int C_not_implemented(void);
int C_not_implemented() { return -1; }

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <direct.h>

#include <time.h>

#define ARG_MAX		256
#define PIPE_BUF	512
#ifndef ENV_MAX
# define ENV_MAX	1024
#endif

static C_TLS char *C_exec_args[ ARG_MAX ];
static C_TLS char *C_exec_env[ ENV_MAX ];
static C_TLS struct group *C_group;
static C_TLS int C_pipefds[ 2 ];
static C_TLS time_t C_secs;
static C_TLS struct tm C_tm;
static C_TLS struct stat C_statbuf;

/* pipe handles */
static C_TLS HANDLE C_rd0, C_wr0, C_wr0_, C_rd1, C_wr1, C_rd1_;
static C_TLS HANDLE C_save0, C_save1; /* saved I/O handles */
static C_TLS char C_rdbuf; /* one-char buffer for read */
static C_TLS int C_exstatus;

/* platform information; initialized for cached testing */
static C_TLS char C_hostname[256] = "";
static C_TLS char C_osver[16] = "";
static C_TLS char C_osrel[16] = "";
static C_TLS char C_processor[16] = "";
static C_TLS char C_shlcmd[256] = "";

/* Windows NT or better */
static int C_isNT = 0;

/* Current user name */
static C_TLS TCHAR C_username[255 + 1] = "";

/* Directory Operations */

#define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#define C_chdir(str)	    C_fix(chdir(C_c_string(str)))
#define C_rmdir(str)	    C_fix(rmdir(C_c_string(str)))

#ifndef __WATCOMC__
/* DIRENT stuff */
struct dirent
{
    char *		d_name;
};

typedef struct
{
    struct _finddata_t	fdata;
    int			handle;
    struct dirent	current;
} DIR;

static DIR * C_fcall
opendir(const char *name)
{
    int name_len = strlen(name);
    DIR *dir = (DIR *)malloc(sizeof(DIR));
    char *what;
    if (!dir)
    {
	errno = ENOMEM;
	return NULL;
    }
    what = (char *)malloc(name_len + 3);
    if (!what)
    {
	free(dir);
	errno = ENOMEM;
	return NULL;
    }
    strcpy(what, name);
    if (strchr("\\/", name[name_len - 1]))
	strcat(what, "*");
    else
	strcat(what, "\\*");

    dir->handle = _findfirst(what, &dir->fdata);
    if (dir->handle == -1)
    {
	free(what);
	free(dir);
	return NULL;
    }
    dir->current.d_name = NULL; /* as the first-time indicator */
    free(what);
    return dir;
}

static int C_fcall
closedir(DIR * dir)
{
    if (dir)
    {
	int res = _findclose(dir->handle);
	free(dir);
	return res;
    }
    return -1;
}

static struct dirent * C_fcall
readdir(DIR * dir)
{
    if (dir)
    {
	if (!dir->current.d_name /* first time after opendir */
	     || _findnext(dir->handle, &dir->fdata) != -1)
	{
	    dir->current.d_name = dir->fdata.name;
	    return &dir->current;
	}
    }
    return NULL;
}
#endif /* ifndef __WATCOMC__ */

#ifdef __WATCOMC__
# define mktemp _mktemp
/* there is no P_DETACH in Watcom CRTL */
# define P_DETACH P_NOWAIT
#endif

#define C_opendir(x,h)		C_set_block_item(h, 0, (C_word) opendir(C_c_string(x)))
#define C_closedir(h)		(closedir((DIR *)C_block_item(h, 0)), C_SCHEME_UNDEFINED)
#define C_readdir(h,e)		C_set_block_item(e, 0, (C_word) readdir((DIR *)C_block_item(h, 0)))
#define C_foundfile(e,b)	(strcpy(C_c_string(b), ((struct dirent *) C_block_item(e, 0))->d_name), C_fix(strlen(((struct dirent *) C_block_item(e, 0))->d_name)))

#define C_curdir(buf)	    (getcwd(C_c_string(buf), 256) ? C_fix(strlen(C_c_string(buf))) : C_SCHEME_FALSE)

#define open_binary_input_pipe(a, n, name)   C_mpointer(a, _popen(C_c_string(name), "r"))
#define open_text_input_pipe(a, n, name)     open_binary_input_pipe(a, n, name)
#define open_binary_output_pipe(a, n, name)  C_mpointer(a, _popen(C_c_string(name), "w"))
#define open_text_output_pipe(a, n, name)    open_binary_output_pipe(a, n, name)
#define close_pipe(p)			     C_fix(_pclose(C_port_file(p)))

#define C_set_file_ptr(port, ptr)  (C_set_block_item(port, 0, (C_block_item(ptr, 0))), C_SCHEME_UNDEFINED)

#define C_getpid	    getpid
#define C_chmod(fn, m)	    C_fix(chmod(C_data_pointer(fn), C_unfix(m)))
#define C_fdopen(a, n, fd, m) C_mpointer(a, fdopen(C_unfix(fd), C_c_string(m)))
#define C_C_fileno(p)	    C_fix(fileno(C_port_file(p)))
#define C_dup(x)	    C_fix(dup(C_unfix(x)))
#define C_dup2(x, y)	    C_fix(dup2(C_unfix(x), C_unfix(y)))
#define C_setvbuf(p, m, s)  C_fix(setvbuf(C_port_file(p), NULL, C_unfix(m), C_unfix(s)))
#define C_access(fn, m)	    C_fix(access((char *)C_data_pointer(fn), C_unfix(m)))
#define C_pipe(d, m)	    C_fix(_pipe(C_pipefds, PIPE_BUF, C_unfix(m)))
#define C_close(fd)	    C_fix(close(C_unfix(fd)))

#define C_getenventry(i)   environ[ i ]

#define C_putenv(s)	    C_fix(putenv((char *)C_data_pointer(s)))
#define C_stat(fn)	    C_fix(stat((char *)C_data_pointer(fn), &C_statbuf))
#define C_fstat(f)	    C_fix(fstat(C_unfix(f), &C_statbuf))

static C_word C_fcall
C_setenv(C_word x, C_word y)
{
    char *sx = C_data_pointer(x),
	 *sy = C_data_pointer(y);
    int n1 = C_strlen(sx),
	n2 = C_strlen(sy);
    char *buf = (char *)C_malloc(n1 + n2 + 2);
    if (buf == NULL)
	return(C_fix(0));
    else
    {
	C_strcpy(buf, sx);
	buf[ n1 ] = '=';
	C_strcpy(buf + n1 + 1, sy);
	return(C_fix(putenv(buf)));
    }
}

static void C_fcall
C_set_arg_string(char **where, int i, char *dat, int len)
{
    char *ptr;
    if (dat)
    {
	ptr = (char *)C_malloc(len + 1);
	C_memcpy(ptr, dat, len);
	ptr[ len ] = '\0';
    }
    else
	ptr = NULL;
    where[ i ] = ptr;
}

static void C_fcall
C_free_arg_string(char **where) {
  while (*where) C_free(*(where++));
}

#define C_set_exec_arg(i, a, len)	C_set_arg_string(C_exec_args, i, a, len)
#define C_set_exec_env(i, a, len)	C_set_arg_string(C_exec_env, i, a, len)

#define C_free_exec_args()		(C_free_arg_string(C_exec_args), C_SCHEME_TRUE)
#define C_free_exec_env()		(C_free_arg_string(C_exec_env), C_SCHEME_TRUE)

#define C_execvp(f)	    C_fix(execvp(C_data_pointer(f), (const char *const *)C_exec_args))
#define C_execve(f)	    C_fix(execve(C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

/* MS replacement for the fork-exec pair */
#define C_spawnvp(m, f)	    C_fix(spawnvp(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args))
#define C_spawnvpe(m, f)    C_fix(spawnvpe(C_unfix(m), C_data_pointer(f), (const char *const *)C_exec_args, (const char *const *)C_exec_env))

#define C_open(fn, fl, m)   C_fix(open(C_c_string(fn), C_unfix(fl), C_unfix(m)))
#define C_read(fd, b, n)    C_fix(read(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_write(fd, b, n)   C_fix(write(C_unfix(fd), C_data_pointer(b), C_unfix(n)))
#define C_mkstemp(t)	    C_fix(mktemp(C_c_string(t)))

#define C_ftell(p)	    C_fix(ftell(C_port_file(p)))
#define C_fseek(p, n, w)    C_mk_nbool(fseek(C_port_file(p), C_unfix(n), C_unfix(w)))
#define C_lseek(fd, o, w)   C_fix(lseek(C_unfix(fd), C_unfix(o), C_unfix(w)))

#define C_flushall()	    C_fix(_flushall())

#define C_ctime(n)	    (C_secs = (n), ctime(&C_secs))

#define C_asctime(v)	    (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), asctime(&C_tm) )
#define C_mktime(v)	    (memset(&C_tm, 0, sizeof(struct tm)), C_tm.tm_sec = C_unfix(C_block_item(v, 0)), C_tm.tm_min = C_unfix(C_block_item(v, 1)), C_tm.tm_hour = C_unfix(C_block_item(v, 2)), C_tm.tm_mday = C_unfix(C_block_item(v, 3)), C_tm.tm_mon = C_unfix(C_block_item(v, 4)), C_tm.tm_year = C_unfix(C_block_item(v, 5)), C_tm.tm_wday = C_unfix(C_block_item(v, 6)), C_tm.tm_yday = C_unfix(C_block_item(v, 7)), C_tm.tm_isdst = (C_block_item(v, 8) != C_SCHEME_FALSE), (C_temporary_flonum = mktime(&C_tm)) != -1)

/*
  mapping from Win32 error codes to errno
*/

typedef struct
{
    DWORD   win32;
    int	    libc;
} errmap_t;

static errmap_t errmap[] =
{
    {ERROR_INVALID_FUNCTION,	  EINVAL},
    {ERROR_FILE_NOT_FOUND,	  ENOENT},
    {ERROR_PATH_NOT_FOUND,	  ENOENT},
    {ERROR_TOO_MANY_OPEN_FILES,	  EMFILE},
    {ERROR_ACCESS_DENIED,	  EACCES},
    {ERROR_INVALID_HANDLE,	  EBADF},
    {ERROR_ARENA_TRASHED,	  ENOMEM},
    {ERROR_NOT_ENOUGH_MEMORY,	  ENOMEM},
    {ERROR_INVALID_BLOCK,	  ENOMEM},
    {ERROR_BAD_ENVIRONMENT,	  E2BIG},
    {ERROR_BAD_FORMAT,		  ENOEXEC},
    {ERROR_INVALID_ACCESS,	  EINVAL},
    {ERROR_INVALID_DATA,	  EINVAL},
    {ERROR_INVALID_DRIVE,	  ENOENT},
    {ERROR_CURRENT_DIRECTORY,	  EACCES},
    {ERROR_NOT_SAME_DEVICE,	  EXDEV},
    {ERROR_NO_MORE_FILES,	  ENOENT},
    {ERROR_LOCK_VIOLATION,	  EACCES},
    {ERROR_BAD_NETPATH,		  ENOENT},
    {ERROR_NETWORK_ACCESS_DENIED, EACCES},
    {ERROR_BAD_NET_NAME,	  ENOENT},
    {ERROR_FILE_EXISTS,		  EEXIST},
    {ERROR_CANNOT_MAKE,		  EACCES},
    {ERROR_FAIL_I24,		  EACCES},
    {ERROR_INVALID_PARAMETER,	  EINVAL},
    {ERROR_NO_PROC_SLOTS,	  EAGAIN},
    {ERROR_DRIVE_LOCKED,	  EACCES},
    {ERROR_BROKEN_PIPE,		  EPIPE},
    {ERROR_DISK_FULL,		  ENOSPC},
    {ERROR_INVALID_TARGET_HANDLE, EBADF},
    {ERROR_INVALID_HANDLE,	  EINVAL},
    {ERROR_WAIT_NO_CHILDREN,	  ECHILD},
    {ERROR_CHILD_NOT_COMPLETE,	  ECHILD},
    {ERROR_DIRECT_ACCESS_HANDLE,  EBADF},
    {ERROR_NEGATIVE_SEEK,	  EINVAL},
    {ERROR_SEEK_ON_DEVICE,	  EACCES},
    {ERROR_DIR_NOT_EMPTY,	  ENOTEMPTY},
    {ERROR_NOT_LOCKED,		  EACCES},
    {ERROR_BAD_PATHNAME,	  ENOENT},
    {ERROR_MAX_THRDS_REACHED,	  EAGAIN},
    {ERROR_LOCK_FAILED,		  EACCES},
    {ERROR_ALREADY_EXISTS,	  EEXIST},
    {ERROR_FILENAME_EXCED_RANGE,  ENOENT},
    {ERROR_NESTING_NOT_ALLOWED,	  EAGAIN},
    {ERROR_NOT_ENOUGH_QUOTA,	  ENOMEM},
    {0, 0}
};

static void C_fcall
set_errno(DWORD w32err)
{
    errmap_t *map = errmap;
    for (; errmap->win32; ++map)
    {
	if (errmap->win32 == w32err)
	{
	    errno = errmap->libc;
	    return;
	}
    }
}

static int C_fcall
set_last_errno()
{
    set_errno(GetLastError());
    return 0;
}

/* Functions for creating process with redirected I/O */

static int C_fcall
zero_handles()
{
    C_rd0 = C_wr0 = C_wr0_ = INVALID_HANDLE_VALUE;
    C_rd1 = C_wr1 = C_rd1_ = INVALID_HANDLE_VALUE;
    C_save0 = C_save1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
close_handles()
{
    if (C_rd0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd0);
    if (C_rd1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1);
    if (C_wr0 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0);
    if (C_wr1 != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr1);
    if (C_rd1_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_rd1_);
    if (C_wr0_ != INVALID_HANDLE_VALUE)
	CloseHandle(C_wr0_);
    if (C_save0 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	CloseHandle(C_save0);
    }
    if (C_save1 != INVALID_HANDLE_VALUE)
    {
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	CloseHandle(C_save1);
    }
    return zero_handles();
}

static int C_fcall
redir_io()
{
    SECURITY_ATTRIBUTES sa;
    sa.nLength = sizeof(SECURITY_ATTRIBUTES);
    sa.bInheritHandle = TRUE;
    sa.lpSecurityDescriptor = NULL;

    zero_handles();

    C_save0 = GetStdHandle(STD_INPUT_HANDLE);
    C_save1 = GetStdHandle(STD_OUTPUT_HANDLE);
    if (!CreatePipe(&C_rd0, &C_wr0, &sa, 0)
	    || !SetStdHandle(STD_INPUT_HANDLE, C_rd0)
	    || !DuplicateHandle(GetCurrentProcess(), C_wr0, GetCurrentProcess(),
		&C_wr0_, 0, FALSE, DUPLICATE_SAME_ACCESS)
	    || !CreatePipe(&C_rd1, &C_wr1, &sa, 0)
	    || !SetStdHandle(STD_OUTPUT_HANDLE, C_wr1)
	    || !DuplicateHandle(GetCurrentProcess(), C_rd1, GetCurrentProcess(),
		&C_rd1_, 0, FALSE, DUPLICATE_SAME_ACCESS))
    {
	set_last_errno();
	close_handles();
	return 0;
    }

    CloseHandle(C_wr0);
    C_wr0 = INVALID_HANDLE_VALUE;
    CloseHandle(C_rd1);
    C_rd1 = INVALID_HANDLE_VALUE;
    return 1;
}

static int C_fcall
run_process(char *cmdline)
{
    PROCESS_INFORMATION pi;
    STARTUPINFO si;

    ZeroMemory(&pi, sizeof(PROCESS_INFORMATION));
    ZeroMemory(&si, sizeof(STARTUPINFO));
    si.cb = sizeof(STARTUPINFO);

    C_wr0_ = C_rd1_ = INVALID_HANDLE_VALUE; /* these handles are saved */

    if (CreateProcess(NULL, cmdline, NULL, NULL, TRUE, 0, NULL,
		      NULL, &si, &pi))
    {
	CloseHandle(pi.hThread);

	SetStdHandle(STD_INPUT_HANDLE, C_save0);
	SetStdHandle(STD_OUTPUT_HANDLE, C_save1);
	C_save0 = C_save1 = INVALID_HANDLE_VALUE;

	CloseHandle(C_rd0);
	CloseHandle(C_wr1);
	C_rd0 = C_wr1 = INVALID_HANDLE_VALUE;
	return (int)pi.hProcess;
    }
    else
	return set_last_errno();
}

static int C_fcall
pipe_write(int hpipe, void* buf, int count)
{
    DWORD done = 0;
    if (WriteFile((HANDLE)hpipe, buf, count, &done, NULL))
	return 1;
    else
	return set_last_errno();
}

static int C_fcall
pipe_read(int hpipe)
{
    DWORD done = 0;
    /* TODO:
    if (!pipe_ready(hpipe))
	go_to_sleep;
    */
    if (ReadFile((HANDLE)hpipe, &C_rdbuf, 1, &done, NULL))
    {
	if (done > 0) /* not EOF yet */
	    return 1;
	else
	    return -1;
    }
    return set_last_errno();
}

static int C_fcall
pipe_ready(int hpipe)
{
    DWORD avail = 0;
    if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL) && avail)
	return 1;
    else
    {
	Sleep(0); /* give pipe a chance */
	if (PeekNamedPipe((HANDLE)hpipe, NULL, 0, NULL, &avail, NULL))
	    return (avail > 0);
	else
	    return 0;
    }
}

#define C_zero_handles() C_fix(zero_handles())
#define C_close_handles() C_fix(close_handles())
#define C_redir_io() (redir_io() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_run_process(cmdline) C_fix(run_process(C_c_string(cmdline)))
#define C_pipe_write(h, b, n) (pipe_write(C_unfix(h), C_c_string(b), C_unfix(n)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_pipe_read(h) C_fix(pipe_read(C_unfix(h)))
#define C_pipe_ready(h) (pipe_ready(C_unfix(h)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define close_handle(h) CloseHandle((HANDLE)h)

static int C_fcall
process_wait(int h, int t)
{
    if (WaitForSingleObject((HANDLE)h, (t ? 0 : INFINITE)) == WAIT_OBJECT_0)
    {
	DWORD ret;
	if (GetExitCodeProcess((HANDLE)h, &ret))
	{
	    CloseHandle((HANDLE)h);
	    C_exstatus = ret;
	    return 1;
	}
    }
    return set_last_errno();
}

#define C_process_wait(p, t) (process_wait(C_unfix(p), C_truep(t)) ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sleep(t) (Sleep(C_unfix(t) * 1000), C_SCHEME_UNDEFINED)

static int C_fcall
get_hostname()
{
    /* Do we already have hostname? */
    if (strlen(C_hostname))
    {
	return 1;
    }
    else
    {
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(1, 1), &wsa) == 0)
	{
	    int nok = gethostname(C_hostname, sizeof(C_hostname));
	    WSACleanup();
	    return !nok;
	}
	return 0;
    }
}

static int C_fcall
sysinfo()
{
    /* Do we need to build the sysinfo? */
    if (!strlen(C_osrel))
    {
	OSVERSIONINFO ovf;
	ZeroMemory(&ovf, sizeof(ovf));
	ovf.dwOSVersionInfoSize = sizeof(ovf);
	if (get_hostname() && GetVersionEx(&ovf))
	{
	    SYSTEM_INFO si;
	    _snprintf(C_osver, sizeof(C_osver) - 1, "%d.%d.%d",
			ovf.dwMajorVersion, ovf.dwMinorVersion, ovf.dwBuildNumber);
	    strncpy(C_osrel, "Win", sizeof(C_osrel) - 1);
	    switch (ovf.dwPlatformId)
	    {
	    case VER_PLATFORM_WIN32s:
		strncpy(C_osrel, "Win32s", sizeof(C_osrel) - 1);
		break;
	    case VER_PLATFORM_WIN32_WINDOWS:
		if (ovf.dwMajorVersion == 4)
		{
		    if (ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win95", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 10)
			strncpy(C_osrel, "Win98", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 90)
			strncpy(C_osrel, "WinMe", sizeof(C_osrel) - 1);
		}
		break;
	    case VER_PLATFORM_WIN32_NT:
		C_isNT = 1;
		if (ovf.dwMajorVersion == 6)
		    strncpy(C_osrel, "WinVista", sizeof(C_osrel) - 1);
		else if (ovf.dwMajorVersion == 5)
		{
		    if (ovf.dwMinorVersion == 2)
			strncpy(C_osrel, "WinServer2003", sizeof(C_osrel) - 1);
		    else if (ovf.dwMinorVersion == 1)
			strncpy(C_osrel, "WinXP", sizeof(C_osrel) - 1);
		    else if ( ovf.dwMinorVersion == 0)
			strncpy(C_osrel, "Win2000", sizeof(C_osrel) - 1);
		}
		else if (ovf.dwMajorVersion <= 4)
		   strncpy(C_osrel, "WinNT", sizeof(C_osrel) - 1);
		break;
	    }
	    GetSystemInfo(&si);
	    strncpy(C_processor, "Unknown", sizeof(C_processor) - 1);
	    switch (si.wProcessorArchitecture)
	    {
	    case PROCESSOR_ARCHITECTURE_INTEL:
		strncpy(C_processor, "x86", sizeof(C_processor) - 1);
		break;
#	    ifdef PROCESSOR_ARCHITECTURE_IA64
	    case PROCESSOR_ARCHITECTURE_IA64:
		strncpy(C_processor, "IA64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_AMD64
	    case PROCESSOR_ARCHITECTURE_AMD64:
		strncpy(C_processor, "x64", sizeof(C_processor) - 1);
		break;
#	    endif
#	    ifdef PROCESSOR_ARCHITECTURE_IA32_ON_WIN64
	    case PROCESSOR_ARCHITECTURE_IA32_ON_WIN64:
		strncpy(C_processor, "WOW64", sizeof(C_processor) - 1);
		break;
#	    endif
	    }
	}
	else
	    return set_last_errno();
    }
    return 1;
}

static int C_fcall
get_shlcmd()
{
    /* Do we need to build the shell command pathname? */
    if (!strlen(C_shlcmd))
    {
	if (sysinfo())
	{
	    char *cmdnam = C_isNT ? "\\cmd.exe" : "\\command.com";
	    UINT len = GetSystemDirectory(C_shlcmd, sizeof(C_shlcmd) - strlen(cmdnam));
	    if (len)
		strcpy(C_shlcmd + len, cmdnam);
	    else
		return set_last_errno();
	}
	else
	    return 0;
    }
    return 1;
}

#define C_get_hostname() (get_hostname() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_sysinfo() (sysinfo() ? C_SCHEME_TRUE : C_SCHEME_FALSE)
#define C_get_shlcmd() (get_shlcmd() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* GetUserName */

static int C_fcall
get_user_name()
{
    if (!strlen(C_username))
    {
	DWORD bufCharCount = sizeof(C_username) / sizeof(C_username[0]);
	if (!GetUserName(C_username, &bufCharCount))
	    return set_last_errno();
    }
    return 1;
}

#define C_get_user_name() (get_user_name() ? C_SCHEME_TRUE : C_SCHEME_FALSE)

/* User Information */

#if 0
static int C_fcall
get_netinfo()
{
    HINSTANCE hNet = 0,
	      hLoc = 0;

    if (isNT)
	hNet = LoadLibrary("netapi32.dll");
    else
    {
	hLoc = LoadLibrary("rlocal32.dll");
	hNet = LoadLibrary("radmin32.dll");
	//hNet = LoadLibrary("netapi.dll");
    }

    if (!hNet)
	return 0;

    
}
#endif

/*
    Spawn a process directly.
    Params:
    app		Command to execute.
    cmdlin	Command line (arguments).
    env		Environment for the new process (may be NULL).
    handle, stdin, stdout, stderr
		Spawned process info are returned in integers.
		When spawned process shares standard io stream with the parent
		process the respective value in handle, stdin, stdout, stderr
		is -1.
    params	A bitmask controling operation.
		Bit 1: Child & parent share standard input if this bit is set.
		Bit 2: Share standard output if bit is set.
		Bit 3: Share standard error if bit is set.

    Returns: zero return value indicates failure.
*/
static int C_fcall
C_process(const char * app, const char * cmdlin, const char ** env,
	  int * phandle,
	  int * pstdin_fd, int * pstdout_fd, int * pstderr_fd,
	  int params)
{
    int i;
    int success = TRUE;
    const int f_share_io[3] = { params & 1, params & 2, params & 4};
    int io_fds[3] = { -1, -1, -1 };
    HANDLE
	child_io_handles[3] = { NULL, NULL, NULL },
	standard_io_handles[3] = {
	    GetStdHandle(STD_INPUT_HANDLE),
	    GetStdHandle(STD_OUTPUT_HANDLE),
	    GetStdHandle(STD_ERROR_HANDLE)};
    const char modes[3] = "rww";
    HANDLE cur_process = GetCurrentProcess(), child_process = NULL;
    void* envblk = NULL;

    /****** create io handles & fds ***/

    for (i=0; i<3 && success; ++i)
    {
	if (f_share_io[i])
	{
	    success = DuplicateHandle(
		cur_process, standard_io_handles[i],
		cur_process, &child_io_handles[i],
		0, FALSE, DUPLICATE_SAME_ACCESS);
	}
	else
	{
	    HANDLE a, b;
	    success = CreatePipe(&a,&b,NULL,0);
	    if(success)
	    {
		HANDLE parent_end;
		if (modes[i]=='r') { child_io_handles[i]=a; parent_end=b; }
		else		   { parent_end=a; child_io_handles[i]=b; }
		success = (io_fds[i] = _open_osfhandle((long)parent_end,0)) >= 0;
	    }
	}
    }

    /****** make handles inheritable */

    for (i=0; i<3 && success; ++i)
	success = SetHandleInformation(child_io_handles[i], HANDLE_FLAG_INHERIT, -1);

#if 0 /* Requires a sorted list by key! */
    /****** create environment block if necessary ****/

    if (env && success)
    {
	char** p;
	int len = 0;

	for (p = env; *p; ++p) len += strlen(*p) + 1;

	if (envblk = C_malloc(len + 1))
	{
	    char* pb = (char*)envblk;
	    for (p = env; *p; ++p)
	    {
		strcpy(pb, *p);
		pb += strlen(*p) + 1;
	    }
	    *pb = '\0';
	}
	else
	    success = FALSE;
    }
#endif

    /****** finally spawn process ****/

    if (success)
    {
	PROCESS_INFORMATION pi;
	STARTUPINFO si;

	ZeroMemory(&pi,sizeof pi);
	ZeroMemory(&si,sizeof si);
	si.cb = sizeof si;
	si.dwFlags = STARTF_USESTDHANDLES;
	si.hStdInput = child_io_handles[0];
	si.hStdOutput = child_io_handles[1];
	si.hStdError = child_io_handles[2];

	/* FIXME passing 'app' param causes failure & possible stack corruption */
	success = CreateProcess(
	    NULL, (char*)cmdlin, NULL, NULL, TRUE, 0, envblk, NULL, &si, &pi);

	if (success)
	{
	    child_process=pi.hProcess;
	    CloseHandle(pi.hThread);
	}
	else
	    set_last_errno();
    }
    else
	set_last_errno();

    /****** cleanup & return *********/

    /* parent must close child end */
    for (i=0; i<3; ++i) CloseHandle(child_io_handles[i]);

    if (success)
    {
	*phandle = (int)child_process;
	*pstdin_fd = io_fds[0];
	*pstdout_fd = io_fds[1];
	*pstderr_fd = io_fds[2];
    }
    else
    {
	for (i=0; i<3; ++i) _close(io_fds[i]);
    }

    return success;
}

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[363];
static double C_possibly_force_alignment;


/* from k3283 */
static C_word C_fcall stub556(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7) C_regparm;
C_regparm static C_word C_fcall stub556(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4,C_word C_a5,C_word C_a6,C_word C_a7){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
int *t3=(int *)C_c_pointer_or_null(C_a3);
int *t4=(int *)C_c_pointer_or_null(C_a4);
int *t5=(int *)C_c_pointer_or_null(C_a5);
int *t6=(int *)C_c_pointer_or_null(C_a6);
int t7=(int )C_unfix(C_a7);
C_r=C_mk_bool(C_process(t0,t1,t2,t3,t4,t5,t6,t7));
return C_r;}

/* from close-handle in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall stub544(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub544(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_truep(C_a0);
C_r=C_fix((C_word)close_handle(t0));
return C_r;}

/* from current-process-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall stub532(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub532(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_r=C_fix((C_word)C_getpid());
return C_r;}

/* from k2925 */
static C_word C_fcall stub435(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub435(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_env(t0,t1,t2);
return C_r;}

/* from k2919 */
static C_word C_fcall stub425(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub425(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_set_exec_arg(t0,t1,t2);
return C_r;}

/* from ex0 */
static C_word C_fcall stub354(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub354(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
_exit(t0);
return C_r;}

/* from local-timezone-abbreviation in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub349(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub349(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char *z = (daylight ? _tzname[1] : _tzname[0]);return(z);
C_ret:
#undef return

return C_r;}

/* from asctime */
static C_word C_fcall stub337(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub337(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word t0=(C_word )(C_a0);
C_r=C_mpointer(&C_a,(void*)C_asctime(t0));
return C_r;}

/* from ctime */
static C_word C_fcall stub328(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub328(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_mpointer(&C_a,(void*)C_ctime(t0));
return C_r;}

/* from get */
static C_word C_fcall stub311(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub311(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)C_getenventry(t0));
return C_r;}

/* from strerror */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

C_noret_decl(C_posix_toplevel)
C_externexport void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1058)
static void C_ccall f_1058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4231)
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4158)
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4146)
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4092)
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4062)
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4056)
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4038)
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4020)
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4014)
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4008)
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3978)
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3749)
static void C_ccall f_3749r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3906)
static void C_fcall f_3906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3901)
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3896)
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3751)
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3883)
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3758)
static void C_fcall f_3758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3768)
static void C_ccall f_3768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_fcall f_3770(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3851)
static void C_ccall f_3851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3744)
static void C_ccall f_3744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3703)
static void C_ccall f_3703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3691)
static void C_ccall f_3691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3655)
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3542)
static void C_ccall f_3542r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3559)
static void C_fcall f_3559(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_fcall f_3554(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3549)
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3544)
static void C_fcall f_3544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3465)
static void C_ccall f_3465r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3482)
static void C_fcall f_3482(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_fcall f_3477(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3472)
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3467)
static void C_fcall f_3467(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3403)
static void C_fcall f_3403(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3438)
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t10) C_noret;
C_noret_decl(f_3386)
static void C_ccall f_3386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3362)
static void C_ccall f_3362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3347)
static void C_ccall f_3347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3253)
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3224)
static void C_ccall f_3224r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3241)
static void C_ccall f_3241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3197)
static void C_ccall f_3197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3213)
static void C_ccall f_3213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3110)
static void C_ccall f_3110r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3134)
static void C_fcall f_3134(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_fcall f_3129(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3124)
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3112)
static void C_fcall f_3112(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3116)
static void C_ccall f_3116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3026)
static void C_ccall f_3026r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3050)
static void C_fcall f_3050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3045)
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3040)
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3028)
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3032)
static void C_ccall f_3032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3011)
static void C_fcall f_3011(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2978)
static void C_fcall f_2978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3001)
static void C_ccall f_3001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2928)
static void C_fcall f_2928(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2940)
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2837)
static void C_fcall f_2837(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2880)
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2911)
static void C_ccall f_2911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2851)
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2722)
static void C_ccall f_2722r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2728)
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2826)
static void C_ccall f_2826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2756)
static void C_ccall f_2756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2759)
static void C_ccall f_2759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2663)
static void C_ccall f_2663r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2667)
static void C_ccall f_2667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2673)
static void C_ccall f_2673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2611)
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2582)
static void C_ccall f_2582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2544)
static void C_ccall f_2544(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2551)
static void C_ccall f_2551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_fcall f_2462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2500)
static void C_ccall f_2500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2449)
static void C_ccall f_2449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2424)
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2435)
static void C_ccall f_2435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2401)
static void C_fcall f_2401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2410)
static void C_ccall f_2410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2392)
static void C_ccall f_2392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2378)
static void C_ccall f_2378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2372)
static void C_ccall f_2372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2345)
static void C_ccall f_2345r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2267)
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2231)
static void C_fcall f_2231(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_ccall f_2249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2201)
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2038)
static void C_ccall f_2038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1990)
static void C_ccall f_1990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_ccall f_1975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1875)
static void C_ccall f_1875r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_fcall f_1857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_fcall f_1851(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static C_word C_fcall f_1839(C_word t0);
C_noret_decl(f_1800)
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1800)
static void C_ccall f_1800r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1780)
static void C_ccall f_1780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1616)
static void C_ccall f_1616r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1724)
static void C_fcall f_1724(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1719)
static void C_fcall f_1719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1618)
static void C_fcall f_1618(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1635)
static void C_ccall f_1635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_fcall f_1652(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1674)
static void C_fcall f_1674(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_ccall f_1684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1602)
static void C_ccall f_1602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1535)
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1556)
static void C_ccall f_1556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1496)
static void C_ccall f_1496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1453)
static void C_ccall f_1453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1438)
static void C_ccall f_1438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1447)
static void C_ccall f_1447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1428)
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1426)
static void C_ccall f_1426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1412)
static void C_ccall f_1412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1403)
static void C_ccall f_1403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1391)
static void C_ccall f_1391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_fcall f_1307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1227)
static void C_ccall f_1227r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1234)
static void C_ccall f_1234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1182)
static void C_ccall f_1182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1192)
static void C_ccall f_1192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1195)
static void C_ccall f_1195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1198)
static void C_ccall f_1198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1156)
static void C_ccall f_1156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1088)
static void C_ccall f_1088(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3906)
static void C_fcall trf_3906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3906(t0,t1);}

C_noret_decl(trf_3901)
static void C_fcall trf_3901(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3901(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3901(t0,t1,t2);}

C_noret_decl(trf_3896)
static void C_fcall trf_3896(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3896(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3896(t0,t1,t2,t3);}

C_noret_decl(trf_3751)
static void C_fcall trf_3751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3751(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3751(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3758)
static void C_fcall trf_3758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3758(t0,t1);}

C_noret_decl(trf_3770)
static void C_fcall trf_3770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3770(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3770(t0,t1,t2,t3);}

C_noret_decl(trf_3559)
static void C_fcall trf_3559(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3559(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3559(t0,t1);}

C_noret_decl(trf_3554)
static void C_fcall trf_3554(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3554(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3554(t0,t1,t2);}

C_noret_decl(trf_3549)
static void C_fcall trf_3549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3549(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3549(t0,t1,t2,t3);}

C_noret_decl(trf_3544)
static void C_fcall trf_3544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3544(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3544(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3482)
static void C_fcall trf_3482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3482(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3482(t0,t1);}

C_noret_decl(trf_3477)
static void C_fcall trf_3477(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3477(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3477(t0,t1,t2);}

C_noret_decl(trf_3472)
static void C_fcall trf_3472(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3472(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3472(t0,t1,t2,t3);}

C_noret_decl(trf_3467)
static void C_fcall trf_3467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3467(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3467(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3403)
static void C_fcall trf_3403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3403(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3403(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3405)
static void C_fcall trf_3405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3405(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3405(t0,t1,t2);}

C_noret_decl(trf_3134)
static void C_fcall trf_3134(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3134(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3134(t0,t1);}

C_noret_decl(trf_3129)
static void C_fcall trf_3129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3129(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3129(t0,t1,t2);}

C_noret_decl(trf_3124)
static void C_fcall trf_3124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3124(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3124(t0,t1,t2,t3);}

C_noret_decl(trf_3112)
static void C_fcall trf_3112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3112(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3112(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3050)
static void C_fcall trf_3050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3050(t0,t1);}

C_noret_decl(trf_3045)
static void C_fcall trf_3045(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3045(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3045(t0,t1,t2);}

C_noret_decl(trf_3040)
static void C_fcall trf_3040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3040(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3040(t0,t1,t2,t3);}

C_noret_decl(trf_3028)
static void C_fcall trf_3028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3028(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3028(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3011)
static void C_fcall trf_3011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3011(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3011(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2978)
static void C_fcall trf_2978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2978(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2978(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2928)
static void C_fcall trf_2928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2928(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2928(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2940)
static void C_fcall trf_2940(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2940(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2940(t0,t1,t2,t3);}

C_noret_decl(trf_2837)
static void C_fcall trf_2837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2837(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2837(t0,t1,t2,t3);}

C_noret_decl(trf_2880)
static void C_fcall trf_2880(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2880(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2880(t0,t1,t2,t3);}

C_noret_decl(trf_2842)
static void C_fcall trf_2842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2842(t0,t1,t2);}

C_noret_decl(trf_2851)
static void C_fcall trf_2851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2851(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2851(t0,t1,t2);}

C_noret_decl(trf_2728)
static void C_fcall trf_2728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2728(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2728(t0,t1,t2);}

C_noret_decl(trf_2768)
static void C_fcall trf_2768(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2768(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2768(t0,t1,t2);}

C_noret_decl(trf_2462)
static void C_fcall trf_2462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2462(t0,t1,t2);}

C_noret_decl(trf_2474)
static void C_fcall trf_2474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2474(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2474(t0,t1,t2);}

C_noret_decl(trf_2401)
static void C_fcall trf_2401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2401(t0,t1);}

C_noret_decl(trf_2313)
static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2313(t0,t1,t2,t3);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2276(t0,t1,t2);}

C_noret_decl(trf_2231)
static void C_fcall trf_2231(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2231(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2231(t0,t1,t2,t3);}

C_noret_decl(trf_1857)
static void C_fcall trf_1857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1857(t0,t1,t2,t3);}

C_noret_decl(trf_1851)
static void C_fcall trf_1851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1851(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1851(t0,t1);}

C_noret_decl(trf_1724)
static void C_fcall trf_1724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1724(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1724(t0,t1);}

C_noret_decl(trf_1719)
static void C_fcall trf_1719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1719(t0,t1,t2);}

C_noret_decl(trf_1618)
static void C_fcall trf_1618(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1618(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1618(t0,t1,t2,t3);}

C_noret_decl(trf_1652)
static void C_fcall trf_1652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1652(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1652(t0,t1);}

C_noret_decl(trf_1674)
static void C_fcall trf_1674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1674(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1674(t0,t1);}

C_noret_decl(trf_1307)
static void C_fcall trf_1307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1307(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2rv)
static void C_fcall tr2rv(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2rv(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n+1);
t2=C_restore_rest_vector(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4rv)
static void C_fcall tr4rv(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4rv(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n+1);
t4=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr9rv)
static void C_fcall tr9rv(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9rv(C_proc9 k){
int n;
C_word *a,t9;
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
n=C_rest_count(0);
a=C_alloc(n+1);
t9=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_posix_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_posix_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("posix_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2910)){
C_save(t1);
C_rereclaim2(2910*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,363);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000/this function is not available on this platform");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[4]=C_h_intern(&lf[4],13,"string-append");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\003 - ");
lf[8]=C_h_intern(&lf[8],17,"\003syspeek-c-string");
lf[9]=C_h_intern(&lf[9],16,"\003sysupdate-errno");
lf[10]=C_h_intern(&lf[10],15,"\003sysposix-error");
lf[11]=C_h_intern(&lf[11],8,"pipe/buf");
lf[12]=C_h_intern(&lf[12],11,"open/rdonly");
lf[13]=C_h_intern(&lf[13],11,"open/wronly");
lf[14]=C_h_intern(&lf[14],9,"open/rdwr");
lf[15]=C_h_intern(&lf[15],9,"open/read");
lf[16]=C_h_intern(&lf[16],10,"open/write");
lf[17]=C_h_intern(&lf[17],10,"open/creat");
lf[18]=C_h_intern(&lf[18],11,"open/append");
lf[19]=C_h_intern(&lf[19],9,"open/excl");
lf[20]=C_h_intern(&lf[20],10,"open/trunc");
lf[21]=C_h_intern(&lf[21],11,"open/binary");
lf[22]=C_h_intern(&lf[22],9,"open/text");
lf[23]=C_h_intern(&lf[23],14,"open/noinherit");
lf[24]=C_h_intern(&lf[24],10,"perm/irusr");
lf[25]=C_h_intern(&lf[25],10,"perm/iwusr");
lf[26]=C_h_intern(&lf[26],10,"perm/ixusr");
lf[27]=C_h_intern(&lf[27],10,"perm/irgrp");
lf[28]=C_h_intern(&lf[28],10,"perm/iwgrp");
lf[29]=C_h_intern(&lf[29],10,"perm/ixgrp");
lf[30]=C_h_intern(&lf[30],10,"perm/iroth");
lf[31]=C_h_intern(&lf[31],10,"perm/iwoth");
lf[32]=C_h_intern(&lf[32],10,"perm/ixoth");
lf[33]=C_h_intern(&lf[33],10,"perm/irwxu");
lf[34]=C_h_intern(&lf[34],10,"perm/irwxg");
lf[35]=C_h_intern(&lf[35],10,"perm/irwxo");
lf[36]=C_h_intern(&lf[36],9,"file-open");
lf[37]=C_h_intern(&lf[37],11,"\000file-error");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[39]=C_h_intern(&lf[39],17,"\003sysmake-c-string");
lf[40]=C_h_intern(&lf[40],20,"\003sysexpand-home-path");
lf[41]=C_h_intern(&lf[41],10,"file-close");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\021cannot close file");
lf[43]=C_h_intern(&lf[43],11,"make-string");
lf[44]=C_h_intern(&lf[44],9,"file-read");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot read from file");
lf[46]=C_h_intern(&lf[46],11,"\000type-error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[48]=C_h_intern(&lf[48],10,"file-write");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot write to file");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000(bad argument type - not a string or blob");
lf[51]=C_h_intern(&lf[51],13,"string-length");
lf[52]=C_h_intern(&lf[52],12,"file-mkstemp");
lf[53]=C_h_intern(&lf[53],13,"\003syssubstring");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot create temporary file");
lf[55]=C_h_intern(&lf[55],8,"seek/set");
lf[56]=C_h_intern(&lf[56],8,"seek/end");
lf[57]=C_h_intern(&lf[57],8,"seek/cur");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot access file");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000*bad argument type - not a fixnum or string");
lf[61]=C_h_intern(&lf[61],9,"file-stat");
lf[62]=C_h_intern(&lf[62],9,"file-size");
lf[63]=C_h_intern(&lf[63],22,"file-modification-time");
lf[64]=C_h_intern(&lf[64],16,"file-access-time");
lf[65]=C_h_intern(&lf[65],16,"file-change-time");
lf[66]=C_h_intern(&lf[66],10,"file-owner");
lf[67]=C_h_intern(&lf[67],16,"file-permissions");
lf[68]=C_h_intern(&lf[68],13,"regular-file\077");
lf[69]=C_h_intern(&lf[69],13,"\003sysfile-info");
lf[70]=C_h_intern(&lf[70],14,"symbolic-link\077");
lf[71]=C_h_intern(&lf[71],13,"file-position");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000%cannot retrieve file position of port");
lf[73]=C_h_intern(&lf[73],6,"stream");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[75]=C_h_intern(&lf[75],5,"port\077");
lf[76]=C_h_intern(&lf[76],18,"set-file-position!");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot set file position");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid file");
lf[79]=C_h_intern(&lf[79],13,"\000bounds-error");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid negative port position");
lf[81]=C_h_intern(&lf[81],16,"create-directory");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create directory");
lf[83]=C_h_intern(&lf[83],16,"change-directory");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot change current directory");
lf[85]=C_h_intern(&lf[85],16,"delete-directory");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot delete directory");
lf[87]=C_h_intern(&lf[87],6,"string");
lf[88]=C_h_intern(&lf[88],9,"directory");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025cannot open directory");
lf[90]=C_h_intern(&lf[90],16,"\003sysmake-pointer");
lf[91]=C_h_intern(&lf[91],17,"current-directory");
lf[92]=C_h_intern(&lf[92],10,"directory\077");
lf[93]=C_h_intern(&lf[93],27,"\003sysplatform-fixup-pathname");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current directory");
lf[95]=C_h_intern(&lf[95],5,"\000text");
lf[96]=C_h_intern(&lf[96],9,"\003syserror");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000#illegal input/output mode specifier");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open pipe");
lf[99]=C_h_intern(&lf[99],13,"\003sysmake-port");
lf[100]=C_h_intern(&lf[100],21,"\003sysstream-port-class");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\006(pipe)");
lf[102]=C_h_intern(&lf[102],15,"open-input-pipe");
lf[103]=C_h_intern(&lf[103],7,"\000binary");
lf[104]=C_h_intern(&lf[104],16,"open-output-pipe");
lf[105]=C_h_intern(&lf[105],16,"close-input-pipe");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\030error while closing pipe");
lf[107]=C_h_intern(&lf[107],14,"\003syscheck-port");
lf[108]=C_h_intern(&lf[108],17,"close-output-pipe");
lf[109]=C_h_intern(&lf[109],20,"call-with-input-pipe");
lf[110]=C_h_intern(&lf[110],21,"call-with-output-pipe");
lf[111]=C_h_intern(&lf[111],20,"with-input-from-pipe");
lf[112]=C_h_intern(&lf[112],18,"\003sysstandard-input");
lf[113]=C_h_intern(&lf[113],19,"with-output-to-pipe");
lf[114]=C_h_intern(&lf[114],19,"\003sysstandard-output");
lf[115]=C_h_intern(&lf[115],11,"create-pipe");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot create pipe");
lf[117]=C_h_intern(&lf[117],11,"signal/term");
lf[118]=C_h_intern(&lf[118],10,"signal/int");
lf[119]=C_h_intern(&lf[119],10,"signal/fpe");
lf[120]=C_h_intern(&lf[120],10,"signal/ill");
lf[121]=C_h_intern(&lf[121],11,"signal/segv");
lf[122]=C_h_intern(&lf[122],11,"signal/abrt");
lf[123]=C_h_intern(&lf[123],12,"signal/break");
lf[124]=C_h_intern(&lf[124],11,"signal/alrm");
lf[125]=C_h_intern(&lf[125],11,"signal/chld");
lf[126]=C_h_intern(&lf[126],11,"signal/cont");
lf[127]=C_h_intern(&lf[127],10,"signal/hup");
lf[128]=C_h_intern(&lf[128],9,"signal/io");
lf[129]=C_h_intern(&lf[129],11,"signal/kill");
lf[130]=C_h_intern(&lf[130],11,"signal/pipe");
lf[131]=C_h_intern(&lf[131],11,"signal/prof");
lf[132]=C_h_intern(&lf[132],11,"signal/quit");
lf[133]=C_h_intern(&lf[133],11,"signal/stop");
lf[134]=C_h_intern(&lf[134],11,"signal/trap");
lf[135]=C_h_intern(&lf[135],11,"signal/tstp");
lf[136]=C_h_intern(&lf[136],10,"signal/urg");
lf[137]=C_h_intern(&lf[137],11,"signal/usr1");
lf[138]=C_h_intern(&lf[138],11,"signal/usr2");
lf[139]=C_h_intern(&lf[139],13,"signal/vtalrm");
lf[140]=C_h_intern(&lf[140],12,"signal/winch");
lf[141]=C_h_intern(&lf[141],11,"signal/xcpu");
lf[142]=C_h_intern(&lf[142],11,"signal/xfsz");
lf[143]=C_h_intern(&lf[143],12,"signals-list");
lf[144]=C_h_intern(&lf[144],18,"\003sysinterrupt-hook");
lf[145]=C_h_intern(&lf[145],14,"signal-handler");
lf[146]=C_h_intern(&lf[146],19,"set-signal-handler!");
lf[147]=C_h_intern(&lf[147],10,"errno/perm");
lf[148]=C_h_intern(&lf[148],11,"errno/noent");
lf[149]=C_h_intern(&lf[149],10,"errno/srch");
lf[150]=C_h_intern(&lf[150],10,"errno/intr");
lf[151]=C_h_intern(&lf[151],8,"errno/io");
lf[152]=C_h_intern(&lf[152],12,"errno/noexec");
lf[153]=C_h_intern(&lf[153],10,"errno/badf");
lf[154]=C_h_intern(&lf[154],11,"errno/child");
lf[155]=C_h_intern(&lf[155],11,"errno/nomem");
lf[156]=C_h_intern(&lf[156],11,"errno/acces");
lf[157]=C_h_intern(&lf[157],11,"errno/fault");
lf[158]=C_h_intern(&lf[158],10,"errno/busy");
lf[159]=C_h_intern(&lf[159],11,"errno/exist");
lf[160]=C_h_intern(&lf[160],12,"errno/notdir");
lf[161]=C_h_intern(&lf[161],11,"errno/isdir");
lf[162]=C_h_intern(&lf[162],11,"errno/inval");
lf[163]=C_h_intern(&lf[163],11,"errno/mfile");
lf[164]=C_h_intern(&lf[164],11,"errno/nospc");
lf[165]=C_h_intern(&lf[165],11,"errno/spipe");
lf[166]=C_h_intern(&lf[166],10,"errno/pipe");
lf[167]=C_h_intern(&lf[167],11,"errno/again");
lf[168]=C_h_intern(&lf[168],10,"errno/rofs");
lf[169]=C_h_intern(&lf[169],10,"errno/nxio");
lf[170]=C_h_intern(&lf[170],10,"errno/2big");
lf[171]=C_h_intern(&lf[171],10,"errno/xdev");
lf[172]=C_h_intern(&lf[172],11,"errno/nodev");
lf[173]=C_h_intern(&lf[173],11,"errno/nfile");
lf[174]=C_h_intern(&lf[174],11,"errno/notty");
lf[175]=C_h_intern(&lf[175],10,"errno/fbig");
lf[176]=C_h_intern(&lf[176],11,"errno/mlink");
lf[177]=C_h_intern(&lf[177],9,"errno/dom");
lf[178]=C_h_intern(&lf[178],11,"errno/range");
lf[179]=C_h_intern(&lf[179],12,"errno/deadlk");
lf[180]=C_h_intern(&lf[180],17,"errno/nametoolong");
lf[181]=C_h_intern(&lf[181],11,"errno/nolck");
lf[182]=C_h_intern(&lf[182],11,"errno/nosys");
lf[183]=C_h_intern(&lf[183],14,"errno/notempty");
lf[184]=C_h_intern(&lf[184],11,"errno/ilseq");
lf[185]=C_h_intern(&lf[185],16,"change-file-mode");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot change file mode");
lf[187]=C_h_intern(&lf[187],17,"file-read-access\077");
lf[188]=C_h_intern(&lf[188],18,"file-write-access\077");
lf[189]=C_h_intern(&lf[189],20,"file-execute-access\077");
lf[190]=C_h_intern(&lf[190],12,"fileno/stdin");
lf[191]=C_h_intern(&lf[191],13,"fileno/stdout");
lf[192]=C_h_intern(&lf[192],13,"fileno/stderr");
lf[193]=C_h_intern(&lf[193],7,"\000append");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid mode for input file");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid mode argument");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001w");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\020cannot open file");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\010(fdport)");
lf[201]=C_h_intern(&lf[201],16,"open-input-file*");
lf[202]=C_h_intern(&lf[202],17,"open-output-file*");
lf[203]=C_h_intern(&lf[203],12,"port->fileno");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\031port has no attached file");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000%cannot access file-descriptor of port");
lf[206]=C_h_intern(&lf[206],25,"\003syspeek-unsigned-integer");
lf[207]=C_h_intern(&lf[207],16,"duplicate-fileno");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000 cannot duplicate file descriptor");
lf[209]=C_h_intern(&lf[209],6,"setenv");
lf[210]=C_h_intern(&lf[210],8,"unsetenv");
lf[211]=C_h_intern(&lf[211],9,"substring");
lf[212]=C_h_intern(&lf[212],19,"current-environment");
lf[213]=C_h_intern(&lf[213],19,"seconds->local-time");
lf[214]=C_h_intern(&lf[214],18,"\003sysdecode-seconds");
lf[215]=C_h_intern(&lf[215],17,"seconds->utc-time");
lf[216]=C_h_intern(&lf[216],15,"seconds->string");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000 cannot convert seconds to string");
lf[218]=C_h_intern(&lf[218],12,"time->string");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot time vector to string");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[221]=C_h_intern(&lf[221],19,"local-time->seconds");
lf[222]=C_h_intern(&lf[222],15,"\003syscons-flonum");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000%cannot convert time vector to seconds");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\025time vector too short");
lf[225]=C_h_intern(&lf[225],27,"local-timezone-abbreviation");
lf[226]=C_h_intern(&lf[226],5,"_exit");
lf[227]=C_h_intern(&lf[227],19,"set-buffering-mode!");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot set buffering mode");
lf[229]=C_h_intern(&lf[229],5,"\000full");
lf[230]=C_h_intern(&lf[230],5,"\000line");
lf[231]=C_h_intern(&lf[231],5,"\000none");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid buffering-mode");
lf[233]=C_h_intern(&lf[233],6,"regexp");
lf[234]=C_h_intern(&lf[234],21,"make-anchored-pattern");
lf[235]=C_h_intern(&lf[235],12,"string-match");
lf[236]=C_h_intern(&lf[236],12,"glob->regexp");
lf[237]=C_h_intern(&lf[237],13,"make-pathname");
lf[238]=C_h_intern(&lf[238],18,"decompose-pathname");
lf[239]=C_h_intern(&lf[239],4,"glob");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[242]=C_h_intern(&lf[242],13,"spawn/overlay");
lf[243]=C_h_intern(&lf[243],10,"spawn/wait");
lf[244]=C_h_intern(&lf[244],12,"spawn/nowait");
lf[245]=C_h_intern(&lf[245],13,"spawn/nowaito");
lf[246]=C_h_intern(&lf[246],12,"spawn/detach");
lf[247]=C_h_intern(&lf[247],16,"char-whitespace\077");
lf[248]=C_h_intern(&lf[248],10,"string-ref");
lf[250]=C_h_intern(&lf[250],7,"reverse");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[253]=C_h_intern(&lf[253],24,"pathname-strip-directory");
lf[256]=C_h_intern(&lf[256],15,"process-execute");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[258]=C_h_intern(&lf[258],13,"process-spawn");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot spawn process");
lf[260]=C_h_intern(&lf[260],18,"current-process-id");
lf[261]=C_h_intern(&lf[261],17,"\003sysshell-command");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000 cannot retrieve system directory");
lf[263]=C_h_intern(&lf[263],6,"getenv");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\007COMSPEC");
lf[265]=C_h_intern(&lf[265],27,"\003sysshell-command-arguments");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\002/c");
lf[267]=C_h_intern(&lf[267],11,"process-run");
lf[269]=C_h_intern(&lf[269],11,"\003sysprocess");
lf[270]=C_h_intern(&lf[270],14,"\000process-error");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\026cannot execute process");
lf[272]=C_h_intern(&lf[272],17,"\003sysmake-locative");
lf[273]=C_h_intern(&lf[273],8,"location");
lf[274]=C_h_intern(&lf[274],18,"string-intersperse");
lf[275]=C_h_intern(&lf[275],12,"\003sysfor-each");
lf[276]=C_h_intern(&lf[276],7,"process");
lf[277]=C_h_intern(&lf[277],8,"process*");
lf[278]=C_h_intern(&lf[278],16,"\003sysprocess-wait");
lf[279]=C_h_intern(&lf[279],12,"process-wait");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000 waiting for child process failed");
lf[281]=C_h_intern(&lf[281],5,"sleep");
lf[282]=C_h_intern(&lf[282],13,"get-host-name");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot retrieve host-name");
lf[284]=C_h_intern(&lf[284],18,"system-information");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\007windows");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot retrieve system-information");
lf[287]=C_h_intern(&lf[287],17,"current-user-name");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000!cannot retrieve current user-name");
lf[289]=C_h_intern(&lf[289],10,"find-files");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[292]=C_h_intern(&lf[292],19,"\003sysundefined-value");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[294]=C_h_intern(&lf[294],16,"\003sysdynamic-wind");
lf[295]=C_h_intern(&lf[295],13,"pathname-file");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[297]=C_h_intern(&lf[297],17,"change-file-owner");
lf[298]=C_h_intern(&lf[298],5,"error");
lf[299]=C_h_intern(&lf[299],11,"create-fifo");
lf[300]=C_h_intern(&lf[300],14,"create-session");
lf[301]=C_h_intern(&lf[301],20,"create-symbolic-link");
lf[302]=C_h_intern(&lf[302],26,"current-effective-group-id");
lf[303]=C_h_intern(&lf[303],25,"current-effective-user-id");
lf[304]=C_h_intern(&lf[304],27,"current-effective-user-name");
lf[305]=C_h_intern(&lf[305],16,"current-group-id");
lf[306]=C_h_intern(&lf[306],15,"current-user-id");
lf[307]=C_h_intern(&lf[307],18,"map-file-to-memory");
lf[308]=C_h_intern(&lf[308],9,"file-link");
lf[309]=C_h_intern(&lf[309],9,"file-lock");
lf[310]=C_h_intern(&lf[310],18,"file-lock/blocking");
lf[311]=C_h_intern(&lf[311],11,"file-select");
lf[312]=C_h_intern(&lf[312],14,"file-test-lock");
lf[313]=C_h_intern(&lf[313],13,"file-truncate");
lf[314]=C_h_intern(&lf[314],11,"file-unlock");
lf[315]=C_h_intern(&lf[315],10,"get-groups");
lf[316]=C_h_intern(&lf[316],17,"group-information");
lf[317]=C_h_intern(&lf[317],17,"initialize-groups");
lf[318]=C_h_intern(&lf[318],26,"memory-mapped-file-pointer");
lf[319]=C_h_intern(&lf[319],17,"parent-process-id");
lf[320]=C_h_intern(&lf[320],12,"process-fork");
lf[321]=C_h_intern(&lf[321],16,"process-group-id");
lf[322]=C_h_intern(&lf[322],14,"process-signal");
lf[323]=C_h_intern(&lf[323],18,"read-symbolic-link");
lf[324]=C_h_intern(&lf[324],10,"set-alarm!");
lf[325]=C_h_intern(&lf[325],13,"set-group-id!");
lf[326]=C_h_intern(&lf[326],11,"set-groups!");
lf[327]=C_h_intern(&lf[327],21,"set-process-group-id!");
lf[328]=C_h_intern(&lf[328],19,"set-root-directory!");
lf[329]=C_h_intern(&lf[329],16,"set-signal-mask!");
lf[330]=C_h_intern(&lf[330],12,"set-user-id!");
lf[331]=C_h_intern(&lf[331],11,"signal-mask");
lf[332]=C_h_intern(&lf[332],12,"signal-mask!");
lf[333]=C_h_intern(&lf[333],14,"signal-masked\077");
lf[334]=C_h_intern(&lf[334],14,"signal-unmask!");
lf[335]=C_h_intern(&lf[335],13,"terminal-name");
lf[336]=C_h_intern(&lf[336],14,"terminal-port\077");
lf[337]=C_h_intern(&lf[337],13,"terminal-size");
lf[338]=C_h_intern(&lf[338],22,"unmap-file-from-memory");
lf[339]=C_h_intern(&lf[339],16,"user-information");
lf[340]=C_h_intern(&lf[340],17,"utc-time->seconds");
lf[341]=C_h_intern(&lf[341],16,"errno/wouldblock");
lf[342]=C_h_intern(&lf[342],5,"fifo\077");
lf[343]=C_h_intern(&lf[343],19,"memory-mapped-file\077");
lf[344]=C_h_intern(&lf[344],13,"map/anonymous");
lf[345]=C_h_intern(&lf[345],8,"map/file");
lf[346]=C_h_intern(&lf[346],9,"map/fixed");
lf[347]=C_h_intern(&lf[347],11,"map/private");
lf[348]=C_h_intern(&lf[348],10,"map/shared");
lf[349]=C_h_intern(&lf[349],10,"open/fsync");
lf[350]=C_h_intern(&lf[350],11,"open/noctty");
lf[351]=C_h_intern(&lf[351],13,"open/nonblock");
lf[352]=C_h_intern(&lf[352],9,"open/sync");
lf[353]=C_h_intern(&lf[353],10,"perm/isgid");
lf[354]=C_h_intern(&lf[354],10,"perm/isuid");
lf[355]=C_h_intern(&lf[355],10,"perm/isvtx");
lf[356]=C_h_intern(&lf[356],9,"prot/exec");
lf[357]=C_h_intern(&lf[357],9,"prot/none");
lf[358]=C_h_intern(&lf[358],9,"prot/read");
lf[359]=C_h_intern(&lf[359],10,"prot/write");
lf[360]=C_h_intern(&lf[360],11,"make-vector");
lf[361]=C_h_intern(&lf[361],17,"register-feature!");
lf[362]=C_h_intern(&lf[362],5,"posix");
C_register_lf2(lf,363,create_ptable());
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1058,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t4);}

/* k1056 */
static void C_ccall f_1058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1059 in k1056 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1062 in k1059 in k1056 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 931  register-feature! */
t3=*((C_word*)lf[361]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[362]);}

/* k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word ab[119],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1077,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1,lf[5]);
t5=C_mutate((C_word*)lf[11]+1,C_fix((C_word)PIPE_BUF));
t6=C_mutate((C_word*)lf[12]+1,C_fix((C_word)O_RDONLY));
t7=C_mutate((C_word*)lf[13]+1,C_fix((C_word)O_WRONLY));
t8=C_mutate((C_word*)lf[14]+1,C_fix((C_word)O_RDWR));
t9=C_mutate((C_word*)lf[15]+1,C_fix((C_word)O_RDWR));
t10=C_mutate((C_word*)lf[16]+1,C_fix((C_word)O_WRONLY));
t11=C_mutate((C_word*)lf[17]+1,C_fix((C_word)O_CREAT));
t12=C_mutate((C_word*)lf[18]+1,C_fix((C_word)O_APPEND));
t13=C_mutate((C_word*)lf[19]+1,C_fix((C_word)O_EXCL));
t14=C_mutate((C_word*)lf[20]+1,C_fix((C_word)O_TRUNC));
t15=C_mutate((C_word*)lf[21]+1,C_fix((C_word)O_BINARY));
t16=C_mutate((C_word*)lf[22]+1,C_fix((C_word)O_TEXT));
t17=C_mutate((C_word*)lf[23]+1,C_fix((C_word)O_NOINHERIT));
t18=C_mutate((C_word*)lf[24]+1,C_fix((C_word)S_IREAD));
t19=C_mutate((C_word*)lf[25]+1,C_fix((C_word)S_IWRITE));
t20=C_mutate((C_word*)lf[26]+1,C_fix((C_word)S_IEXEC));
t21=C_mutate((C_word*)lf[27]+1,C_fix((C_word)S_IREAD));
t22=C_mutate((C_word*)lf[28]+1,C_fix((C_word)S_IWRITE));
t23=C_mutate((C_word*)lf[29]+1,C_fix((C_word)S_IEXEC));
t24=C_mutate((C_word*)lf[30]+1,C_fix((C_word)S_IREAD));
t25=C_mutate((C_word*)lf[31]+1,C_fix((C_word)S_IWRITE));
t26=C_mutate((C_word*)lf[32]+1,C_fix((C_word)S_IEXEC));
t27=C_mutate((C_word*)lf[33]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t28=C_mutate((C_word*)lf[34]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t29=C_mutate((C_word*)lf[35]+1,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC));
t30=(C_word)C_u_fixnum_or(C_fix((C_word)S_IREAD),C_fix((C_word)S_IREAD));
t31=(C_word)C_a_i_bitwise_ior(&a,2,C_fix((C_word)S_IREAD | S_IWRITE | S_IEXEC),t30);
t32=C_mutate((C_word*)lf[36]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1123,a[2]=t31,tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[41]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1164,tmp=(C_word)a,a+=2,tmp));
t34=*((C_word*)lf[43]+1);
t35=C_mutate((C_word*)lf[44]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1182,a[2]=t34,tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[48]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1227,tmp=(C_word)a,a+=2,tmp));
t37=*((C_word*)lf[51]+1);
t38=C_mutate((C_word*)lf[52]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1269,a[2]=t37,tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[55]+1,C_fix((C_word)SEEK_SET));
t40=C_mutate((C_word*)lf[56]+1,C_fix((C_word)SEEK_END));
t41=C_mutate((C_word*)lf[57]+1,C_fix((C_word)SEEK_CUR));
t42=C_mutate(&lf[58],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1307,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[61]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1345,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[62]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1369,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1375,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1381,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[65]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1387,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1393,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1399,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[68]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1405,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1428,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[71]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1434,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[76]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1474,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1535,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[83]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1562,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[85]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1589,tmp=(C_word)a,a+=2,tmp));
t57=*((C_word*)lf[4]+1);
t58=*((C_word*)lf[43]+1);
t59=*((C_word*)lf[87]+1);
t60=C_mutate((C_word*)lf[88]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1616,a[2]=t58,tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[92]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1773,tmp=(C_word)a,a+=2,tmp));
t62=*((C_word*)lf[43]+1);
t63=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1800,a[2]=t62,tmp=(C_word)a,a+=3,tmp));
t64=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1839,tmp=(C_word)a,a+=2,tmp);
t65=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1851,tmp=(C_word)a,a+=2,tmp);
t66=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1857,tmp=(C_word)a,a+=2,tmp);
t67=C_mutate((C_word*)lf[102]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1875,a[2]=t65,a[3]=t66,a[4]=t64,tmp=(C_word)a,a+=5,tmp));
t68=C_mutate((C_word*)lf[104]+1,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1911,a[2]=t65,a[3]=t66,a[4]=t64,tmp=(C_word)a,a+=5,tmp));
t69=C_mutate((C_word*)lf[105]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1947,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[108]+1,*((C_word*)lf[105]+1));
t71=*((C_word*)lf[102]+1);
t72=*((C_word*)lf[104]+1);
t73=*((C_word*)lf[105]+1);
t74=*((C_word*)lf[108]+1);
t75=C_mutate((C_word*)lf[109]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1966,a[2]=t71,a[3]=t73,tmp=(C_word)a,a+=4,tmp));
t76=C_mutate((C_word*)lf[110]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1990,a[2]=t72,a[3]=t74,tmp=(C_word)a,a+=4,tmp));
t77=C_mutate((C_word*)lf[111]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=t71,a[3]=t73,tmp=(C_word)a,a+=4,tmp));
t78=C_mutate((C_word*)lf[113]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2034,a[2]=t72,a[3]=t74,tmp=(C_word)a,a+=4,tmp));
t79=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2054,tmp=(C_word)a,a+=2,tmp));
t80=C_mutate((C_word*)lf[117]+1,C_fix((C_word)SIGTERM));
t81=C_mutate((C_word*)lf[118]+1,C_fix((C_word)SIGINT));
t82=C_mutate((C_word*)lf[119]+1,C_fix((C_word)SIGFPE));
t83=C_mutate((C_word*)lf[120]+1,C_fix((C_word)SIGILL));
t84=C_mutate((C_word*)lf[121]+1,C_fix((C_word)SIGSEGV));
t85=C_mutate((C_word*)lf[122]+1,C_fix((C_word)SIGABRT));
t86=C_mutate((C_word*)lf[123]+1,C_fix((C_word)SIGBREAK));
t87=C_set_block_item(lf[124],0,C_fix(0));
t88=C_set_block_item(lf[125],0,C_fix(0));
t89=C_set_block_item(lf[126],0,C_fix(0));
t90=C_set_block_item(lf[127],0,C_fix(0));
t91=C_set_block_item(lf[128],0,C_fix(0));
t92=C_set_block_item(lf[129],0,C_fix(0));
t93=C_set_block_item(lf[130],0,C_fix(0));
t94=C_set_block_item(lf[131],0,C_fix(0));
t95=C_set_block_item(lf[132],0,C_fix(0));
t96=C_set_block_item(lf[133],0,C_fix(0));
t97=C_set_block_item(lf[134],0,C_fix(0));
t98=C_set_block_item(lf[135],0,C_fix(0));
t99=C_set_block_item(lf[136],0,C_fix(0));
t100=C_set_block_item(lf[137],0,C_fix(0));
t101=C_set_block_item(lf[138],0,C_fix(0));
t102=C_set_block_item(lf[139],0,C_fix(0));
t103=C_set_block_item(lf[140],0,C_fix(0));
t104=C_set_block_item(lf[141],0,C_fix(0));
t105=C_set_block_item(lf[142],0,C_fix(0));
t106=(C_word)C_a_i_list(&a,7,*((C_word*)lf[117]+1),*((C_word*)lf[118]+1),*((C_word*)lf[119]+1),*((C_word*)lf[120]+1),*((C_word*)lf[121]+1),*((C_word*)lf[122]+1),*((C_word*)lf[123]+1));
t107=C_mutate((C_word*)lf[143]+1,t106);
t108=*((C_word*)lf[144]+1);
t109=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t108,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1349 make-vector */
t110=*((C_word*)lf[360]+1);
((C_proc4)(void*)(*((C_word*)t110+1)))(4,t110,t109,C_fix(256),C_SCHEME_FALSE);}

/* k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word t150;
C_word t151;
C_word t152;
C_word t153;
C_word t154;
C_word t155;
C_word t156;
C_word t157;
C_word t158;
C_word t159;
C_word t160;
C_word t161;
C_word t162;
C_word t163;
C_word t164;
C_word t165;
C_word t166;
C_word t167;
C_word t168;
C_word t169;
C_word t170;
C_word t171;
C_word t172;
C_word t173;
C_word t174;
C_word t175;
C_word t176;
C_word t177;
C_word t178;
C_word t179;
C_word ab[224],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=C_mutate((C_word*)lf[145]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2123,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[146]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[144]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[147]+1,C_fix((C_word)EPERM));
t6=C_mutate((C_word*)lf[148]+1,C_fix((C_word)ENOENT));
t7=C_mutate((C_word*)lf[149]+1,C_fix((C_word)ESRCH));
t8=C_mutate((C_word*)lf[150]+1,C_fix((C_word)EINTR));
t9=C_mutate((C_word*)lf[151]+1,C_fix((C_word)EIO));
t10=C_mutate((C_word*)lf[152]+1,C_fix((C_word)ENOEXEC));
t11=C_mutate((C_word*)lf[153]+1,C_fix((C_word)EBADF));
t12=C_mutate((C_word*)lf[154]+1,C_fix((C_word)ECHILD));
t13=C_mutate((C_word*)lf[155]+1,C_fix((C_word)ENOMEM));
t14=C_mutate((C_word*)lf[156]+1,C_fix((C_word)EACCES));
t15=C_mutate((C_word*)lf[157]+1,C_fix((C_word)EFAULT));
t16=C_mutate((C_word*)lf[158]+1,C_fix((C_word)EBUSY));
t17=C_mutate((C_word*)lf[159]+1,C_fix((C_word)EEXIST));
t18=C_mutate((C_word*)lf[160]+1,C_fix((C_word)ENOTDIR));
t19=C_mutate((C_word*)lf[161]+1,C_fix((C_word)EISDIR));
t20=C_mutate((C_word*)lf[162]+1,C_fix((C_word)EINVAL));
t21=C_mutate((C_word*)lf[163]+1,C_fix((C_word)EMFILE));
t22=C_mutate((C_word*)lf[164]+1,C_fix((C_word)ENOSPC));
t23=C_mutate((C_word*)lf[165]+1,C_fix((C_word)ESPIPE));
t24=C_mutate((C_word*)lf[166]+1,C_fix((C_word)EPIPE));
t25=C_mutate((C_word*)lf[167]+1,C_fix((C_word)EAGAIN));
t26=C_mutate((C_word*)lf[168]+1,C_fix((C_word)EROFS));
t27=C_mutate((C_word*)lf[169]+1,C_fix((C_word)ENXIO));
t28=C_mutate((C_word*)lf[170]+1,C_fix((C_word)E2BIG));
t29=C_mutate((C_word*)lf[171]+1,C_fix((C_word)EXDEV));
t30=C_mutate((C_word*)lf[172]+1,C_fix((C_word)ENODEV));
t31=C_mutate((C_word*)lf[173]+1,C_fix((C_word)ENFILE));
t32=C_mutate((C_word*)lf[174]+1,C_fix((C_word)ENOTTY));
t33=C_mutate((C_word*)lf[175]+1,C_fix((C_word)EFBIG));
t34=C_mutate((C_word*)lf[176]+1,C_fix((C_word)EMLINK));
t35=C_mutate((C_word*)lf[177]+1,C_fix((C_word)EDOM));
t36=C_mutate((C_word*)lf[178]+1,C_fix((C_word)ERANGE));
t37=C_mutate((C_word*)lf[179]+1,C_fix((C_word)EDEADLK));
t38=C_mutate((C_word*)lf[180]+1,C_fix((C_word)ENAMETOOLONG));
t39=C_mutate((C_word*)lf[181]+1,C_fix((C_word)ENOLCK));
t40=C_mutate((C_word*)lf[182]+1,C_fix((C_word)ENOSYS));
t41=C_mutate((C_word*)lf[183]+1,C_fix((C_word)ENOTEMPTY));
t42=C_mutate((C_word*)lf[184]+1,C_fix((C_word)EILSEQ));
t43=C_mutate((C_word*)lf[185]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2201,tmp=(C_word)a,a+=2,tmp));
t44=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2231,tmp=(C_word)a,a+=2,tmp);
t45=C_mutate((C_word*)lf[187]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2255,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[188]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2261,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[189]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2267,a[2]=t44,tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[190]+1,C_fix((C_word)0));
t49=C_mutate((C_word*)lf[191]+1,C_fix((C_word)1));
t50=C_mutate((C_word*)lf[192]+1,C_fix((C_word)2));
t51=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2276,tmp=(C_word)a,a+=2,tmp);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2313,tmp=(C_word)a,a+=2,tmp);
t53=C_mutate((C_word*)lf[201]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2331,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t54=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2345,a[2]=t51,a[3]=t52,tmp=(C_word)a,a+=4,tmp));
t55=C_mutate((C_word*)lf[203]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2359,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[207]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2394,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[209]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2424,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[210]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2441,tmp=(C_word)a,a+=2,tmp));
t59=*((C_word*)lf[211]+1);
t60=C_mutate((C_word*)lf[212]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2456,a[2]=t59,tmp=(C_word)a,a+=3,tmp));
t61=C_mutate((C_word*)lf[213]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2521,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[215]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2530,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[216]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2544,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[218]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2572,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[221]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2611,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[225]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2639,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[226]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2647,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[227]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2663,tmp=(C_word)a,a+=2,tmp));
t69=*((C_word*)lf[233]+1);
t70=*((C_word*)lf[234]+1);
t71=*((C_word*)lf[235]+1);
t72=*((C_word*)lf[236]+1);
t73=*((C_word*)lf[88]+1);
t74=*((C_word*)lf[237]+1);
t75=*((C_word*)lf[238]+1);
t76=C_mutate((C_word*)lf[239]+1,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2722,a[2]=t72,a[3]=t70,a[4]=t69,a[5]=t73,a[6]=t71,a[7]=t74,a[8]=t75,tmp=(C_word)a,a+=9,tmp));
t77=C_mutate((C_word*)lf[242]+1,C_fix((C_word)P_OVERLAY));
t78=C_mutate((C_word*)lf[243]+1,C_fix((C_word)P_WAIT));
t79=C_mutate((C_word*)lf[244]+1,C_fix((C_word)P_NOWAIT));
t80=C_mutate((C_word*)lf[245]+1,C_fix((C_word)P_NOWAITO));
t81=C_mutate((C_word*)lf[246]+1,C_fix((C_word)P_DETACH));
t82=*((C_word*)lf[247]+1);
t83=*((C_word*)lf[51]+1);
t84=*((C_word*)lf[248]+1);
t85=*((C_word*)lf[4]+1);
t86=C_mutate(&lf[249],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2837,a[2]=t85,a[3]=t83,a[4]=t84,a[5]=t82,tmp=(C_word)a,a+=6,tmp));
t87=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2916,tmp=(C_word)a,a+=2,tmp);
t88=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2922,tmp=(C_word)a,a+=2,tmp);
t89=*((C_word*)lf[253]+1);
t90=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2928,tmp=(C_word)a,a+=2,tmp);
t91=C_mutate(&lf[254],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2978,a[2]=t89,a[3]=t87,a[4]=t88,a[5]=t90,tmp=(C_word)a,a+=6,tmp));
t92=C_mutate(&lf[255],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3011,tmp=(C_word)a,a+=2,tmp));
t93=C_mutate((C_word*)lf[256]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3026,tmp=(C_word)a,a+=2,tmp));
t94=C_mutate((C_word*)lf[258]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3110,tmp=(C_word)a,a+=2,tmp));
t95=C_mutate((C_word*)lf[260]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3194,tmp=(C_word)a,a+=2,tmp));
t96=C_mutate((C_word*)lf[261]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3197,tmp=(C_word)a,a+=2,tmp));
t97=C_mutate((C_word*)lf[265]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3218,tmp=(C_word)a,a+=2,tmp));
t98=*((C_word*)lf[258]+1);
t99=*((C_word*)lf[263]+1);
t100=C_mutate((C_word*)lf[267]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3224,a[2]=t98,tmp=(C_word)a,a+=3,tmp));
t101=C_mutate(&lf[268],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3253,tmp=(C_word)a,a+=2,tmp));
t102=C_mutate((C_word*)lf[269]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3307,tmp=(C_word)a,a+=2,tmp));
t103=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3403,tmp=(C_word)a,a+=2,tmp);
t104=C_mutate((C_word*)lf[276]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3465,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t105=C_mutate((C_word*)lf[277]+1,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3542,a[2]=t103,tmp=(C_word)a,a+=3,tmp));
t106=C_mutate((C_word*)lf[278]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3619,tmp=(C_word)a,a+=2,tmp));
t107=C_mutate((C_word*)lf[279]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3631,tmp=(C_word)a,a+=2,tmp));
t108=C_mutate((C_word*)lf[281]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3688,tmp=(C_word)a,a+=2,tmp));
t109=C_mutate((C_word*)lf[282]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3691,tmp=(C_word)a,a+=2,tmp));
t110=C_mutate((C_word*)lf[284]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3703,tmp=(C_word)a,a+=2,tmp));
t111=C_mutate((C_word*)lf[287]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3734,tmp=(C_word)a,a+=2,tmp));
t112=*((C_word*)lf[239]+1);
t113=*((C_word*)lf[235]+1);
t114=*((C_word*)lf[237]+1);
t115=*((C_word*)lf[92]+1);
t116=C_mutate((C_word*)lf[289]+1,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3749,a[2]=t115,a[3]=t114,a[4]=t112,a[5]=t113,tmp=(C_word)a,a+=6,tmp));
t117=C_mutate((C_word*)lf[297]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3972,tmp=(C_word)a,a+=2,tmp));
t118=C_mutate((C_word*)lf[299]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3978,tmp=(C_word)a,a+=2,tmp));
t119=C_mutate((C_word*)lf[300]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3984,tmp=(C_word)a,a+=2,tmp));
t120=C_mutate((C_word*)lf[301]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3990,tmp=(C_word)a,a+=2,tmp));
t121=C_mutate((C_word*)lf[302]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3996,tmp=(C_word)a,a+=2,tmp));
t122=C_mutate((C_word*)lf[303]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4002,tmp=(C_word)a,a+=2,tmp));
t123=C_mutate((C_word*)lf[304]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4008,tmp=(C_word)a,a+=2,tmp));
t124=C_mutate((C_word*)lf[305]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4014,tmp=(C_word)a,a+=2,tmp));
t125=C_mutate((C_word*)lf[306]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4020,tmp=(C_word)a,a+=2,tmp));
t126=C_mutate((C_word*)lf[307]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4026,tmp=(C_word)a,a+=2,tmp));
t127=C_mutate((C_word*)lf[308]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4032,tmp=(C_word)a,a+=2,tmp));
t128=C_mutate((C_word*)lf[309]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4038,tmp=(C_word)a,a+=2,tmp));
t129=C_mutate((C_word*)lf[310]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4044,tmp=(C_word)a,a+=2,tmp));
t130=C_mutate((C_word*)lf[311]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4050,tmp=(C_word)a,a+=2,tmp));
t131=C_mutate((C_word*)lf[312]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4056,tmp=(C_word)a,a+=2,tmp));
t132=C_mutate((C_word*)lf[313]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4062,tmp=(C_word)a,a+=2,tmp));
t133=C_mutate((C_word*)lf[314]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4068,tmp=(C_word)a,a+=2,tmp));
t134=C_mutate((C_word*)lf[315]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4074,tmp=(C_word)a,a+=2,tmp));
t135=C_mutate((C_word*)lf[316]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4080,tmp=(C_word)a,a+=2,tmp));
t136=C_mutate((C_word*)lf[317]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4086,tmp=(C_word)a,a+=2,tmp));
t137=C_mutate((C_word*)lf[318]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4092,tmp=(C_word)a,a+=2,tmp));
t138=C_mutate((C_word*)lf[319]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4098,tmp=(C_word)a,a+=2,tmp));
t139=C_mutate((C_word*)lf[320]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4104,tmp=(C_word)a,a+=2,tmp));
t140=C_mutate((C_word*)lf[321]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4110,tmp=(C_word)a,a+=2,tmp));
t141=C_mutate((C_word*)lf[322]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4116,tmp=(C_word)a,a+=2,tmp));
t142=C_mutate((C_word*)lf[323]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4122,tmp=(C_word)a,a+=2,tmp));
t143=C_mutate((C_word*)lf[324]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4128,tmp=(C_word)a,a+=2,tmp));
t144=C_mutate((C_word*)lf[325]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4134,tmp=(C_word)a,a+=2,tmp));
t145=C_mutate((C_word*)lf[326]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4140,tmp=(C_word)a,a+=2,tmp));
t146=C_mutate((C_word*)lf[327]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4146,tmp=(C_word)a,a+=2,tmp));
t147=C_mutate((C_word*)lf[328]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4152,tmp=(C_word)a,a+=2,tmp));
t148=C_mutate((C_word*)lf[329]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4158,tmp=(C_word)a,a+=2,tmp));
t149=C_mutate((C_word*)lf[330]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4164,tmp=(C_word)a,a+=2,tmp));
t150=C_mutate((C_word*)lf[331]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4170,tmp=(C_word)a,a+=2,tmp));
t151=C_mutate((C_word*)lf[332]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4176,tmp=(C_word)a,a+=2,tmp));
t152=C_mutate((C_word*)lf[333]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4182,tmp=(C_word)a,a+=2,tmp));
t153=C_mutate((C_word*)lf[334]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4188,tmp=(C_word)a,a+=2,tmp));
t154=C_mutate((C_word*)lf[335]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4194,tmp=(C_word)a,a+=2,tmp));
t155=C_mutate((C_word*)lf[336]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4200,tmp=(C_word)a,a+=2,tmp));
t156=C_mutate((C_word*)lf[337]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4206,tmp=(C_word)a,a+=2,tmp));
t157=C_mutate((C_word*)lf[338]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4212,tmp=(C_word)a,a+=2,tmp));
t158=C_mutate((C_word*)lf[339]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4218,tmp=(C_word)a,a+=2,tmp));
t159=C_mutate((C_word*)lf[340]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4224,tmp=(C_word)a,a+=2,tmp));
t160=C_set_block_item(lf[341],0,C_fix(0));
t161=C_mutate((C_word*)lf[342]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4231,tmp=(C_word)a,a+=2,tmp));
t162=C_mutate((C_word*)lf[343]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4234,tmp=(C_word)a,a+=2,tmp));
t163=C_set_block_item(lf[344],0,C_fix(0));
t164=C_set_block_item(lf[345],0,C_fix(0));
t165=C_set_block_item(lf[346],0,C_fix(0));
t166=C_set_block_item(lf[347],0,C_fix(0));
t167=C_set_block_item(lf[348],0,C_fix(0));
t168=C_set_block_item(lf[349],0,C_fix(0));
t169=C_set_block_item(lf[350],0,C_fix(0));
t170=C_set_block_item(lf[351],0,C_fix(0));
t171=C_set_block_item(lf[352],0,C_fix(0));
t172=C_set_block_item(lf[353],0,C_fix(0));
t173=C_set_block_item(lf[354],0,C_fix(0));
t174=C_set_block_item(lf[355],0,C_fix(0));
t175=C_set_block_item(lf[356],0,C_fix(0));
t176=C_set_block_item(lf[357],0,C_fix(0));
t177=C_set_block_item(lf[358],0,C_fix(0));
t178=C_set_block_item(lf[359],0,C_fix(0));
t179=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t179+1)))(2,t179,C_SCHEME_UNDEFINED);}

/* memory-mapped-file? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4234,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* fifo? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4231(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4231,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* utc-time->seconds in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
/* posixwin.scm: 1982 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[340],lf[0]);}

/* user-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
/* posixwin.scm: 1981 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[339],lf[0]);}

/* unmap-file-from-memory in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
/* posixwin.scm: 1980 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[338],lf[0]);}

/* terminal-size in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
/* posixwin.scm: 1979 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[337],lf[0]);}

/* terminal-port? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
/* posixwin.scm: 1978 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[336],lf[0]);}

/* terminal-name in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4194,2,t0,t1);}
/* posixwin.scm: 1977 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[335],lf[0]);}

/* signal-unmask! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
/* posixwin.scm: 1976 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[334],lf[0]);}

/* signal-masked? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
/* posixwin.scm: 1975 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[333],lf[0]);}

/* signal-mask! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
/* posixwin.scm: 1974 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[332],lf[0]);}

/* signal-mask in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
/* posixwin.scm: 1973 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[331],lf[0]);}

/* set-user-id! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
/* posixwin.scm: 1972 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[330],lf[0]);}

/* set-signal-mask! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4158(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4158,2,t0,t1);}
/* posixwin.scm: 1971 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[329],lf[0]);}

/* set-root-directory! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
/* posixwin.scm: 1970 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[328],lf[0]);}

/* set-process-group-id! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4146(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4146,2,t0,t1);}
/* posixwin.scm: 1969 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[327],lf[0]);}

/* set-groups! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4140,2,t0,t1);}
/* posixwin.scm: 1968 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[326],lf[0]);}

/* set-group-id! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
/* posixwin.scm: 1967 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[325],lf[0]);}

/* set-alarm! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4128,2,t0,t1);}
/* posixwin.scm: 1966 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[324],lf[0]);}

/* read-symbolic-link in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
/* posixwin.scm: 1965 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[323],lf[0]);}

/* process-signal in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
/* posixwin.scm: 1964 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[322],lf[0]);}

/* process-group-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
/* posixwin.scm: 1963 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[321],lf[0]);}

/* process-fork in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
/* posixwin.scm: 1962 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[320],lf[0]);}

/* parent-process-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4098,2,t0,t1);}
/* posixwin.scm: 1961 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[319],lf[0]);}

/* memory-mapped-file-pointer in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4092(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4092,2,t0,t1);}
/* posixwin.scm: 1960 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[318],lf[0]);}

/* initialize-groups in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
/* posixwin.scm: 1959 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[317],lf[0]);}

/* group-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
/* posixwin.scm: 1958 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[316],lf[0]);}

/* get-groups in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
/* posixwin.scm: 1957 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[315],lf[0]);}

/* file-unlock in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
/* posixwin.scm: 1956 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[314],lf[0]);}

/* file-truncate in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4062(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4062,2,t0,t1);}
/* posixwin.scm: 1955 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[313],lf[0]);}

/* file-test-lock in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4056(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4056,2,t0,t1);}
/* posixwin.scm: 1954 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[312],lf[0]);}

/* file-select in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4050,2,t0,t1);}
/* posixwin.scm: 1953 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[311],lf[0]);}

/* file-lock/blocking in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
/* posixwin.scm: 1952 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[310],lf[0]);}

/* file-lock in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4038(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4038,2,t0,t1);}
/* posixwin.scm: 1951 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[309],lf[0]);}

/* file-link in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4032,2,t0,t1);}
/* posixwin.scm: 1950 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[308],lf[0]);}

/* map-file-to-memory in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
/* posixwin.scm: 1949 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[307],lf[0]);}

/* current-user-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4020(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4020,2,t0,t1);}
/* posixwin.scm: 1948 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[306],lf[0]);}

/* current-group-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4014(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4014,2,t0,t1);}
/* posixwin.scm: 1947 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[305],lf[0]);}

/* current-effective-user-name in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4008(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4008,2,t0,t1);}
/* posixwin.scm: 1946 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[304],lf[0]);}

/* current-effective-user-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4002,2,t0,t1);}
/* posixwin.scm: 1945 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[303],lf[0]);}

/* current-effective-group-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
/* posixwin.scm: 1944 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[302],lf[0]);}

/* create-symbolic-link in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
/* posixwin.scm: 1943 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[301],lf[0]);}

/* create-session in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
/* posixwin.scm: 1942 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[300],lf[0]);}

/* create-fifo in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3978(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3978,2,t0,t1);}
/* posixwin.scm: 1941 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[299],lf[0]);}

/* change-file-owner in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3972,2,t0,t1);}
/* posixwin.scm: 1940 error */
t2=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[297],lf[0]);}

/* find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_3749r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3749r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3749r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3751,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3896,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3901,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3906,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-action727761 */
t9=t8;
f_3906(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-id728759 */
t11=t7;
f_3901(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-limit729756 */
t13=t6;
f_3896(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body725731 */
t15=t5;
f_3751(t15,t1,t9,t11,t13);}}}}

/* def-action727 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3906,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3912,tmp=(C_word)a,a+=2,tmp);
/* def-id728759 */
t3=((C_word*)t0)[2];
f_3901(t3,t1,t2);}

/* a3911 in def-action727 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3912,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_cons(&a,2,t2,t3));}

/* def-id728 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3901(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3901,NULL,3,t0,t1,t2);}
/* def-limit729756 */
t3=((C_word*)t0)[2];
f_3896(t3,t1,t2,C_SCHEME_END_OF_LIST);}

/* def-limit729 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3896(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3896,NULL,4,t0,t1,t2,t3);}
/* body725731 */
t4=((C_word*)t0)[2];
f_3751(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3751(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3751,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(((C_word*)t0)[7],lf[289]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3758,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=((C_word*)t0)[5],a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
t9=t4;
if(C_truep(t9)){
t10=(C_word)C_fixnump(t4);
t11=t8;
f_3758(t11,(C_truep(t10)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp):t4));}
else{
t10=t8;
f_3758(t10,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3883,tmp=(C_word)a,a+=2,tmp));}}

/* f_3883 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3883(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3883,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* f_3891 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3891,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]));}

/* k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3758,NULL,2,t0,t1);}
t2=(C_word)C_i_stringp(((C_word*)t0)[11]);
t3=(C_truep(t2)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3875,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp):((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3871,a[2]=t4,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1918 make-pathname */
t6=((C_word*)t0)[7];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],lf[296]);}

/* k3869 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1918 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3768,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3770,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_3770(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3770(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3770,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(C_word)C_slot(t2,C_fix(0));
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t3,a[10]=t5,a[11]=t1,a[12]=((C_word*)t0)[9],tmp=(C_word)a,a+=13,tmp);
/* posixwin.scm: 1924 directory? */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1925 pathname-file */
t3=*((C_word*)lf[295]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1931 pproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}}

/* k3855 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1931 action */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1932 loop */
t2=((C_word*)((C_word*)t0)[7])[1];
f_3770(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k3862 in k3855 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1931 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3851,2,t0,t1);}
if(C_truep((C_truep((C_word)C_i_equalp(t1,lf[290]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t1,lf[291]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
/* posixwin.scm: 1925 loop */
t2=((C_word*)((C_word*)t0)[10])[1];
f_3770(t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3804,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1926 lproc */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3814,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3816,a[2]=t4,a[3]=((C_word*)t0)[9],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3838,a[2]=t6,a[3]=((C_word*)t0)[9],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1928 ##sys#dynamic-wind */
t11=*((C_word*)lf[294]+1);
((C_proc5)(void*)(*((C_word*)t11+1)))(5,t11,t7,t8,t9,t10);}
else{
/* posixwin.scm: 1930 loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_3770(t2,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}}

/* a3837 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[292]+1));}

/* a3823 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1929 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[293]);}

/* k3834 in a3823 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 glob */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3830 in a3823 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1929 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3770(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3815 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3816,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,*((C_word*)lf[292]+1));}

/* k3812 in k3802 in k3849 in k3787 in loop in k3766 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1927 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3770(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* f_3875 in k3756 in body725 in find-files in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3875,3,t0,t1,t2);}
/* posixwin.scm: 1916 string-match */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* current-user-name in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
if(C_truep((C_word)C_get_user_name())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_username),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3744,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1892 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3742 in current-user-name in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1893 ##sys#error */
t2=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[287],lf[288]);}

/* system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3703,2,t0,t1);}
if(C_truep((C_word)C_sysinfo())){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3714,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1883 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3727 in system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1884 ##sys#error */
t2=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[284],lf[286]);}

/* k3712 in system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osrel),C_fix(0));}

/* k3716 in k3712 in system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3722,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_osver),C_fix(0));}

/* k3720 in k3716 in k3712 in system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3726,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_processor),C_fix(0));}

/* k3724 in k3720 in k3716 in k3712 in system-information in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,5,lf[285],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* get-host-name in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3691,2,t0,t1);}
if(C_truep((C_word)C_get_hostname())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,C_mpointer(&a,(void*)C_hostname),C_fix(0));}
else{
/* posixwin.scm: 1873 ##sys#error */
t2=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[282],lf[283]);}}

/* sleep in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3688,3,t0,t1,t2);}
t3=(C_word)C_sleep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}

/* process-wait in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_3631r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3631r(t0,t1,t2,t3);}}

static void C_ccall f_3631r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(7);
t4=(C_word)C_i_nullp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_u_i_car(t3));
t6=(C_word)C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:(C_word)C_slot(t3,C_fix(1)));
t8=(C_word)C_i_check_exact_2(t2,lf[279]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3649,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1852 ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t9,t10);}

/* a3654 in process-wait in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3655(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3655,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1855 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* posixwin.scm: 1857 values */
C_values(5,0,t1,t2,t3,t4);}}

/* k3663 in a3654 in process-wait in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1856 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[270],lf[279],lf[280],((C_word*)t0)[2]);}

/* a3648 in process-wait in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3649,2,t0,t1);}
/* posixwin.scm: 1852 ##sys#process-wait */
t2=*((C_word*)lf[278]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#process-wait in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3619,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_process_wait(t2,t3))){
/* posixwin.scm: 1845 values */
C_values(5,0,t1,t2,C_SCHEME_TRUE,C_fix((C_word)C_exstatus));}
else{
/* posixwin.scm: 1846 values */
C_values(5,0,t1,C_fix(-1),C_SCHEME_FALSE,C_SCHEME_FALSE);}}

/* process* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3542(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3542r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3542r(t0,t1,t2,t3);}}

static void C_ccall f_3542r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3544,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3549,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3554,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3559,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args676689 */
t8=t7;
f_3559(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env677687 */
t10=t6;
f_3554(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf678684 */
t12=t5;
f_3549(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body674680 */
t14=t4;
f_3544(t14,t1,t8,t10,t12);}}}}

/* def-args676 in process* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3559(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3559,NULL,2,t0,t1);}
/* def-env677687 */
t2=((C_word*)t0)[2];
f_3554(t2,t1,C_SCHEME_FALSE);}

/* def-env677 in process* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3554(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3554,NULL,3,t0,t1,t2);}
/* def-exactf678684 */
t3=((C_word*)t0)[2];
f_3549(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf678 in process* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3549(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3549,NULL,4,t0,t1,t2,t3);}
/* body674680 */
t4=((C_word*)t0)[2];
f_3544(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body674 in process* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3544(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3544,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1839 %process */
f_3403(t1,lf[277],C_SCHEME_TRUE,((C_word*)t0)[2],t2,t3,t4);}

/* process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3465(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_3465r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3465r(t0,t1,t2,t3);}}

static void C_ccall f_3465r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(13);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3467,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3482,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-args648661 */
t8=t7;
f_3482(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-env649659 */
t10=t6;
f_3477(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf650656 */
t12=t5;
f_3472(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body646652 */
t14=t4;
f_3467(t14,t1,t8,t10,t12);}}}}

/* def-args648 in process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3482(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3482,NULL,2,t0,t1);}
/* def-env649659 */
t2=((C_word*)t0)[2];
f_3477(t2,t1,C_SCHEME_FALSE);}

/* def-env649 in process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3477(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3477,NULL,3,t0,t1,t2);}
/* def-exactf650656 */
t3=((C_word*)t0)[2];
f_3472(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf650 in process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3472(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3472,NULL,4,t0,t1,t2,t3);}
/* body646652 */
t4=((C_word*)t0)[2];
f_3467(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body646 in process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3467(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3467,NULL,5,t0,t1,t2,t3,t4);}
/* posixwin.scm: 1836 %process */
f_3403(t1,lf[276],C_SCHEME_FALSE,((C_word*)t0)[2],t2,t3,t4);}

/* %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3403(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3403,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t12=(C_word)C_i_check_string_2(((C_word*)t8)[1],t2);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3424,a[2]=t11,a[3]=t1,a[4]=t10,a[5]=t3,a[6]=t6,a[7]=t9,a[8]=t8,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t9)[1])){
/* posixwin.scm: 1824 chkstrlst */
t14=t11;
f_3405(t14,t13,((C_word*)t9)[1]);}
else{
t14=C_set_block_item(t10,0,C_SCHEME_TRUE);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3459,a[2]=t13,a[3]=t8,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1827 ##sys#shell-command-arguments */
t16=*((C_word*)lf[265]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,((C_word*)t8)[1]);}}

/* k3457 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3459,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1828 ##sys#shell-command */
t4=*((C_word*)lf[261]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3461 in k3457 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_3424(2,t3,t2);}

/* k3422 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
/* posixwin.scm: 1829 chkstrlst */
t3=((C_word*)t0)[2];
f_3405(t3,t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3427(2,t3,C_SCHEME_UNDEFINED);}}

/* k3425 in k3422 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3438,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1830 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3437 in k3425 in k3422 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3438(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_3438,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(((C_word*)t0)[2])){
/* posixwin.scm: 1832 values */
C_values(6,0,t1,t2,t3,t4,t5);}
else{
/* posixwin.scm: 1833 values */
C_values(5,0,t1,t2,t3,t4);}}

/* a3431 in k3425 in k3422 in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
/* posixwin.scm: 1830 ##sys#process */
t2=*((C_word*)lf[269]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,t1,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_SCHEME_TRUE,C_SCHEME_TRUE,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* chkstrlst in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3405(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3405,NULL,3,t0,t1,t2);}
t3=(C_word)C_i_check_list_2(t2,((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[275]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3413 in chkstrlst in %process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3414,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_check_string_2(t2,((C_word*)t0)[2]));}

/* ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,...){
C_word tmp;
C_word t9;
va_list v;
C_word *a,c2=c;
C_save_rest(t8,c2,9);
if(!C_demand(c*C_SIZEOF_PAIR+14)){
C_save_and_reclaim((void*)tr9rv,(void*)f_3307r,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
else{
a=C_alloc((c-9)*3);
t9=C_restore_rest_vector(a,C_rest_count(0));
f_3307r(t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}}

static void C_ccall f_3307r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(14);
t10=(C_word)C_vemptyp(t9);
t11=(C_truep(t10)?C_SCHEME_FALSE:(C_word)C_slot(t9,C_fix(0)));
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3314,a[2]=t2,a[3]=t6,a[4]=t7,a[5]=t8,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3386,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(C_word)C_a_i_cons(&a,2,t3,t4);
/* posixwin.scm: 1796 $quote-args-list */
t15=lf[249];
f_2837(t15,t13,t14,t11);}

/* k3384 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1796 string-intersperse */
t2=*((C_word*)lf[274]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t3=((*(int *)C_data_pointer(t2))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t5=((*(int *)C_data_pointer(t4))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t6=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t7=((*(int *)C_data_pointer(t6))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t8=(C_word)C_a_i_bytevector(&a,1,C_fix(1));
t9=((*(int *)C_data_pointer(t8))=C_unfix(C_fix(-1)),C_SCHEME_UNDEFINED);
t10=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=((C_word*)t0)[5],a[9]=t2,a[10]=((C_word*)t0)[6],a[11]=t1,a[12]=((C_word*)t0)[7],tmp=(C_word)a,a+=13,tmp);
/* ##sys#make-locative */
t11=*((C_word*)lf[272]+1);
((C_proc6)(void*)(*((C_word*)t11+1)))(6,t11,t10,t2,C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3358,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[5],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3362,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* ##sys#make-locative */
t3=*((C_word*)lf[272]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[7],C_fix(0),C_SCHEME_FALSE,lf[273]);}

/* k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=t1,a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
t3=(C_truep(((C_word*)t0)[6])?C_fix(0):C_fix(1));
t4=(C_truep(((C_word*)t0)[4])?C_fix(0):C_fix(2));
t5=(C_truep(((C_word*)t0)[8])?C_fix(0):C_fix(4));
/* posixwin.scm: 1803 + */
C_plus(5,0,t2,t3,t4,t5);}

/* k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=((C_word*)t0)[16];
t3=((C_word*)t0)[15];
t4=((C_word*)t0)[14];
t5=((C_word*)t0)[13];
t6=((C_word*)t0)[12];
t7=((C_word*)t0)[11];
t8=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3261,a[2]=t3,a[3]=((C_word*)t0)[15],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=t1,a[14]=t7,a[15]=t6,a[16]=t5,a[17]=t4,tmp=(C_word)a,a+=18,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t9=t8;
f_3261(2,t9,C_SCHEME_FALSE);}}

/* k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_3265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t1,a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_3265(2,t3,C_SCHEME_FALSE);}}

/* k3263 in k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[17])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[17]):C_SCHEME_FALSE);
t3=(C_truep(((C_word*)t0)[16])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[16]):C_SCHEME_FALSE);
t4=(C_truep(((C_word*)t0)[15])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[15]):C_SCHEME_FALSE);
t5=(C_truep(((C_word*)t0)[14])?(C_word)C_i_foreign_pointer_argumentp(((C_word*)t0)[14]):C_SCHEME_FALSE);
if(C_truep((C_word)stub556(C_SCHEME_UNDEFINED,((C_word*)t0)[13],t1,C_SCHEME_FALSE,t2,t3,t4,t5,((C_word*)t0)[12]))){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* posixwin.scm: 1806 open-input-file* */
t7=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[4]))));}
else{
t7=t6;
f_3327(2,t7,C_SCHEME_FALSE);}}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3347,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1811 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3345 in k3263 in k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1812 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[270],((C_word*)t0)[3],lf[271],((C_word*)t0)[2]);}

/* k3325 in k3263 in k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3331,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1807 open-output-file* */
t3=*((C_word*)lf[202]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3331(2,t3,C_SCHEME_FALSE);}}

/* k3329 in k3325 in k3263 in k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* posixwin.scm: 1809 open-input-file* */
t3=*((C_word*)lf[201]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))));}
else{
t3=t2;
f_3335(2,t3,C_SCHEME_FALSE);}}

/* k3333 in k3329 in k3325 in k3263 in k3259 in k3368 in k3364 in k3360 in k3356 in k3352 in k3312 in ##sys#process in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1805 values */
C_values(6,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_fix((C_word)*((int *)C_data_pointer(((C_word*)t0)[2]))),t1);}

/* close-handle in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3253(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3253,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub544(C_SCHEME_UNDEFINED,t2));}

/* process-run in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3224(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3rv,(void*)f_3224r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_3224r(t0,t1,t2,t3);}}

static void C_ccall f_3224r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=(C_word)C_notvemptyp(t3);
t5=(C_truep(t4)?(C_word)C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t5)){
/* posixwin.scm: 1764 process-spawn */
t6=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,*((C_word*)lf[244]+1),t2,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3241,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1765 ##sys#shell-command */
t7=*((C_word*)lf[261]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3239 in process-run in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1765 ##sys#shell-command-arguments */
t3=*((C_word*)lf[265]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3243 in k3239 in process-run in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1765 process-spawn */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[244]+1),((C_word*)t0)[2],t1);}

/* ##sys#shell-command-arguments in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3218,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_list(&a,2,lf[266],t2));}

/* ##sys#shell-command in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3201,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1748 getenv */
t3=*((C_word*)lf[263]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[264]);}

/* k3199 in ##sys#shell-command in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep((C_word)C_get_shlcmd())){
/* ##sys#peek-c-string */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_mpointer(&a,(void*)C_shlcmd),C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1752 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}}

/* k3211 in k3199 in ##sys#shell-command in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1753 ##sys#error */
t2=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[261],lf[262]);}

/* current-process-id in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3194,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub532(C_SCHEME_UNDEFINED));}

/* process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3110r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3110r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3110r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3112,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3124,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3134,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t4))){
/* def-arglst511525 */
t9=t8;
f_3134(t9,t1);}
else{
t9=(C_word)C_u_i_car(t4);
t10=(C_word)C_slot(t4,C_fix(1));
if(C_truep((C_word)C_i_nullp(t10))){
/* def-envlst512523 */
t11=t7;
f_3129(t11,t1,t9);}
else{
t11=(C_word)C_u_i_car(t10);
t12=(C_word)C_slot(t10,C_fix(1));
if(C_truep((C_word)C_i_nullp(t12))){
/* def-exactf513520 */
t13=t6;
f_3124(t13,t1,t9,t11);}
else{
t13=(C_word)C_u_i_car(t12);
t14=(C_word)C_slot(t12,C_fix(1));
/* body509515 */
t15=t5;
f_3112(t15,t1,t9,t11,t13);}}}}

/* def-arglst511 in process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3134(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3134,NULL,2,t0,t1);}
/* def-envlst512523 */
t2=((C_word*)t0)[2];
f_3129(t2,t1,C_SCHEME_FALSE);}

/* def-envlst512 in process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3129(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3129,NULL,3,t0,t1,t2);}
/* def-exactf513520 */
t3=((C_word*)t0)[2];
f_3124(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf513 in process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3124(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3124,NULL,4,t0,t1,t2,t3);}
/* body509515 */
t4=((C_word*)t0)[2];
f_3112(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body509 in process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3112(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3112,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3116,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1739 $exec-setup */
t6=lf[254];
f_2978(t6,t5,lf[258],((C_word*)t0)[2],t2,t3,t4);}

/* k3114 in body509 in process-spawn in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[5])?(C_word)C_spawnvpe(((C_word*)t0)[4],t1):(C_word)C_spawnvp(((C_word*)t0)[4],t1));
/* posixwin.scm: 1740 $exec-teardown */
f_3011(((C_word*)t0)[3],lf[258],lf[259],((C_word*)t0)[2],t2);}

/* process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3026(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3026r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3026r(t0,t1,t2,t3);}}

static void C_ccall f_3026r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3040,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3045,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3050,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-arglst481495 */
t8=t7;
f_3050(t8,t1);}
else{
t8=(C_word)C_u_i_car(t3);
t9=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t9))){
/* def-envlst482493 */
t10=t6;
f_3045(t10,t1,t8);}
else{
t10=(C_word)C_u_i_car(t9);
t11=(C_word)C_slot(t9,C_fix(1));
if(C_truep((C_word)C_i_nullp(t11))){
/* def-exactf483490 */
t12=t5;
f_3040(t12,t1,t8,t10);}
else{
t12=(C_word)C_u_i_car(t11);
t13=(C_word)C_slot(t11,C_fix(1));
/* body479485 */
t14=t4;
f_3028(t14,t1,t8,t10,t12);}}}}

/* def-arglst481 in process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3050,NULL,2,t0,t1);}
/* def-envlst482493 */
t2=((C_word*)t0)[2];
f_3045(t2,t1,C_SCHEME_FALSE);}

/* def-envlst482 in process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3045(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3045,NULL,3,t0,t1,t2);}
/* def-exactf483490 */
t3=((C_word*)t0)[2];
f_3040(t3,t1,t2,C_SCHEME_FALSE);}

/* def-exactf483 in process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3040(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3040,NULL,4,t0,t1,t2,t3);}
/* body479485 */
t4=((C_word*)t0)[2];
f_3028(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body479 in process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3028(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3028,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3032,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1734 $exec-setup */
t6=lf[254];
f_2978(t6,t5,lf[256],((C_word*)t0)[2],t2,t3,t4);}

/* k3030 in body479 in process-execute in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_execve(t1):(C_word)C_execvp(t1));
/* posixwin.scm: 1735 $exec-teardown */
f_3011(((C_word*)t0)[3],lf[256],lf[257],((C_word*)t0)[2],t2);}

/* $exec-teardown in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_3011(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3011,NULL,5,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3015,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1726 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3013 in $exec-teardown in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_free_exec_args();
t3=(C_word)C_free_exec_env();
t4=(C_word)C_eqp(((C_word*)t0)[6],C_fix(-1));
if(C_truep(t4)){
/* posixwin.scm: 1730 ##sys#error */
t5=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[6]);}}

/* $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2978(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2978,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_word)C_i_check_string_2(t3,t2);
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2985,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=t3,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* posixwin.scm: 1718 pathname-strip-directory */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_block_size(t1);
/* posixwin.scm: 1719 setarg */
t4=((C_word*)t0)[4];
f_2916(5,t4,t2,C_fix(0),t1,t3);}

/* k2986 in k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1720 $quote-args-list */
t4=lf[249];
f_2837(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3003 in k2986 in k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1720 build-exec-argvec */
f_2928(((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2],C_fix(1));}

/* k2989 in k2986 in k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1721 build-exec-argvec */
f_2928(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k2992 in k2989 in k2986 in k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(C_word)C_flushall();
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3001,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1723 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2999 in k2992 in k2989 in k2986 in k2983 in $exec-setup in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_3001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1723 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* build-exec-argvec in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2928(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2928,NULL,5,t1,t2,t3,t4,t5);}
if(C_truep(t3)){
t6=(C_word)C_i_check_list_2(t3,t2);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2940,a[2]=t8,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_2940(t10,t1,t3,t5);}
else{
/* posixwin.scm: 1715 argvec-setter */
t6=t4;
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t5,C_SCHEME_FALSE,C_fix(0));}}

/* do446 in build-exec-argvec in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2940(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2940,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1711 argvec-setter */
t4=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,t3,C_SCHEME_FALSE,C_fix(0));}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_i_check_string_2(t4,((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_block_size(t4);
/* posixwin.scm: 1714 argvec-setter */
t8=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,t3,t4,t7);}}

/* k2957 in do446 in build-exec-argvec in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2940(t4,((C_word*)t0)[2],t2,t3);}

/* setenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2922,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub435(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* setarg in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2916,5,t0,t1,t2,t3,t4);}
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)stub425(C_SCHEME_UNDEFINED,t2,t5,t4));}

/* $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2837(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2837,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2880,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_2880(t8,t1,t2,C_SCHEME_END_OF_LIST);}}

/* loop in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2880(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2880,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
/* posixwin.scm: 1692 reverse */
t4=*((C_word*)lf[250]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=(C_word)C_u_i_car(t2);
t5=(C_word)C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2908,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2911,a[2]=t4,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1697 needs-quoting? */
t8=((C_word*)t0)[2];
f_2842(t8,t7,t4);}}

/* k2909 in loop in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* posixwin.scm: 1697 string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[251],((C_word*)t0)[2],lf[252]);}
else{
t2=((C_word*)t0)[3];
f_2908(2,t2,((C_word*)t0)[2]);}}

/* k2906 in loop in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* posixwin.scm: 1694 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2880(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* needs-quoting? in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2842,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2846,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1684 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2844 in needs-quoting? in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2846,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2851,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2851(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k2844 in needs-quoting? in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2851(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2851,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2864,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2875,a[2]=t4,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1688 string-ref */
t6=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],t2);}}

/* k2873 in loop in k2844 in needs-quoting? in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1688 char-whitespace? */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2862 in loop in k2844 in needs-quoting? in $quote-args-list in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
t2=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1689 loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2851(t3,((C_word*)t0)[4],t2);}}

/* glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2722(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_2722r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2722r(t0,t1,t2);}}

static void C_ccall f_2722r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(12);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t4,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_2728(t6,t1,t2);}

/* conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2728,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_u_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2743,a[2]=t3,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}}

/* a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2749,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2826,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_truep(t3)?t3:lf[241]);
/* posixwin.scm: 1645 make-pathname */
t8=((C_word*)t0)[7];
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t6,C_SCHEME_FALSE,t7,t4);}

/* k2824 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1645 glob->regexp */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2756,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* posixwin.scm: 1646 make-anchored-pattern */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* posixwin.scm: 1647 regexp */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[240]);
/* posixwin.scm: 1648 directory */
t4=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_TRUE);}

/* k2764 in k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2768(t5,((C_word*)t0)[2],t1);}

/* loop in k2764 in k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2768(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2768,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
/* posixwin.scm: 1649 conc-loop */
t4=((C_word*)((C_word*)t0)[7])[1];
f_2728(t4,t1,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_u_i_car(t2);
/* posixwin.scm: 1650 string-match */
t5=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,((C_word*)t0)[2],t4);}}

/* k2783 in loop in k2764 in k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2795,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_u_i_car(t1);
/* posixwin.scm: 1651 make-pathname */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}
else{
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(1));
/* posixwin.scm: 1652 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2768(t3,((C_word*)t0)[6],t2);}}

/* k2793 in k2783 in loop in k2764 in k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1651 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2768(t4,t2,t3);}

/* k2797 in k2793 in k2783 in loop in k2764 in k2757 in k2754 in k2751 in a2748 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* a2742 in conc-loop in glob in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
/* posixwin.scm: 1644 decompose-pathname */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* set-buffering-mode! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2663(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_2663r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_2663r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2663r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2667,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1615 ##sys#check-port */
t6=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,lf[227]);}

/* k2665 in set-buffering-mode! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2667,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):C_fix((C_word)BUFSIZ));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2673,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t4,lf[229]);
if(C_truep(t6)){
t7=t5;
f_2673(2,t7,C_fix((C_word)_IOFBF));}
else{
t7=(C_word)C_eqp(t4,lf[230]);
if(C_truep(t7)){
t8=t5;
f_2673(2,t8,C_fix((C_word)_IOLBF));}
else{
t8=(C_word)C_eqp(t4,lf[231]);
if(C_truep(t8)){
t9=t5;
f_2673(2,t9,C_fix((C_word)_IONBF));}
else{
/* posixwin.scm: 1621 ##sys#error */
t9=*((C_word*)lf[96]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t5,lf[227],lf[232],((C_word*)t0)[4],((C_word*)t0)[3]);}}}}

/* k2671 in k2665 in set-buffering-mode! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=(C_word)C_i_check_exact_2(((C_word*)t0)[4],lf[227]);
t3=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t4=(C_word)C_eqp(lf[73],t3);
t5=(C_truep(t4)?(C_word)C_setvbuf(((C_word*)t0)[3],t1,((C_word*)t0)[4]):C_fix(-1));
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(0)))){
/* posixwin.scm: 1627 ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,((C_word*)t0)[2],lf[227],lf[228],((C_word*)t0)[3],t1,((C_word*)t0)[4]);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}

/* _exit in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2647r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2647r(t0,t1,t2);}}

static void C_ccall f_2647r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
t3=(C_word)C_notvemptyp(t2);
t4=(C_truep(t3)?(C_word)C_slot(t2,C_fix(0)):C_fix(0));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)stub354(C_SCHEME_UNDEFINED,t4));}

/* local-timezone-abbreviation in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2639,2,t0,t1);}
t2=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,(C_word)stub349(t2),C_fix(0));}

/* local-time->seconds in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2611(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2611,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[221]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2618,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1591 ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[221],lf[224],t2);}
else{
t6=t4;
f_2618(2,t6,C_SCHEME_UNDEFINED);}}

/* k2616 in local-time->seconds in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_mktime(((C_word*)t0)[3]))){
/* posixwin.scm: 1593 ##sys#cons-flonum */
t2=*((C_word*)lf[222]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}
else{
/* posixwin.scm: 1594 ##sys#error */
t2=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[221],lf[223],((C_word*)t0)[3]);}}

/* time->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2572,3,t0,t1,t2);}
t3=(C_word)C_i_check_vector_2(t2,lf[218]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_lessp(t5,C_fix(10)))){
/* posixwin.scm: 1584 ##sys#error */
t6=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[218],lf[220],t2);}
else{
t6=t4;
f_2579(2,t6,C_SCHEME_UNDEFINED);}}

/* k2577 in time->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2582,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub337(t4,t3),C_fix(0));}

/* k2580 in k2577 in time->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2585,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2585(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1586 ##sys#error */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[218],lf[219],((C_word*)t0)[2]);}}

/* k2583 in k2580 in k2577 in time->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1587 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2544(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2544,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2548,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub328(t5,t4),C_fix(0));}

/* k2546 in seconds->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2551,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2551(2,t3,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1577 ##sys#error */
t3=*((C_word*)lf[96]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[216],lf[217],((C_word*)t0)[2]);}}

/* k2549 in k2546 in seconds->string in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_block_size(((C_word*)t0)[3]);
t3=(C_word)C_u_fixnum_difference(t2,C_fix(1));
/* posixwin.scm: 1578 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0),t3);}

/* seconds->utc-time in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2530,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[215]);
/* posixwin.scm: 1571 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_TRUE);}

/* seconds->local-time in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2521,3,t0,t1,t2);}
t3=(C_word)C_i_check_number_2(t2,lf[213]);
/* posixwin.scm: 1567 ##sys#decode-seconds */
t4=*((C_word*)lf[214]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,C_SCHEME_FALSE);}

/* current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2456,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2462(t5,t1,C_fix(0));}

/* loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2462,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2466,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,(C_word)stub311(t5,t4),C_fix(0));}

/* k2464 in loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2466,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2474,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2474(t5,((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* scan in k2464 in loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2474,NULL,3,t0,t1,t2);}
t3=(C_word)C_eqp(C_make_character(61),(C_word)C_subchar(((C_word*)t0)[6],t2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2500,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 1559 substring */
t5=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[6],C_fix(0),t2);}
else{
t4=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* posixwin.scm: 1560 scan */
t7=t1;
t8=t4;
t1=t7;
t2=t8;
goto loop;}}

/* k2498 in scan in k2464 in loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2504,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_u_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_block_size(((C_word*)t0)[3]);
/* posixwin.scm: 1559 substring */
t5=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,((C_word*)t0)[3],t3,t4);}

/* k2502 in k2498 in scan in k2464 in loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_u_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1559 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2462(t5,t3,t4);}

/* k2490 in k2502 in k2498 in scan in k2464 in loop in current-environment in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2492,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* unsetenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2441,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[210]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2449,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1547 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k2447 in unsetenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_putenv(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* setenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2424,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[209]);
t5=(C_word)C_i_check_string_2(t3,lf[209]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2435,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1542 ##sys#make-c-string */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k2433 in setenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1542 ##sys#make-c-string */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2437 in k2433 in setenv in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_setenv(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* duplicate-fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3rv,(void*)f_2394r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_2394r(t0,t1,t2,t3);}}

static void C_ccall f_2394r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(4);
t4=(C_word)C_i_check_exact_2(t2,*((C_word*)lf[207]+1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2401,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_vemptyp(t3))){
t6=t5;
f_2401(t6,(C_word)C_dup(t2));}
else{
t6=(C_word)C_slot(t3,C_fix(0));
t7=(C_word)C_i_check_exact_2(t6,lf[207]);
t8=t5;
f_2401(t8,(C_word)C_dup2(t2,t6));}}

/* k2399 in duplicate-fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2401,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2404,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2410,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1532 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_2404(2,t3,C_SCHEME_UNDEFINED);}}

/* k2408 in k2399 in duplicate-fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1533 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[207],lf[208],((C_word*)t0)[2]);}

/* k2402 in k2399 in duplicate-fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* port->fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1514 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[203]);}

/* k2361 in port->fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2392,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1515 ##sys#peek-unsigned-integer */
t3=*((C_word*)lf[206]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k2390 in k2361 in port->fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2392,2,t0,t1);}
if(C_truep((C_word)C_i_zerop(t1))){
/* posixwin.scm: 1521 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[46],lf[203],lf[204],((C_word*)t0)[2]);}
else{
t2=(C_word)C_C_fileno(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2372,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2378,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1518 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t3;
f_2372(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2376 in k2390 in k2361 in port->fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1519 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[203],lf[205],((C_word*)t0)[2]);}

/* k2370 in k2390 in k2361 in port->fileno in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* open-output-file* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2345(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2345r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2345r(t0,t1,t2,t3);}}

static void C_ccall f_2345r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[202]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2357,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1510 mode */
f_2276(t5,C_SCHEME_FALSE,t3);}

/* k2355 in open-output-file* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1510 check */
f_2313(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_FALSE,t2);}

/* open-input-file* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_2331r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2331r(t0,t1,t2,t3);}}

static void C_ccall f_2331r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t4=(C_word)C_i_check_exact_2(t2,lf[201]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1506 mode */
f_2276(t5,C_SCHEME_TRUE,t3);}

/* k2341 in open-input-file* in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(C_word)C_fdopen(&a,2,((C_word*)t0)[4],t1);
/* posixwin.scm: 1506 check */
f_2313(((C_word*)t0)[2],((C_word*)t0)[4],C_SCHEME_TRUE,t2);}

/* check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2313(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2313,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1497 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2315 in check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1499 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[199],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1500 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[200],lf[73]);}}

/* k2327 in k2315 in check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2276(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2284,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(t3))){
t5=(C_word)C_u_i_car(t3);
t6=(C_word)C_eqp(t5,lf[193]);
if(C_truep(t6)){
t7=t2;
if(C_truep(t7)){
/* posixwin.scm: 1492 ##sys#error */
t8=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t4,lf[194],t5);}
else{
t8=t4;
f_2284(2,t8,lf[195]);}}
else{
/* posixwin.scm: 1493 ##sys#error */
t7=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,lf[196],t5);}}
else{
t5=t4;
f_2284(2,t5,(C_truep(t2)?lf[197]:lf[198]));}}

/* k2282 in mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1488 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* file-execute-access? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2267(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2267,3,t0,t1,t2);}
/* posixwin.scm: 1472 check */
f_2231(t1,t2,C_fix((C_word)2),lf[189]);}

/* file-write-access? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2261,3,t0,t1,t2);}
/* posixwin.scm: 1471 check */
f_2231(t1,t2,C_fix((C_word)4),lf[188]);}

/* file-read-access? in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2255,3,t0,t1,t2);}
/* posixwin.scm: 1470 check */
f_2231(t1,t2,C_fix((C_word)2),lf[187]);}

/* check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_2231(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2231,NULL,4,t1,t2,t3,t4);}
t5=(C_word)C_i_check_string_2(t2,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2253,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1467 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2251 in check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1467 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2247 in check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2249,2,t0,t1);}
t2=(C_word)C_access(t1,((C_word*)t0)[3]);
t3=(C_word)C_eqp(C_fix(0),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2241,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2241(2,t5,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1468 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2239 in k2247 in check in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* change-file-mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2201(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2201,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[185]);
t5=(C_word)C_i_check_exact_2(t3,lf[185]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2225,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1456 ##sys#expand-home-path */
t8=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t2);}

/* k2227 in change-file-mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1456 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2223 in change-file-mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2225,2,t0,t1);}
t2=(C_word)C_chmod(t1,((C_word*)t0)[4]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1457 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2215 in k2223 in change-file-mode in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1458 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[185],lf[186],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#interrupt-hook in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2145,4,t0,t1,t2,t3);}
t4=(C_word)C_slot(((C_word*)t0)[3],t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2155,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1364 h */
t6=t4;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1366 oldhook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k2153 in ##sys#interrupt-hook in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1365 ##sys#context-switch */
C_context_switch(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* set-signal-handler! in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2132,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact_2(t2,lf[146]);
t5=(C_truep(t3)?t2:C_SCHEME_FALSE);
t6=(C_word)C_establish_signal_handler(t2,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_i_setslot(((C_word*)t0)[2],t2,t3));}

/* signal-handler in k2119 in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2123,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[145]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(((C_word*)t0)[2],t2));}

/* create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2rv,(void*)f_2054r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_2054r(t0,t1,t2);}}

static void C_ccall f_2054r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?(C_word)C_u_fixnum_or(*((C_word*)lf[21]+1),*((C_word*)lf[23]+1)):(C_word)C_slot(t2,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2061,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_pipe(C_SCHEME_FALSE,t4),C_fix(0)))){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1301 ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t5;
f_2061(2,t6,C_SCHEME_UNDEFINED);}}

/* k2068 in create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1302 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[37],lf[115],lf[116]);}

/* k2059 in create-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1303 values */
C_values(4,0,((C_word*)t0)[2],C_fix((C_word)C_pipefds[ 0 ]),C_fix((C_word)C_pipefds[ 1 ]));}

/* with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2034r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2034r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2034r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[114]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2038,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2036 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2038,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2044,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1286 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2043 in k2036 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2044r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2044r(t0,t1,t2);}}

static void C_ccall f_2044r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2048,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1288 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2046 in a2043 in k2036 in with-output-to-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[114]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2014r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2014r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2014r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=*((C_word*)lf[112]+1);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2018,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
C_apply(5,0,t6,((C_word*)t0)[2],t2,t4);}

/* k2016 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2024,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1276 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* a2023 in k2016 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2024r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2024r(t0,t1,t2);}}

static void C_ccall f_2024r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2028,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1278 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2026 in a2023 in k2016 in with-input-from-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[112]+1,((C_word*)t0)[4]);
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1990(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1990r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1990r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1990r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1994,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1992 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1266 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2004 in k1992 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2005r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2005r(t0,t1,t2);}}

static void C_ccall f_2005r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1269 close-output-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k2007 in a2004 in k1992 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1998 in k1992 in call-with-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1999,2,t0,t1);}
/* posixwin.scm: 1267 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1966r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1966r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1970,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_apply(5,0,t5,((C_word*)t0)[2],t2,t4);}

/* k1968 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1975,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1981,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1258 ##sys#call-with-values */
C_u_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1980 in k1968 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1981r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1981r(t0,t1,t2);}}

static void C_ccall f_1981r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1985,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1261 close-input-pipe */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k1983 in a1980 in k1968 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1974 in k1968 in call-with-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1975,2,t0,t1);}
/* posixwin.scm: 1259 proc */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1947,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1951,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1245 ##sys#check-port */
t4=*((C_word*)lf[107]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[105]);}

/* k1949 in close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(C_word)close_pipe(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1247 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1952 in k1949 in close-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t2)){
/* posixwin.scm: 1248 ##sys#signal-hook */
t3=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],lf[37],lf[105],lf[106],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1911r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1911r(t0,t1,t2,t3);}}

static void C_ccall f_1911r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[104]);
t5=f_1839(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1925,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[95]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1932,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1240 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1942,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1241 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1242 badmode */
f_1851(t6,t5);}}}

/* k1940 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1942,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1925(2,t2,(C_word)open_binary_output_pipe(&a,1,t1));}

/* k1930 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1932,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1925(2,t2,(C_word)open_text_output_pipe(&a,1,t1));}

/* k1923 in open-output-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1237 check */
f_1857(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1875(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_1875r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1875r(t0,t1,t2,t3);}}

static void C_ccall f_1875r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(11);
t4=(C_word)C_i_check_string_2(t2,lf[102]);
t5=f_1839(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1889,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(t5,lf[95]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1896,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1230 ##sys#make-c-string */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t2);}
else{
t8=(C_word)C_eqp(t5,lf[103]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1906,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1231 ##sys#make-c-string */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
/* posixwin.scm: 1232 badmode */
f_1851(t6,t5);}}}

/* k1904 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1889(2,t2,(C_word)open_binary_input_pipe(&a,1,t1));}

/* k1894 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1889(2,t2,(C_word)open_text_input_pipe(&a,1,t1));}

/* k1887 in open-input-pipe in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1227 check */
f_1857(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1857(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1857,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1217 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1859 in check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
/* posixwin.scm: 1219 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[37],lf[98],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1873,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1220 ##sys#make-port */
t3=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],*((C_word*)lf[100]+1),lf[101],lf[73]);}}

/* k1871 in k1859 in check in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_set_file_ptr(t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* badmode in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1851(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1851,NULL,2,t1,t2);}
/* posixwin.scm: 1215 ##sys#error */
t3=*((C_word*)lf[96]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[97],t2);}

/* mode in k1068 in k1065 in k1062 in k1059 in k1056 */
static C_word C_fcall f_1839(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
t2=(C_word)C_i_pairp(t1);
return((C_truep(t2)?(C_word)C_slot(t1,C_fix(0)):lf[95]));}

/* current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1800(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2rv,(void*)f_1800r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest_vector(a,C_rest_count(0));
f_1800r(t0,t1,t2);}}

static void C_ccall f_1800r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(3);
t3=(C_word)C_vemptyp(t2);
t4=(C_truep(t3)?C_SCHEME_FALSE:(C_word)C_slot(t2,C_fix(0)));
if(C_truep(t4)){
/* posixwin.scm: 1202 change-directory */
t5=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1813,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1203 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}}

/* k1811 in current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(C_word)C_curdir(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1816,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1205 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1814 in k1811 in current-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* posixwin.scm: 1207 ##sys#substring */
t2=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),((C_word*)t0)[4]);}
else{
/* posixwin.scm: 1208 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[91],lf[94]);}}

/* directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1773,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[92]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1780,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1798,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1195 ##sys#expand-home-path */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t2);}

/* k1796 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1195 ##sys#platform-fixup-pathname */
t2=*((C_word*)lf[93]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1792 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1194 ##sys#file-info */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1778 in directory? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(1),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1616(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_1616r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1616r(t0,t1,t2);}}

static void C_ccall f_1616r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1719,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1724,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t2))){
/* def-spec113139 */
t6=t5;
f_1724(t6,t1);}
else{
t6=(C_word)C_u_i_car(t2);
t7=(C_word)C_slot(t2,C_fix(1));
if(C_truep((C_word)C_i_nullp(t7))){
/* def-show-dotfiles?114137 */
t8=t4;
f_1719(t8,t1,t6);}
else{
t8=(C_word)C_u_i_car(t7);
t9=(C_word)C_slot(t7,C_fix(1));
/* body111116 */
t10=t3;
f_1618(t10,t1,t6,t8);}}}

/* def-spec113 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1724(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1724,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1732,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1165 current-directory */
t3=*((C_word*)lf[91]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1730 in def-spec113 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* def-show-dotfiles?114137 */
t2=((C_word*)t0)[3];
f_1719(t2,((C_word*)t0)[2],t1);}

/* def-show-dotfiles?114 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1719,NULL,3,t0,t1,t2);}
/* body111116 */
t3=((C_word*)t0)[2];
f_1618(t3,t1,t2,C_SCHEME_FALSE);}

/* body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1618(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1618,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_string_2(t2,lf[88]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1625,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1167 make-string */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_fix(256));}

/* k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1168 ##sys#make-pointer */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* posixwin.scm: 1169 ##sys#make-pointer */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1170 ##sys#expand-home-path */
t4=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1716 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1170 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1635,2,t0,t1);}
t2=(C_word)C_opendir(t1,((C_word*)t0)[7]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[7]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1173 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1652,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_1652(t6,((C_word*)t0)[6]);}}

/* loop in k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1652(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1652,NULL,2,t0,t1);}
t2=(C_word)C_readdir(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep((C_word)C_null_pointerp(((C_word*)t0)[5]))){
t3=(C_word)C_closedir(((C_word*)t0)[6]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(C_word)C_foundfile(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1182 ##sys#substring */
t5=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[4],C_fix(0),t3);}}

/* k1660 in loop in k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=(C_word)C_subchar(t1,C_fix(0));
t3=(C_word)C_i_greaterp(((C_word*)t0)[5],C_fix(1));
t4=(C_truep(t3)?(C_word)C_subchar(t1,C_fix(1)):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1674,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_eqp(t2,C_make_character(46));
if(C_truep(t6)){
t7=(C_word)C_i_not(t4);
if(C_truep(t7)){
t8=t5;
f_1674(t8,t7);}
else{
t8=(C_word)C_eqp(t4,C_make_character(46));
t9=(C_truep(t8)?(C_word)C_eqp(((C_word*)t0)[5],C_fix(2)):C_SCHEME_FALSE);
t10=t5;
f_1674(t10,(C_truep(t9)?t9:(C_word)C_i_not(((C_word*)t0)[2])));}}
else{
t7=t5;
f_1674(t7,C_SCHEME_FALSE);}}

/* k1672 in k1660 in loop in k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1674(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1674,NULL,2,t0,t1);}
if(C_truep(t1)){
/* posixwin.scm: 1189 loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1652(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1190 loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1652(t3,t2);}}

/* k1682 in k1672 in k1660 in loop in k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1684,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k1642 in k1633 in k1629 in k1626 in k1623 in body111 in directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1174 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[88],lf[89],((C_word*)t0)[2]);}

/* delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1589,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[85]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1610,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1157 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1612 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1157 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1608 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=(C_word)C_rmdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1602,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1158 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1600 in k1608 in delete-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1159 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[85],lf[86],((C_word*)t0)[2]);}

/* change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1562,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[83]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1583,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1587,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1150 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1585 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1150 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1581 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(C_word)C_chdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1151 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1573 in k1581 in change-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1152 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[83],lf[84],((C_word*)t0)[2]);}

/* create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1535,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[81]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1556,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1143 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1558 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1143 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1554 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1556,2,t0,t1);}
t2=(C_word)C_mkdir(t1);
if(C_truep((C_word)C_i_zerop(t2))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1144 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1546 in k1554 in create-directory in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1145 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[81],lf[82],((C_word*)t0)[2]);}

/* set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1474r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1474r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1474r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(6);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):C_fix((C_word)SEEK_SET));
t7=(C_word)C_i_check_exact_2(t3,lf[76]);
t8=(C_word)C_i_check_exact_2(t6,lf[76]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1487,a[2]=t6,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_lessp(t3,C_fix(0)))){
/* posixwin.scm: 1128 ##sys#signal-hook */
t10=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t9,lf[79],lf[76],lf[80],t3,t2);}
else{
t10=t9;
f_1487(2,t10,C_SCHEME_UNDEFINED);}}

/* k1485 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1129 port? */
t4=*((C_word*)lf[75]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k1500 in k1485 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[5],C_fix(7));
t3=(C_word)C_eqp(t2,lf[73]);
t4=((C_word*)t0)[4];
f_1493(2,t4,(C_truep(t3)?(C_word)C_fseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[5]))){
t2=((C_word*)t0)[4];
f_1493(2,t2,(C_word)C_lseek(((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2]));}
else{
/* posixwin.scm: 1133 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[46],lf[76],lf[78],((C_word*)t0)[5]);}}}

/* k1491 in k1485 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1496,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1134 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1494 in k1491 in k1485 in set-file-position! in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1135 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[76],lf[77],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1434,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1438,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1453,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1112 port? */
t5=*((C_word*)lf[75]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1451 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(7));
t3=(C_word)C_eqp(t2,lf[73]);
t4=((C_word*)t0)[2];
f_1438(2,t4,(C_truep(t3)?(C_word)C_ftell(((C_word*)t0)[3]):C_fix(-1)));}
else{
if(C_truep((C_word)C_fixnump(((C_word*)t0)[3]))){
t2=((C_word*)t0)[2];
f_1438(2,t2,(C_word)C_lseek(((C_word*)t0)[3],C_fix(0),C_fix((C_word)SEEK_CUR)));}
else{
/* posixwin.scm: 1117 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[46],lf[71],lf[74],((C_word*)t0)[3]);}}}

/* k1436 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1441,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1447,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1119 ##sys#update-errno */
t4=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t2;
f_1441(2,t3,C_SCHEME_UNDEFINED);}}

/* k1445 in k1436 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1120 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[71],lf[72],((C_word*)t0)[2]);}

/* k1439 in k1436 in file-position in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* symbolic-link? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1428(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1428,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[70]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}

/* regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1405,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[68]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1412,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1426,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1103 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k1424 in regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1103 ##sys#file-info */
t2=*((C_word*)lf[69]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1410 in regular-file? in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(4));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(C_fix(0),t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* file-permissions in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1399,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1403,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1099 ##sys#stat */
f_1307(t3,t2);}

/* k1401 in file-permissions in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode));}

/* file-owner in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1393,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1397,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1098 ##sys#stat */
f_1307(t3,t2);}

/* k1395 in file-owner in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid));}

/* file-change-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1387,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1391,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1097 ##sys#stat */
f_1307(t3,t2);}

/* k1389 in file-change-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1391,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_ctime));}

/* file-access-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1381,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1385,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1096 ##sys#stat */
f_1307(t3,t2);}

/* k1383 in file-access-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_atime));}

/* file-modification-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1375,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1095 ##sys#stat */
f_1307(t3,t2);}

/* k1377 in file-modification-time in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1379,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_flonum(&a,C_statbuf.st_mtime));}

/* file-size in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1369,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1094 ##sys#stat */
f_1307(t3,t2);}

/* k1371 in file-size in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size));}

/* file-stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1345r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1345r(t0,t1,t2,t3);}}

static void C_ccall f_1345r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(3);
t4=(C_word)C_vemptyp(t3);
t5=(C_truep(t4)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1352,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1088 ##sys#stat */
f_1307(t6,t2);}

/* k1350 in file-stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1352,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_vector(&a,13,C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_ino),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_mode),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_nlink),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_uid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_gid),C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)C_statbuf.st_size),C_flonum(&a,C_statbuf.st_atime),C_flonum(&a,C_statbuf.st_ctime),C_flonum(&a,C_statbuf.st_mtime),C_fix(0),C_fix(0),C_fix(0),C_fix(0)));}

/* ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_fcall f_1307(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1307,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1311,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_fixnump(t2))){
t4=t3;
f_1311(2,t4,(C_word)C_fstat(t2));}
else{
if(C_truep((C_word)C_i_stringp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1081 ##sys#expand-home-path */
t6=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
/* posixwin.scm: 1082 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[46],lf[60],t2);}}}

/* k1338 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1081 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1334 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1311(2,t2,(C_word)C_stat(t1));}

/* k1309 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
if(C_truep((C_word)C_fixnum_lessp(t1,C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1084 ##sys#update-errno */
t3=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1318 in k1309 in ##sys#stat in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1085 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[37],lf[59],((C_word*)t0)[2]);}

/* file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1269,3,t0,t1,t2);}
t3=(C_word)C_i_check_string_2(t2,lf[52]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1276,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1050 ##sys#make-c-string */
t5=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1274 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(C_word)C_mkstemp(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1052 string-length */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1277 in k1274 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_eqp(C_fix(-1),((C_word*)t0)[4]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1054 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t2;
f_1282(2,t4,C_SCHEME_UNDEFINED);}}

/* k1297 in k1277 in k1274 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1055 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[52],lf[54],((C_word*)t0)[2]);}

/* k1280 in k1277 in k1274 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1289,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_u_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* posixwin.scm: 1056 ##sys#substring */
t4=*((C_word*)lf[53]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],C_fix(0),t3);}

/* k1287 in k1280 in k1277 in k1274 in file-mkstemp in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1056 values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1227(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1227r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1227r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1227r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(6);
t5=(C_word)C_i_check_exact_2(t2,lf[48]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1234,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t7=(C_truep((C_word)C_blockp(t3))?(C_word)C_byteblockp(t3):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t6;
f_1234(2,t8,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1037 ##sys#signal-hook */
t8=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t8+1)))(6,t8,t6,lf[46],lf[48],lf[50],t3);}}

/* k1232 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1234,2,t0,t1);}
t2=(C_word)C_notvemptyp(((C_word*)t0)[5]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[5],C_fix(0)):(C_word)C_block_size(((C_word*)t0)[4]));
t4=(C_word)C_i_check_exact_2(t3,lf[48]);
t5=(C_word)C_write(((C_word*)t0)[3],((C_word*)t0)[4],t3);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1243,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1249,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1042 ##sys#update-errno */
t9=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1243(2,t8,C_SCHEME_UNDEFINED);}}

/* k1247 in k1232 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1043 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[48],lf[49],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1241 in k1232 in file-write in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1182(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1182r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1182r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1182r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(C_word)C_i_check_exact_2(t2,lf[44]);
t6=(C_word)C_i_check_exact_2(t3,lf[44]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1192,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_notvemptyp(t4))){
t8=t7;
f_1192(2,t8,(C_word)C_slot(t4,C_fix(0)));}
else{
/* posixwin.scm: 1024 make-string */
t8=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}}

/* k1190 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep((C_word)C_blockp(t1))?(C_word)C_byteblockp(t1):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=t2;
f_1195(2,t4,C_SCHEME_UNDEFINED);}
else{
/* posixwin.scm: 1026 ##sys#signal-hook */
t4=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[46],lf[44],lf[47],t1);}}

/* k1193 in k1190 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1195,2,t0,t1);}
t2=(C_word)C_read(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1198,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1207,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* posixwin.scm: 1029 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1198(2,t5,C_SCHEME_UNDEFINED);}}

/* k1205 in k1193 in k1190 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1030 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[37],lf[44],lf[45],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1196 in k1193 in k1190 in file-read in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1198,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* file-close in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1164,3,t0,t1,t2);}
t3=(C_word)C_i_check_exact_2(t2,lf[41]);
if(C_truep((C_word)C_fixnum_lessp((C_word)C_close(t2),C_fix(0)))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* posixwin.scm: 1016 ##sys#update-errno */
t5=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1175 in file-close in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1017 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[37],lf[41],lf[42],((C_word*)t0)[2]);}

/* file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4rv,(void*)f_1123r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest_vector(a,C_rest_count(0));
f_1123r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1123r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(9);
t5=(C_word)C_notvemptyp(t4);
t6=(C_truep(t5)?(C_word)C_slot(t4,C_fix(0)):((C_word*)t0)[2]);
t7=(C_word)C_i_check_string_2(t2,lf[36]);
t8=(C_word)C_i_check_exact_2(t3,lf[36]);
t9=(C_word)C_i_check_exact_2(t6,lf[36]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1140,a[2]=t2,a[3]=t1,a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1156,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* posixwin.scm: 1006 ##sys#expand-home-path */
t12=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t2);}

/* k1154 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1006 ##sys#make-c-string */
t2=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1138 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1140,2,t0,t1);}
t2=(C_word)C_open(t1,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1143,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* posixwin.scm: 1008 ##sys#update-errno */
t6=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_1143(2,t5,C_SCHEME_UNDEFINED);}}

/* k1147 in k1138 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 1009 ##sys#signal-hook */
t2=*((C_word*)lf[6]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[5],lf[37],lf[36],lf[38],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1141 in k1138 in file-open in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr5r,(void*)f_1077r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1077r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1077r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1081,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* posixwin.scm: 937  ##sys#update-errno */
t7=*((C_word*)lf[9]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k1079 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,(C_word)stub3(t4,t1),C_fix(0));}

/* k1090 in k1079 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* posixwin.scm: 938  string-append */
t2=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[7],t1);}

/* k1086 in k1079 in posix-error in k1068 in k1065 in k1062 in k1059 in k1056 */
static void C_ccall f_1088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(7,0,((C_word*)t0)[5],*((C_word*)lf[6]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[373] = {
{"toplevelposixwin.scm",(void*)C_posix_toplevel},
{"f_1058posixwin.scm",(void*)f_1058},
{"f_1061posixwin.scm",(void*)f_1061},
{"f_1064posixwin.scm",(void*)f_1064},
{"f_1067posixwin.scm",(void*)f_1067},
{"f_1070posixwin.scm",(void*)f_1070},
{"f_2121posixwin.scm",(void*)f_2121},
{"f_4234posixwin.scm",(void*)f_4234},
{"f_4231posixwin.scm",(void*)f_4231},
{"f_4224posixwin.scm",(void*)f_4224},
{"f_4218posixwin.scm",(void*)f_4218},
{"f_4212posixwin.scm",(void*)f_4212},
{"f_4206posixwin.scm",(void*)f_4206},
{"f_4200posixwin.scm",(void*)f_4200},
{"f_4194posixwin.scm",(void*)f_4194},
{"f_4188posixwin.scm",(void*)f_4188},
{"f_4182posixwin.scm",(void*)f_4182},
{"f_4176posixwin.scm",(void*)f_4176},
{"f_4170posixwin.scm",(void*)f_4170},
{"f_4164posixwin.scm",(void*)f_4164},
{"f_4158posixwin.scm",(void*)f_4158},
{"f_4152posixwin.scm",(void*)f_4152},
{"f_4146posixwin.scm",(void*)f_4146},
{"f_4140posixwin.scm",(void*)f_4140},
{"f_4134posixwin.scm",(void*)f_4134},
{"f_4128posixwin.scm",(void*)f_4128},
{"f_4122posixwin.scm",(void*)f_4122},
{"f_4116posixwin.scm",(void*)f_4116},
{"f_4110posixwin.scm",(void*)f_4110},
{"f_4104posixwin.scm",(void*)f_4104},
{"f_4098posixwin.scm",(void*)f_4098},
{"f_4092posixwin.scm",(void*)f_4092},
{"f_4086posixwin.scm",(void*)f_4086},
{"f_4080posixwin.scm",(void*)f_4080},
{"f_4074posixwin.scm",(void*)f_4074},
{"f_4068posixwin.scm",(void*)f_4068},
{"f_4062posixwin.scm",(void*)f_4062},
{"f_4056posixwin.scm",(void*)f_4056},
{"f_4050posixwin.scm",(void*)f_4050},
{"f_4044posixwin.scm",(void*)f_4044},
{"f_4038posixwin.scm",(void*)f_4038},
{"f_4032posixwin.scm",(void*)f_4032},
{"f_4026posixwin.scm",(void*)f_4026},
{"f_4020posixwin.scm",(void*)f_4020},
{"f_4014posixwin.scm",(void*)f_4014},
{"f_4008posixwin.scm",(void*)f_4008},
{"f_4002posixwin.scm",(void*)f_4002},
{"f_3996posixwin.scm",(void*)f_3996},
{"f_3990posixwin.scm",(void*)f_3990},
{"f_3984posixwin.scm",(void*)f_3984},
{"f_3978posixwin.scm",(void*)f_3978},
{"f_3972posixwin.scm",(void*)f_3972},
{"f_3749posixwin.scm",(void*)f_3749},
{"f_3906posixwin.scm",(void*)f_3906},
{"f_3912posixwin.scm",(void*)f_3912},
{"f_3901posixwin.scm",(void*)f_3901},
{"f_3896posixwin.scm",(void*)f_3896},
{"f_3751posixwin.scm",(void*)f_3751},
{"f_3883posixwin.scm",(void*)f_3883},
{"f_3891posixwin.scm",(void*)f_3891},
{"f_3758posixwin.scm",(void*)f_3758},
{"f_3871posixwin.scm",(void*)f_3871},
{"f_3768posixwin.scm",(void*)f_3768},
{"f_3770posixwin.scm",(void*)f_3770},
{"f_3789posixwin.scm",(void*)f_3789},
{"f_3857posixwin.scm",(void*)f_3857},
{"f_3864posixwin.scm",(void*)f_3864},
{"f_3851posixwin.scm",(void*)f_3851},
{"f_3804posixwin.scm",(void*)f_3804},
{"f_3838posixwin.scm",(void*)f_3838},
{"f_3824posixwin.scm",(void*)f_3824},
{"f_3836posixwin.scm",(void*)f_3836},
{"f_3832posixwin.scm",(void*)f_3832},
{"f_3816posixwin.scm",(void*)f_3816},
{"f_3814posixwin.scm",(void*)f_3814},
{"f_3875posixwin.scm",(void*)f_3875},
{"f_3734posixwin.scm",(void*)f_3734},
{"f_3744posixwin.scm",(void*)f_3744},
{"f_3703posixwin.scm",(void*)f_3703},
{"f_3729posixwin.scm",(void*)f_3729},
{"f_3714posixwin.scm",(void*)f_3714},
{"f_3718posixwin.scm",(void*)f_3718},
{"f_3722posixwin.scm",(void*)f_3722},
{"f_3726posixwin.scm",(void*)f_3726},
{"f_3691posixwin.scm",(void*)f_3691},
{"f_3688posixwin.scm",(void*)f_3688},
{"f_3631posixwin.scm",(void*)f_3631},
{"f_3655posixwin.scm",(void*)f_3655},
{"f_3665posixwin.scm",(void*)f_3665},
{"f_3649posixwin.scm",(void*)f_3649},
{"f_3619posixwin.scm",(void*)f_3619},
{"f_3542posixwin.scm",(void*)f_3542},
{"f_3559posixwin.scm",(void*)f_3559},
{"f_3554posixwin.scm",(void*)f_3554},
{"f_3549posixwin.scm",(void*)f_3549},
{"f_3544posixwin.scm",(void*)f_3544},
{"f_3465posixwin.scm",(void*)f_3465},
{"f_3482posixwin.scm",(void*)f_3482},
{"f_3477posixwin.scm",(void*)f_3477},
{"f_3472posixwin.scm",(void*)f_3472},
{"f_3467posixwin.scm",(void*)f_3467},
{"f_3403posixwin.scm",(void*)f_3403},
{"f_3459posixwin.scm",(void*)f_3459},
{"f_3463posixwin.scm",(void*)f_3463},
{"f_3424posixwin.scm",(void*)f_3424},
{"f_3427posixwin.scm",(void*)f_3427},
{"f_3438posixwin.scm",(void*)f_3438},
{"f_3432posixwin.scm",(void*)f_3432},
{"f_3405posixwin.scm",(void*)f_3405},
{"f_3414posixwin.scm",(void*)f_3414},
{"f_3307posixwin.scm",(void*)f_3307},
{"f_3386posixwin.scm",(void*)f_3386},
{"f_3314posixwin.scm",(void*)f_3314},
{"f_3354posixwin.scm",(void*)f_3354},
{"f_3358posixwin.scm",(void*)f_3358},
{"f_3362posixwin.scm",(void*)f_3362},
{"f_3366posixwin.scm",(void*)f_3366},
{"f_3370posixwin.scm",(void*)f_3370},
{"f_3261posixwin.scm",(void*)f_3261},
{"f_3265posixwin.scm",(void*)f_3265},
{"f_3347posixwin.scm",(void*)f_3347},
{"f_3327posixwin.scm",(void*)f_3327},
{"f_3331posixwin.scm",(void*)f_3331},
{"f_3335posixwin.scm",(void*)f_3335},
{"f_3253posixwin.scm",(void*)f_3253},
{"f_3224posixwin.scm",(void*)f_3224},
{"f_3241posixwin.scm",(void*)f_3241},
{"f_3245posixwin.scm",(void*)f_3245},
{"f_3218posixwin.scm",(void*)f_3218},
{"f_3197posixwin.scm",(void*)f_3197},
{"f_3201posixwin.scm",(void*)f_3201},
{"f_3213posixwin.scm",(void*)f_3213},
{"f_3194posixwin.scm",(void*)f_3194},
{"f_3110posixwin.scm",(void*)f_3110},
{"f_3134posixwin.scm",(void*)f_3134},
{"f_3129posixwin.scm",(void*)f_3129},
{"f_3124posixwin.scm",(void*)f_3124},
{"f_3112posixwin.scm",(void*)f_3112},
{"f_3116posixwin.scm",(void*)f_3116},
{"f_3026posixwin.scm",(void*)f_3026},
{"f_3050posixwin.scm",(void*)f_3050},
{"f_3045posixwin.scm",(void*)f_3045},
{"f_3040posixwin.scm",(void*)f_3040},
{"f_3028posixwin.scm",(void*)f_3028},
{"f_3032posixwin.scm",(void*)f_3032},
{"f_3011posixwin.scm",(void*)f_3011},
{"f_3015posixwin.scm",(void*)f_3015},
{"f_2978posixwin.scm",(void*)f_2978},
{"f_2985posixwin.scm",(void*)f_2985},
{"f_2988posixwin.scm",(void*)f_2988},
{"f_3005posixwin.scm",(void*)f_3005},
{"f_2991posixwin.scm",(void*)f_2991},
{"f_2994posixwin.scm",(void*)f_2994},
{"f_3001posixwin.scm",(void*)f_3001},
{"f_2928posixwin.scm",(void*)f_2928},
{"f_2940posixwin.scm",(void*)f_2940},
{"f_2959posixwin.scm",(void*)f_2959},
{"f_2922posixwin.scm",(void*)f_2922},
{"f_2916posixwin.scm",(void*)f_2916},
{"f_2837posixwin.scm",(void*)f_2837},
{"f_2880posixwin.scm",(void*)f_2880},
{"f_2911posixwin.scm",(void*)f_2911},
{"f_2908posixwin.scm",(void*)f_2908},
{"f_2842posixwin.scm",(void*)f_2842},
{"f_2846posixwin.scm",(void*)f_2846},
{"f_2851posixwin.scm",(void*)f_2851},
{"f_2875posixwin.scm",(void*)f_2875},
{"f_2864posixwin.scm",(void*)f_2864},
{"f_2722posixwin.scm",(void*)f_2722},
{"f_2728posixwin.scm",(void*)f_2728},
{"f_2749posixwin.scm",(void*)f_2749},
{"f_2826posixwin.scm",(void*)f_2826},
{"f_2753posixwin.scm",(void*)f_2753},
{"f_2756posixwin.scm",(void*)f_2756},
{"f_2759posixwin.scm",(void*)f_2759},
{"f_2766posixwin.scm",(void*)f_2766},
{"f_2768posixwin.scm",(void*)f_2768},
{"f_2785posixwin.scm",(void*)f_2785},
{"f_2795posixwin.scm",(void*)f_2795},
{"f_2799posixwin.scm",(void*)f_2799},
{"f_2743posixwin.scm",(void*)f_2743},
{"f_2663posixwin.scm",(void*)f_2663},
{"f_2667posixwin.scm",(void*)f_2667},
{"f_2673posixwin.scm",(void*)f_2673},
{"f_2647posixwin.scm",(void*)f_2647},
{"f_2639posixwin.scm",(void*)f_2639},
{"f_2611posixwin.scm",(void*)f_2611},
{"f_2618posixwin.scm",(void*)f_2618},
{"f_2572posixwin.scm",(void*)f_2572},
{"f_2579posixwin.scm",(void*)f_2579},
{"f_2582posixwin.scm",(void*)f_2582},
{"f_2585posixwin.scm",(void*)f_2585},
{"f_2544posixwin.scm",(void*)f_2544},
{"f_2548posixwin.scm",(void*)f_2548},
{"f_2551posixwin.scm",(void*)f_2551},
{"f_2530posixwin.scm",(void*)f_2530},
{"f_2521posixwin.scm",(void*)f_2521},
{"f_2456posixwin.scm",(void*)f_2456},
{"f_2462posixwin.scm",(void*)f_2462},
{"f_2466posixwin.scm",(void*)f_2466},
{"f_2474posixwin.scm",(void*)f_2474},
{"f_2500posixwin.scm",(void*)f_2500},
{"f_2504posixwin.scm",(void*)f_2504},
{"f_2492posixwin.scm",(void*)f_2492},
{"f_2441posixwin.scm",(void*)f_2441},
{"f_2449posixwin.scm",(void*)f_2449},
{"f_2424posixwin.scm",(void*)f_2424},
{"f_2435posixwin.scm",(void*)f_2435},
{"f_2439posixwin.scm",(void*)f_2439},
{"f_2394posixwin.scm",(void*)f_2394},
{"f_2401posixwin.scm",(void*)f_2401},
{"f_2410posixwin.scm",(void*)f_2410},
{"f_2404posixwin.scm",(void*)f_2404},
{"f_2359posixwin.scm",(void*)f_2359},
{"f_2363posixwin.scm",(void*)f_2363},
{"f_2392posixwin.scm",(void*)f_2392},
{"f_2378posixwin.scm",(void*)f_2378},
{"f_2372posixwin.scm",(void*)f_2372},
{"f_2345posixwin.scm",(void*)f_2345},
{"f_2357posixwin.scm",(void*)f_2357},
{"f_2331posixwin.scm",(void*)f_2331},
{"f_2343posixwin.scm",(void*)f_2343},
{"f_2313posixwin.scm",(void*)f_2313},
{"f_2317posixwin.scm",(void*)f_2317},
{"f_2329posixwin.scm",(void*)f_2329},
{"f_2276posixwin.scm",(void*)f_2276},
{"f_2284posixwin.scm",(void*)f_2284},
{"f_2267posixwin.scm",(void*)f_2267},
{"f_2261posixwin.scm",(void*)f_2261},
{"f_2255posixwin.scm",(void*)f_2255},
{"f_2231posixwin.scm",(void*)f_2231},
{"f_2253posixwin.scm",(void*)f_2253},
{"f_2249posixwin.scm",(void*)f_2249},
{"f_2241posixwin.scm",(void*)f_2241},
{"f_2201posixwin.scm",(void*)f_2201},
{"f_2229posixwin.scm",(void*)f_2229},
{"f_2225posixwin.scm",(void*)f_2225},
{"f_2217posixwin.scm",(void*)f_2217},
{"f_2145posixwin.scm",(void*)f_2145},
{"f_2155posixwin.scm",(void*)f_2155},
{"f_2132posixwin.scm",(void*)f_2132},
{"f_2123posixwin.scm",(void*)f_2123},
{"f_2054posixwin.scm",(void*)f_2054},
{"f_2070posixwin.scm",(void*)f_2070},
{"f_2061posixwin.scm",(void*)f_2061},
{"f_2034posixwin.scm",(void*)f_2034},
{"f_2038posixwin.scm",(void*)f_2038},
{"f_2044posixwin.scm",(void*)f_2044},
{"f_2048posixwin.scm",(void*)f_2048},
{"f_2014posixwin.scm",(void*)f_2014},
{"f_2018posixwin.scm",(void*)f_2018},
{"f_2024posixwin.scm",(void*)f_2024},
{"f_2028posixwin.scm",(void*)f_2028},
{"f_1990posixwin.scm",(void*)f_1990},
{"f_1994posixwin.scm",(void*)f_1994},
{"f_2005posixwin.scm",(void*)f_2005},
{"f_2009posixwin.scm",(void*)f_2009},
{"f_1999posixwin.scm",(void*)f_1999},
{"f_1966posixwin.scm",(void*)f_1966},
{"f_1970posixwin.scm",(void*)f_1970},
{"f_1981posixwin.scm",(void*)f_1981},
{"f_1985posixwin.scm",(void*)f_1985},
{"f_1975posixwin.scm",(void*)f_1975},
{"f_1947posixwin.scm",(void*)f_1947},
{"f_1951posixwin.scm",(void*)f_1951},
{"f_1954posixwin.scm",(void*)f_1954},
{"f_1911posixwin.scm",(void*)f_1911},
{"f_1942posixwin.scm",(void*)f_1942},
{"f_1932posixwin.scm",(void*)f_1932},
{"f_1925posixwin.scm",(void*)f_1925},
{"f_1875posixwin.scm",(void*)f_1875},
{"f_1906posixwin.scm",(void*)f_1906},
{"f_1896posixwin.scm",(void*)f_1896},
{"f_1889posixwin.scm",(void*)f_1889},
{"f_1857posixwin.scm",(void*)f_1857},
{"f_1861posixwin.scm",(void*)f_1861},
{"f_1873posixwin.scm",(void*)f_1873},
{"f_1851posixwin.scm",(void*)f_1851},
{"f_1839posixwin.scm",(void*)f_1839},
{"f_1800posixwin.scm",(void*)f_1800},
{"f_1813posixwin.scm",(void*)f_1813},
{"f_1816posixwin.scm",(void*)f_1816},
{"f_1773posixwin.scm",(void*)f_1773},
{"f_1798posixwin.scm",(void*)f_1798},
{"f_1794posixwin.scm",(void*)f_1794},
{"f_1780posixwin.scm",(void*)f_1780},
{"f_1616posixwin.scm",(void*)f_1616},
{"f_1724posixwin.scm",(void*)f_1724},
{"f_1732posixwin.scm",(void*)f_1732},
{"f_1719posixwin.scm",(void*)f_1719},
{"f_1618posixwin.scm",(void*)f_1618},
{"f_1625posixwin.scm",(void*)f_1625},
{"f_1628posixwin.scm",(void*)f_1628},
{"f_1631posixwin.scm",(void*)f_1631},
{"f_1718posixwin.scm",(void*)f_1718},
{"f_1635posixwin.scm",(void*)f_1635},
{"f_1652posixwin.scm",(void*)f_1652},
{"f_1662posixwin.scm",(void*)f_1662},
{"f_1674posixwin.scm",(void*)f_1674},
{"f_1684posixwin.scm",(void*)f_1684},
{"f_1644posixwin.scm",(void*)f_1644},
{"f_1589posixwin.scm",(void*)f_1589},
{"f_1614posixwin.scm",(void*)f_1614},
{"f_1610posixwin.scm",(void*)f_1610},
{"f_1602posixwin.scm",(void*)f_1602},
{"f_1562posixwin.scm",(void*)f_1562},
{"f_1587posixwin.scm",(void*)f_1587},
{"f_1583posixwin.scm",(void*)f_1583},
{"f_1575posixwin.scm",(void*)f_1575},
{"f_1535posixwin.scm",(void*)f_1535},
{"f_1560posixwin.scm",(void*)f_1560},
{"f_1556posixwin.scm",(void*)f_1556},
{"f_1548posixwin.scm",(void*)f_1548},
{"f_1474posixwin.scm",(void*)f_1474},
{"f_1487posixwin.scm",(void*)f_1487},
{"f_1502posixwin.scm",(void*)f_1502},
{"f_1493posixwin.scm",(void*)f_1493},
{"f_1496posixwin.scm",(void*)f_1496},
{"f_1434posixwin.scm",(void*)f_1434},
{"f_1453posixwin.scm",(void*)f_1453},
{"f_1438posixwin.scm",(void*)f_1438},
{"f_1447posixwin.scm",(void*)f_1447},
{"f_1441posixwin.scm",(void*)f_1441},
{"f_1428posixwin.scm",(void*)f_1428},
{"f_1405posixwin.scm",(void*)f_1405},
{"f_1426posixwin.scm",(void*)f_1426},
{"f_1412posixwin.scm",(void*)f_1412},
{"f_1399posixwin.scm",(void*)f_1399},
{"f_1403posixwin.scm",(void*)f_1403},
{"f_1393posixwin.scm",(void*)f_1393},
{"f_1397posixwin.scm",(void*)f_1397},
{"f_1387posixwin.scm",(void*)f_1387},
{"f_1391posixwin.scm",(void*)f_1391},
{"f_1381posixwin.scm",(void*)f_1381},
{"f_1385posixwin.scm",(void*)f_1385},
{"f_1375posixwin.scm",(void*)f_1375},
{"f_1379posixwin.scm",(void*)f_1379},
{"f_1369posixwin.scm",(void*)f_1369},
{"f_1373posixwin.scm",(void*)f_1373},
{"f_1345posixwin.scm",(void*)f_1345},
{"f_1352posixwin.scm",(void*)f_1352},
{"f_1307posixwin.scm",(void*)f_1307},
{"f_1340posixwin.scm",(void*)f_1340},
{"f_1336posixwin.scm",(void*)f_1336},
{"f_1311posixwin.scm",(void*)f_1311},
{"f_1320posixwin.scm",(void*)f_1320},
{"f_1269posixwin.scm",(void*)f_1269},
{"f_1276posixwin.scm",(void*)f_1276},
{"f_1279posixwin.scm",(void*)f_1279},
{"f_1299posixwin.scm",(void*)f_1299},
{"f_1282posixwin.scm",(void*)f_1282},
{"f_1289posixwin.scm",(void*)f_1289},
{"f_1227posixwin.scm",(void*)f_1227},
{"f_1234posixwin.scm",(void*)f_1234},
{"f_1249posixwin.scm",(void*)f_1249},
{"f_1243posixwin.scm",(void*)f_1243},
{"f_1182posixwin.scm",(void*)f_1182},
{"f_1192posixwin.scm",(void*)f_1192},
{"f_1195posixwin.scm",(void*)f_1195},
{"f_1207posixwin.scm",(void*)f_1207},
{"f_1198posixwin.scm",(void*)f_1198},
{"f_1164posixwin.scm",(void*)f_1164},
{"f_1177posixwin.scm",(void*)f_1177},
{"f_1123posixwin.scm",(void*)f_1123},
{"f_1156posixwin.scm",(void*)f_1156},
{"f_1140posixwin.scm",(void*)f_1140},
{"f_1149posixwin.scm",(void*)f_1149},
{"f_1143posixwin.scm",(void*)f_1143},
{"f_1077posixwin.scm",(void*)f_1077},
{"f_1081posixwin.scm",(void*)f_1081},
{"f_1092posixwin.scm",(void*)f_1092},
{"f_1088posixwin.scm",(void*)f_1088},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
