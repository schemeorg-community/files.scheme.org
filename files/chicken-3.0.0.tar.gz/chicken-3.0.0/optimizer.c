/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:29
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: optimizer.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -extend private-namespace.scm -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[259];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9555)
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9563)
static void C_ccall f_9563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9568)
static void C_fcall f_9568(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9578)
static void C_ccall f_9578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9602)
static void C_ccall f_9602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9587)
static void C_fcall f_9587(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8960)
static void C_ccall f_8960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9002)
static void C_ccall f_9002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9012)
static void C_fcall f_9012(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_fcall f_9105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9121)
static void C_fcall f_9121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9168)
static void C_ccall f_9168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9158)
static void C_ccall f_9158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9270)
static void C_ccall f_9270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_9283)
static void C_ccall f_9283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9318)
static void C_ccall f_9318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9302)
static void C_ccall f_9302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9306)
static void C_ccall f_9306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9295)
static void C_ccall f_9295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9392)
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_ccall f_9411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9457)
static void C_ccall f_9457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9449)
static void C_ccall f_9449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9433)
static void C_ccall f_9433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8744)
static void C_ccall f_8744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8766)
static void C_ccall f_8766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8821)
static void C_ccall f_8821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8791)
static void C_ccall f_8791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8813)
static void C_ccall f_8813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8809)
static void C_ccall f_8809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8789)
static void C_ccall f_8789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8855)
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_8869)
static void C_ccall f_8869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3947)
static void C_ccall f_3947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7084)
static void C_ccall f_7084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8631)
static void C_ccall f_8631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8634)
static void C_ccall f_8634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8637)
static void C_ccall f_8637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8646)
static void C_ccall f_8646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8723)
static void C_ccall f_8723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8649)
static void C_ccall f_8649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8652)
static void C_ccall f_8652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8655)
static void C_ccall f_8655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8717)
static void C_ccall f_8717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_ccall f_8658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8661)
static void C_ccall f_8661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7693)
static void C_fcall f_7693(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7711)
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7717)
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8664)
static void C_ccall f_8664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8706)
static void C_ccall f_8706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8704)
static void C_ccall f_8704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8670)
static void C_ccall f_8670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8673)
static void C_ccall f_8673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8676)
static void C_ccall f_8676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8679)
static void C_ccall f_8679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8682)
static void C_ccall f_8682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8685)
static void C_ccall f_8685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8688)
static void C_ccall f_8688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8691)
static void C_ccall f_8691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8484)
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8490)
static void C_ccall f_8490(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8602)
static void C_ccall f_8602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8611)
static void C_ccall f_8611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8614)
static void C_ccall f_8614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8509)
static void C_ccall f_8509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_fcall f_8514(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8555)
static void C_fcall f_8555(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8552)
static void C_ccall f_8552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8537)
static void C_ccall f_8537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8548)
static void C_ccall f_8548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8544)
static void C_ccall f_8544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8397)
static void C_fcall f_8397(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8403)
static void C_ccall f_8403(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8459)
static void C_ccall f_8459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8455)
static void C_ccall f_8455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8425)
static void C_ccall f_8425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8147)
static void C_fcall f_8147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8161)
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8168)
static void C_ccall f_8168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8181)
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8188)
static void C_ccall f_8188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8191)
static void C_ccall f_8191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8373)
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8392)
static void C_ccall f_8392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8388)
static void C_ccall f_8388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8330)
static void C_ccall f_8330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8313)
static void C_ccall f_8313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8272)
static void C_ccall f_8272(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8194)
static void C_ccall f_8194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8243)
static void C_ccall f_8243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8231)
static void C_ccall f_8231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8227)
static void C_ccall f_8227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8159)
static void C_ccall f_8159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7946)
static void C_fcall f_7946(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8133)
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8011)
static void C_ccall f_8011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8088)
static void C_ccall f_8088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8093)
static void C_ccall f_8093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8131)
static void C_ccall f_8131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7955)
static void C_ccall f_7955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7993)
static void C_ccall f_7993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7998)
static void C_ccall f_7998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7975)
static void C_ccall f_7975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7953)
static void C_ccall f_7953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8123)
static void C_ccall f_8123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8109)
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8013)
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8079)
static void C_ccall f_8079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8033)
static void C_ccall f_8033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8055)
static void C_ccall f_8055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8051)
static void C_ccall f_8051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8043)
static void C_ccall f_8043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_fcall f_7727(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7733)
static void C_fcall f_7733(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7752)
static void C_fcall f_7752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7919)
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7849)
static void C_ccall f_7849(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7865)
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7895)
static void C_ccall f_7895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_ccall f_7899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7838)
static void C_ccall f_7838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7843)
static void C_ccall f_7843(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7814)
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7826)
static void C_ccall f_7826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7763)
static void C_fcall f_7763(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7784)
static void C_ccall f_7784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7781)
static void C_ccall f_7781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7731)
static void C_ccall f_7731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_fcall f_7483(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7489)
static void C_fcall f_7489(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7508)
static void C_fcall f_7508(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7610)
static void C_ccall f_7610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7601)
static void C_ccall f_7601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7567)
static void C_fcall f_7567(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7576)
static void C_ccall f_7576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7588)
static void C_ccall f_7588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7519)
static void C_fcall f_7519(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7540)
static void C_ccall f_7540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7537)
static void C_ccall f_7537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7487)
static void C_ccall f_7487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7384)
static void C_fcall f_7384(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7390)
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7434)
static void C_ccall f_7434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7439)
static void C_fcall f_7439(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7446)
static void C_ccall f_7446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7473)
static void C_ccall f_7473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7469)
static void C_ccall f_7469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7461)
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7459)
static void C_ccall f_7459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7424)
static void C_ccall f_7424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7402)
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7409)
static void C_ccall f_7409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7187)
static void C_fcall f_7187(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7341)
static void C_ccall f_7341(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7366)
static void C_ccall f_7366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7356)
static void C_ccall f_7356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7360)
static void C_ccall f_7360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_ccall f_7339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7190)
static void C_fcall f_7190(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7312)
static void C_ccall f_7312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7324)
static void C_ccall f_7324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7258)
static void C_fcall f_7258(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7240)
static void C_ccall f_7240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7215)
static void C_fcall f_7215(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7218)
static void C_fcall f_7218(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7223)
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7087)
static void C_fcall f_7087(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7093)
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7124)
static void C_fcall f_7124(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7128)
static void C_ccall f_7128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7132)
static void C_ccall f_7132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7091)
static void C_ccall f_7091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7079)
static void C_ccall f_7079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7082)
static void C_ccall f_7082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_fcall f_5952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6062)
static void C_ccall f_6062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6008)
static void C_ccall f_6008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6014)
static void C_ccall f_6014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6114)
static void C_fcall f_6114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_6524)
static void C_ccall f_6524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6531)
static void C_ccall f_6531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6117)
static void C_fcall f_6117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_6511)
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_ccall f_6498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6454)
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6393)
static void C_fcall f_6393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6365)
static void C_fcall f_6365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6312)
static void C_ccall f_6312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6318)
static void C_fcall f_6318(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6323)
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_fcall f_6277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6255)
static void C_ccall f_6255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6251)
static void C_ccall f_6251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6221)
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6184)
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6200)
static void C_ccall f_6200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6166)
static void C_ccall f_6166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6533)
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_7069)
static void C_ccall f_7069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7067)
static void C_ccall f_7067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6537)
static void C_ccall f_6537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6547)
static void C_ccall f_6547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7041)
static void C_ccall f_7041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6553)
static void C_fcall f_6553(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6559)
static void C_ccall f_6559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6562)
static void C_ccall f_6562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6568)
static void C_ccall f_6568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6744)
static void C_ccall f_6744(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6966)
static void C_ccall f_6966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6969)
static void C_ccall f_6969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6919)
static void C_ccall f_6919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_ccall f_6922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6788)
static void C_ccall f_6788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6846)
static void C_ccall f_6846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6873)
static void C_ccall f_6873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6849)
static void C_ccall f_6849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6852)
static void C_ccall f_6852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6571)
static void C_ccall f_6571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6726)
static void C_ccall f_6726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6724)
static void C_ccall f_6724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6677)
static void C_ccall f_6677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6574)
static void C_ccall f_6574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6586)
static void C_ccall f_6586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6589)
static void C_ccall f_6589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6592)
static void C_ccall f_6592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3969)
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5854)
static void C_ccall f_5854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5868)
static void C_fcall f_5868(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_fcall f_3994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5888)
static void C_ccall f_5888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5835)
static void C_ccall f_5835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5754)
static void C_ccall f_5754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5757)
static void C_ccall f_5757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5776)
static void C_fcall f_5776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5603)
static void C_ccall f_5603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5693)
static void C_ccall f_5693(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5618)
static void C_ccall f_5618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5662)
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5660)
static void C_ccall f_5660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5570)
static void C_ccall f_5570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_ccall f_5379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_ccall f_5382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5442)
static void C_ccall f_5442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5407)
static void C_ccall f_5407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5347)
static void C_ccall f_5347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5357)
static void C_ccall f_5357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5299)
static void C_fcall f_5299(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5200)
static void C_ccall f_5200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5230)
static void C_fcall f_5230(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5107)
static void C_ccall f_5107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5021)
static void C_ccall f_5021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5024)
static void C_ccall f_5024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4974)
static void C_fcall f_4974(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4977)
static void C_ccall f_4977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4919)
static void C_ccall f_4919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4815)
static void C_ccall f_4815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_fcall f_4830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4843)
static void C_ccall f_4843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4750)
static void C_ccall f_4750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4758)
static void C_ccall f_4758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4584)
static void C_ccall f_4584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4606)
static void C_fcall f_4606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4609)
static void C_fcall f_4609(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4668)
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4612)
static void C_ccall f_4612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4615)
static void C_ccall f_4615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4620)
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4600)
static void C_ccall f_4600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4557)
static void C_ccall f_4557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4496)
static void C_ccall f_4496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4499)
static void C_ccall f_4499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4523)
static void C_ccall f_4523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4512)
static void C_ccall f_4512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4431)
static void C_ccall f_4431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4338)
static void C_ccall f_4338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4383)
static void C_ccall f_4383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4282)
static void C_ccall f_4282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4134)
static void C_ccall f_4134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4137)
static void C_ccall f_4137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4162)
static void C_fcall f_4162(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4026)
static void C_ccall f_4026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4089)
static void C_ccall f_4089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_fcall f_4029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3949)
static void C_ccall f_3949r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_ccall f_3963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3934)
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3943)
static void C_ccall f_3943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3876)
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3921)
static void C_ccall f_3921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_ccall f_3886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3894)
static void C_ccall f_3894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3832)
static void C_ccall f_3832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3678)
static void C_ccall f_3678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3757)
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3789)
static void C_ccall f_3789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3755)
static void C_ccall f_3755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3684)
static void C_ccall f_3684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3693)
static void C_ccall f_3693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3627)
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3633)
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3606)
static void C_ccall f_3606r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3415)
static void C_ccall f_3415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3421)
static void C_fcall f_3421(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_fcall f_3436(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3442)
static void C_ccall f_3442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_fcall f_3448(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3457)
static void C_fcall f_3457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3176)
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3183)
static void C_ccall f_3183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3188)
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3201)
static void C_ccall f_3201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3377)
static void C_ccall f_3377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_ccall f_3204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3349)
static void C_ccall f_3349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3222)
static void C_fcall f_3222(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3228)
static void C_ccall f_3228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_fcall f_3237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3243)
static void C_ccall f_3243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3264)
static void C_ccall f_3264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_ccall f_3168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3152)
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3148)
static C_word C_fcall f_3148(C_word t0);
C_noret_decl(f_1674)
static void C_ccall f_1674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3049)
static void C_ccall f_3049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3068)
static void C_ccall f_3068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_fcall f_3030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3034)
static void C_ccall f_3034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_ccall f_2943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3022)
static void C_ccall f_3022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2955)
static void C_fcall f_2955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2961)
static void C_ccall f_2961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2915)
static void C_ccall f_2915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_ccall f_2348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_fcall f_2531(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_fcall f_2552(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2748)
static void C_fcall f_2748(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2774)
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2801)
static void C_ccall f_2801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2793)
static void C_ccall f_2793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2768)
static void C_ccall f_2768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2603)
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2642)
static void C_ccall f_2642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2648)
static void C_ccall f_2648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2685)
static void C_ccall f_2685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_ccall f_2661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_ccall f_2665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2619)
static void C_ccall f_2619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2558)
static void C_ccall f_2558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2571)
static void C_ccall f_2571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2495)
static void C_ccall f_2495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_fcall f_2441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_fcall f_2399(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2369)
static void C_ccall f_2369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2172)
static void C_ccall f_2172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2264)
static void C_ccall f_2264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2276)
static void C_ccall f_2276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2305)
static void C_ccall f_2305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_ccall f_2289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2202)
static void C_ccall f_2202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_ccall f_2238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2231)
static void C_ccall f_2231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2183)
static void C_ccall f_2183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2157)
static void C_ccall f_2157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2118)
static void C_fcall f_2118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2135)
static void C_ccall f_2135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_fcall f_2040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2056)
static void C_ccall f_2056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_fcall f_2079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1983)
static void C_ccall f_1983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1965)
static void C_ccall f_1965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1917)
static void C_ccall f_1917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1927)
static void C_ccall f_1927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1947)
static void C_ccall f_1947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1906)
static void C_ccall f_1906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1910)
static void C_fcall f_1910(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1707)
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1711)
static void C_ccall f_1711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1722)
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1771)
static void C_ccall f_1771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1750)
static void C_fcall f_1750(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1703)
static C_word C_fcall f_1703(C_word t0);
C_noret_decl(f_1693)
static C_word C_fcall f_1693(C_word t0);
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1677)
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1468)
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_fcall f_1516(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1568)
static void C_fcall f_1568(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1587)
static void C_ccall f_1587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1571)
static void C_ccall f_1571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_fcall f_1504(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1499)
static void C_ccall f_1499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static C_word C_fcall f_1471(C_word *a,C_word t0,C_word t1);

C_noret_decl(trf_9568)
static void C_fcall trf_9568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9568(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9568(t0,t1,t2);}

C_noret_decl(trf_9587)
static void C_fcall trf_9587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9587(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9587(t0,t1);}

C_noret_decl(trf_9012)
static void C_fcall trf_9012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9012(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9012(t0,t1,t2,t3);}

C_noret_decl(trf_9105)
static void C_fcall trf_9105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9105(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_9105(t0,t1,t2,t3,t4);}

C_noret_decl(trf_9121)
static void C_fcall trf_9121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9121(t0,t1);}

C_noret_decl(trf_7693)
static void C_fcall trf_7693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7693(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7693(t0,t1,t2,t3);}

C_noret_decl(trf_8484)
static void C_fcall trf_8484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8484(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8484(t0,t1,t2);}

C_noret_decl(trf_8514)
static void C_fcall trf_8514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8514(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8514(t0,t1,t2,t3);}

C_noret_decl(trf_8555)
static void C_fcall trf_8555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8555(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8555(t0,t1);}

C_noret_decl(trf_8397)
static void C_fcall trf_8397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8397(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8397(t0,t1,t2);}

C_noret_decl(trf_8147)
static void C_fcall trf_8147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8147(t0,t1,t2,t3);}

C_noret_decl(trf_7946)
static void C_fcall trf_7946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7946(t0,t1,t2);}

C_noret_decl(trf_7727)
static void C_fcall trf_7727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7727(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7727(t0,t1,t2);}

C_noret_decl(trf_7733)
static void C_fcall trf_7733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7733(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7733(t0,t1,t2,t3);}

C_noret_decl(trf_7752)
static void C_fcall trf_7752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7752(t0,t1);}

C_noret_decl(trf_7763)
static void C_fcall trf_7763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7763(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7763(t0,t1,t2,t3);}

C_noret_decl(trf_7483)
static void C_fcall trf_7483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7483(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7483(t0,t1,t2);}

C_noret_decl(trf_7489)
static void C_fcall trf_7489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7489(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7489(t0,t1,t2,t3);}

C_noret_decl(trf_7508)
static void C_fcall trf_7508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7508(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7508(t0,t1);}

C_noret_decl(trf_7567)
static void C_fcall trf_7567(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7567(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7567(t0,t1);}

C_noret_decl(trf_7519)
static void C_fcall trf_7519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7519(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7519(t0,t1,t2,t3);}

C_noret_decl(trf_7384)
static void C_fcall trf_7384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7384(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7384(t0,t1,t2,t3);}

C_noret_decl(trf_7439)
static void C_fcall trf_7439(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7439(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7439(t0,t1,t2,t3);}

C_noret_decl(trf_7187)
static void C_fcall trf_7187(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7187(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7187(t0,t1,t2);}

C_noret_decl(trf_7190)
static void C_fcall trf_7190(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7190(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7190(t0,t1,t2,t3);}

C_noret_decl(trf_7258)
static void C_fcall trf_7258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7258(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7258(t0,t1,t2,t3);}

C_noret_decl(trf_7215)
static void C_fcall trf_7215(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7215(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7215(t0,t1);}

C_noret_decl(trf_7218)
static void C_fcall trf_7218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7218(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7218(t0,t1);}

C_noret_decl(trf_7087)
static void C_fcall trf_7087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7087(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7087(t0,t1);}

C_noret_decl(trf_7124)
static void C_fcall trf_7124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7124(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7124(t0,t1);}

C_noret_decl(trf_5952)
static void C_fcall trf_5952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5952(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5952(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6114)
static void C_fcall trf_6114(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6114(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_6114(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_6117)
static void C_fcall trf_6117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6117(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_6117(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_6393)
static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6393(t0,t1);}

C_noret_decl(trf_6365)
static void C_fcall trf_6365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6365(t0,t1);}

C_noret_decl(trf_6318)
static void C_fcall trf_6318(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6318(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6318(t0,t1);}

C_noret_decl(trf_6277)
static void C_fcall trf_6277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6277(t0,t1);}

C_noret_decl(trf_6533)
static void C_fcall trf_6533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6533(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_6533(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_6553)
static void C_fcall trf_6553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6553(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6553(t0,t1);}

C_noret_decl(trf_5868)
static void C_fcall trf_5868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5868(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5868(t0,t1,t2,t3);}

C_noret_decl(trf_3994)
static void C_fcall trf_3994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3994(t0,t1);}

C_noret_decl(trf_5776)
static void C_fcall trf_5776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5776(t0,t1);}

C_noret_decl(trf_5299)
static void C_fcall trf_5299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5299(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5299(t0,t1);}

C_noret_decl(trf_5230)
static void C_fcall trf_5230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5230(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5230(t0,t1);}

C_noret_decl(trf_4974)
static void C_fcall trf_4974(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4974(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4974(t0,t1);}

C_noret_decl(trf_4830)
static void C_fcall trf_4830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4830(t0,t1);}

C_noret_decl(trf_4606)
static void C_fcall trf_4606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4606(t0,t1);}

C_noret_decl(trf_4609)
static void C_fcall trf_4609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4609(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4609(t0,t1);}

C_noret_decl(trf_4165)
static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4165(t0,t1);}

C_noret_decl(trf_4162)
static void C_fcall trf_4162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4162(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4162(t0,t1);}

C_noret_decl(trf_4029)
static void C_fcall trf_4029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4029(t0,t1);}

C_noret_decl(trf_3972)
static void C_fcall trf_3972(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3972(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3972(t0,t1,t2,t3);}

C_noret_decl(trf_3714)
static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3714(t0,t1);}

C_noret_decl(trf_3627)
static void C_fcall trf_3627(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3627(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3627(t0,t1,t2,t3);}

C_noret_decl(trf_3633)
static void C_fcall trf_3633(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3633(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3633(t0,t1,t2,t3);}

C_noret_decl(trf_3421)
static void C_fcall trf_3421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3421(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3421(t0,t1);}

C_noret_decl(trf_3436)
static void C_fcall trf_3436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3436(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3436(t0,t1);}

C_noret_decl(trf_3448)
static void C_fcall trf_3448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3448(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3448(t0,t1);}

C_noret_decl(trf_3457)
static void C_fcall trf_3457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3457(t0,t1);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3210(t0,t1);}

C_noret_decl(trf_3222)
static void C_fcall trf_3222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3222(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3222(t0,t1);}

C_noret_decl(trf_3237)
static void C_fcall trf_3237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3237(t0,t1);}

C_noret_decl(trf_3152)
static void C_fcall trf_3152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3152(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3152(t0,t1,t2,t3);}

C_noret_decl(trf_3030)
static void C_fcall trf_3030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3030(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3030(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2015(t0,t1,t2);}

C_noret_decl(trf_2984)
static void C_fcall trf_2984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2984(t0,t1);}

C_noret_decl(trf_2955)
static void C_fcall trf_2955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2955(t0,t1);}

C_noret_decl(trf_2531)
static void C_fcall trf_2531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2531(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2531(t0,t1);}

C_noret_decl(trf_2552)
static void C_fcall trf_2552(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2552(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2552(t0,t1);}

C_noret_decl(trf_2748)
static void C_fcall trf_2748(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2748(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2748(t0,t1);}

C_noret_decl(trf_2603)
static void C_fcall trf_2603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2603(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2603(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2441)
static void C_fcall trf_2441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2441(t0,t1);}

C_noret_decl(trf_2399)
static void C_fcall trf_2399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2399(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2399(t0,t1);}

C_noret_decl(trf_2118)
static void C_fcall trf_2118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2118(t0,t1);}

C_noret_decl(trf_2040)
static void C_fcall trf_2040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2040(t0,t1,t2);}

C_noret_decl(trf_2079)
static void C_fcall trf_2079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2079(t0,t1);}

C_noret_decl(trf_1910)
static void C_fcall trf_1910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1910(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1910(t0,t1);}

C_noret_decl(trf_1707)
static void C_fcall trf_1707(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1707(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1707(t0,t1,t2);}

C_noret_decl(trf_1750)
static void C_fcall trf_1750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1750(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1750(t0,t1);}

C_noret_decl(trf_1677)
static void C_fcall trf_1677(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1677(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1677(t0,t1,t2,t3);}

C_noret_decl(trf_1516)
static void C_fcall trf_1516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1516(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1516(t0,t1,t2,t3);}

C_noret_decl(trf_1568)
static void C_fcall trf_1568(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1568(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1568(t0,t1);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1541(t0,t1);}

C_noret_decl(trf_1504)
static void C_fcall trf_1504(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1504(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1504(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1914)){
C_save(t1);
C_rereclaim2(1914*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,259);
lf[0]=C_h_intern(&lf[0],19,"\003sysundefined-value");
lf[1]=C_h_intern(&lf[1],34,"\010compilerscan-toplevel-assignments");
lf[2]=C_h_intern(&lf[2],12,"always-bound");
lf[3]=C_h_intern(&lf[3],6,"append");
lf[4]=C_h_intern(&lf[4],18,"\010compilerdebugging");
lf[5]=C_h_intern(&lf[5],1,"o");
lf[6]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[7]=C_h_intern(&lf[7],12,"\003sysfor-each");
lf[8]=C_h_intern(&lf[8],13,"\004corevariable");
lf[9]=C_h_intern(&lf[9],2,"if");
lf[10]=C_h_intern(&lf[10],3,"let");
lf[11]=C_h_intern(&lf[11],6,"lambda");
lf[12]=C_h_intern(&lf[12],13,"\004corecallunit");
lf[13]=C_h_intern(&lf[13],9,"\004corecall");
lf[14]=C_h_intern(&lf[14],4,"set!");
lf[15]=C_h_intern(&lf[15],9,"\004corecond");
lf[16]=C_h_intern(&lf[16],11,"\004coreswitch");
lf[17]=C_h_intern(&lf[17],30,"call-with-current-continuation");
lf[18]=C_h_intern(&lf[18],1,"p");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[20]=C_h_intern(&lf[20],24,"\010compilersimplifications");
lf[21]=C_h_intern(&lf[21],23,"\010compilersimplified-ops");
lf[22]=C_h_intern(&lf[22],41,"\010compilerperform-high-level-optimizations");
lf[23]=C_h_intern(&lf[23],12,"\010compilerget");
lf[24]=C_h_intern(&lf[24],5,"quote");
lf[25]=C_h_intern(&lf[25],10,"alist-cons");
lf[26]=C_h_intern(&lf[26],4,"caar");
lf[27]=C_h_intern(&lf[27],7,"\003sysmap");
lf[28]=C_h_intern(&lf[28],19,"\010compilermatch-node");
lf[29]=C_h_intern(&lf[29],3,"any");
lf[30]=C_h_intern(&lf[30],18,"\003syshash-table-ref");
lf[31]=C_h_intern(&lf[31],30,"\010compilerbroken-constant-nodes");
lf[32]=C_h_intern(&lf[32],11,"lset-adjoin");
lf[33]=C_h_intern(&lf[33],3,"eq\077");
lf[34]=C_h_intern(&lf[34],4,"node");
lf[35]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[36]=C_h_intern(&lf[36],14,"\010compilerqnode");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[38]=C_h_intern(&lf[38],4,"eval");
lf[39]=C_h_intern(&lf[39],22,"with-exception-handler");
lf[40]=C_h_intern(&lf[40],5,"every");
lf[41]=C_h_intern(&lf[41],8,"foldable");
lf[42]=C_h_intern(&lf[42],16,"extended-binding");
lf[43]=C_h_intern(&lf[43],16,"standard-binding");
lf[44]=C_h_intern(&lf[44],5,"value");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[46]=C_h_intern(&lf[46],16,"\010compilervarnode");
lf[47]=C_h_intern(&lf[47],11,"collapsable");
lf[48]=C_h_intern(&lf[48],10,"replacable");
lf[49]=C_h_intern(&lf[49],9,"replacing");
lf[50]=C_h_intern(&lf[50],12,"contractable");
lf[51]=C_h_intern(&lf[51],9,"removable");
lf[52]=C_h_intern(&lf[52],11,"\004corelambda");
lf[53]=C_h_intern(&lf[53],6,"unused");
lf[54]=C_h_intern(&lf[54],9,"partition");
lf[55]=C_h_intern(&lf[55],26,"\010compilerbuild-lambda-list");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[57]=C_h_intern(&lf[57],13,"explicit-rest");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[59]=C_h_intern(&lf[59],30,"\010compilerdecompose-lambda-list");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[61]=C_h_intern(&lf[61],21,"has-unused-parameters");
lf[62]=C_h_intern(&lf[62],31,"\010compilerinline-lambda-bindings");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[64]=C_h_intern(&lf[64],24,"\010compilercheck-signature");
lf[65]=C_h_intern(&lf[65],30,"\010compilerconstant-declarations");
lf[66]=C_h_intern(&lf[66],14,"\004coreundefined");
lf[67]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[68]=C_h_intern(&lf[68],1,"x");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\0005removed call to constant procedure with unused result");
lf[70]=C_h_intern(&lf[70],37,"\010compilerexpression-has-side-effects\077");
lf[71]=C_h_intern(&lf[71],8,"assigned");
lf[72]=C_h_intern(&lf[72],10,"references");
lf[73]=C_h_intern(&lf[73],7,"unknown");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[75]=C_h_intern(&lf[75],1,"i");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023procedure inlinable");
lf[77]=C_h_intern(&lf[77],14,"append-reverse");
lf[78]=C_h_intern(&lf[78],6,"gensym");
lf[79]=C_h_intern(&lf[79],1,"t");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[81]=C_h_intern(&lf[81],8,"split-at");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[83]=C_h_intern(&lf[83],20,"\004coreinline_allocate");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[85]=C_h_intern(&lf[85],24,"\010compilernot-inline-list");
lf[86]=C_h_intern(&lf[86],20,"\010compilerinline-list");
lf[87]=C_h_intern(&lf[87],24,"\010compilerinline-max-size");
lf[88]=C_h_intern(&lf[88],9,"inlinable");
lf[89]=C_h_intern(&lf[89],6,"simple");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[91]=C_h_intern(&lf[91],26,"\010compilerblock-compilation");
lf[92]=C_h_intern(&lf[92],20,"\010compilerexport-list");
lf[93]=C_h_intern(&lf[93],6,"global");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[97]=C_h_intern(&lf[97],5,"print");
lf[98]=C_h_intern(&lf[98],7,"newline");
lf[99]=C_h_intern(&lf[99],6,"print*");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[103]=C_h_intern(&lf[103],34,"\010compilerperform-pre-optimization!");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[105]=C_h_intern(&lf[105],24,"node-subexpressions-set!");
lf[106]=C_h_intern(&lf[106],20,"node-parameters-set!");
lf[107]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\034removed call in test-context");
lf[109]=C_h_intern(&lf[109],10,"call-sites");
lf[110]=C_h_intern(&lf[110],67,"\010compilerside-effect-free-standard-bindings-that-never-return-false");
lf[111]=C_h_intern(&lf[111],7,"reverse");
lf[112]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[113]=C_h_intern(&lf[113],3,"not");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[115]=C_h_intern(&lf[115],24,"register-simplifications");
lf[116]=C_h_intern(&lf[116],19,"\003syshash-table-set!");
lf[117]=C_h_intern(&lf[117],38,"\010compilerreorganize-recursive-bindings");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\026eliminated assignments");
lf[119]=C_h_intern(&lf[119],10,"fold-right");
lf[120]=C_h_intern(&lf[120],4,"fold");
lf[121]=C_h_intern(&lf[121],25,"\010compilertopological-sort");
lf[122]=C_h_intern(&lf[122],6,"lset<=");
lf[123]=C_h_intern(&lf[123],10,"filter-map");
lf[124]=C_h_intern(&lf[124],6,"filter");
lf[125]=C_h_intern(&lf[125],10,"append-map");
lf[126]=C_h_intern(&lf[126],28,"\010compilerscan-used-variables");
lf[127]=C_h_intern(&lf[127],8,"for-each");
lf[128]=C_h_intern(&lf[128],3,"map");
lf[129]=C_h_intern(&lf[129],4,"cons");
lf[130]=C_h_intern(&lf[130],27,"\010compilersubstitution-table");
lf[131]=C_h_intern(&lf[131],16,"\010compilerrewrite");
lf[132]=C_h_intern(&lf[132],28,"\010compilersimplify-named-call");
lf[133]=C_h_intern(&lf[133],37,"\010compilerinline-substitutions-enabled");
lf[134]=C_h_intern(&lf[134],11,"\004coreinline");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[137]=C_h_intern(&lf[137],6,"unsafe");
lf[138]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[139]=C_h_intern(&lf[139],6,"vector");
lf[140]=C_h_intern(&lf[140],14,"rest-parameter");
lf[141]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[142]=C_h_intern(&lf[142],11,"number-type");
lf[143]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[145]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_h_intern(&lf[147],6,"fixnum");
lf[148]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[149]=C_h_intern(&lf[149],21,"\010compilerfold-boolean");
lf[150]=C_h_intern(&lf[150],6,"flonum");
lf[151]=C_h_intern(&lf[151],7,"generic");
lf[152]=C_h_intern(&lf[152],5,"cons*");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_h_intern(&lf[154],9,"\004coreproc");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[161]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[162]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[163]=C_h_intern(&lf[163],19,"\010compilerfold-inner");
lf[164]=C_h_intern(&lf[164],6,"remove");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[169]=C_h_intern(&lf[169],5,"fifth");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_h_intern(&lf[171],13,"\010compilerbomb");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[173]=C_h_intern(&lf[173],34,"\010compilertransform-direct-lambdas!");
lf[174]=C_h_intern(&lf[174],19,"\010compilercopy-node!");
lf[175]=C_h_intern(&lf[175],16,"\004coredirect_call");
lf[176]=C_h_intern(&lf[176],4,"quit");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[178]=C_h_intern(&lf[178],15,"lset-difference");
lf[179]=C_h_intern(&lf[179],15,"node-class-set!");
lf[180]=C_h_intern(&lf[180],12,"\004corerecurse");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[182]=C_h_intern(&lf[182],4,"take");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[185]=C_h_intern(&lf[185],11,"\004corereturn");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[187]=C_h_intern(&lf[187],18,"\004coredirect_lambda");
lf[188]=C_h_intern(&lf[188],6,"cdaddr");
lf[189]=C_h_intern(&lf[189],6,"caaddr");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[192]=C_h_intern(&lf[192],6,"unzip1");
lf[193]=C_h_intern(&lf[193],16,"\003sysmake-promise");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[195]=C_h_intern(&lf[195],5,"boxed");
lf[196]=C_h_intern(&lf[196],15,"\004coreinline_ref");
lf[197]=C_h_intern(&lf[197],37,"\010compilerestimate-foreign-result-size");
lf[198]=C_h_intern(&lf[198],19,"\004coreinline_loc_ref");
lf[199]=C_h_intern(&lf[199],5,"lset=");
lf[200]=C_h_intern(&lf[200],6,"delete");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[202]=C_h_intern(&lf[202],32,"\010compilerperform-lambda-lifting!");
lf[203]=C_h_intern(&lf[203],23,"\003syshash-table-for-each");
lf[204]=C_h_intern(&lf[204],1,"+");
lf[205]=C_h_intern(&lf[205],17,"delete-duplicates");
lf[206]=C_h_intern(&lf[206],14,"\004coreprimitive");
lf[207]=C_h_intern(&lf[207],7,"delete!");
lf[208]=C_h_intern(&lf[208],11,"concatenate");
lf[209]=C_h_intern(&lf[209],5,"count");
lf[210]=C_h_intern(&lf[210],22,"\010compilerblock-globals");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[214]=C_h_intern(&lf[214],12,"pretty-print");
lf[215]=C_h_intern(&lf[215],1,"l");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[226]=C_h_intern(&lf[226],11,"make-vector");
lf[227]=C_h_intern(&lf[227],3,"var");
lf[228]=C_h_intern(&lf[228],2,"d2");
lf[229]=C_h_intern(&lf[229],1,"y");
lf[230]=C_h_intern(&lf[230],2,"d3");
lf[231]=C_h_intern(&lf[231],1,"z");
lf[232]=C_h_intern(&lf[232],2,"d1");
lf[233]=C_h_intern(&lf[233],2,"op");
lf[234]=C_h_intern(&lf[234],5,"clist");
lf[235]=C_h_intern(&lf[235],34,"\010compilermembership-test-operators");
lf[236]=C_h_intern(&lf[236],32,"\010compilermembership-unfold-limit");
lf[237]=C_h_intern(&lf[237],4,"var1");
lf[238]=C_h_intern(&lf[238],4,"var0");
lf[239]=C_h_intern(&lf[239],6,"const1");
lf[240]=C_h_intern(&lf[240],4,"var2");
lf[241]=C_h_intern(&lf[241],6,"const2");
lf[242]=C_h_intern(&lf[242],5,"body2");
lf[243]=C_h_intern(&lf[243],4,"rest");
lf[244]=C_h_intern(&lf[244],5,"body1");
lf[245]=C_h_intern(&lf[245],27,"\010compilereq-inline-operator");
lf[246]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[247]=C_h_intern(&lf[247],19,"\010compilerimmediate\077");
lf[248]=C_h_intern(&lf[248],5,"const");
lf[249]=C_h_intern(&lf[249],1,"n");
lf[250]=C_h_intern(&lf[250],7,"clauses");
lf[251]=C_h_intern(&lf[251],1,"d");
lf[252]=C_h_intern(&lf[252],4,"body");
lf[253]=C_h_intern(&lf[253],4,"more");
lf[254]=C_h_intern(&lf[254],4,"args");
lf[255]=C_h_intern(&lf[255],1,"a");
lf[256]=C_h_intern(&lf[256],1,"b");
lf[257]=C_h_intern(&lf[257],1,"c");
lf[258]=C_h_intern(&lf[258],4,"cdar");
C_register_lf2(lf,259,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1457,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1455 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1458 in k1455 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1461 in k1458 in k1455 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=C_retrieve(lf[0]);
t3=C_mutate((C_word*)lf[1]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1468,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 152  make-vector */
t5=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[53],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1,t1);
t3=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[22]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1674,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[103]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3145,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[115]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3606,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(C_word)C_a_i_list(&a,1,lf[255]);
t9=(C_word)C_a_i_list(&a,2,lf[8],t8);
t10=(C_word)C_a_i_cons(&a,2,lf[256],lf[257]);
t11=(C_word)C_a_i_cons(&a,2,t9,t10);
t12=(C_word)C_a_i_cons(&a,2,lf[251],t11);
t13=(C_word)C_a_i_cons(&a,2,lf[13],t12);
t14=(C_word)C_a_i_list(&a,4,lf[255],lf[256],lf[257],lf[251]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9555,tmp=(C_word)a,a+=2,tmp);
t16=(C_word)C_a_i_list(&a,3,t13,t14,t15);
/* optimizer.scm: 544  register-simplifications */
t17=C_retrieve(lf[115]);
((C_proc4)C_retrieve_proc(t17))(4,t17,t7,lf[13],t16);}

/* a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9555(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_9555,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9563,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 550  ##sys#hash-table-ref */
t8=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t7,C_retrieve(lf[130]),t3);}

/* k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9563,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_9568(t6,((C_word*)t0)[2],t2);}

/* loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_9568(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9568,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9578,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9613,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 552  caar */
t5=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}}

/* k9611 in loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9617,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 552  cdar */
t3=*((C_word*)lf[258]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9615 in k9611 in loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 552  simplify-named-call */
t2=C_retrieve(lf[132]);
((C_proc9)C_retrieve_proc(t2))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9576 in loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9578,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[5],C_retrieve(lf[21]));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9587,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_9587(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9602,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 557  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[5],C_fix(1),C_retrieve(lf[21]));}}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 559  loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_9568(t3,((C_word*)t0)[4],t2);}}

/* k9600 in k9576 in loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[21]+1,t1);
t3=((C_word*)t0)[2];
f_9587(t3,t2);}

/* k9585 in k9576 in loop in k9561 in a9554 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_9587(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word ab[434],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3616,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[237]);
t4=(C_word)C_a_i_list(&a,1,lf[233]);
t5=(C_word)C_a_i_list(&a,1,lf[238]);
t6=(C_word)C_a_i_list(&a,2,lf[8],t5);
t7=(C_word)C_a_i_list(&a,1,lf[239]);
t8=(C_word)C_a_i_list(&a,2,lf[24],t7);
t9=(C_word)C_a_i_list(&a,4,lf[134],t4,t6,t8);
t10=(C_word)C_a_i_list(&a,1,lf[237]);
t11=(C_word)C_a_i_list(&a,2,lf[8],t10);
t12=(C_word)C_a_i_list(&a,1,lf[240]);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[238]);
t15=(C_word)C_a_i_list(&a,2,lf[8],t14);
t16=(C_word)C_a_i_list(&a,1,lf[241]);
t17=(C_word)C_a_i_list(&a,2,lf[24],t16);
t18=(C_word)C_a_i_list(&a,4,lf[134],t13,t15,t17);
t19=(C_word)C_a_i_list(&a,1,lf[240]);
t20=(C_word)C_a_i_list(&a,2,lf[8],t19);
t21=(C_word)C_a_i_list(&a,5,lf[9],lf[228],t20,lf[242],lf[243]);
t22=(C_word)C_a_i_list(&a,4,lf[10],t12,t18,t21);
t23=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t11,lf[244],t22);
t24=(C_word)C_a_i_list(&a,4,lf[10],t3,t9,t23);
t25=(C_word)C_a_i_list(&a,11,lf[238],lf[237],lf[240],lf[233],lf[239],lf[241],lf[244],lf[242],lf[232],lf[228],lf[243]);
t26=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9392,tmp=(C_word)a,a+=2,tmp);
t27=(C_word)C_a_i_list(&a,3,t24,t25,t26);
t28=(C_word)C_a_i_list(&a,1,lf[227]);
t29=(C_word)C_a_i_list(&a,1,lf[233]);
t30=(C_word)C_a_i_list(&a,1,lf[238]);
t31=(C_word)C_a_i_list(&a,2,lf[8],t30);
t32=(C_word)C_a_i_list(&a,1,lf[248]);
t33=(C_word)C_a_i_list(&a,2,lf[24],t32);
t34=(C_word)C_a_i_list(&a,4,lf[134],t29,t31,t33);
t35=(C_word)C_a_i_list(&a,1,lf[227]);
t36=(C_word)C_a_i_list(&a,2,lf[8],t35);
t37=(C_word)C_a_i_list(&a,1,lf[249]);
t38=(C_word)C_a_i_list(&a,1,lf[238]);
t39=(C_word)C_a_i_list(&a,2,lf[8],t38);
t40=(C_word)C_a_i_cons(&a,2,t39,lf[250]);
t41=(C_word)C_a_i_cons(&a,2,t37,t40);
t42=(C_word)C_a_i_cons(&a,2,lf[16],t41);
t43=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t36,lf[252],t42);
t44=(C_word)C_a_i_list(&a,4,lf[10],t28,t34,t43);
t45=(C_word)C_a_i_list(&a,8,lf[227],lf[233],lf[238],lf[248],lf[251],lf[252],lf[249],lf[250]);
t46=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9270,tmp=(C_word)a,a+=2,tmp);
t47=(C_word)C_a_i_list(&a,3,t44,t45,t46);
t48=(C_word)C_a_i_list(&a,1,lf[237]);
t49=(C_word)C_a_i_list(&a,2,lf[66],C_SCHEME_END_OF_LIST);
t50=(C_word)C_a_i_list(&a,4,lf[10],t48,t49,lf[253]);
t51=(C_word)C_a_i_list(&a,2,lf[237],lf[253]);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9002,tmp=(C_word)a,a+=2,tmp);
t53=(C_word)C_a_i_list(&a,3,t50,t51,t52);
t54=(C_word)C_a_i_list(&a,1,lf[227]);
t55=(C_word)C_a_i_list(&a,1,lf[233]);
t56=(C_word)C_a_i_cons(&a,2,t55,lf[254]);
t57=(C_word)C_a_i_cons(&a,2,lf[134],t56);
t58=(C_word)C_a_i_list(&a,1,lf[227]);
t59=(C_word)C_a_i_list(&a,2,lf[8],t58);
t60=(C_word)C_a_i_list(&a,5,lf[9],lf[251],t59,lf[68],lf[229]);
t61=(C_word)C_a_i_list(&a,4,lf[10],t54,t57,t60);
t62=(C_word)C_a_i_list(&a,6,lf[227],lf[233],lf[254],lf[251],lf[68],lf[229]);
t63=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8926,tmp=(C_word)a,a+=2,tmp);
t64=(C_word)C_a_i_list(&a,3,t61,t62,t63);
/* optimizer.scm: 562  register-simplifications */
t65=C_retrieve(lf[115]);
((C_proc7)C_retrieve_proc(t65))(7,t65,t2,lf[10],t27,t47,t53,t64);}

/* a8925 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8926,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8960,a[2]=t1,a[3]=t8,a[4]=t7,a[5]=t5,a[6]=t4,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 697  get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,t2,t3,lf[72]);}}

/* k8958 in a8925 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8960,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=((C_word*)t0)[7];
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[6]);
t6=((C_word*)t0)[5];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,3,t7,((C_word*)t0)[4],((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[9],t4,t8));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9002(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9002,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9012,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_9012(t9,t1,t5,t4);}

/* loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_9012(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_9012,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t3;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t3;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_cdr(t7);
if(C_truep((C_word)C_i_nullp(t11))){
t12=(C_word)C_i_car(t9);
t13=(C_word)C_slot(t12,C_fix(2));
t14=(C_word)C_slot(t12,C_fix(3));
t15=(C_word)C_slot(t12,C_fix(1));
t16=(C_word)C_eqp(t15,lf[66]);
if(C_truep(t16)){
t17=(C_word)C_i_car(t7);
t18=(C_word)C_a_i_cons(&a,2,t17,t2);
t19=(C_word)C_i_cadr(t9);
/* optimizer.scm: 643  loop1 */
t23=t1;
t24=t18;
t25=t19;
t1=t23;
t2=t24;
t3=t25;
goto loop;}
else{
t17=(C_word)C_eqp(t15,lf[14]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9076,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t9,a[5]=t14,a[6]=t13,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 645  reverse */
t19=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t19))(3,t19,t18,t2);}
else{
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_SCHEME_FALSE);}}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9076,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(t1))){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(C_word)C_i_car(t1);
t4=(C_word)C_eqp(t2,t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_i_cdr(t1);
t8=(C_word)C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_9105(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_9105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9105,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=(C_word)C_slot(t5,C_fix(1));
t7=t4;
t8=(C_word)C_slot(t7,C_fix(2));
t9=t4;
t10=(C_word)C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9121,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=(C_word)C_eqp(t6,lf[10]);
if(C_truep(t12)){
t13=(C_word)C_i_cdr(t8);
if(C_truep((C_word)C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9228,a[2]=t10,a[3]=t3,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t8);
/* optimizer.scm: 656  get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t14,((C_word*)t0)[2],t15,lf[72]);}
else{
t14=t11;
f_9121(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_9121(t13,C_SCHEME_FALSE);}}

/* k9226 in loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_9121(t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t2=(C_word)C_i_car(((C_word*)t0)[2]);
t3=(C_word)C_slot(t2,C_fix(1));
t4=(C_word)C_eqp(lf[14],t3);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(C_word)C_i_car(((C_word*)t0)[2]);
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=((C_word*)t0)[4];
f_9121(t9,(C_word)C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_9121(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_9121(t2,C_SCHEME_FALSE);}}}

/* k9119 in loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_9121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9121,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[8]);
t3=(C_word)C_slot(t2,C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(C_word)C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=(C_word)C_i_cdr(((C_word*)t0)[6]);
t7=(C_word)C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm: 660  loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_9105(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep((C_word)C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9158,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9168,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 664  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a9167 in k9119 in loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9168(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9168,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a9157 in k9119 in loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 665  reverse */
t3=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9164 in a9157 in k9119 in loop2 in k9074 in loop1 in a9001 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 665  reorganize-recursive-bindings */
t2=C_retrieve(lf[117]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(c!=11) C_bad_argc_2(c,11,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_9270,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep((C_word)C_i_equalp(t4,C_retrieve(lf[245])))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9283,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 609  immediate? */
t12=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k9281 in a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9283,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 610  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9316 in k9281 in a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9318,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_fixnum_increase(((C_word*)t0)[7]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9295,a[2]=t5,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 614  varnode */
t8=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9300 in k9316 in k9281 in a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 615  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9304 in k9300 in k9316 in k9281 in a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 614  cons* */
t2=C_retrieve(lf[152]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9293 in k9316 in k9281 in a9269 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9295,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[16],((C_word*)t0)[2],t1));}

/* a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9392(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(c!=14) C_bad_argc_2(c,14,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_9392,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep((C_word)C_i_equalp(t6,C_retrieve(lf[245])))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9405,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 582  immediate? */
t15=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9405,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9411,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 583  immediate? */
t3=C_retrieve(lf[247]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9411,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 584  get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9455 in k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9457,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9449,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 585  get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[72]);}
else{
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9447 in k9455 in k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9449,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 589  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k9431 in k9447 in k9455 in k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9437,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 590  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9435 in k9431 in k9447 in k9455 in k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9441,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 592  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k9439 in k9435 in k9431 in k9447 in k9455 in k9409 in k9403 in a9391 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9441,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[16],lf[246],t2));}

/* k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[160],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_a_i_list(&a,1,lf[227]);
t4=(C_word)C_a_i_list(&a,2,lf[8],t3);
t5=(C_word)C_a_i_list(&a,4,lf[13],lf[228],t4,lf[229]);
t6=(C_word)C_a_i_list(&a,1,lf[227]);
t7=(C_word)C_a_i_list(&a,2,lf[8],t6);
t8=(C_word)C_a_i_list(&a,4,lf[13],lf[230],t7,lf[231]);
t9=(C_word)C_a_i_list(&a,5,lf[9],lf[232],lf[68],t5,t8);
t10=(C_word)C_a_i_list(&a,7,lf[232],lf[228],lf[230],lf[68],lf[229],lf[231],lf[227]);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8855,tmp=(C_word)a,a+=2,tmp);
t12=(C_word)C_a_i_list(&a,3,t9,t10,t11);
t13=(C_word)C_a_i_list(&a,1,lf[233]);
t14=(C_word)C_a_i_list(&a,1,lf[234]);
t15=(C_word)C_a_i_list(&a,2,lf[24],t14);
t16=(C_word)C_a_i_list(&a,4,lf[134],t13,lf[68],t15);
t17=(C_word)C_a_i_list(&a,5,lf[9],lf[232],t16,lf[229],lf[231]);
t18=(C_word)C_a_i_list(&a,6,lf[232],lf[233],lf[68],lf[234],lf[229],lf[231]);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8744,tmp=(C_word)a,a+=2,tmp);
t20=(C_word)C_a_i_list(&a,3,t17,t18,t19);
/* optimizer.scm: 704  register-simplifications */
t21=C_retrieve(lf[115]);
((C_proc5)C_retrieve_proc(t21))(5,t21,t2,lf[9],t12,t20);}

/* a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8744(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_8744,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(C_word)C_i_assoc(t4,C_retrieve(lf[235]));
if(C_truep(t9)){
if(C_truep((C_word)C_i_listp(t6))){
t10=(C_word)C_i_length(t6);
t11=C_retrieve(lf[236]);
if(C_truep((C_word)C_fixnum_lessp(t10,t11))){
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8766,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,a[7]=t3,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 735  gensym */
t13=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8766,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[8]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_a_i_list(&a,1,t1);
t5=((C_word*)t0)[7];
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8789,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8791,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8821,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 752  qnode */
t9=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,C_SCHEME_FALSE);}

/* k8819 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 744  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a8790 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8791,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8813,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 749  varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k8811 in a8790 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8813,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 749  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k8815 in k8811 in a8790 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8817,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 750  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k8807 in k8815 in k8811 in a8790 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8809,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2));}

/* k8787 in k8764 in a8743 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[9],((C_word*)t0)[5],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t4));}

/* a8854 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8855(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(c!=10) C_bad_argc_2(c,10,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_8855,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8869,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 720  varnode */
t11=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t11))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k8867 in a8854 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8869,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[15],C_SCHEME_END_OF_LIST,t2);
t4=(C_word)C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t4));}

/* k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3621,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3947,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 847  make-vector */
t4=*((C_word*)lf[226]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3947,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1,t1);
t3=C_mutate((C_word*)lf[131]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3949,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[132]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3969,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[173]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5949,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[202]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7084,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7084(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[44],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7084,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7087,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7187,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7384,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7483,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7727,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7946,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8147,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8397,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8484,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8631,a[2]=t6,a[3]=t7,a[4]=t8,a[5]=t9,a[6]=t10,a[7]=t11,a[8]=t13,a[9]=t14,a[10]=t1,a[11]=t12,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1825 debugging */
t16=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t15,lf[18],lf[225]);}

/* k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1826 find-lifting-candidates */
t3=((C_word*)t0)[2];
f_7087(t3,t2);}

/* k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1827 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[224]);}

/* k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1828 build-call-graph */
t3=((C_word*)t0)[2];
f_7187(t3,t2,((C_word*)t0)[3]);}

/* k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8643,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1829 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[223]);}

/* k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8646,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1830 eliminate */
t3=((C_word*)t0)[4];
f_7384(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8649,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8723,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1831 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[222]);}

/* k8721 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1831 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8649(2,t2,C_SCHEME_UNDEFINED);}}

/* k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1832 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[221]);}

/* k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1833 collect-accessibles */
t3=((C_word*)t0)[2];
f_7483(t3,t2,((C_word*)t0)[3]);}

/* k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8717,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1834 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[220]);}

/* k8715 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1834 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8658(2,t2,C_SCHEME_UNDEFINED);}}

/* k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1835 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[219]);}

/* k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8664,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1836 eliminate4 */
t4=((C_word*)t0)[3];
f_7727(t4,t3,((C_word*)t0)[2]);}

/* k8712 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8714,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7693,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7693(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k8712 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7693(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7693,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7711,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1630 filter */
t6=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,t2);}

/* a7710 in loop in k8712 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7711(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7711,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7717,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(t2);
/* optimizer.scm: 1630 every */
t5=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a7716 in a7710 in loop in k8712 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7717(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7717,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_assq(t2,((C_word*)t0)[2]));}

/* k7695 in loop in k8712 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=(C_word)C_i_length(t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_eqp(t3,t2);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}
else{
/* optimizer.scm: 1634 loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7693(t5,((C_word*)t0)[3],t1,t2);}}

/* k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8704,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8706,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1837 ##sys#make-promise */
t5=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8705 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8706,2,t0,t1);}
/* optimizer.scm: 1837 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k8702 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1837 debugging */
t2=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[5],lf[218],t1);}

/* k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1838 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[217]);}

/* k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1839 compute-extra-variables */
t3=((C_word*)t0)[2];
f_7946(t3,t2,((C_word*)t0)[5]);}

/* k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8697,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1840 debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[215],lf[216]);}

/* k8695 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1840 pretty-print */
t2=C_retrieve(lf[214]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_8676(2,t2,C_SCHEME_UNDEFINED);}}

/* k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1841 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[213]);}

/* k8677 in k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1842 extend-call-sites! */
t3=((C_word*)t0)[2];
f_8397(t3,t2,((C_word*)t0)[4]);}

/* k8680 in k8677 in k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1843 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[212]);}

/* k8683 in k8680 in k8677 in k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1844 remove-local-bindings! */
t3=((C_word*)t0)[2];
f_8484(t3,t2,((C_word*)t0)[4]);}

/* k8686 in k8683 in k8680 in k8677 in k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1845 debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[211]);}

/* k8689 in k8686 in k8683 in k8680 in k8677 in k8674 in k8671 in k8668 in k8665 in k8662 in k8659 in k8656 in k8653 in k8650 in k8647 in k8644 in k8641 in k8638 in k8635 in k8632 in k8629 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1846 reconstruct! */
t2=((C_word*)t0)[5];
f_8147(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_8484(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8484,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8490,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8490(3,t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8490(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[13],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8490,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8509,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=(C_word)C_slot(t11,C_fix(3));
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t10,((C_word*)((C_word*)t0)[2])[1],t12);}
else{
t10=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8602,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=(C_word)C_slot(t12,C_fix(3));
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,((C_word*)((C_word*)t0)[2])[1],t13);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* k8600 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8602,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8611,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1820 node-class-set! */
t4=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],lf[66]);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k8609 in k8600 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8611,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8614,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1821 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8612 in k8609 in k8600 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1822 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8509,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8514,a[2]=((C_word*)t0)[5],a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_8514(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_8514(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8514,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=(C_word)C_i_car(t3);
/* optimizer.scm: 1810 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8537,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8552,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1812 reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8555,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t2);
if(C_truep((C_word)C_i_assq(t5,((C_word*)t0)[2]))){
t6=t4;
f_8555(t6,C_SCHEME_UNDEFINED);}
else{
t6=(C_word)C_i_car(t2);
t7=(C_word)C_a_i_cons(&a,2,t6,((C_word*)((C_word*)t0)[6])[1]);
t8=C_mutate(((C_word *)((C_word*)t0)[6])+1,t7);
t9=(C_word)C_i_car(t3);
t10=(C_word)C_a_i_cons(&a,2,t9,((C_word*)((C_word*)t0)[4])[1]);
t11=C_mutate(((C_word *)((C_word*)t0)[4])+1,t10);
t12=t4;
f_8555(t12,t11);}}}

/* k8553 in do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_8555(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_8514(t4,((C_word*)t0)[2],t2,t3);}

/* k8550 in do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1812 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8535 in do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8544,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8548,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1813 reverse */
t4=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k8546 in k8535 in do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1813 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k8542 in k8535 in do1385 in k8507 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1813 node-subexpressions-set! */
t2=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_8397(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8397,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8403,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_8403(3,t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8403(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8403,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8425,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_slot(t10,C_fix(1));
t13=(C_word)C_eqp(lf[8],t12);
if(C_truep(t13)){
t14=(C_word)C_slot(t10,C_fix(2));
t15=(C_word)C_i_car(t14);
t16=(C_word)C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=(C_word)C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8455,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8459,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t20=(C_word)C_i_cdr(t16);
/* map */
t21=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t19,C_retrieve(lf[46]),t20);}
else{
t17=t11;
f_8425(2,t17,C_SCHEME_UNDEFINED);}}
else{
t14=t11;
f_8425(2,t14,C_SCHEME_UNDEFINED);}}
else{
/* for-each */
t10=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}

/* k8457 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1792 append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k8453 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8455,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 1790 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8423 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=(C_word)C_slot(t2,C_fix(3));
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t3);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_8147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8147,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8159,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8161,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
/* optimizer.scm: 1726 fold-right */
t9=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t4,t5,t8,t2);}

/* a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8161(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8161,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8168,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1729 get */
t6=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,((C_word*)t0)[2],t4,lf[44]);}

/* k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8168,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],C_retrieve(lf[210]));
t3=C_mutate((C_word*)lf[210]+1,t2);
t4=(C_word)C_slot(t1,C_fix(2));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8181,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1731 decompose-lambda-list */
t7=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[2],t5,t6);}

/* a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8181(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8181,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=(C_word)C_i_cdr(t5);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8188,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_retrieve(lf[78]),t6);}

/* k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8191,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1736 map */
t3=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[129]+1),((C_word*)t0)[5],t1);}

/* k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8194,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8272,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8287,a[2]=t5,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_8287(3,t9,t2,t4);}

/* walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[28],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8287,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8306,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8313,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
/* map */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],t6);}
else{
t10=(C_word)C_eqp(t4,lf[8]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8330,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=(C_word)C_i_car(t6);
/* optimizer.scm: 1765 rename */
t13=((C_word*)t0)[2];
f_8272(3,t13,t11,t12);}
else{
t11=(C_word)C_eqp(t4,lf[14]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8343,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8354,a[2]=t2,a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 1767 rename */
t15=((C_word*)t0)[2];
f_8272(3,t15,t13,t14);}
else{
t12=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8373,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1770 decompose-lambda-list */
t15=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t15))(4,t15,t1,t13,t14);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t8);}}}}}

/* a8372 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8373(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8373,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8388,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8392,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],t2);}

/* k8390 in a8372 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1773 build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8386 in a8372 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_set_car(((C_word*)t0)[5],t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1774 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8287(3,t4,((C_word*)t0)[2],t3);}

/* k8352 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8354,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1767 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8341 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k8328 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8330,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1765 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k8311 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1762 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8304 in walk in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* rename in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8272(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8272,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?(C_word)C_i_cdr(t3):t2));}

/* k8192 in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8194,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8243,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1739 gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}

/* k8241 in k8192 in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8243,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8227,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8231,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1745 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8229 in k8241 in k8192 in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_fixnum_plus(((C_word*)t0)[4],t2);
/* optimizer.scm: 1745 build-lambda-list */
t4=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t4))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k8225 in k8241 in k8192 in k8189 in k8186 in a8180 in k8166 in a8160 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8227,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_slot(((C_word*)t0)[6],C_fix(3));
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[11],t2,t3);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[5],t5);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[4]);
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t7));}

/* k8157 in reconstruct! in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8159,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1723 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7946,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8011,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8133,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t2);}

/* a8132 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8133,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cadr(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_cons(&a,2,t3,t4));}

/* k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8011,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8013,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8088,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t5)[1],((C_word*)t0)[4]);}

/* k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8093,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8093,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8131,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1712 get */
t5=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[2],t3,lf[44]);}

/* k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8131,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7955,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7955(3,t8,t4,t1);}

/* walk in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7955,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_eqp(t4,lf[10]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7975,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1688 append */
t11=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=(C_word)C_eqp(t4,lf[11]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7993,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1691 decompose-lambda-list */
t13=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t13))(4,t13,t1,t11,t12);}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* a7992 in walk in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7993(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7993,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7998,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1694 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k7996 in a7992 in walk in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 1695 walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7955(3,t4,((C_word*)t0)[2],t3);}

/* k7973 in walk in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}

/* k7951 in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7953,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8109,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8123,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 1718 delete-duplicates */
t7=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,*((C_word*)lf[33]+1));}

/* k8121 in k7951 in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1714 remove */
t2=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8108 in k7951 in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8109(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8109,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:(C_word)C_i_memq(t2,((C_word*)t0)[2])));}

/* k8105 in k7951 in k8129 in a8092 in k8086 in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8107,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8013(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8013,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8081,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1703 count */
t6=C_retrieve(lf[209]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a8080 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8081,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_eqp(((C_word*)t0)[2],t2));}

/* k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8079,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greaterp(t1,C_fix(1)))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8033,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t7=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t4);}}

/* a8066 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8067,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm: 1706 walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8013(3,t4,t1,t3);}

/* k8031 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8033,2,t0,t1);}
t2=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8043,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8051,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8055,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* map */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a8056 in k8031 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8057,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k8053 in k8031 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1708 concatenate */
t2=C_retrieve(lf[208]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k8049 in k8031 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1708 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8041 in k8031 in k8077 in walk in k8009 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_8043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7727(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7727,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7731,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7733,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_7733(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7733(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7733,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7752,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_7752(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7752(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7752(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7752(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7752,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[7],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7763,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7763(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[7],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7814,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1653 decompose-lambda-list */
t6=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t6))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=(C_word)C_eqp(((C_word*)t0)[7],lf[13]);
if(C_truep(t4)){
t5=(C_word)C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7838,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7849,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1659 call-with-current-continuation */
t8=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7919,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t5,((C_word*)t0)[3]);}}}}}

/* a7918 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7919,3,t0,t1,t2);}
/* optimizer.scm: 1674 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7733(t3,t1,t2,((C_word*)t0)[2]);}

/* a7848 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7849(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7849,3,t0,t1,t2);}
t3=(C_word)C_slot(((C_word*)t0)[4],C_fix(1));
t4=(C_word)C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(C_word)C_slot(((C_word*)t0)[4],C_fix(2));
t8=(C_word)C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7865,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_7865(3,t12,t1,t8);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}}

/* loop in a7848 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7865(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7865,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7885,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7895,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=(C_word)C_i_cadr(t5);
/* optimizer.scm: 1668 lset<= */
t9=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,*((C_word*)lf[33]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k7893 in loop in a7848 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7895,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_7885(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1670 delete! */
t3=C_retrieve(lf[207]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[33]+1));}}

/* k7897 in k7893 in loop in a7848 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm: 1671 return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7883 in loop in a7848 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k7836 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7843,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7842 in k7836 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7843(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7843,3,t0,t1,t2);}
/* optimizer.scm: 1673 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7733(t3,t1,t2,((C_word*)t0)[2]);}

/* a7813 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7814(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7814,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7826,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1656 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7824 in a7813 in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1656 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7733(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7763(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7763,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7781,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1648 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7784,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1650 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7733(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7782 in loop in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1651 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7763(t4,((C_word*)t0)[2],t2,t3);}

/* k7779 in loop in k7750 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1648 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7733(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7729 in eliminate4 in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7483(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7483,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7487,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7489,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_7489(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7489(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7489,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_7508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_7508(t12,t10);}
else{
t12=(C_word)C_eqp(t5,lf[24]);
if(C_truep(t12)){
t13=t11;
f_7508(t13,t12);}
else{
t13=(C_word)C_eqp(t5,lf[66]);
if(C_truep(t13)){
t14=t11;
f_7508(t14,t13);}
else{
t14=(C_word)C_eqp(t5,lf[206]);
t15=t11;
f_7508(t15,(C_truep(t14)?t14:(C_word)C_eqp(t5,lf[154])));}}}}

/* k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7508(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7508,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[10],lf[10]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7519,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_7519(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[10],lf[11]);
if(C_truep(t3)){
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7567,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=(C_word)C_i_cdr(t4);
if(C_truep((C_word)C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7601,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(C_word)C_i_cdr(t4);
/* optimizer.scm: 1605 alist-cons */
t9=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t9))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=t5;
f_7567(t7,C_SCHEME_UNDEFINED);}}
else{
t6=t5;
f_7567(t6,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7610,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[11],t4,((C_word*)t0)[6]);}}}}

/* a7609 in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7610,3,t0,t1,t2);}
/* optimizer.scm: 1611 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7489(t3,t1,t2,((C_word*)t0)[2]);}

/* k7599 in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_7567(t3,t2);}

/* k7565 in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7567(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7567,NULL,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7576,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1606 decompose-lambda-list */
t4=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a7575 in k7565 in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7576(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7576,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7588,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1609 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7586 in a7575 in k7565 in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1609 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7489(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7519(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7519,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7537,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1596 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7540,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 1598 walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_7489(t6,t4,t5,((C_word*)t0)[3]);}}

/* k7538 in loop in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1599 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7519(t4,((C_word*)t0)[2],t2,t3);}

/* k7535 in loop in k7506 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1596 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7489(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7485 in collect-accessibles in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7384(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7384,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7390,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1566 remove */
t5=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t4,t3);}

/* a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7390(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7390,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7424,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7434,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1576 unzip1 */
t7=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t5);}

/* k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7434,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7439,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_7439(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7439(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7439,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7446,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cddr(t4);
/* optimizer.scm: 1579 lset-difference */
t7=C_retrieve(lf[178]);
((C_proc6)C_retrieve_proc(t7))(6,t7,t5,*((C_word*)lf[33]+1),t6,t3,((C_word*)t0)[2]);}

/* k7444 in count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7473,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1580 delete-duplicates */
t4=C_retrieve(lf[205]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,*((C_word*)lf[33]+1));}

/* k7471 in k7444 in count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7473,2,t0,t1);}
t2=(C_word)C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7469,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1581 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7467 in k7471 in k7444 in count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7469,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7461,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a7460 in k7467 in k7471 in k7444 in count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7461(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7461,3,t0,t1,t2);}
/* optimizer.scm: 1582 count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7439(t3,t1,t2,((C_word*)t0)[2]);}

/* k7457 in k7467 in k7471 in k7444 in count in k7432 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1582 fold */
t2=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k7422 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7424,2,t0,t1);}
t2=(C_word)C_fixnum_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1569 any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a7401 in k7422 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7402,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7409,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1570 get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],t2,lf[71]);}

/* k7407 in a7401 in k7422 in a7389 in eliminate in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7187(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7187,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7190,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7339,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7341,a[2]=t10,a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t14=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,t2);}

/* a7340 in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7341(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7341,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_slot(t4,C_fix(2));
t6=(C_word)C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7356,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7366,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1555 decompose-lambda-list */
t11=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t6,t10);}

/* a7365 in a7340 in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7366(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7366,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t6=(C_word)C_i_car(t5);
/* optimizer.scm: 1558 walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_7190(t7,t1,t6,t2);}

/* k7354 in a7340 in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7360,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm: 1559 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k7358 in k7354 in a7340 in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7337 in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7190(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7190,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=(C_word)C_eqp(t5,lf[8]);
t11=(C_truep(t10)?t10:(C_word)C_eqp(t5,lf[14]));
if(C_truep(t11)){
t12=(C_word)C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7215,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=(C_word)C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7240,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_7240(2,t16,t14);}
else{
/* optimizer.scm: 1531 get */
t16=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t16))(5,t16,t15,((C_word*)t0)[2],t12,lf[93]);}}
else{
t12=(C_word)C_eqp(t5,lf[10]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7258,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_7258(t16,t1,t7,t9);}
else{
t13=(C_word)C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7312,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1543 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7329,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t9);}}}}

/* a7328 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7329,3,t0,t1,t2);}
/* optimizer.scm: 1546 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7190(t3,t1,t2,((C_word*)t0)[2]);}

/* a7311 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7312(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7312,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7324,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1545 append */
t7=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k7322 in a7311 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1545 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7190(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7258(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7258,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
t4=(C_word)C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7276,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1538 append */
t6=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7282,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_car(t3);
/* optimizer.scm: 1540 walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_7190(t7,t5,t6,((C_word*)t0)[3]);}}

/* k7280 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
t3=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1541 loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7258(t4,((C_word*)t0)[2],t2,t3);}

/* k7274 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1538 walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_7190(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7238 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7240,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_7215(t2,C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_7215(t4,t3);}}

/* k7213 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7215(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7215,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7218,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_7218(t5,t4);}
else{
t3=t2;
f_7218(t3,C_SCHEME_UNDEFINED);}}

/* k7216 in k7213 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7218(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7218,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a7222 in k7216 in k7213 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7223,3,t0,t1,t2);}
/* optimizer.scm: 1534 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7190(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7087(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7087,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7091,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7093,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1502 ##sys#hash-table-for-each */
t6=C_retrieve(lf[203]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7092 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7093(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7093,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(lf[44],t3);
if(C_truep(t4)){
t5=(C_word)C_i_assq(lf[72],t3);
if(C_truep(t5)){
t6=(C_word)C_i_assq(lf[109],t3);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t5);
t8=(C_word)C_i_length(t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7124,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep((C_word)C_i_assq(lf[73],t3))){
t10=t9;
f_7124(t10,C_SCHEME_FALSE);}
else{
t10=(C_word)C_i_cdr(t4);
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(lf[11],t11);
if(C_truep(t12)){
if(C_truep((C_word)C_i_assq(lf[93],t3))){
t13=t9;
f_7124(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_cdr(t6);
t14=(C_word)C_i_length(t13);
t15=t9;
f_7124(t15,(C_word)C_eqp(t8,t14));}}
else{
t13=t9;
f_7124(t13,C_SCHEME_FALSE);}}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k7122 in a7092 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_7124(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7124,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1513 alist-cons */
t4=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k7126 in k7122 in a7092 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7128,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1514 alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k7130 in k7126 in k7122 in a7092 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k7089 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[35],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5949,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6533,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6114,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5952,a[2]=t3,a[3]=t13,a[4]=t15,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t12,tmp=(C_word)a,a+=9,tmp));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7079,a[2]=t2,a[3]=t15,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1481 debugging */
t18=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t17,lf[18],lf[201]);}

/* k7077 in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7082,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1482 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5952(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k7080 in k7077 in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_5952(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word *a;
loop:
a=C_alloc(30);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5952,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t3;
t8=(C_word)C_slot(t7,C_fix(3));
t9=t3;
t10=(C_word)C_slot(t9,C_fix(1));
t11=(C_word)C_eqp(t10,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5977,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep((C_word)C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6062,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1275 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[2],t2,lf[73]);}
else{
t14=t13;
f_5977(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_5977(2,t14,C_SCHEME_FALSE);}}
else{
t12=(C_word)C_eqp(t10,lf[14]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t6);
t14=(C_word)C_i_car(t8);
/* optimizer.scm: 1285 walk */
t24=t1;
t25=t13;
t26=t14;
t27=C_SCHEME_FALSE;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t13=(C_word)C_eqp(t10,lf[10]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6088,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=(C_word)C_i_car(t6);
t16=(C_word)C_i_car(t8);
/* optimizer.scm: 1287 walk */
t24=t14;
t25=t15;
t26=t16;
t27=t3;
t1=t24;
t2=t25;
t3=t26;
t4=t27;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6108,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t15=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t14,t8);}}}}

/* a6107 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6108,3,t0,t1,t2);}
/* optimizer.scm: 1289 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5952(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6086 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 1288 walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5952(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k6060 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6062,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_5977(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep((C_word)C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6008,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1277 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[44]);}
else{
t2=((C_word*)t0)[9];
f_5977(2,t2,C_SCHEME_FALSE);}}}

/* k6006 in k6060 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6008,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1278 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[72]);}
else{
t2=((C_word*)t0)[4];
f_5977(2,t2,C_SCHEME_FALSE);}}

/* k6012 in k6006 in k6060 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6014,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm: 1279 get */
t3=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[109]);}
else{
t2=((C_word*)t0)[4];
f_5977(2,t2,C_SCHEME_FALSE);}}

/* k6018 in k6012 in k6006 in k6060 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6020,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=(C_word)C_i_length(((C_word*)t0)[8]);
t4=(C_word)C_i_length(t1);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[7]);
t7=(C_word)C_i_car(((C_word*)t0)[6]);
t8=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm: 1282 scan */
t9=((C_word*)t0)[4];
f_6114(t9,((C_word*)t0)[3],t6,t7,((C_word*)t0)[5],((C_word*)t0)[2],t8);}
else{
t6=((C_word*)t0)[3];
f_5977(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_5977(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_5977(2,t2,C_SCHEME_FALSE);}}

/* k5975 in walk in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 1283 transform */
t2=((C_word*)t0)[11];
f_6533(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 1284 walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5952(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6114(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6114,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6117,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6524,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1368 rec */
t18=((C_word*)t12)[1];
f_6117(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k6522 in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6524,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6531,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1369 delete */
t3=C_retrieve(lf[200]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6529 in k6522 in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1369 lset= */
t2=C_retrieve(lf[199]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],*((C_word*)lf[33]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6117(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(68);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6117,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(3));
t10=t2;
t11=(C_word)C_slot(t10,C_fix(1));
t12=(C_word)C_eqp(t11,lf[8]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6166,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1300 get */
t15=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t15))(5,t15,t14,((C_word*)t0)[9],t13,lf[195]);}
else{
t13=(C_word)C_eqp(t11,lf[52]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=(C_word)C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6184,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1308 decompose-lambda-list */
t16=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t16))(4,t16,t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=(C_word)C_eqp(t11,lf[83]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=(C_word)C_i_cadr(t7);
t17=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6221,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1317 every */
t20=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t20))(4,t20,t1,t19,t9);}}
else{
t15=(C_word)C_eqp(t11,lf[187]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6255,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=(C_word)C_i_car(t9);
/* optimizer.scm: 1320 scan-used-variables */
t18=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t18))(4,t18,t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=(C_word)C_eqp(t11,lf[196]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=(C_word)C_i_cadr(t7);
/* optimizer.scm: 1325 estimate-foreign-result-size */
t19=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t19))(3,t19,t17,t18);}
else{
t17=(C_word)C_eqp(t11,lf[198]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6312,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=(C_word)C_i_car(t7);
/* optimizer.scm: 1333 estimate-foreign-result-size */
t20=C_retrieve(lf[197]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t18,t19);}
else{
t18=(C_word)C_eqp(t11,lf[13]);
if(C_truep(t18)){
t19=(C_word)C_i_car(t9);
t20=(C_word)C_slot(t19,C_fix(1));
t21=(C_word)C_eqp(lf[8],t20);
if(C_truep(t21)){
t22=(C_word)C_slot(t19,C_fix(2));
t23=(C_word)C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6365,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=(C_word)C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
t26=(C_word)C_eqp(((C_word*)((C_word*)t0)[10])[1],C_fix(0));
if(C_truep(t26)){
t27=(C_word)C_i_cadr(t9);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6393,a[2]=t24,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t29=(C_word)C_slot(t27,C_fix(1));
t30=(C_word)C_eqp(lf[8],t29);
if(C_truep(t30)){
t31=(C_word)C_slot(t27,C_fix(2));
t32=(C_word)C_i_car(t31);
t33=(C_word)C_a_i_cons(&a,2,t32,((C_word*)((C_word*)t0)[3])[1]);
t34=C_mutate(((C_word *)((C_word*)t0)[3])+1,t33);
t35=t28;
f_6393(t35,t34);}
else{
t31=t28;
f_6393(t31,C_SCHEME_UNDEFINED);}}
else{
t27=t24;
f_6365(t27,C_SCHEME_FALSE);}}
else{
t26=t24;
f_6365(t26,(C_word)C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=(C_word)C_eqp(t11,lf[175]);
if(C_truep(t19)){
t20=(C_word)C_i_cadddr(t7);
t21=(C_word)C_eqp(t20,C_fix(0));
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6454,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1359 every */
t26=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t26))(4,t26,t1,t25,t9);}}}
else{
t20=(C_word)C_eqp(t11,lf[14]);
if(C_truep(t20)){
t21=(C_word)C_i_car(t9);
t22=(C_word)C_i_car(t7);
/* optimizer.scm: 1360 rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=(C_word)C_eqp(t11,lf[10]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6487,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=(C_word)C_i_car(t9);
t24=(C_word)C_i_car(t7);
/* optimizer.scm: 1362 rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6511,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1364 every */
t23=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t23))(4,t23,t1,t22,t9);}}}}}}}}}}}

/* a6510 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6511,3,t0,t1,t2);}
/* optimizer.scm: 1364 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6485 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6487,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6498,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1363 append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6496 in k6485 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1363 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6117(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a6453 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6454(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6454,3,t0,t1,t2);}
/* optimizer.scm: 1359 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6391 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[2];
f_6365(t3,C_SCHEME_TRUE);}

/* k6363 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6365,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6370,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1352 every */
t4=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6369 in k6363 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6370,3,t0,t1,t2);}
/* optimizer.scm: 1352 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6310 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6312,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6318,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6318(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6318(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6318(t7,C_SCHEME_TRUE);}}}

/* k6316 in k6310 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6318(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6318,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6323,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1339 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6322 in k6316 in k6310 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6323(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6323,3,t0,t1,t2);}
/* optimizer.scm: 1339 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6269 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(C_word)C_eqp(t1,C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_6277(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_6277(t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_6277(t7,C_SCHEME_TRUE);}}}

/* k6275 in k6269 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6277,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6282,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1331 every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a6281 in k6275 in k6269 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6282,3,t0,t1,t2);}
/* optimizer.scm: 1331 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k6253 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6255,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1322 alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6249 in k6253 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a6220 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6221(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6221,3,t0,t1,t2);}
/* optimizer.scm: 1317 rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_6117(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a6183 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6184,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6200,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1312 append */
t9=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k6198 in a6183 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1312 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6117(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k6164 in rec in scan in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(C_word)C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6533(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6533,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6537,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7067,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7069,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1373 ##sys#make-promise */
t11=*((C_word*)lf[193]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm: 1374 debugging */
t9=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t9))(6,t9,t8,lf[5],lf[194],t3,t7);}}

/* a7068 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7069,2,t0,t1);}
/* optimizer.scm: 1373 unzip1 */
t2=C_retrieve(lf[192]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k7065 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1373 debugging */
t2=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],lf[5],lf[191],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6537,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=(C_word)C_slot(t3,C_fix(2));
t5=(C_word)C_i_caddr(t4);
t6=(C_word)C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6547,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 1379 get */
t10=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t10))(5,t10,t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[109]);}

/* k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6547,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6553,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[11]))){
t5=(C_word)C_i_cdr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t5))){
t6=(C_word)C_i_cddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t6))){
t7=(C_word)C_i_caddr(((C_word*)t0)[11]);
if(C_truep((C_word)C_i_pairp(t7))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7041,a[2]=t4,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
/* cdaddr */
t9=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,((C_word*)t0)[11]);}
else{
t8=t4;
f_6553(t8,C_SCHEME_FALSE);}}
else{
t7=t4;
f_6553(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_6553(t6,C_SCHEME_FALSE);}}
else{
t5=t4;
f_6553(t5,C_SCHEME_FALSE);}}

/* k7039 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_7041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep((C_word)C_i_listp(t1))){
t2=(C_word)C_i_cdddr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_pairp(t2))){
t3=(C_word)C_i_cddddr(((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
f_6553(t4,(C_word)C_i_nullp(t3));}
else{
t3=((C_word*)t0)[2];
f_6553(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
f_6553(t2,C_SCHEME_FALSE);}}

/* k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_6553(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6553,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6559,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* caaddr */
t4=*((C_word*)lf[189]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[13]);}
else{
/* ##compiler#bomb */
t2=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[10],lf[190],((C_word*)t0)[13]);}}

/* k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_6562,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* cdaddr */
t3=*((C_word*)lf[188]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[14]);}

/* k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6562,2,t0,t1);}
t2=(C_word)C_i_cddr(((C_word*)t0)[15]);
t3=(C_word)C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm: 1386 node-class-set! */
t5=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],lf[187]);}

/* k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6571,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6744,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_6744(3,t9,t2,t5);}

/* rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6744(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[25],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6744,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(2));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(3));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=(C_word)C_i_cadr(t6);
t12=(C_word)C_slot(t10,C_fix(2));
t13=(C_word)C_slot(t11,C_fix(2));
t14=(C_word)C_slot(t10,C_fix(1));
t15=(C_word)C_eqp(lf[8],t14);
if(C_truep(t15)){
t16=(C_word)C_i_car(t12);
t17=(C_word)C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm: 1400 alist-cons */
t19=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t19))(5,t19,t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=(C_word)C_i_car(t12);
t19=(C_word)C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6919,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1425 node-class-set! */
t21=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t21))(4,t21,t20,t2,lf[185]);}
else{
/* optimizer.scm: 1428 bomb */
t20=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t20))(3,t20,t1,lf[186]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t4);
t12=(C_word)C_i_car(t6);
if(C_truep((C_word)C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6966,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1433 alist-cons */
t14=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t14))(5,t14,t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* for-each */
t13=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}
else{
/* for-each */
t11=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,((C_word*)((C_word*)t0)[3])[1],t6);}}}

/* k6964 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6966,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1434 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k6967 in k6964 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1435 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6744(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6917 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1426 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6920 in k6917 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 1427 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6788,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=(C_word)C_i_car(((C_word*)t0)[11]);
t4=(C_word)C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6797,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_i_cdr(((C_word*)t0)[9]);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[5],t7);
if(C_truep(t8)){
t9=t5;
f_6797(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1403 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[181],((C_word*)t0)[4]);}}
else{
t5=(C_word)C_i_car(((C_word*)t0)[11]);
t6=(C_word)C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(C_word)C_i_cdr(t6);
t8=(C_word)C_slot(t7,C_fix(3));
t9=(C_word)C_i_car(t8);
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6843,a[2]=t7,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=t9,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
t11=(C_word)C_i_cdr(((C_word*)t0)[9]);
t12=(C_word)C_i_length(t11);
t13=(C_word)C_eqp(((C_word*)t0)[5],t12);
if(C_truep(t13)){
t14=t10;
f_6843(2,t14,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1414 quit */
t14=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t14))(4,t14,t10,lf[183],((C_word*)t0)[4]);}}
else{
/* optimizer.scm: 1423 bomb */
t7=C_retrieve(lf[171]);
((C_proc4)C_retrieve_proc(t7))(4,t7,((C_word*)t0)[8],lf[184],((C_word*)t0)[11]);}}}

/* k6841 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6846,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1417 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[10]);}

/* k6844 in k6841 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6849,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6873,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[2],C_fix(2));
t5=(C_word)C_i_caddr(t4);
/* optimizer.scm: 1418 take */
t6=C_retrieve(lf[182]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t5,C_fix(1));}

/* k6871 in k6844 in k6841 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1418 node-parameters-set! */
t2=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6847 in k6844 in k6841 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6852,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[180],t3,t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 1419 node-subexpressions-set! */
t7=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[2],t6);}

/* k6850 in k6847 in k6844 in k6841 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1422 rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_6744(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6795 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1406 node-class-set! */
t3=C_retrieve(lf[179]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[3],lf[180]);}

/* k6798 in k6795 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm: 1407 node-parameters-set! */
t4=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k6801 in k6798 in k6795 in k6786 in rec in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 1408 node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6574,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6724,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6726,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1456 lset-difference */
t6=C_retrieve(lf[178]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a6725 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6726(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6726,4,t0,t1,t2,t3);}
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_eqp(t4,t5));}

/* k6722 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a6666 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6667,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6677,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_cdr(t4);
t7=(C_word)C_i_length(t6);
t8=(C_word)C_eqp(((C_word*)t0)[3],t7);
if(C_truep(t8)){
t9=t5;
f_6677(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm: 1446 quit */
t9=C_retrieve(lf[176]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t5,lf[177],((C_word*)t0)[2]);}}

/* k6675 in a6666 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6677,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(C_word)C_i_cddr(((C_word*)t0)[6]);
t6=(C_word)C_a_i_cons(&a,2,t4,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[175],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t2,t7);
/* optimizer.scm: 1449 node-subexpressions-set! */
t9=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t9))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6574,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?(C_word)C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(C_word)C_a_i_record(&a,4,lf[34],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6586,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 1461 copy-node! */
t5=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6589,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6625,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm: 1463 fold-right */
t4=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a6624 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6625,4,t0,t1,t2,t3);}
t4=(C_word)C_i_car(t2);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_slot(t6,C_fix(3));
t8=(C_word)C_i_car(t7);
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_slot(t8,C_fix(2));
t11=(C_word)C_slot(t8,C_fix(3));
t12=(C_word)C_a_i_record(&a,4,lf[34],t9,t10,t11);
t13=(C_word)C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t13));}

/* k6587 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6592,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1472 copy-node! */
t3=C_retrieve(lf[174]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6590 in k6587 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6597,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a6596 in k6590 in k6587 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6597,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6604,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6623,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1476 gensym */
t6=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}

/* k6621 in a6596 in k6590 in k6587 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6623,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1476 node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6602 in a6596 in k6590 in k6587 in k6584 in k6572 in k6569 in k6566 in k6560 in k6557 in k6551 in k6545 in k6535 in transform in ##compiler#transform-direct-lambdas! in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6604,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(3));
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_car(t2,t3));}

/* ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3969(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word ab[182],*a=ab;
if(c!=9) C_bad_argc_2(c,9,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_3969,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
switch(t6){
case C_fix(1):
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4026,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 865  test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);
case C_fix(2):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4134,a[2]=t4,a[3]=t9,a[4]=t2,a[5]=t1,a[6]=t5,a[7]=t8,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 883  test */
t14=t9;
f_3972(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4238,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 901  test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep(C_retrieve(lf[137]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(2),t10);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4282,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 909  test */
t13=t9;
f_3972(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4338,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 921  test */
t11=t9;
f_3972(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(6):
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_eqp(C_fix(1),t12);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4431,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 937  test */
t15=t9;
f_3972(t15,t14,t4,lf[43]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(7):
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
if(C_truep(C_retrieve(lf[133]))){
t12=(C_word)C_i_length(t8);
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t12,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4496,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 949  test */
t16=t9;
f_3972(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4557,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t2,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 959  test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4584,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 967  test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4728,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 994  test */
t13=t9;
f_3972(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_caddr(t7);
t11=(C_truep(t10)?t10:C_retrieve(lf[137]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4815,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1011 test */
t13=t9;
f_3972(t13,t12,t4,lf[43]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4880,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1024 test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4956,a[2]=t4,a[3]=t9,a[4]=t3,a[5]=t8,a[6]=t5,a[7]=t1,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1037 test */
t11=t9;
f_3972(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_cadr(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5021,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1048 test */
t14=t9;
f_3972(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_eqp(C_fix(1),t10);
if(C_truep(t11)){
t12=C_retrieve(lf[137]);
t13=(C_truep(t12)?t12:(C_word)C_i_cadddr(t7));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5104,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t5,a[6]=t1,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1066 test */
t15=t9;
f_3972(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(16):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_not(t10);
t14=(C_truep(t13)?t13:(C_word)C_eqp(t11,t10));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5197,a[2]=t4,a[3]=t9,a[4]=t11,a[5]=t12,a[6]=t1,a[7]=t5,a[8]=t8,a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 1087 test */
t16=t9;
f_3972(t16,t15,t4,lf[42]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(C_retrieve(lf[133]))){
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_car(t7);
t12=(C_word)C_eqp(t10,t11);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5276,a[2]=t4,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1104 test */
t14=t9;
f_3972(t14,t13,t4,lf[42]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(C_retrieve(lf[133]))){
if(C_truep((C_word)C_i_nullp(t8))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5344,a[2]=t4,a[3]=t9,a[4]=t7,a[5]=t1,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1118 test */
t11=t9;
f_3972(t11,t10,t4,lf[42]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5379,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1128 test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(20):
t10=(C_word)C_i_length(t8);
t11=(C_word)C_i_cadddr(t7);
t12=(C_truep(t11)?t11:C_retrieve(lf[137]));
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_i_car(t7);
t14=(C_word)C_eqp(t10,t13);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5527,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t10,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1157 test */
t16=t9;
f_3972(t16,t15,t4,lf[43]);}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5600,a[2]=t4,a[3]=t9,a[4]=t8,a[5]=t1,a[6]=t5,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1175 test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
case C_fix(22):
t10=(C_word)C_i_car(t7);
t11=(C_word)C_i_length(t8);
t12=(C_word)C_i_cadddr(t7);
if(C_truep(C_retrieve(lf[133]))){
t13=(C_word)C_eqp(t11,t10);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5754,a[2]=t4,a[3]=t9,a[4]=t12,a[5]=t8,a[6]=t1,a[7]=t5,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 1209 test */
t15=t9;
f_3972(t15,t14,t4,lf[42]);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(C_retrieve(lf[133]))){
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5817,a[2]=t4,a[3]=t9,a[4]=t5,a[5]=t1,a[6]=t8,a[7]=t7,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 1230 test */
t11=t9;
f_3972(t11,t10,t4,lf[43]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}
default:
/* optimizer.scm: 1250 bomb */
t10=C_retrieve(lf[171]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t1,lf[172]);}}

/* k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5820(2,t3,t1);}
else{
/* optimizer.scm: 1230 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_length(((C_word*)t0)[4]);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,t4))){
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
t6=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5835,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5842,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1236 varnode */
t10=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t10))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5842,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1238 ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5854(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5854,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5862,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_5868(t9,t4,t3,t5);}

/* loop in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_5868(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(13);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5868,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_nullp(t2))){
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5888,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_car(t3);
if(C_truep((C_word)C_i_symbolp(t5))){
/* optimizer.scm: 856  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3994,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_pairp(t5))){
t7=(C_word)C_i_car(t5);
t8=t6;
f_3994(t8,(C_word)C_eqp(lf[24],t7));}
else{
t7=t6;
f_3994(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep((C_word)C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(C_word)C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5917,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
t7=(C_word)C_i_cdr(t3);
/* optimizer.scm: 1248 loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k5915 in loop in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5917,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3992 in loop in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm: 857  qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
/* optimizer.scm: 858  qnode */
t2=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k5886 in loop in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5888,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5892,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 1246 loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5868(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k5890 in k5886 in loop in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5892,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5860 in a5853 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1239 append */
t2=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a5847 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5848,2,t0,t1);}
/* optimizer.scm: 1238 split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5844 in k5840 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1235 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5833 in k5818 in k5815 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5835,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5752 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5757,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5757(2,t3,t1);}
else{
/* optimizer.scm: 1209 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5755 in k5752 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5757,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5776,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5789,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1217 fifth */
t7=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[6]);}
else{
t6=(C_word)C_i_cadr(((C_word*)t0)[6]);
t7=(C_word)C_a_i_list(&a,2,t6,((C_word*)t0)[2]);
t8=((C_word*)t0)[3];
t9=t4;
f_5776(t9,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t7,t8));}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5787 in k5755 in k5752 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
f_5776(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}

/* k5774 in k5755 in k5752 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_5776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5776,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[170],t2));}

/* k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5603,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5603(2,t3,t1);}
else{
/* optimizer.scm: 1175 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5603,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 1177 fifth */
t4=C_retrieve(lf[169]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5618,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5693,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1181 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a5692 in k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5693(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5693,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5616 in k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5618,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1186 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[167],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5660,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5662,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 1194 fold-inner */
t5=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,t1);}}}

/* a5661 in k5616 in k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5662(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5662,4,t0,t1,t2,t3);}
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
if(C_truep(t4)){
t5=(C_word)C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6));}
else{
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=(C_word)C_a_i_list(&a,2,t2,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t5,t6));}}

/* k5658 in k5616 in k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5660,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[168],t2));}

/* k5632 in k5616 in k5607 in k5601 in k5598 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[166],t2));}

/* k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_5530(2,t3,t1);}
else{
/* optimizer.scm: 1157 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5528 in k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5558,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1163 ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5557 in k5528 in k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5558,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5570,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1165 qnode */
t6=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k5568 in a5557 in k5528 in k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5570,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 1164 append */
t3=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5547 in k5528 in k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(C_word)C_fixnum_decrease(((C_word*)t0)[3]);
/* optimizer.scm: 1163 split-at */
t3=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k5541 in k5528 in k5525 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[165],t3));}

/* k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5382(2,t3,t1);}
else{
/* optimizer.scm: 1128 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5382,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5391,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5463,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1132 remove */
t6=C_retrieve(lf[164]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a5462 in k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5463,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(1));
t5=(C_word)C_eqp(lf[24],t4);
if(C_truep(t5)){
t6=t2;
t7=(C_word)C_slot(t6,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k5389 in k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
if(C_truep((C_word)C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5407,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 1137 qnode */
t3=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=(C_word)C_i_cdr(t1);
if(C_truep((C_word)C_i_nullp(t2))){
t3=(C_word)C_i_car(t1);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[161],t4));}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(C_retrieve(lf[142]),lf[147]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5442,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 1145 fold-inner */
t7=C_retrieve(lf[163]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a5443 in k5389 in k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5444,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=(C_word)C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t4,t5));}

/* k5440 in k5389 in k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5442,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[162],t2));}

/* k5405 in k5389 in k5380 in k5377 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5407,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[160],t2));}

/* k5342 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5347,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_5347(2,t3,t1);}
else{
/* optimizer.scm: 1118 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5345 in k5342 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5347,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5357,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 1119 qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5355 in k5345 in k5342 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5357,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[159],t2));}

/* k5274 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5279(2,t3,t1);}
else{
/* optimizer.scm: 1104 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5277 in k5274 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t3=(C_word)C_i_cddr(((C_word*)t0)[5]);
t4=t2;
f_5299(t4,(C_word)C_i_pairp(t3));}
else{
t3=t2;
f_5299(t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5297 in k5277 in k5274 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_5299(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5299,NULL,2,t0,t1);}
t2=(C_truep(t1)?(C_word)C_i_caddr(((C_word*)t0)[5]):(C_word)C_i_cadr(((C_word*)t0)[5]));
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[158],t6));}

/* k5195 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5200,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_5200(2,t3,t1);}
else{
/* optimizer.scm: 1087 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5198 in k5195 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5200,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_cadr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5230,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(C_word)C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
if(C_truep(t6)){
t7=t5;
f_5230(t7,(C_word)C_fixnum_increase(((C_word*)t0)[2]));}
else{
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[3]))){
t7=(C_word)C_i_car(((C_word*)t0)[3]);
t8=t5;
f_5230(t8,(C_word)C_fixnum_times(((C_word*)t0)[2],t7));}
else{
t7=t5;
f_5230(t7,((C_word*)t0)[3]);}}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5228 in k5198 in k5195 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_5230(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5230,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[83],t2,t3);
t5=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[157],t5));}

/* k5102 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5107,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5107(2,t3,t1);}
else{
/* optimizer.scm: 1067 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5105 in k5102 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5107,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 1070 varnode */
t9=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t9))(3,t9,t7,t8);}
else{
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_eqp(C_retrieve(lf[142]),t4);
if(C_truep(t5)){
t6=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[156],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5124 in k5105 in k5102 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1070 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5117 in k5105 in k5102 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k5019 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5024,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_5024(2,t3,t1);}
else{
/* optimizer.scm: 1049 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k5022 in k5019 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_5024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5024,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_retrieve(lf[142]),t2);
if(C_truep(t3)){
t4=(C_word)C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_retrieve(lf[137]));
if(C_truep(t5)){
t6=(C_truep(C_retrieve(lf[137]))?(C_word)C_i_cadddr(((C_word*)t0)[5]):(C_word)C_i_caddr(((C_word*)t0)[5]));
t7=(C_word)C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t7,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[155],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4954 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4959(2,t3,t1);}
else{
/* optimizer.scm: 1037 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4957 in k4954 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)t0)[2]))){
t6=(C_word)C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_4974(t7,(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_4974(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4972 in k4957 in k4954 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4974(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4974,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4977,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=(C_word)C_a_i_record(&a,4,lf[34],lf[154],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm: 1041 cons* */
t5=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4975 in k4972 in k4957 in k4954 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4977,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4878 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4883(2,t3,t1);}
else{
/* optimizer.scm: 1024 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4881 in k4878 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4883,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_length(((C_word*)t0)[4]);
t5=(C_word)C_i_caddr(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_less_or_equal_p(t4,t5))){
t6=(C_word)C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[153],t7));}
else{
t7=(C_word)C_i_car(((C_word*)t0)[5]);
t8=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4919,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4926,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 1031 varnode */
t12=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4924 in k4881 in k4878 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1031 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4917 in k4881 in k4878 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4919,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4813 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4818(2,t3,t1);}
else{
/* optimizer.scm: 1011 test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4816 in k4813 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_4830(t5,t3);}
else{
t5=(C_word)C_i_length(((C_word*)t0)[2]);
t6=(C_word)C_i_car(((C_word*)t0)[5]);
t7=t4;
f_4830(t7,(C_word)C_eqp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4828 in k4816 in k4813 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4843,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 1016 varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4841 in k4828 in k4816 in k4813 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 1016 cons* */
t2=C_retrieve(lf[152]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4834 in k4828 in k4816 in k4813 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k4726 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4728,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_and((C_word)C_fixnum_lessp(C_fix(0),t2),(C_word)C_fixnum_lessp(t2,C_fix(3))))){
t3=(C_word)C_i_car(((C_word*)t0)[4]);
t4=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4750,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_i_car(((C_word*)t0)[4]);
/* optimizer.scm: 998  varnode */
t7=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4748 in k4726 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4750,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4758,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 1001 qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4756 in k4748 in k4726 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4758,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_i_nullp(t3))){
t4=(C_word)C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm: 1003 varnode */
t5=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t2,t4);}
else{
t4=t2;
f_4762(2,t4,(C_word)C_i_cadr(((C_word*)t0)[3]));}}

/* k4760 in k4756 in k4748 in k4726 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t2));}

/* k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4584,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
if(C_truep((C_word)C_fixnum_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4600,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 969  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4606,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve(lf[137]))){
t4=(C_word)C_eqp(C_retrieve(lf[142]),lf[151]);
t5=t3;
f_4606(t5,(C_word)C_i_not(t4));}
else{
t4=t3;
f_4606(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4606,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4609,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4609(t3,t1);}
else{
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_4609(t5,t4);}
else{
t5=(C_word)C_eqp(C_retrieve(lf[142]),lf[150]);
t6=t2;
f_4609(t6,(C_truep(t5)?(C_word)C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4609(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4609,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4668,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a4667 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4668,3,t0,t1,t2);}
/* optimizer.scm: 973  gensym */
t3=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* k4610 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4615,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_retrieve(lf[46]),t1);}

/* k4613 in k4610 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4615,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4620,tmp=(C_word)a,a+=2,tmp);
t3=(C_word)C_eqp(C_retrieve(lf[142]),lf[147]);
t4=(C_truep(t3)?(C_word)C_i_car(((C_word*)t0)[6]):(C_word)C_i_cadr(((C_word*)t0)[6]));
t5=(C_word)C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4644,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4646,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 985  fold-boolean */
t8=C_retrieve(lf[149]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t7,t1);}

/* a4645 in k4613 in k4610 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4646,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[2],t4));}

/* k4642 in k4613 in k4610 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4644,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[148],t2);
/* optimizer.scm: 975  fold-right */
t4=C_retrieve(lf[119]);
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a4619 in k4613 in k4610 in k4607 in k4604 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4620(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4620,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_a_i_list(&a,1,t3);
t6=(C_word)C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t5,t6));}

/* k4598 in k4582 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4600,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[146],t2));}

/* k4555 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4560(2,t3,t1);}
else{
/* optimizer.scm: 960  test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4558 in k4555 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=t2;
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4494 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4496,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4499,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4499(2,t3,t1);}
else{
/* optimizer.scm: 949  test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4497 in k4494 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4499,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_cadr(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4512,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4523,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm: 954  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4521 in k4497 in k4494 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4523,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 953  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k4510 in k4497 in k4494 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4512,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[145],t3));}

/* k4429 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4431,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=(C_word)C_i_cadr(((C_word*)t0)[5]);
t5=(C_word)C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t5,t6);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t8);
t10=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[144],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4336 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4341,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_4341(2,t3,t1);}
else{
/* optimizer.scm: 922  test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4339 in k4336 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4341,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)C_i_caddr(((C_word*)t0)[4]);
t5=(C_word)C_i_not(t4);
t6=(C_truep(t5)?t5:(C_word)C_eqp(t4,C_retrieve(lf[142])));
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_word)C_a_i_list(&a,1,t7);
t9=(C_word)C_i_car(((C_word*)t0)[5]);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t9,tmp=(C_word)a,a+=6,tmp);
t11=(C_word)C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm: 930  qnode */
t12=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t12))(3,t12,t10,t11);}
else{
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4381 in k4339 in k4336 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4383,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=(C_word)C_a_i_record(&a,4,lf[34],lf[134],((C_word*)t0)[4],t2);
t4=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[143],t4));}

/* k4280 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4282,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[5]);
t3=(C_word)C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 911  varnode */
t6=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4293 in k4280 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(C_word)C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm: 914  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* k4301 in k4293 in k4280 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t3));}

/* k4236 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_4241(2,t3,t1);}
else{
/* optimizer.scm: 901  test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k4239 in k4236 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4241,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[2]);
/* optimizer.scm: 902  varnode */
t4=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4249 in k4239 in k4236 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[141],t2));}

/* k4132 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4137,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_4137(2,t3,t1);}
else{
/* optimizer.scm: 883  test */
t3=((C_word*)t0)[3];
f_3972(t3,t2,((C_word*)t0)[2],lf[43]);}}

/* k4135 in k4132 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4137,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:C_retrieve(lf[137]));
if(C_truep(t3)){
t4=(C_word)C_i_car(((C_word*)t0)[5]);
t5=(C_word)C_i_cadddr(((C_word*)t0)[6]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4162,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t8=(C_word)C_slot(t4,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4194,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t11=(C_word)C_slot(t4,C_fix(2));
t12=(C_word)C_i_car(t11);
/* optimizer.scm: 893  get */
t13=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t13))(5,t13,t10,((C_word*)t0)[2],t12,lf[140]);}
else{
t10=t7;
f_4165(t10,C_SCHEME_FALSE);}}
else{
t8=t7;
f_4165(t8,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4192 in k4135 in k4132 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4165(t2,(C_word)C_eqp(lf[139],t1));}

/* k4163 in k4135 in k4132 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4165(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
f_4162(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t2,t3));}
else{
t2=(C_word)C_i_cadr(((C_word*)t0)[2]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
f_4162(t5,(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4));}}

/* k4160 in k4135 in k4132 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4162(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4162,NULL,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[138],t2));}

/* k4024 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4026,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_length(((C_word*)t0)[3]);
t4=(C_word)C_i_car(((C_word*)t0)[4]);
t5=(C_word)C_eqp(t3,t4);
if(C_truep(t5)){
t6=(C_word)C_i_car(((C_word*)t0)[3]);
t7=(C_word)C_i_cadr(((C_word*)t0)[3]);
t8=(C_word)C_slot(t6,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_slot(t7,C_fix(1));
t11=(C_word)C_eqp(lf[8],t10);
if(C_truep(t11)){
t12=(C_word)C_slot(t6,C_fix(2));
t13=(C_word)C_slot(t7,C_fix(2));
if(C_truep((C_word)C_i_equalp(t12,t13))){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4089,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 872  qnode */
t15=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t15))(3,t15,t14,C_SCHEME_TRUE);}
else{
t14=t2;
f_4029(t14,C_SCHEME_FALSE);}}
else{
t12=t2;
f_4029(t12,C_SCHEME_FALSE);}}
else{
t10=t2;
f_4029(t10,C_SCHEME_FALSE);}}
else{
t6=t2;
f_4029(t6,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k4087 in k4024 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_4089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4089,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_4029(t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[136],t2));}

/* k4027 in k4024 in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_4029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4029,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_retrieve(lf[133]))){
t2=(C_word)C_i_cadr(((C_word*)t0)[4]);
t3=(C_word)C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[134],t3,t4);
t6=(C_word)C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[135],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* test in ##compiler#simplify-named-call in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3972(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3972,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 854  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#rewrite in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3949(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3949r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3949r(t0,t1,t2,t3);}}

static void C_ccall f_3949r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3953,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 850  ##sys#hash-table-ref */
t5=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,C_retrieve(lf[130]),t2);}

/* k3951 in ##compiler#rewrite in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3953,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm: 851  append */
t5=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t2,t4);}

/* k3961 in k3951 in ##compiler#rewrite in k3945 in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 851  ##sys#hash-table-set! */
t2=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],C_retrieve(lf[130]),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3621(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3621,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3625,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 762  map */
t8=*((C_word*)lf[128]+1);
((C_proc5)C_retrieve_proc(t8))(5,t8,t7,*((C_word*)lf[129]+1),t2,t3);}

/* k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3627,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3672,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 773  for-each */
t5=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a3933 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3934(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3934,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3939,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3943,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 774  scan-used-variables */
t6=C_retrieve(lf[126]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k3941 in a3933 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 774  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3937 in a3933 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3876,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t8=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,((C_word*)t0)[2]);}

/* a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3876,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3886,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 783  filter */
t5=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a3907 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3908,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3921,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 784  find-path */
t5=((C_word*)t0)[2];
f_3627(t5,t4,((C_word*)t0)[3],t2);}}

/* k3919 in a3907 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm: 784  find-path */
t2=((C_word*)t0)[5];
f_3627(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3884 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3890,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 786  gensym */
t4=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k3900 in k3884 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3902,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm: 786  alist-cons */
t3=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k3888 in k3884 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3894,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm: 787  append */
t5=*((C_word*)lf[3]+1);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k3892 in k3888 in k3884 in a3875 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3675,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3678,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* for-each */
t6=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[7])[1]);}

/* a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3817,3,t0,t1,t2);}
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3824,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_i_cdr(t2);
/* optimizer.scm: 796  append-map */
t7=C_retrieve(lf[125]);
((C_proc4)C_retrieve_proc(t7))(4,t7,t4,t5,t6);}

/* a3859 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3860,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 797  filter */
t4=C_retrieve(lf[124]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a3865 in a3859 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3866,3,t0,t1,t2);}
/* optimizer.scm: 797  find-path */
t3=((C_word*)t0)[3];
f_3627(t3,t1,((C_word*)t0)[2],t2);}

/* k3822 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3832,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3834,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 802  filter-map */
t5=C_retrieve(lf[123]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a3833 in k3822 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3834,3,t0,t1,t2);}
t3=(C_word)C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3847,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_cdr(t2);
/* optimizer.scm: 803  lset<= */
t6=C_retrieve(lf[122]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,*((C_word*)lf[33]+1),t5,((C_word*)t0)[2]);}}

/* k3845 in a3833 in k3822 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?(C_word)C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k3830 in k3822 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 800  alist-cons */
t2=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k3826 in k3822 in a3816 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3678,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 809  topological-sort */
t3=C_retrieve(lf[121]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[33]+1));}

/* k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3684,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 814  fold */
t6=C_retrieve(lf[120]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3701,4,t0,t1,t2,t3);}
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3714,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=(C_word)C_i_cdr(t5);
if(C_truep((C_word)C_i_nullp(t8))){
t9=(C_word)C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=(C_word)C_i_cdr(t9);
t11=(C_word)C_i_memq(t6,t10);
t12=t7;
f_3714(t12,(C_word)C_i_not(t11));}
else{
t9=t7;
f_3714(t9,C_SCHEME_FALSE);}}

/* k3712 in a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=(C_word)C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3737,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3755,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3757,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 828  fold-right */
t5=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a3756 in k3712 in a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3757(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3757,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3789,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 831  gensym */
t5=C_retrieve(lf[78]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k3787 in a3756 in k3712 in a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3789,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(C_word)C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=(C_word)C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_a_i_list(&a,1,t5);
t7=(C_word)C_a_i_record(&a,4,lf[34],lf[14],t3,t6);
t8=(C_word)C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t2,t8));}

/* k3753 in k3712 in a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 823  fold-right */
t2=C_retrieve(lf[119]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a3736 in k3712 in a3700 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3737,4,t0,t1,t2,t3);}
t4=(C_word)C_a_i_list(&a,1,t2);
t5=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=(C_word)C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_word)C_a_i_record(&a,4,lf[34],lf[10],t4,t6));}

/* k3682 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3684,2,t0,t1);}
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3693,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 840  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[118],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm: 842  values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k3691 in k3682 in k3679 in k3676 in k3673 in k3670 in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 841  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3627(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3627,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3633,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3633(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3633(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3633,NULL,4,t0,t1,t2,t3);}
if(C_truep((C_word)C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(C_word)C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=(C_word)C_i_cdr(t4);
t6=(C_word)C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=(C_word)C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3657,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 770  any */
t9=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t1,t8,t5);}}}

/* a3656 in find in find-path in k3623 in ##compiler#reorganize-recursive-bindings in k3617 in k3614 in k3611 in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3657,3,t0,t1,t2);}
/* optimizer.scm: 770  find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3633(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3606(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3606r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3606r(t0,t1,t2,t3);}}

static void C_ccall f_3606r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm: 541  ##sys#hash-table-set! */
t4=C_retrieve(lf[116]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,C_retrieve(lf[20]),t2,t3);}

/* ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3145,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3152,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3159,a[2]=t3,a[3]=t9,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 454  debugging */
t11=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,lf[18],lf[114]);}

/* k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3394,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 457  test */
t4=((C_word*)t0)[3];
f_3152(t4,t3,lf[113],lf[43]);}

/* k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3399,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3601,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 493  test */
t4=((C_word*)t0)[3];
f_3152(t4,t3,lf[113],lf[109]);}
else{
t2=((C_word*)t0)[2];
f_3162(2,t2,C_SCHEME_UNDEFINED);}}

/* k3599 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3399,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3412,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=t1,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3590,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 463  test */
t10=((C_word*)t0)[2];
f_3152(t10,t9,t7,lf[73]);}

/* k3588 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3412(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 463  test */
t2=((C_word*)t0)[3];
f_3152(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3415,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 464  test */
t3=((C_word*)t0)[3];
f_3152(t3,t2,((C_word*)t0)[2],lf[72]);}

/* k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_i_length(((C_word*)t0)[4]);
t6=(C_word)C_eqp(C_fix(3),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(((C_word*)t0)[8],C_fix(1));
t8=t2;
f_3421(t8,(C_word)C_eqp(lf[52],t7));}
else{
t7=t2;
f_3421(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3421(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3421(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3421(t3,C_SCHEME_FALSE);}}

/* k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3421(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3421,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(C_word)C_slot(t5,C_fix(3));
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t8=(C_word)C_i_cdr(t3);
t9=t7;
f_3436(t9,(C_word)C_i_nullp(t8));}
else{
t8=t7;
f_3436(t8,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3436(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3436,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3442,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 475  test */
t4=((C_word*)t0)[2];
f_3152(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=(C_word)C_i_length(t1);
t4=(C_word)C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=(C_word)C_slot(((C_word*)t0)[9],C_fix(1));
t6=t2;
f_3448(t6,(C_word)C_eqp(lf[9],t5));}
else{
t5=t2;
f_3448(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3448(t3,C_SCHEME_FALSE);}}

/* k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3448(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3448,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[9],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3457,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_slot(t3,C_fix(1));
t6=(C_word)C_eqp(lf[8],t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(2));
t8=(C_word)C_i_car(t7);
t9=t4;
f_3457(t9,(C_word)C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_3457(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3455 in k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3457,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 487  node-parameters-set! */
t5=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],lf[112]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3462 in k3455 in k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 488  node-subexpressions-set! */
t4=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k3465 in k3462 in k3455 in k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3470,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 491  reverse */
t6=*((C_word*)lf[111]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}

/* k3483 in k3465 in k3462 in k3455 in k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3485,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 489  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3468 in k3465 in k3462 in k3455 in k3446 in k3440 in k3434 in k3419 in k3413 in k3410 in a3398 in k3392 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 492  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3148(((C_word*)t0)[2]));}

/* k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* for-each */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_retrieve(lf[110]));}

/* a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3176,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3183,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 498  test */
t4=((C_word*)t0)[3];
f_3152(t4,t3,t2,lf[43]);}

/* k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3183,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3188,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3388,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 531  test */
t4=((C_word*)t0)[4];
f_3152(t4,t3,((C_word*)t0)[5],lf[109]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3386 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3188(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3188,3,t0,t1,t2);}
t3=(C_word)C_i_cdr(t2);
t4=(C_word)C_slot(t3,C_fix(3));
t5=(C_word)C_i_cadr(t4);
t6=(C_word)C_slot(t5,C_fix(2));
t7=(C_word)C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3201,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t4,a[8]=((C_word*)t0)[5],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 504  test */
t9=((C_word*)t0)[3];
f_3152(t9,t8,t7,lf[72]);}

/* k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3204,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3377,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 505  test */
t4=((C_word*)t0)[4];
f_3152(t4,t3,((C_word*)t0)[2],lf[73]);}

/* k3375 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3204(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 505  test */
t2=((C_word*)t0)[3];
f_3152(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=(C_word)C_slot(t1,C_fix(1));
t4=(C_word)C_eqp(lf[52],t3);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[3])){
t5=(C_word)C_i_length(((C_word*)t0)[3]);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3349,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(C_word)C_i_cddr(((C_word*)t0)[7]);
/* optimizer.scm: 510  any */
t10=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t7=t2;
f_3210(t7,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3210(t5,C_SCHEME_FALSE);}}
else{
t5=t2;
f_3210(t5,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3210(t3,C_SCHEME_FALSE);}}

/* a3350 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3351,3,t0,t1,t2);}
/* optimizer.scm: 510  expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k3347 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3210(t2,(C_word)C_i_not(t1));}

/* k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t5=(C_word)C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t5,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep((C_word)C_i_listp(t3))){
t7=(C_word)C_i_cdr(t3);
if(C_truep((C_word)C_i_nullp(t7))){
t8=(C_word)C_slot(t5,C_fix(1));
t9=t6;
f_3222(t9,(C_word)C_eqp(lf[9],t8));}
else{
t8=t6;
f_3222(t8,C_SCHEME_FALSE);}}
else{
t7=t6;
f_3222(t7,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3222(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3222,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3228,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 518  test */
t4=((C_word*)t0)[2];
f_3152(t4,t3,t2,lf[72]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3228,2,t0,t1);}
t2=(C_word)C_slot(((C_word*)t0)[8],C_fix(3));
t3=(C_word)C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t5=(C_word)C_i_length(t1);
t6=(C_word)C_eqp(C_fix(1),t5);
if(C_truep(t6)){
t7=(C_word)C_slot(t3,C_fix(1));
t8=(C_word)C_eqp(lf[8],t7);
if(C_truep(t8)){
t9=(C_word)C_slot(t3,C_fix(2));
t10=(C_word)C_i_car(t9);
t11=t4;
f_3237(t11,(C_word)C_eqp(((C_word*)t0)[2],t10));}
else{
t9=t4;
f_3237(t9,C_SCHEME_FALSE);}}
else{
t7=t4;
f_3237(t7,C_SCHEME_FALSE);}}
else{
t5=t4;
f_3237(t5,C_SCHEME_FALSE);}}

/* k3235 in k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[7],C_fix(3));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3243,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 527  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[108],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k3241 in k3235 in k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3243,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 528  node-parameters-set! */
t3=C_retrieve(lf[106]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[2],lf[107]);}

/* k3244 in k3241 in k3235 in k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3264,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 529  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,C_SCHEME_TRUE);}

/* k3262 in k3244 in k3241 in k3235 in k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3264,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm: 529  node-subexpressions-set! */
t3=C_retrieve(lf[105]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3247 in k3244 in k3241 in k3235 in k3226 in k3220 in k3208 in k3202 in k3199 in a3187 in k3181 in a3175 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 530  touch */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,f_3148(((C_word*)t0)[2]));}

/* k3163 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 534  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[104],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3168(2,t4,C_SCHEME_UNDEFINED);}}

/* k3166 in k3163 in k3160 in k3157 in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3152(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3152,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 452  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k1669 in k1461 in k1458 in k1455 */
static C_word C_fcall f_3148(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1674(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[70],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1674,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1677,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp);
t18=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1693,tmp=(C_word)a,a+=2,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1703,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1707,a[2]=t3,a[3]=t21,a[4]=t19,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1799,a[2]=t26,a[3]=t16,a[4]=t17,a[5]=t24,a[6]=t18,a[7]=t19,a[8]=t7,a[9]=t21,a[10]=t15,tmp=(C_word)a,a+=11,tmp));
t30=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2015,a[2]=t11,a[3]=t3,a[4]=t28,a[5]=t24,a[6]=t5,a[7]=t9,a[8]=t16,a[9]=t19,tmp=(C_word)a,a+=10,tmp));
t31=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3030,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t32=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3049,a[2]=t24,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 420  perform-pre-optimization! */
t33=C_retrieve(lf[103]);
((C_proc4)C_retrieve_proc(t33))(4,t33,t32,t2,t3);}

/* k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3049,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm: 421  values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3055,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 423  debugging */
t3=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[18],lf[102]);}}

/* k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=C_set_block_item(lf[21],0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 425  walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1799(3,t4,t3,((C_word*)t0)[2]);}

/* k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep((C_word)C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm: 426  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[101],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_3062(2,t3,C_SCHEME_UNDEFINED);}}

/* k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3098,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_pairp(C_retrieve(lf[21])))){
/* optimizer.scm: 427  debugging */
t4=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,lf[5],lf[100]);}
else{
t4=t3;
f_3098(2,t4,C_SCHEME_FALSE);}}

/* k3096 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3103,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_retrieve(lf[21]));}
else{
t2=((C_word*)t0)[2];
f_3065(2,t2,C_SCHEME_UNDEFINED);}}

/* a3102 in k3096 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3103,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_car(t2);
/* optimizer.scm: 430  print* */
t5=*((C_word*)lf[99]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,C_make_character(9),t4);}

/* k3105 in a3102 in k3096 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_i_cdr(((C_word*)t0)[3]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(1)))){
t3=(C_word)C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm: 432  print */
t4=*((C_word*)lf[97]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm: 433  newline */
t3=*((C_word*)lf[98]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[2]);}}

/* k3063 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3068,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 435  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[96],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3068(2,t4,C_SCHEME_UNDEFINED);}}

/* k3066 in k3063 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 436  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[95],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3071(2,t4,C_SCHEME_UNDEFINED);}}

/* k3069 in k3066 in k3063 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* optimizer.scm: 437  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,lf[5],lf[94],((C_word*)((C_word*)t0)[2])[1]);}
else{
t4=t2;
f_3074(2,t4,C_SCHEME_UNDEFINED);}}

/* k3072 in k3069 in k3066 in k3063 in k3060 in k3057 in k3053 in k3047 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 438  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_3030(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3030,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3034,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* map */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)((C_word*)t0)[2])[1],t5);}

/* k3032 in walk-generic in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3040,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 416  every */
t3=C_retrieve(lf[40]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k3038 in k3032 in walk-generic in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_record(&a,4,lf[34],t2,t3,((C_word*)t0)[2]));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[68],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,3,t0,t1,t2);}
t3=t2;
t4=(C_word)C_slot(t3,C_fix(3));
t5=t2;
t6=(C_word)C_slot(t5,C_fix(2));
t7=t2;
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(t8,lf[8]);
if(C_truep(t9)){
t10=(C_word)C_i_car(t6);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[7],a[3]=t6,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t12,tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2040(t14,t1,t10);}
else{
t10=(C_word)C_eqp(t8,lf[10]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2115,a[2]=t11,a[3]=((C_word*)t0)[8],a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 251  test */
t13=((C_word*)t0)[8];
f_1677(t13,t12,t11,lf[48]);}
else{
t11=(C_word)C_eqp(t8,lf[52]);
if(C_truep(t11)){
t12=(C_word)C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2172,a[2]=t8,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t12,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t6,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t14=(C_word)C_i_car(t6);
/* optimizer.scm: 261  test */
t15=((C_word*)t0)[8];
f_1677(t15,t13,t14,lf[61]);}
else{
t12=(C_word)C_eqp(t8,lf[13]);
if(C_truep(t12)){
t13=(C_word)C_i_car(t4);
t14=(C_word)C_slot(t13,C_fix(1));
t15=(C_word)C_eqp(t14,lf[8]);
if(C_truep(t15)){
t16=(C_word)C_slot(t13,C_fix(2));
t17=(C_word)C_i_car(t16);
t18=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[2],a[3]=t13,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t8,a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=t17,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[9],a[14]=t4,tmp=(C_word)a,a+=15,tmp);
t19=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2890,a[2]=t17,a[3]=((C_word*)t0)[8],a[4]=t18,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 299  test */
t20=((C_word*)t0)[8];
f_1677(t20,t19,t17,lf[73]);}
else{
t16=(C_word)C_eqp(t14,lf[52]);
if(C_truep(t16)){
if(C_truep((C_word)C_i_car(t6))){
/* optimizer.scm: 393  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3030(t17,t1,t2,t8,t6,t4);}
else{
t17=(C_word)C_i_cdr(t6);
t18=(C_word)C_a_i_cons(&a,2,C_SCHEME_TRUE,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2915,a[2]=t18,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* map */
t20=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t19,((C_word*)((C_word*)t0)[5])[1],t4);}}
else{
/* optimizer.scm: 395  walk-generic */
t17=((C_word*)((C_word*)t0)[4])[1];
f_3030(t17,t1,t2,t8,t6,t4);}}}
else{
t13=(C_word)C_eqp(t8,lf[14]);
if(C_truep(t13)){
t14=(C_word)C_i_car(t6);
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=t6,a[7]=t14,a[8]=t1,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 399  test */
t16=((C_word*)t0)[8];
f_1677(t16,t15,t14,lf[50]);}
else{
/* optimizer.scm: 412  walk-generic */
t14=((C_word*)((C_word*)t0)[4])[1];
f_3030(t14,t1,t2,t8,t6,t4);}}}}}}

/* k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=t2;
f_2943(2,t3,t1);}
else{
/* optimizer.scm: 399  test */
t3=((C_word*)t0)[2];
f_1677(t3,t2,((C_word*)t0)[7],lf[48]);}}

/* k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2943,2,t0,t1);}
if(C_truep(t1)){
t2=f_1703(((C_word*)t0)[9]);
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2955,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3022,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 402  test */
t4=((C_word*)t0)[2];
f_1677(t4,t3,((C_word*)t0)[7],lf[93]);}}

/* k3020 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3022,2,t0,t1);}
t2=(C_word)C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2984,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_2984(t4,t2);}
else{
t4=C_retrieve(lf[91]);
if(C_truep(t4)){
t5=t3;
f_2984(t5,t4);}
else{
if(C_truep(C_retrieve(lf[92]))){
t5=(C_word)C_i_memq(((C_word*)t0)[2],C_retrieve(lf[92]));
t6=t3;
f_2984(t6,(C_word)C_i_not(t5));}
else{
t5=t3;
f_2984(t5,C_SCHEME_FALSE);}}}}

/* k2982 in k3020 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2984,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 405  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[6];
f_2955(t2,C_SCHEME_FALSE);}}

/* k3003 in k2982 in k3020 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3005,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2955(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 406  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k2995 in k3003 in k2982 in k3020 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2955(t2,(C_word)C_i_not(t1));}

/* k2953 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2955(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2955,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1703(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2961,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 408  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[90],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 410  walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1799(3,t4,t2,t3);}}

/* k2972 in k2953 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2974,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[14],((C_word*)t0)[2],t2));}

/* k2959 in k2953 in k2941 in k2938 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2961,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* k2913 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2915,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2888 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2348(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 299  test */
t2=((C_word*)t0)[3];
f_1677(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2348,2,t0,t1);}
t2=(C_word)C_i_cdr(((C_word*)t0)[14]);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[14],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=t1,tmp=(C_word)a,a+=17,tmp);
/* optimizer.scm: 301  test */
t4=((C_word*)t0)[4];
f_1677(t4,t3,((C_word*)t0)[10],lf[50]);}

/* k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[47],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2357,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=t3,a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 304  check-signature */
t5=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,((C_word*)t0)[11],((C_word*)t0)[12],t3);}
else{
if(C_truep((C_word)C_i_memq(((C_word*)t0)[11],C_retrieve(lf[65])))){
t2=(C_word)C_i_car(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[13],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=(C_word)C_slot(t2,C_fix(1));
t5=(C_word)C_eqp(lf[8],t4);
if(C_truep(t5)){
t6=(C_word)C_slot(t2,C_fix(2));
t7=(C_word)C_i_car(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2517,a[2]=t7,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 312  test */
t10=((C_word*)t0)[4];
f_1677(t10,t9,t7,lf[73]);}
else{
t8=t3;
f_2399(t8,C_SCHEME_FALSE);}}
else{
t6=t3;
f_2399(t6,C_SCHEME_FALSE);}}
else{
t4=t3;
f_2399(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2531,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[16])){
t3=(C_word)C_slot(((C_word*)t0)[16],C_fix(1));
t4=t2;
f_2531(t4,(C_word)C_eqp(lf[52],t3));}
else{
t3=t2;
f_2531(t3,C_SCHEME_FALSE);}}}}

/* k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2531(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2531,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(((C_word*)t0)[16],C_fix(2));
t3=(C_word)C_i_caddr(t2);
t4=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_2542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t3,a[14]=((C_word*)t0)[16],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=t2,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm: 327  decompose-lambda-list */
t5=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t5))(4,t5,((C_word*)t0)[2],t3,t4);}
else{
/* optimizer.scm: 390  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3030(t2,((C_word*)t0)[2],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[28],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2542,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_i_car(((C_word*)t0)[17]);
t6=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t3,a[13]=t5,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=t1,a[20]=((C_word*)t0)[15],a[21]=((C_word*)t0)[16],tmp=(C_word)a,a+=22,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[17],a[4]=t6,a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 331  test */
t8=((C_word*)t0)[3];
f_1677(t8,t7,t5,lf[89]);}

/* k2839 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2841,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 332  test */
t3=((C_word*)t0)[2];
f_1677(t3,t2,((C_word*)t0)[5],lf[88]);}
else{
t2=((C_word*)t0)[4];
f_2552(t2,C_SCHEME_FALSE);}}

/* k2845 in k2839 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
if(C_truep((C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[85])))){
t2=((C_word*)t0)[3];
f_2552(t2,C_SCHEME_FALSE);}
else{
t2=(C_word)C_i_memq(((C_word*)t0)[4],C_retrieve(lf[86]));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_2552(t3,t2);}
else{
t3=(C_word)C_i_cadddr(((C_word*)t0)[2]);
t4=C_retrieve(lf[87]);
t5=((C_word*)t0)[3];
f_2552(t5,(C_word)C_fixnum_lessp(t3,t4));}}}
else{
t2=((C_word*)t0)[3];
f_2552(t2,C_SCHEME_FALSE);}}

/* k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2552(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2552,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_cadddr(((C_word*)t0)[14]);
/* optimizer.scm: 336  debugging */
t4=C_retrieve(lf[4]);
((C_proc7)C_retrieve_proc(t4))(7,t4,t2,lf[75],lf[76],((C_word*)t0)[15],((C_word*)t0)[13],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[20],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[21],a[12]=((C_word*)t0)[7],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[9],a[15]=((C_word*)t0)[10],a[16]=((C_word*)t0)[19],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],a[19]=((C_word*)t0)[16],tmp=(C_word)a,a+=20,tmp);
/* optimizer.scm: 341  test */
t3=((C_word*)t0)[4];
f_1677(t3,t2,((C_word*)t0)[13],lf[61]);}}

/* k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[19]);
t3=((C_word*)t0)[18];
if(C_truep((C_word)C_fixnum_lessp(t2,t3))){
/* optimizer.scm: 343  walk-generic */
t4=((C_word*)((C_word*)t0)[17])[1];
f_3030(t4,((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2603,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t5,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp));
t7=((C_word*)t5)[1];
f_2603(t7,((C_word*)t0)[16],((C_word*)t0)[5],((C_word*)t0)[18],((C_word*)t0)[19],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2748,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[4],tmp=(C_word)a,a+=14,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2831,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 365  test */
t4=((C_word*)t0)[6];
f_1677(t4,t3,((C_word*)t0)[2],lf[57]);}}

/* k2829 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_2748(t3,(C_word)C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2748(t2,C_SCHEME_FALSE);}}

/* k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2748(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2748,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_length(((C_word*)t0)[13]);
t3=(C_word)C_i_length(((C_word*)t0)[12]);
if(C_truep((C_word)C_fixnum_lessp(t3,t2))){
/* optimizer.scm: 369  walk-generic */
t4=((C_word*)((C_word*)t0)[11])[1];
f_3030(t4,((C_word*)t0)[10],t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[12],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 371  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,lf[5],lf[84],((C_word*)t0)[3],t2);}}
else{
/* optimizer.scm: 389  walk-generic */
t2=((C_word*)((C_word*)t0)[11])[1];
f_3030(t2,((C_word*)t0)[10],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}

/* k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2768,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2774,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 372  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2773 in k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2774(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2774,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2778,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2793,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2801,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* optimizer.scm: 382  qnode */
t7=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,C_SCHEME_END_OF_LIST);}
else{
t7=(C_word)C_i_length(t3);
t8=(C_word)C_fixnum_times(C_fix(3),t7);
t9=(C_word)C_a_i_list(&a,2,lf[82],t8);
t10=t6;
f_2801(2,t10,(C_word)C_a_i_record(&a,4,lf[34],lf[83],t9,t3));}}

/* k2799 in a2773 in k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2801,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
/* optimizer.scm: 378  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2791 in a2773 in k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2793,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2776 in a2773 in k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2778,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[4],t1);
t3=(C_word)C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a2767 in k2761 in k2746 in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2768,2,t0,t1);}
/* optimizer.scm: 372  split-at */
t2=C_retrieve(lf[81]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2603,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_word)C_i_nullp(t2);
t7=(C_truep(t6)?t6:(C_word)C_eqp(t3,C_fix(0)));
if(C_truep(t7)){
t8=f_1703(((C_word*)t0)[9]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2619,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2630,a[2]=((C_word*)t0)[6],a[3]=t9,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 350  append-reverse */
t11=C_retrieve(lf[77]);
((C_proc4)C_retrieve_proc(t11))(4,t11,t10,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
t9=(C_word)C_i_car(t2);
/* optimizer.scm: 351  test */
t10=((C_word*)t0)[2];
f_1677(t10,t8,t9,lf[53]);}}

/* k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2636,2,t0,t1);}
if(C_truep(t1)){
t2=f_1703(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2642,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 353  debugging */
t5=C_retrieve(lf[4]);
((C_proc6)C_retrieve_proc(t5))(6,t5,t3,lf[5],lf[80],t4,((C_word*)t0)[2]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[9]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[8]);
t4=(C_word)C_i_cdr(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[7]);
t6=(C_word)C_a_i_cons(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm: 361  loop */
t7=((C_word*)((C_word*)t0)[6])[1];
f_2603(t7,((C_word*)t0)[10],t2,t3,t4,t6);}}

/* k2640 in k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2642,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2648,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[6]);
/* optimizer.scm: 354  expression-has-side-effects? */
t4=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k2646 in k2640 in k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2648,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 357  gensym */
t3=C_retrieve(lf[78]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[79]);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_decrease(((C_word*)t0)[6]);
t4=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm: 360  loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2603(t5,((C_word*)t0)[8],t2,t3,t4,((C_word*)t0)[3]);}}

/* k2683 in k2646 in k2640 in k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2685,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[5]);
/* optimizer.scm: 358  walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1799(3,t5,t3,t4);}

/* k2659 in k2683 in k2646 in k2640 in k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2665,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(C_word)C_i_cdr(((C_word*)t0)[6]);
t4=(C_word)C_fixnum_decrease(((C_word*)t0)[5]);
t5=(C_word)C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm: 359  loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2603(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k2663 in k2659 in k2683 in k2646 in k2640 in k2634 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2665,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t2));}

/* k2628 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2630,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}

/* k2617 in loop in k2587 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2619,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[13],((C_word*)t0)[2],t1));}

/* k2553 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 337  check-signature */
t3=C_retrieve(lf[64]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[4]);}

/* k2556 in k2553 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2561,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 338  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[74],((C_word*)t0)[2]);}

/* k2559 in k2556 in k2553 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2561,2,t0,t1);}
t2=f_1703(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2571,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 340  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_TRUE);}

/* k2569 in k2559 in k2556 in k2553 in k2550 in a2541 in k2529 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 340  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1799(3,t2,((C_word*)t0)[2],t1);}

/* k2515 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2420(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm: 312  test */
t2=((C_word*)t0)[3];
f_1677(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[44]);}}

/* k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2420,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_caddr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2438,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t3);
/* optimizer.scm: 315  test */
t6=((C_word*)t0)[2];
f_1677(t6,t4,t5,lf[53]);}
else{
t4=((C_word*)t0)[7];
f_2399(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_2399(t2,C_SCHEME_FALSE);}}

/* k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_2441(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 316  test */
t5=((C_word*)t0)[2];
f_1677(t5,t3,t4,lf[72]);}}

/* k2493 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2495,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2441(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 317  test */
t4=((C_word*)t0)[2];
f_1677(t4,t2,t3,lf[71]);}}

/* k2485 in k2493 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2441(t2,(C_word)C_i_not(t1));}

/* k2439 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2441,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2464,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm: 318  any */
t5=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[6];
f_2399(t2,C_SCHEME_FALSE);}}

/* a2465 in k2439 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2466,3,t0,t1,t2);}
/* ##compiler#expression-has-side-effects? */
t3=C_retrieve(lf[70]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2462 in k2439 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2464,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2399(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 319  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[68],lf[69],((C_word*)t0)[2]);}}

/* k2448 in k2462 in k2439 in k2436 in k2418 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=(C_word)C_a_i_record(&a,4,lf[34],lf[66],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_2399(t4,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[67],t3));}

/* k2397 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2399(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* optimizer.scm: 323  walk-generic */
t2=((C_word*)((C_word*)t0)[6])[1];
f_3030(t2,((C_word*)t0)[7],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k2364 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2369,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 305  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[63],((C_word*)t0)[2]);}

/* k2367 in k2364 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2369,2,t0,t1);}
t2=f_1703(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_slot(((C_word*)t0)[4],C_fix(3));
t5=(C_word)C_i_car(t4);
/* optimizer.scm: 307  inline-lambda-bindings */
t6=C_retrieve(lf[62]);
((C_proc6)C_retrieve_proc(t6))(6,t6,t3,((C_word*)t0)[3],((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2377 in k2367 in k2364 in k2355 in k2346 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 307  walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1799(3,t2,((C_word*)t0)[2],t1);}

/* k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2172,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2177,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 262  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 277  test */
t4=((C_word*)t0)[11];
f_1677(t4,t2,t3,lf[57]);}}

/* k2262 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2264,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 278  decompose-lambda-list */
t3=C_retrieve(lf[59]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
/* optimizer.scm: 290  walk-generic */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3030(t2,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* a2268 in k2262 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2269,5,t0,t1,t2,t3,t4);}
t5=f_1703(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2276,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 282  debugging */
t7=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[5],lf[60],t4);}

/* k2274 in a2268 in k2262 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2276,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[7]);
t3=(C_word)C_i_cadr(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2305,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t5=(C_word)C_fixnum_increase(((C_word*)t0)[3]);
/* optimizer.scm: 287  build-lambda-list */
t6=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k2303 in k2274 in a2268 in k2262 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2305,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2289,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 289  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1799(3,t6,t4,t5);}

/* k2287 in k2303 in k2274 in a2268 in k2262 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2289,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2177(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2177,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2183,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2195,4,t0,t1,t2,t3);}
t4=f_1703(((C_word*)t0)[8]);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm: 267  debugging */
t6=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t5,lf[5],lf[58],t2);}

/* k2200 in a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2202,2,t0,t1);}
t2=(C_word)C_i_car(((C_word*)t0)[9]);
t3=(C_word)C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2231,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t6=(C_word)C_i_car(((C_word*)t0)[9]);
/* optimizer.scm: 271  test */
t7=((C_word*)t0)[2];
f_1677(t7,t5,t6,lf[57]);}
else{
t6=t5;
f_2238(2,t6,C_SCHEME_FALSE);}}

/* k2236 in k2200 in a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2238,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 272  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[56],((C_word*)t0)[2]);}
else{
/* optimizer.scm: 274  build-lambda-list */
t2=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k2239 in k2236 in k2200 in a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_fixnum_increase(((C_word*)t0)[4]);
/* optimizer.scm: 273  build-lambda-list */
t3=C_retrieve(lf[55]);
((C_proc5)C_retrieve_proc(t3))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k2229 in k2200 in a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2231,2,t0,t1);}
t2=(C_word)C_i_cadddr(((C_word*)t0)[7]);
t3=(C_word)C_a_i_list(&a,4,((C_word*)t0)[6],((C_word*)t0)[5],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2215,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_i_car(((C_word*)t0)[3]);
/* optimizer.scm: 276  walk */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1799(3,t6,t4,t5);}

/* k2213 in k2229 in k2200 in a2194 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[52],((C_word*)t0)[2],t2));}

/* a2182 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2189,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 265  partition */
t3=C_retrieve(lf[54]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a2188 in a2182 in a2176 in k2170 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2189,3,t0,t1,t2);}
/* optimizer.scm: 265  test */
t3=((C_word*)t0)[2];
f_1677(t3,t1,t2,lf[53]);}

/* k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2118,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_2118(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2141,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 252  test */
t4=((C_word*)t0)[3];
f_1677(t4,t3,((C_word*)t0)[2],lf[51]);}}

/* k2139 in k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2141,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2118(t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 253  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[50]);}}

/* k2148 in k2139 in k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2150,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2157,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 253  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[49]);}
else{
t2=((C_word*)t0)[4];
f_2118(t2,C_SCHEME_FALSE);}}

/* k2155 in k2148 in k2139 in k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2118(t2,(C_word)C_i_not(t1));}

/* k2116 in k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2118,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_1703(((C_word*)t0)[7]);
t3=(C_word)C_fixnum_increase(((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=(C_word)C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm: 256  walk */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1799(3,t6,((C_word*)t0)[3],t5);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* map */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)t0)[5]);}}

/* k2133 in k2116 in k2113 in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2135,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,4,lf[34],lf[10],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2040,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2044,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm: 237  test */
t4=((C_word*)t0)[4];
f_1677(t4,t3,t2,lf[48]);}

/* k2042 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
if(C_truep(t1)){
/* replace119 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2040(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2056,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm: 238  test */
t3=((C_word*)t0)[5];
f_1677(t3,t2,((C_word*)t0)[4],lf[47]);}}

/* k2054 in k2042 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2056,2,t0,t1);}
if(C_truep(t1)){
t2=f_1703(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 240  debugging */
t4=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,lf[5],lf[45],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[3]);
t4=(C_word)C_eqp(((C_word*)t0)[4],t3);
if(C_truep(t4)){
t5=t2;
f_2079(t5,C_SCHEME_UNDEFINED);}
else{
t5=f_1703(((C_word*)t0)[7]);
t6=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t2;
f_2079(t8,t7);}}}

/* k2077 in k2054 in k2042 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_2079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 247  varnode */
t2=C_retrieve(lf[46]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2060 in k2054 in k2042 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 241  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[44]);}

/* k2071 in k2060 in k2054 in k2042 in replace in walk1 in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(t1,C_fix(2));
t3=(C_word)C_i_car(t2);
/* optimizer.scm: 241  qnode */
t4=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1799(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1799,3,t0,t1,t2);}
if(C_truep((C_word)C_i_memq(t2,C_retrieve(lf[31])))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)((C_word*)t0)[10])[1];
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm: 190  walk1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2015(t5,t4,t2);}}

/* k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1813,2,t0,t1);}
t2=(C_word)C_slot(t1,C_fix(3));
t3=(C_word)C_slot(t1,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1822,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,lf[9]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1831,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t2,a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t7=(C_word)C_i_car(t2);
/* optimizer.scm: 195  constant-node? */
t8=((C_word*)t0)[5];
f_1683(3,t8,t6,t7);}
else{
t6=(C_word)C_eqp(t3,lf[13]);
if(C_truep(t6)){
t7=(C_word)C_i_car(t2);
t8=(C_word)C_slot(t7,C_fix(1));
t9=(C_word)C_eqp(lf[8],t8);
if(C_truep(t9)){
t10=(C_word)C_i_car(t2);
t11=(C_word)C_slot(t10,C_fix(2));
t12=(C_word)C_i_car(t11);
t13=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=t4,a[9]=t12,tmp=(C_word)a,a+=10,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1980,a[2]=t12,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t13,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 206  test */
t15=((C_word*)t0)[2];
f_1677(t15,t14,t12,lf[43]);}
else{
t10=t4;
f_1822(2,t10,t1);}}
else{
t7=t4;
f_1822(2,t7,t1);}}}

/* k1978 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1983,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1983(2,t3,t1);}
else{
/* optimizer.scm: 207  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[42]);}}

/* k1981 in k1978 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1983,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 208  test */
t3=((C_word*)t0)[3];
f_1677(t3,t2,((C_word*)t0)[2],lf[41]);}
else{
t2=((C_word*)t0)[5];
f_1883(2,t2,C_SCHEME_FALSE);}}

/* k1987 in k1981 in k1978 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm: 209  every */
t3=C_retrieve(lf[40]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1883(2,t2,C_SCHEME_FALSE);}}

/* k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1965,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_cddr(((C_word*)t0)[3]);
/* map */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[8];
f_1822(2,t2,((C_word*)t0)[7]);}}

/* a1964 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1965,3,t0,t1,t2);}
t3=f_1693(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_a_i_list(&a,2,lf[24],t3));}

/* k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1963,2,t0,t1);}
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1894,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t3,t4);}

/* a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1894,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1900,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1917,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=C_retrieve(lf[39]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1948 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1949r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1949r(t0,t1,t2);}}

static void C_ccall f_1949r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1954 in a1948 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1922 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1927,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 217  eval */
t3=C_retrieve(lf[38]);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1925 in a1922 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1930,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 218  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[37],((C_word*)t0)[2]);}

/* k1928 in k1925 in a1922 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=f_1703(((C_word*)t0)[5]);
t3=(C_word)C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1947,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 223  qnode */
t5=C_retrieve(lf[36]);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k1945 in k1928 in k1925 in a1922 in a1916 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1947,2,t0,t1);}
t2=(C_word)C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)C_a_i_record(&a,4,lf[34],lf[13],lf[35],t2));}

/* a1899 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1906,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g9799 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1905 in a1899 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_1910(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_1910(t4,t3);}}

/* k1908 in a1905 in a1899 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_1910(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1910,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 215  lset-adjoin */
t3=C_retrieve(lf[32]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,*((C_word*)lf[33]+1),C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k1912 in k1908 in a1905 in a1899 in a1893 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k1890 in k1961 in k1881 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1829 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(t1)){
t2=(C_word)C_fixnum_plus(((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=f_1703(((C_word*)t0)[7]);
t5=(C_word)C_i_car(((C_word*)t0)[6]);
t6=f_1693(t5);
t7=(C_truep(t6)?(C_word)C_i_cadr(((C_word*)t0)[6]):(C_word)C_i_caddr(((C_word*)t0)[6]));
/* optimizer.scm: 198  walk */
t8=((C_word*)((C_word*)t0)[4])[1];
f_1799(3,t8,((C_word*)t0)[3],t7);}
else{
t2=((C_word*)t0)[3];
f_1822(2,t2,((C_word*)t0)[2]);}}

/* k1820 in k1811 in walk in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 188  simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1707(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_1707(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1707,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=(C_word)C_slot(t4,C_fix(1));
/* optimizer.scm: 169  ##sys#hash-table-ref */
t6=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,C_retrieve(lf[20]),t5);}

/* k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1714,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1722,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 170  any */
t4=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,t1);}
else{
t3=t2;
f_1714(2,t3,C_SCHEME_FALSE);}}

/* a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1722(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1722,3,t0,t1,t2);}
t3=(C_word)C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1732,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_i_car(t2);
/* optimizer.scm: 172  match-node */
t6=C_retrieve(lf[28]);
((C_proc5)C_retrieve_proc(t6))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1732,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1738,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_caddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1781,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1780 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1781,3,t0,t1,t2);}
t3=(C_word)C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_cdr(t3));}

/* k1777 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1736 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1738,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1744,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 175  caar */
t3=*((C_word*)lf[26]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1742 in k1736 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=(C_word)C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1750,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=(C_word)C_i_cdr(t2);
t5=(C_word)C_fixnum_increase(t4);
t6=t3;
f_1750(t6,(C_word)C_i_set_cdr(t2,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1771,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 179  alist-cons */
t5=C_retrieve(lf[25]);
((C_proc5)C_retrieve_proc(t5))(5,t5,t4,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k1769 in k1742 in k1736 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1750(t3,t2);}

/* k1748 in k1742 in k1736 in k1730 in a1721 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_1750(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=f_1703(((C_word*)t0)[5]);
/* optimizer.scm: 181  simplify */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1707(t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1712 in k1709 in simplify in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* touch in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static C_word C_fcall f_1703(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* node-value in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static C_word C_fcall f_1693(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=(C_word)C_slot(t1,C_fix(2));
return((C_word)C_i_car(t2));}

/* constant-node? in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
t3=(C_word)C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_eqp(lf[24],t3));}

/* test in ##compiler#perform-high-level-optimizations in k1669 in k1461 in k1458 in k1455 */
static void C_fcall f_1677(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1677,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm: 163  get */
t4=C_retrieve(lf[23]);
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1468,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1489,a[2]=t2,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm: 95   debugging */
t9=C_retrieve(lf[4]);
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,lf[18],lf[19]);}

/* k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm: 96   call-with-current-continuation */
t4=*((C_word*)lf[17]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1501,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1516,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
/* optimizer.scm: 131  scan */
t9=((C_word*)t6)[1];
f_1516(t9,t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_fcall f_1516(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1516,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=(C_word)C_slot(t4,C_fix(2));
t6=t2;
t7=(C_word)C_slot(t6,C_fix(3));
t8=t2;
t9=(C_word)C_slot(t8,C_fix(1));
t10=(C_word)C_eqp(t9,lf[8]);
if(C_truep(t10)){
t11=(C_word)C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1541,a[2]=t1,a[3]=((C_word*)t0)[7],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_word)C_i_memq(t11,t3))){
t13=t12;
f_1541(t13,C_SCHEME_FALSE);}
else{
t13=(C_word)C_i_memq(t11,((C_word*)((C_word*)t0)[6])[1]);
t14=t12;
f_1541(t14,(C_word)C_i_not(t13));}}
else{
t11=(C_word)C_eqp(t9,lf[9]);
t12=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t9,a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t7,a[9]=t1,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t11)){
t13=t12;
f_1568(t13,t11);}
else{
t13=(C_word)C_eqp(t9,lf[15]);
t14=t12;
f_1568(t14,(C_truep(t13)?t13:(C_word)C_eqp(t9,lf[16])));}}}

/* k1566 in scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_fcall f_1568(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1568,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1571,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 113  scan */
t4=((C_word*)((C_word*)t0)[7])[1];
f_1516(t4,t2,t3,((C_word*)t0)[6]);}
else{
t2=(C_word)C_eqp(((C_word*)t0)[5],lf[10]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1587,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 117  scan */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1516(t5,t3,t4,((C_word*)t0)[6]);}
else{
t3=(C_word)C_eqp(((C_word*)t0)[5],lf[11]);
t4=(C_truep(t3)?t3:(C_word)C_eqp(((C_word*)t0)[5],lf[12]));
if(C_truep(t4)){
t5=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}
else{
t5=(C_word)C_eqp(((C_word*)t0)[5],lf[13]);
if(C_truep(t5)){
/* optimizer.scm: 122  return */
t6=((C_word*)t0)[10];
((C_proc3)C_retrieve_proc(t6))(3,t6,((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t6=(C_word)C_eqp(((C_word*)t0)[5],lf[14]);
if(C_truep(t6)){
t7=(C_word)C_i_car(((C_word*)t0)[4]);
t8=(C_truep((C_word)C_i_memq(t7,((C_word*)t0)[6]))?C_SCHEME_UNDEFINED:f_1471(C_a_i(&a,3),((C_word*)t0)[3],t7));
t9=(C_word)C_i_car(((C_word*)t0)[8]);
/* optimizer.scm: 127  scan */
t10=((C_word*)((C_word*)t0)[7])[1];
f_1516(t10,((C_word*)t0)[9],t9,((C_word*)t0)[6]);}
else{
/* optimizer.scm: 129  scan-each */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1504(t7,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[6]);}}}}}}

/* k1585 in k1566 in scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1587,2,t0,t1);}
t2=(C_word)C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1598,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm: 118  append */
t4=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1596 in k1585 in k1566 in scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 118  scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1516(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1569 in k1566 in scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm: 114  return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1539 in scan in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_fcall f_1541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* scan-each in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_fcall f_1504(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1504,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1510,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a1509 in scan-each in a1500 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1510,3,t0,t1,t2);}
/* optimizer.scm: 100  scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1516(t3,t1,t2,((C_word*)t0)[2]);}

/* k1490 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm: 132  debugging */
t3=C_retrieve(lf[4]);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[5],lf[6],((C_word*)((C_word*)t0)[2])[1]);}

/* k1493 in k1490 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1499,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm: 133  append */
t3=*((C_word*)lf[3]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],C_retrieve(lf[2]));}

/* k1497 in k1493 in k1490 in k1487 in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static void C_ccall f_1499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[2]+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k1461 in k1458 in k1455 */
static C_word C_fcall f_1471(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep((C_word)C_i_memq(t1,((C_word*)((C_word*)t0)[3])[1]))){
return(C_SCHEME_UNDEFINED);}
else{
t2=(C_word)C_a_i_cons(&a,2,t1,((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[614] = {
{"topleveloptimizer.scm",(void*)C_optimizer_toplevel},
{"f_1457optimizer.scm",(void*)f_1457},
{"f_1460optimizer.scm",(void*)f_1460},
{"f_1463optimizer.scm",(void*)f_1463},
{"f_1671optimizer.scm",(void*)f_1671},
{"f_9555optimizer.scm",(void*)f_9555},
{"f_9563optimizer.scm",(void*)f_9563},
{"f_9568optimizer.scm",(void*)f_9568},
{"f_9613optimizer.scm",(void*)f_9613},
{"f_9617optimizer.scm",(void*)f_9617},
{"f_9578optimizer.scm",(void*)f_9578},
{"f_9602optimizer.scm",(void*)f_9602},
{"f_9587optimizer.scm",(void*)f_9587},
{"f_3613optimizer.scm",(void*)f_3613},
{"f_8926optimizer.scm",(void*)f_8926},
{"f_8960optimizer.scm",(void*)f_8960},
{"f_9002optimizer.scm",(void*)f_9002},
{"f_9012optimizer.scm",(void*)f_9012},
{"f_9076optimizer.scm",(void*)f_9076},
{"f_9105optimizer.scm",(void*)f_9105},
{"f_9228optimizer.scm",(void*)f_9228},
{"f_9121optimizer.scm",(void*)f_9121},
{"f_9168optimizer.scm",(void*)f_9168},
{"f_9158optimizer.scm",(void*)f_9158},
{"f_9166optimizer.scm",(void*)f_9166},
{"f_9270optimizer.scm",(void*)f_9270},
{"f_9283optimizer.scm",(void*)f_9283},
{"f_9318optimizer.scm",(void*)f_9318},
{"f_9302optimizer.scm",(void*)f_9302},
{"f_9306optimizer.scm",(void*)f_9306},
{"f_9295optimizer.scm",(void*)f_9295},
{"f_9392optimizer.scm",(void*)f_9392},
{"f_9405optimizer.scm",(void*)f_9405},
{"f_9411optimizer.scm",(void*)f_9411},
{"f_9457optimizer.scm",(void*)f_9457},
{"f_9449optimizer.scm",(void*)f_9449},
{"f_9433optimizer.scm",(void*)f_9433},
{"f_9437optimizer.scm",(void*)f_9437},
{"f_9441optimizer.scm",(void*)f_9441},
{"f_3616optimizer.scm",(void*)f_3616},
{"f_8744optimizer.scm",(void*)f_8744},
{"f_8766optimizer.scm",(void*)f_8766},
{"f_8821optimizer.scm",(void*)f_8821},
{"f_8791optimizer.scm",(void*)f_8791},
{"f_8813optimizer.scm",(void*)f_8813},
{"f_8817optimizer.scm",(void*)f_8817},
{"f_8809optimizer.scm",(void*)f_8809},
{"f_8789optimizer.scm",(void*)f_8789},
{"f_8855optimizer.scm",(void*)f_8855},
{"f_8869optimizer.scm",(void*)f_8869},
{"f_3619optimizer.scm",(void*)f_3619},
{"f_3947optimizer.scm",(void*)f_3947},
{"f_7084optimizer.scm",(void*)f_7084},
{"f_8631optimizer.scm",(void*)f_8631},
{"f_8634optimizer.scm",(void*)f_8634},
{"f_8637optimizer.scm",(void*)f_8637},
{"f_8640optimizer.scm",(void*)f_8640},
{"f_8643optimizer.scm",(void*)f_8643},
{"f_8646optimizer.scm",(void*)f_8646},
{"f_8723optimizer.scm",(void*)f_8723},
{"f_8649optimizer.scm",(void*)f_8649},
{"f_8652optimizer.scm",(void*)f_8652},
{"f_8655optimizer.scm",(void*)f_8655},
{"f_8717optimizer.scm",(void*)f_8717},
{"f_8658optimizer.scm",(void*)f_8658},
{"f_8661optimizer.scm",(void*)f_8661},
{"f_8714optimizer.scm",(void*)f_8714},
{"f_7693optimizer.scm",(void*)f_7693},
{"f_7711optimizer.scm",(void*)f_7711},
{"f_7717optimizer.scm",(void*)f_7717},
{"f_7697optimizer.scm",(void*)f_7697},
{"f_8664optimizer.scm",(void*)f_8664},
{"f_8706optimizer.scm",(void*)f_8706},
{"f_8704optimizer.scm",(void*)f_8704},
{"f_8667optimizer.scm",(void*)f_8667},
{"f_8670optimizer.scm",(void*)f_8670},
{"f_8673optimizer.scm",(void*)f_8673},
{"f_8697optimizer.scm",(void*)f_8697},
{"f_8676optimizer.scm",(void*)f_8676},
{"f_8679optimizer.scm",(void*)f_8679},
{"f_8682optimizer.scm",(void*)f_8682},
{"f_8685optimizer.scm",(void*)f_8685},
{"f_8688optimizer.scm",(void*)f_8688},
{"f_8691optimizer.scm",(void*)f_8691},
{"f_8484optimizer.scm",(void*)f_8484},
{"f_8490optimizer.scm",(void*)f_8490},
{"f_8602optimizer.scm",(void*)f_8602},
{"f_8611optimizer.scm",(void*)f_8611},
{"f_8614optimizer.scm",(void*)f_8614},
{"f_8509optimizer.scm",(void*)f_8509},
{"f_8514optimizer.scm",(void*)f_8514},
{"f_8555optimizer.scm",(void*)f_8555},
{"f_8552optimizer.scm",(void*)f_8552},
{"f_8537optimizer.scm",(void*)f_8537},
{"f_8548optimizer.scm",(void*)f_8548},
{"f_8544optimizer.scm",(void*)f_8544},
{"f_8397optimizer.scm",(void*)f_8397},
{"f_8403optimizer.scm",(void*)f_8403},
{"f_8459optimizer.scm",(void*)f_8459},
{"f_8455optimizer.scm",(void*)f_8455},
{"f_8425optimizer.scm",(void*)f_8425},
{"f_8147optimizer.scm",(void*)f_8147},
{"f_8161optimizer.scm",(void*)f_8161},
{"f_8168optimizer.scm",(void*)f_8168},
{"f_8181optimizer.scm",(void*)f_8181},
{"f_8188optimizer.scm",(void*)f_8188},
{"f_8191optimizer.scm",(void*)f_8191},
{"f_8287optimizer.scm",(void*)f_8287},
{"f_8373optimizer.scm",(void*)f_8373},
{"f_8392optimizer.scm",(void*)f_8392},
{"f_8388optimizer.scm",(void*)f_8388},
{"f_8354optimizer.scm",(void*)f_8354},
{"f_8343optimizer.scm",(void*)f_8343},
{"f_8330optimizer.scm",(void*)f_8330},
{"f_8313optimizer.scm",(void*)f_8313},
{"f_8306optimizer.scm",(void*)f_8306},
{"f_8272optimizer.scm",(void*)f_8272},
{"f_8194optimizer.scm",(void*)f_8194},
{"f_8243optimizer.scm",(void*)f_8243},
{"f_8231optimizer.scm",(void*)f_8231},
{"f_8227optimizer.scm",(void*)f_8227},
{"f_8159optimizer.scm",(void*)f_8159},
{"f_7946optimizer.scm",(void*)f_7946},
{"f_8133optimizer.scm",(void*)f_8133},
{"f_8011optimizer.scm",(void*)f_8011},
{"f_8088optimizer.scm",(void*)f_8088},
{"f_8093optimizer.scm",(void*)f_8093},
{"f_8131optimizer.scm",(void*)f_8131},
{"f_7955optimizer.scm",(void*)f_7955},
{"f_7993optimizer.scm",(void*)f_7993},
{"f_7998optimizer.scm",(void*)f_7998},
{"f_7975optimizer.scm",(void*)f_7975},
{"f_7953optimizer.scm",(void*)f_7953},
{"f_8123optimizer.scm",(void*)f_8123},
{"f_8109optimizer.scm",(void*)f_8109},
{"f_8107optimizer.scm",(void*)f_8107},
{"f_8013optimizer.scm",(void*)f_8013},
{"f_8081optimizer.scm",(void*)f_8081},
{"f_8079optimizer.scm",(void*)f_8079},
{"f_8067optimizer.scm",(void*)f_8067},
{"f_8033optimizer.scm",(void*)f_8033},
{"f_8057optimizer.scm",(void*)f_8057},
{"f_8055optimizer.scm",(void*)f_8055},
{"f_8051optimizer.scm",(void*)f_8051},
{"f_8043optimizer.scm",(void*)f_8043},
{"f_7727optimizer.scm",(void*)f_7727},
{"f_7733optimizer.scm",(void*)f_7733},
{"f_7752optimizer.scm",(void*)f_7752},
{"f_7919optimizer.scm",(void*)f_7919},
{"f_7849optimizer.scm",(void*)f_7849},
{"f_7865optimizer.scm",(void*)f_7865},
{"f_7895optimizer.scm",(void*)f_7895},
{"f_7899optimizer.scm",(void*)f_7899},
{"f_7885optimizer.scm",(void*)f_7885},
{"f_7838optimizer.scm",(void*)f_7838},
{"f_7843optimizer.scm",(void*)f_7843},
{"f_7814optimizer.scm",(void*)f_7814},
{"f_7826optimizer.scm",(void*)f_7826},
{"f_7763optimizer.scm",(void*)f_7763},
{"f_7784optimizer.scm",(void*)f_7784},
{"f_7781optimizer.scm",(void*)f_7781},
{"f_7731optimizer.scm",(void*)f_7731},
{"f_7483optimizer.scm",(void*)f_7483},
{"f_7489optimizer.scm",(void*)f_7489},
{"f_7508optimizer.scm",(void*)f_7508},
{"f_7610optimizer.scm",(void*)f_7610},
{"f_7601optimizer.scm",(void*)f_7601},
{"f_7567optimizer.scm",(void*)f_7567},
{"f_7576optimizer.scm",(void*)f_7576},
{"f_7588optimizer.scm",(void*)f_7588},
{"f_7519optimizer.scm",(void*)f_7519},
{"f_7540optimizer.scm",(void*)f_7540},
{"f_7537optimizer.scm",(void*)f_7537},
{"f_7487optimizer.scm",(void*)f_7487},
{"f_7384optimizer.scm",(void*)f_7384},
{"f_7390optimizer.scm",(void*)f_7390},
{"f_7434optimizer.scm",(void*)f_7434},
{"f_7439optimizer.scm",(void*)f_7439},
{"f_7446optimizer.scm",(void*)f_7446},
{"f_7473optimizer.scm",(void*)f_7473},
{"f_7469optimizer.scm",(void*)f_7469},
{"f_7461optimizer.scm",(void*)f_7461},
{"f_7459optimizer.scm",(void*)f_7459},
{"f_7424optimizer.scm",(void*)f_7424},
{"f_7402optimizer.scm",(void*)f_7402},
{"f_7409optimizer.scm",(void*)f_7409},
{"f_7187optimizer.scm",(void*)f_7187},
{"f_7341optimizer.scm",(void*)f_7341},
{"f_7366optimizer.scm",(void*)f_7366},
{"f_7356optimizer.scm",(void*)f_7356},
{"f_7360optimizer.scm",(void*)f_7360},
{"f_7339optimizer.scm",(void*)f_7339},
{"f_7190optimizer.scm",(void*)f_7190},
{"f_7329optimizer.scm",(void*)f_7329},
{"f_7312optimizer.scm",(void*)f_7312},
{"f_7324optimizer.scm",(void*)f_7324},
{"f_7258optimizer.scm",(void*)f_7258},
{"f_7282optimizer.scm",(void*)f_7282},
{"f_7276optimizer.scm",(void*)f_7276},
{"f_7240optimizer.scm",(void*)f_7240},
{"f_7215optimizer.scm",(void*)f_7215},
{"f_7218optimizer.scm",(void*)f_7218},
{"f_7223optimizer.scm",(void*)f_7223},
{"f_7087optimizer.scm",(void*)f_7087},
{"f_7093optimizer.scm",(void*)f_7093},
{"f_7124optimizer.scm",(void*)f_7124},
{"f_7128optimizer.scm",(void*)f_7128},
{"f_7132optimizer.scm",(void*)f_7132},
{"f_7091optimizer.scm",(void*)f_7091},
{"f_5949optimizer.scm",(void*)f_5949},
{"f_7079optimizer.scm",(void*)f_7079},
{"f_7082optimizer.scm",(void*)f_7082},
{"f_5952optimizer.scm",(void*)f_5952},
{"f_6108optimizer.scm",(void*)f_6108},
{"f_6088optimizer.scm",(void*)f_6088},
{"f_6062optimizer.scm",(void*)f_6062},
{"f_6008optimizer.scm",(void*)f_6008},
{"f_6014optimizer.scm",(void*)f_6014},
{"f_6020optimizer.scm",(void*)f_6020},
{"f_5977optimizer.scm",(void*)f_5977},
{"f_6114optimizer.scm",(void*)f_6114},
{"f_6524optimizer.scm",(void*)f_6524},
{"f_6531optimizer.scm",(void*)f_6531},
{"f_6117optimizer.scm",(void*)f_6117},
{"f_6511optimizer.scm",(void*)f_6511},
{"f_6487optimizer.scm",(void*)f_6487},
{"f_6498optimizer.scm",(void*)f_6498},
{"f_6454optimizer.scm",(void*)f_6454},
{"f_6393optimizer.scm",(void*)f_6393},
{"f_6365optimizer.scm",(void*)f_6365},
{"f_6370optimizer.scm",(void*)f_6370},
{"f_6312optimizer.scm",(void*)f_6312},
{"f_6318optimizer.scm",(void*)f_6318},
{"f_6323optimizer.scm",(void*)f_6323},
{"f_6271optimizer.scm",(void*)f_6271},
{"f_6277optimizer.scm",(void*)f_6277},
{"f_6282optimizer.scm",(void*)f_6282},
{"f_6255optimizer.scm",(void*)f_6255},
{"f_6251optimizer.scm",(void*)f_6251},
{"f_6221optimizer.scm",(void*)f_6221},
{"f_6184optimizer.scm",(void*)f_6184},
{"f_6200optimizer.scm",(void*)f_6200},
{"f_6166optimizer.scm",(void*)f_6166},
{"f_6533optimizer.scm",(void*)f_6533},
{"f_7069optimizer.scm",(void*)f_7069},
{"f_7067optimizer.scm",(void*)f_7067},
{"f_6537optimizer.scm",(void*)f_6537},
{"f_6547optimizer.scm",(void*)f_6547},
{"f_7041optimizer.scm",(void*)f_7041},
{"f_6553optimizer.scm",(void*)f_6553},
{"f_6559optimizer.scm",(void*)f_6559},
{"f_6562optimizer.scm",(void*)f_6562},
{"f_6568optimizer.scm",(void*)f_6568},
{"f_6744optimizer.scm",(void*)f_6744},
{"f_6966optimizer.scm",(void*)f_6966},
{"f_6969optimizer.scm",(void*)f_6969},
{"f_6919optimizer.scm",(void*)f_6919},
{"f_6922optimizer.scm",(void*)f_6922},
{"f_6788optimizer.scm",(void*)f_6788},
{"f_6843optimizer.scm",(void*)f_6843},
{"f_6846optimizer.scm",(void*)f_6846},
{"f_6873optimizer.scm",(void*)f_6873},
{"f_6849optimizer.scm",(void*)f_6849},
{"f_6852optimizer.scm",(void*)f_6852},
{"f_6797optimizer.scm",(void*)f_6797},
{"f_6800optimizer.scm",(void*)f_6800},
{"f_6803optimizer.scm",(void*)f_6803},
{"f_6571optimizer.scm",(void*)f_6571},
{"f_6726optimizer.scm",(void*)f_6726},
{"f_6724optimizer.scm",(void*)f_6724},
{"f_6667optimizer.scm",(void*)f_6667},
{"f_6677optimizer.scm",(void*)f_6677},
{"f_6574optimizer.scm",(void*)f_6574},
{"f_6586optimizer.scm",(void*)f_6586},
{"f_6625optimizer.scm",(void*)f_6625},
{"f_6589optimizer.scm",(void*)f_6589},
{"f_6592optimizer.scm",(void*)f_6592},
{"f_6597optimizer.scm",(void*)f_6597},
{"f_6623optimizer.scm",(void*)f_6623},
{"f_6604optimizer.scm",(void*)f_6604},
{"f_3969optimizer.scm",(void*)f_3969},
{"f_5817optimizer.scm",(void*)f_5817},
{"f_5820optimizer.scm",(void*)f_5820},
{"f_5842optimizer.scm",(void*)f_5842},
{"f_5854optimizer.scm",(void*)f_5854},
{"f_5868optimizer.scm",(void*)f_5868},
{"f_5917optimizer.scm",(void*)f_5917},
{"f_3994optimizer.scm",(void*)f_3994},
{"f_5888optimizer.scm",(void*)f_5888},
{"f_5892optimizer.scm",(void*)f_5892},
{"f_5862optimizer.scm",(void*)f_5862},
{"f_5848optimizer.scm",(void*)f_5848},
{"f_5846optimizer.scm",(void*)f_5846},
{"f_5835optimizer.scm",(void*)f_5835},
{"f_5754optimizer.scm",(void*)f_5754},
{"f_5757optimizer.scm",(void*)f_5757},
{"f_5789optimizer.scm",(void*)f_5789},
{"f_5776optimizer.scm",(void*)f_5776},
{"f_5600optimizer.scm",(void*)f_5600},
{"f_5603optimizer.scm",(void*)f_5603},
{"f_5609optimizer.scm",(void*)f_5609},
{"f_5693optimizer.scm",(void*)f_5693},
{"f_5618optimizer.scm",(void*)f_5618},
{"f_5662optimizer.scm",(void*)f_5662},
{"f_5660optimizer.scm",(void*)f_5660},
{"f_5634optimizer.scm",(void*)f_5634},
{"f_5527optimizer.scm",(void*)f_5527},
{"f_5530optimizer.scm",(void*)f_5530},
{"f_5558optimizer.scm",(void*)f_5558},
{"f_5570optimizer.scm",(void*)f_5570},
{"f_5548optimizer.scm",(void*)f_5548},
{"f_5543optimizer.scm",(void*)f_5543},
{"f_5379optimizer.scm",(void*)f_5379},
{"f_5382optimizer.scm",(void*)f_5382},
{"f_5463optimizer.scm",(void*)f_5463},
{"f_5391optimizer.scm",(void*)f_5391},
{"f_5444optimizer.scm",(void*)f_5444},
{"f_5442optimizer.scm",(void*)f_5442},
{"f_5407optimizer.scm",(void*)f_5407},
{"f_5344optimizer.scm",(void*)f_5344},
{"f_5347optimizer.scm",(void*)f_5347},
{"f_5357optimizer.scm",(void*)f_5357},
{"f_5276optimizer.scm",(void*)f_5276},
{"f_5279optimizer.scm",(void*)f_5279},
{"f_5299optimizer.scm",(void*)f_5299},
{"f_5197optimizer.scm",(void*)f_5197},
{"f_5200optimizer.scm",(void*)f_5200},
{"f_5230optimizer.scm",(void*)f_5230},
{"f_5104optimizer.scm",(void*)f_5104},
{"f_5107optimizer.scm",(void*)f_5107},
{"f_5126optimizer.scm",(void*)f_5126},
{"f_5119optimizer.scm",(void*)f_5119},
{"f_5021optimizer.scm",(void*)f_5021},
{"f_5024optimizer.scm",(void*)f_5024},
{"f_4956optimizer.scm",(void*)f_4956},
{"f_4959optimizer.scm",(void*)f_4959},
{"f_4974optimizer.scm",(void*)f_4974},
{"f_4977optimizer.scm",(void*)f_4977},
{"f_4880optimizer.scm",(void*)f_4880},
{"f_4883optimizer.scm",(void*)f_4883},
{"f_4926optimizer.scm",(void*)f_4926},
{"f_4919optimizer.scm",(void*)f_4919},
{"f_4815optimizer.scm",(void*)f_4815},
{"f_4818optimizer.scm",(void*)f_4818},
{"f_4830optimizer.scm",(void*)f_4830},
{"f_4843optimizer.scm",(void*)f_4843},
{"f_4836optimizer.scm",(void*)f_4836},
{"f_4728optimizer.scm",(void*)f_4728},
{"f_4750optimizer.scm",(void*)f_4750},
{"f_4758optimizer.scm",(void*)f_4758},
{"f_4762optimizer.scm",(void*)f_4762},
{"f_4584optimizer.scm",(void*)f_4584},
{"f_4606optimizer.scm",(void*)f_4606},
{"f_4609optimizer.scm",(void*)f_4609},
{"f_4668optimizer.scm",(void*)f_4668},
{"f_4612optimizer.scm",(void*)f_4612},
{"f_4615optimizer.scm",(void*)f_4615},
{"f_4646optimizer.scm",(void*)f_4646},
{"f_4644optimizer.scm",(void*)f_4644},
{"f_4620optimizer.scm",(void*)f_4620},
{"f_4600optimizer.scm",(void*)f_4600},
{"f_4557optimizer.scm",(void*)f_4557},
{"f_4560optimizer.scm",(void*)f_4560},
{"f_4496optimizer.scm",(void*)f_4496},
{"f_4499optimizer.scm",(void*)f_4499},
{"f_4523optimizer.scm",(void*)f_4523},
{"f_4512optimizer.scm",(void*)f_4512},
{"f_4431optimizer.scm",(void*)f_4431},
{"f_4338optimizer.scm",(void*)f_4338},
{"f_4341optimizer.scm",(void*)f_4341},
{"f_4383optimizer.scm",(void*)f_4383},
{"f_4282optimizer.scm",(void*)f_4282},
{"f_4295optimizer.scm",(void*)f_4295},
{"f_4303optimizer.scm",(void*)f_4303},
{"f_4238optimizer.scm",(void*)f_4238},
{"f_4241optimizer.scm",(void*)f_4241},
{"f_4251optimizer.scm",(void*)f_4251},
{"f_4134optimizer.scm",(void*)f_4134},
{"f_4137optimizer.scm",(void*)f_4137},
{"f_4194optimizer.scm",(void*)f_4194},
{"f_4165optimizer.scm",(void*)f_4165},
{"f_4162optimizer.scm",(void*)f_4162},
{"f_4026optimizer.scm",(void*)f_4026},
{"f_4089optimizer.scm",(void*)f_4089},
{"f_4029optimizer.scm",(void*)f_4029},
{"f_3972optimizer.scm",(void*)f_3972},
{"f_3949optimizer.scm",(void*)f_3949},
{"f_3953optimizer.scm",(void*)f_3953},
{"f_3963optimizer.scm",(void*)f_3963},
{"f_3621optimizer.scm",(void*)f_3621},
{"f_3625optimizer.scm",(void*)f_3625},
{"f_3934optimizer.scm",(void*)f_3934},
{"f_3943optimizer.scm",(void*)f_3943},
{"f_3939optimizer.scm",(void*)f_3939},
{"f_3672optimizer.scm",(void*)f_3672},
{"f_3876optimizer.scm",(void*)f_3876},
{"f_3908optimizer.scm",(void*)f_3908},
{"f_3921optimizer.scm",(void*)f_3921},
{"f_3886optimizer.scm",(void*)f_3886},
{"f_3902optimizer.scm",(void*)f_3902},
{"f_3890optimizer.scm",(void*)f_3890},
{"f_3894optimizer.scm",(void*)f_3894},
{"f_3675optimizer.scm",(void*)f_3675},
{"f_3817optimizer.scm",(void*)f_3817},
{"f_3860optimizer.scm",(void*)f_3860},
{"f_3866optimizer.scm",(void*)f_3866},
{"f_3824optimizer.scm",(void*)f_3824},
{"f_3834optimizer.scm",(void*)f_3834},
{"f_3847optimizer.scm",(void*)f_3847},
{"f_3832optimizer.scm",(void*)f_3832},
{"f_3828optimizer.scm",(void*)f_3828},
{"f_3678optimizer.scm",(void*)f_3678},
{"f_3681optimizer.scm",(void*)f_3681},
{"f_3701optimizer.scm",(void*)f_3701},
{"f_3714optimizer.scm",(void*)f_3714},
{"f_3757optimizer.scm",(void*)f_3757},
{"f_3789optimizer.scm",(void*)f_3789},
{"f_3755optimizer.scm",(void*)f_3755},
{"f_3737optimizer.scm",(void*)f_3737},
{"f_3684optimizer.scm",(void*)f_3684},
{"f_3693optimizer.scm",(void*)f_3693},
{"f_3627optimizer.scm",(void*)f_3627},
{"f_3633optimizer.scm",(void*)f_3633},
{"f_3657optimizer.scm",(void*)f_3657},
{"f_3606optimizer.scm",(void*)f_3606},
{"f_3145optimizer.scm",(void*)f_3145},
{"f_3159optimizer.scm",(void*)f_3159},
{"f_3394optimizer.scm",(void*)f_3394},
{"f_3601optimizer.scm",(void*)f_3601},
{"f_3399optimizer.scm",(void*)f_3399},
{"f_3590optimizer.scm",(void*)f_3590},
{"f_3412optimizer.scm",(void*)f_3412},
{"f_3415optimizer.scm",(void*)f_3415},
{"f_3421optimizer.scm",(void*)f_3421},
{"f_3436optimizer.scm",(void*)f_3436},
{"f_3442optimizer.scm",(void*)f_3442},
{"f_3448optimizer.scm",(void*)f_3448},
{"f_3457optimizer.scm",(void*)f_3457},
{"f_3464optimizer.scm",(void*)f_3464},
{"f_3467optimizer.scm",(void*)f_3467},
{"f_3485optimizer.scm",(void*)f_3485},
{"f_3470optimizer.scm",(void*)f_3470},
{"f_3162optimizer.scm",(void*)f_3162},
{"f_3176optimizer.scm",(void*)f_3176},
{"f_3183optimizer.scm",(void*)f_3183},
{"f_3388optimizer.scm",(void*)f_3388},
{"f_3188optimizer.scm",(void*)f_3188},
{"f_3201optimizer.scm",(void*)f_3201},
{"f_3377optimizer.scm",(void*)f_3377},
{"f_3204optimizer.scm",(void*)f_3204},
{"f_3351optimizer.scm",(void*)f_3351},
{"f_3349optimizer.scm",(void*)f_3349},
{"f_3210optimizer.scm",(void*)f_3210},
{"f_3222optimizer.scm",(void*)f_3222},
{"f_3228optimizer.scm",(void*)f_3228},
{"f_3237optimizer.scm",(void*)f_3237},
{"f_3243optimizer.scm",(void*)f_3243},
{"f_3246optimizer.scm",(void*)f_3246},
{"f_3264optimizer.scm",(void*)f_3264},
{"f_3249optimizer.scm",(void*)f_3249},
{"f_3165optimizer.scm",(void*)f_3165},
{"f_3168optimizer.scm",(void*)f_3168},
{"f_3152optimizer.scm",(void*)f_3152},
{"f_3148optimizer.scm",(void*)f_3148},
{"f_1674optimizer.scm",(void*)f_1674},
{"f_3049optimizer.scm",(void*)f_3049},
{"f_3055optimizer.scm",(void*)f_3055},
{"f_3059optimizer.scm",(void*)f_3059},
{"f_3062optimizer.scm",(void*)f_3062},
{"f_3098optimizer.scm",(void*)f_3098},
{"f_3103optimizer.scm",(void*)f_3103},
{"f_3107optimizer.scm",(void*)f_3107},
{"f_3065optimizer.scm",(void*)f_3065},
{"f_3068optimizer.scm",(void*)f_3068},
{"f_3071optimizer.scm",(void*)f_3071},
{"f_3074optimizer.scm",(void*)f_3074},
{"f_3030optimizer.scm",(void*)f_3030},
{"f_3034optimizer.scm",(void*)f_3034},
{"f_3040optimizer.scm",(void*)f_3040},
{"f_2015optimizer.scm",(void*)f_2015},
{"f_2940optimizer.scm",(void*)f_2940},
{"f_2943optimizer.scm",(void*)f_2943},
{"f_3022optimizer.scm",(void*)f_3022},
{"f_2984optimizer.scm",(void*)f_2984},
{"f_3005optimizer.scm",(void*)f_3005},
{"f_2997optimizer.scm",(void*)f_2997},
{"f_2955optimizer.scm",(void*)f_2955},
{"f_2974optimizer.scm",(void*)f_2974},
{"f_2961optimizer.scm",(void*)f_2961},
{"f_2915optimizer.scm",(void*)f_2915},
{"f_2890optimizer.scm",(void*)f_2890},
{"f_2348optimizer.scm",(void*)f_2348},
{"f_2357optimizer.scm",(void*)f_2357},
{"f_2531optimizer.scm",(void*)f_2531},
{"f_2542optimizer.scm",(void*)f_2542},
{"f_2841optimizer.scm",(void*)f_2841},
{"f_2847optimizer.scm",(void*)f_2847},
{"f_2552optimizer.scm",(void*)f_2552},
{"f_2589optimizer.scm",(void*)f_2589},
{"f_2831optimizer.scm",(void*)f_2831},
{"f_2748optimizer.scm",(void*)f_2748},
{"f_2763optimizer.scm",(void*)f_2763},
{"f_2774optimizer.scm",(void*)f_2774},
{"f_2801optimizer.scm",(void*)f_2801},
{"f_2793optimizer.scm",(void*)f_2793},
{"f_2778optimizer.scm",(void*)f_2778},
{"f_2768optimizer.scm",(void*)f_2768},
{"f_2603optimizer.scm",(void*)f_2603},
{"f_2636optimizer.scm",(void*)f_2636},
{"f_2642optimizer.scm",(void*)f_2642},
{"f_2648optimizer.scm",(void*)f_2648},
{"f_2685optimizer.scm",(void*)f_2685},
{"f_2661optimizer.scm",(void*)f_2661},
{"f_2665optimizer.scm",(void*)f_2665},
{"f_2630optimizer.scm",(void*)f_2630},
{"f_2619optimizer.scm",(void*)f_2619},
{"f_2555optimizer.scm",(void*)f_2555},
{"f_2558optimizer.scm",(void*)f_2558},
{"f_2561optimizer.scm",(void*)f_2561},
{"f_2571optimizer.scm",(void*)f_2571},
{"f_2517optimizer.scm",(void*)f_2517},
{"f_2420optimizer.scm",(void*)f_2420},
{"f_2438optimizer.scm",(void*)f_2438},
{"f_2495optimizer.scm",(void*)f_2495},
{"f_2487optimizer.scm",(void*)f_2487},
{"f_2441optimizer.scm",(void*)f_2441},
{"f_2466optimizer.scm",(void*)f_2466},
{"f_2464optimizer.scm",(void*)f_2464},
{"f_2450optimizer.scm",(void*)f_2450},
{"f_2399optimizer.scm",(void*)f_2399},
{"f_2366optimizer.scm",(void*)f_2366},
{"f_2369optimizer.scm",(void*)f_2369},
{"f_2379optimizer.scm",(void*)f_2379},
{"f_2172optimizer.scm",(void*)f_2172},
{"f_2264optimizer.scm",(void*)f_2264},
{"f_2269optimizer.scm",(void*)f_2269},
{"f_2276optimizer.scm",(void*)f_2276},
{"f_2305optimizer.scm",(void*)f_2305},
{"f_2289optimizer.scm",(void*)f_2289},
{"f_2177optimizer.scm",(void*)f_2177},
{"f_2195optimizer.scm",(void*)f_2195},
{"f_2202optimizer.scm",(void*)f_2202},
{"f_2238optimizer.scm",(void*)f_2238},
{"f_2241optimizer.scm",(void*)f_2241},
{"f_2231optimizer.scm",(void*)f_2231},
{"f_2215optimizer.scm",(void*)f_2215},
{"f_2183optimizer.scm",(void*)f_2183},
{"f_2189optimizer.scm",(void*)f_2189},
{"f_2115optimizer.scm",(void*)f_2115},
{"f_2141optimizer.scm",(void*)f_2141},
{"f_2150optimizer.scm",(void*)f_2150},
{"f_2157optimizer.scm",(void*)f_2157},
{"f_2118optimizer.scm",(void*)f_2118},
{"f_2135optimizer.scm",(void*)f_2135},
{"f_2040optimizer.scm",(void*)f_2040},
{"f_2044optimizer.scm",(void*)f_2044},
{"f_2056optimizer.scm",(void*)f_2056},
{"f_2079optimizer.scm",(void*)f_2079},
{"f_2062optimizer.scm",(void*)f_2062},
{"f_2073optimizer.scm",(void*)f_2073},
{"f_1799optimizer.scm",(void*)f_1799},
{"f_1813optimizer.scm",(void*)f_1813},
{"f_1980optimizer.scm",(void*)f_1980},
{"f_1983optimizer.scm",(void*)f_1983},
{"f_1989optimizer.scm",(void*)f_1989},
{"f_1883optimizer.scm",(void*)f_1883},
{"f_1965optimizer.scm",(void*)f_1965},
{"f_1963optimizer.scm",(void*)f_1963},
{"f_1894optimizer.scm",(void*)f_1894},
{"f_1917optimizer.scm",(void*)f_1917},
{"f_1949optimizer.scm",(void*)f_1949},
{"f_1955optimizer.scm",(void*)f_1955},
{"f_1923optimizer.scm",(void*)f_1923},
{"f_1927optimizer.scm",(void*)f_1927},
{"f_1930optimizer.scm",(void*)f_1930},
{"f_1947optimizer.scm",(void*)f_1947},
{"f_1900optimizer.scm",(void*)f_1900},
{"f_1906optimizer.scm",(void*)f_1906},
{"f_1910optimizer.scm",(void*)f_1910},
{"f_1914optimizer.scm",(void*)f_1914},
{"f_1892optimizer.scm",(void*)f_1892},
{"f_1831optimizer.scm",(void*)f_1831},
{"f_1822optimizer.scm",(void*)f_1822},
{"f_1707optimizer.scm",(void*)f_1707},
{"f_1711optimizer.scm",(void*)f_1711},
{"f_1722optimizer.scm",(void*)f_1722},
{"f_1732optimizer.scm",(void*)f_1732},
{"f_1781optimizer.scm",(void*)f_1781},
{"f_1779optimizer.scm",(void*)f_1779},
{"f_1738optimizer.scm",(void*)f_1738},
{"f_1744optimizer.scm",(void*)f_1744},
{"f_1771optimizer.scm",(void*)f_1771},
{"f_1750optimizer.scm",(void*)f_1750},
{"f_1714optimizer.scm",(void*)f_1714},
{"f_1703optimizer.scm",(void*)f_1703},
{"f_1693optimizer.scm",(void*)f_1693},
{"f_1683optimizer.scm",(void*)f_1683},
{"f_1677optimizer.scm",(void*)f_1677},
{"f_1468optimizer.scm",(void*)f_1468},
{"f_1489optimizer.scm",(void*)f_1489},
{"f_1501optimizer.scm",(void*)f_1501},
{"f_1516optimizer.scm",(void*)f_1516},
{"f_1568optimizer.scm",(void*)f_1568},
{"f_1587optimizer.scm",(void*)f_1587},
{"f_1598optimizer.scm",(void*)f_1598},
{"f_1571optimizer.scm",(void*)f_1571},
{"f_1541optimizer.scm",(void*)f_1541},
{"f_1504optimizer.scm",(void*)f_1504},
{"f_1510optimizer.scm",(void*)f_1510},
{"f_1492optimizer.scm",(void*)f_1492},
{"f_1495optimizer.scm",(void*)f_1495},
{"f_1499optimizer.scm",(void*)f_1499},
{"f_1471optimizer.scm",(void*)f_1471},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
