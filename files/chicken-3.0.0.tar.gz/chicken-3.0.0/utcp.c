/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:28
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: tcp.scm -quiet -no-trace -optimize-level 2 -include-path . -explicit-use -unsafe -no-lambda-info -output-file utcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[96];
static double C_possibly_force_alignment;


/* from general-strerror */
static C_word C_fcall stub344(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub344(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

/* from get-socket-error */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub340(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub340(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)return(-1);return(err);
C_ret:
#undef return

return C_r;}

/* from f_773 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub165(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub165(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

/* from k687 */
#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub151(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub151(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

/* from k584 in ##net#gethostaddr in k550 in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub125(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub125(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);return(1);
C_ret:
#undef return

return C_r;}

/* from ##net#select-write */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub119(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub119(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from ##net#select in k550 in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub115(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub115(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     return(rv);
C_ret:
#undef return

return C_r;}

/* from k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub106(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub106(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) return(0);
     else return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

/* from ##net#startup */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub102(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub102(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     return(1);
#endif
C_ret:
#undef return

return C_r;}

/* from ##net#getpeername */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub98(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#getpeerport */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub94(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub94(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockport in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub90(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub90(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) return(-1);else return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

/* from ##net#getsockname */
#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub85(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub85(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);return(addr_buffer);
C_ret:
#undef return

return C_r;}

/* from ##net#make-nonblocking in k466 in k463 in k460 */
#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub81(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) return(0);return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

/* from k523 */
static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub73(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from ##net#shutdown in k466 in k463 in k460 */
static C_word C_fcall stub66(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub66(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k513 */
static C_word C_fcall stub56(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub56(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k506 */
static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub44(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)send(t0,t1,t2,t3));
return C_r;}

/* from ##net#close in k466 in k463 in k460 */
static C_word C_fcall stub37(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub37(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k490 */
static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub27(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from ##net#listen */
static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub20(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k476 */
static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub11(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from ##net#socket in k466 in k463 in k460 */
static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub3(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_468)
static void C_ccall f_468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_552)
static void C_ccall f_552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_936)
static void C_ccall f_936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_ccall f_2132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2101)
static void C_ccall f_2101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2066)
static void C_ccall f_2066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2062)
static void C_ccall f_2062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1999)
static void C_ccall f_1999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1968)
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1728)
static void C_ccall f_1728r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1735)
static void C_ccall f_1735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1747)
static void C_ccall f_1747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1773)
static void C_ccall f_1773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1914)
static void C_ccall f_1914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_fcall f_1836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1843)
static void C_ccall f_1843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1852)
static void C_ccall f_1852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1855)
static void C_ccall f_1855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_fcall f_1752(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1759)
static void C_ccall f_1759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1702)
static void C_ccall f_1702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1713)
static void C_ccall f_1713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1709)
static void C_ccall f_1709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1693)
static void C_ccall f_1693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1607)
static void C_ccall f_1607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_fcall f_1612(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_ccall f_1634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1645)
static void C_ccall f_1645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1641)
static void C_ccall f_1641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_fcall f_985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1494)
static void C_fcall f_1494(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1510)
static void C_ccall f_1510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1536)
static void C_ccall f_1536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1429)
static void C_fcall f_1429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1394)
static void C_fcall f_1394(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1397)
static void C_ccall f_1397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1404)
static void C_ccall f_1404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_ccall f_1345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1367)
static void C_ccall f_1367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_ccall f_1374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1358)
static void C_ccall f_1358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1327)
static void C_ccall f_1327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1081)
static void C_ccall f_1081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1255)
static void C_fcall f_1255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_fcall f_1216(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_fcall f_1225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1287)
static void C_ccall f_1287(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1181)
static void C_ccall f_1181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1082)
static void C_fcall f_1082(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1092)
static void C_fcall f_1092(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1114)
static void C_ccall f_1114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_ccall f_1120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_fcall f_1008(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_fcall f_1014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_fcall f_954(C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_928)
static void C_ccall f_928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_892)
static void C_ccall f_892(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_847)
static void C_fcall f_847(C_word t0,C_word t1) C_noret;
C_noret_decl(f_842)
static void C_fcall f_842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_799)
static void C_fcall f_799(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_811)
static void C_ccall f_811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_830)
static void C_ccall f_830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_821)
static void C_ccall f_821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_768)
static void C_ccall f_768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_707)
static void C_ccall f_707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_713)
static void C_ccall f_713(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_ccall f_719(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_fcall f_612(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_621)
static void C_fcall f_621(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_648)
static void C_ccall f_648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_660)
static void C_ccall f_660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_671)
static void C_ccall f_671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_667)
static void C_ccall f_667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_fcall f_591(C_word t0) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_606)
static void C_ccall f_606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_577)
static void C_fcall f_577(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static C_word C_fcall f_571(C_word t0);
C_noret_decl(f_536)
static C_word C_fcall f_536(C_word t0);
C_noret_decl(f_527)
static C_word C_fcall f_527(C_word t0);
C_noret_decl(f_517)
static C_word C_fcall f_517(C_word t0,C_word t1);
C_noret_decl(f_500)
static C_word C_fcall f_500(C_word t0);
C_noret_decl(f_470)
static C_word C_fcall f_470(C_word t0,C_word t1,C_word t2);

C_noret_decl(trf_1836)
static void C_fcall trf_1836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1836(t0,t1);}

C_noret_decl(trf_1752)
static void C_fcall trf_1752(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1752(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1752(t0,t1);}

C_noret_decl(trf_1612)
static void C_fcall trf_1612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1612(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1612(t0,t1);}

C_noret_decl(trf_985)
static void C_fcall trf_985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_985(t0,t1,t2);}

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1001(t0,t1);}

C_noret_decl(trf_1494)
static void C_fcall trf_1494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1494(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1494(t0,t1,t2);}

C_noret_decl(trf_1429)
static void C_fcall trf_1429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1429(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1429(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1394)
static void C_fcall trf_1394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1394(t0,t1);}

C_noret_decl(trf_1255)
static void C_fcall trf_1255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1255(t0,t1);}

C_noret_decl(trf_1216)
static void C_fcall trf_1216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1216(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1216(t0,t1);}

C_noret_decl(trf_1225)
static void C_fcall trf_1225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1225(t0,t1);}

C_noret_decl(trf_1082)
static void C_fcall trf_1082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1082(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1082(t0,t1,t2);}

C_noret_decl(trf_1092)
static void C_fcall trf_1092(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1092(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1092(t0,t1,t2,t3);}

C_noret_decl(trf_1008)
static void C_fcall trf_1008(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1008(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1008(t0,t1);}

C_noret_decl(trf_1014)
static void C_fcall trf_1014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1014(t0,t1);}

C_noret_decl(trf_954)
static void C_fcall trf_954(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_954(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_954(t0,t1);}

C_noret_decl(trf_847)
static void C_fcall trf_847(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_847(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_847(t0,t1);}

C_noret_decl(trf_842)
static void C_fcall trf_842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_842(t0,t1,t2);}

C_noret_decl(trf_799)
static void C_fcall trf_799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_799(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_799(t0,t1,t2,t3);}

C_noret_decl(trf_612)
static void C_fcall trf_612(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_612(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_612(t0,t1,t2,t3);}

C_noret_decl(trf_621)
static void C_fcall trf_621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_621(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_621(t0,t1,t2);}

C_noret_decl(trf_591)
static void C_fcall trf_591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_591(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_591(t0);}

C_noret_decl(trf_577)
static void C_fcall trf_577(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_577(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_577(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr3rv)
static void C_fcall tr3rv(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3rv(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n+1);
t3=C_restore_rest_vector(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(450)){
C_save(t1);
C_rereclaim2(450*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,96);
lf[7]=C_h_intern(&lf[7],17,"\003sysmake-c-string");
lf[9]=C_h_intern(&lf[9],18,"\003syscurrent-thread");
lf[10]=C_h_intern(&lf[10],12,"\003sysschedule");
lf[11]=C_h_intern(&lf[11],9,"substring");
lf[13]=C_h_intern(&lf[13],15,"\003syssignal-hook");
lf[14]=C_h_intern(&lf[14],14,"\000network-error");
lf[15]=C_h_intern(&lf[15],11,"tcp-connect");
lf[16]=C_h_intern(&lf[16],17,"\003sysstring-append");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000$can not compute port from service - ");
lf[18]=C_h_intern(&lf[18],17,"\003syspeek-c-string");
lf[19]=C_h_intern(&lf[19],16,"\003sysupdate-errno");
lf[20]=C_h_intern(&lf[20],10,"tcp-listen");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\031can not bind to socket - ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[23]=C_h_intern(&lf[23],11,"make-string");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[25]=C_h_intern(&lf[25],9,"\003syserror");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\025can not create socket");
lf[27]=C_h_intern(&lf[27],13,"\000domain-error");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[29]=C_h_intern(&lf[29],12,"tcp-listener");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\033can not listen on socket - ");
lf[31]=C_h_intern(&lf[31],13,"tcp-listener\077");
lf[32]=C_h_intern(&lf[32],9,"tcp-close");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\033can not close TCP socket - ");
lf[34]=C_h_intern(&lf[34],15,"tcp-buffer-size");
lf[35]=C_h_intern(&lf[35],19,"\003sysundefined-value");
lf[36]=C_h_intern(&lf[36],16,"tcp-read-timeout");
lf[37]=C_h_intern(&lf[37],17,"tcp-write-timeout");
lf[38]=C_h_intern(&lf[38],19,"tcp-connect-timeout");
lf[39]=C_h_intern(&lf[39],18,"tcp-accept-timeout");
lf[40]=C_h_intern(&lf[40],15,"make-input-port");
lf[41]=C_h_intern(&lf[41],16,"make-output-port");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[44]=C_h_intern(&lf[44],25,"\003systhread-block-for-i/o!");
lf[45]=C_h_intern(&lf[45],29,"\003systhread-block-for-timeout!");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\033can not read from socket - ");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\032can not write to socket - ");
lf[49]=C_h_intern(&lf[49],13,"\003syssubstring");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[52]=C_h_intern(&lf[52],6,"socket");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000#can not close socket output port - ");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\042can not close socket input port - ");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[60]=C_h_intern(&lf[60],15,"\003sysmake-string");
lf[61]=C_h_intern(&lf[61],20,"\003sysscan-buffer-line");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\033can not create TCP ports - ");
lf[64]=C_h_intern(&lf[64],10,"tcp-accept");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[67]=C_h_intern(&lf[67],17,"tcp-accept-ready\077");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000!can not check socket for input - ");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\034can not connect to socket - ");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[73]=C_h_intern(&lf[73],4,"\000all");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\031can not find host address");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\030can not create socket - ");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[79]=C_h_intern(&lf[79],20,"\003systcp-port->fileno");
lf[80]=C_h_intern(&lf[80],13,"\003sysport-data");
lf[81]=C_h_intern(&lf[81],13,"tcp-addresses");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000!can not compute remote address - ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000 can not compute local address - ");
lf[84]=C_h_intern(&lf[84],16,"tcp-port-numbers");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\036can not compute remote port - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\035can not compute local port - ");
lf[87]=C_h_intern(&lf[87],17,"tcp-listener-port");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\037can not obtain listener port - ");
lf[89]=C_h_intern(&lf[89],16,"tcp-abandon-port");
lf[90]=C_h_intern(&lf[90],14,"\003syscheck-port");
lf[91]=C_h_intern(&lf[91],19,"tcp-listener-fileno");
lf[92]=C_h_intern(&lf[92],14,"make-parameter");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\032can not initialize Winsock");
lf[94]=C_h_intern(&lf[94],17,"register-feature!");
lf[95]=C_h_intern(&lf[95],3,"tcp");
C_register_lf2(lf,96,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_462,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k460 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k463 in k460 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 97   register-feature! */
t3=*((C_word*)lf[94]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[95]);}

/* k466 in k463 in k460 */
static void C_ccall f_468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_468,2,t0,t1);}
t2=C_mutate(&lf[0],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_470,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[1],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_500,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[2],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_517,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[3],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_527,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[4],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_536,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_552,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)stub102(C_SCHEME_UNDEFINED))){
t8=t7;
f_552(2,t8,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 195  ##sys#signal-hook */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,lf[14],lf[93]);}}

/* k550 in k466 in k463 in k460 */
static void C_ccall f_552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_552,2,t0,t1);}
t2=C_mutate(&lf[5],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_571,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate(&lf[6],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_577,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[8],(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_591,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[11]+1);
t6=C_mutate(&lf[12],(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_612,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[20]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_797,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[31]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_892,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[32]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_901,tmp=(C_word)a,a+=2,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_936,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 329  make-parameter */
t11=*((C_word*)lf[92]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,C_SCHEME_FALSE);}

/* k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_936,2,t0,t1);}
t2=C_mutate((C_word*)lf[34]+1,t1);
t3=*((C_word*)lf[35]+1);
t4=C_mutate((C_word*)lf[36]+1,t3);
t5=*((C_word*)lf[35]+1);
t6=C_mutate((C_word*)lf[37]+1,t5);
t7=*((C_word*)lf[35]+1);
t8=C_mutate((C_word*)lf[38]+1,t7);
t9=*((C_word*)lf[35]+1);
t10=C_mutate((C_word*)lf[39]+1,t9);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_954,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_971,a[2]=t11,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 340  check */
f_954(t13,lf[36]);}

/* k2138 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 340  make-parameter */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_971,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 341  check */
f_954(t4,lf[37]);}

/* k2134 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 341  make-parameter */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_fix(60000),t1);}

/* k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2132,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 342  check */
f_954(t4,lf[38]);}

/* k2130 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 342  make-parameter */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_983,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2128,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 343  check */
f_954(t4,lf[39]);}

/* k2126 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 343  make-parameter */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1,t1);
t3=*((C_word*)lf[40]+1);
t4=*((C_word*)lf[41]+1);
t5=*((C_word*)lf[34]+1);
t6=*((C_word*)lf[23]+1);
t7=C_mutate(&lf[42],(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_985,a[2]=t6,a[3]=t5,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t8=C_mutate((C_word*)lf[64]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1597,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[67]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1683,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[15]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1728,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[79]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1968,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[81]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1978,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[84]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2023,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[87]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2068,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[89]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2097,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[91]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2117,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2117,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2097,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2101,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 648  ##sys#check-port */
t4=*((C_word*)lf[90]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[89]);}

/* k2099 in tcp-abandon-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2108,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 650  ##sys#port-data */
t3=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k2106 in k2099 in tcp-abandon-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_word)C_slot(((C_word*)t0)[3],C_fix(1));
t3=(C_truep(t2)?C_fix(2):C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_word)C_i_set_i_slot(t1,t3,C_SCHEME_TRUE));}

/* tcp-listener-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2068,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[87]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_536(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2091,a[2]=t4,a[3]=t2,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2095,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t8=t6;
f_2081(2,t8,C_SCHEME_UNDEFINED);}}

/* k2093 in tcp-listener-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 643  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[88],t1);}

/* k2089 in tcp-listener-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 642  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[87],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2079 in tcp-listener-port in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2023,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 630  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=f_536(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_2037(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2062,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2066,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2064 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 633  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[86],t1);}

/* k2060 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 633  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[84],t1,((C_word*)t0)[2]);}

/* k2035 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2037,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(C_word)stub94(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2044(2,t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2055,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2053 in k2035 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 635  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[85],t1);}

/* k2049 in k2035 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 635  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[84],t1,((C_word*)t0)[2]);}

/* k2042 in k2035 in k2025 in tcp-port-numbers in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 631  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 622  ##sys#tcp-port->fileno */
t4=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1989,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub85(t4,t3),C_fix(0));}

/* k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1992(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2021,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2019 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 625  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[83],t1);}

/* k2015 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 625  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[81],t1,((C_word*)t0)[2]);}

/* k1990 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1996,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,(C_word)stub98(t4,t3),C_fix(0));}

/* k1994 in k1990 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_1999(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2008 in k1994 in k1990 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 627  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[82],t1);}

/* k2004 in k1994 in k1990 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 627  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[81],t1,((C_word*)t0)[2]);}

/* k1997 in k1994 in k1990 in k1987 in k1980 in tcp-addresses in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 623  values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1968(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1968,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1976,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 619  ##sys#port-data */
t4=*((C_word*)lf[80]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k1974 in ##sys#tcp-port->fileno in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_slot(t1,C_fix(0)));}

/* tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1728(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3rv,(void*)f_1728r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest_vector(a,C_rest_count(0));
f_1728r(t0,t1,t2,t3);}}

static void C_ccall f_1728r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(C_word)C_vemptyp(t3);
t6=(C_truep(t5)?C_SCHEME_FALSE:(C_word)C_slot(t3,C_fix(0)));
t7=t6;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1735,a[2]=t1,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 570  tcp-connect-timeout */
t10=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}

/* k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1735,2,t0,t1);}
t2=(C_word)C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1741,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_1741(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1945,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 573  ##sys#call-with-values */
C_u_call_with_values(4,0,t4,t5,t6);}}

/* a1950 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1951,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a1944 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
/* tcp.scm: 573  ##net#parse-host */
t2=lf[12];
f_612(t2,t1,((C_word*)((C_word*)t0)[2])[1],lf[78]);}

/* k1935 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=((C_word*)t0)[3];
f_1741(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 574  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],lf[77],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(C_word)C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 576  make-string */
t4=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1747,2,t0,t1);}
t2=f_470(C_fix((C_word)AF_INET),C_fix((C_word)SOCK_STREAM),C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1752,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1773,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t5=(C_word)C_eqp(C_fix(-1),t2);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1923,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 585  ##sys#update-errno */
t7=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1773(2,t6,C_SCHEME_UNDEFINED);}}

/* k1921 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1932 in k1921 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[76],t1);}

/* k1928 in k1921 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 586  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[15],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1773,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1776,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1914,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 587  ##net#gethostaddr */
f_577(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k1912 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1776(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 588  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],lf[75],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=f_527(((C_word*)t0)[6]);
if(C_truep(t3)){
t4=t2;
f_1779(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 590  ##sys#update-errno */
t5=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1898 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1909 in k1898 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 591  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[74],t1);}

/* k1905 in k1898 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 591  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=(C_truep(t3)?t3:C_SCHEME_FALSE);
t6=(C_word)stub73(C_SCHEME_UNDEFINED,((C_word*)t0)[6],t5,t4);
t7=(C_word)C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t10,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_1836(t12,t2);}
else{
/* tcp.scm: 610  fail */
t9=((C_word*)t0)[2];
f_1752(t9,t2);}}
else{
t8=t2;
f_1782(2,t8,C_SCHEME_UNDEFINED);}}

/* loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1836,NULL,2,t0,t1);}
t2=(C_word)stub119(C_SCHEME_UNDEFINED,((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1843,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
/* tcp.scm: 596  fail */
t5=((C_word*)t0)[2];
f_1752(t5,t3);}
else{
t5=t3;
f_1843(2,t5,C_SCHEME_UNDEFINED);}}

/* k1841 in loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1843,2,t0,t1);}
t2=(C_word)C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1852,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=(C_word)C_fudge(C_fix(16));
t5=(C_word)C_u_fixnum_plus(t4,((C_word*)t0)[2]);
/* tcp.scm: 599  ##sys#thread-block-for-timeout! */
t6=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[9]+1),t5);}
else{
t4=t3;
f_1852(2,t4,C_SCHEME_UNDEFINED);}}}

/* k1850 in k1841 in loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1855,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 602  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[73]);}

/* k1853 in k1850 in k1841 in loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 603  yield */
f_591(t2);}

/* k1856 in k1853 in k1850 in k1841 in loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 605  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[14],lf[15],lf[72],((C_word*)t0)[2]);}
else{
t3=t2;
f_1861(2,t3,C_SCHEME_UNDEFINED);}}

/* k1859 in k1856 in k1853 in k1850 in k1841 in loop in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 609  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1836(t2,((C_word*)t0)[2]);}

/* k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1782,2,t0,t1);}
t2=(C_word)stub340(C_SCHEME_UNDEFINED,((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_eqp(t2,C_fix(-1));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1805,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(C_word)C_a_i_bytevector(&a,1,C_fix(3));
/* ##sys#peek-c-string */
t8=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,(C_word)stub344(t7,t2),C_fix(0));}
else{
t5=t3;
f_1788(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1820 in k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 615  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[71],t1);}

/* k1816 in k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 615  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1803 in k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 613  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[70],t1);}

/* k1799 in k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 613  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[14],lf[15],t1);}

/* k1786 in k1780 in k1777 in k1774 in k1771 in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 616  ##net#io-ports */
t2=lf[42];
f_985(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1752(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1752,NULL,2,t0,t1);}
t2=f_500(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1759,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 580  ##sys#update-errno */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k1757 in fail in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1770,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1768 in k1757 in fail in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 582  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[69],t1);}

/* k1764 in k1757 in fail in k1745 in k1739 in k1733 in tcp-connect in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 581  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[15],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1683,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure_2(t2,lf[29],lf[67]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_571(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1693,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1702,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 552  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_1693(2,t8,C_SCHEME_UNDEFINED);}}

/* k1700 in tcp-accept-ready? in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1709,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1711 in k1700 in tcp-accept-ready? in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 554  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[68],t1);}

/* k1707 in k1700 in tcp-accept-ready? in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 553  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[67],t1,((C_word*)t0)[2]);}

/* k1691 in tcp-accept-ready? in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1597,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[29]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1607,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 524  tcp-accept-timeout */
t6=*((C_word*)lf[39]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1607,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1612,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1612(t5,((C_word*)t0)[2]);}

/* loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1612(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1612,NULL,2,t0,t1);}
t2=f_571(((C_word*)t0)[5]);
t3=(C_word)C_eqp(C_fix(1),t2);
if(C_truep(t3)){
t4=(C_word)stub27(C_SCHEME_UNDEFINED,((C_word*)t0)[5],C_SCHEME_FALSE,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1625,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_eqp(C_fix(-1),t4);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1634,a[2]=((C_word*)t0)[4],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 529  ##sys#update-errno */
t8=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t5;
f_1625(2,t7,C_SCHEME_UNDEFINED);}}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=(C_word)C_fudge(C_fix(16));
t6=(C_word)C_u_fixnum_plus(t5,((C_word*)t0)[2]);
/* tcp.scm: 536  ##sys#thread-block-for-timeout! */
t7=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,*((C_word*)lf[9]+1),t6);}
else{
t5=t4;
f_1648(2,t5,C_SCHEME_UNDEFINED);}}}

/* k1646 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1651,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 539  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1649 in k1646 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 540  yield */
f_591(t2);}

/* k1652 in k1649 in k1646 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 542  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[14],lf[64],lf[66],((C_word*)t0)[2]);}
else{
t3=t2;
f_1657(2,t3,C_SCHEME_UNDEFINED);}}

/* k1655 in k1652 in k1649 in k1646 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 546  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1612(t2,((C_word*)t0)[2]);}

/* k1632 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1641,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1645,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1643 in k1632 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 531  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[65],t1);}

/* k1639 in k1632 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 530  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[64],t1,((C_word*)t0)[2]);}

/* k1623 in loop in k1605 in tcp-accept in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 533  ##net#io-ports */
t2=lf[42];
f_985(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_985,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t4=f_527(t2);
if(C_truep(t4)){
t5=t3;
f_989(2,t5,C_SCHEME_UNDEFINED);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 352  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k1582 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1595,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1593 in k1582 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 353  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[63],t1);}

/* k1589 in k1582 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 353  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[14],t1);}

/* k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 354  make-string */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix(1024));}

/* k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_992,2,t0,t1);}
t2=(C_word)C_a_i_vector(&a,3,((C_word*)t0)[6],C_SCHEME_FALSE,C_SCHEME_FALSE);
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t8,a[5]=t10,a[6]=((C_word*)t0)[5],a[7]=t2,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=((C_word*)t0)[6],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm: 360  tbs */
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}

/* k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(t1)){
t3=(C_word)C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1001(t4,(C_truep(t3)?lf[62]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1001(t3,C_SCHEME_FALSE);}}

/* k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1001(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm: 362  tcp-read-timeout */
t5=*((C_word*)lf[36]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* tcp.scm: 363  tcp-write-timeout */
t3=*((C_word*)lf[37]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[47],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1008,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1081,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1323,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[14],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1423,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1488,a[2]=t2,a[3]=((C_word*)t0)[13],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 391  make-input-port */
t9=((C_word*)t0)[2];
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t3,t4,t5,t6,C_SCHEME_FALSE,t7,t8);}

/* a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1488,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1494,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_1494(t7,t1,C_SCHEME_FALSE);}

/* loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1494(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1494,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* tcp.scm: 438  ##sys#scan-buffer-line */
t4=*((C_word*)lf[61]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[5],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1563,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 455  read-input */
t4=((C_word*)t0)[3];
f_1008(t4,t3);}}

/* k1561 in loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1]))){
/* tcp.scm: 457  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1494(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1505 in loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1506,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1510,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
t5=(C_word)C_u_fixnum_difference(t2,((C_word*)((C_word*)t0)[7])[1]);
/* tcp.scm: 443  ##sys#make-string */
t6=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k1508 in a1505 in loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1510,2,t0,t1);}
t2=(C_word)C_substring_copy(((C_word*)t0)[11],t1,((C_word*)((C_word*)t0)[10])[1],((C_word*)t0)[9],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[10])+1,((C_word*)t0)[8]);
t4=(C_word)C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1520,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 447  read-input */
t6=((C_word*)t0)[3];
f_1008(t6,t5);}
else{
t5=(C_word)C_slot(((C_word*)t0)[2],C_fix(4));
t6=(C_word)C_u_fixnum_plus(t5,C_fix(1));
t7=(C_word)C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t6);
if(C_truep(((C_word*)t0)[6])){
/* tcp.scm: 453  ##sys#string-append */
t8=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[5],((C_word*)t0)[6],t1);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t1);}}}

/* k1518 in k1508 in a1505 in loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1520,2,t0,t1);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[59]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1536,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
/* tcp.scm: 450  ##sys#string-append */
t3=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2]);}
else{
t3=t2;
f_1536(2,t3,((C_word*)t0)[2]);}}}

/* k1534 in k1518 in k1508 in a1505 in loop in a1487 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 450  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1494(t2,((C_word*)t0)[2],t1);}

/* a1422 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1423,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1429,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_1429(t9,t1,t3,C_fix(0),t5);}

/* loop in a1422 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1429(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1429,NULL,5,t0,t1,t2,t3,t4);}
t5=(C_word)C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
if(C_truep((C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=(C_word)C_u_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=(C_word)C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=(C_word)C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=(C_word)C_u_fixnum_difference(t2,t8);
t14=(C_word)C_u_fixnum_plus(t3,t8);
t15=(C_word)C_u_fixnum_plus(t4,t8);
/* tcp.scm: 429  loop */
t18=t1;
t19=t13;
t20=t14;
t21=t15;
t1=t18;
t2=t19;
t3=t20;
t4=t21;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1477,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm: 431  read-input */
t7=((C_word*)t0)[2];
f_1008(t7,t6);}}}

/* k1475 in loop in a1422 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
/* tcp.scm: 434  loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1429(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* a1379 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(C_truep((C_word)C_slot(((C_word*)t0)[4],C_fix(1)))?C_SCHEME_UNDEFINED:f_517(((C_word*)t0)[3],C_fix((C_word)SD_RECEIVE)));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1394,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t5=f_500(((C_word*)t0)[3]);
t6=t4;
f_1394(t6,(C_word)C_eqp(C_fix(-1),t5));}
else{
t5=t4;
f_1394(t5,C_SCHEME_FALSE);}}}

/* k1392 in a1379 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1394,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 415  ##sys#update-errno */
t3=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1395 in k1392 in a1379 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1408,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1406 in k1395 in k1392 in a1379 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 418  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[58],t1);}

/* k1402 in k1395 in k1392 in a1379 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 416  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* a1344 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1345,2,t0,t1);}
t2=(C_word)C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=f_571(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1358,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(C_word)C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1367,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 404  ##sys#update-errno */
t7=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=t4;
f_1358(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1365 in a1344 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1376 in k1365 in a1344 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 407  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[57],t1);}

/* k1372 in k1365 in a1344 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 405  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1356 in a1344 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1322 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1327,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm: 394  read-input */
t3=((C_word*)t0)[2];
f_1008(t3,t2);}
else{
t3=t2;
f_1327(2,t3,C_SCHEME_UNDEFINED);}}

/* k1325 in a1322 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep((C_word)C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(C_word)C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=(C_word)C_u_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[29],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1181,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1287,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1208,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=(C_truep(((C_word*)((C_word*)t0)[6])[1])?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1271,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp):C_SCHEME_FALSE);
/* tcp.scm: 487  make-output-port */
t7=((C_word*)t0)[2];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,t5,t6);}

/* f_1271 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep((C_word)C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 511  output */
t4=((C_word*)t0)[2];
f_1082(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k1279 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[56]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1255,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(C_word)C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1255(t6,(C_word)C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1255(t5,C_SCHEME_FALSE);}}}

/* k1253 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1255,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 501  output */
t3=((C_word*)t0)[2];
f_1082(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1216(t2,C_SCHEME_UNDEFINED);}}

/* k1256 in k1253 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[55]);
t3=((C_word*)t0)[2];
f_1216(t3,t2);}

/* k1214 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1216(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1216,NULL,2,t0,t1);}
t2=(C_truep((C_word)C_slot(((C_word*)t0)[5],C_fix(2)))?C_SCHEME_UNDEFINED:f_517(((C_word*)t0)[4],C_fix((C_word)SD_SEND)));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=f_500(((C_word*)t0)[4]);
t5=t3;
f_1225(t5,(C_word)C_eqp(C_fix(-1),t4));}
else{
t4=t3;
f_1225(t4,C_SCHEME_FALSE);}}

/* k1223 in k1214 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 505  ##sys#update-errno */
t3=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1226 in k1223 in k1214 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1237 in k1226 in k1223 in k1214 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 507  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k1233 in k1226 in k1223 in k1214 in a1207 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 506  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* f_1307 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1307,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
if(C_truep((C_word)C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm: 496  output */
t4=((C_word*)t0)[2];
f_1082(t4,t1,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* f_1287 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1287(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1287,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 490  ##sys#string-append */
t4=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1290 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1292,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(C_word)C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 492  output */
t5=((C_word*)t0)[2];
f_1082(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}}

/* k1299 in k1290 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[53]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1179 in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[50]);
t3=(C_word)C_i_setslot(t1,C_fix(3),lf[51]);
t4=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[52]);
t5=(C_word)C_i_setslot(t1,C_fix(7),lf[52]);
t6=(C_word)C_i_setslot(((C_word*)t0)[4],C_fix(9),((C_word*)t0)[3]);
t7=(C_word)C_i_setslot(t1,C_fix(9),((C_word*)t0)[3]);
/* tcp.scm: 519  values */
C_values(4,0,((C_word*)t0)[2],((C_word*)t0)[4],t1);}

/* output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1082(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1082,NULL,3,t0,t1,t2);}
t3=(C_word)C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_1092(t7,t1,t3,t2);}

/* loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1092(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1092,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_i_fixnum_min(C_fix(8192),t2);
t5=((C_word*)t0)[4];
t6=t3;
t7=(C_truep(t6)?t6:C_SCHEME_FALSE);
t8=(C_word)stub44(C_SCHEME_UNDEFINED,t5,t7,t4,C_fix(0));
t9=(C_word)C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1114,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[2])){
t12=(C_word)C_fudge(C_fix(16));
t13=(C_word)C_u_fixnum_plus(t12,((C_word*)t0)[2]);
/* tcp.scm: 468  ##sys#thread-block-for-timeout! */
t14=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t11,*((C_word*)lf[9]+1),t13);}
else{
t12=t11;
f_1114(2,t12,C_SCHEME_UNDEFINED);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 479  ##sys#update-errno */
t12=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}}
else{
if(C_truep((C_word)C_fixnum_lessp(t8,t2))){
t10=(C_word)C_u_fixnum_difference(t2,t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1174,a[2]=t10,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t12=(C_word)C_block_size(t3);
/* tcp.scm: 485  ##sys#substring */
t13=*((C_word*)lf[49]+1);
((C_proc5)(void*)(*((C_word*)t13+1)))(5,t13,t11,t3,t8,t12);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}}

/* k1172 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 485  loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1092(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1144 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1155 in k1144 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 482  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[48],t1);}

/* k1151 in k1144 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 480  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1112 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 471  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1115 in k1112 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* tcp.scm: 472  yield */
f_591(t2);}

/* k1118 in k1115 in k1112 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 474  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[14],lf[47],((C_word*)t0)[2]);}
else{
t3=t2;
f_1123(2,t3,C_SCHEME_UNDEFINED);}}

/* k1121 in k1118 in k1115 in k1112 in loop in output in k1079 in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 477  loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1092(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1008(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1008,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_1014(t5,t1);}

/* loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_1014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1014,NULL,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=(C_word)stub56(C_SCHEME_UNDEFINED,t2,t4,C_fix(1024),C_fix(0));
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(C_word)C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
t9=(C_word)C_fudge(C_fix(16));
t10=(C_word)C_u_fixnum_plus(t9,((C_word*)t0)[4]);
/* tcp.scm: 371  ##sys#thread-block-for-timeout! */
t11=*((C_word*)lf[45]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t8,*((C_word*)lf[9]+1),t10);}
else{
t9=t8;
f_1033(2,t9,C_SCHEME_UNDEFINED);}}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[7],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 382  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t5);
t8=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1063 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1076,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1074 in k1063 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 385  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[46],t1);}

/* k1070 in k1063 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 383  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[14],t1,((C_word*)t0)[2]);}

/* k1031 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 374  ##sys#thread-block-for-i/o! */
t3=*((C_word*)lf[44]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[9]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1034 in k1031 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 375  yield */
f_591(t2);}

/* k1037 in k1034 in k1031 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep((C_word)C_slot(*((C_word*)lf[9]+1),C_fix(13)))){
/* tcp.scm: 377  ##sys#signal-hook */
t3=*((C_word*)lf[13]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[14],lf[43],((C_word*)t0)[2]);}
else{
t3=t2;
f_1042(2,t3,C_SCHEME_UNDEFINED);}}

/* k1040 in k1037 in k1034 in k1031 in loop in read-input in k1005 in k1002 in k999 in k996 in k990 in k987 in ##net#io-ports in k981 in k977 in k973 in k969 in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 380  loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1014(t2,((C_word*)t0)[2]);}

/* check in k934 in k550 in k466 in k463 in k460 */
static void C_fcall f_954(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_954,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=t2,tmp=(C_word)a,a+=3,tmp));}

/* f_956 in check in k934 in k550 in k466 in k463 in k460 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_956,3,t0,t1,t2);}
t3=(C_truep(t2)?(C_word)C_i_check_exact_2(t2,((C_word*)t0)[2]):C_SCHEME_UNDEFINED);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}

/* tcp-close in k550 in k466 in k463 in k460 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_901,3,t0,t1,t2);}
t3=(C_word)C_i_check_structure(t2,lf[29]);
t4=(C_word)C_slot(t2,C_fix(1));
t5=f_500(t4);
t6=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_917,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 323  ##sys#update-errno */
t8=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}}

/* k915 in tcp-close in k550 in k466 in k463 in k460 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k926 in k915 in tcp-close in k550 in k466 in k463 in k460 */
static void C_ccall f_928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[33],t1);}

/* k922 in k915 in tcp-close in k550 in k466 in k463 in k460 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 324  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[32],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k550 in k466 in k463 in k460 */
static void C_ccall f_892(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_892,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep((C_word)C_blockp(t2))?(C_word)C_i_structurep(t2,lf[29]):C_SCHEME_FALSE));}

/* tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_797r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_797r(t0,t1,t2,t3);}}

static void C_ccall f_797r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_799,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_842,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_847,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep((C_word)C_i_nullp(t3))){
/* def-w184202 */
t7=t6;
f_847(t7,t1);}
else{
t7=(C_word)C_u_i_car(t3);
t8=(C_word)C_slot(t3,C_fix(1));
if(C_truep((C_word)C_i_nullp(t8))){
/* def-host185200 */
t9=t5;
f_842(t9,t1,t7);}
else{
t9=(C_word)C_u_i_car(t8);
t10=(C_word)C_slot(t8,C_fix(1));
/* body182187 */
t11=t4;
f_799(t11,t1,t7,t9);}}}

/* def-w184 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_fcall f_847(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_847,NULL,2,t0,t1);}
/* def-host185200 */
t2=((C_word*)t0)[2];
f_842(t2,t1,C_fix(10));}

/* def-host185 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_fcall f_842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_842,NULL,3,t0,t1,t2);}
/* body182187 */
t3=((C_word*)t0)[2];
f_799(t3,t1,t2,C_SCHEME_FALSE);}

/* body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_fcall f_799(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_799,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_805,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_811,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_u_call_with_values(4,0,t1,t4,t5);}

/* a810 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_811,4,t0,t1,t2,t3);}
t4=(C_word)C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=(C_word)stub20(C_SCHEME_UNDEFINED,t5,t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_821,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t9=(C_word)C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_830,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 311  ##sys#update-errno */
t11=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=t8;
f_821(2,t10,C_SCHEME_UNDEFINED);}}

/* k828 in a810 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_830,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_841,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k839 in k828 in a810 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 312  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[30],t1);}

/* k835 in k828 in a810 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 312  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k819 in a810 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_821,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)C_a_i_record(&a,2,lf[29],((C_word*)t0)[2]));}

/* a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=(C_word)C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_698,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=(C_word)C_fixnum_lessp(t2,C_fix(0));
t8=(C_truep(t7)?t7:(C_word)C_fixnum_greater_or_equal_p(t2,C_fix(65535)));
if(C_truep(t8)){
/* tcp.scm: 280  ##sys#signal-hook */
t9=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t6,lf[27],lf[20],lf[28],t2);}
else{
t9=t6;
f_698(2,t9,C_SCHEME_UNDEFINED);}}

/* k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=f_470(C_fix((C_word)AF_INET),((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(C_word)C_eqp(C_fix((C_word)INVALID_SOCKET),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm: 283  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_704(2,t5,C_SCHEME_UNDEFINED);}}

/* k778 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 284  ##sys#error */
t2=*((C_word*)lf[25]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[26]);}

/* k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_704,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_773,tmp=(C_word)a,a+=2,tmp);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}

/* f_773 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_773,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_word)stub165(C_SCHEME_UNDEFINED,t2));}

/* k770 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(C_word)C_eqp(C_fix(-1),t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 290  ##sys#update-errno */
t4=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[3];
f_707(2,t3,C_SCHEME_UNDEFINED);}}

/* k755 in k770 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_768,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k766 in k755 in k770 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 291  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[24],t1);}

/* k762 in k755 in k770 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 291  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[20],t1,((C_word*)t0)[2]);}

/* k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm: 292  make-string */
t3=*((C_word*)lf[23]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_713,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 294  ##net#gethostaddr */
f_577(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
t4=(C_truep(t3)?t3:C_SCHEME_FALSE);
t5=t2;
f_713(2,t5,(C_word)stub151(C_SCHEME_UNDEFINED,t4,((C_word*)t0)[3]));}}

/* k743 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_713(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm: 295  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],lf[22],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k711 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_713(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_713,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=(C_truep(t2)?t2:C_SCHEME_FALSE);
t5=(C_word)stub11(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t4,t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_719,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=(C_word)C_eqp(C_fix(-1),t5);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 299  ##sys#update-errno */
t9=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=t6;
f_719(2,t8,C_SCHEME_UNDEFINED);}}

/* k726 in k711 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_735,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_739,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k737 in k726 in k711 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 300  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[21],t1);}

/* k733 in k726 in k711 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 300  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[14],lf[20],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k717 in k711 in k708 in k705 in k702 in k696 in a804 in body182 in tcp-listen in k550 in k466 in k463 in k460 */
static void C_ccall f_719(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 301  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_fcall f_612(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_612,NULL,4,t0,t1,t2,t3);}
t4=(C_word)C_block_size(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_621,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t4,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_621(t8,t1,C_fix(0));}

/* loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_fcall f_621(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_621,NULL,3,t0,t1,t2);}
if(C_truep((C_word)C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
/* tcp.scm: 251  values */
C_values(4,0,t1,((C_word*)t0)[5],C_SCHEME_FALSE);}
else{
t3=(C_word)C_subchar(((C_word*)t0)[5],t2);
t4=(C_word)C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_644,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=(C_word)C_u_fixnum_increase(t2);
/* tcp.scm: 255  substring */
t7=((C_word*)t0)[3];
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[5],t6,((C_word*)t0)[6]);}
else{
t5=(C_word)C_u_fixnum_plus(t2,C_fix(1));
/* tcp.scm: 264  loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_648,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm: 256  substring */
t3=((C_word*)t0)[4];
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_648,2,t0,t1);}
t2=t1;
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_559,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
/* ##sys#make-c-string */
t5=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=t4;
f_559(2,t5,C_SCHEME_FALSE);}}

/* k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
/* ##sys#make-c-string */
t3=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_563(2,t3,C_SCHEME_FALSE);}}

/* k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
t2=(C_word)stub106(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_654,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(C_word)C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_660,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm: 259  ##sys#update-errno */
t6=*((C_word*)lf[19]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t3;
f_654(2,t5,C_SCHEME_UNDEFINED);}}

/* k658 in k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_660,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_671,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k669 in k658 in k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 261  ##sys#string-append */
t2=*((C_word*)lf[16]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[17],t1);}

/* k665 in k658 in k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 260  ##sys#signal-hook */
t2=*((C_word*)lf[13]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[14],lf[15],t1,((C_word*)t0)[2]);}

/* k652 in k561 in k557 in k646 in k642 in loop in ##net#parse-host in k550 in k466 in k463 in k460 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm: 254  values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k550 in k466 in k463 in k460 */
static void C_fcall f_591(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_591,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_597,tmp=(C_word)a,a+=2,tmp);
/* tcp.scm: 239  ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a596 in yield in k550 in k466 in k463 in k460 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_597,3,t0,t1,t2);}
t3=*((C_word*)lf[9]+1);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_606,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(C_word)C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm: 243  ##sys#schedule */
t6=*((C_word*)lf[10]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t1);}

/* a605 in a596 in yield in k550 in k466 in k463 in k460 */
static void C_ccall f_606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_606,2,t0,t1);}
/* tcp.scm: 242  return */
t2=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k550 in k466 in k463 in k460 */
static void C_fcall f_577(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_577,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?t2:C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_586,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* ##sys#make-c-string */
t7=*((C_word*)lf[7]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t7=t6;
f_586(2,t7,C_SCHEME_FALSE);}}

/* k584 in ##net#gethostaddr in k550 in k466 in k463 in k460 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_word)stub125(C_SCHEME_UNDEFINED,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* ##net#select in k550 in k466 in k463 in k460 */
static C_word C_fcall f_571(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub115(C_SCHEME_UNDEFINED,t1));}

/* ##net#getsockport in k466 in k463 in k460 */
static C_word C_fcall f_536(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub90(C_SCHEME_UNDEFINED,t1));}

/* ##net#make-nonblocking in k466 in k463 in k460 */
static C_word C_fcall f_527(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub81(C_SCHEME_UNDEFINED,t1));}

/* ##net#shutdown in k466 in k463 in k460 */
static C_word C_fcall f_517(C_word t1,C_word t2){
C_word tmp;
C_word t3;
return((C_word)stub66(C_SCHEME_UNDEFINED,t1,t2));}

/* ##net#close in k466 in k463 in k460 */
static C_word C_fcall f_500(C_word t1){
C_word tmp;
C_word t2;
return((C_word)stub37(C_SCHEME_UNDEFINED,t1));}

/* ##net#socket in k466 in k463 in k460 */
static C_word C_fcall f_470(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
return((C_word)stub3(C_SCHEME_UNDEFINED,t1,t2,t3));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[213] = {
{"topleveltcp.scm",(void*)C_tcp_toplevel},
{"f_462tcp.scm",(void*)f_462},
{"f_465tcp.scm",(void*)f_465},
{"f_468tcp.scm",(void*)f_468},
{"f_552tcp.scm",(void*)f_552},
{"f_936tcp.scm",(void*)f_936},
{"f_2140tcp.scm",(void*)f_2140},
{"f_971tcp.scm",(void*)f_971},
{"f_2136tcp.scm",(void*)f_2136},
{"f_975tcp.scm",(void*)f_975},
{"f_2132tcp.scm",(void*)f_2132},
{"f_979tcp.scm",(void*)f_979},
{"f_2128tcp.scm",(void*)f_2128},
{"f_983tcp.scm",(void*)f_983},
{"f_2117tcp.scm",(void*)f_2117},
{"f_2097tcp.scm",(void*)f_2097},
{"f_2101tcp.scm",(void*)f_2101},
{"f_2108tcp.scm",(void*)f_2108},
{"f_2068tcp.scm",(void*)f_2068},
{"f_2095tcp.scm",(void*)f_2095},
{"f_2091tcp.scm",(void*)f_2091},
{"f_2081tcp.scm",(void*)f_2081},
{"f_2023tcp.scm",(void*)f_2023},
{"f_2027tcp.scm",(void*)f_2027},
{"f_2066tcp.scm",(void*)f_2066},
{"f_2062tcp.scm",(void*)f_2062},
{"f_2037tcp.scm",(void*)f_2037},
{"f_2055tcp.scm",(void*)f_2055},
{"f_2051tcp.scm",(void*)f_2051},
{"f_2044tcp.scm",(void*)f_2044},
{"f_1978tcp.scm",(void*)f_1978},
{"f_1982tcp.scm",(void*)f_1982},
{"f_1989tcp.scm",(void*)f_1989},
{"f_2021tcp.scm",(void*)f_2021},
{"f_2017tcp.scm",(void*)f_2017},
{"f_1992tcp.scm",(void*)f_1992},
{"f_1996tcp.scm",(void*)f_1996},
{"f_2010tcp.scm",(void*)f_2010},
{"f_2006tcp.scm",(void*)f_2006},
{"f_1999tcp.scm",(void*)f_1999},
{"f_1968tcp.scm",(void*)f_1968},
{"f_1976tcp.scm",(void*)f_1976},
{"f_1728tcp.scm",(void*)f_1728},
{"f_1735tcp.scm",(void*)f_1735},
{"f_1951tcp.scm",(void*)f_1951},
{"f_1945tcp.scm",(void*)f_1945},
{"f_1937tcp.scm",(void*)f_1937},
{"f_1741tcp.scm",(void*)f_1741},
{"f_1747tcp.scm",(void*)f_1747},
{"f_1923tcp.scm",(void*)f_1923},
{"f_1934tcp.scm",(void*)f_1934},
{"f_1930tcp.scm",(void*)f_1930},
{"f_1773tcp.scm",(void*)f_1773},
{"f_1914tcp.scm",(void*)f_1914},
{"f_1776tcp.scm",(void*)f_1776},
{"f_1900tcp.scm",(void*)f_1900},
{"f_1911tcp.scm",(void*)f_1911},
{"f_1907tcp.scm",(void*)f_1907},
{"f_1779tcp.scm",(void*)f_1779},
{"f_1836tcp.scm",(void*)f_1836},
{"f_1843tcp.scm",(void*)f_1843},
{"f_1852tcp.scm",(void*)f_1852},
{"f_1855tcp.scm",(void*)f_1855},
{"f_1858tcp.scm",(void*)f_1858},
{"f_1861tcp.scm",(void*)f_1861},
{"f_1782tcp.scm",(void*)f_1782},
{"f_1822tcp.scm",(void*)f_1822},
{"f_1818tcp.scm",(void*)f_1818},
{"f_1805tcp.scm",(void*)f_1805},
{"f_1801tcp.scm",(void*)f_1801},
{"f_1788tcp.scm",(void*)f_1788},
{"f_1752tcp.scm",(void*)f_1752},
{"f_1759tcp.scm",(void*)f_1759},
{"f_1770tcp.scm",(void*)f_1770},
{"f_1766tcp.scm",(void*)f_1766},
{"f_1683tcp.scm",(void*)f_1683},
{"f_1702tcp.scm",(void*)f_1702},
{"f_1713tcp.scm",(void*)f_1713},
{"f_1709tcp.scm",(void*)f_1709},
{"f_1693tcp.scm",(void*)f_1693},
{"f_1597tcp.scm",(void*)f_1597},
{"f_1607tcp.scm",(void*)f_1607},
{"f_1612tcp.scm",(void*)f_1612},
{"f_1648tcp.scm",(void*)f_1648},
{"f_1651tcp.scm",(void*)f_1651},
{"f_1654tcp.scm",(void*)f_1654},
{"f_1657tcp.scm",(void*)f_1657},
{"f_1634tcp.scm",(void*)f_1634},
{"f_1645tcp.scm",(void*)f_1645},
{"f_1641tcp.scm",(void*)f_1641},
{"f_1625tcp.scm",(void*)f_1625},
{"f_985tcp.scm",(void*)f_985},
{"f_1584tcp.scm",(void*)f_1584},
{"f_1595tcp.scm",(void*)f_1595},
{"f_1591tcp.scm",(void*)f_1591},
{"f_989tcp.scm",(void*)f_989},
{"f_992tcp.scm",(void*)f_992},
{"f_998tcp.scm",(void*)f_998},
{"f_1001tcp.scm",(void*)f_1001},
{"f_1004tcp.scm",(void*)f_1004},
{"f_1007tcp.scm",(void*)f_1007},
{"f_1488tcp.scm",(void*)f_1488},
{"f_1494tcp.scm",(void*)f_1494},
{"f_1563tcp.scm",(void*)f_1563},
{"f_1506tcp.scm",(void*)f_1506},
{"f_1510tcp.scm",(void*)f_1510},
{"f_1520tcp.scm",(void*)f_1520},
{"f_1536tcp.scm",(void*)f_1536},
{"f_1423tcp.scm",(void*)f_1423},
{"f_1429tcp.scm",(void*)f_1429},
{"f_1477tcp.scm",(void*)f_1477},
{"f_1380tcp.scm",(void*)f_1380},
{"f_1394tcp.scm",(void*)f_1394},
{"f_1397tcp.scm",(void*)f_1397},
{"f_1408tcp.scm",(void*)f_1408},
{"f_1404tcp.scm",(void*)f_1404},
{"f_1345tcp.scm",(void*)f_1345},
{"f_1367tcp.scm",(void*)f_1367},
{"f_1378tcp.scm",(void*)f_1378},
{"f_1374tcp.scm",(void*)f_1374},
{"f_1358tcp.scm",(void*)f_1358},
{"f_1323tcp.scm",(void*)f_1323},
{"f_1327tcp.scm",(void*)f_1327},
{"f_1081tcp.scm",(void*)f_1081},
{"f_1271tcp.scm",(void*)f_1271},
{"f_1281tcp.scm",(void*)f_1281},
{"f_1208tcp.scm",(void*)f_1208},
{"f_1255tcp.scm",(void*)f_1255},
{"f_1258tcp.scm",(void*)f_1258},
{"f_1216tcp.scm",(void*)f_1216},
{"f_1225tcp.scm",(void*)f_1225},
{"f_1228tcp.scm",(void*)f_1228},
{"f_1239tcp.scm",(void*)f_1239},
{"f_1235tcp.scm",(void*)f_1235},
{"f_1307tcp.scm",(void*)f_1307},
{"f_1287tcp.scm",(void*)f_1287},
{"f_1292tcp.scm",(void*)f_1292},
{"f_1301tcp.scm",(void*)f_1301},
{"f_1181tcp.scm",(void*)f_1181},
{"f_1082tcp.scm",(void*)f_1082},
{"f_1092tcp.scm",(void*)f_1092},
{"f_1174tcp.scm",(void*)f_1174},
{"f_1146tcp.scm",(void*)f_1146},
{"f_1157tcp.scm",(void*)f_1157},
{"f_1153tcp.scm",(void*)f_1153},
{"f_1114tcp.scm",(void*)f_1114},
{"f_1117tcp.scm",(void*)f_1117},
{"f_1120tcp.scm",(void*)f_1120},
{"f_1123tcp.scm",(void*)f_1123},
{"f_1008tcp.scm",(void*)f_1008},
{"f_1014tcp.scm",(void*)f_1014},
{"f_1065tcp.scm",(void*)f_1065},
{"f_1076tcp.scm",(void*)f_1076},
{"f_1072tcp.scm",(void*)f_1072},
{"f_1033tcp.scm",(void*)f_1033},
{"f_1036tcp.scm",(void*)f_1036},
{"f_1039tcp.scm",(void*)f_1039},
{"f_1042tcp.scm",(void*)f_1042},
{"f_954tcp.scm",(void*)f_954},
{"f_956tcp.scm",(void*)f_956},
{"f_901tcp.scm",(void*)f_901},
{"f_917tcp.scm",(void*)f_917},
{"f_928tcp.scm",(void*)f_928},
{"f_924tcp.scm",(void*)f_924},
{"f_892tcp.scm",(void*)f_892},
{"f_797tcp.scm",(void*)f_797},
{"f_847tcp.scm",(void*)f_847},
{"f_842tcp.scm",(void*)f_842},
{"f_799tcp.scm",(void*)f_799},
{"f_811tcp.scm",(void*)f_811},
{"f_830tcp.scm",(void*)f_830},
{"f_841tcp.scm",(void*)f_841},
{"f_837tcp.scm",(void*)f_837},
{"f_821tcp.scm",(void*)f_821},
{"f_805tcp.scm",(void*)f_805},
{"f_698tcp.scm",(void*)f_698},
{"f_780tcp.scm",(void*)f_780},
{"f_704tcp.scm",(void*)f_704},
{"f_773tcp.scm",(void*)f_773},
{"f_772tcp.scm",(void*)f_772},
{"f_757tcp.scm",(void*)f_757},
{"f_768tcp.scm",(void*)f_768},
{"f_764tcp.scm",(void*)f_764},
{"f_707tcp.scm",(void*)f_707},
{"f_710tcp.scm",(void*)f_710},
{"f_745tcp.scm",(void*)f_745},
{"f_713tcp.scm",(void*)f_713},
{"f_728tcp.scm",(void*)f_728},
{"f_739tcp.scm",(void*)f_739},
{"f_735tcp.scm",(void*)f_735},
{"f_719tcp.scm",(void*)f_719},
{"f_612tcp.scm",(void*)f_612},
{"f_621tcp.scm",(void*)f_621},
{"f_644tcp.scm",(void*)f_644},
{"f_648tcp.scm",(void*)f_648},
{"f_559tcp.scm",(void*)f_559},
{"f_563tcp.scm",(void*)f_563},
{"f_660tcp.scm",(void*)f_660},
{"f_671tcp.scm",(void*)f_671},
{"f_667tcp.scm",(void*)f_667},
{"f_654tcp.scm",(void*)f_654},
{"f_591tcp.scm",(void*)f_591},
{"f_597tcp.scm",(void*)f_597},
{"f_606tcp.scm",(void*)f_606},
{"f_577tcp.scm",(void*)f_577},
{"f_586tcp.scm",(void*)f_586},
{"f_571tcp.scm",(void*)f_571},
{"f_536tcp.scm",(void*)f_536},
{"f_527tcp.scm",(void*)f_527},
{"f_517tcp.scm",(void*)f_517},
{"f_500tcp.scm",(void*)f_500},
{"f_470tcp.scm",(void*)f_470},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
