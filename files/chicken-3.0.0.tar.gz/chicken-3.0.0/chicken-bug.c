/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2008-02-07 01:31
   Version 3.0.0 - linux-unix-gnu-x86	[ manyargs dload ptables applyhook ]
   (c)2000-2008 Felix L. Winkelmann	compiled 2008-02-07 on galinha (Linux)
   command line: chicken-bug.scm -quiet -no-trace -optimize-level 2 -include-path . -no-lambda-info -output-file chicken-bug.c
   used units: library eval extras srfi_13 posix utils tcp extras
*/

#include "chicken.h"


#ifndef C_TARGET_CC
# define C_TARGET_CC  C_INSTALL_CC
#endif

#ifndef C_TARGET_CXX
# define C_TARGET_CXX  C_INSTALL_CXX
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_149)
static void C_ccall f_149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_152)
static void C_ccall f_152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_155)
static void C_ccall f_155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_158)
static void C_ccall f_158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_161)
static void C_ccall f_161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_164)
static void C_ccall f_164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_167)
static void C_ccall f_167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_170)
static void C_ccall f_170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1072)
static void C_ccall f_1072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1068)
static void C_ccall f_1068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1065)
static void C_ccall f_1065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_983)
static void C_ccall f_983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1059)
static void C_ccall f_1059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1047)
static void C_ccall f_1047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1043)
static void C_ccall f_1043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1039)
static void C_ccall f_1039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1019)
static void C_ccall f_1019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_988)
static void C_ccall f_988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_968)
static void C_ccall f_968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_971)
static void C_ccall f_971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_904)
static void C_ccall f_904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_946)
static void C_ccall f_946r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_940)
static void C_ccall f_940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_910)
static void C_ccall f_910(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_ccall f_926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_835)
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_865)
static void C_ccall f_865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_877)
static void C_ccall f_877r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_883)
static void C_ccall f_883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_841)
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_807)
static void C_ccall f_807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_823)
static void C_ccall f_823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_608)
static void C_fcall f_608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_612)
static void C_ccall f_612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_619)
static void C_fcall f_619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_655)
static void C_ccall f_655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_647)
static void C_ccall f_647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_635)
static void C_ccall f_635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_554)
static void C_ccall f_554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_550)
static void C_ccall f_550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_ccall f_529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_417)
static void C_ccall f_417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_511)
static void C_ccall f_511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_507)
static void C_ccall f_507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_420)
static void C_fcall f_420(C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_426)
static void C_ccall f_426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_fcall f_432(C_word t0,C_word t1) C_noret;
C_noret_decl(f_482)
static void C_ccall f_482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_457)
static void C_ccall f_457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_ccall f_465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_447)
static void C_ccall f_447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_394)
static void C_ccall f_394(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_375)
static void C_ccall f_375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_385)
static void C_ccall f_385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_379)
static void C_ccall f_379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_366)
static void C_ccall f_366(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_370)
static void C_ccall f_370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_180)
static void C_ccall f_180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_183)
static void C_ccall f_183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_360)
static void C_ccall f_360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_186)
static void C_ccall f_186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_352)
static void C_ccall f_352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_189)
static void C_ccall f_189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_192)
static void C_ccall f_192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_195)
static void C_ccall f_195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_198)
static void C_ccall f_198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_201)
static void C_ccall f_201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_336)
static void C_ccall f_336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_204)
static void C_ccall f_204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_207)
static void C_ccall f_207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_210)
static void C_ccall f_210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_213)
static void C_ccall f_213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_216)
static void C_ccall f_216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_ccall f_324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_316)
static void C_ccall f_316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_ccall f_283(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_287)
static void C_ccall f_287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_292)
static void C_ccall f_292(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_222)
static void C_ccall f_222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_281)
static void C_ccall f_281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_267)
static void C_ccall f_267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_269)
static void C_ccall f_269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_277)
static void C_ccall f_277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_225)
static void C_ccall f_225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_228)
static void C_ccall f_228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_263)
static void C_ccall f_263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_237)
static void C_ccall f_237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_240)
static void C_ccall f_240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_245)
static void C_ccall f_245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_253)
static void C_ccall f_253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_231)
static void C_ccall f_231(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_608)
static void C_fcall trf_608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_608(t0,t1);}

C_noret_decl(trf_619)
static void C_fcall trf_619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_619(t0,t1);}

C_noret_decl(trf_420)
static void C_fcall trf_420(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_420(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_420(t0,t1);}

C_noret_decl(trf_432)
static void C_fcall trf_432(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_432(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_432(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(636)){
C_save(t1);
C_rereclaim2(636*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000xchicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org\012felix@call-with-current-continuation.org");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-janitors@nongnu.org");
lf[7]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014mx10.gnu.org\376\003\000\000\002\376B\000\000\014mx20.gnu.org\376\377\016");
lf[8]=C_h_intern(&lf[8],12,"collect-info");
lf[9]=C_h_intern(&lf[9],7,"newline");
lf[10]=C_h_intern(&lf[10],7,"display");
lf[11]=C_h_intern(&lf[11],8,"read-all");
lf[12]=C_h_intern(&lf[12],20,"with-input-from-pipe");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[14]=C_h_intern(&lf[14],5,"print");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[17]=C_h_intern(&lf[17],8,"feature\077");
lf[18]=C_h_intern(&lf[18],4,"unix");
lf[19]=C_h_intern(&lf[19],17,"\003syspeek-c-string");
lf[20]=C_h_intern(&lf[20],20,"with-input-from-file");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[24]=C_h_intern(&lf[24],6,"printf");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[26]=C_h_intern(&lf[26],11,"make-string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfor-each");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[29]=C_h_intern(&lf[29],4,"chop");
lf[30]=C_h_intern(&lf[30],4,"sort");
lf[31]=C_h_intern(&lf[31],8,"string<\077");
lf[32]=C_h_intern(&lf[32],7,"\003sysmap");
lf[33]=C_h_intern(&lf[33],15,"keyword->string");
lf[34]=C_h_intern(&lf[34],12,"\003sysfeatures");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024Include path:\011~s~%~%");
lf[37]=C_h_intern(&lf[37],21,"\003sysinclude-pathnames");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[40]=C_h_intern(&lf[40],12,"chicken-home");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[43]=C_h_intern(&lf[43],15,"chicken-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[46]=C_h_intern(&lf[46],14,"build-platform");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[48]=C_h_intern(&lf[48],16,"software-version");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[50]=C_h_intern(&lf[50],13,"software-type");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[52]=C_h_intern(&lf[52],12,"machine-type");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\030User information:\011~s~%~%");
lf[55]=C_h_intern(&lf[55],16,"user-information");
lf[56]=C_h_intern(&lf[56],15,"current-user-id");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[59]=C_h_intern(&lf[59],15,"seconds->string");
lf[60]=C_h_intern(&lf[60],15,"current-seconds");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[63]=C_h_intern(&lf[63],5,"usage");
lf[64]=C_h_intern(&lf[64],4,"exit");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[66]=C_h_intern(&lf[66],10,"user-input");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\001VThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012once you have fini"
"shed. Press CTRL-C to abort the program. You can\012also pass the description from "
"a file (just abort now and re-invoke\012\042chicken-bug\042 with one or more input files "
"given on the command-line)\012");
lf[68]=C_h_intern(&lf[68],13,"\003systty-port\077");
lf[69]=C_h_intern(&lf[69],18,"current-input-port");
lf[70]=C_h_intern(&lf[70],7,"justify");
lf[71]=C_h_intern(&lf[71],13,"string-append");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[73]=C_h_intern(&lf[73],4,"main");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_h_intern(&lf[75],8,"try-mail");
lf[76]=C_h_intern(&lf[76],21,"with-output-to-string");
lf[77]=C_h_intern(&lf[77],12,"mail-headers");
lf[78]=C_h_intern(&lf[78],7,"sprintf");
lf[79]=C_h_intern(&lf[79],15,"\003sysmatch-error");
lf[80]=C_h_intern(&lf[80],19,"seconds->local-time");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000G\012Could not send mail automatically!\012\012A bug report has been written to `");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[93]=C_h_intern(&lf[93],19,"with-output-to-file");
lf[94]=C_h_intern(&lf[94],9,"send-mail");
lf[95]=C_h_intern(&lf[95],13,"mail-date-str");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[100]=C_h_intern(&lf[100],10,"string-pad");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[125]=C_h_intern(&lf[125],17,"seconds->utc-time");
lf[126]=C_h_intern(&lf[126],9,"mail-read");
lf[127]=C_h_intern(&lf[127],9,"substring");
lf[128]=C_h_intern(&lf[128],9,"condition");
lf[129]=C_h_intern(&lf[129],17,"close-output-port");
lf[130]=C_h_intern(&lf[130],16,"close-input-port");
lf[131]=C_h_intern(&lf[131],9,"read-line");
lf[132]=C_h_intern(&lf[132],22,"with-exception-handler");
lf[133]=C_h_intern(&lf[133],30,"call-with-current-continuation");
lf[134]=C_h_intern(&lf[134],10,"mail-write");
lf[135]=C_h_intern(&lf[135],10,"mail-check");
lf[136]=C_h_intern(&lf[136],11,"tcp-connect");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000QBug report successfully mailed to the Chicken maintainers.\012Thank you very m"
"uch!\012\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_149,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k147 */
static void C_ccall f_149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_152,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k150 in k147 */
static void C_ccall f_152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_152,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_155,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k153 in k150 in k147 */
static void C_ccall f_155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_158,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k156 in k153 in k150 in k147 */
static void C_ccall f_158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_161,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_164,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_167,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_170,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_170,2,t0,t1);}
t2=C_mutate(&lf[0],lf[1]);
t3=C_mutate(&lf[2],lf[3]);
t4=C_mutate(&lf[4],lf[5]);
t5=C_mutate(&lf[6],lf[7]);
t6=C_mutate((C_word*)lf[8]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_176,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[63]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_366,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[66]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_375,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[70]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_394,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_413,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[75]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_556,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[95]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_597,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[77]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_785,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[126]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_803,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[134]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_889,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[135]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_958,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[94]+1,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_979,tmp=(C_word)a,a+=2,tmp));
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1072,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 239  command-line-arguments */
t20=C_retrieve(lf[148]);
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}

/* k1070 in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 239  main */
t2=*((C_word*)lf[73]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1060 in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1065,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=C_retrieve(lf[147]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1066 in k1060 in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1063 in k1060 in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_979,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_983,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 222  print */
t7=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t7))(5,t7,t6,lf[145],t2,lf[146]);}

/* k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_988,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_994,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 223  ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_994,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* chicken-bug.scm: 225  call-with-current-continuation */
t5=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t4);}

/* a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1000,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1059,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 227  mail-read */
t5=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1057 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 227  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1055,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 228  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[144]);}

/* k1053 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 228  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 229  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[143]);}

/* k1049 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 229  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1047,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 230  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[142]);}

/* k1045 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 230  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1016,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1043,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm: 231  mail-write */
t4=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1041 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 231  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1019,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1039,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 232  string-append */
t5=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t5))(7,t5,t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[139],((C_word*)t0)[2],lf[140]);}

/* k1037 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 232  mail-write */
t2=*((C_word*)lf[134]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1033 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 232  mail-check */
t2=*((C_word*)lf[135]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1019,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 233  display */
t3=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[138],((C_word*)t0)[3]);}

/* k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 234  close-input-port */
t3=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 235  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 236  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[137]);}

/* k1029 in k1026 in k1023 in k1020 in k1017 in k1014 in k1011 in k1008 in k1005 in k1002 in a999 in a993 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* a987 in k981 in send-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_988,2,t0,t1);}
/* chicken-bug.scm: 224  tcp-connect */
t2=C_retrieve(lf[136]);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[2],C_fix(25));}

/* mail-check in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_958,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?(C_word)C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_968,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 217  close-input-port */
t9=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t9))(3,t9,t8,t2);}}

/* k966 in mail-check in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 218  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k969 in k966 in mail-check in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 219  k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_889,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_893,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_904,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 207  call-with-current-continuation */
t8=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}

/* a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_904,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_910,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_934,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 207  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a933 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_940,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_946,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 207  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a945 in a933 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_946(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_946r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_946r(t0,t1,t2);}}

static void C_ccall f_946r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_952,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 207  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a951 in a945 in a933 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_952,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a939 in a933 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_940,2,t0,t1);}
/* chicken-bug.scm: 207  display */
t2=*((C_word*)lf[10]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a909 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_910(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_910,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 207  g84 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a915 in a909 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_916,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_923,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 208  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k921 in a915 in a909 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 208  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k924 in k921 in a915 in a909 in a903 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k900 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k891 in mail-write in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 210  mail-read */
t2=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_803,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_807,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_833,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_835,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 198  call-with-current-continuation */
t7=*((C_word*)lf[133]+1);
((C_proc3)C_retrieve_proc(t7))(3,t7,t5,t6);}

/* a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_835(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_835,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_841,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_865,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 198  with-exception-handler */
t5=C_retrieve(lf[132]);
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* a864 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_877,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 198  ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a876 in a864 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_877(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_877r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_877r(t0,t1,t2);}}

static void C_ccall f_877r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_883,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 198  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a882 in a876 in a864 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_883,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a870 in a864 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
/* chicken-bug.scm: 198  read-line */
t2=C_retrieve(lf[131]);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* a840 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_841,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_847,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 198  g69 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a846 in a840 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_847,2,t0,t1);}
t2=(C_word)C_i_structurep(((C_word*)t0)[4],lf[128]);
t3=(C_truep(t2)?(C_word)C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_854,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 199  close-input-port */
t5=*((C_word*)lf[130]+1);
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[2]);}

/* k852 in a846 in a840 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 199  close-output-port */
t3=*((C_word*)lf[129]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k855 in k852 in a846 in a840 in a834 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k831 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k805 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_807,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_string_ref(t1,C_fix(0));
if(C_truep((C_word)C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 202  substring */
t4=*((C_word*)lf[127]+1);
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm: 203  mail-read */
t3=*((C_word*)lf[126]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k821 in k805 in mail-read in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 202  string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_793,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_797,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_801,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 192  current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k799 in mail-headers in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 192  seconds->utc-time */
t2=C_retrieve(lf[125]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k795 in mail-headers in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 192  mail-date-str */
t2=*((C_word*)lf[95]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k791 in mail-headers in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 191  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[2],lf[120],t1,lf[121],lf[122],lf[123],lf[124]);}

/* mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_597,3,t0,t1,t2);}
t3=(C_word)C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_608,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_608(t5,lf[113]);
case C_fix(1):
t5=t4;
f_608(t5,lf[114]);
case C_fix(2):
t5=t4;
f_608(t5,lf[115]);
case C_fix(3):
t5=t4;
f_608(t5,lf[116]);
case C_fix(4):
t5=t4;
f_608(t5,lf[117]);
case C_fix(5):
t5=t4;
f_608(t5,lf[118]);
default:
t5=(C_word)C_eqp(t3,C_fix(6));
t6=t4;
f_608(t6,(C_truep(t5)?lf[119]:C_SCHEME_UNDEFINED));}}

/* k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_fcall f_608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_608,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_612,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_740,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm: 167  number->string */
C_number_to_string(3,0,t3,t4);}

/* k738 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 167  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_612,2,t0,t1);}
t2=(C_word)C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_619,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_619(t4,lf[101]);
case C_fix(1):
t4=t3;
f_619(t4,lf[102]);
case C_fix(2):
t4=t3;
f_619(t4,lf[103]);
case C_fix(3):
t4=t3;
f_619(t4,lf[104]);
case C_fix(4):
t4=t3;
f_619(t4,lf[105]);
case C_fix(5):
t4=t3;
f_619(t4,lf[106]);
case C_fix(6):
t4=t3;
f_619(t4,lf[107]);
case C_fix(7):
t4=t3;
f_619(t4,lf[108]);
case C_fix(8):
t4=t3;
f_619(t4,lf[109]);
case C_fix(9):
t4=t3;
f_619(t4,lf[110]);
case C_fix(10):
t4=t3;
f_619(t4,lf[111]);
default:
t4=(C_word)C_eqp(t2,C_fix(11));
t5=t3;
f_619(t5,(C_truep(t4)?lf[112]:C_SCHEME_UNDEFINED));}}

/* k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_fcall f_619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_619,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_623,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=(C_word)C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm: 181  number->string */
C_number_to_string(3,0,t2,t4);}

/* k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_627,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_655,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm: 183  number->string */
C_number_to_string(3,0,t3,t4);}

/* k653 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 183  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k625 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_647,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm: 185  number->string */
C_number_to_string(3,0,t3,t4);}

/* k645 in k625 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 185  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k629 in k625 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_635,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_word)C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm: 187  number->string */
C_number_to_string(3,0,t3,t4);}

/* k637 in k629 in k625 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 187  string-pad */
t2=C_retrieve(lf[100]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k633 in k629 in k625 in k621 in k617 in k610 in k606 in mail-date-str in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 158  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc13)C_retrieve_proc(t2))(13,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[96],((C_word*)t0)[3],lf[97],((C_word*)t0)[2],lf[98],t1,lf[99]);}

/* try-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_556,6,t0,t1,t2,t3,t4,t5);}
if(C_truep((C_word)C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_566,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_574,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 150  with-output-to-file */
t8=C_retrieve(lf[93]);
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_581,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=(C_word)C_i_car(t2);
/* chicken-bug.scm: 154  send-mail */
t8=*((C_word*)lf[94]+1);
((C_proc6)C_retrieve_proc(t8))(6,t8,t6,t7,t5,t4,t3);}}

/* k579 in try-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(C_word)C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm: 155  try-mail */
t3=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a573 in try-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
/* chicken-bug.scm: 151  print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k564 in try-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_569,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 152  print */
t3=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t3))(5,t3,t2,lf[91],((C_word*)t0)[2],lf[92]);}

/* k567 in k564 in try-mail in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 153  print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[90],lf[3]);}

/* main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_413,3,t0,t1,t2);}
t3=lf[74];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_417,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_513,a[2]=t8,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* for-each */
t11=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,t2);}

/* a512 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_513,3,t0,t1,t2);}
if(C_truep((C_word)C_i_string_equal_p(lf[82],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_525,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 107  user-input */
t6=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t3=t2;
if(C_truep((C_truep((C_word)C_i_equalp(t3,lf[84]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[85]))?C_SCHEME_TRUE:(C_truep((C_word)C_i_equalp(t3,lf[86]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-bug.scm: 109  usage */
t4=*((C_word*)lf[63]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,C_fix(0));}
else{
if(C_truep((C_word)C_i_string_equal_p(lf[87],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_550,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_554,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 118  read-all */
t7=C_retrieve(lf[11]);
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,t2);}}}}

/* k552 in a512 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 115  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[88],((C_word*)t0)[2],lf[89],t1);}

/* k548 in a512 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k527 in a512 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 107  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[83],t1);}

/* k523 in a512 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_420(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_507,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_511,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 121  user-input */
t5=*((C_word*)lf[66]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}

/* k509 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 121  string-append */
t2=*((C_word*)lf[71]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[81],t1);}

/* k505 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_420(t3,t2);}

/* k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_fcall f_420(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_420,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 122  newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_503,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 123  current-seconds */
t4=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k501 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 123  seconds->local-time */
t2=C_retrieve(lf[80]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_426,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep((C_word)C_i_vectorp(t1))){
t3=(C_word)C_i_vector_length(t1);
t4=t2;
f_432(t4,(C_word)C_eqp(t3,C_fix(10)));}
else{
t3=t2;
f_432(t3,C_SCHEME_FALSE);}}

/* k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_fcall f_432(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_432,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(3));
t3=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(4));
t4=(C_word)C_i_vector_ref(((C_word*)t0)[5],C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_447,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 126  print */
t6=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(C_word)C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_482,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 130  justify */
t8=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,t3);}}
else{
/* chicken-bug.scm: 123  ##sys#match-error */
t2=*((C_word*)lf[79]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* k480 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_486,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 130  justify */
t3=*((C_word*)lf[70]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k484 in k480 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 130  sprintf */
t2=C_retrieve(lf[78]);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[1],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k455 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_461,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm: 131  mail-headers */
t3=*((C_word*)lf[77]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k459 in k455 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_465,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_467,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 132  with-output-to-string */
t4=C_retrieve(lf[76]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* a466 in k459 in k455 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_471,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 134  print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k469 in a466 in k459 in k455 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 135  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k463 in k459 in k455 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 128  try-mail */
t2=*((C_word*)lf[75]+1);
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[4],lf[7],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k445 in k430 in k424 in k421 in k418 in k415 in main in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 127  collect-info */
t2=*((C_word*)lf[8]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* justify in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_394(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_394,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 94   number->string */
C_number_to_string(3,0,t3,t2);}

/* k396 in justify in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=(C_word)C_i_string_length(t1);
if(C_truep((C_word)C_i_greaterp(t2,C_fix(1)))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}
else{
/* chicken-bug.scm: 97   string-append */
t3=*((C_word*)lf[71]+1);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[72],t1);}}

/* user-input in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_375,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_379,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_385,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 81   current-input-port */
t5=*((C_word*)lf[69]+1);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k390 in user-input in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 81   ##sys#tty-port? */
t2=C_retrieve(lf[68]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k383 in user-input in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm: 82   print */
t2=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[67]);}
else{
t2=((C_word*)t0)[2];
f_379(2,t2,C_SCHEME_UNDEFINED);}}

/* k377 in user-input in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 91   read-all */
t2=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* usage in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_366(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_366,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_370,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 66   print */
t4=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[65]);}

/* k368 in usage in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 78   exit */
t2=C_retrieve(lf[64]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_180,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 32   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[62]);}

/* k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_183,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 33   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[61]);}

/* k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_186,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_360,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_364,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 34   current-seconds */
t5=C_retrieve(lf[60]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k362 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 34   seconds->string */
t2=C_retrieve(lf[59]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k358 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 34   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[57],t1,lf[58]);}

/* k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_189,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 35   current-user-id */
t5=C_retrieve(lf[56]);
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}

/* k354 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 35   user-information */
t2=C_retrieve(lf[55]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k350 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 35   printf */
t2=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[54],t1);}

/* k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_192,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 36   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[53]);}

/* k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 37   machine-type */
t4=C_retrieve(lf[52]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k346 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 37   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[51],t1);}

/* k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 38   software-type */
t4=C_retrieve(lf[50]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k342 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 38   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[49],t1);}

/* k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_201,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 39   software-version */
t4=C_retrieve(lf[48]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k338 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 39   print */
t2=*((C_word*)lf[14]+1);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[47],t1);}

/* k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_204,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_336,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 40   build-platform */
t4=C_retrieve(lf[46]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k334 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 40   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[44],t1,lf[45]);}

/* k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_207,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_332,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 41   chicken-version */
t4=C_retrieve(lf[43]);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,C_SCHEME_TRUE);}

/* k330 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 41   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[41],t1,lf[42]);}

/* k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_210,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_328,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 42   chicken-home */
t4=C_retrieve(lf[40]);
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k326 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 42   print */
t2=*((C_word*)lf[14]+1);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[2],lf[38],t1,lf[39]);}

/* k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 43   printf */
t3=C_retrieve(lf[24]);
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,lf[36],C_retrieve(lf[37]));}

/* k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_213,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 44   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[35]);}

/* k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_283,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_316,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_320,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_324,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* map */
t7=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_retrieve(lf[33]),C_retrieve(lf[34]));}

/* k322 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   sort */
t2=C_retrieve(lf[30]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[31]+1));}

/* k318 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 52   chop */
t2=C_retrieve(lf[29]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k314 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a282 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_283(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_283,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_287,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm: 47   display */
t4=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[28]);}

/* k285 in a282 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_292,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a291 in k285 in a282 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_292(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_292,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_300,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(C_word)C_i_string_length(t2);
t5=(C_word)C_fixnum_difference(C_fix(16),t4);
t6=(C_word)C_i_fixnum_max(C_fix(1),t5);
/* chicken-bug.scm: 50   make-string */
t7=*((C_word*)lf[26]+1);
((C_proc4)C_retrieve_proc(t7))(4,t7,t3,t6,C_make_character(32));}

/* k298 in a291 in k285 in a282 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 50   printf */
t2=C_retrieve(lf[24]);
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[25],((C_word*)t0)[2],t1);}

/* k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_222,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 53   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}

/* k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_267,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_281,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k279 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 54   make-pathname */
t2=C_retrieve(lf[21]);
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[22]);}

/* k265 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_269,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 54   with-input-from-file */
t3=C_retrieve(lf[20]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a268 in k265 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_277,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 56   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k275 in a268 in k265 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 56   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_228,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 57   newline */
t3=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_231,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_237,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_263,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k261 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep((C_word)C_i_string_equal_p(t1,lf[16]))){
/* chicken-bug.scm: 58   feature? */
t2=C_retrieve(lf[17]);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],lf[18]);}
else{
t2=((C_word*)t0)[2];
f_237(2,t2,C_SCHEME_FALSE);}}

/* k235 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_237,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_240,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 59   print */
t3=*((C_word*)lf[14]+1);
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[15]);}
else{
t2=((C_word*)t0)[2];
f_231(2,t2,C_SCHEME_UNDEFINED);}}

/* k238 in k235 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_245,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm: 60   with-input-from-pipe */
t3=C_retrieve(lf[12]);
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],lf[13],t2);}

/* a244 in k238 in k235 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_253,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm: 62   read-all */
t3=C_retrieve(lf[11]);
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k251 in a244 in k238 in k235 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 62   display */
t2=*((C_word*)lf[10]+1);
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k229 in k226 in k223 in k220 in k217 in k214 in k211 in k208 in k205 in k202 in k199 in k196 in k193 in k190 in k187 in k184 in k181 in k178 in collect-info in k168 in k165 in k162 in k159 in k156 in k153 in k150 in k147 */
static void C_ccall f_231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm: 63   newline */
t2=*((C_word*)lf[9]+1);
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[160] = {
{"toplevelchicken-bug.scm",(void*)C_toplevel},
{"f_149chicken-bug.scm",(void*)f_149},
{"f_152chicken-bug.scm",(void*)f_152},
{"f_155chicken-bug.scm",(void*)f_155},
{"f_158chicken-bug.scm",(void*)f_158},
{"f_161chicken-bug.scm",(void*)f_161},
{"f_164chicken-bug.scm",(void*)f_164},
{"f_167chicken-bug.scm",(void*)f_167},
{"f_170chicken-bug.scm",(void*)f_170},
{"f_1072chicken-bug.scm",(void*)f_1072},
{"f_1062chicken-bug.scm",(void*)f_1062},
{"f_1068chicken-bug.scm",(void*)f_1068},
{"f_1065chicken-bug.scm",(void*)f_1065},
{"f_979chicken-bug.scm",(void*)f_979},
{"f_983chicken-bug.scm",(void*)f_983},
{"f_994chicken-bug.scm",(void*)f_994},
{"f_1000chicken-bug.scm",(void*)f_1000},
{"f_1059chicken-bug.scm",(void*)f_1059},
{"f_1004chicken-bug.scm",(void*)f_1004},
{"f_1055chicken-bug.scm",(void*)f_1055},
{"f_1007chicken-bug.scm",(void*)f_1007},
{"f_1051chicken-bug.scm",(void*)f_1051},
{"f_1010chicken-bug.scm",(void*)f_1010},
{"f_1047chicken-bug.scm",(void*)f_1047},
{"f_1013chicken-bug.scm",(void*)f_1013},
{"f_1043chicken-bug.scm",(void*)f_1043},
{"f_1016chicken-bug.scm",(void*)f_1016},
{"f_1039chicken-bug.scm",(void*)f_1039},
{"f_1035chicken-bug.scm",(void*)f_1035},
{"f_1019chicken-bug.scm",(void*)f_1019},
{"f_1022chicken-bug.scm",(void*)f_1022},
{"f_1025chicken-bug.scm",(void*)f_1025},
{"f_1028chicken-bug.scm",(void*)f_1028},
{"f_1031chicken-bug.scm",(void*)f_1031},
{"f_988chicken-bug.scm",(void*)f_988},
{"f_958chicken-bug.scm",(void*)f_958},
{"f_968chicken-bug.scm",(void*)f_968},
{"f_971chicken-bug.scm",(void*)f_971},
{"f_889chicken-bug.scm",(void*)f_889},
{"f_904chicken-bug.scm",(void*)f_904},
{"f_934chicken-bug.scm",(void*)f_934},
{"f_946chicken-bug.scm",(void*)f_946},
{"f_952chicken-bug.scm",(void*)f_952},
{"f_940chicken-bug.scm",(void*)f_940},
{"f_910chicken-bug.scm",(void*)f_910},
{"f_916chicken-bug.scm",(void*)f_916},
{"f_923chicken-bug.scm",(void*)f_923},
{"f_926chicken-bug.scm",(void*)f_926},
{"f_902chicken-bug.scm",(void*)f_902},
{"f_893chicken-bug.scm",(void*)f_893},
{"f_803chicken-bug.scm",(void*)f_803},
{"f_835chicken-bug.scm",(void*)f_835},
{"f_865chicken-bug.scm",(void*)f_865},
{"f_877chicken-bug.scm",(void*)f_877},
{"f_883chicken-bug.scm",(void*)f_883},
{"f_871chicken-bug.scm",(void*)f_871},
{"f_841chicken-bug.scm",(void*)f_841},
{"f_847chicken-bug.scm",(void*)f_847},
{"f_854chicken-bug.scm",(void*)f_854},
{"f_857chicken-bug.scm",(void*)f_857},
{"f_833chicken-bug.scm",(void*)f_833},
{"f_807chicken-bug.scm",(void*)f_807},
{"f_823chicken-bug.scm",(void*)f_823},
{"f_785chicken-bug.scm",(void*)f_785},
{"f_801chicken-bug.scm",(void*)f_801},
{"f_797chicken-bug.scm",(void*)f_797},
{"f_793chicken-bug.scm",(void*)f_793},
{"f_597chicken-bug.scm",(void*)f_597},
{"f_608chicken-bug.scm",(void*)f_608},
{"f_740chicken-bug.scm",(void*)f_740},
{"f_612chicken-bug.scm",(void*)f_612},
{"f_619chicken-bug.scm",(void*)f_619},
{"f_623chicken-bug.scm",(void*)f_623},
{"f_655chicken-bug.scm",(void*)f_655},
{"f_627chicken-bug.scm",(void*)f_627},
{"f_647chicken-bug.scm",(void*)f_647},
{"f_631chicken-bug.scm",(void*)f_631},
{"f_639chicken-bug.scm",(void*)f_639},
{"f_635chicken-bug.scm",(void*)f_635},
{"f_556chicken-bug.scm",(void*)f_556},
{"f_581chicken-bug.scm",(void*)f_581},
{"f_574chicken-bug.scm",(void*)f_574},
{"f_566chicken-bug.scm",(void*)f_566},
{"f_569chicken-bug.scm",(void*)f_569},
{"f_413chicken-bug.scm",(void*)f_413},
{"f_513chicken-bug.scm",(void*)f_513},
{"f_554chicken-bug.scm",(void*)f_554},
{"f_550chicken-bug.scm",(void*)f_550},
{"f_529chicken-bug.scm",(void*)f_529},
{"f_525chicken-bug.scm",(void*)f_525},
{"f_417chicken-bug.scm",(void*)f_417},
{"f_511chicken-bug.scm",(void*)f_511},
{"f_507chicken-bug.scm",(void*)f_507},
{"f_420chicken-bug.scm",(void*)f_420},
{"f_423chicken-bug.scm",(void*)f_423},
{"f_503chicken-bug.scm",(void*)f_503},
{"f_426chicken-bug.scm",(void*)f_426},
{"f_432chicken-bug.scm",(void*)f_432},
{"f_482chicken-bug.scm",(void*)f_482},
{"f_486chicken-bug.scm",(void*)f_486},
{"f_457chicken-bug.scm",(void*)f_457},
{"f_461chicken-bug.scm",(void*)f_461},
{"f_467chicken-bug.scm",(void*)f_467},
{"f_471chicken-bug.scm",(void*)f_471},
{"f_465chicken-bug.scm",(void*)f_465},
{"f_447chicken-bug.scm",(void*)f_447},
{"f_394chicken-bug.scm",(void*)f_394},
{"f_398chicken-bug.scm",(void*)f_398},
{"f_375chicken-bug.scm",(void*)f_375},
{"f_392chicken-bug.scm",(void*)f_392},
{"f_385chicken-bug.scm",(void*)f_385},
{"f_379chicken-bug.scm",(void*)f_379},
{"f_366chicken-bug.scm",(void*)f_366},
{"f_370chicken-bug.scm",(void*)f_370},
{"f_176chicken-bug.scm",(void*)f_176},
{"f_180chicken-bug.scm",(void*)f_180},
{"f_183chicken-bug.scm",(void*)f_183},
{"f_364chicken-bug.scm",(void*)f_364},
{"f_360chicken-bug.scm",(void*)f_360},
{"f_186chicken-bug.scm",(void*)f_186},
{"f_356chicken-bug.scm",(void*)f_356},
{"f_352chicken-bug.scm",(void*)f_352},
{"f_189chicken-bug.scm",(void*)f_189},
{"f_192chicken-bug.scm",(void*)f_192},
{"f_348chicken-bug.scm",(void*)f_348},
{"f_195chicken-bug.scm",(void*)f_195},
{"f_344chicken-bug.scm",(void*)f_344},
{"f_198chicken-bug.scm",(void*)f_198},
{"f_340chicken-bug.scm",(void*)f_340},
{"f_201chicken-bug.scm",(void*)f_201},
{"f_336chicken-bug.scm",(void*)f_336},
{"f_204chicken-bug.scm",(void*)f_204},
{"f_332chicken-bug.scm",(void*)f_332},
{"f_207chicken-bug.scm",(void*)f_207},
{"f_328chicken-bug.scm",(void*)f_328},
{"f_210chicken-bug.scm",(void*)f_210},
{"f_213chicken-bug.scm",(void*)f_213},
{"f_216chicken-bug.scm",(void*)f_216},
{"f_324chicken-bug.scm",(void*)f_324},
{"f_320chicken-bug.scm",(void*)f_320},
{"f_316chicken-bug.scm",(void*)f_316},
{"f_283chicken-bug.scm",(void*)f_283},
{"f_287chicken-bug.scm",(void*)f_287},
{"f_292chicken-bug.scm",(void*)f_292},
{"f_300chicken-bug.scm",(void*)f_300},
{"f_219chicken-bug.scm",(void*)f_219},
{"f_222chicken-bug.scm",(void*)f_222},
{"f_281chicken-bug.scm",(void*)f_281},
{"f_267chicken-bug.scm",(void*)f_267},
{"f_269chicken-bug.scm",(void*)f_269},
{"f_277chicken-bug.scm",(void*)f_277},
{"f_225chicken-bug.scm",(void*)f_225},
{"f_228chicken-bug.scm",(void*)f_228},
{"f_263chicken-bug.scm",(void*)f_263},
{"f_237chicken-bug.scm",(void*)f_237},
{"f_240chicken-bug.scm",(void*)f_240},
{"f_245chicken-bug.scm",(void*)f_245},
{"f_253chicken-bug.scm",(void*)f_253},
{"f_231chicken-bug.scm",(void*)f_231},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
