/* Copyright 1998 Lars T Hansen.
 * 
 * $Id: bdw-larceny.c 2543 2005-07-20 21:54:03Z pnkfelix $
 *
 * Larceny run-time system -- wrapper for larceny.c, with Boehm collector.
 */

#define BDW_GC
#include "larceny.c"

/* eof */
