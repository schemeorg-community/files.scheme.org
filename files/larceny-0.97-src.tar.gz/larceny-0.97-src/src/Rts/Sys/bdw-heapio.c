/* $Id: bdw-heapio.c 2543 2005-07-20 21:54:03Z pnkfelix $ 
 */

#define BDW_GC
#include "heapio.c"

/* eof */
