/* Generated from chicken-uninstall.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-uninstall.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file chicken-uninstall.c
   used units: library eval srfi_1 posix data_structures utils ports regex srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[76];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_395)
static void C_ccall f_395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_404)
static void C_ccall f_404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_407)
static void C_ccall f_407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_413)
static void C_ccall f_413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_416)
static void C_ccall f_416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_423)
static void C_ccall f_423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_730)
static void C_fcall f_730(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_823)
static void C_fcall f_823(C_word t0,C_word t1) C_noret;
C_noret_decl(f_926)
static void C_fcall f_926(C_word t0,C_word t1) C_noret;
C_noret_decl(f1104)
static void C_ccall f1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1099)
static void C_ccall f1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_958)
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_952)
static void C_ccall f_952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_838)
static void C_ccall f_838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1094)
static void C_ccall f1094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1089)
static void C_ccall f1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_740)
static void C_ccall f_740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_753)
static void C_fcall f_753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_801)
static void C_ccall f_801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_780)
static void C_fcall f_780(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_531)
static void C_ccall f_531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_fcall f_490(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_ccall f_467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_478)
static void C_ccall f_478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_474)
static void C_ccall f_474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_624)
static void C_ccall f_624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_608)
static void C_ccall f_608r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_614)
static void C_ccall f_614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_584)
static void C_ccall f_584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_602)
static void C_ccall f_602(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_600)
static void C_ccall f_600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_596)
static void C_ccall f_596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_592)
static void C_ccall f_592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_557)
static void C_ccall f_557(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_537)
static void C_ccall f_537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_546)
static void C_ccall f_546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_644)
static void C_fcall f_644(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_656)
static void C_ccall f_656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_685)
static void C_ccall f_685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_675)
static void C_ccall f_675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_683)
static void C_ccall f_683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_670)
static void C_ccall f_670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1031)
static void C_ccall f_1031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_427)
static void C_fcall f_427(C_word t0) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_445)
static void C_ccall f_445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_451)
static void C_ccall f_451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_730)
static void C_fcall trf_730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_730(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_730(t0,t1,t2,t3);}

C_noret_decl(trf_823)
static void C_fcall trf_823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_823(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_823(t0,t1);}

C_noret_decl(trf_926)
static void C_fcall trf_926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_926(t0,t1);}

C_noret_decl(trf_753)
static void C_fcall trf_753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_753(t0,t1,t2);}

C_noret_decl(trf_780)
static void C_fcall trf_780(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_780(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_780(t0,t1,t2);}

C_noret_decl(trf_490)
static void C_fcall trf_490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_490(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_490(t0,t1,t2);}

C_noret_decl(trf_644)
static void C_fcall trf_644(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_644(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_644(t0,t1,t2);}

C_noret_decl(trf_427)
static void C_fcall trf_427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_427(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_427(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(462)){
C_save(t1);
C_rereclaim2(462*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,76);
lf[4]=C_h_intern(&lf[4],13,"make-pathname");
lf[5]=C_h_intern(&lf[5],17,"get-output-string");
lf[6]=C_h_intern(&lf[6],7,"display");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\010chicken/");
lf[8]=C_h_intern(&lf[8],18,"open-output-string");
lf[9]=C_h_intern(&lf[9],17,"\003syspeek-c-string");
lf[10]=C_h_intern(&lf[10],15,"repository-path");
lf[12]=C_h_intern(&lf[12],25,"\003sysimplicit-exit-handler");
lf[13]=C_h_intern(&lf[13],5,"print");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\022nothing to remove.");
lf[15]=C_h_intern(&lf[15],26,"setup-api#remove-extension");
lf[16]=C_h_intern(&lf[16],16,"\003sysdynamic-wind");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\011removing ");
lf[18]=C_h_intern(&lf[18],7,"aborted");
lf[19]=C_h_intern(&lf[19],4,"exit");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\010aborted.");
lf[21]=C_h_intern(&lf[21],6,"signal");
lf[22]=C_h_intern(&lf[22],10,"yes-or-no\077");
lf[23]=C_h_intern(&lf[23],8,"\000default");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[25]=C_h_intern(&lf[25],6,"\000abort");
lf[26]=C_h_intern(&lf[26],21,"setup-api#abort-setup");
lf[27]=C_h_intern(&lf[27],18,"string-concatenate");
lf[28]=C_h_intern(&lf[28],6,"append");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000+About to delete the following extensions:\012\012\376\377\016");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030\012Do you want to proceed\077\376\377\016");
lf[31]=C_h_intern(&lf[31],13,"string-append");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[34]=C_h_intern(&lf[34],7,"\003sysmap");
lf[35]=C_h_intern(&lf[35],22,"with-exception-handler");
lf[36]=C_h_intern(&lf[36],30,"call-with-current-continuation");
lf[37]=C_h_intern(&lf[37],17,"delete-duplicates");
lf[38]=C_h_intern(&lf[38],8,"string=\077");
lf[39]=C_h_intern(&lf[39],11,"concatenate");
lf[40]=C_h_intern(&lf[40],4,"grep");
lf[41]=C_h_intern(&lf[41],13,"pathname-file");
lf[42]=C_h_intern(&lf[42],4,"glob");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[45]=C_h_intern(&lf[45],7,"reverse");
lf[46]=C_h_intern(&lf[46],6,"regexp");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[49]=C_h_intern(&lf[49],13,"regexp-escape");
lf[50]=C_h_intern(&lf[50],12,"glob->regexp");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\002\034usage: chicken-uninstall [OPTION | PATTERN] ...\012\012  -h   -help              "
"      show this message and exit\012  -v   -version                 show version an"
"d exit\012       -force                   don\047t ask, delete whatever matches\012      "
" -exact                   treat PATTERN as exact match (not a pattern)\012  -s   -s"
"udo                    use sudo(1) for deleting files\012       -host              "
"      when cross-compiling, uninstall host extensions only\012       -target       "
"           when cross-compiling, uninstall target extensions only");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[55]=C_h_intern(&lf[55],15,"chicken-version");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006-exact");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[62]=C_h_intern(&lf[62],22,"setup-api#sudo-install");
lf[63]=C_h_intern(&lf[63],6,"string");
lf[64]=C_h_intern(&lf[64],4,"memq");
lf[65]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\377\016");
lf[66]=C_h_intern(&lf[66],5,"every");
lf[67]=C_h_intern(&lf[67],16,"\003sysstring->list");
lf[68]=C_h_intern(&lf[68],9,"substring");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[71]=C_h_intern(&lf[71],22,"command-line-arguments");
lf[72]=C_h_intern(&lf[72],8,"feature\077");
lf[73]=C_h_intern(&lf[73],14,"\000cross-chicken");
lf[74]=C_h_intern(&lf[74],11,"\003sysrequire");
lf[75]=C_h_intern(&lf[75],9,"setup-api");
C_register_lf2(lf,76,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k387 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k390 in k387 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_395,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k393 in k390 in k387 */
static void C_ccall f_395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k396 in k393 in k390 in k387 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_407,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_407,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_413,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_416,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[74]))(3,*((C_word*)lf[74]+1),t2,lf[75]);}

/* k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_423,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* feature? */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,lf[73]);}

/* k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_423,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,C_retrieve2(lf[0],"main#*cross-chicken*"));
t4=C_mutate(&lf[2] /* (set! main#*target-extensions* ...) */,C_retrieve2(lf[0],"main#*cross-chicken*"));
t5=C_mutate(&lf[3] /* (set! main#repo-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_427,tmp=(C_word)a,a+=2,tmp));
t6=lf[11] /* main#*force* */ =C_SCHEME_FALSE;;
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1025,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1035,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[71]))(2,*((C_word*)lf[71]+1),t8);}

/* k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_730,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_730(t7,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_730(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_730,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_740,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1089,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t5,lf[51]);}
else{
t5=t4;
f_740(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=C_i_car(t2);
t5=C_i_string_equal_p(t4,lf[52]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_823,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t4,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t5)){
t7=t6;
f_823(t7,t5);}
else{
t7=C_i_string_equal_p(t4,lf[69]);
t8=t6;
f_823(t8,(C_truep(t7)?t7:C_i_string_equal_p(t4,lf[70])));}}}

/* k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_823(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_823,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t3,lf[51]);}
else{
t2=C_i_string_equal_p(((C_word*)t0)[6],lf[53]);
t3=(C_truep(t2)?t2:C_i_string_equal_p(((C_word*)t0)[6],lf[54]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_838,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_845,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[55]))(2,*((C_word*)lf[55]+1),t5);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[6],lf[56]))){
t4=lf[1] /* main#*host-extensions* */ =C_SCHEME_FALSE;;
t5=C_i_cdr(((C_word*)t0)[5]);
/* loop277 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_730(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[6],lf[57]))){
t4=lf[2] /* main#*target-extensions* */ =C_SCHEME_FALSE;;
t5=C_i_cdr(((C_word*)t0)[5]);
/* loop277 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_730(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[6],lf[58]))){
t4=lf[11] /* main#*force* */ =C_SCHEME_TRUE;;
t5=C_i_cdr(((C_word*)t0)[5]);
/* loop277 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_730(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[6],lf[59]))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=C_i_cdr(((C_word*)t0)[5]);
/* loop277 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_730(t6,((C_word*)t0)[7],t5,((C_word*)t0)[3]);}
else{
t4=C_i_string_equal_p(((C_word*)t0)[6],lf[60]);
t5=(C_truep(t4)?t4:C_i_string_equal_p(((C_word*)t0)[6],lf[61]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t6,C_SCHEME_TRUE);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_926,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_positivep(t7))){
t8=C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t9=t6;
f_926(t9,C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_926(t8,C_SCHEME_FALSE);}}}}}}}}}

/* k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_935,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[68]+1)))(4,*((C_word*)lf[68]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1104,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t4,lf[51]);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* loop277 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_730(t4,((C_word*)t0)[4],t2,t3);}}

/* f1104 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(1));}

/* k973 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[67]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_935,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_941,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_967,tmp=(C_word)a,a+=2,tmp);
/* every */
((C_proc4)C_retrieve_symbol_proc(lf[66]))(4,*((C_word*)lf[66]+1),t2,t3,t1);}

/* a966 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_967,3,t0,t1,t2);}
t3=*((C_word*)lf[64]+1);
/* g337338 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[65]);}

/* k939 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_941,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_952,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_958,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1099,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t3,lf[51]);}}

/* f1099 in k939 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(1));}

/* a957 in k939 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_958(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_958,3,t0,t1,t2);}
t3=*((C_word*)lf[63]+1);
/* g356357 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k950 in k939 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[28]+1)))(4,*((C_word*)lf[28]+1),((C_word*)t0)[2],t1,t2);}

/* k946 in k939 in k933 in k924 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop277 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_730(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k911 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
/* loop277 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_730(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k843 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],t1);}

/* k836 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(0));}

/* f1094 in k821 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f1094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(0));}

/* f1089 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(1));}

/* k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_747,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_753,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_753(t11,t7,((C_word*)t0)[2]);}

/* loop285 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_753(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_753,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_780,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_801,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g301302 */
t6=t3;
f_780(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k799 in loop285 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_801,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop285298 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_753(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop285298 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_753(t6,((C_word*)t0)[3],t5);}}

/* g301 in loop285 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_780(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_780,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_791,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_795,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* regexp-escape */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t4,t2);}
else{
/* glob->regexp */
((C_proc3)C_retrieve_symbol_proc(lf[50]))(3,*((C_word*)lf[50]+1),t1,t2);}}

/* k793 in g301 in loop285 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[31]+1)))(5,*((C_word*)lf[31]+1),((C_word*)t0)[2],lf[47],t1,lf[48]);}

/* k789 in g301 in loop285 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* regexp */
((C_proc3)C_retrieve_symbol_proc(lf[46]))(3,*((C_word*)lf[46]+1),((C_word*)t0)[2],t1);}

/* k749 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[45]+1)))(3,*((C_word*)lf[45]+1),((C_word*)t0)[2],t1);}

/* k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_747,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_624,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_467,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_488,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_527,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_531,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* main#repo-path */
f_427(t11);}

/* k529 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1,lf[43],lf[44]);}

/* k525 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* glob */
((C_proc3)C_retrieve_symbol_proc(lf[42]))(3,*((C_word*)lf[42]+1),((C_word*)t0)[2],t1);}

/* k486 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_490(t5,((C_word*)t0)[2],t1);}

/* loop166 in k486 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_490(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_490,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[41]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_519,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g182183 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k517 in loop166 in k486 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_519,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop166179 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_490(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop166179 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_490(t6,((C_word*)t0)[3],t5);}}

/* k465 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_474,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_478,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_480,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a479 in k465 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_480,3,t0,t1,t2);}
t3=C_retrieve(lf[40]);
/* g204205 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k476 in k465 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t1);}

/* k472 in k465 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),((C_word*)t0)[2],t1,*((C_word*)lf[38]+1));}

/* k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_624,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14]);}
else{
t2=C_retrieve2(lf[11],"main#*force*");
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_639,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_639(2,t4,t2);}
else{
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_546,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_551,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t5,t6);}}}

/* a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_551,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_557,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_578,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,t3,t4);}

/* a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_584,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_608,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a607 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_608(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_608r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_608r(t0,t1,t2);}}

static void C_ccall f_608r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_614,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k209213 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a613 in a607 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_614,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a583 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_592,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_600,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_602,tmp=(C_word)a,a+=2,tmp);
/* map */
t6=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a601 in a583 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_602(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_602,3,t0,t1,t2);}
t3=*((C_word*)lf[31]+1);
/* g232233 */
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,lf[32],t2,lf[33]);}

/* k598 in a583 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[28]+1)))(5,*((C_word*)lf[28]+1),((C_word*)t0)[2],lf[29],t1,lf[30]);}

/* k594 in a583 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1);}

/* k590 in a583 in a577 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* yes-or-no? */
((C_proc7)C_retrieve_symbol_proc(lf[22]))(7,*((C_word*)lf[22]+1),((C_word*)t0)[2],t1,lf[23],lf[24],lf[25],C_retrieve(lf[26]));}

/* a556 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_557(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_557,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_563,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k209213 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a562 in a556 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[2],lf[18]);
if(C_truep(t2)){
t3=t1;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_537,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t4,lf[20]);}
else{
/* signal */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t1,((C_word*)t0)[2]);}}

/* k535 in a562 in a556 in a550 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[19]))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],C_fix(1));}

/* k544 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g211212 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_639,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_644,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_644(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_644(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_644,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_698,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_656,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),t5,lf[17],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[1],"main#*host-extensions*"))?C_retrieve2(lf[2],"main#*target-extensions*"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[15]))(3,*((C_word*)lf[15]+1),t3,((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* main#repo-path */
f_427(t3);}}

/* k693 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#remove-extension */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k663 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_665,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_670,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_675,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_685,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a684 in k663 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_685,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[1],"main#*host-extensions*"));
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a674 in k663 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_675,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_683,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* main#repo-path */
f_427(t2);}

/* k681 in a674 in k663 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#remove-extension */
((C_proc4)C_retrieve_symbol_proc(lf[15]))(4,*((C_word*)lf[15]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a669 in k663 in k654 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_670,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[1],"main#*host-extensions*"));
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k696 in loop245 in k637 in k622 in k745 in k738 in loop in k1033 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_644(t3,((C_word*)t0)[2],t2);}

/* k1023 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),t3);}

/* k1029 in k1023 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1026 in k1023 in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_fcall f_427(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_427,NULL,1,t1);}
t2=(C_truep(C_retrieve2(lf[0],"main#*cross-chicken*"))?C_i_not(C_retrieve2(lf[1],"main#*host-extensions*")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}
else{
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t1);}}

/* k439 in main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_445,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k443 in k439 in main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_448,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,lf[7],t1);}

/* k446 in k443 in k439 in main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,C_fix((C_word)C_BINARY_VERSION),((C_word*)t0)[2]);}

/* k449 in k446 in k443 in k439 in main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,((C_word*)t0)[2]);}

/* k452 in k449 in k446 in k443 in k439 in main#repo-path in k421 in k417 in k414 in k411 in k408 in k405 in k402 in k399 in k396 in k393 in k390 in k387 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[82] = {
{"toplevel:chicken_uninstall_scm",(void*)C_toplevel},
{"f_389:chicken_uninstall_scm",(void*)f_389},
{"f_392:chicken_uninstall_scm",(void*)f_392},
{"f_395:chicken_uninstall_scm",(void*)f_395},
{"f_398:chicken_uninstall_scm",(void*)f_398},
{"f_401:chicken_uninstall_scm",(void*)f_401},
{"f_404:chicken_uninstall_scm",(void*)f_404},
{"f_407:chicken_uninstall_scm",(void*)f_407},
{"f_410:chicken_uninstall_scm",(void*)f_410},
{"f_413:chicken_uninstall_scm",(void*)f_413},
{"f_416:chicken_uninstall_scm",(void*)f_416},
{"f_419:chicken_uninstall_scm",(void*)f_419},
{"f_423:chicken_uninstall_scm",(void*)f_423},
{"f_1035:chicken_uninstall_scm",(void*)f_1035},
{"f_730:chicken_uninstall_scm",(void*)f_730},
{"f_823:chicken_uninstall_scm",(void*)f_823},
{"f_926:chicken_uninstall_scm",(void*)f_926},
{"f1104:chicken_uninstall_scm",(void*)f1104},
{"f_975:chicken_uninstall_scm",(void*)f_975},
{"f_935:chicken_uninstall_scm",(void*)f_935},
{"f_967:chicken_uninstall_scm",(void*)f_967},
{"f_941:chicken_uninstall_scm",(void*)f_941},
{"f1099:chicken_uninstall_scm",(void*)f1099},
{"f_958:chicken_uninstall_scm",(void*)f_958},
{"f_952:chicken_uninstall_scm",(void*)f_952},
{"f_948:chicken_uninstall_scm",(void*)f_948},
{"f_913:chicken_uninstall_scm",(void*)f_913},
{"f_845:chicken_uninstall_scm",(void*)f_845},
{"f_838:chicken_uninstall_scm",(void*)f_838},
{"f1094:chicken_uninstall_scm",(void*)f1094},
{"f1089:chicken_uninstall_scm",(void*)f1089},
{"f_740:chicken_uninstall_scm",(void*)f_740},
{"f_753:chicken_uninstall_scm",(void*)f_753},
{"f_801:chicken_uninstall_scm",(void*)f_801},
{"f_780:chicken_uninstall_scm",(void*)f_780},
{"f_795:chicken_uninstall_scm",(void*)f_795},
{"f_791:chicken_uninstall_scm",(void*)f_791},
{"f_751:chicken_uninstall_scm",(void*)f_751},
{"f_747:chicken_uninstall_scm",(void*)f_747},
{"f_531:chicken_uninstall_scm",(void*)f_531},
{"f_527:chicken_uninstall_scm",(void*)f_527},
{"f_488:chicken_uninstall_scm",(void*)f_488},
{"f_490:chicken_uninstall_scm",(void*)f_490},
{"f_519:chicken_uninstall_scm",(void*)f_519},
{"f_467:chicken_uninstall_scm",(void*)f_467},
{"f_480:chicken_uninstall_scm",(void*)f_480},
{"f_478:chicken_uninstall_scm",(void*)f_478},
{"f_474:chicken_uninstall_scm",(void*)f_474},
{"f_624:chicken_uninstall_scm",(void*)f_624},
{"f_551:chicken_uninstall_scm",(void*)f_551},
{"f_578:chicken_uninstall_scm",(void*)f_578},
{"f_608:chicken_uninstall_scm",(void*)f_608},
{"f_614:chicken_uninstall_scm",(void*)f_614},
{"f_584:chicken_uninstall_scm",(void*)f_584},
{"f_602:chicken_uninstall_scm",(void*)f_602},
{"f_600:chicken_uninstall_scm",(void*)f_600},
{"f_596:chicken_uninstall_scm",(void*)f_596},
{"f_592:chicken_uninstall_scm",(void*)f_592},
{"f_557:chicken_uninstall_scm",(void*)f_557},
{"f_563:chicken_uninstall_scm",(void*)f_563},
{"f_537:chicken_uninstall_scm",(void*)f_537},
{"f_546:chicken_uninstall_scm",(void*)f_546},
{"f_639:chicken_uninstall_scm",(void*)f_639},
{"f_644:chicken_uninstall_scm",(void*)f_644},
{"f_656:chicken_uninstall_scm",(void*)f_656},
{"f_695:chicken_uninstall_scm",(void*)f_695},
{"f_665:chicken_uninstall_scm",(void*)f_665},
{"f_685:chicken_uninstall_scm",(void*)f_685},
{"f_675:chicken_uninstall_scm",(void*)f_675},
{"f_683:chicken_uninstall_scm",(void*)f_683},
{"f_670:chicken_uninstall_scm",(void*)f_670},
{"f_698:chicken_uninstall_scm",(void*)f_698},
{"f_1025:chicken_uninstall_scm",(void*)f_1025},
{"f_1031:chicken_uninstall_scm",(void*)f_1031},
{"f_1028:chicken_uninstall_scm",(void*)f_1028},
{"f_427:chicken_uninstall_scm",(void*)f_427},
{"f_441:chicken_uninstall_scm",(void*)f_441},
{"f_445:chicken_uninstall_scm",(void*)f_445},
{"f_448:chicken_uninstall_scm",(void*)f_448},
{"f_451:chicken_uninstall_scm",(void*)f_451},
{"f_454:chicken_uninstall_scm",(void*)f_454},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
