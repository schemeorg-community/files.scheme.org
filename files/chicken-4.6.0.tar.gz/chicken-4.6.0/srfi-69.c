/* Generated from srfi-69.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: srfi-69.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file srfi-69.c -extend ./private-namespace.scm
   unit: srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[120];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,30),40,35,35,115,121,115,35,110,117,109,98,101,114,45,104,97,115,104,45,104,111,111,107,32,111,98,106,57,52,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,32),40,110,117,109,98,101,114,45,104,97,115,104,32,111,98,106,49,48,49,32,46,32,116,109,112,49,48,48,49,48,50,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,36),40,111,98,106,101,99,116,45,117,105,100,45,104,97,115,104,32,111,98,106,49,55,53,32,46,32,116,109,112,49,55,52,49,55,54,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,32),40,115,121,109,98,111,108,45,104,97,115,104,32,111,98,106,49,57,56,32,46,32,116,109,112,49,57,55,49,57,57,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,107,101,121,119,111,114,100,32,120,50,49,57,32,46,32,121,50,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,33),40,107,101,121,119,111,114,100,45,104,97,115,104,32,111,98,106,50,50,56,32,46,32,116,109,112,50,50,55,50,50,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,29),40,101,113,63,45,104,97,115,104,32,111,98,106,50,55,49,32,46,32,116,109,112,50,55,48,50,55,50,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,101,113,118,63,45,104,97,115,104,32,111,98,106,51,53,51,32,46,32,116,109,112,51,53,50,51,53,52,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,104,115,104,51,55,55,32,105,51,55,56,32,108,101,110,51,55,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,46),40,118,101,99,116,111,114,45,104,97,115,104,32,111,98,106,51,55,49,32,115,101,101,100,51,55,50,32,100,101,112,116,104,51,55,51,32,115,116,97,114,116,51,55,52,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,39),40,114,101,99,117,114,115,105,118,101,45,97,116,111,109,105,99,45,104,97,115,104,32,111,98,106,51,56,49,32,100,101,112,116,104,51,56,50,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,13),40,103,52,55,48,32,111,98,106,52,55,50,41,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,103,52,55,51,32,111,98,106,52,55,53,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,13),40,103,52,56,53,32,111,98,106,52,56,55,41,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,13),40,103,52,56,56,32,111,98,106,52,57,48,41,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,32),40,114,101,99,117,114,115,105,118,101,45,104,97,115,104,32,111,98,106,52,48,52,32,100,101,112,116,104,52,48,53,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,21),40,42,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,51,54,55,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,32),40,101,113,117,97,108,63,45,104,97,115,104,32,111,98,106,53,48,48,32,46,32,116,109,112,52,57,57,53,48,49,41};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,51,51,32,115,116,97,114,116,53,52,49,32,101,110,100,53,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,53,51,54,32,37,115,116,97,114,116,53,51,49,53,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,53,51,53,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,32),40,115,116,114,105,110,103,45,104,97,115,104,32,115,116,114,53,50,48,32,46,32,116,109,112,53,49,57,53,50,49,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,56,52,32,115,116,97,114,116,53,57,50,32,101,110,100,53,57,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,110,100,53,56,55,32,37,115,116,97,114,116,53,56,50,53,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,115,116,97,114,116,53,56,54,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,35),40,115,116,114,105,110,103,45,99,105,45,104,97,115,104,32,115,116,114,53,55,49,32,46,32,116,109,112,53,55,48,53,55,50,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,43),40,104,97,115,104,45,116,97,98,108,101,45,99,97,110,111,110,105,99,97,108,45,108,101,110,103,116,104,32,116,97,98,54,50,57,32,114,101,113,54,51,48,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,86),40,42,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,116,101,115,116,54,52,54,32,104,97,115,104,54,52,55,32,108,101,110,54,52,56,32,109,105,110,45,108,111,97,100,54,52,57,32,109,97,120,45,108,111,97,100,54,53,48,32,105,110,105,116,105,97,108,54,53,51,32,116,109,112,54,52,53,54,53,52,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,19),40,105,110,118,97,114,103,45,101,114,114,32,109,115,103,55,49,48,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,8),40,102,95,51,50,52,56,41};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,97,114,103,115,55,48,55,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,104,97,115,104,45,116,97,98,108,101,32,46,32,97,114,103,117,109,101,110,116,115,48,54,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,104,97,115,104,45,116,97,98,108,101,63,32,111,98,106,55,52,49,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,115,105,122,101,32,104,116,55,52,50,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,39),40,104,97,115,104,45,116,97,98,108,101,45,101,113,117,105,118,97,108,101,110,99,101,45,102,117,110,99,116,105,111,110,32,104,116,55,52,52,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,104,45,102,117,110,99,116,105,111,110,32,104,116,55,52,54,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,105,110,45,108,111,97,100,32,104,116,55,52,56,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,27),40,104,97,115,104,45,116,97,98,108,101,45,109,97,120,45,108,111,97,100,32,104,116,55,53,48,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,107,101,121,115,32,104,116,55,53,50,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,30),40,104,97,115,104,45,116,97,98,108,101,45,119,101,97,107,45,118,97,108,117,101,115,32,104,116,55,53,52,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,31),40,104,97,115,104,45,116,97,98,108,101,45,104,97,115,45,105,110,105,116,105,97,108,63,32,104,116,55,53,54,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,105,110,105,116,105,97,108,32,104,116,55,53,57,41,0,0,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,55,55,49,41};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,54,55,32,105,55,54,57,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,40),40,104,97,115,104,45,116,97,98,108,101,45,114,101,115,105,122,101,33,32,104,116,55,55,57,32,118,101,99,55,56,48,32,108,101,110,55,56,49,41};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,21),40,99,111,112,121,45,108,111,111,112,32,98,117,99,107,101,116,55,57,53,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,55,57,49,32,105,55,57,51,41};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,24),40,42,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,55,56,55,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,23),40,104,97,115,104,45,116,97,98,108,101,45,99,111,112,121,32,104,116,56,48,48,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,53,48,41};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,56,53,57,41};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,56,49,52,32,102,117,110,99,56,50,50,32,116,104,117,110,107,56,50,51,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,8),40,102,95,51,57,56,56,41};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,116,104,117,110,107,56,49,55,32,37,102,117,110,99,56,49,50,56,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,97,51,57,57,56,32,120,56,55,56,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,102,117,110,99,56,49,54,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,45),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,32,104,116,56,48,57,32,107,101,121,56,49,48,32,46,32,116,109,112,56,48,56,56,49,49,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,49,52,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,50,51,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,57),40,42,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,56,56,52,32,107,101,121,56,56,53,32,102,117,110,99,56,56,54,32,100,101,102,56,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,56),40,104,97,115,104,45,116,97,98,108,101,45,117,112,100,97,116,101,33,47,100,101,102,97,117,108,116,32,104,116,57,51,50,32,107,101,121,57,51,51,32,102,117,110,99,57,51,52,32,100,101,102,57,51,53,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,54,56,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,55,51,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,115,101,116,33,32,104,116,57,51,57,32,107,101,121,57,52,48,32,118,97,108,57,52,49,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,47),40,104,97,115,104,45,116,97,98,108,101,45,114,101,102,47,100,101,102,97,117,108,116,32,104,116,49,48,48,56,32,107,101,121,49,48,48,57,32,100,101,102,49,48,49,48,41,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,52,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,101,120,105,115,116,115,63,32,104,116,49,48,50,53,32,107,101,121,49,48,50,54,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,48,54,56,32,98,117,99,107,101,116,49,48,54,57,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,100,101,108,101,116,101,33,32,104,116,49,48,52,57,32,107,101,121,49,48,53,48,41,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,32,112,114,101,118,49,48,56,54,32,98,117,99,107,101,116,49,48,56,55,41,0,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,56,50,32,105,49,48,56,52,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,36),40,104,97,115,104,45,116,97,98,108,101,45,114,101,109,111,118,101,33,32,104,116,49,48,55,55,32,102,117,110,99,49,48,55,56,41,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,99,108,101,97,114,33,32,104,116,49,48,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,13),40,97,53,48,49,57,32,120,49,49,49,50,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,20),40,100,111,108,111,111,112,49,49,48,56,32,108,115,116,49,49,49,48,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,48,53,32,105,49,49,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,36),40,42,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,49,48,49,32,104,116,50,49,49,48,50,41,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,35),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,33,32,104,116,49,49,49,49,55,32,104,116,50,49,49,49,56,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,34),40,104,97,115,104,45,116,97,98,108,101,45,109,101,114,103,101,32,104,116,49,49,49,50,49,32,104,116,50,49,49,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,51,50,32,108,115,116,49,49,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,50,57,32,108,115,116,49,49,51,48,41,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,62,97,108,105,115,116,32,104,116,49,49,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,13),40,97,53,49,54,48,32,120,49,49,53,51,41,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,13),40,103,49,49,53,48,32,120,49,49,53,50,41,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,52,51,32,103,49,49,52,55,49,49,52,57,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,40),40,97,108,105,115,116,45,62,104,97,115,104,45,116,97,98,108,101,32,97,108,105,115,116,49,49,51,56,32,46,32,114,101,115,116,49,49,51,57,41};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,54,54,32,108,115,116,49,49,54,55,41,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,54,51,32,108,115,116,49,49,54,52,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,24),40,104,97,115,104,45,116,97,98,108,101,45,107,101,121,115,32,104,116,49,49,53,57,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,26),40,108,111,111,112,50,32,98,117,99,107,101,116,49,49,55,57,32,108,115,116,49,49,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,49,55,54,32,108,115,116,49,49,55,55,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,26),40,104,97,115,104,45,116,97,98,108,101,45,118,97,108,117,101,115,32,104,116,49,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,18),40,103,49,50,48,49,32,98,117,99,107,101,116,49,50,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,57,52,32,103,49,49,57,56,49,50,48,48,41,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,49,56,57,32,105,49,49,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,38),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,49,56,53,32,112,114,111,99,49,49,56,54,41,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,26),40,102,111,108,100,50,32,98,117,99,107,101,116,49,50,49,55,32,97,99,99,49,50,49,56,41,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,105,49,50,49,52,32,97,99,99,49,50,49,53,41,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,43),40,42,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,50,48,56,32,102,117,110,99,49,50,48,57,32,105,110,105,116,49,50,49,48,41,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,42),40,104,97,115,104,45,116,97,98,108,101,45,102,111,108,100,32,104,116,49,50,50,50,32,102,117,110,99,49,50,50,51,32,105,110,105,116,49,50,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,37),40,104,97,115,104,45,116,97,98,108,101,45,102,111,114,45,101,97,99,104,32,104,116,49,50,50,55,32,112,114,111,99,49,50,50,56,41,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,33),40,104,97,115,104,45,116,97,98,108,101,45,119,97,108,107,32,104,116,49,50,51,49,32,112,114,111,99,49,50,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,97,53,52,57,54,32,107,49,50,51,55,32,118,49,50,51,56,32,97,49,50,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,32),40,104,97,115,104,45,116,97,98,108,101,45,109,97,112,32,104,116,49,50,51,53,32,102,117,110,99,49,50,51,54,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,23),40,97,53,53,48,57,32,104,116,49,50,52,50,32,112,111,114,116,49,50,52,51,41,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,98,117,99,107,101,116,57,57,56,41};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,32,98,117,99,107,101,116,49,48,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,8),40,102,95,53,54,52,54,41};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,32),40,97,53,53,50,53,32,104,116,57,56,55,32,107,101,121,57,56,56,32,46,32,116,109,112,57,56,54,57,56,57,41};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_69_toplevel)
C_externexport void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_5526)
static void C_ccall f_5526r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5624)
static void C_ccall f_5624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4500)
static void C_ccall f_4500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5514)
static void C_ccall f_5514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5517)
static void C_ccall f_5517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5508)
static void C_ccall f_5508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5485)
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5505)
static void C_ccall f_5505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5480)
static void C_ccall f_5480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5449)
static void C_ccall f_5449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5456)
static void C_ccall f_5456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5383)
static void C_fcall f_5383(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5395)
static void C_fcall f_5395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5411)
static void C_fcall f_5411(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5439)
static void C_ccall f_5439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5312)
static void C_fcall f_5312(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5324)
static void C_fcall f_5324(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5347)
static void C_fcall f_5347(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5370)
static void C_ccall f_5370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_fcall f_5355(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5334)
static void C_ccall f_5334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5262)
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5278)
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5182)
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5197)
static void C_fcall f_5197(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5135)
static void C_ccall f_5135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5140)
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_fcall f_5148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5138)
static void C_ccall f_5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5086)
static void C_fcall f_5086(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5039)
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5053)
static void C_ccall f_5053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4959)
static void C_fcall f_4959(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4971)
static void C_fcall f_4971(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4994)
static void C_fcall f_4994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4943)
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4894)
static void C_fcall f_4894(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4913)
static void C_ccall f_4913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4881)
static void C_ccall f_4881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4732)
static void C_ccall f_4732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_fcall f_4799(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static C_word C_fcall f_4752(C_word t0,C_word t1,C_word t2);
C_noret_decl(f_4608)
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4679)
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static C_word C_fcall f_4639(C_word t0,C_word t1);
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4518)
static void C_ccall f_4518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4572)
static void C_fcall f_4572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static C_word C_fcall f_4533(C_word t0,C_word t1);
C_noret_decl(f_4284)
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4360)
static void C_ccall f_4360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_fcall f_4316(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_ccall f_4352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4327)
static void C_fcall f_4327(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4333)
static void C_fcall f_4333(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4382)
static void C_ccall f_4382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_fcall f_4448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4478)
static void C_ccall f_4478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4399)
static void C_fcall f_4399(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4279)
static void C_ccall f_4279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4073)
static void C_fcall f_4073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4109)
static void C_ccall f_4109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_fcall f_4084(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_fcall f_4090(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_fcall f_4212(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_ccall f_4222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3730)
static void C_ccall f_3730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3993)
static void C_fcall f_3993(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3976)
static void C_fcall f_3976(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3988)
static void C_ccall f_3988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_fcall f_3732(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3739)
static void C_ccall f_3739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3742)
static void C_ccall f_3742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3814)
static void C_ccall f_3814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3770)
static void C_fcall f_3770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3806)
static void C_ccall f_3806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_fcall f_3781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_fcall f_3787(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3821)
static void C_ccall f_3821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_fcall f_3913(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3950)
static void C_ccall f_3950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3923)
static void C_ccall f_3923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3878)
static void C_ccall f_3878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3624)
static void C_fcall f_3624(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3686)
static void C_fcall f_3686(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3707)
static void C_ccall f_3707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3587)
static void C_ccall f_3587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3593)
static void C_ccall f_3593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3539)
static void C_fcall f_3539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3555)
static void C_ccall f_3555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3526)
static void C_ccall f_3526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3596)
static void C_ccall f_3596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3441)
static void C_ccall f_3441(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3045)
static void C_ccall f_3045r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3398)
static void C_ccall f_3398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3401)
static void C_ccall f_3401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_fcall f_3123(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3378)
static void C_ccall f_3378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_fcall f_3126(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3346)
static void C_ccall f_3346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3352)
static void C_ccall f_3352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_fcall f_3129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3164)
static void C_fcall f_3164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3283)
static void C_ccall f_3283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3296)
static void C_ccall f_3296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3286)
static void C_ccall f_3286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_ccall f_3261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static void C_ccall f_3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_ccall f_3194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3175)
static void C_fcall f_3175(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3155)
static void C_ccall f_3155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3047)
static C_word C_fcall f_3047(C_word t0);
C_noret_decl(f_3014)
static void C_fcall f_3014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_3018)
static void C_ccall f_3018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2984)
static void C_fcall f_2984(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2990)
static C_word C_fcall f_2990(C_word t0,C_word t1);
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2922)
static void C_fcall f_2922(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2894)
static void C_fcall f_2894(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2898)
static void C_ccall f_2898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2901)
static void C_ccall f_2901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2857)
static void C_ccall f_2857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2781)
static void C_fcall f_2781(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2772)
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2753)
static void C_fcall f_2753(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_fcall f_2174(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2628)
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2616)
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2600)
static void C_ccall f_2600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2549)
static void C_fcall f_2549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2569)
static void C_ccall f_2569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2561)
static void C_ccall f_2561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_fcall f_2523(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_fcall f_2242(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2276)
static void C_fcall f_2276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2279)
static void C_fcall f_2279(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2177)
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2194)
static void C_fcall f_2194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2115)
static void C_ccall f_2115r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2153)
static void C_ccall f_2153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1845)
static void C_ccall f_1845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1879)
static void C_ccall f_1879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1691)
static void C_ccall f_1691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1694)
static void C_ccall f_1694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1497)
static void C_fcall f_1497(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_5605)
static void C_fcall trf_5605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5605(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5605(t0,t1,t2);}

C_noret_decl(trf_5563)
static void C_fcall trf_5563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5563(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5563(t0,t1,t2);}

C_noret_decl(trf_5383)
static void C_fcall trf_5383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5383(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5383(t0,t1,t2,t3);}

C_noret_decl(trf_5395)
static void C_fcall trf_5395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5395(t0,t1,t2,t3);}

C_noret_decl(trf_5411)
static void C_fcall trf_5411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5411(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5411(t0,t1,t2,t3);}

C_noret_decl(trf_5312)
static void C_fcall trf_5312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5312(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5312(t0,t1,t2);}

C_noret_decl(trf_5324)
static void C_fcall trf_5324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5324(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5324(t0,t1,t2);}

C_noret_decl(trf_5347)
static void C_fcall trf_5347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5347(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5347(t0,t1,t2);}

C_noret_decl(trf_5355)
static void C_fcall trf_5355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5355(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5355(t0,t1,t2);}

C_noret_decl(trf_5262)
static void C_fcall trf_5262(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5262(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5262(t0,t1,t2,t3);}

C_noret_decl(trf_5278)
static void C_fcall trf_5278(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5278(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5278(t0,t1,t2,t3);}

C_noret_decl(trf_5197)
static void C_fcall trf_5197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5197(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5197(t0,t1,t2,t3);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5213(t0,t1,t2,t3);}

C_noret_decl(trf_5140)
static void C_fcall trf_5140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5140(t0,t1,t2);}

C_noret_decl(trf_5148)
static void C_fcall trf_5148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5148(t0,t1,t2);}

C_noret_decl(trf_5070)
static void C_fcall trf_5070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5070(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5070(t0,t1,t2,t3);}

C_noret_decl(trf_5086)
static void C_fcall trf_5086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5086(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5086(t0,t1,t2,t3);}

C_noret_decl(trf_4959)
static void C_fcall trf_4959(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4959(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4959(t0,t1,t2);}

C_noret_decl(trf_4971)
static void C_fcall trf_4971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4971(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4971(t0,t1,t2);}

C_noret_decl(trf_4994)
static void C_fcall trf_4994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4994(t0,t1,t2);}

C_noret_decl(trf_4868)
static void C_fcall trf_4868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4868(t0,t1,t2);}

C_noret_decl(trf_4894)
static void C_fcall trf_4894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4894(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4894(t0,t1,t2,t3);}

C_noret_decl(trf_4799)
static void C_fcall trf_4799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4799(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4799(t0,t1,t2,t3);}

C_noret_decl(trf_4679)
static void C_fcall trf_4679(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4679(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4679(t0,t1,t2);}

C_noret_decl(trf_4572)
static void C_fcall trf_4572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4572(t0,t1,t2);}

C_noret_decl(trf_4316)
static void C_fcall trf_4316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4316(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4316(t0,t1);}

C_noret_decl(trf_4327)
static void C_fcall trf_4327(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4327(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4327(t0,t1);}

C_noret_decl(trf_4333)
static void C_fcall trf_4333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4333(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4333(t0,t1);}

C_noret_decl(trf_4448)
static void C_fcall trf_4448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4448(t0,t1,t2);}

C_noret_decl(trf_4399)
static void C_fcall trf_4399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4399(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4399(t0,t1,t2);}

C_noret_decl(trf_4044)
static void C_fcall trf_4044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4044(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4044(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4073)
static void C_fcall trf_4073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4073(t0,t1);}

C_noret_decl(trf_4084)
static void C_fcall trf_4084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4084(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4084(t0,t1);}

C_noret_decl(trf_4090)
static void C_fcall trf_4090(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4090(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4090(t0,t1);}

C_noret_decl(trf_4212)
static void C_fcall trf_4212(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4212(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4212(t0,t1,t2);}

C_noret_decl(trf_4153)
static void C_fcall trf_4153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4153(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4153(t0,t1,t2);}

C_noret_decl(trf_3993)
static void C_fcall trf_3993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3993(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3993(t0,t1);}

C_noret_decl(trf_3976)
static void C_fcall trf_3976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3976(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3976(t0,t1,t2);}

C_noret_decl(trf_3732)
static void C_fcall trf_3732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3732(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3732(t0,t1,t2,t3);}

C_noret_decl(trf_3770)
static void C_fcall trf_3770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3770(t0,t1);}

C_noret_decl(trf_3781)
static void C_fcall trf_3781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3781(t0,t1);}

C_noret_decl(trf_3787)
static void C_fcall trf_3787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3787(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3787(t0,t1);}

C_noret_decl(trf_3913)
static void C_fcall trf_3913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3913(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3913(t0,t1,t2);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3850(t0,t1,t2);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3609(t0,t1,t2);}

C_noret_decl(trf_3624)
static void C_fcall trf_3624(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3624(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3624(t0,t1,t2);}

C_noret_decl(trf_3686)
static void C_fcall trf_3686(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3686(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3686(t0,t1,t2);}

C_noret_decl(trf_3516)
static void C_fcall trf_3516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3516(t0,t1,t2);}

C_noret_decl(trf_3539)
static void C_fcall trf_3539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3539(t0,t1,t2);}

C_noret_decl(trf_3123)
static void C_fcall trf_3123(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3123(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3123(t0,t1);}

C_noret_decl(trf_3126)
static void C_fcall trf_3126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3126(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3126(t0,t1);}

C_noret_decl(trf_3129)
static void C_fcall trf_3129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3129(t0,t1);}

C_noret_decl(trf_3164)
static void C_fcall trf_3164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3164(t0,t1,t2);}

C_noret_decl(trf_3175)
static void C_fcall trf_3175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3175(t0,t1,t2);}

C_noret_decl(trf_3014)
static void C_fcall trf_3014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3014(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_3014(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2984)
static void C_fcall trf_2984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2984(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2984(t0,t1,t2);}

C_noret_decl(trf_2922)
static void C_fcall trf_2922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2922(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2922(t0,t1);}

C_noret_decl(trf_2913)
static void C_fcall trf_2913(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2913(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2913(t0,t1,t2);}

C_noret_decl(trf_2894)
static void C_fcall trf_2894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2894(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2894(t0,t1,t2,t3);}

C_noret_decl(trf_2781)
static void C_fcall trf_2781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2781(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2781(t0,t1);}

C_noret_decl(trf_2772)
static void C_fcall trf_2772(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2772(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2772(t0,t1,t2);}

C_noret_decl(trf_2753)
static void C_fcall trf_2753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2753(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2753(t0,t1,t2,t3);}

C_noret_decl(trf_2174)
static void C_fcall trf_2174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2174(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2174(t0,t1);}

C_noret_decl(trf_2293)
static void C_fcall trf_2293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2293(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2293(t0,t1,t2,t3);}

C_noret_decl(trf_2628)
static void C_fcall trf_2628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2628(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2628(t0,t1,t2);}

C_noret_decl(trf_2616)
static void C_fcall trf_2616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2616(t0,t1,t2);}

C_noret_decl(trf_2549)
static void C_fcall trf_2549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2549(t0,t1,t2);}

C_noret_decl(trf_2523)
static void C_fcall trf_2523(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2523(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2523(t0,t1,t2);}

C_noret_decl(trf_2242)
static void C_fcall trf_2242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2242(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2242(t0,t1,t2,t3);}

C_noret_decl(trf_2276)
static void C_fcall trf_2276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2276(t0,t1);}

C_noret_decl(trf_2279)
static void C_fcall trf_2279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2279(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2279(t0,t1);}

C_noret_decl(trf_2177)
static void C_fcall trf_2177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2177(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2177(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2194)
static void C_fcall trf_2194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2194(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2194(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1497)
static void C_fcall trf_1497(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1497(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1497(t0,t1);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_69_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_69_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(953)){
C_save(t1);
C_rereclaim2(953*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,120);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],20,"\003sysnumber-hash-hook");
lf[4]=C_h_intern(&lf[4],11,"number-hash");
lf[5]=C_h_intern(&lf[5],5,"fxmod");
lf[6]=C_h_intern(&lf[6],15,"\003syssignal-hook");
lf[7]=C_h_intern(&lf[7],5,"\000type");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid number");
lf[9]=C_h_intern(&lf[9],9,"\003syserror");
lf[10]=C_h_intern(&lf[10],15,"object-uid-hash");
lf[11]=C_h_intern(&lf[11],11,"symbol-hash");
lf[12]=C_h_intern(&lf[12],17,"\003syscheck-keyword");
lf[13]=C_h_intern(&lf[13],11,"\000type-error");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a keyword");
lf[15]=C_h_intern(&lf[15],8,"keyword\077");
lf[16]=C_h_intern(&lf[16],12,"keyword-hash");
lf[17]=C_h_intern(&lf[17],8,"eq\077-hash");
lf[18]=C_h_intern(&lf[18],16,"hash-by-identity");
lf[19]=C_h_intern(&lf[19],9,"eqv\077-hash");
lf[20]=C_h_intern(&lf[20],5,"fxmin");
lf[21]=C_h_intern(&lf[21],11,"input-port\077");
lf[22]=C_h_intern(&lf[22],11,"equal\077-hash");
lf[23]=C_h_intern(&lf[23],4,"hash");
lf[24]=C_h_intern(&lf[24],11,"string-hash");
lf[25]=C_h_intern(&lf[25],13,"\003syssubstring");
lf[26]=C_h_intern(&lf[26],15,"\003syscheck-range");
lf[27]=C_h_intern(&lf[27],14,"string-ci-hash");
lf[28]=C_h_intern(&lf[28],14,"string-hash-ci");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\0013\376\003\000\000\002\376\377\001\000\000\002i\376\003\000\000\002\376\377\001\000\000\004\325\376\003\000\000\002\376\377\001\000\000\011\255\376\003\000\000\002\376\377\001\000\000\023]\376\003\000\000\002\376\377\001\000\000&\303\376\003\000\000\002\376\377\001"
"\000\000M\215\376\003\000\000\002\376\377\001\000\000\233\035\376\003\000\000\002\376\377\001\000\0016\077\376\003\000\000\002\376\377\001\000\002l\201\376\003\000\000\002\376\377\001\000\004\331\005\376\003\000\000\002\376\377\001\000\011\262\025\376\003\000\000\002\376\377\001\000\023dA\376\003\000\000"
"\002\376\377\001\000&\310\205\376\003\000\000\002\376\377\001\000M\221\037\376\003\000\000\002\376\377\001\000\233\042I\376\003\000\000\002\376\377\001\0016D\277\376\003\000\000\002\376\377\001\002l\211\207\376\003\000\000\002\376\377\001\004\331\023\027\376\003\000\000\002\376\377\001\011\262&1"
"\376\003\000\000\002\376\377\001\023dLq\376\003\000\000\002\376\377\001&\310\230\373\376\003\000\000\002\376\377\001\077\377\377\377\376\377\016");
lf[32]=C_h_intern(&lf[32],11,"make-vector");
lf[34]=C_h_intern(&lf[34],10,"hash-table");
lf[35]=C_h_intern(&lf[35],3,"eq\077");
lf[36]=C_h_intern(&lf[36],4,"eqv\077");
lf[37]=C_h_intern(&lf[37],6,"equal\077");
lf[38]=C_h_intern(&lf[38],8,"string=\077");
lf[39]=C_h_intern(&lf[39],11,"string-ci=\077");
lf[40]=C_h_intern(&lf[40],1,"=");
lf[41]=C_h_intern(&lf[41],15,"make-hash-table");
lf[42]=C_decode_literal(C_heaptop,"\376U0.5\000");
lf[43]=C_decode_literal(C_heaptop,"\376U0.8\000");
lf[44]=C_h_intern(&lf[44],7,"warning");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\033user test without user hash");
lf[46]=C_h_intern(&lf[46],5,"error");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\036min-load greater than max-load");
lf[48]=C_h_intern(&lf[48],3,"fp<");
lf[49]=C_h_intern(&lf[49],5,"\000test");
lf[50]=C_h_intern(&lf[50],17,"\003syscheck-closure");
lf[51]=C_h_intern(&lf[51],5,"\000hash");
lf[52]=C_h_intern(&lf[52],5,"\000size");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[54]=C_h_intern(&lf[54],8,"\000initial");
lf[55]=C_h_intern(&lf[55],9,"\000min-load");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid min-load");
lf[57]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[58]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[59]=C_h_intern(&lf[59],17,"\003syscheck-inexact");
lf[60]=C_h_intern(&lf[60],9,"\000max-load");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid max-load");
lf[62]=C_decode_literal(C_heaptop,"\376U1.0\000");
lf[63]=C_decode_literal(C_heaptop,"\376U0.0\000");
lf[64]=C_h_intern(&lf[64],10,"\000weak-keys");
lf[65]=C_h_intern(&lf[65],12,"\000weak-values");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\017unknown keyword");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\025missing keyword value");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\017missing keyword");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\014invalid size");
lf[70]=C_h_intern(&lf[70],11,"hash-table\077");
lf[71]=C_h_intern(&lf[71],15,"hash-table-size");
lf[72]=C_h_intern(&lf[72],31,"hash-table-equivalence-function");
lf[73]=C_h_intern(&lf[73],24,"hash-table-hash-function");
lf[74]=C_h_intern(&lf[74],19,"hash-table-min-load");
lf[75]=C_h_intern(&lf[75],19,"hash-table-max-load");
lf[76]=C_h_intern(&lf[76],20,"hash-table-weak-keys");
lf[77]=C_h_intern(&lf[77],22,"hash-table-weak-values");
lf[78]=C_h_intern(&lf[78],23,"hash-table-has-initial\077");
lf[79]=C_h_intern(&lf[79],18,"hash-table-initial");
lf[80]=C_h_intern(&lf[80],18,"hash-table-resize!");
lf[82]=C_h_intern(&lf[82],15,"hash-table-copy");
lf[83]=C_h_intern(&lf[83],18,"hash-table-update!");
lf[84]=C_h_intern(&lf[84],5,"floor");
lf[85]=C_h_intern(&lf[85],13,"\000access-error");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[88]=C_h_intern(&lf[88],26,"hash-table-update!/default");
lf[89]=C_h_intern(&lf[89],15,"hash-table-set!");
lf[90]=C_h_intern(&lf[90],19,"\003sysundefined-value");
lf[91]=C_h_intern(&lf[91],14,"hash-table-ref");
lf[92]=C_h_intern(&lf[92],22,"hash-table-ref/default");
lf[93]=C_h_intern(&lf[93],18,"hash-table-exists\077");
lf[94]=C_h_intern(&lf[94],18,"hash-table-delete!");
lf[95]=C_h_intern(&lf[95],18,"hash-table-remove!");
lf[96]=C_h_intern(&lf[96],17,"hash-table-clear!");
lf[97]=C_h_intern(&lf[97],12,"vector-fill!");
lf[99]=C_h_intern(&lf[99],17,"hash-table-merge!");
lf[100]=C_h_intern(&lf[100],16,"hash-table-merge");
lf[101]=C_h_intern(&lf[101],17,"hash-table->alist");
lf[102]=C_h_intern(&lf[102],17,"alist->hash-table");
lf[103]=C_h_intern(&lf[103],15,"hash-table-keys");
lf[104]=C_h_intern(&lf[104],17,"hash-table-values");
lf[107]=C_h_intern(&lf[107],15,"hash-table-fold");
lf[108]=C_h_intern(&lf[108],19,"hash-table-for-each");
lf[109]=C_h_intern(&lf[109],15,"hash-table-walk");
lf[110]=C_h_intern(&lf[110],14,"hash-table-map");
lf[111]=C_h_intern(&lf[111],9,"\003sysprint");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\002)>");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\016#<hash-table (");
lf[114]=C_h_intern(&lf[114],27,"\003sysregister-record-printer");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\037hash-table does not contain key");
lf[116]=C_h_intern(&lf[116],18,"getter-with-setter");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\035(hash-table-ref ht key . def)");
lf[118]=C_h_intern(&lf[118],17,"register-feature!");
lf[119]=C_h_intern(&lf[119],7,"srfi-69");
C_register_lf2(lf,120,create_ptable());
t2=C_mutate(&lf[0] /* (set! c106 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:38: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[118]+1)))(3,*((C_word*)lf[118]+1),t3,lf[119]);}

/* k1311 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word ab[114],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1313,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! ##sys#number-hash-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[4]+1 /* (set! number-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[10]+1 /* (set! object-uid-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[11]+1 /* (set! symbol-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[12]+1 /* (set! ##sys#check-keyword ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1661,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[16]+1 /* (set! keyword-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[17]+1 /* (set! eq?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1841,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[18]+1 /* (set! hash-by-identity ...) */,*((C_word*)lf[17]+1));
t10=C_mutate((C_word*)lf[19]+1 /* (set! eqv?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2115,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[3] /* (set! *equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[22]+1 /* (set! equal?-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[23]+1 /* (set! hash ...) */,*((C_word*)lf[22]+1));
t14=C_mutate((C_word*)lf[24]+1 /* (set! string-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2700,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[27]+1 /* (set! string-ci-hash ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2841,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[28]+1 /* (set! string-hash-ci ...) */,*((C_word*)lf[27]+1));
t17=C_mutate(&lf[29] /* (set! constant628 ...) */,lf[30]);
t18=C_mutate(&lf[31] /* (set! hash-table-canonical-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2984,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[32]+1);
t20=C_mutate(&lf[33] /* (set! *make-hash-table ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3014,a[2]=t19,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[36]+1);
t23=*((C_word*)lf[37]+1);
t24=*((C_word*)lf[38]+1);
t25=*((C_word*)lf[39]+1);
t26=*((C_word*)lf[40]+1);
t27=C_mutate((C_word*)lf[41]+1 /* (set! make-hash-table ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3045,a[2]=t26,a[3]=t25,a[4]=t24,a[5]=t23,a[6]=t22,a[7]=t21,a[8]=((C_word)li32),tmp=(C_word)a,a+=9,tmp));
t28=C_mutate((C_word*)lf[70]+1 /* (set! hash-table? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[71]+1 /* (set! hash-table-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3414,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[72]+1 /* (set! hash-table-equivalence-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[73]+1 /* (set! hash-table-hash-function ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[74]+1 /* (set! hash-table-min-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3441,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[75]+1 /* (set! hash-table-max-load ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3450,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[76]+1 /* (set! hash-table-weak-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3459,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[77]+1 /* (set! hash-table-weak-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3468,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[78]+1 /* (set! hash-table-has-initial? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3477,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[79]+1 /* (set! hash-table-initial ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[80]+1 /* (set! hash-table-resize! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t39=*((C_word*)lf[32]+1);
t40=C_mutate(&lf[81] /* (set! *hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3609,a[2]=t39,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp));
t41=C_mutate((C_word*)lf[82]+1 /* (set! hash-table-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t42=*((C_word*)lf[35]+1);
t43=C_mutate((C_word*)lf[83]+1 /* (set! hash-table-update! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3730,a[2]=t42,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp));
t44=*((C_word*)lf[35]+1);
t45=C_mutate(&lf[87] /* (set! *hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4044,a[2]=t44,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp));
t46=C_mutate((C_word*)lf[88]+1 /* (set! hash-table-update!/default ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t47=*((C_word*)lf[35]+1);
t48=C_mutate((C_word*)lf[89]+1 /* (set! hash-table-set! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4284,a[2]=t47,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp));
t49=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4500,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t50=*((C_word*)lf[35]+1);
t51=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5526,a[2]=t50,a[3]=((C_word)li113),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:787: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[116]+1)))(5,*((C_word*)lf[116]+1),t49,t51,*((C_word*)lf[89]+1),lf[117]);}

/* a5525 in k1311 */
static void C_ccall f_5526(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr4r,(void*)f_5526r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_5526r(t0,t1,t2,t3,t4);}}

static void C_ccall f_5526r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(11);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5530,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_5530(2,t6,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5646,a[2]=t2,a[3]=t3,a[4]=((C_word)li112),tmp=(C_word)a,a+=5,tmp));}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_5530(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* f_5646 in a5525 in k1311 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
/* srfi-69.scm:790: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[6]+1)))(7,*((C_word*)lf[6]+1),t1,lf[85],lf[91],lf[115],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5528 in a5525 in k1311 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=C_i_check_structure_2(((C_word*)t0)[5],lf[34],lf[91]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:794: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t1,lf[91]);}

/* k5534 in k5528 in a5525 in k1311 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_slot(((C_word*)t0)[6],C_fix(3));
t4=C_slot(((C_word*)t0)[6],C_fix(4));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t6=C_block_size(t2);
/* srfi-69.scm:798: hash */
t7=t4;
((C_proc4)C_retrieve_proc(t7))(4,t7,t5,((C_word*)t0)[3],t6);}

/* k5546 in k5534 in k5528 in a5525 in k1311 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5563,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li110),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5563(t7,((C_word*)t0)[2],t3);}
else{
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5605,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li111),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_5605(t7,((C_word*)t0)[2],t3);}}

/* loop in k5546 in k5534 in k5528 in a5525 in k1311 */
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5605,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:811: def */
t3=((C_word*)t0)[5];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5624,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:813: test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k5622 in loop in k5546 in k5534 in k5528 in a5525 in k1311 */
static void C_ccall f_5624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:815: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5605(t3,((C_word*)t0)[5],t2);}}

/* loop in k5546 in k5534 in k5528 in a5525 in k1311 */
static void C_fcall f_5563(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5563,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* srfi-69.scm:803: def */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_slot(t3,C_fix(1)));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:807: loop */
t8=t1;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4498 in k1311 */
static void C_ccall f_4500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[63],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4500,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! hash-table-ref ...) */,t1);
t3=*((C_word*)lf[35]+1);
t4=C_mutate((C_word*)lf[92]+1 /* (set! hash-table-ref/default ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4502,a[2]=t3,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp));
t5=*((C_word*)lf[35]+1);
t6=C_mutate((C_word*)lf[93]+1 /* (set! hash-table-exists? ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4608,a[2]=t5,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t7=*((C_word*)lf[35]+1);
t8=C_mutate((C_word*)lf[94]+1 /* (set! hash-table-delete! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4716,a[2]=t7,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate((C_word*)lf[95]+1 /* (set! hash-table-remove! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4847,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[96]+1 /* (set! hash-table-clear! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4943,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[98] /* (set! *hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4959,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[99]+1 /* (set! hash-table-merge! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5027,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[100]+1 /* (set! hash-table-merge ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5039,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[101]+1 /* (set! hash-table->alist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5055,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[102]+1 /* (set! alist->hash-table ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5128,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[103]+1 /* (set! hash-table-keys ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5182,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[104]+1 /* (set! hash-table-values ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5247,a[2]=((C_word)li96),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[105] /* (set! *hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5312,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate(&lf[106] /* (set! *hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5383,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[107]+1 /* (set! hash-table-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5449,a[2]=((C_word)li104),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[108]+1 /* (set! hash-table-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5461,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[109]+1 /* (set! hash-table-walk ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5473,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[110]+1 /* (set! hash-table-map ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5485,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5508,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t25=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:1073: ##sys#register-record-printer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t24,lf[34],t25);}

/* a5509 in k4498 in k1311 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5510,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5514,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1076: ##sys#print */
t5=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[113],C_SCHEME_FALSE,t3);}

/* k5512 in a5509 in k4498 in k1311 */
static void C_ccall f_5514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(2));
/* srfi-69.scm:1077: ##sys#print */
t4=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k5515 in k5512 in a5509 in k4498 in k1311 */
static void C_ccall f_5517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1078: ##sys#print */
t2=*((C_word*)lf[111]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[112],C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k5506 in k4498 in k1311 */
static void C_ccall f_5508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* hash-table-map in k4498 in k1311 */
static void C_ccall f_5485(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5485,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[110]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5492,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1067: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t3,lf[110]);}

/* k5490 in hash-table-map in k4498 in k1311 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5497,a[2]=((C_word*)t0)[4],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1068: *hash-table-fold */
f_5383(((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}

/* a5496 in k5490 in hash-table-map in k4498 in k1311 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5497,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5505,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:1068: func */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t2,t3);}

/* k5503 in a5496 in k5490 in hash-table-map in k4498 in k1311 */
static void C_ccall f_5505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5505,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* hash-table-walk in k4498 in k1311 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5473,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[109]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5480,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1062: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t3,lf[109]);}

/* k5478 in hash-table-walk in k4498 in k1311 */
static void C_ccall f_5480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1063: *hash-table-for-each */
f_5312(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-for-each in k4498 in k1311 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5461,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[108]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5468,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:1057: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t3,lf[108]);}

/* k5466 in hash-table-for-each in k4498 in k1311 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1058: *hash-table-for-each */
f_5312(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* hash-table-fold in k4498 in k1311 */
static void C_ccall f_5449(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5449,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[107]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5456,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:1052: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t6,t3,lf[107]);}

/* k5454 in hash-table-fold in k4498 in k1311 */
static void C_ccall f_5456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1053: *hash-table-fold */
f_5383(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-fold in k4498 in k1311 */
static void C_fcall f_5383(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5383,NULL,4,t1,t2,t3,t4);}
t5=C_slot(t2,C_fix(1));
t6=C_block_size(t5);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5395,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t6,a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_5395(t10,t1,C_fix(0),t4);}

/* loop in *hash-table-fold in k4498 in k1311 */
static void C_fcall f_5395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5395,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5411,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word)li101),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_5411(t8,t1,t4,t3);}}

/* fold2 in loop in *hash-table-fold in k4498 in k1311 */
static void C_fcall f_5411(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5411,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:1045: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_5395(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5439,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t7=C_slot(t4,C_fix(0));
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:1048: func */
t9=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t9))(5,t9,t6,t7,t8,t3);}}

/* k5437 in fold2 in loop in *hash-table-fold in k4498 in k1311 */
static void C_ccall f_5439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:1047: fold2 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5411(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* *hash-table-for-each in k4498 in k1311 */
static void C_fcall f_5312(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5312,NULL,3,t1,t2,t3);}
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5324,a[2]=t3,a[3]=t4,a[4]=t7,a[5]=t5,a[6]=((C_word)li99),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5324(t9,t1,C_fix(0));}

/* doloop1189 in *hash-table-for-each in k4498 in k1311 */
static void C_fcall f_5324(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5324,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5334,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5347,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word)li98),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_5347(t8,t3,t4);}}

/* loop1194 in doloop1189 in *hash-table-for-each in k4498 in k1311 */
static void C_fcall f_5347(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5347,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5355,a[2]=((C_word*)t0)[3],a[3]=((C_word)li97),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5370,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g12011202 */
t6=t3;
f_5355(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5368 in loop1194 in doloop1189 in *hash-table-for-each in k4498 in k1311 */
static void C_ccall f_5370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5347(t3,((C_word*)t0)[2],t2);}

/* g1201 in loop1194 in doloop1189 in *hash-table-for-each in k4498 in k1311 */
static void C_fcall f_5355(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5355,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* srfi-69.scm:1033: proc */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t3,t4);}

/* k5332 in doloop1189 in *hash-table-for-each in k4498 in k1311 */
static void C_ccall f_5334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5324(t3,((C_word*)t0)[2],t2);}

/* hash-table-values in k4498 in k1311 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5247,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[104]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5262,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li95),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5262(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-values in k4498 in k1311 */
static void C_fcall f_5262(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5262,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5278,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5278(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-values in k4498 in k1311 */
static void C_fcall f_5278(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5278,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:1015: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5262(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(1));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1016: loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* hash-table-keys in k4498 in k1311 */
static void C_ccall f_5182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5182,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[103]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5197,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5197(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table-keys in k4498 in k1311 */
static void C_fcall f_5197(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5197,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5213,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5213(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table-keys in k4498 in k1311 */
static void C_fcall f_5213(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5213,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:1000: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5197(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_a_i_cons(&a,2,t6,t3);
/* srfi-69.scm:1001: loop2 */
t10=t1;
t11=t4;
t12=t7;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}

/* alist->hash-table in k4498 in k1311 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5128r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5128r(t0,t1,t2,t3);}}

static void C_ccall f_5128r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=C_i_check_list_2(t2,lf[102]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5135,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t5,*((C_word*)lf[41]+1),t3);}

/* k5133 in alist->hash-table in k4498 in k1311 */
static void C_ccall f_5135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5138,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5140,a[2]=t4,a[3]=t1,a[4]=((C_word)li89),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5140(t6,t2,((C_word*)t0)[2]);}

/* loop1143 in k5133 in alist->hash-table in k4498 in k1311 */
static void C_fcall f_5140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5140,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[3],a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5169,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11501151 */
t6=t3;
f_5148(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5167 in loop1143 in k5133 in alist->hash-table in k4498 in k1311 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5140(t3,((C_word*)t0)[2],t2);}

/* g1150 in loop1143 in k5133 in alist->hash-table in k4498 in k1311 */
static void C_fcall f_5148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5148,NULL,3,t0,t1,t2);}
t3=C_i_check_pair_2(t2,lf[102]);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5161,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:984: *hash-table-update!/default */
t7=lf[87];
f_4044(t7,t1,((C_word*)t0)[2],t4,t5,t6);}

/* a5160 in g1150 in loop1143 in k5133 in alist->hash-table in k4498 in k1311 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5161,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5136 in k5133 in alist->hash-table in k4498 in k1311 */
static void C_ccall f_5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* hash-table->alist in k4498 in k1311 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5055,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[101]);
t4=C_slot(t2,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5070,a[2]=t7,a[3]=t4,a[4]=t5,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_5070(t9,t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in hash-table->alist in k4498 in k1311 */
static void C_fcall f_5070(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5070,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5086,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_5086(t8,t1,t4,t3);}}

/* loop2 in loop in hash-table->alist in k4498 in k1311 */
static void C_fcall f_5086(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5086,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:972: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5070(t5,t1,t4,t3);}
else{
t4=C_slot(t2,C_fix(1));
t5=C_slot(t2,C_fix(0));
t6=C_slot(t5,C_fix(0));
t7=C_slot(t5,C_fix(1));
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,t8,t3);
/* srfi-69.scm:973: loop2 */
t12=t1;
t13=t4;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* hash-table-merge in k4498 in k1311 */
static void C_ccall f_5039(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5039,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[100]);
t5=C_i_check_structure_2(t3,lf[34],lf[100]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5053,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:958: *hash-table-copy */
t7=lf[81];
f_3609(t7,t6,t2);}

/* k5051 in hash-table-merge in k4498 in k1311 */
static void C_ccall f_5053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:958: *hash-table-merge! */
f_4959(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* hash-table-merge! in k4498 in k1311 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5027,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[99]);
t5=C_i_check_structure_2(t3,lf[34],lf[99]);
/* srfi-69.scm:953: *hash-table-merge! */
f_4959(t1,t2,t3);}

/* *hash-table-merge! in k4498 in k1311 */
static void C_fcall f_4959(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4959,NULL,3,t1,t2,t3);}
t4=C_slot(t3,C_fix(1));
t5=C_block_size(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4971,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=t5,a[6]=((C_word)li80),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_4971(t9,t1,C_fix(0));}

/* doloop1105 in *hash-table-merge! in k4498 in k1311 */
static void C_fcall f_4971(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4971,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=((C_word*)t0)[4];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4981,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4994,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4994(t8,t3,t4);}}

/* doloop1108 in doloop1105 in *hash-table-merge! in k4498 in k1311 */
static void C_fcall f_4994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4994,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5007,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5020,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm:948: *hash-table-update!/default */
t8=lf[87];
f_4044(t8,t4,((C_word*)t0)[2],t5,t6,t7);}}

/* a5019 in doloop1108 in doloop1105 in *hash-table-merge! in k4498 in k1311 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5020,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5005 in doloop1108 in doloop1105 in *hash-table-merge! in k4498 in k1311 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4994(t3,((C_word*)t0)[2],t2);}

/* k4979 in doloop1105 in *hash-table-merge! in k4498 in k1311 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4971(t3,((C_word*)t0)[2],t2);}

/* hash-table-clear! in k4498 in k1311 */
static void C_ccall f_4943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4943,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[96]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4950,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(1));
/* srfi-69.scm:935: vector-fill! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),t4,t5,C_SCHEME_END_OF_LIST);}

/* k4948 in hash-table-clear! in k4498 in k1311 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_fix(0)));}

/* hash-table-remove! in k4498 in k1311 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4847,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[95]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4854,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:912: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t3,lf[95]);}

/* k4852 in hash-table-remove! in k4498 in k1311 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=C_block_size(t2);
t4=C_slot(((C_word*)t0)[4],C_fix(2));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=((C_word)li75),tmp=(C_word)a,a+=9,tmp));
t10=((C_word*)t8)[1];
f_4868(t10,((C_word*)t0)[2],C_fix(0));}

/* doloop1082 in k4852 in hash-table-remove! in k4498 in k1311 */
static void C_fcall f_4868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4868,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)((C_word*)t0)[5])[1]));}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4881,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word)li74),tmp=(C_word)a,a+=8,tmp));
t8=((C_word*)t6)[1];
f_4894(t8,t3,C_SCHEME_FALSE,t4);}}

/* loop in doloop1082 in k4852 in hash-table-remove! in k4498 in k1311 */
static void C_fcall f_4894(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4894,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4913,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t5,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=C_slot(t4,C_fix(0));
t8=C_slot(t4,C_fix(1));
/* srfi-69.scm:922: func */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t6,t7,t8);}}

/* k4911 in loop in doloop1082 in k4852 in hash-table-remove! in k4498 in k1311 */
static void C_ccall f_4913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[9])?C_i_setslot(((C_word*)t0)[9],C_fix(1),((C_word*)t0)[8]):C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[8]));
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
/* srfi-69.scm:929: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4894(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[8]);}}

/* k4879 in doloop1082 in k4852 in hash-table-remove! in k4498 in k1311 */
static void C_ccall f_4881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4868(t3,((C_word*)t0)[2],t2);}

/* hash-table-delete! in k4498 in k1311 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4716,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[94]);
t5=C_slot(t2,C_fix(1));
t6=C_block_size(t5);
t7=C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4732,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:876: hash */
t9=t7;
((C_proc4)C_retrieve_proc(t9))(4,t9,t8,t3,t6);}

/* k4730 in hash-table-delete! in k4498 in k1311 */
static void C_ccall f_4732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4732,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(3));
t3=C_slot(((C_word*)t0)[6],C_fix(2));
t4=C_fixnum_difference(t3,C_fix(1));
t5=C_slot(((C_word*)t0)[5],t1);
t6=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4752,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],a[7]=((C_word)li71),tmp=(C_word)a,a+=8,tmp);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,f_4752(t7,C_SCHEME_FALSE,t5));}
else{
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t8,a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[5],a[9]=((C_word)li72),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4799(t10,((C_word*)t0)[2],C_SCHEME_FALSE,t5);}}

/* loop in k4730 in hash-table-delete! in k4498 in k1311 */
static void C_fcall f_4799(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4799,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4818,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t5,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t7=C_slot(t4,C_fix(0));
/* srfi-69.scm:899: test */
t8=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t8))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k4816 in loop in k4730 in hash-table-delete! in k4498 in k1311 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=(C_truep(((C_word*)t0)[10])?C_i_setslot(((C_word*)t0)[10],C_fix(1),((C_word*)t0)[9]):C_i_setslot(((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[9]));
t3=C_i_set_i_slot(((C_word*)t0)[6],C_fix(2),((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}
else{
/* srfi-69.scm:906: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4799(t2,((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[9]);}}

/* loop in k4730 in hash-table-delete! in k4498 in k1311 */
static C_word C_fcall f_4752(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t2))){
return(C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
t5=C_slot(t3,C_fix(0));
t6=C_eqp(((C_word*)t0)[6],t5);
if(C_truep(t6)){
t7=(C_truep(t1)?C_i_setslot(t1,C_fix(1),t4):C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t4));
t8=C_i_set_i_slot(((C_word*)t0)[3],C_fix(2),((C_word*)t0)[2]);
return(C_SCHEME_TRUE);}
else{
t10=t2;
t11=t4;
t1=t10;
t2=t11;
goto loop;}}}

/* hash-table-exists? in k4498 in k1311 */
static void C_ccall f_4608(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4608,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[34],lf[93]);
t5=C_slot(t2,C_fix(1));
t6=C_slot(t2,C_fix(3));
t7=C_slot(t2,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4624,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=t6,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
t9=C_block_size(t5);
/* srfi-69.scm:852: hash */
t10=t7;
((C_proc4)C_retrieve_proc(t10))(4,t10,t8,t3,t9);}

/* k4622 in hash-table-exists? in k4498 in k1311 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4624,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[6],((C_word*)t0)[5]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[4],t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[3],a[3]=((C_word)li68),tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4639(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[4],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4679,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4679(t7,((C_word*)t0)[2],t3);}}

/* loop in k4622 in hash-table-exists? in k4498 in k1311 */
static void C_fcall f_4679(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4679,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:864: test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4690 in loop in k4622 in hash-table-exists? in k4498 in k1311 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:865: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4679(t3,((C_word*)t0)[4],t2);}}

/* loop in k4622 in hash-table-exists? in k4498 in k1311 */
static C_word C_fcall f_4639(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t1))){
return(C_SCHEME_FALSE);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(t4);}
else{
t5=C_slot(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* hash-table-ref/default in k4498 in k1311 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4502,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[92]);
t6=C_slot(t2,C_fix(1));
t7=C_slot(t2,C_fix(3));
t8=C_slot(t2,C_fix(4));
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4518,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t6,a[6]=t7,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
t10=C_block_size(t6);
/* srfi-69.scm:826: hash */
t11=t8;
((C_proc4)C_retrieve_proc(t11))(4,t11,t9,t3,t10);}

/* k4516 in hash-table-ref/default in k4498 in k1311 */
static void C_ccall f_4518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4518,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=C_slot(((C_word*)t0)[5],t1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4533,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_4533(t4,t3));}
else{
t3=C_slot(((C_word*)t0)[5],t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word)li66),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4572(t7,((C_word*)t0)[2],t3);}}

/* loop in k4516 in hash-table-ref/default in k4498 in k1311 */
static void C_fcall f_4572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4572,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[5];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4588,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:841: test */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}

/* k4586 in loop in k4516 in hash-table-ref/default in k4498 in k1311 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[4],C_fix(1)));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:843: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4572(t3,((C_word*)t0)[5],t2);}}

/* loop in k4516 in hash-table-ref/default in k4498 in k1311 */
static C_word C_fcall f_4533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
loop:
C_stack_check;
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=C_slot(t1,C_fix(0));
t3=C_slot(t2,C_fix(0));
t4=C_eqp(((C_word*)t0)[2],t3);
if(C_truep(t4)){
return(C_slot(t2,C_fix(1)));}
else{
t5=C_slot(t1,C_fix(1));
t8=t5;
t1=t8;
goto loop;}}}

/* hash-table-set! in k1311 */
static void C_ccall f_4284(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[23],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4284,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[34],lf[89]);
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4367,a[2]=t7,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(5));
t12=C_slot(t9,C_fix(6));
t13=C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4316,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4360,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm:615: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t15,t16);}

/* k4358 in hash-table-set! in k1311 */
static void C_ccall f_4360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4316(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4316(t3,t2);}}

/* k4314 in hash-table-set! in k1311 */
static void C_fcall f_4316(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4316,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4327,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm:616: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t3,t4);}

/* k4350 in k4314 in hash-table-set! in k1311 */
static void C_ccall f_4352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4327(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4327(t3,t2);}}

/* k4325 in k4314 in hash-table-set! in k1311 */
static void C_fcall f_4327(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4327,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4333,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_4333(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4333(t3,C_SCHEME_FALSE);}}

/* k4331 in k4325 in k4314 in hash-table-set! in k1311 */
static void C_fcall f_4333(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:619: hash-table-resize! */
t2=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4367(2,t3,t2);}}

/* k4365 in hash-table-set! in k1311 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(4));
t3=C_slot(((C_word*)t0)[7],C_fix(3));
t4=C_slot(((C_word*)t0)[7],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4382,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:759: hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[4],t5);}

/* k4380 in k4365 in hash-table-set! in k1311 */
static void C_ccall f_4382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4382,2,t0,t1);}
t2=C_slot(((C_word*)t0)[9],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4388,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=C_eqp(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4399,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word)li62),tmp=(C_word)a,a+=11,tmp));
t8=((C_word*)t6)[1];
f_4399(t8,t3,t2);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t1,a[7]=((C_word*)t0)[9],a[8]=t2,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=((C_word)li63),tmp=(C_word)a,a+=12,tmp));
t8=((C_word*)t6)[1];
f_4448(t8,t3,t2);}}

/* loop in k4380 in k4365 in hash-table-set! in k1311 */
static void C_fcall f_4448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4448,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[10],((C_word*)t0)[9]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[8]);
t5=C_i_setslot(((C_word*)t0)[7],((C_word*)t0)[6],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]));}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4478,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[9],a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:779: test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[10],t5);}}

/* k4476 in loop in k4380 in k4365 in hash-table-set! in k1311 */
static void C_ccall f_4478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[5],C_fix(1),((C_word*)t0)[4]));}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:781: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4448(t3,((C_word*)t0)[6],t2);}}

/* loop in k4380 in k4365 in hash-table-set! in k1311 */
static void C_fcall f_4399(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4399,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[7]);
t5=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]));}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[9],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_setslot(t3,C_fix(1),((C_word*)t0)[8]));}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:771: loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4386 in k4380 in k4365 in hash-table-set! in k1311 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[90]+1));}

/* hash-table-update!/default in k1311 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4272,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_check_structure_2(t2,lf[34],lf[88]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4279,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:746: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t7,t4,lf[88]);}

/* k4277 in hash-table-update!/default in k1311 */
static void C_ccall f_4279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:747: *hash-table-update!/default */
t2=lf[87];
f_4044(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* *hash-table-update!/default in k1311 */
static void C_fcall f_4044(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4044,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_slot(t2,C_fix(2));
t7=C_fixnum_plus(t6,C_fix(1));
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4124,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t7,a[6]=t3,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t9=t2;
t10=C_slot(t9,C_fix(1));
t11=C_slot(t9,C_fix(5));
t12=C_slot(t9,C_fix(6));
t13=C_block_size(t10);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4073,a[2]=t12,a[3]=t7,a[4]=t13,a[5]=t10,a[6]=t9,a[7]=t8,tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_a_i_times(&a,2,t13,t11);
/* srfi-69.scm:615: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t15,t16);}

/* k4115 in *hash-table-update!/default in k1311 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4073(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4073(t3,t2);}}

/* k4071 in *hash-table-update!/default in k1311 */
static void C_fcall f_4073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4073,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4109,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm:616: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t3,t4);}

/* k4107 in k4071 in *hash-table-update!/default in k1311 */
static void C_ccall f_4109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_4084(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_4084(t3,t2);}}

/* k4082 in k4071 in *hash-table-update!/default in k1311 */
static void C_fcall f_4084(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4084,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_4090(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_4090(t3,C_SCHEME_FALSE);}}

/* k4088 in k4082 in k4071 in *hash-table-update!/default in k1311 */
static void C_fcall f_4090(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:619: hash-table-resize! */
t2=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_4124(2,t3,t2);}}

/* k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4124,2,t0,t1);}
t2=C_slot(((C_word*)t0)[8],C_fix(4));
t3=C_slot(((C_word*)t0)[8],C_fix(3));
t4=C_slot(((C_word*)t0)[8],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:714: hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=C_slot(((C_word*)t0)[10],t1);
t3=C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4153,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li58),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_4153(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li59),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_4212(t7,((C_word*)t0)[2],t2);}}

/* loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_fcall f_4212(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4212,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4222,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:733: func */
t4=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:738: test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k4243 in loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm:739: func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:742: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4212(t3,((C_word*)t0)[5],t2);}}

/* k4246 in k4243 in loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4220 in loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4222,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(9);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4153,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4163,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:720: func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[3]);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm:726: func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:729: loop */
t11=t1;
t12=t6;
t1=t11;
t2=t12;
goto loop;}}}

/* k4187 in loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4161 in loop in k4137 in k4122 in *hash-table-update!/default in k1311 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-update! in k1311 */
static void C_ccall f_3730(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+16)){
C_save_and_reclaim((void*)tr4r,(void*)f_3730r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3730r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3730r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(16);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3732,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3976,a[2]=t3,a[3]=t5,a[4]=t2,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t6,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-func816877 */
t8=t7;
f_3993(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-thunk817871 */
t10=t6;
f_3976(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body814821 */
t12=t5;
f_3732(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-func816 in hash-table-update! in k1311 */
static void C_fcall f_3993(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3993,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3999,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* def-thunk817871 */
t3=((C_word*)t0)[2];
f_3976(t3,t1,t2);}

/* a3998 in def-func816 in hash-table-update! in k1311 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3999,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* def-thunk817 in hash-table-update! in k1311 */
static void C_fcall f_3976(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3976,NULL,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[4],C_fix(9));
if(C_truep(t3)){
/* body814821 */
t4=((C_word*)t0)[3];
f_3732(t4,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3988,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
/* body814821 */
t5=((C_word*)t0)[3];
f_3732(t5,t1,t2,t4);}}

/* f_3988 in def-thunk817 in hash-table-update! in k1311 */
static void C_ccall f_3988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3988,2,t0,t1);}
/* srfi-69.scm:663: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[6]+1)))(7,*((C_word*)lf[6]+1),t1,lf[85],lf[83],lf[86],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* body814 in hash-table-update! in k1311 */
static void C_fcall f_3732(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3732,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(((C_word*)t0)[4],lf[34],lf[83]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3739,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:667: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t2,lf[83]);}

/* k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3742,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:668: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,((C_word*)t0)[3],lf[83]);}

/* k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3742,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(2));
t3=C_fixnum_plus(t2,C_fix(1));
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[7];
t6=C_slot(t5,C_fix(1));
t7=C_slot(t5,C_fix(5));
t8=C_slot(t5,C_fix(6));
t9=C_block_size(t6);
t10=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3770,a[2]=t8,a[3]=t3,a[4]=t9,a[5]=t6,a[6]=t5,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3814,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_times(&a,2,t9,t7);
/* srfi-69.scm:615: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t11,t12);}

/* k3812 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_3770(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_3770(t3,t2);}}

/* k3768 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_fcall f_3770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3770,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,((C_word*)t0)[4],((C_word*)t0)[2]);
/* srfi-69.scm:616: floor */
((C_proc3)C_retrieve_proc(*((C_word*)lf[84]+1)))(3,*((C_word*)lf[84]+1),t3,t4);}

/* k3804 in k3768 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_immp(t1))){
t2=((C_word*)t0)[2];
f_3781(t2,t1);}
else{
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
f_3781(t3,t2);}}

/* k3779 in k3768 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_fcall f_3781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3781,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[4],C_fix(1073741823)))){
t3=C_fixnum_less_or_equal_p(((C_word*)t0)[3],((C_word*)t0)[2]);
t4=t2;
f_3787(t4,(C_truep(t3)?C_fixnum_less_or_equal_p(((C_word*)t0)[2],t1):C_SCHEME_FALSE));}
else{
t3=t2;
f_3787(t3,C_SCHEME_FALSE);}}

/* k3785 in k3779 in k3768 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_fcall f_3787(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:619: hash-table-resize! */
t2=*((C_word*)lf[80]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3821(2,t3,t2);}}

/* k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3821,2,t0,t1);}
t2=C_slot(((C_word*)t0)[8],C_fix(4));
t3=C_slot(((C_word*)t0)[8],C_fix(3));
t4=C_slot(((C_word*)t0)[8],C_fix(1));
t5=C_block_size(t4);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t3,a[9]=((C_word*)t0)[7],a[10]=t4,tmp=(C_word)a,a+=11,tmp);
/* srfi-69.scm:675: hash */
t7=t2;
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[6],t5);}

/* k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
t2=C_slot(((C_word*)t0)[10],t1);
t3=C_eqp(((C_word*)t0)[9],((C_word*)t0)[8]);
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3850,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[10],a[9]=t2,a[10]=((C_word*)t0)[7],a[11]=((C_word)li50),tmp=(C_word)a,a+=12,tmp));
t7=((C_word*)t5)[1];
f_3850(t7,((C_word*)t0)[2],t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[8],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=t2,a[11]=((C_word*)t0)[7],a[12]=((C_word)li51),tmp=(C_word)a,a+=13,tmp));
t7=((C_word*)t5)[1];
f_3913(t7,((C_word*)t0)[2],t2);}}

/* loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_fcall f_3913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3913,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3923,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3941,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:694: thunk */
t5=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3950,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t3,C_fix(0));
/* srfi-69.scm:699: test */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[11],t5);}}

/* k3948 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3950,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3953,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* srfi-69.scm:700: func */
t4=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:703: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3913(t3,((C_word*)t0)[5],t2);}}

/* k3951 in k3948 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3939 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:694: func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3921 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3923,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a;
loop:
a=C_alloc(13);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3850,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3860,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3878,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:681: thunk */
t5=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_eqp(((C_word*)t0)[10],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3890,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t3,C_fix(1));
/* srfi-69.scm:687: func */
t8=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t8))(3,t8,t6,t7);}
else{
t6=C_slot(t2,C_fix(1));
/* srfi-69.scm:690: loop */
t12=t1;
t13=t6;
t1=t12;
t2=t13;
goto loop;}}}

/* k3888 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(1),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k3876 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:681: func */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k3858 in loop in k3834 in k3819 in k3740 in k3737 in body814 in hash-table-update! in k1311 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[7]);
t4=C_i_setslot(((C_word*)t0)[6],((C_word*)t0)[5],t3);
t5=C_i_set_i_slot(((C_word*)t0)[4],C_fix(2),((C_word*)t0)[3]);
t6=t1;
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* hash-table-copy in k1311 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3721,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[82]);
/* srfi-69.scm:648: *hash-table-copy */
t4=lf[81];
f_3609(t4,t1,t2);}

/* *hash-table-copy in k1311 */
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3609,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=C_block_size(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3619,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:628: make-vector */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}

/* k3617 in *hash-table-copy in k1311 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3624,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word)li47),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_3624(t5,((C_word*)t0)[2],C_fix(0));}

/* doloop791 in k3617 in *hash-table-copy in k1311 */
static void C_fcall f_3624(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3624,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_slot(((C_word*)t0)[5],C_fix(3));
t4=C_slot(((C_word*)t0)[5],C_fix(4));
t5=C_slot(((C_word*)t0)[5],C_fix(2));
t6=C_slot(((C_word*)t0)[5],C_fix(5));
t7=C_slot(((C_word*)t0)[5],C_fix(6));
t8=C_slot(((C_word*)t0)[5],C_fix(7));
t9=C_slot(((C_word*)t0)[5],C_fix(8));
t10=C_slot(((C_word*)t0)[5],C_fix(9));
/* srfi-69.scm:631: *make-hash-table */
t11=lf[33];
f_3014(t11,t1,t3,t4,t5,t6,t7,t10,C_a_i_list(&a,1,((C_word*)t0)[4]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3680,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[2],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3686,a[2]=t6,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3686(t8,t3,t4);}}

/* copy-loop in doloop791 in k3617 in *hash-table-copy in k1311 */
static void C_fcall f_3686(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(7);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3686,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=C_slot(t3,C_fix(1));
t6=C_a_i_cons(&a,2,t4,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3707,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_slot(t2,C_fix(1));
/* srfi-69.scm:644: copy-loop */
t10=t7;
t11=t8;
t1=t10;
t2=t11;
goto loop;}}

/* k3705 in copy-loop in doloop791 in k3617 in *hash-table-copy in k1311 */
static void C_ccall f_3707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3707,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3678 in doloop791 in k3617 in *hash-table-copy in k1311 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3624(t4,((C_word*)t0)[2],t3);}

/* hash-table-resize! in k1311 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3583,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3587,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_fixnum_times(t4,C_fix(2));
/* srfi-69.scm:602: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t5,C_fix(1073741823),t6);}

/* k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3590,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:603: hash-table-canonical-length */
f_2984(t2,lf[29],t1);}

/* k3588 in k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3593,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:604: make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t2,t1,C_SCHEME_END_OF_LIST);}

/* k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3596,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(4));
t4=((C_word*)t0)[2];
t5=t1;
t6=C_block_size(t4);
t7=C_block_size(t5);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3516,a[2]=t7,a[3]=t3,a[4]=t5,a[5]=t4,a[6]=t9,a[7]=t6,a[8]=((C_word)li44),tmp=(C_word)a,a+=9,tmp));
t11=((C_word*)t9)[1];
f_3516(t11,t2,C_fix(0));}

/* doloop767 in k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_fcall f_3516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3516,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3526,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[5],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=((C_word*)t0)[4],a[6]=((C_word)li43),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_3539(t8,t3,t4);}}

/* loop in doloop767 in k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_fcall f_3539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3539,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3555,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:594: hash */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t5,t4,((C_word*)t0)[2]);}}

/* k3553 in loop in doloop767 in k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3555,2,t0,t1);}
t2=C_slot(((C_word*)t0)[7],C_fix(1));
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=C_slot(((C_word*)t0)[5],t1);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_i_setslot(((C_word*)t0)[5],t1,t5);
t7=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:597: loop */
t8=((C_word*)((C_word*)t0)[3])[1];
f_3539(t8,((C_word*)t0)[2],t7);}

/* k3524 in doloop767 in k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3516(t3,((C_word*)t0)[2],t2);}

/* k3594 in k3591 in k3588 in k3585 in hash-table-resize! in k1311 */
static void C_ccall f_3596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]));}

/* hash-table-initial in k1311 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3489,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[79]);
t4=C_slot(t2,C_fix(9));
if(C_truep(t4)){
/* srfi-69.scm:581: thunk */
t5=t4;
((C_proc2)C_retrieve_proc(t5))(2,t5,t1);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* hash-table-has-initial? in k1311 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3477,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[78]);
t4=C_slot(t2,C_fix(9));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* hash-table-weak-values in k1311 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3468,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[77]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(8)));}

/* hash-table-weak-keys in k1311 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3459,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(7)));}

/* hash-table-max-load in k1311 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3450,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(6)));}

/* hash-table-min-load in k1311 */
static void C_ccall f_3441(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3441,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[74]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(5)));}

/* hash-table-hash-function in k1311 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3432,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[73]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(4)));}

/* hash-table-equivalence-function in k1311 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3423,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[72]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* hash-table-size in k1311 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3414,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[34],lf[71]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(2)));}

/* hash-table? in k1311 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3408,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[34]));}

/* make-hash-table in k1311 */
static void C_ccall f_3045(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+41)){
C_save_and_reclaim((void*)tr2r,(void*)f_3045r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3045r(t0,t1,t2);}}

static void C_ccall f_3045r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(41);
t3=t2;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=*((C_word*)lf[37]+1);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(307);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=lf[42];
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=lf[43];
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3047,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t6,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t18=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3123,a[2]=t4,a[3]=t2,a[4]=t17,a[5]=t12,a[6]=t16,a[7]=t14,a[8]=t6,a[9]=t1,a[10]=t8,a[11]=t10,tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)t4)[1]))){
t19=t18;
f_3123(t19,C_SCHEME_UNDEFINED);}
else{
t19=C_i_car(((C_word*)t4)[1]);
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3398,a[2]=t4,a[3]=t19,a[4]=t6,a[5]=t18,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:460: keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t20,t19);}}

/* k3396 in make-hash-table in k1311 */
static void C_ccall f_3398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3398,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3123(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3401,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:461: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,((C_word*)t0)[3],lf[41]);}}

/* k3399 in k3396 in make-hash-table in k1311 */
static void C_ccall f_3401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3123(t5,t4);}

/* k3121 in make-hash-table in k1311 */
static void C_fcall f_3123(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3123,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3126(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3378,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:466: keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3376 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3378,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3126(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3381,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:467: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,((C_word*)t0)[3],lf[41]);}}

/* k3379 in k3376 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,((C_word*)t0)[4]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3126(t5,t4);}

/* k3124 in k3121 in make-hash-table in k1311 */
static void C_fcall f_3126(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3126,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t3=t2;
f_3129(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3346,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:472: keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t3);}}

/* k3344 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3346,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
f_3129(t3,t2);}
else{
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[41]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3352,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),((C_word*)t0)[4]))){
t4=t3;
f_3352(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:475: error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t3,lf[41],lf[69],((C_word*)t0)[4]);}}}

/* k3350 in k3344 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3356,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:476: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t2,C_fix(1073741823),((C_word*)t0)[2]);}

/* k3354 in k3350 in k3344 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_3129(t5,t4);}

/* k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_fcall f_3129(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3129,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3164,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=t4,a[9]=((C_word*)t0)[3],a[10]=((C_word)li31),tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_3164(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_fcall f_3164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3164,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3175,a[2]=((C_word*)t0)[9],a[3]=t3,a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3185,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
/* srfi-69.scm:485: keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t3);}}

/* k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[12]);
t3=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t2,tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t3;
f_3191(2,t4,C_i_car(t2));}
else{
/* srfi-69.scm:489: invarg-err */
t4=((C_word*)t0)[2];
f_3175(t4,t3,lf[67]);}}
else{
/* srfi-69.scm:521: invarg-err */
t2=((C_word*)t0)[2];
f_3175(t2,((C_word*)t0)[10],lf[68]);}}

/* k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3194,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[9],lf[49]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3207,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:492: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t4,t1,lf[41]);}
else{
t4=C_eqp(((C_word*)t0)[9],lf[51]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:495: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t5,t1,lf[41]);}
else{
t5=C_eqp(((C_word*)t0)[9],lf[52]);
if(C_truep(t5)){
t6=C_i_check_exact_2(t1,lf[41]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3230,a[2]=t1,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(C_fix(0),t1))){
t8=t7;
f_3230(2,t8,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:500: error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),t7,lf[41],lf[53],t1);}}
else{
t6=C_eqp(((C_word*)t0)[9],lf[54]);
if(C_truep(t6)){
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3248,a[2]=t1,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp));
t8=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm:520: loop */
t9=((C_word*)((C_word*)t0)[11])[1];
f_3164(t9,((C_word*)t0)[10],t8);}
else{
t7=C_eqp(((C_word*)t0)[9],lf[55]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:505: ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t8,t1,lf[41]);}
else{
t8=C_eqp(((C_word*)t0)[9],lf[60]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3283,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* srfi-69.scm:510: ##sys#check-inexact */
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),t9,t1,lf[41]);}
else{
t9=C_eqp(((C_word*)t0)[9],lf[64]);
if(C_truep(t9)){
if(C_truep(t1)){
t10=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm:520: loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3164(t11,((C_word*)t0)[10],t10);}
else{
t10=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm:520: loop */
t11=((C_word*)((C_word*)t0)[11])[1];
f_3164(t11,((C_word*)t0)[10],t10);}}
else{
t10=C_eqp(((C_word*)t0)[9],lf[65]);
if(C_truep(t10)){
if(C_truep(t1)){
t11=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm:520: loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3164(t12,((C_word*)t0)[10],t11);}
else{
t11=C_i_cdr(((C_word*)t0)[12]);
/* srfi-69.scm:520: loop */
t12=((C_word*)((C_word*)t0)[11])[1];
f_3164(t12,((C_word*)t0)[10],t11);}}
else{
/* srfi-69.scm:519: invarg-err */
t11=((C_word*)t0)[2];
f_3175(t11,t2,lf[66]);}}}}}}}}}

/* k3281 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3290,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3296,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:511: fp< */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t4,lf[63],((C_word*)t0)[5]);}

/* k3294 in k3281 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:511: fp< */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[62]);}
else{
t2=((C_word*)t0)[3];
f_3290(2,t2,C_SCHEME_FALSE);}}

/* k3288 in k3281 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3164(t4,((C_word*)t0)[3],t3);}
else{
/* srfi-69.scm:512: error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),((C_word*)t0)[2],lf[41],lf[61],((C_word*)t0)[6]);}}

/* k3284 in k3281 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3164(t4,((C_word*)t0)[2],t3);}

/* k3256 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3265,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:506: fp< */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t4,lf[58],((C_word*)t0)[5]);}

/* k3269 in k3256 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:506: fp< */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[57]);}
else{
t2=((C_word*)t0)[3];
f_3265(2,t2,C_SCHEME_FALSE);}}

/* k3263 in k3256 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3164(t4,((C_word*)t0)[3],t3);}
else{
/* srfi-69.scm:507: error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[46]+1)))(5,*((C_word*)lf[46]+1),((C_word*)t0)[2],lf[41],lf[56],((C_word*)t0)[6]);}}

/* k3259 in k3256 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3164(t4,((C_word*)t0)[2],t3);}

/* f_3248 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3228 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3230,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3234,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* srfi-69.scm:501: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t2,C_fix(1073741823),((C_word*)t0)[2]);}

/* k3232 in k3228 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3164(t4,((C_word*)t0)[2],t3);}

/* k3215 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3164(t4,((C_word*)t0)[2],t3);}

/* k3205 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3164(t4,((C_word*)t0)[2],t3);}

/* k3192 in k3189 in k3183 in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* srfi-69.scm:520: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3164(t3,((C_word*)t0)[2],t2);}

/* invarg-err in loop in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_fcall f_3175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3175,NULL,3,t0,t1,t2);}
/* srfi-69.scm:484: error */
((C_proc6)C_retrieve_proc(*((C_word*)lf[46]+1)))(6,*((C_word*)lf[46]+1),t1,lf[41],t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3130 in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:523: fp< */
((C_proc4)C_retrieve_proc(*((C_word*)lf[48]+1)))(4,*((C_word*)lf[48]+1),t3,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[5])[1]);}

/* k3157 in k3130 in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* srfi-69.scm:524: error */
((C_proc6)C_retrieve_proc(*((C_word*)lf[46]+1)))(6,*((C_word*)lf[46]+1),((C_word*)t0)[4],lf[41],lf[47],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=((C_word*)t0)[4];
f_3135(2,t2,C_SCHEME_UNDEFINED);}}

/* k3133 in k3130 in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* srfi-69.scm:526: hash-table-canonical-length */
f_2984(t2,lf[29],((C_word*)((C_word*)t0)[9])[1]);}

/* k3137 in k3133 in k3130 in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[9])+1,t1);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
/* srfi-69.scm:536: *make-hash-table */
t3=lf[33];
f_3014(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t3=f_3047(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=C_mutate(((C_word *)((C_word*)t0)[8])+1,t3);
/* srfi-69.scm:536: *make-hash-table */
t5=lf[33];
f_3014(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3155,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* srfi-69.scm:533: warning */
((C_proc4)C_retrieve_proc(*((C_word*)lf[44]+1)))(4,*((C_word*)lf[44]+1),t4,lf[41],lf[45]);}}}

/* k3153 in k3137 in k3133 in k3130 in k3127 in k3124 in k3121 in make-hash-table in k1311 */
static void C_ccall f_3155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,*((C_word*)lf[22]+1));
/* srfi-69.scm:536: *make-hash-table */
t3=lf[33];
f_3014(t3,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[8])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1],C_SCHEME_END_OF_LIST);}

/* hash-for-test in make-hash-table in k1311 */
static C_word C_fcall f_3047(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_stack_check;
t1=C_eqp(((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t2=(C_truep(t1)?t1:C_eqp(*((C_word*)lf[35]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t2)){
t3=*((C_word*)lf[17]+1);
return(t3);}
else{
t3=C_eqp(((C_word*)t0)[6],((C_word*)((C_word*)t0)[7])[1]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[36]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t4)){
return(*((C_word*)lf[19]+1));}
else{
t5=C_eqp(((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);
t6=(C_truep(t5)?t5:C_eqp(*((C_word*)lf[37]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t6)){
t7=*((C_word*)lf[22]+1);
return(t7);}
else{
t7=C_eqp(((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1]);
t8=(C_truep(t7)?t7:C_eqp(*((C_word*)lf[38]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t8)){
return(*((C_word*)lf[24]+1));}
else{
t9=C_eqp(((C_word*)t0)[3],((C_word*)((C_word*)t0)[7])[1]);
t10=(C_truep(t9)?t9:C_eqp(*((C_word*)lf[39]+1),((C_word*)((C_word*)t0)[7])[1]));
if(C_truep(t10)){
t11=*((C_word*)lf[28]+1);
return(t11);}
else{
t11=C_eqp(((C_word*)t0)[2],((C_word*)((C_word*)t0)[7])[1]);
if(C_truep(t11)){
return((C_truep(t11)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}
else{
t12=C_eqp(*((C_word*)lf[40]+1),((C_word*)((C_word*)t0)[7])[1]);
return((C_truep(t12)?*((C_word*)lf[4]+1):C_SCHEME_FALSE));}}}}}}}

/* *make-hash-table in k1311 */
static void C_fcall f_3014(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3014,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3018,a[2]=t7,a[3]=t6,a[4]=t5,a[5]=t3,a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t8))){
/* srfi-69.scm:408: make-vector */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t9,t4,C_SCHEME_END_OF_LIST);}
else{
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
t11=t9;
f_3018(2,t11,C_i_car(t8));}
else{
/* ##sys#error */
t11=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,lf[0],t8);}}}

/* k3016 in *make-hash-table in k1311 */
static void C_ccall f_3018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3018,2,t0,t1);}
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,10,lf[34],t1,C_fix(0),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]));}

/* hash-table-canonical-length in k1311 */
static void C_fcall f_2984(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2984,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2990,a[2]=t3,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2990(t4,t2));}

/* loop in hash-table-canonical-length in k1311 */
static C_word C_fcall f_2990(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=C_slot(t1,C_fix(0));
t3=C_slot(t1,C_fix(1));
t4=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
if(C_truep(t4)){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}
else{
if(C_truep(C_i_nullp(t3))){
return(t2);}
else{
t6=t3;
t1=t6;
goto loop;}}}

/* string-ci-hash in k1311 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2841r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2841r(t0,t1,t2,t3);}}

static void C_ccall f_2841r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_check_string_2(t2,lf[27]);
t9=C_i_check_exact_2(t5,lf[27]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2857,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2894,a[2]=t2,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2913,a[2]=t11,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=t12,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
/* def-start586598 */
t14=t13;
f_2922(t14,t10);}
else{
t14=C_i_car(t7);
t15=C_i_cdr(t7);
if(C_truep(C_i_nullp(t15))){
/* def-end587596 */
t16=t12;
f_2913(t16,t10,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
/* body584591 */
t18=t11;
f_2894(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_2857(2,t11,t2);}}

/* def-start586 in string-ci-hash in k1311 */
static void C_fcall f_2922(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2922,NULL,2,t0,t1);}
/* def-end587596 */
t2=((C_word*)t0)[2];
f_2913(t2,t1,C_fix(0));}

/* def-end587 in string-ci-hash in k1311 */
static void C_fcall f_2913(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2913,NULL,3,t0,t1,t2);}
t3=C_block_size(((C_word*)t0)[3]);
/* body584591 */
t4=((C_word*)t0)[2];
f_2894(t4,t1,t2,t3);}

/* body584 in string-ci-hash in k1311 */
static void C_fcall f_2894(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2894,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2898,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm:356: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t4,t2,C_fix(0),t5,lf[28]);}

/* k2896 in body584 in string-ci-hash in k1311 */
static void C_ccall f_2898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm:357: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[28]);}

/* k2899 in k2896 in body584 in string-ci-hash in k1311 */
static void C_ccall f_2901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:358: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2855 in string-ci-hash in k1311 */
static void C_ccall f_2857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_hash_string_ci(t1);
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=C_fixnum_negate(t2);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t3,t5,((C_word*)t0)[2]);}
else{
t4=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t3,t4,((C_word*)t0)[2]);}}

/* string-hash in k1311 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_2700r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2700r(t0,t1,t2,t3);}}

static void C_ccall f_2700r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(17);
t4=C_i_nullp(t3);
t5=(C_truep(t4)?C_fix(536870912):C_i_car(t3));
t6=C_i_nullp(t3);
t7=(C_truep(t6)?C_SCHEME_END_OF_LIST:C_i_cdr(t3));
t8=C_i_check_string_2(t2,lf[24]);
t9=C_i_check_exact_2(t5,lf[24]);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t7))){
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2753,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2772,a[2]=t11,a[3]=t2,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2781,a[2]=t12,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
/* def-start535547 */
t14=t13;
f_2781(t14,t10);}
else{
t14=C_i_car(t7);
t15=C_i_cdr(t7);
if(C_truep(C_i_nullp(t15))){
/* def-end536545 */
t16=t12;
f_2772(t16,t10,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
/* body533540 */
t18=t11;
f_2753(t18,t10,t14,t16);}
else{
/* ##sys#error */
t18=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t10,lf[0],t17);}}}}
else{
t11=t10;
f_2716(2,t11,t2);}}

/* def-start535 in string-hash in k1311 */
static void C_fcall f_2781(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2781,NULL,2,t0,t1);}
/* def-end536545 */
t2=((C_word*)t0)[2];
f_2772(t2,t1,C_fix(0));}

/* def-end536 in string-hash in k1311 */
static void C_fcall f_2772(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2772,NULL,3,t0,t1,t2);}
t3=C_block_size(((C_word*)t0)[3]);
/* body533540 */
t4=((C_word*)t0)[2];
f_2753(t4,t1,t2,t3);}

/* body533 in string-hash in k1311 */
static void C_fcall f_2753(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2753,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2757,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(((C_word*)t0)[2]);
/* srfi-69.scm:344: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t4,t2,C_fix(0),t5,lf[24]);}

/* k2755 in body533 in string-hash in k1311 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* srfi-69.scm:345: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[26]+1)))(6,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2],C_fix(0),t3,lf[24]);}

/* k2758 in k2755 in body533 in string-hash in k1311 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-69.scm:346: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[25]+1)))(5,*((C_word*)lf[25]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2714 in string-hash in k1311 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_hash_string(t1);
t3=((C_word*)t0)[3];
if(C_truep(C_fixnum_lessp(t2,C_fix(0)))){
t4=C_fixnum_negate(t2);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t3,t5,((C_word*)t0)[2]);}
else{
t4=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t2);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t3,t4,((C_word*)t0)[2]);}}

/* equal?-hash in k1311 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2640r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2640r(t0,t1,t2,t3);}}

static void C_ccall f_2640r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2644(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2644(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2642 in equal?-hash in k1311 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[23]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:332: *equal?-hash */
f_2174(t3,((C_word*)t0)[2]);}

/* k2676 in k2642 in equal?-hash in k1311 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}}

/* *equal?-hash in k1311 */
static void C_fcall f_2174(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2174,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2177,a[2]=t8,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp));
t10=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2242,a[2]=t8,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp));
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2293,a[2]=t4,a[3]=t6,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
/* srfi-69.scm:328: recursive-hash */
t12=((C_word*)t8)[1];
f_2293(t12,t1,t2,C_fix(0));}

/* recursive-hash in *equal?-hash in k1311 */
static void C_fcall f_2293(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2293,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,C_fix(4)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(99));}
else{
if(C_truep(C_fixnump(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
if(C_truep(C_charp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(C_character_code(t2)));}
else{
switch(t2){
case C_SCHEME_TRUE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(256));
case C_SCHEME_FALSE:
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(257));
default:
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(258));}
else{
if(C_truep(C_eofp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t2))){
t4=t1;
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t4;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_hash_string(t6));}
else{
if(C_truep(C_i_numberp(t2))){
t4=t1;
t5=t2;
if(C_truep(C_i_flonump(t5))){
t6=C_subbyte(t5,C_fix(7));
t7=C_subbyte(t5,C_fix(6));
t8=C_subbyte(t5,C_fix(5));
t9=C_subbyte(t5,C_fix(4));
t10=C_subbyte(t5,C_fix(3));
t11=C_subbyte(t5,C_fix(2));
t12=C_subbyte(t5,C_fix(1));
t13=C_subbyte(t5,C_fix(0));
t14=C_fixnum_shift_left(t13,C_fix(1));
t15=C_fixnum_plus(t12,t14);
t16=C_fixnum_shift_left(t15,C_fix(1));
t17=C_fixnum_plus(t11,t16);
t18=C_fixnum_shift_left(t17,C_fix(1));
t19=C_fixnum_plus(t10,t18);
t20=C_fixnum_shift_left(t19,C_fix(1));
t21=C_fixnum_plus(t9,t20);
t22=C_fixnum_shift_left(t21,C_fix(1));
t23=C_fixnum_plus(t8,t22);
t24=C_fixnum_shift_left(t23,C_fix(1));
t25=C_fixnum_plus(t7,t24);
t26=C_fixnum_shift_left(t25,C_fix(1));
t27=C_fixnum_plus(t6,t26);
t28=t4;
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,C_fixnum_times(C_fix(331804471),t27));}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:144: ##sys#number-hash-hook */
t7=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}}
else{
t4=t2;
if(C_truep(C_blockp(t4))){
t5=t2;
if(C_truep(C_byteblockp(t5))){
t6=t1;
t7=t2;
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_hash_string(t7));}
else{
if(C_truep(C_i_listp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* g470471 */
t7=t6;
f_2523(t7,t1,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2549,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
/* g473474 */
t7=t6;
f_2549(t7,t1,t2);}
else{
t6=t2;
if(C_truep(C_portp(t6))){
t7=t1;
t8=t2;
t9=C_peek_fixnum(t8,C_fix(0));
t10=C_fixnum_shift_left(t9,C_fix(4));
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2600,a[2]=t10,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* srfi-69.scm:272: input-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t11,t8);}
else{
t7=t2;
if(C_truep(C_specialp(t7))){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2616,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
/* g485486 */
t9=t8;
f_2616(t9,t1,t2);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2628,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* g488489 */
t9=t8;
f_2628(t9,t1,t2);}}}}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(262));}}}}}}}}}}

/* g488 in recursive-hash in *equal?-hash in k1311 */
static void C_fcall f_2628(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2628,NULL,3,t0,t1,t2);}
/* srfi-69.scm:280: vector-hash */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2177(t3,t1,t2,C_fix(0),((C_word*)t0)[2],C_fix(0));}

/* g485 in recursive-hash in *equal?-hash in k1311 */
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2616,NULL,3,t0,t1,t2);}
t3=C_peek_fixnum(t2,C_fix(0));
/* srfi-69.scm:277: vector-hash */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2177(t4,t1,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* k2598 in recursive-hash in *equal?-hash in k1311 */
static void C_ccall f_2600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_fixnum_plus(((C_word*)t0)[2],C_fix(260)):C_fixnum_plus(((C_word*)t0)[2],C_fix(261))));}

/* g473 in recursive-hash in *equal?-hash in k1311 */
static void C_fcall f_2549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2549,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_slot(t2,C_fix(0));
/* srfi-69.scm:267: recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2242(t5,t3,t4,((C_word*)t0)[2]);}

/* k2567 in g473 in recursive-hash in *equal?-hash in k1311 */
static void C_ccall f_2569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2569,2,t0,t1);}
t2=C_fixnum_shift_left(t1,C_fix(16));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2561,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:268: recursive-atomic-hash */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2242(t5,t3,t4,((C_word*)t0)[2]);}

/* k2559 in k2567 in g473 in recursive-hash in *equal?-hash in k1311 */
static void C_ccall f_2561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[2],t1));}

/* g470 in recursive-hash in *equal?-hash in k1311 */
static void C_fcall f_2523(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2523,NULL,3,t0,t1,t2);}
t3=C_i_length(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2535,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* srfi-69.scm:264: recursive-atomic-hash */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2242(t6,t4,t5,((C_word*)t0)[2]);}

/* k2533 in g470 in recursive-hash in *equal?-hash in k1311 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fixnum_plus(((C_word*)t0)[2],t1));}

/* k2487 in recursive-hash in *equal?-hash in k1311 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(t1));}

/* recursive-atomic-hash in *equal?-hash in k1311 */
static void C_fcall f_2242(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2242,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2276,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=t2;
t6=C_i_not(C_blockp(t5));
if(C_truep(t6)){
t7=t4;
f_2276(t7,(C_truep(t6)?t6:C_i_numberp(t5)));}
else{
t7=C_i_symbolp(t5);
t8=t4;
f_2276(t8,(C_truep(t7)?t7:C_i_numberp(t5)));}}

/* k2274 in recursive-atomic-hash in *equal?-hash in k1311 */
static void C_fcall f_2276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2276,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_2279(t3,t1);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_2279(t4,C_byteblockp(t3));}}

/* k2277 in k2274 in recursive-atomic-hash in *equal?-hash in k1311 */
static void C_fcall f_2279(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* srfi-69.scm:302: recursive-hash */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2293(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(99));}}

/* vector-hash in *equal?-hash in k1311 */
static void C_fcall f_2177(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2177,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_block_size(t2);
t7=C_fixnum_plus(t6,t3);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2240,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=t2,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* srfi-69.scm:289: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),t8,C_fix(4),t6);}

/* k2238 in vector-hash in *equal?-hash in k1311 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=C_fixnum_difference(t1,((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2194,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=((C_word)li8),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2194(t6,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],t2);}

/* loop in k2238 in vector-hash in *equal?-hash in k1311 */
static void C_fcall f_2194(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2194,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_fixnum_shift_left(t2,C_fix(4));
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2228,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=C_slot(((C_word*)t0)[4],t3);
t9=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* srfi-69.scm:294: recursive-hash */
t10=((C_word*)((C_word*)t0)[2])[1];
f_2293(t10,t7,t8,t9);}}

/* k2226 in loop in k2238 in vector-hash in *equal?-hash in k1311 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[7],t1);
t3=C_fixnum_plus(((C_word*)t0)[6],t2);
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
/* srfi-69.scm:292: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_2194(t6,((C_word*)t0)[2],t3,t4,t5);}

/* eqv?-hash in k1311 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2115r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2115r(t0,t1,t2,t3);}}

static void C_ccall f_2115r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2119,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2119(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2119(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2117 in eqv?-hash in k1311 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[19]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2153,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_2153(2,t5,t4);}
else{
if(C_truep(C_charp(t4))){
t5=t3;
f_2153(2,t5,C_fix(C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_2153(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_2153(2,t5,C_fix(257));
default:
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_2153(2,t5,C_fix(258));}
else{
if(C_truep(C_eofp(t4))){
t5=t3;
f_2153(2,t5,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t4))){
t5=C_slot(t4,C_fix(1));
t6=t3;
f_2153(2,t6,C_hash_string(t5));}
else{
if(C_truep(C_i_numberp(t4))){
if(C_truep(C_i_flonump(t4))){
t5=C_subbyte(t4,C_fix(7));
t6=C_subbyte(t4,C_fix(6));
t7=C_subbyte(t4,C_fix(5));
t8=C_subbyte(t4,C_fix(4));
t9=C_subbyte(t4,C_fix(3));
t10=C_subbyte(t4,C_fix(2));
t11=C_subbyte(t4,C_fix(1));
t12=C_subbyte(t4,C_fix(0));
t13=C_fixnum_shift_left(t12,C_fix(1));
t14=C_fixnum_plus(t11,t13);
t15=C_fixnum_shift_left(t14,C_fix(1));
t16=C_fixnum_plus(t10,t15);
t17=C_fixnum_shift_left(t16,C_fix(1));
t18=C_fixnum_plus(t9,t17);
t19=C_fixnum_shift_left(t18,C_fix(1));
t20=C_fixnum_plus(t8,t19);
t21=C_fixnum_shift_left(t20,C_fix(1));
t22=C_fixnum_plus(t7,t21);
t23=C_fixnum_shift_left(t22,C_fix(1));
t24=C_fixnum_plus(t6,t23);
t25=C_fixnum_shift_left(t24,C_fix(1));
t26=C_fixnum_plus(t5,t25);
t27=t3;
f_2153(2,t27,C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:144: ##sys#number-hash-hook */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}
else{
if(C_truep(C_blockp(t4))){
/* srfi-69.scm:163: *equal?-hash */
f_2174(t3,t4);}
else{
t5=t3;
f_2153(2,t5,C_fix(262));}}}}}}}}}

/* k2089 in k2117 in eqv?-hash in k1311 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2153(2,t2,C_fix(t1));}

/* k2151 in k2117 in eqv?-hash in k1311 */
static void C_ccall f_2153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}}

/* eq?-hash in k1311 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1841r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1841r(t0,t1,t2,t3);}}

static void C_ccall f_1841r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1845,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1845(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1845(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1843 in eq?-hash in k1311 */
static void C_ccall f_1845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1845,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[17]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1879,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_1879(2,t5,t4);}
else{
if(C_truep(C_charp(t4))){
t5=t3;
f_1879(2,t5,C_fix(C_character_code(t4)));}
else{
switch(t4){
case C_SCHEME_TRUE:
t5=t3;
f_1879(2,t5,C_fix(256));
case C_SCHEME_FALSE:
t5=t3;
f_1879(2,t5,C_fix(257));
default:
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_1879(2,t5,C_fix(258));}
else{
if(C_truep(C_eofp(t4))){
t5=t3;
f_1879(2,t5,C_fix(259));}
else{
if(C_truep(C_i_symbolp(t4))){
t5=C_slot(t4,C_fix(1));
t6=t3;
f_1879(2,t6,C_hash_string(t5));}
else{
if(C_truep(C_blockp(t4))){
/* srfi-69.scm:163: *equal?-hash */
f_2174(t3,t4);}
else{
t5=t3;
f_1879(2,t5,C_fix(262));}}}}}}}}

/* k1877 in k1843 in eq?-hash in k1311 */
static void C_ccall f_1879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}}

/* keyword-hash in k1311 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1687r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1687r(t0,t1,t2,t3);}}

static void C_ccall f_1687r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1691,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1691(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1691(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1689 in keyword-hash in k1311 */
static void C_ccall f_1691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:199: ##sys#check-keyword */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[16]);}

/* k1692 in k1689 in keyword-hash in k1311 */
static void C_ccall f_1694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[16]);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=C_hash_string(t4);
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
if(C_truep(C_fixnum_lessp(t5,C_fix(0)))){
t8=C_fixnum_negate(t5);
t9=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t8);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t6,t9,t7);}
else{
t8=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t5);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t6,t8,t7);}}

/* ##sys#check-keyword in k1311 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1661r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1661r(t0,t1,t2,t3);}}

static void C_ccall f_1661r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1668,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* srfi-69.scm:186: keyword? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t4,t2);}

/* k1666 in ##sys#check-keyword in k1311 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
/* srfi-69.scm:187: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[6]+1)))(6,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[13],C_SCHEME_FALSE,lf[14],((C_word*)t0)[2]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* srfi-69.scm:187: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[6]+1)))(6,*((C_word*)lf[6]+1),((C_word*)t0)[4],lf[13],t2,lf[14],((C_word*)t0)[2]);}}}

/* symbol-hash in k1311 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1588r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1588r(t0,t1,t2,t3);}}

static void C_ccall f_1588r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1592,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1592(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1592(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1590 in symbol-hash in k1311 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=C_i_check_symbol_2(((C_word*)t0)[3],lf[11]);
t3=C_i_check_exact_2(t1,lf[11]);
t4=((C_word*)t0)[3];
t5=C_slot(t4,C_fix(1));
t6=C_hash_string(t5);
t7=((C_word*)t0)[2];
t8=t1;
if(C_truep(C_fixnum_lessp(t6,C_fix(0)))){
t9=C_fixnum_negate(t6);
t10=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t9);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t7,t10,t8);}
else{
t9=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t6);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t7,t9,t8);}}

/* object-uid-hash in k1311 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1524r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1524r(t0,t1,t2,t3);}}

static void C_ccall f_1524r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1528(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1528(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1526 in object-uid-hash in k1311 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1528,2,t0,t1);}
t2=C_i_check_exact_2(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1567,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
/* srfi-69.scm:163: *equal?-hash */
f_2174(t3,t4);}

/* k1565 in k1526 in object-uid-hash in k1311 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}}

/* number-hash in k1311 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1321r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1321r(t0,t1,t2,t3);}}

static void C_ccall f_1321r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1325,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1325(2,t5,C_fix(536870912));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1325(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1323 in number-hash in k1311 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_numberp(((C_word*)t0)[2]))){
t3=t2;
f_1328(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-69.scm:152: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[6]+1)))(6,*((C_word*)lf[6]+1),t2,lf[7],lf[4],lf[8],((C_word*)t0)[2]);}}

/* k1326 in k1323 in number-hash in k1311 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1497,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_fixnump(t4))){
t5=t3;
f_1497(t5,t4);}
else{
if(C_truep(C_i_flonump(t4))){
t5=C_subbyte(t4,C_fix(7));
t6=C_subbyte(t4,C_fix(6));
t7=C_subbyte(t4,C_fix(5));
t8=C_subbyte(t4,C_fix(4));
t9=C_subbyte(t4,C_fix(3));
t10=C_subbyte(t4,C_fix(2));
t11=C_subbyte(t4,C_fix(1));
t12=C_subbyte(t4,C_fix(0));
t13=C_fixnum_shift_left(t12,C_fix(1));
t14=C_fixnum_plus(t11,t13);
t15=C_fixnum_shift_left(t14,C_fix(1));
t16=C_fixnum_plus(t10,t15);
t17=C_fixnum_shift_left(t16,C_fix(1));
t18=C_fixnum_plus(t9,t17);
t19=C_fixnum_shift_left(t18,C_fix(1));
t20=C_fixnum_plus(t8,t19);
t21=C_fixnum_shift_left(t20,C_fix(1));
t22=C_fixnum_plus(t7,t21);
t23=C_fixnum_shift_left(t22,C_fix(1));
t24=C_fixnum_plus(t6,t23);
t25=C_fixnum_shift_left(t24,C_fix(1));
t26=C_fixnum_plus(t5,t25);
t27=t3;
f_1497(t27,C_fixnum_times(C_fix(331804471),t26));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1491,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* srfi-69.scm:144: ##sys#number-hash-hook */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}}}

/* k1489 in k1326 in k1323 in number-hash in k1311 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1497(t2,C_fix(t1));}

/* k1495 in k1326 in k1323 in number-hash in k1311 */
static void C_fcall f_1497(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
if(C_truep(C_fixnum_lessp(t1,C_fix(0)))){
t4=C_fixnum_negate(t1);
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}
else{
t4=t1;
t5=C_fixnum_and(C_fix((C_word)C_MOST_POSITIVE_32_BIT_FIXNUM),t4);
/* srfi-69.scm:116: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[5]+1)))(4,*((C_word*)lf[5]+1),t2,t5,t3);}}

/* ##sys#number-hash-hook in k1311 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1315,3,t0,t1,t2);}
/* srfi-69.scm:140: *equal?-hash */
f_2174(t1,t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[260] = {
{"toplevel:srfi_69_scm",(void*)C_srfi_69_toplevel},
{"f_1313:srfi_69_scm",(void*)f_1313},
{"f_5526:srfi_69_scm",(void*)f_5526},
{"f_5646:srfi_69_scm",(void*)f_5646},
{"f_5530:srfi_69_scm",(void*)f_5530},
{"f_5536:srfi_69_scm",(void*)f_5536},
{"f_5548:srfi_69_scm",(void*)f_5548},
{"f_5605:srfi_69_scm",(void*)f_5605},
{"f_5624:srfi_69_scm",(void*)f_5624},
{"f_5563:srfi_69_scm",(void*)f_5563},
{"f_4500:srfi_69_scm",(void*)f_4500},
{"f_5510:srfi_69_scm",(void*)f_5510},
{"f_5514:srfi_69_scm",(void*)f_5514},
{"f_5517:srfi_69_scm",(void*)f_5517},
{"f_5508:srfi_69_scm",(void*)f_5508},
{"f_5485:srfi_69_scm",(void*)f_5485},
{"f_5492:srfi_69_scm",(void*)f_5492},
{"f_5497:srfi_69_scm",(void*)f_5497},
{"f_5505:srfi_69_scm",(void*)f_5505},
{"f_5473:srfi_69_scm",(void*)f_5473},
{"f_5480:srfi_69_scm",(void*)f_5480},
{"f_5461:srfi_69_scm",(void*)f_5461},
{"f_5468:srfi_69_scm",(void*)f_5468},
{"f_5449:srfi_69_scm",(void*)f_5449},
{"f_5456:srfi_69_scm",(void*)f_5456},
{"f_5383:srfi_69_scm",(void*)f_5383},
{"f_5395:srfi_69_scm",(void*)f_5395},
{"f_5411:srfi_69_scm",(void*)f_5411},
{"f_5439:srfi_69_scm",(void*)f_5439},
{"f_5312:srfi_69_scm",(void*)f_5312},
{"f_5324:srfi_69_scm",(void*)f_5324},
{"f_5347:srfi_69_scm",(void*)f_5347},
{"f_5370:srfi_69_scm",(void*)f_5370},
{"f_5355:srfi_69_scm",(void*)f_5355},
{"f_5334:srfi_69_scm",(void*)f_5334},
{"f_5247:srfi_69_scm",(void*)f_5247},
{"f_5262:srfi_69_scm",(void*)f_5262},
{"f_5278:srfi_69_scm",(void*)f_5278},
{"f_5182:srfi_69_scm",(void*)f_5182},
{"f_5197:srfi_69_scm",(void*)f_5197},
{"f_5213:srfi_69_scm",(void*)f_5213},
{"f_5128:srfi_69_scm",(void*)f_5128},
{"f_5135:srfi_69_scm",(void*)f_5135},
{"f_5140:srfi_69_scm",(void*)f_5140},
{"f_5169:srfi_69_scm",(void*)f_5169},
{"f_5148:srfi_69_scm",(void*)f_5148},
{"f_5161:srfi_69_scm",(void*)f_5161},
{"f_5138:srfi_69_scm",(void*)f_5138},
{"f_5055:srfi_69_scm",(void*)f_5055},
{"f_5070:srfi_69_scm",(void*)f_5070},
{"f_5086:srfi_69_scm",(void*)f_5086},
{"f_5039:srfi_69_scm",(void*)f_5039},
{"f_5053:srfi_69_scm",(void*)f_5053},
{"f_5027:srfi_69_scm",(void*)f_5027},
{"f_4959:srfi_69_scm",(void*)f_4959},
{"f_4971:srfi_69_scm",(void*)f_4971},
{"f_4994:srfi_69_scm",(void*)f_4994},
{"f_5020:srfi_69_scm",(void*)f_5020},
{"f_5007:srfi_69_scm",(void*)f_5007},
{"f_4981:srfi_69_scm",(void*)f_4981},
{"f_4943:srfi_69_scm",(void*)f_4943},
{"f_4950:srfi_69_scm",(void*)f_4950},
{"f_4847:srfi_69_scm",(void*)f_4847},
{"f_4854:srfi_69_scm",(void*)f_4854},
{"f_4868:srfi_69_scm",(void*)f_4868},
{"f_4894:srfi_69_scm",(void*)f_4894},
{"f_4913:srfi_69_scm",(void*)f_4913},
{"f_4881:srfi_69_scm",(void*)f_4881},
{"f_4716:srfi_69_scm",(void*)f_4716},
{"f_4732:srfi_69_scm",(void*)f_4732},
{"f_4799:srfi_69_scm",(void*)f_4799},
{"f_4818:srfi_69_scm",(void*)f_4818},
{"f_4752:srfi_69_scm",(void*)f_4752},
{"f_4608:srfi_69_scm",(void*)f_4608},
{"f_4624:srfi_69_scm",(void*)f_4624},
{"f_4679:srfi_69_scm",(void*)f_4679},
{"f_4692:srfi_69_scm",(void*)f_4692},
{"f_4639:srfi_69_scm",(void*)f_4639},
{"f_4502:srfi_69_scm",(void*)f_4502},
{"f_4518:srfi_69_scm",(void*)f_4518},
{"f_4572:srfi_69_scm",(void*)f_4572},
{"f_4588:srfi_69_scm",(void*)f_4588},
{"f_4533:srfi_69_scm",(void*)f_4533},
{"f_4284:srfi_69_scm",(void*)f_4284},
{"f_4360:srfi_69_scm",(void*)f_4360},
{"f_4316:srfi_69_scm",(void*)f_4316},
{"f_4352:srfi_69_scm",(void*)f_4352},
{"f_4327:srfi_69_scm",(void*)f_4327},
{"f_4333:srfi_69_scm",(void*)f_4333},
{"f_4367:srfi_69_scm",(void*)f_4367},
{"f_4382:srfi_69_scm",(void*)f_4382},
{"f_4448:srfi_69_scm",(void*)f_4448},
{"f_4478:srfi_69_scm",(void*)f_4478},
{"f_4399:srfi_69_scm",(void*)f_4399},
{"f_4388:srfi_69_scm",(void*)f_4388},
{"f_4272:srfi_69_scm",(void*)f_4272},
{"f_4279:srfi_69_scm",(void*)f_4279},
{"f_4044:srfi_69_scm",(void*)f_4044},
{"f_4117:srfi_69_scm",(void*)f_4117},
{"f_4073:srfi_69_scm",(void*)f_4073},
{"f_4109:srfi_69_scm",(void*)f_4109},
{"f_4084:srfi_69_scm",(void*)f_4084},
{"f_4090:srfi_69_scm",(void*)f_4090},
{"f_4124:srfi_69_scm",(void*)f_4124},
{"f_4139:srfi_69_scm",(void*)f_4139},
{"f_4212:srfi_69_scm",(void*)f_4212},
{"f_4245:srfi_69_scm",(void*)f_4245},
{"f_4248:srfi_69_scm",(void*)f_4248},
{"f_4222:srfi_69_scm",(void*)f_4222},
{"f_4153:srfi_69_scm",(void*)f_4153},
{"f_4189:srfi_69_scm",(void*)f_4189},
{"f_4163:srfi_69_scm",(void*)f_4163},
{"f_3730:srfi_69_scm",(void*)f_3730},
{"f_3993:srfi_69_scm",(void*)f_3993},
{"f_3999:srfi_69_scm",(void*)f_3999},
{"f_3976:srfi_69_scm",(void*)f_3976},
{"f_3988:srfi_69_scm",(void*)f_3988},
{"f_3732:srfi_69_scm",(void*)f_3732},
{"f_3739:srfi_69_scm",(void*)f_3739},
{"f_3742:srfi_69_scm",(void*)f_3742},
{"f_3814:srfi_69_scm",(void*)f_3814},
{"f_3770:srfi_69_scm",(void*)f_3770},
{"f_3806:srfi_69_scm",(void*)f_3806},
{"f_3781:srfi_69_scm",(void*)f_3781},
{"f_3787:srfi_69_scm",(void*)f_3787},
{"f_3821:srfi_69_scm",(void*)f_3821},
{"f_3836:srfi_69_scm",(void*)f_3836},
{"f_3913:srfi_69_scm",(void*)f_3913},
{"f_3950:srfi_69_scm",(void*)f_3950},
{"f_3953:srfi_69_scm",(void*)f_3953},
{"f_3941:srfi_69_scm",(void*)f_3941},
{"f_3923:srfi_69_scm",(void*)f_3923},
{"f_3850:srfi_69_scm",(void*)f_3850},
{"f_3890:srfi_69_scm",(void*)f_3890},
{"f_3878:srfi_69_scm",(void*)f_3878},
{"f_3860:srfi_69_scm",(void*)f_3860},
{"f_3721:srfi_69_scm",(void*)f_3721},
{"f_3609:srfi_69_scm",(void*)f_3609},
{"f_3619:srfi_69_scm",(void*)f_3619},
{"f_3624:srfi_69_scm",(void*)f_3624},
{"f_3686:srfi_69_scm",(void*)f_3686},
{"f_3707:srfi_69_scm",(void*)f_3707},
{"f_3680:srfi_69_scm",(void*)f_3680},
{"f_3583:srfi_69_scm",(void*)f_3583},
{"f_3587:srfi_69_scm",(void*)f_3587},
{"f_3590:srfi_69_scm",(void*)f_3590},
{"f_3593:srfi_69_scm",(void*)f_3593},
{"f_3516:srfi_69_scm",(void*)f_3516},
{"f_3539:srfi_69_scm",(void*)f_3539},
{"f_3555:srfi_69_scm",(void*)f_3555},
{"f_3526:srfi_69_scm",(void*)f_3526},
{"f_3596:srfi_69_scm",(void*)f_3596},
{"f_3489:srfi_69_scm",(void*)f_3489},
{"f_3477:srfi_69_scm",(void*)f_3477},
{"f_3468:srfi_69_scm",(void*)f_3468},
{"f_3459:srfi_69_scm",(void*)f_3459},
{"f_3450:srfi_69_scm",(void*)f_3450},
{"f_3441:srfi_69_scm",(void*)f_3441},
{"f_3432:srfi_69_scm",(void*)f_3432},
{"f_3423:srfi_69_scm",(void*)f_3423},
{"f_3414:srfi_69_scm",(void*)f_3414},
{"f_3408:srfi_69_scm",(void*)f_3408},
{"f_3045:srfi_69_scm",(void*)f_3045},
{"f_3398:srfi_69_scm",(void*)f_3398},
{"f_3401:srfi_69_scm",(void*)f_3401},
{"f_3123:srfi_69_scm",(void*)f_3123},
{"f_3378:srfi_69_scm",(void*)f_3378},
{"f_3381:srfi_69_scm",(void*)f_3381},
{"f_3126:srfi_69_scm",(void*)f_3126},
{"f_3346:srfi_69_scm",(void*)f_3346},
{"f_3352:srfi_69_scm",(void*)f_3352},
{"f_3356:srfi_69_scm",(void*)f_3356},
{"f_3129:srfi_69_scm",(void*)f_3129},
{"f_3164:srfi_69_scm",(void*)f_3164},
{"f_3185:srfi_69_scm",(void*)f_3185},
{"f_3191:srfi_69_scm",(void*)f_3191},
{"f_3283:srfi_69_scm",(void*)f_3283},
{"f_3296:srfi_69_scm",(void*)f_3296},
{"f_3290:srfi_69_scm",(void*)f_3290},
{"f_3286:srfi_69_scm",(void*)f_3286},
{"f_3258:srfi_69_scm",(void*)f_3258},
{"f_3271:srfi_69_scm",(void*)f_3271},
{"f_3265:srfi_69_scm",(void*)f_3265},
{"f_3261:srfi_69_scm",(void*)f_3261},
{"f_3248:srfi_69_scm",(void*)f_3248},
{"f_3230:srfi_69_scm",(void*)f_3230},
{"f_3234:srfi_69_scm",(void*)f_3234},
{"f_3217:srfi_69_scm",(void*)f_3217},
{"f_3207:srfi_69_scm",(void*)f_3207},
{"f_3194:srfi_69_scm",(void*)f_3194},
{"f_3175:srfi_69_scm",(void*)f_3175},
{"f_3132:srfi_69_scm",(void*)f_3132},
{"f_3159:srfi_69_scm",(void*)f_3159},
{"f_3135:srfi_69_scm",(void*)f_3135},
{"f_3139:srfi_69_scm",(void*)f_3139},
{"f_3155:srfi_69_scm",(void*)f_3155},
{"f_3047:srfi_69_scm",(void*)f_3047},
{"f_3014:srfi_69_scm",(void*)f_3014},
{"f_3018:srfi_69_scm",(void*)f_3018},
{"f_2984:srfi_69_scm",(void*)f_2984},
{"f_2990:srfi_69_scm",(void*)f_2990},
{"f_2841:srfi_69_scm",(void*)f_2841},
{"f_2922:srfi_69_scm",(void*)f_2922},
{"f_2913:srfi_69_scm",(void*)f_2913},
{"f_2894:srfi_69_scm",(void*)f_2894},
{"f_2898:srfi_69_scm",(void*)f_2898},
{"f_2901:srfi_69_scm",(void*)f_2901},
{"f_2857:srfi_69_scm",(void*)f_2857},
{"f_2700:srfi_69_scm",(void*)f_2700},
{"f_2781:srfi_69_scm",(void*)f_2781},
{"f_2772:srfi_69_scm",(void*)f_2772},
{"f_2753:srfi_69_scm",(void*)f_2753},
{"f_2757:srfi_69_scm",(void*)f_2757},
{"f_2760:srfi_69_scm",(void*)f_2760},
{"f_2716:srfi_69_scm",(void*)f_2716},
{"f_2640:srfi_69_scm",(void*)f_2640},
{"f_2644:srfi_69_scm",(void*)f_2644},
{"f_2678:srfi_69_scm",(void*)f_2678},
{"f_2174:srfi_69_scm",(void*)f_2174},
{"f_2293:srfi_69_scm",(void*)f_2293},
{"f_2628:srfi_69_scm",(void*)f_2628},
{"f_2616:srfi_69_scm",(void*)f_2616},
{"f_2600:srfi_69_scm",(void*)f_2600},
{"f_2549:srfi_69_scm",(void*)f_2549},
{"f_2569:srfi_69_scm",(void*)f_2569},
{"f_2561:srfi_69_scm",(void*)f_2561},
{"f_2523:srfi_69_scm",(void*)f_2523},
{"f_2535:srfi_69_scm",(void*)f_2535},
{"f_2489:srfi_69_scm",(void*)f_2489},
{"f_2242:srfi_69_scm",(void*)f_2242},
{"f_2276:srfi_69_scm",(void*)f_2276},
{"f_2279:srfi_69_scm",(void*)f_2279},
{"f_2177:srfi_69_scm",(void*)f_2177},
{"f_2240:srfi_69_scm",(void*)f_2240},
{"f_2194:srfi_69_scm",(void*)f_2194},
{"f_2228:srfi_69_scm",(void*)f_2228},
{"f_2115:srfi_69_scm",(void*)f_2115},
{"f_2119:srfi_69_scm",(void*)f_2119},
{"f_2091:srfi_69_scm",(void*)f_2091},
{"f_2153:srfi_69_scm",(void*)f_2153},
{"f_1841:srfi_69_scm",(void*)f_1841},
{"f_1845:srfi_69_scm",(void*)f_1845},
{"f_1879:srfi_69_scm",(void*)f_1879},
{"f_1687:srfi_69_scm",(void*)f_1687},
{"f_1691:srfi_69_scm",(void*)f_1691},
{"f_1694:srfi_69_scm",(void*)f_1694},
{"f_1661:srfi_69_scm",(void*)f_1661},
{"f_1668:srfi_69_scm",(void*)f_1668},
{"f_1588:srfi_69_scm",(void*)f_1588},
{"f_1592:srfi_69_scm",(void*)f_1592},
{"f_1524:srfi_69_scm",(void*)f_1524},
{"f_1528:srfi_69_scm",(void*)f_1528},
{"f_1567:srfi_69_scm",(void*)f_1567},
{"f_1321:srfi_69_scm",(void*)f_1321},
{"f_1325:srfi_69_scm",(void*)f_1325},
{"f_1328:srfi_69_scm",(void*)f_1328},
{"f_1491:srfi_69_scm",(void*)f_1491},
{"f_1497:srfi_69_scm",(void*)f_1497},
{"f_1315:srfi_69_scm",(void*)f_1315},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
