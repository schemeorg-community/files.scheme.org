/* Generated from chicken.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file chicken.c
   used units: library eval chicken_syntax chicken_ffi_syntax srfi_1 srfi_4 utils files extras data_structures support compiler optimizer unboxing compiler_syntax scrutinizer driver platform backend srfi_69
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_ffi_syntax_toplevel)
C_externimport void C_ccall C_chicken_ffi_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_4_toplevel)
C_externimport void C_ccall C_srfi_4_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_support_toplevel)
C_externimport void C_ccall C_support_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_toplevel)
C_externimport void C_ccall C_compiler_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_optimizer_toplevel)
C_externimport void C_ccall C_optimizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_unboxing_toplevel)
C_externimport void C_ccall C_unboxing_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_compiler_syntax_toplevel)
C_externimport void C_ccall C_compiler_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scrutinizer_toplevel)
C_externimport void C_ccall C_scrutinizer_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_driver_toplevel)
C_externimport void C_ccall C_driver_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_platform_toplevel)
C_externimport void C_ccall C_platform_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_backend_toplevel)
C_externimport void C_ccall C_backend_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[42];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_93)
static void C_ccall f_93(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_96)
static void C_ccall f_96(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_99)
static void C_ccall f_99(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_102)
static void C_ccall f_102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_105)
static void C_ccall f_105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_108)
static void C_ccall f_108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_111)
static void C_ccall f_111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_114)
static void C_ccall f_114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_117)
static void C_ccall f_117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_120)
static void C_ccall f_120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_123)
static void C_ccall f_123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_126)
static void C_ccall f_126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_129)
static void C_ccall f_129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_132)
static void C_ccall f_132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_135)
static void C_ccall f_135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_138)
static void C_ccall f_138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_141)
static void C_ccall f_141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_144)
static void C_ccall f_144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_147)
static void C_ccall f_147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_150)
static void C_ccall f_150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_505)
static void C_ccall f_505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_493)
static void C_ccall f_493(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_483)
static void C_ccall f_483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_491)
static void C_ccall f_491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_154)
static void C_ccall f_154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_283)
static void C_ccall f_283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_295)
static void C_fcall f_295(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_397)
static void C_ccall f_397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_384)
static void C_ccall f_384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_364)
static void C_ccall f_364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_354)
static void C_ccall f_354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_287)
static void C_ccall f_287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_290)
static void C_ccall f_290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_271)
static void C_ccall f_271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_275)
static void C_ccall f_275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_263)
static void C_ccall f_263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_269)
static void C_ccall f_269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_266)
static void C_ccall f_266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_156)
static void C_ccall f_156(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_162)
static void C_fcall f_162(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_197)
static void C_fcall f_197(C_word t0,C_word t1) C_noret;
C_noret_decl(f_223)
static void C_ccall f_223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_219)
static void C_ccall f_219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_176)
static void C_ccall f_176(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_295)
static void C_fcall trf_295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_295(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_295(t0,t1,t2);}

C_noret_decl(trf_162)
static void C_fcall trf_162(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_162(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_162(t0,t1,t2,t3,t4);}

C_noret_decl(trf_197)
static void C_fcall trf_197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_197(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_197(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(360)){
C_save(t1);
C_rereclaim2(360*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,42);
lf[0]=C_h_intern(&lf[0],27,"\010compilercompiler-arguments");
lf[1]=C_h_intern(&lf[1],29,"\010compilerprocess-command-line");
lf[2]=C_h_intern(&lf[2],7,"reverse");
lf[3]=C_h_intern(&lf[3],14,"string->symbol");
lf[4]=C_h_intern(&lf[4],9,"substring");
lf[5]=C_h_intern(&lf[5],25,"\003sysimplicit-exit-handler");
lf[6]=C_h_intern(&lf[6],17,"user-options-pass");
lf[7]=C_h_intern(&lf[7],4,"exit");
lf[8]=C_h_intern(&lf[8],19,"compile-source-file");
lf[9]=C_h_intern(&lf[9],14,"optimize-level");
lf[10]=C_h_intern(&lf[10],5,"cons*");
lf[11]=C_h_intern(&lf[11],18,"no-compiler-syntax");
lf[12]=C_h_intern(&lf[12],21,"no-usual-integrations");
lf[13]=C_h_intern(&lf[13],22,"optimize-leaf-routines");
lf[14]=C_h_intern(&lf[14],6,"inline");
lf[15]=C_h_intern(&lf[15],13,"inline-global");
lf[16]=C_h_intern(&lf[16],5,"local");
lf[17]=C_h_intern(&lf[17],8,"unboxing");
lf[18]=C_h_intern(&lf[18],6,"unsafe");
lf[19]=C_h_intern(&lf[19],18,"disable-interrupts");
lf[20]=C_h_intern(&lf[20],8,"no-trace");
lf[21]=C_h_intern(&lf[21],5,"block");
lf[22]=C_h_intern(&lf[22],11,"lambda-lift");
lf[23]=C_h_intern(&lf[23],14,"no-lambda-info");
lf[24]=C_h_intern(&lf[24],11,"debug-level");
lf[25]=C_h_intern(&lf[25],10,"scrutinize");
lf[26]=C_h_intern(&lf[26],31,"\010compilervalid-compiler-options");
lf[27]=C_h_intern(&lf[27],45,"\010compilervalid-compiler-options-with-argument");
lf[28]=C_h_intern(&lf[28],4,"quit");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 missing argument to `-~s\047 option");
lf[30]=C_h_intern(&lf[30],7,"warning");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000 invalid compiler option (gnored)");
lf[32]=C_h_intern(&lf[32],4,"conc");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[34]=C_h_intern(&lf[34],6,"append");
lf[35]=C_h_intern(&lf[35],4,"argv");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_h_intern(&lf[37],6,"remove");
lf[38]=C_h_intern(&lf[38],12,"string-split");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],24,"get-environment-variable");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN_OPTIONS");
C_register_lf2(lf,42,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_93,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k91 */
static void C_ccall f_93(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_93,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_96,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k94 in k91 */
static void C_ccall f_96(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_96,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_99,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k97 in k94 in k91 */
static void C_ccall f_99(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_99,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_ffi_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k100 in k97 in k94 in k91 */
static void C_ccall f_102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_105,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_108,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_111,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_114,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_117,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_120,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_123,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_support_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_126,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_129,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_132,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_unboxing_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_135,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_compiler_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_138,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_141,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_driver_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_144,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_platform_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_backend_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_150,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_483,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_493,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_501,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_505,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm:45: get-environment-variable */
t7=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[41]);}

/* k503 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* chicken.scm:45: string-split */
t3=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
/* chicken.scm:45: string-split */
t2=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[39]);}}

/* k499 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:43: remove */
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a492 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_493(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_493,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_equal_p(t2,lf[36]));}

/* k481 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_491,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken.scm:46: argv */
t3=*((C_word*)lf[35]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k489 in k481 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(t1);
/* chicken.scm:42: append */
t3=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_154,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#compiler-arguments ...) */,t1);
t3=C_mutate((C_word*)lf[1]+1 /* (set! ##compiler#process-command-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_156,tmp=(C_word)a,a+=2,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_263,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_271,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_283,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_283(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_283,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_287,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_295,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_295(t9,t5,((C_word*)t4)[1]);}

/* loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_fcall f_295(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_295,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=C_eqp(lf[9],t3);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_317,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t4);
/* chicken.scm:79: string->number */
C_string_to_number(3,0,t6,t7);}
else{
t6=C_eqp(lf[24],t3);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_397,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=C_i_car(t4);
/* chicken.scm:105: string->number */
C_string_to_number(3,0,t7,t8);}
else{
if(C_truep(C_i_memq(t3,*((C_word*)lf[26]+1)))){
/* chicken.scm:111: loop */
t16=t1;
t17=t4;
t1=t16;
t2=t17;
goto loop;}
else{
if(C_truep(C_i_memq(t3,*((C_word*)lf[27]+1)))){
if(C_truep(C_i_pairp(t4))){
t7=C_i_cdr(t4);
/* chicken.scm:114: loop */
t16=t1;
t17=t7;
t1=t16;
t2=t17;
goto loop;}
else{
/* chicken.scm:115: quit */
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[29],t3);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_466,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_stringp(t3))){
/* chicken.scm:117: warning */
t9=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[31],t3);}
else{
/* chicken.scm:119: conc */
t9=*((C_word*)lf[32]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,lf[33],t3);}}}}}}}

/* k471 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:117: warning */
t2=*((C_word*)lf[30]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[31],t1);}

/* k464 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:120: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_295(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k395 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_397,2,t0,t1);}
switch(t1){
case C_fix(0):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:107: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[23],lf[20],((C_word*)((C_word*)t0)[5])[1]);
case C_fix(1):
t2=C_a_i_cons(&a,2,lf[20],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:110: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_295(t5,((C_word*)t0)[2],t4);
default:
t2=C_a_i_cons(&a,2,lf[25],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:110: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_295(t5,((C_word*)t0)[2],t4);}}

/* k412 in k395 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:110: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_317,2,t0,t1);}
switch(t1){
case C_fix(0):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_334,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:83: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[11],lf[12],((C_word*)((C_word*)t0)[5])[1]);
case C_fix(1):
t2=C_a_i_cons(&a,2,lf[13],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_295(t5,((C_word*)t0)[2],t4);
case C_fix(2):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_354,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:88: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[13],lf[14],((C_word*)((C_word*)t0)[5])[1]);
case C_fix(3):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_364,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:91: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[13],lf[14],lf[15],((C_word*)((C_word*)t0)[5])[1]);
case C_fix(4):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:94: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,lf[13],lf[14],lf[16],lf[17],lf[18],((C_word*)((C_word*)t0)[5])[1]);
default:
if(C_truep(C_i_greater_or_equalp(t1,C_fix(5)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken.scm:99: cons* */
t3=*((C_word*)lf[10]+1);
((C_proc12)(void*)(*((C_word*)t3+1)))(12,t3,t2,lf[19],lf[20],lf[18],lf[21],lf[13],lf[22],lf[23],lf[14],lf[17],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_295(t3,((C_word*)t0)[2],t2);}}}

/* k382 in k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k372 in k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k362 in k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k352 in k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k332 in k315 in loop in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken.scm:103: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_295(t4,((C_word*)t0)[2],t3);}

/* k285 in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_290,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t2,*((C_word*)lf[8]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k288 in k285 in a282 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:122: exit */
t2=*((C_word*)lf[7]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a270 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_275,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm:73: user-options-pass */
t3=*((C_word*)lf[6]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k273 in a270 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* g3233 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[0]+1));}
else{
t2=*((C_word*)lf[1]+1);
/* g3233 */
t3=t2;
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[0]+1));}}

/* k261 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_269,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
t4=*((C_word*)lf[5]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k267 in k261 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k264 in k261 in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_156(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_156,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_162,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_162(t6,t1,t2,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_fcall f_162(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_162,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_176,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken.scm:58: reverse */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
t5=C_i_car(t2);
t6=C_i_string_length(t5);
t7=C_i_string_ref(t5,C_fix(0));
t8=C_eqp(C_make_character(45),t7);
t9=(C_truep(t8)?C_i_greaterp(t6,C_fix(1)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_197,a[2]=t6,a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_greaterp(t6,C_fix(1)))){
t11=C_i_string_ref(t5,C_fix(1));
t12=t10;
f_197(t12,C_eqp(C_make_character(58),t11));}
else{
t11=t10;
f_197(t11,C_SCHEME_FALSE);}}
else{
if(C_truep(t4)){
t10=C_i_cdr(t2);
t11=C_a_i_cons(&a,2,t5,t3);
/* chicken.scm:67: loop */
t17=t1;
t18=t10;
t19=t11;
t20=t4;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}
else{
t10=C_i_cdr(t2);
/* chicken.scm:68: loop */
t17=t1;
t18=t10;
t19=t3;
t20=t5;
t1=t17;
t2=t18;
t3=t19;
t4=t20;
goto loop;}}}}

/* k195 in loop in ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_fcall f_197(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_197,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[8]);
/* chicken.scm:64: loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_162(t3,((C_word*)t0)[6],t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=C_i_cdr(((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_219,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_223,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken.scm:65: substring */
t5=*((C_word*)lf[4]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2]);}}

/* k221 in k195 in loop in ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:65: string->symbol */
t2=*((C_word*)lf[3]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k217 in k195 in loop in ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_219,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* chicken.scm:65: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_162(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k174 in loop in ##compiler#process-command-line in k152 in k148 in k145 in k142 in k139 in k136 in k133 in k130 in k127 in k124 in k121 in k118 in k115 in k112 in k109 in k106 in k103 in k100 in k97 in k94 in k91 */
static void C_ccall f_176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken.scm:58: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[53] = {
{"toplevel:chicken_scm",(void*)C_toplevel},
{"f_93:chicken_scm",(void*)f_93},
{"f_96:chicken_scm",(void*)f_96},
{"f_99:chicken_scm",(void*)f_99},
{"f_102:chicken_scm",(void*)f_102},
{"f_105:chicken_scm",(void*)f_105},
{"f_108:chicken_scm",(void*)f_108},
{"f_111:chicken_scm",(void*)f_111},
{"f_114:chicken_scm",(void*)f_114},
{"f_117:chicken_scm",(void*)f_117},
{"f_120:chicken_scm",(void*)f_120},
{"f_123:chicken_scm",(void*)f_123},
{"f_126:chicken_scm",(void*)f_126},
{"f_129:chicken_scm",(void*)f_129},
{"f_132:chicken_scm",(void*)f_132},
{"f_135:chicken_scm",(void*)f_135},
{"f_138:chicken_scm",(void*)f_138},
{"f_141:chicken_scm",(void*)f_141},
{"f_144:chicken_scm",(void*)f_144},
{"f_147:chicken_scm",(void*)f_147},
{"f_150:chicken_scm",(void*)f_150},
{"f_505:chicken_scm",(void*)f_505},
{"f_501:chicken_scm",(void*)f_501},
{"f_493:chicken_scm",(void*)f_493},
{"f_483:chicken_scm",(void*)f_483},
{"f_491:chicken_scm",(void*)f_491},
{"f_154:chicken_scm",(void*)f_154},
{"f_283:chicken_scm",(void*)f_283},
{"f_295:chicken_scm",(void*)f_295},
{"f_473:chicken_scm",(void*)f_473},
{"f_466:chicken_scm",(void*)f_466},
{"f_397:chicken_scm",(void*)f_397},
{"f_414:chicken_scm",(void*)f_414},
{"f_317:chicken_scm",(void*)f_317},
{"f_384:chicken_scm",(void*)f_384},
{"f_374:chicken_scm",(void*)f_374},
{"f_364:chicken_scm",(void*)f_364},
{"f_354:chicken_scm",(void*)f_354},
{"f_334:chicken_scm",(void*)f_334},
{"f_287:chicken_scm",(void*)f_287},
{"f_290:chicken_scm",(void*)f_290},
{"f_271:chicken_scm",(void*)f_271},
{"f_275:chicken_scm",(void*)f_275},
{"f_263:chicken_scm",(void*)f_263},
{"f_269:chicken_scm",(void*)f_269},
{"f_266:chicken_scm",(void*)f_266},
{"f_156:chicken_scm",(void*)f_156},
{"f_162:chicken_scm",(void*)f_162},
{"f_197:chicken_scm",(void*)f_197},
{"f_223:chicken_scm",(void*)f_223},
{"f_219:chicken_scm",(void*)f_219},
{"f_176:chicken_scm",(void*)f_176},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
