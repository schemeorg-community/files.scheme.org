/* Generated from chicken-syntax.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-syntax.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file chicken-syntax.c
   unit: chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[235];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,28),40,97,50,48,53,57,32,102,111,114,109,49,56,55,54,32,114,49,56,55,55,32,99,49,56,55,56,41,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,52),40,97,50,48,54,57,32,105,110,112,117,116,49,56,53,49,49,56,54,52,32,114,101,110,97,109,101,49,56,54,48,49,56,54,53,32,99,111,109,112,97,114,101,49,56,52,56,49,56,54,54,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,52),40,97,50,49,50,53,32,105,110,112,117,116,49,56,49,48,49,56,50,51,32,114,101,110,97,109,101,49,56,49,57,49,56,50,52,32,99,111,109,112,97,114,101,49,56,48,55,49,56,50,53,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,97,50,50,57,49,32,120,49,55,57,56,32,114,49,55,57,57,32,99,49,56,48,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,28),40,97,50,51,49,54,32,102,111,114,109,49,55,57,49,32,114,49,55,57,50,32,99,49,55,57,51,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,28),40,97,50,51,53,51,32,102,111,114,109,49,55,56,48,32,114,49,55,56,49,32,99,49,55,56,50,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,108,111,111,112,32,120,115,49,55,54,48,32,118,97,114,115,49,55,54,49,32,98,115,49,55,54,50,32,118,97,108,115,49,55,54,51,32,114,101,115,116,49,55,54,52,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,28),40,97,50,52,53,52,32,102,111,114,109,49,55,53,51,32,114,49,55,53,52,32,99,49,55,53,53,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,40),40,108,111,111,112,32,120,115,49,55,51,50,32,118,97,114,115,49,55,51,51,32,118,97,108,115,49,55,51,52,32,114,101,115,116,49,55,51,53,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,28),40,97,50,54,55,57,32,102,111,114,109,49,55,50,53,32,114,49,55,50,54,32,99,49,55,50,55,41,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,108,111,116,115,49,54,56,56,32,105,49,54,56,57,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,103,49,54,56,49,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,54,53,32,103,49,54,55,53,49,54,55,57,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,54,51,57,32,103,49,54,52,57,49,54,53,51,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,28),40,97,50,56,55,51,32,102,111,114,109,49,54,50,52,32,114,49,54,50,53,32,99,49,54,50,54,41,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,7),40,103,49,53,56,49,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,53,54,53,32,103,49,53,55,53,49,53,55,57,41,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,20),40,112,97,114,115,101,45,99,108,97,117,115,101,32,99,49,53,52,54,41,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,53,57,56,32,103,49,54,48,56,49,54,49,50,41,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,97,51,52,51,50,32,102,111,114,109,49,53,51,52,32,114,49,53,51,53,32,99,49,53,51,54,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,28),40,97,51,56,52,57,32,102,111,114,109,49,53,50,50,32,114,49,53,50,51,32,99,49,53,50,52,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,28),40,97,52,48,54,48,32,102,111,114,109,49,53,48,50,32,114,49,53,48,51,32,99,49,53,48,52,41,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,105,49,51,57,52,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,15),40,103,101,110,118,97,114,115,32,110,49,51,57,50,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,52,51,48,50,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,30),40,108,111,111,112,49,52,55,52,32,103,49,52,56,52,49,52,56,57,32,103,49,52,56,53,49,52,57,48,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,27),40,98,117,105,108,100,32,118,97,114,115,50,49,52,53,51,32,118,114,101,115,116,49,52,53,52,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,27),40,97,52,51,49,50,32,118,97,114,115,49,49,52,52,57,32,118,97,114,115,50,49,52,53,48,41,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,34),40,97,52,50,55,48,32,118,97,114,115,49,52,51,54,32,97,114,103,99,49,52,51,55,32,114,101,115,116,49,52,51,56,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,97,52,50,54,48,32,99,49,52,51,52,32,98,111,100,121,49,52,51,53,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,34),40,97,52,54,51,53,32,118,97,114,115,49,52,49,56,32,97,114,103,99,49,52,49,57,32,114,101,115,116,49,52,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,57,57,32,103,49,52,48,57,49,52,49,51,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,28),40,97,52,49,53,56,32,102,111,114,109,49,51,56,56,32,114,49,51,56,57,32,99,49,51,57,48,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,27),40,108,111,111,112,32,97,114,103,115,49,51,55,48,32,118,97,114,100,101,102,115,49,51,55,49,41,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,28),40,97,52,54,57,55,32,102,111,114,109,49,51,53,54,32,114,49,51,53,55,32,99,49,51,53,56,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,28),40,97,53,48,48,53,32,102,111,114,109,49,51,52,50,32,114,49,51,52,51,32,99,49,51,52,52,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,48),40,114,101,99,117,114,32,118,97,114,115,49,50,49,53,32,100,101,102,97,117,108,116,101,114,115,49,50,49,54,32,110,111,110,45,100,101,102,97,117,108,116,115,49,50,49,55,41};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,61),40,109,97,107,101,45,105,102,45,116,114,101,101,32,118,97,114,115,49,50,48,57,32,100,101,102,97,117,108,116,101,114,115,49,50,49,48,32,98,111,100,121,45,112,114,111,99,49,50,49,49,32,114,101,115,116,49,50,49,50,41,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,31),40,112,114,101,102,105,120,45,115,121,109,32,112,114,101,102,105,120,49,50,53,49,32,115,121,109,49,50,53,50,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,58),40,114,101,99,117,114,32,118,97,114,115,49,50,48,48,32,100,101,102,97,117,108,116,101,114,45,110,97,109,101,115,49,50,48,49,32,100,101,102,115,49,50,48,50,32,110,101,120,116,45,103,117,121,49,50,48,51,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,103,49,51,50,51,32,118,97,114,49,51,50,53,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,48,55,32,103,49,51,49,55,49,51,50,49,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,56,49,32,103,49,50,57,49,49,50,57,53,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,13),40,103,49,50,55,50,32,118,49,50,55,52,41,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,53,54,32,103,49,50,54,54,49,50,55,48,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,50,57,32,103,49,50,51,57,49,50,52,51,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,28),40,97,53,50,50,51,32,102,111,114,109,49,49,56,54,32,114,49,49,56,55,32,99,49,49,56,56,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,103,49,49,55,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,49,53,53,32,103,49,49,54,53,49,49,54,57,41,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,30),40,101,120,112,97,110,100,32,99,108,97,117,115,101,115,49,49,51,52,32,101,108,115,101,63,49,49,51,53,41,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,28),40,97,53,56,48,55,32,102,111,114,109,49,49,50,50,32,114,49,49,50,51,32,99,49,49,50,52,41,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,13),40,102,111,108,100,32,98,115,49,49,48,49,41,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,28),40,97,54,48,50,50,32,102,111,114,109,49,48,57,53,32,114,49,48,57,54,32,99,49,48,57,55,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,28),40,113,117,111,116,105,102,121,45,112,114,111,99,32,120,115,49,48,55,55,32,105,100,49,48,55,56,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,28),40,97,54,49,55,53,32,102,111,114,109,49,48,55,51,32,114,49,48,55,52,32,99,49,48,55,53,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,28),40,97,54,50,57,53,32,102,111,114,109,49,48,54,53,32,114,49,48,54,54,32,99,49,48,54,55,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,8),40,108,111,111,107,117,112,41};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,103,49,48,52,57,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,51,51,32,103,49,48,52,51,49,48,52,55,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,49,48,32,103,49,48,50,48,49,48,50,52,41,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,14),40,103,49,48,48,50,32,118,98,49,48,48,52,41,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,57,56,54,32,103,57,57,54,49,48,48,48,41,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,54,50,32,103,57,55,50,57,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,11),40,103,57,52,57,32,118,57,53,49,41,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,51,51,32,103,57,52,51,57,52,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,48,56,32,103,57,49,56,57,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,25),40,97,54,51,55,53,32,102,111,114,109,57,48,48,32,114,57,48,49,32,99,57,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,19),40,102,111,108,100,32,118,98,105,110,100,105,110,103,115,56,57,49,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,25),40,97,54,55,52,48,32,102,111,114,109,56,56,52,32,114,56,56,53,32,99,56,56,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,20),40,97,112,112,101,110,100,42,32,105,108,55,51,55,32,108,55,51,56,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,19),40,109,97,112,42,32,112,114,111,99,55,51,57,32,108,55,52,48,41,0,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,13),40,108,111,111,107,117,112,32,118,56,48,52,41,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,11),40,103,56,52,51,32,118,56,52,53,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,50,55,32,103,56,51,55,56,52,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,35),40,102,111,108,100,32,108,108,105,115,116,115,56,49,54,32,101,120,112,115,56,49,55,32,108,108,105,115,116,115,50,56,49,56,41,0,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,56,53,57,32,103,56,54,57,56,55,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,56,48,55,32,97,99,99,56,48,56,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,103,55,57,55,32,118,55,57,57,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,56,49,32,103,55,57,49,55,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,108,105,115,116,115,55,55,48,32,97,99,99,55,55,49,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,52,55,32,103,55,53,55,55,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,25),40,97,54,56,48,57,32,102,111,114,109,55,51,48,32,114,55,51,49,32,99,55,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,18),40,97,55,51,53,50,32,103,55,50,48,55,50,49,55,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,97,55,51,50,56,32,102,111,114,109,55,48,57,32,114,55,49,48,32,99,55,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,54,55,57,32,103,54,56,57,54,57,52,32,103,54,57,48,54,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,53,51,32,103,54,54,51,54,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,25),40,97,55,51,55,48,32,102,111,114,109,54,51,54,32,114,54,51,55,32,99,54,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,25),40,97,55,53,57,53,32,102,111,114,109,54,50,57,32,114,54,51,48,32,99,54,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,25),40,97,55,54,52,48,32,102,111,114,109,54,50,50,32,114,54,50,51,32,99,54,50,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,53,57,50,32,103,54,48,50,54,48,55,32,103,54,48,51,54,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,53,54,54,32,103,53,55,54,53,56,49,32,103,53,55,55,53,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,53,52,48,32,103,53,53,48,53,53,53,32,103,53,53,49,53,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,6),40,103,53,50,57,41,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,49,51,32,103,53,50,51,53,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,6),40,103,53,48,52,41,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,52,56,56,32,103,52,57,56,53,48,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,52,54,52,32,103,52,55,52,52,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,52,52,48,32,103,52,53,48,52,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,25),40,97,55,54,55,55,32,102,111,114,109,52,51,49,32,114,52,51,50,32,99,52,51,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,115,115,52,49,50,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,25),40,97,56,49,53,55,32,102,111,114,109,51,57,55,32,114,51,57,56,32,99,51,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,54,55,32,103,51,55,55,51,56,50,32,103,51,55,56,51,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,51,54,32,103,51,52,54,51,53,49,32,103,51,52,55,51,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,51,48,53,32,103,51,49,53,51,50,48,32,103,51,49,54,51,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,50,55,52,32,103,50,56,52,50,56,57,32,103,50,56,53,50,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,50,52,53,32,103,50,53,53,50,54,48,32,103,50,53,54,50,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,50,55,48,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,49,57,54,32,103,50,48,54,50,49,49,32,103,50,48,55,50,49,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,50,50,32,103,50,51,50,50,51,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,6),40,103,49,56,53,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,54,57,32,103,49,55,57,49,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,6),40,103,49,54,48,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,52,52,32,103,49,53,52,49,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,50,48,32,103,49,51,48,49,51,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,25),40,97,56,50,55,53,32,102,111,114,109,49,49,50,32,114,49,49,51,32,99,49,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,23),40,97,56,57,53,53,32,102,111,114,109,57,56,32,114,57,57,32,99,49,48,48,41,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,22),40,97,57,48,56,54,32,102,111,114,109,56,51,32,114,56,52,32,99,56,53,41,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,22),40,97,57,49,56,56,32,102,111,114,109,55,53,32,114,55,54,32,99,55,55,41,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,22),40,97,57,50,48,57,32,102,111,114,109,54,57,32,114,55,48,32,99,55,49,41,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,22),40,97,57,50,50,55,32,102,111,114,109,54,50,32,114,54,51,32,99,54,52,41,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,22),40,97,57,51,50,48,32,102,111,114,109,52,49,32,114,52,50,32,99,52,51,41,0,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,22),40,109,97,112,115,108,111,116,115,32,115,108,111,116,115,50,53,32,105,50,54,41,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,19),40,97,57,52,53,55,32,120,49,50,32,114,49,51,32,99,49,52,41,0,0,0,0,0};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,19),40,97,57,56,57,53,32,102,111,114,109,53,32,114,54,32,99,55,41,0,0,0,0,0};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_chicken_syntax_toplevel)
C_externexport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9900)
static void C_ccall f_9900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9907)
static void C_ccall f_9907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9894)
static void C_ccall f_9894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9458)
static void C_ccall f_9458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9462)
static void C_ccall f_9462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9471)
static void C_ccall f_9471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9477)
static void C_ccall f_9477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9480)
static void C_ccall f_9480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9890)
static void C_ccall f_9890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9850)
static void C_ccall f_9850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9882)
static void C_ccall f_9882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9842)
static void C_ccall f_9842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9798)
static void C_ccall f_9798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9509)
static void C_fcall f_9509(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9519)
static void C_ccall f_9519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9786)
static void C_ccall f_9786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9522)
static void C_ccall f_9522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9782)
static void C_ccall f_9782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9525)
static void C_ccall f_9525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9572)
static void C_fcall f_9572(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9536)
static void C_ccall f_9536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9507)
static void C_ccall f_9507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9503)
static void C_ccall f_9503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9456)
static void C_ccall f_9456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9321)
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9325)
static void C_ccall f_9325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9376)
static void C_fcall f_9376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9430)
static void C_ccall f_9430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9391)
static void C_ccall f_9391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9354)
static void C_ccall f_9354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9319)
static void C_ccall f_9319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9228)
static void C_ccall f_9228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9311)
static void C_ccall f_9311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9226)
static void C_ccall f_9226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9210)
static void C_ccall f_9210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9208)
static void C_ccall f_9208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9189)
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9087)
static void C_ccall f_9087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9091)
static void C_ccall f_9091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9097)
static void C_ccall f_9097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9141)
static void C_ccall f_9141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_ccall f_1955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_ccall f_8956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8960)
static void C_ccall f_8960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8972)
static void C_ccall f_8972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8276)
static void C_ccall f_8276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8280)
static void C_ccall f_8280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8917)
static void C_fcall f_8917(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8946)
static void C_ccall f_8946(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8873)
static void C_fcall f_8873(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8911)
static void C_ccall f_8911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8900)
static void C_fcall f_8900(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8908)
static void C_ccall f_8908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8292)
static void C_ccall f_8292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8829)
static void C_fcall f_8829(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8867)
static void C_ccall f_8867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8856)
static void C_fcall f_8856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8295)
static void C_ccall f_8295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_fcall f_8794(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8823)
static void C_ccall f_8823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8743)
static void C_ccall f_8743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8745)
static void C_fcall f_8745(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8778)
static void C_ccall f_8778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8758)
static void C_fcall f_8758(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8654)
static void C_ccall f_8654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8721)
static void C_fcall f_8721(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8735)
static void C_ccall f_8735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8666)
static void C_ccall f_8666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8668)
static void C_fcall f_8668(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8701)
static void C_ccall f_8701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8681)
static void C_fcall f_8681(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8662)
static void C_ccall f_8662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8658)
static void C_ccall f_8658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8590)
static void C_fcall f_8590(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8603)
static void C_fcall f_8603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8510)
static void C_ccall f_8510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8528)
static void C_fcall f_8528(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8541)
static void C_fcall f_8541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8518)
static void C_ccall f_8518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8514)
static void C_ccall f_8514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8506)
static void C_ccall f_8506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8498)
static void C_ccall f_8498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8430)
static void C_fcall f_8430(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8443)
static void C_fcall f_8443(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8350)
static void C_ccall f_8350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8368)
static void C_fcall f_8368(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8381)
static void C_fcall f_8381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8354)
static void C_ccall f_8354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8346)
static void C_ccall f_8346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8274)
static void C_ccall f_8274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1961)
static void C_ccall f_1961(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8158)
static void C_ccall f_8158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8162)
static void C_ccall f_8162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8266)
static void C_ccall f_8266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8171)
static void C_ccall f_8171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8174)
static void C_ccall f_8174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8177)
static void C_ccall f_8177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8217)
static void C_fcall f_8217(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8240)
static void C_ccall f_8240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8247)
static void C_ccall f_8247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8254)
static void C_ccall f_8254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8230)
static void C_ccall f_8230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8180)
static void C_ccall f_8180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7678)
static void C_ccall f_7678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7682)
static void C_ccall f_7682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7691)
static void C_ccall f_7691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8119)
static void C_fcall f_8119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8148)
static void C_ccall f_8148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7694)
static void C_ccall f_7694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8084)
static void C_fcall f_8084(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7697)
static void C_ccall f_7697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8040)
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8078)
static void C_ccall f_8078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_fcall f_8067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8075)
static void C_ccall f_8075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7700)
static void C_ccall f_7700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7996)
static void C_fcall f_7996(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_fcall f_8023(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8031)
static void C_ccall f_8031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7947)
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7980)
static void C_ccall f_7980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_fcall f_7960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7892)
static void C_ccall f_7892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7898)
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7931)
static void C_ccall f_7931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7911)
static void C_fcall f_7911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7896)
static void C_ccall f_7896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7714)
static void C_ccall f_7714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7788)
static void C_fcall f_7788(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7801)
static void C_fcall f_7801(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7786)
static void C_ccall f_7786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7782)
static void C_ccall f_7782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7762)
static void C_ccall f_7762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7676)
static void C_ccall f_7676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1967)
static void C_ccall f_1967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7641)
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7639)
static void C_ccall f_7639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7596)
static void C_ccall f_7596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7600)
static void C_ccall f_7600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7631)
static void C_ccall f_7631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7594)
static void C_ccall f_7594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7371)
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7553)
static void C_fcall f_7553(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7582)
static void C_ccall f_7582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7450)
static void C_ccall f_7450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7483)
static void C_fcall f_7483(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7496)
static void C_fcall f_7496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7481)
static void C_ccall f_7481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7477)
static void C_ccall f_7477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7369)
static void C_ccall f_7369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7329)
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7333)
static void C_ccall f_7333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7353)
static void C_ccall f_7353(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7361)
static void C_ccall f_7361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7336)
static void C_ccall f_7336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7347)
static void C_ccall f_7347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6810)
static void C_ccall f_6810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6814)
static void C_ccall f_6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7290)
static void C_fcall f_7290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6895)
static void C_ccall f_6895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7250)
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7263)
static void C_ccall f_7263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6898)
static void C_ccall f_6898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7202)
static void C_fcall f_7202(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7244)
static void C_ccall f_7244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7229)
static void C_fcall f_7229(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7241)
static void C_ccall f_7241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7237)
static void C_ccall f_7237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6901)
static void C_ccall f_6901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7156)
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7189)
static void C_ccall f_7189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7196)
static void C_ccall f_7196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6913)
static void C_ccall f_6913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7116)
static void C_fcall f_7116(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6920)
static void C_ccall f_6920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6922)
static void C_fcall f_6922(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7110)
static void C_ccall f_7110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6994)
static void C_fcall f_6994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7076)
static void C_ccall f_7076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7033)
static void C_ccall f_7033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7013)
static void C_ccall f_7013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6946)
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6984)
static void C_ccall f_6984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6973)
static void C_fcall f_6973(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6940)
static void C_ccall f_6940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6944)
static void C_ccall f_6944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6902)
static void C_ccall f_6902(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6853)
static void C_fcall f_6853(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6876)
static void C_ccall f_6876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6880)
static void C_ccall f_6880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6822)
static void C_fcall f_6822(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6843)
static void C_ccall f_6843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6808)
static void C_ccall f_6808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6745)
static void C_ccall f_6745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6759)
static void C_fcall f_6759(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6796)
static void C_ccall f_6796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6777)
static void C_ccall f_6777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6739)
static void C_ccall f_6739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6376)
static void C_ccall f_6376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6380)
static void C_ccall f_6380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6697)
static void C_fcall f_6697(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6695)
static void C_ccall f_6695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6389)
static void C_ccall f_6389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6645)
static void C_fcall f_6645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6687)
static void C_ccall f_6687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6672)
static void C_fcall f_6672(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6684)
static void C_ccall f_6684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6680)
static void C_ccall f_6680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6392)
static void C_ccall f_6392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6605)
static void C_fcall f_6605(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6412)
static void C_ccall f_6412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6426)
static void C_fcall f_6426(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6599)
static void C_ccall f_6599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6453)
static void C_fcall f_6453(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6551)
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6481)
static void C_ccall f_6481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6495)
static void C_fcall f_6495(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6522)
static C_word C_fcall f_6522(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6485)
static void C_ccall f_6485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6420)
static void C_ccall f_6420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6424)
static void C_ccall f_6424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static C_word C_fcall f_6393(C_word t0,C_word t1);
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6370)
static void C_ccall f_6370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6300)
static void C_ccall f_6300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6303)
static void C_ccall f_6303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6338)
static void C_ccall f_6338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6294)
static void C_ccall f_6294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1991)
static void C_ccall f_1991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6282)
static void C_ccall f_6282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6278)
static void C_ccall f_6278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6179)
static void C_fcall f_6179(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6183)
static void C_ccall f_6183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6192)
static void C_fcall f_6192(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_ccall f_6224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6220)
static void C_ccall f_6220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6204)
static void C_fcall f_6204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6195)
static void C_ccall f_6195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6023)
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6038)
static void C_fcall f_6038(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6108)
static void C_ccall f_6108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6052)
static void C_ccall f_6052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6021)
static void C_ccall f_6021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1997)
static void C_ccall f_1997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5824)
static void C_ccall f_5824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5873)
static void C_ccall f_5873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5879)
static void C_ccall f_5879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5955)
static void C_fcall f_5955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5982)
static C_word C_fcall f_5982(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5945)
static void C_ccall f_5945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5937)
static void C_ccall f_5937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5933)
static void C_ccall f_5933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5906)
static void C_ccall f_5906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5902)
static void C_ccall f_5902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5882)
static void C_ccall f_5882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5846)
static void C_ccall f_5846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5806)
static void C_ccall f_5806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5798)
static void C_ccall f_5798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5749)
static void C_fcall f_5749(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5778)
static void C_ccall f_5778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5705)
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5732)
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5740)
static void C_ccall f_5740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5670)
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5699)
static void C_ccall f_5699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5562)
static void C_ccall f_5562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5664)
static void C_ccall f_5664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5653)
static void C_fcall f_5653(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5661)
static void C_ccall f_5661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5571)
static void C_ccall f_5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_ccall f_5255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_fcall f_5257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5278)
static void C_ccall f_5278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_ccall f_5574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5544)
static void C_fcall f_5544(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5556)
static void C_ccall f_5556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_fcall f_5336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5342)
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5502)
static void C_ccall f_5502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5466)
static void C_ccall f_5466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5416)
static void C_ccall f_5416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5222)
static void C_ccall f_5222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2003)
static void C_ccall f_2003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5210)
static void C_ccall f_5210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_ccall f_5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5006)
static void C_ccall f_5006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5051)
static void C_ccall f_5051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5111)
static void C_ccall f_5111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4714)
static void C_ccall f_4714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_fcall f_4744(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_ccall f_4853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4696)
static void C_ccall f_4696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4684)
static void C_ccall f_4684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4680)
static void C_ccall f_4680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_ccall f_4676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4200)
static void C_ccall f_4200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4636)
static void C_ccall f_4636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4640)
static void C_ccall f_4640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4593)
static void C_ccall f_4593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4218)
static void C_ccall f_4218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4221)
static void C_ccall f_4221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4224)
static void C_ccall f_4224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4261)
static void C_ccall f_4261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4275)
static void C_ccall f_4275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_fcall f_4289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4313)
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4389)
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4537)
static void C_ccall f_4537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4457)
static void C_ccall f_4457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_ccall f_4446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4317)
static void C_ccall f_4317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4340)
static void C_fcall f_4340(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_fcall f_4353(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4334)
static void C_ccall f_4334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_ccall f_4303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4311)
static void C_ccall f_4311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4297)
static void C_ccall f_4297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4171)
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4189)
static void C_ccall f_4189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4157)
static void C_ccall f_4157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4061)
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_ccall f_4126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4059)
static void C_ccall f_4059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_ccall f_2015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3854)
static void C_ccall f_3854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3857)
static void C_ccall f_3857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3871)
static void C_ccall f_3871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_ccall f_3991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3840)
static void C_ccall f_3840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3433)
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3443)
static void C_ccall f_3443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3446)
static void C_ccall f_3446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3449)
static void C_ccall f_3449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3661)
static void C_ccall f_3661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3701)
static void C_ccall f_3701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3735)
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3764)
static void C_ccall f_3764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3454)
static void C_fcall f_3454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3578)
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3605)
static C_word C_fcall f_3605(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3572)
static void C_ccall f_3572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3564)
static void C_ccall f_3564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3545)
static void C_ccall f_3545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3515)
static void C_ccall f_3515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3496)
static void C_ccall f_3496(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2021)
static void C_ccall f_2021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2896)
static void C_ccall f_2896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2902)
static void C_ccall f_2902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2905)
static void C_ccall f_2905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3382)
static void C_fcall f_3382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3362)
static C_word C_fcall f_3362(C_word t0,C_word t1);
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3329)
static void C_ccall f_3329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2937)
static void C_fcall f_2937(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3251)
static void C_ccall f_3251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_fcall f_2956(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_fcall f_2962(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_fcall f_3060(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3029)
static void C_ccall f_3029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2977)
static void C_fcall f_2977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2985)
static void C_ccall f_2985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2981)
static void C_ccall f_2981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2931)
static void C_ccall f_2931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2864)
static void C_ccall f_2864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2687)
static void C_ccall f_2687(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_fcall f_2699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2784)
static void C_ccall f_2784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2718)
static void C_ccall f_2718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2678)
static void C_ccall f_2678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2670)
static void C_ccall f_2670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2459)
static void C_ccall f_2459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2593)
static void C_ccall f_2593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2627)
static void C_ccall f_2627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2615)
static void C_ccall f_2615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2484)
static void C_ccall f_2484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_ccall f_2487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2583)
static void C_ccall f_2583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2548)
static void C_ccall f_2548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2358)
static void C_ccall f_2358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2441)
static void C_ccall f_2441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_ccall f_2344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2296)
static void C_ccall f_2296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2039)
static void C_ccall f_2039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2136)
static void C_fcall f_2136(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_ccall f_2160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2210)
static void C_fcall f_2210(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2124)
static void C_ccall f_2124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2070)
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2109)
static void C_ccall f_2109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2080)
static void C_ccall f_2080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2093)
static void C_ccall f_2093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2068)
static void C_ccall f_2068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2058)
static void C_ccall f_2058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2048)
static void C_ccall f_2048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_9509)
static void C_fcall trf_9509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9509(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_9509(t0,t1,t2,t3);}

C_noret_decl(trf_9572)
static void C_fcall trf_9572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9572(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9572(t0,t1);}

C_noret_decl(trf_9376)
static void C_fcall trf_9376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9376(t0,t1);}

C_noret_decl(trf_8917)
static void C_fcall trf_8917(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8917(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8917(t0,t1,t2);}

C_noret_decl(trf_8873)
static void C_fcall trf_8873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8873(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8873(t0,t1,t2);}

C_noret_decl(trf_8900)
static void C_fcall trf_8900(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8900(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8900(t0,t1);}

C_noret_decl(trf_8829)
static void C_fcall trf_8829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8829(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8829(t0,t1,t2);}

C_noret_decl(trf_8856)
static void C_fcall trf_8856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8856(t0,t1);}

C_noret_decl(trf_8794)
static void C_fcall trf_8794(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8794(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8794(t0,t1,t2);}

C_noret_decl(trf_8745)
static void C_fcall trf_8745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8745(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8745(t0,t1,t2,t3);}

C_noret_decl(trf_8758)
static void C_fcall trf_8758(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8758(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8758(t0,t1);}

C_noret_decl(trf_8721)
static void C_fcall trf_8721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8721(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8721(t0,t1,t2);}

C_noret_decl(trf_8668)
static void C_fcall trf_8668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8668(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8668(t0,t1,t2,t3);}

C_noret_decl(trf_8681)
static void C_fcall trf_8681(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8681(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8681(t0,t1);}

C_noret_decl(trf_8590)
static void C_fcall trf_8590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8590(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8590(t0,t1,t2,t3);}

C_noret_decl(trf_8603)
static void C_fcall trf_8603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8603(t0,t1);}

C_noret_decl(trf_8528)
static void C_fcall trf_8528(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8528(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8528(t0,t1,t2,t3);}

C_noret_decl(trf_8541)
static void C_fcall trf_8541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8541(t0,t1);}

C_noret_decl(trf_8430)
static void C_fcall trf_8430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8430(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8430(t0,t1,t2,t3);}

C_noret_decl(trf_8443)
static void C_fcall trf_8443(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8443(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8443(t0,t1);}

C_noret_decl(trf_8368)
static void C_fcall trf_8368(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8368(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8368(t0,t1,t2,t3);}

C_noret_decl(trf_8381)
static void C_fcall trf_8381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8381(t0,t1);}

C_noret_decl(trf_8217)
static void C_fcall trf_8217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8217(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8217(t0,t1,t2);}

C_noret_decl(trf_8119)
static void C_fcall trf_8119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8119(t0,t1,t2);}

C_noret_decl(trf_8084)
static void C_fcall trf_8084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8084(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8084(t0,t1,t2);}

C_noret_decl(trf_8040)
static void C_fcall trf_8040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8040(t0,t1,t2);}

C_noret_decl(trf_8067)
static void C_fcall trf_8067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8067(t0,t1);}

C_noret_decl(trf_7996)
static void C_fcall trf_7996(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7996(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7996(t0,t1,t2);}

C_noret_decl(trf_8023)
static void C_fcall trf_8023(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8023(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8023(t0,t1);}

C_noret_decl(trf_7947)
static void C_fcall trf_7947(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7947(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7947(t0,t1,t2,t3);}

C_noret_decl(trf_7960)
static void C_fcall trf_7960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7960(t0,t1);}

C_noret_decl(trf_7898)
static void C_fcall trf_7898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7898(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7898(t0,t1,t2,t3);}

C_noret_decl(trf_7911)
static void C_fcall trf_7911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7911(t0,t1);}

C_noret_decl(trf_7788)
static void C_fcall trf_7788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7788(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7788(t0,t1,t2,t3);}

C_noret_decl(trf_7801)
static void C_fcall trf_7801(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7801(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7801(t0,t1);}

C_noret_decl(trf_7553)
static void C_fcall trf_7553(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7553(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7553(t0,t1,t2);}

C_noret_decl(trf_7483)
static void C_fcall trf_7483(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7483(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7483(t0,t1,t2,t3);}

C_noret_decl(trf_7496)
static void C_fcall trf_7496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7496(t0,t1);}

C_noret_decl(trf_7290)
static void C_fcall trf_7290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7290(t0,t1,t2);}

C_noret_decl(trf_7250)
static void C_fcall trf_7250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7250(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7250(t0,t1,t2,t3);}

C_noret_decl(trf_7202)
static void C_fcall trf_7202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7202(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7202(t0,t1,t2);}

C_noret_decl(trf_7229)
static void C_fcall trf_7229(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7229(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7229(t0,t1,t2);}

C_noret_decl(trf_7156)
static void C_fcall trf_7156(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7156(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7156(t0,t1,t2,t3);}

C_noret_decl(trf_7116)
static void C_fcall trf_7116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7116(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7116(t0,t1,t2);}

C_noret_decl(trf_6922)
static void C_fcall trf_6922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6922(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6922(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6994)
static void C_fcall trf_6994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6994(t0,t1);}

C_noret_decl(trf_6946)
static void C_fcall trf_6946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6946(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6946(t0,t1,t2);}

C_noret_decl(trf_6973)
static void C_fcall trf_6973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6973(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6973(t0,t1,t2);}

C_noret_decl(trf_6853)
static void C_fcall trf_6853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6853(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6853(t0,t1,t2,t3);}

C_noret_decl(trf_6822)
static void C_fcall trf_6822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6822(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6822(t0,t1,t2,t3);}

C_noret_decl(trf_6759)
static void C_fcall trf_6759(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6759(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6759(t0,t1,t2);}

C_noret_decl(trf_6697)
static void C_fcall trf_6697(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6697(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6697(t0,t1,t2);}

C_noret_decl(trf_6645)
static void C_fcall trf_6645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6645(t0,t1,t2);}

C_noret_decl(trf_6672)
static void C_fcall trf_6672(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6672(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6672(t0,t1,t2);}

C_noret_decl(trf_6605)
static void C_fcall trf_6605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6605(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6605(t0,t1,t2);}

C_noret_decl(trf_6426)
static void C_fcall trf_6426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6426(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6426(t0,t1,t2);}

C_noret_decl(trf_6453)
static void C_fcall trf_6453(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6453(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6453(t0,t1,t2);}

C_noret_decl(trf_6551)
static void C_fcall trf_6551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6551(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6551(t0,t1,t2);}

C_noret_decl(trf_6495)
static void C_fcall trf_6495(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6495(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6495(t0,t1,t2);}

C_noret_decl(trf_6179)
static void C_fcall trf_6179(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6179(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6179(t0,t1,t2,t3);}

C_noret_decl(trf_6192)
static void C_fcall trf_6192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6192(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6192(t0,t1);}

C_noret_decl(trf_6204)
static void C_fcall trf_6204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6204(t0,t1);}

C_noret_decl(trf_6038)
static void C_fcall trf_6038(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6038(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6038(t0,t1,t2);}

C_noret_decl(trf_5848)
static void C_fcall trf_5848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5848(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5848(t0,t1,t2,t3);}

C_noret_decl(trf_5955)
static void C_fcall trf_5955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5955(t0,t1,t2);}

C_noret_decl(trf_5749)
static void C_fcall trf_5749(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5749(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5749(t0,t1,t2);}

C_noret_decl(trf_5705)
static void C_fcall trf_5705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5705(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5705(t0,t1,t2);}

C_noret_decl(trf_5732)
static void C_fcall trf_5732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5732(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5732(t0,t1,t2);}

C_noret_decl(trf_5670)
static void C_fcall trf_5670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5670(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5670(t0,t1,t2);}

C_noret_decl(trf_5626)
static void C_fcall trf_5626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5626(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5626(t0,t1,t2);}

C_noret_decl(trf_5653)
static void C_fcall trf_5653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5653(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5653(t0,t1,t2);}

C_noret_decl(trf_5257)
static void C_fcall trf_5257(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5257(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5257(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5544)
static void C_fcall trf_5544(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5544(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5544(t0,t1,t2);}

C_noret_decl(trf_5336)
static void C_fcall trf_5336(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5336(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_5336(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5342)
static void C_fcall trf_5342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5342(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_5342(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4744)
static void C_fcall trf_4744(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4744(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4744(t0,t1,t2,t3);}

C_noret_decl(trf_4599)
static void C_fcall trf_4599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4599(t0,t1,t2);}

C_noret_decl(trf_4289)
static void C_fcall trf_4289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4289(t0,t1);}

C_noret_decl(trf_4389)
static void C_fcall trf_4389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4389(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4389(t0,t1,t2,t3);}

C_noret_decl(trf_4340)
static void C_fcall trf_4340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4340(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4340(t0,t1,t2,t3);}

C_noret_decl(trf_4353)
static void C_fcall trf_4353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4353(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4353(t0,t1);}

C_noret_decl(trf_4165)
static void C_fcall trf_4165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4165(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4165(t0,t1,t2);}

C_noret_decl(trf_4171)
static void C_fcall trf_4171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4171(t0,t1,t2);}

C_noret_decl(trf_3735)
static void C_fcall trf_3735(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3735(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3735(t0,t1,t2);}

C_noret_decl(trf_3454)
static void C_fcall trf_3454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3454(t0,t1,t2);}

C_noret_decl(trf_3578)
static void C_fcall trf_3578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3578(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3578(t0,t1,t2);}

C_noret_decl(trf_3382)
static void C_fcall trf_3382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3382(t0,t1,t2);}

C_noret_decl(trf_3335)
static void C_fcall trf_3335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3335(t0,t1,t2);}

C_noret_decl(trf_2937)
static void C_fcall trf_2937(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2937(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2937(t0,t1,t2,t3);}

C_noret_decl(trf_2956)
static void C_fcall trf_2956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2956(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2956(t0,t1);}

C_noret_decl(trf_2962)
static void C_fcall trf_2962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2962(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2962(t0,t1);}

C_noret_decl(trf_3060)
static void C_fcall trf_3060(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3060(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3060(t0,t1);}

C_noret_decl(trf_2977)
static void C_fcall trf_2977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2977(t0,t1);}

C_noret_decl(trf_2699)
static void C_fcall trf_2699(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2699(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2699(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2474)
static void C_fcall trf_2474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2474(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2474(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2136)
static void C_fcall trf_2136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2136(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2136(t0,t1);}

C_noret_decl(trf_2210)
static void C_fcall trf_2210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2210(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2210(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_chicken_syntax_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("chicken_syntax_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(3067)){
C_save(t1);
C_rereclaim2(3067*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,235);
lf[0]=C_h_intern(&lf[0],29,"\003syschicken-macro-environment");
lf[1]=C_h_intern(&lf[1],17,"register-feature!");
lf[2]=C_h_intern(&lf[2],6,"srfi-8");
lf[3]=C_h_intern(&lf[3],7,"srfi-16");
lf[4]=C_h_intern(&lf[4],7,"srfi-26");
lf[5]=C_h_intern(&lf[5],7,"srfi-31");
lf[6]=C_h_intern(&lf[6],7,"srfi-15");
lf[7]=C_h_intern(&lf[7],7,"srfi-11");
lf[8]=C_h_intern(&lf[8],16,"\003sysmacro-subset");
lf[9]=C_h_intern(&lf[9],29,"\003sysdefault-macro-environment");
lf[10]=C_h_intern(&lf[10],28,"\003sysextend-macro-environment");
lf[11]=C_h_intern(&lf[11],12,"define-macro");
lf[12]=C_h_intern(&lf[12],12,"syntax-error");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000<`define-macro\047 is not supported - please use `define-syntax\047");
lf[14]=C_h_intern(&lf[14],18,"\003syser-transformer");
lf[15]=C_h_intern(&lf[15],19,"let-compiler-syntax");
lf[16]=C_h_intern(&lf[16],24,"\004corelet-compiler-syntax");
lf[17]=C_h_intern(&lf[17],25,"\003syssyntax-rules-mismatch");
lf[18]=C_h_intern(&lf[18],9,"\003syslist\077");
lf[19]=C_h_intern(&lf[19],22,"define-compiler-syntax");
lf[20]=C_h_intern(&lf[20],27,"\004coredefine-compiler-syntax");
lf[21]=C_h_intern(&lf[21],6,"lambda");
lf[22]=C_h_intern(&lf[22],3,"use");
lf[23]=C_h_intern(&lf[23],22,"\004corerequire-extension");
lf[24]=C_h_intern(&lf[24],16,"\003syscheck-syntax");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[26]=C_h_intern(&lf[26],17,"define-for-syntax");
lf[27]=C_h_intern(&lf[27],10,"\003sysappend");
lf[28]=C_h_intern(&lf[28],6,"define");
lf[29]=C_h_intern(&lf[29],16,"begin-for-syntax");
lf[30]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[31]=C_h_intern(&lf[31],3,"rec");
lf[32]=C_h_intern(&lf[32],11,"\004corelambda");
lf[33]=C_h_intern(&lf[33],11,"\004coreletrec");
lf[34]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[35]=C_h_intern(&lf[35],5,"apply");
lf[36]=C_h_intern(&lf[36],4,"cute");
lf[37]=C_h_intern(&lf[37],8,"\004corelet");
lf[38]=C_h_intern(&lf[38],6,"gensym");
lf[39]=C_h_intern(&lf[39],7,"reverse");
lf[40]=C_h_intern(&lf[40],5,"<...>");
lf[41]=C_h_intern(&lf[41],2,"<>");
lf[42]=C_h_intern(&lf[42],19,"\003sysprimitive-alias");
lf[43]=C_h_intern(&lf[43],3,"cut");
lf[44]=C_h_intern(&lf[44],10,"\004corebegin");
lf[45]=C_h_intern(&lf[45],18,"getter-with-setter");
lf[46]=C_h_intern(&lf[46],18,"define-record-type");
lf[47]=C_h_intern(&lf[47],10,"\004corequote");
lf[48]=C_h_intern(&lf[48],18,"\003sysmake-structure");
lf[49]=C_h_intern(&lf[49],14,"\003sysstructure\077");
lf[50]=C_h_intern(&lf[50],19,"\003syscheck-structure");
lf[51]=C_h_intern(&lf[51],10,"\004corecheck");
lf[52]=C_h_intern(&lf[52],13,"\003sysblock-ref");
lf[53]=C_h_intern(&lf[53],10,"\003syssetter");
lf[54]=C_h_intern(&lf[54],14,"\003sysblock-set!");
lf[55]=C_h_intern(&lf[55],6,"setter");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[57]=C_h_intern(&lf[57],3,"car");
lf[58]=C_h_intern(&lf[58],1,"y");
lf[59]=C_h_intern(&lf[59],1,"x");
lf[60]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\001\376\003\000\000\002\376\001\000\000\010variable\376\001\000"
"\000\001_");
lf[61]=C_h_intern(&lf[61],4,"else");
lf[62]=C_h_intern(&lf[62],4,"memv");
lf[63]=C_h_intern(&lf[63],14,"condition-case");
lf[64]=C_h_intern(&lf[64],9,"condition");
lf[65]=C_h_intern(&lf[65],8,"\003sysslot");
lf[66]=C_h_intern(&lf[66],10,"\003syssignal");
lf[67]=C_h_intern(&lf[67],4,"cond");
lf[68]=C_h_intern(&lf[68],17,"handle-exceptions");
lf[69]=C_h_intern(&lf[69],3,"and");
lf[70]=C_h_intern(&lf[70],4,"kvar");
lf[71]=C_h_intern(&lf[71],5,"exvar");
lf[72]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[73]=C_h_intern(&lf[73],30,"call-with-current-continuation");
lf[74]=C_h_intern(&lf[74],22,"with-exception-handler");
lf[75]=C_h_intern(&lf[75],10,"\003sysvalues");
lf[76]=C_h_intern(&lf[76],9,"\003sysapply");
lf[77]=C_h_intern(&lf[77],20,"\003syscall-with-values");
lf[78]=C_h_intern(&lf[78],4,"args");
lf[79]=C_h_intern(&lf[79],1,"k");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[81]=C_h_intern(&lf[81],21,"define-record-printer");
lf[82]=C_h_intern(&lf[82],5,"quote");
lf[83]=C_h_intern(&lf[83],27,"\003sysregister-record-printer");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\006symbol\376\377\016\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[87]=C_h_intern(&lf[87],2,">=");
lf[88]=C_h_intern(&lf[88],3,"cdr");
lf[89]=C_h_intern(&lf[89],3,"eq\077");
lf[90]=C_h_intern(&lf[90],11,"case-lambda");
lf[91]=C_h_intern(&lf[91],6,"length");
lf[92]=C_h_intern(&lf[92],7,"\004coreif");
lf[93]=C_h_intern(&lf[93],9,"split-at!");
lf[94]=C_h_intern(&lf[94],4,"take");
lf[95]=C_h_intern(&lf[95],4,"list");
lf[96]=C_h_intern(&lf[96],11,"lambda-list");
lf[97]=C_h_intern(&lf[97],25,"\003sysdecompose-lambda-list");
lf[98]=C_h_intern(&lf[98],10,"fold-right");
lf[99]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corecheck\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011\003syserror\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016\004coreimmutable\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376B\000\0000no matching clause in call to \047case-lambda\047 form\376\377\016\376\377\016\376\377\016"
"\376\377\016");
lf[100]=C_h_intern(&lf[100],6,"append");
lf[101]=C_h_intern(&lf[101],4,"lvar");
lf[102]=C_h_intern(&lf[102],4,"rvar");
lf[103]=C_h_intern(&lf[103],3,"min");
lf[104]=C_h_intern(&lf[104],7,"require");
lf[105]=C_h_intern(&lf[105],6,"srfi-1");
lf[106]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[107]=C_h_intern(&lf[107],5,"null\077");
lf[108]=C_h_intern(&lf[108],14,"let-optionals*");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[110]=C_h_intern(&lf[110],14,"\004coreimmutable");
lf[111]=C_h_intern(&lf[111],9,"\003syserror");
lf[112]=C_h_intern(&lf[112],4,"tmp2");
lf[113]=C_h_intern(&lf[113],3,"tmp");
lf[114]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[115]=C_h_intern(&lf[115],8,"optional");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[118]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[119]=C_h_intern(&lf[119],13,"let-optionals");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[121]=C_h_intern(&lf[121],14,"string->symbol");
lf[122]=C_h_intern(&lf[122],13,"string-append");
lf[123]=C_h_intern(&lf[123],14,"symbol->string");
lf[124]=C_h_intern(&lf[124],4,"let*");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\004def-");
lf[126]=C_h_intern(&lf[126],6,"_%rest");
lf[127]=C_h_intern(&lf[127],4,"body");
lf[128]=C_h_intern(&lf[128],4,"cadr");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\001%");
lf[130]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[131]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\003\000\000\002\376\001\000\000\010variable\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000");
lf[132]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[133]=C_h_intern(&lf[133],6,"select");
lf[134]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\012\004corebegin\376\377\016");
lf[136]=C_h_intern(&lf[136],10,"\003sysnotice");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\0005non-`else\047 clause following `else\047 clause in `select\047");
lf[138]=C_h_intern(&lf[138],16,"\003sysstrip-syntax");
lf[139]=C_h_intern(&lf[139],8,"\003syseqv\077");
lf[140]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[141]=C_h_intern(&lf[141],16,"\003syssyntax-error");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid syntax");
lf[143]=C_h_intern(&lf[143],2,"or");
lf[144]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\001\000\000\001_");
lf[145]=C_h_intern(&lf[145],8,"and-let*");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[147]=C_h_intern(&lf[147],13,"define-inline");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000*invalid substitution form - must be lambda");
lf[149]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[150]=C_h_intern(&lf[150],18,"\004coredefine-inline");
lf[151]=C_h_intern(&lf[151],8,"list-ref");
lf[152]=C_h_intern(&lf[152],9,"nth-value");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[154]=C_h_intern(&lf[154],13,"letrec-values");
lf[155]=C_h_intern(&lf[155],9,"\004coreset!");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[157]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[158]=C_h_intern(&lf[158],11,"let*-values");
lf[159]=C_h_intern(&lf[159],10,"let-values");
lf[160]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[161]=C_h_intern(&lf[161],4,"caar");
lf[162]=C_h_intern(&lf[162],4,"cdar");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\004list\376\001\000\000\001_");
lf[164]=C_h_intern(&lf[164],13,"define-values");
lf[165]=C_h_intern(&lf[165],11,"set!-values");
lf[166]=C_h_intern(&lf[166],19,"\003sysregister-export");
lf[167]=C_h_intern(&lf[167],18,"\003syscurrent-module");
lf[168]=C_h_intern(&lf[168],12,"\003sysfor-each");
lf[169]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[170]=C_h_intern(&lf[170],14,"\004coreundefined");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\001\000\000\010variable\376\377\001\000\000\000\000\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[172]=C_h_intern(&lf[172],6,"unless");
lf[173]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[174]=C_h_intern(&lf[174],4,"when");
lf[175]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[176]=C_h_intern(&lf[176],12,"parameterize");
lf[177]=C_h_intern(&lf[177],16,"\003sysdynamic-wind");
lf[178]=C_h_intern(&lf[178],1,"t");
lf[179]=C_h_intern(&lf[179],8,"\003syslist");
lf[180]=C_h_intern(&lf[180],4,"swap");
lf[181]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[182]=C_h_intern(&lf[182],9,"eval-when");
lf[183]=C_h_intern(&lf[183],10,"\000compiling");
lf[184]=C_h_intern(&lf[184],12,"\003sysfeatures");
lf[185]=C_h_intern(&lf[185],19,"\004corecompiletimetoo");
lf[186]=C_h_intern(&lf[186],20,"\004corecompiletimeonly");
lf[187]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[188]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid situation specifier");
lf[190]=C_h_intern(&lf[190],4,"load");
lf[191]=C_h_intern(&lf[191],7,"compile");
lf[192]=C_h_intern(&lf[192],4,"eval");
lf[193]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\002");
lf[194]=C_h_intern(&lf[194],9,"fluid-let");
lf[195]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\000\000\000\002\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016\376\377\001\000\000\000\000\376\001\000\000\001_");
lf[196]=C_h_intern(&lf[196],6,"ensure");
lf[197]=C_h_intern(&lf[197],11,"\000type-error");
lf[198]=C_h_intern(&lf[198],15,"\003syssignal-hook");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\033argument has incorrect type");
lf[200]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\003");
lf[201]=C_h_intern(&lf[201],6,"assert");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\020assertion failed");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[205]=C_h_intern(&lf[205],15,"get-line-number");
lf[206]=C_decode_literal(C_heaptop,"\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[207]=C_h_intern(&lf[207],7,"include");
lf[208]=C_h_intern(&lf[208],12,"\004coreinclude");
lf[209]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006string\376\377\016");
lf[210]=C_h_intern(&lf[210],7,"declare");
lf[211]=C_h_intern(&lf[211],12,"\004coredeclare");
lf[212]=C_h_intern(&lf[212],4,"time");
lf[213]=C_h_intern(&lf[213],15,"\003sysstart-timer");
lf[214]=C_h_intern(&lf[214],14,"\003sysstop-timer");
lf[215]=C_h_intern(&lf[215],17,"\003sysdisplay-times");
lf[216]=C_h_intern(&lf[216],7,"receive");
lf[217]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\013lambda-list\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\001");
lf[218]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\002\376\001\000\000\001_\376\377\001\000\000\000\000");
lf[219]=C_h_intern(&lf[219],13,"define-record");
lf[220]=C_h_intern(&lf[220],15,"\000record-setters");
lf[221]=C_h_intern(&lf[221],3,"val");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\005-set!");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\001\077");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\005make-");
lf[227]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\000\000\000\002\376\001\000\000\006symbol\376\377\001\000\000\000\000");
lf[228]=C_h_intern(&lf[228],15,"define-constant");
lf[229]=C_h_intern(&lf[229],20,"\004coredefine-constant");
lf[230]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\006symbol\376\003\000\000\002\376\001\000\000\001_\376\377\016");
lf[231]=C_h_intern(&lf[231],21,"\003sysmacro-environment");
lf[232]=C_h_intern(&lf[232],11,"\003sysprovide");
lf[233]=C_h_intern(&lf[233],19,"chicken-more-macros");
lf[234]=C_h_intern(&lf[234],14,"chicken-syntax");
C_register_lf2(lf,235,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1930,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:38: ##sys#provide */
t3=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[233],lf[234]);}

/* k1928 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:46: ##sys#macro-environment */
t3=*((C_word*)lf[231]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1932 in k1928 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1937,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9894,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9896,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:51: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9895 in k1932 in k1928 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9896,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9900,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:53: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[228],t2,lf[230]);}

/* k9898 in a9895 in k1932 in k1928 */
static void C_ccall f_9900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9907,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k9905 in k9898 in a9895 in k1932 in k1928 */
static void C_ccall f_9907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9907,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[229],t1));}

/* k9892 in k1932 in k1928 */
static void C_ccall f_9894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:48: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[228],C_SCHEME_END_OF_LIST,t1);}

/* k1935 in k1932 in k1928 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9456,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9458,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:58: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9458,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9462,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:60: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[219],t2,lf[227]);}

/* k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9462,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9471,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:63: symbol->string */
t5=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9471,2,t0,t1);}
t2=C_i_memq(lf[220],*((C_word*)lf[184]+1));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9477,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:65: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[28]);}

/* k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9480,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:66: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9850,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:69: string-append */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[226],((C_word*)t0)[2]);}

/* k9888 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:69: string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9850,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9882,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=t3,tmp=(C_word)a,a+=11,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);}

/* k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[37],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9882,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[10],t1);
t3=C_a_i_cons(&a,2,lf[48],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[8],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[7],t8);
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9798,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t9,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9842,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:72: string-append */
t12=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,((C_word*)t0)[2],lf[225]);}

/* k9840 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:72: string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9798,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[59],t5);
t7=C_a_i_cons(&a,2,lf[49],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t2,t8);
t10=C_a_i_cons(&a,2,lf[32],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t1,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9503,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9507,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t17,a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word)li121),tmp=(C_word)a,a+=9,tmp));
t19=((C_word*)t17)[1];
f_9509(t19,t15,((C_word*)t0)[2],C_fix(1));}

/* mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_fcall f_9509(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9509,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,C_SCHEME_END_OF_LIST);
if(C_truep(t4)){
t5=t2;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9519,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t6=C_slot(t2,C_fix(0));
/* chicken-syntax.scm:77: symbol->string */
t7=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}}

/* k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9522,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:78: string-append */
t4=*((C_word*)lf[122]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[2],lf[223],t1,lf[224]);}

/* k9784 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:78: string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9520 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9525,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=t1,a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:79: string-append */
t4=*((C_word*)lf[122]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],lf[222],((C_word*)t0)[2]);}

/* k9780 in k9520 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:79: string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k9523 in k9520 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word ab[123],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9525,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[221],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[59],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[47],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[59],t6);
t8=C_a_i_cons(&a,2,lf[50],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[51],t9);
t11=C_a_i_cons(&a,2,lf[221],C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=C_a_i_cons(&a,2,lf[59],t12);
t14=C_a_i_cons(&a,2,lf[54],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t10,t15);
t17=C_a_i_cons(&a,2,t3,t16);
t18=C_a_i_cons(&a,2,lf[32],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,((C_word*)t0)[8],t19);
t21=C_a_i_cons(&a,2,((C_word*)t0)[7],t20);
t22=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9572,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t21,a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t23=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[59],t26);
t28=C_a_i_cons(&a,2,lf[50],t27);
t29=C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=C_a_i_cons(&a,2,lf[51],t29);
t31=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[59],t31);
t33=C_a_i_cons(&a,2,lf[52],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t30,t34);
t36=C_a_i_cons(&a,2,t23,t35);
t37=C_a_i_cons(&a,2,lf[32],t36);
t38=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t37,t38);
t40=t22;
f_9572(t40,C_a_i_cons(&a,2,((C_word*)t0)[2],t39));}
else{
t23=C_a_i_cons(&a,2,lf[59],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,((C_word*)t0)[10],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[59],t26);
t28=C_a_i_cons(&a,2,lf[50],t27);
t29=C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=C_a_i_cons(&a,2,lf[51],t29);
t31=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[59],t31);
t33=C_a_i_cons(&a,2,lf[52],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t30,t34);
t36=C_a_i_cons(&a,2,t23,t35);
t37=t22;
f_9572(t37,C_a_i_cons(&a,2,lf[32],t36));}}

/* k9570 in k9523 in k9520 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_fcall f_9572(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9572,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],t5);
t7=C_a_i_cons(&a,2,lf[44],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9536,a[2]=t7,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t9=C_slot(((C_word*)t0)[4],C_fix(1));
t10=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:101: mapslots */
t11=((C_word*)((C_word*)t0)[2])[1];
f_9509(t11,t8,t9,t10);}

/* k9534 in k9570 in k9523 in k9520 in k9517 in mapslots in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9536,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k9505 in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k9501 in k9796 in k9880 in k9848 in k9478 in k9475 in k9469 in k9460 in a9457 in k1935 in k1932 in k1928 */
static void C_ccall f_9503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9503,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[44],t3));}

/* k9454 in k1935 in k1932 in k1928 */
static void C_ccall f_9456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:56: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[219],C_SCHEME_END_OF_LIST,t1);}

/* k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9319,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9321,a[2]=((C_word)li120),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:106: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9321(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9321,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9325,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:108: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[216],t2,lf[218]);}

/* k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9325,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9354,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:112: ##sys#check-syntax */
t4=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[216],((C_word*)t0)[3],lf[217]);}}

/* k9359 in k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9361,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_caddr(((C_word*)t0)[3]);
t4=C_i_cdddr(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9376,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_cdr(t2);
t7=t5;
f_9376(t7,C_i_nullp(t6));}
else{
t6=t5;
f_9376(t6,C_SCHEME_FALSE);}}

/* k9374 in k9359 in k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_9376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9391,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9430,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k9428 in k9374 in k9359 in k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9430,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k9389 in k9374 in k9359 in k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9391,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k9352 in k9323 in a9320 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9354,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,lf[179],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k9317 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:103: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[216],C_SCHEME_END_OF_LIST,t1);}

/* k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1943,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1946,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9226,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9228,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:124: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9227 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9228,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9232,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:126: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[178]);}

/* k9230 in a9227 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[213],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9311,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k9309 in k9230 in a9227 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9311,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,lf[214],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[215],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[75],t7);
t9=C_a_i_cons(&a,2,lf[76],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[4],t11);
t13=C_a_i_cons(&a,2,lf[32],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t3,t14);
t16=C_a_i_cons(&a,2,lf[77],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,((C_word*)t0)[3],t17);
t19=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[44],t18));}

/* k9224 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:122: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[212],C_SCHEME_END_OF_LIST,t1);}

/* k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1946,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9208,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9210,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:138: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9209 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9210(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9210,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9218,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(t2);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}

/* k9216 in a9209 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9218,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[211],t1));}

/* k9206 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:136: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[210],C_SCHEME_END_OF_LIST,t1);}

/* k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9187,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9189,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:144: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a9188 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9189(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9189,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9193,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:146: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[207],t2,lf[209]);}

/* k9191 in a9188 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[208],t3));}

/* k9185 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:142: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[207],C_SCHEME_END_OF_LIST,t1);}

/* k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1952,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1955,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9085,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=*((C_word*)lf[122]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9087,a[2]=t4,a[3]=((C_word)li116),tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:151: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,t5);}

/* a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9087(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9087,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9091,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:154: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[201],t2,lf[206]);}

/* k9089 in a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9091,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9097,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:156: get-line-number */
t4=*((C_word*)lf[205]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}

/* k9095 in k9089 in a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9097,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[5]);
t3=C_i_nullp(t2);
t4=(C_truep(t3)?lf[202]:C_i_car(t2));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9106,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* chicken-syntax.scm:162: string-append */
t6=((C_word*)t0)[2];
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,lf[203],t1,lf[204],t4);}
else{
t6=t5;
f_9106(2,t6,t4);}}

/* k9104 in k9095 in k9089 in a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9106,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[51],t2);
t4=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9141,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=C_i_length(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t6,C_fix(1)))){
t7=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t7,C_SCHEME_END_OF_LIST);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9166,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:170: ##sys#strip-syntax */
t8=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,((C_word*)t0)[4]);}}

/* k9164 in k9104 in k9095 in k9089 in a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9166,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k9139 in k9104 in k9095 in k9089 in a9086 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9141,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[111],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[92],t6));}

/* k9083 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:149: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[201],C_SCHEME_END_OF_LIST,t1);}

/* k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8954,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8956,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:175: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8955 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8956(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8956,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8960,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:177: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[196],t2,lf[200]);}

/* k8958 in a8955 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8960,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8972,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:181: r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[113]);}

/* k8970 in k8958 in a8955 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[54],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8972,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[51],t7);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* ##sys#append */
t10=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t10=C_a_i_cons(&a,2,lf[199],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[82],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[110],t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,lf[82],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t1,t16);
t18=C_a_i_cons(&a,2,t13,t17);
/* ##sys#append */
t19=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t9,t18,C_SCHEME_END_OF_LIST);}}

/* k9017 in k8970 in k8958 in a8955 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9019,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[197],t1);
t3=C_a_i_cons(&a,2,lf[198],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[92],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[37],t9));}

/* k8952 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:172: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[196],C_SCHEME_END_OF_LIST,t1);}

/* k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1961,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8274,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8276,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:195: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8276,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8280,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:197: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[194],t2,lf[195]);}

/* k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8280,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8289,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8917,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=((C_word)li113),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_8917(t12,t8,t2);}

/* loop120 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8917(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8917,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8946,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g136137 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8944 in loop120 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8946(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8946,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop120133 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8917(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop120133 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8917(t6,((C_word*)t0)[3],t5);}}

/* k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8873,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li112),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8873(t10,t6,((C_word*)t0)[3]);}

/* loop144 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8873(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8873,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8900,a[2]=((C_word*)t0)[5],a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8911,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g160161 */
t6=t3;
f_8900(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8909 in loop144 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8911,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop144157 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8873(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop144157 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8873(t6,((C_word*)t0)[3],t5);}}

/* g160 in loop144 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8900(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8900,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8908,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:201: gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8906 in g160 in loop144 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:201: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8292,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8829,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li110),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8829(t10,t6,((C_word*)t0)[3]);}

/* loop169 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8829(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8829,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8856,a[2]=((C_word*)t0)[5],a[3]=((C_word)li109),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g185186 */
t6=t3;
f_8856(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8865 in loop169 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8867,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop169182 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8829(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop169182 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8829(t6,((C_word*)t0)[3],t5);}}

/* g185 in loop169 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8856,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8864,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:202: gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8862 in g185 in loop169 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:202: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8306,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8654,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8743,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8794,a[2]=t9,a[3]=t14,a[4]=t11,a[5]=((C_word)li108),tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_8794(t16,t12,((C_word*)t0)[2]);}

/* loop222 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8794(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8794,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8823,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g238239 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8821 in loop222 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8823,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop222235 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8794(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop222235 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8794(t6,((C_word*)t0)[3],t5);}}

/* k8741 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8743,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8745,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word)li107),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8745(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop196 in k8741 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8745(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8745,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8778,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g215216 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8776 in loop196 in k8741 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8778,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8758(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8758(t5,t4);}}

/* k8756 in k8776 in loop196 in k8741 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop196210 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8745(t5,((C_word*)t0)[2],t3,t4);}

/* k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8658,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8662,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8666,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t9=C_i_length(((C_word*)t0)[2]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8721,a[2]=t11,a[3]=((C_word)li106),tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_8721(t13,t8,t9);}

/* loop in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8721(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8721,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8735,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_fixnum_difference(t2,C_fix(1));
/* chicken-syntax.scm:209: loop */
t7=t4;
t8=t5;
t1=t7;
t2=t8;
goto loop;}}

/* k8733 in loop in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8735,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_SCHEME_FALSE,t1));}

/* k8664 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8666,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8668,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word)li105),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_8668(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop245 in k8664 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8668(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8668,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8701,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g264265 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8699 in loop245 in k8664 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8701,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_8681(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_8681(t5,t4);}}

/* k8679 in k8699 in loop245 in k8664 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8681(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop245259 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8668(t5,((C_word*)t0)[2],t3,t4);}

/* k8660 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k8656 in k8652 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8510,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8590,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8590(t11,t7,((C_word*)t0)[4],((C_word*)t0)[5]);}

/* loop274 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8590(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8590,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8603,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8603(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8603(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8601 in loop274 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop274288 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8590(t5,((C_word*)t0)[2],t3,t4);}

/* k8508 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8514,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8518,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8528,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li103),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8528(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop305 in k8508 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8528(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8528,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8541,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8541(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8541(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8539 in loop305 in k8508 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop305319 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8528(t5,((C_word*)t0)[2],t3,t4);}

/* k8516 in k8508 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8518,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8512 in k8508 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8506,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8498,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8346,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8430,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_8430(t13,t9,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* loop336 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8430(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8430,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8443,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8443(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8443(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8441 in loop336 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8443(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop336350 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8430(t5,((C_word*)t0)[2],t3,t4);}

/* k8348 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8354,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8368,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_8368(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop367 in k8348 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8368(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8368,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8381,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_8381(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_8381(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k8379 in loop367 in k8348 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop367381 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_8368(t5,((C_word*)t0)[2],t3,t4);}

/* k8356 in k8348 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k8352 in k8348 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8344 in k8496 in k8504 in k8304 in k8293 in k8290 in k8287 in k8278 in a8275 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8346,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[177],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[37],t9));}

/* k8272 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:193: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[194],C_SCHEME_END_OF_LIST,t1);}

/* k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1961(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1961,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1964,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8156,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8158,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:227: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8158(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8158,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8162,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:229: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[182],t2,lf[193]);}

/* k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8162,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8266,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_i_cddr(((C_word*)t0)[5]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8266,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:232: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[192]);}

/* k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:233: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[191]);}

/* k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:234: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[190]);}

/* k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8177,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8180,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t7,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8217,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t3,a[9]=t10,a[10]=((C_word)li99),tmp=(C_word)a,a+=11,tmp));
t12=((C_word*)t10)[1];
f_8217(t12,t8,((C_word*)t0)[2]);}

/* loop in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8217(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8217,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8230,a[2]=t1,a[3]=((C_word*)t0)[9],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8240,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=t2,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:241: c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8238 in loop in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8240,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[12],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[11],C_fix(1));
/* chicken-syntax.scm:245: loop */
t4=((C_word*)((C_word*)t0)[10])[1];
f_8217(t4,((C_word*)t0)[9],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:242: c */
t3=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k8245 in k8238 in loop in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8247,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[9],C_fix(1));
/* chicken-syntax.scm:245: loop */
t4=((C_word*)((C_word*)t0)[8])[1];
f_8217(t4,((C_word*)t0)[7],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8254,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:243: c */
t3=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k8252 in k8245 in k8238 in loop in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[6],0,C_SCHEME_TRUE);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
/* chicken-syntax.scm:245: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8217(t4,((C_word*)t0)[3],t3);}
else{
t2=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm:244: ##sys#error */
t3=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],lf[189],t2);}}

/* k8228 in loop in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
/* chicken-syntax.scm:245: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8217(t3,((C_word*)t0)[2],t2);}

/* k8178 in k8175 in k8172 in k8169 in k8264 in k8160 in a8157 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8180,2,t0,t1);}
if(C_truep(C_i_memq(lf[183],*((C_word*)lf[184]+1)))){
t2=(C_truep(((C_word*)((C_word*)t0)[6])[1])?((C_word*)((C_word*)t0)[5])[1]:C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[185],t3));}
else{
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[186],t3));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(((C_word*)((C_word*)t0)[5])[1])?((C_word*)t0)[4]:lf[187]));}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)((C_word*)t0)[2])[1])?((C_word*)t0)[4]:lf[188]));}}

/* k8154 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:225: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[182],C_SCHEME_END_OF_LIST,t1);}

/* k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1964,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1967,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7676,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7678,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:257: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7678,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7682,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:259: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[176],t2,lf[181]);}

/* k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7682,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7691,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:262: r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[180]);}

/* k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7691,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8119,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li97),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_8119(t10,t6,((C_word*)t0)[2]);}

/* loop440 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8119,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8148,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g456457 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8146 in loop440 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8148,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop440453 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8119(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop440453 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8119(t6,((C_word*)t0)[3],t5);}}

/* k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7694,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7697,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8084,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_8084(t10,t6,((C_word*)t0)[2]);}

/* loop464 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8084,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g480481 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8111 in loop464 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8113,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop464477 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8084(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop464477 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8084(t6,((C_word*)t0)[3],t5);}}

/* k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7697,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8040,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li95),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_8040(t10,t6,((C_word*)t0)[3]);}

/* loop488 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8040,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8067,a[2]=((C_word*)t0)[5],a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8078,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g504505 */
t6=t3;
f_8067(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8076 in loop488 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8078,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop488501 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8040(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop488501 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8040(t6,((C_word*)t0)[3],t5);}}

/* g504 in loop488 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8067,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8075,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:265: gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8073 in g504 in loop488 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:265: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7700,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7996,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li93),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_7996(t10,t6,((C_word*)t0)[3]);}

/* loop513 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7996(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7996,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8023,a[2]=((C_word*)t0)[5],a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g529530 */
t6=t3;
f_8023(t6,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8032 in loop513 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8034,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop513526 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7996(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop513526 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7996(t6,((C_word*)t0)[3],t5);}}

/* g529 in loop513 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_8023(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8023,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8031,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:266: gensym */
t3=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8029 in g529 in loop513 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_8031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:266: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7714,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7892,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7947,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li91),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7947(t11,t7,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* loop540 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7947(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7947,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7980,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g559560 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7978 in loop540 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7980,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_7960(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_7960(t5,t4);}}

/* k7958 in k7978 in loop540 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop540554 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7947(t5,((C_word*)t0)[2],t3,t4);}

/* k7890 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7892,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7896,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7898,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li90),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7898(t10,t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop566 in k7890 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7898(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7898,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[179]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7931,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g585586 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7929 in loop566 in k7890 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7931,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7911,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_7911(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_7911(t5,t4);}}

/* k7909 in k7929 in loop566 in k7890 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop566580 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7898(t5,((C_word*)t0)[2],t3,t4);}

/* k7894 in k7890 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:268: ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7782,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7786,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7788,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li89),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7788(t11,t7,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop592 in k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7788(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[50],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7788,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[178],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t6,t12);
t14=C_a_i_cons(&a,2,lf[178],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t7,t14);
t16=C_a_i_cons(&a,2,lf[155],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t13,t17);
t19=C_a_i_cons(&a,2,t11,t18);
t20=C_a_i_cons(&a,2,lf[37],t19);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7801,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t21,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t23=t22;
f_7801(t23,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t21));}
else{
t23=C_mutate(((C_word *)((C_word*)t0)[2])+1,t21);
t24=t22;
f_7801(t24,t23);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7799 in loop592 in k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7801(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop592606 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7788(t5,((C_word*)t0)[2],t3,t4);}

/* k7784 in k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7780 in k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7782,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t6,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k7760 in k7780 in k7712 in k7701 in k7698 in k7695 in k7692 in k7689 in k7680 in a7677 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7762,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],t5);
t7=C_a_i_cons(&a,2,lf[177],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=C_a_i_cons(&a,2,lf[37],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[37],t12));}

/* k7674 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:255: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[176],C_SCHEME_END_OF_LIST,t1);}

/* k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1967,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7639,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7641,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:285: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7640 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7641(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7641,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7645,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:287: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[174],t2,lf[175]);}

/* k7643 in a7640 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k7666 in k7643 in a7640 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7668,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k7637 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:283: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[174],C_SCHEME_END_OF_LIST,t1);}

/* k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7594,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7596,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:293: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7595 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7596(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7596,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7600,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:295: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[172],t2,lf[173]);}

/* k7598 in a7595 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7600,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7631,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k7629 in k7598 in a7595 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7631,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[92],t5));}

/* k7592 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:291: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[172],C_SCHEME_END_OF_LIST,t1);}

/* k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7369,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7371,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:302: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7371(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7371,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7375,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:304: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[165],t2,lf[171]);}

/* k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7375,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_caddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t2))){
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,lf[170],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t8);
t10=C_a_i_cons(&a,2,lf[32],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t6,t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[77],t12));}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[155],t7));}
else{
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7450,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7553,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li85),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7553(t13,t9,t2);}}}

/* loop653 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7553(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7553,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[38]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7582,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g669670 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7580 in loop653 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7582,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop653666 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7553(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop653666 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7553(t6,((C_word*)t0)[3],t5);}}

/* k7448 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7450,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7477,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7481,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7483,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word)li84),tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_7483(t14,t10,((C_word*)t0)[2],t1);}

/* loop679 in k7448 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7483(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7483,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=C_slot(t2,C_fix(0));
t7=C_slot(t3,C_fix(0));
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,lf[155],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7496,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,a[6]=t11,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t13=t12;
f_7496(t13,C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t11));}
else{
t13=C_mutate(((C_word *)((C_word*)t0)[2])+1,t11);
t14=t12;
f_7496(t14,t13);}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7494 in loop679 in k7448 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop679693 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7483(t5,((C_word*)t0)[2],t3,t4);}

/* k7479 in k7448 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7475 in k7448 in k7373 in a7370 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7477,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k7367 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:300: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[165],C_SCHEME_END_OF_LIST,t1);}

/* k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7327,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7329,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:325: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7329,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7333,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:327: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[164],t2,lf[169]);}

/* k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7336,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7353,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* for-each */
t5=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* a7352 in k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7353(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7353,3,t0,t1,t2);}
t3=*((C_word*)lf[166]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7361,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:328: ##sys#current-module */
t5=*((C_word*)lf[167]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k7359 in a7352 in k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g723724 */
t2=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7334 in k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7336,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7343,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:329: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[165]);}

/* k7341 in k7334 in k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7347,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k7345 in k7341 in k7334 in k7331 in a7328 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7347,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k7325 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:323: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[164],C_SCHEME_END_OF_LIST,t1);}

/* k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6808,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6810,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:333: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6810(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6810,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6814,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:335: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[159],t2,lf[163]);}

/* k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6814,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6822,a[2]=t5,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6853,a[2]=t7,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp));
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6895,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t7,a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7290,a[2]=t11,a[3]=t16,a[4]=t13,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_7290(t18,t14,t2);}

/* loop747 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7290,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7319,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g763764 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7317 in loop747 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7319,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop747760 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7290(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop747760 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7290(t6,((C_word*)t0)[3],t5);}}

/* k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6898,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7250,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_7250(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7250(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7250,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7263,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t4))){
/* chicken-syntax.scm:353: append */
t6=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,t3);}
else{
if(C_truep(C_i_pairp(t4))){
/* chicken-syntax.scm:354: append* */
t6=((C_word*)((C_word*)t0)[2])[1];
f_6822(t6,t5,t4,t3);}
else{
t6=C_a_i_cons(&a,2,t4,t3);
t7=C_i_cdr(t2);
/* chicken-syntax.scm:356: loop */
t10=t1;
t11=t7;
t12=t6;
t1=t10;
t2=t11;
t3=t12;
goto loop;}}}}

/* k7261 in loop in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm:356: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7250(t3,((C_word*)t0)[2],t2,t1);}

/* k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6898,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6901,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7202,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li78),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_7202(t10,t6,t1);}

/* loop781 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7202(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7202,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7229,a[2]=((C_word*)t0)[5],a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7244,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g797798 */
t6=t3;
f_7229(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7242 in loop781 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7244,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop781794 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7202(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop781794 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7202(t6,((C_word*)t0)[3],t5);}}

/* g797 in loop781 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7229(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7229,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7237,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7241,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:357: gensym */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k7239 in g797 in loop781 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:357: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7235 in g797 in loop781 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7237,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6902,a[2]=t1,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6913,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7156,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_7156(t7,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}

/* loop in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7156(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7156,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* chicken-syntax.scm:361: reverse */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_i_car(t2);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7196,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:365: map* */
t6=((C_word*)((C_word*)t0)[3])[1];
f_6853(t6,t5,((C_word*)t0)[2],t4);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7189,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:364: lookup */
t6=((C_word*)t0)[2];
f_6902(3,t6,t5,t4);}}}

/* k7187 in loop in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7189,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm:366: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7156(t4,((C_word*)t0)[2],t3,t2);}

/* k7194 in loop in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7196,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm:366: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_7156(t4,((C_word*)t0)[2],t3,t2);}

/* k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6913,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6920,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7116,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_7116(t10,t6,((C_word*)t0)[2]);}

/* loop859 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_7116(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7116,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop859872 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop859872 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6920,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6922,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word)li74),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_6922(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6922(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6922,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6940,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6946,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[4],a[6]=((C_word)li73),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_6946(t13,t9,((C_word*)t0)[3]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6994,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(t4);
if(C_truep(C_i_pairp(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7110,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:374: cdar */
t8=*((C_word*)lf[162]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t7=t5;
f_6994(t7,C_SCHEME_FALSE);}}}

/* k7108 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6994(t2,C_i_nullp(t1));}

/* k6992 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6994,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:376: caar */
t3=*((C_word*)lf[161]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_i_car(((C_word*)t0)[3]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7076,a[2]=((C_word*)t0)[5],a[3]=t5,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cdr(((C_word*)t0)[4]);
t9=C_i_cdr(((C_word*)t0)[6]);
t10=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm:383: fold */
t11=((C_word*)((C_word*)t0)[2])[1];
f_6922(t11,t7,t8,t9,t10);}}

/* k7074 in k6992 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7076,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,lf[32],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[77],t6));}

/* k7031 in k6992 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7033,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7013,a[2]=((C_word*)t0)[5],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[4]);
t8=C_i_cdr(((C_word*)t0)[6]);
t9=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm:377: fold */
t10=((C_word*)((C_word*)t0)[2])[1];
f_6922(t10,t6,t7,t8,t9);}

/* k7011 in k7031 in k6992 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_7013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7013,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* loop827 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6946(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6946,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6973,a[2]=((C_word*)t0)[5],a[3]=((C_word)li72),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6984,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g843844 */
t6=t3;
f_6973(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6982 in loop827 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6984,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop827840 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6946(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop827840 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6946(t6,((C_word*)t0)[3],t5);}}

/* g843 in loop827 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6973(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6973,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6981,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:372: lookup */
t4=((C_word*)t0)[2];
f_6902(3,t4,t3,t2);}

/* k6979 in g843 in loop827 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6938 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6940,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6944,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6942 in k6938 in fold in k6918 in k6911 in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6944,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* lookup in k6899 in k6896 in k6893 in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6902(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6902,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_cdr(t3));}

/* map* in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6853(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6853,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_pairp(t3))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6876,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* chicken-syntax.scm:346: proc */
t6=t2;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
/* chicken-syntax.scm:345: proc */
t4=t2;
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}}

/* k6874 in map* in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6880,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* chicken-syntax.scm:346: map* */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6853(t4,t2,((C_word*)t0)[2],t3);}

/* k6878 in k6874 in map* in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6880,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* append* in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6822(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6822,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6843,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* chicken-syntax.scm:342: append* */
t8=t5;
t9=t6;
t10=t3;
t1=t8;
t2=t9;
t3=t10;
goto loop;}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}}

/* k6841 in append* in k6812 in a6809 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6843,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6806 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:331: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[159],C_SCHEME_END_OF_LIST,t1);}

/* k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6739,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6741,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:387: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6741,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6745,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:389: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[158],t2,lf[160]);}

/* k6743 in a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6745,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6754,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:392: r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[159]);}

/* k6752 in k6743 in a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6754,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6759,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6759(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fold in k6752 in k6743 in a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6759(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6759,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6777,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6796,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t2);
/* chicken-syntax.scm:397: fold */
t9=t5;
t10=t6;
t1=t9;
t2=t10;
goto loop;}}

/* k6794 in fold in k6752 in k6743 in a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6796,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k6775 in fold in k6752 in k6743 in a6740 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6777,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k6737 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:385: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[158],C_SCHEME_END_OF_LIST,t1);}

/* k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1985,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1988,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6374,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6376,a[2]=((C_word)li66),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:401: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6376(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6376,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6380,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:403: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[154],t2,lf[157]);}

/* k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6380,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_cddr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6389,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6695,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6697,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6697(t13,t9,t2);}

/* loop908 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6697(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6697,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop908921 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop908921 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6693 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[27]+1),t1);}

/* k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6389,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6392,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6645,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li64),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_6645(t10,t6,t1);}

/* loop933 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6645(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6645,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6672,a[2]=((C_word*)t0)[5],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6687,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g949950 */
t6=t3;
f_6672(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6685 in loop933 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6687,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop933946 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6645(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop933946 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6645(t6,((C_word*)t0)[3],t5);}}

/* g949 in loop933 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6672(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6672,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6680,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6684,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:407: gensym */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k6682 in g949 in loop933 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:407: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k6678 in g949 in loop933 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6680,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6392,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6393,a[2]=t1,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6412,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6605,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6605(t11,t7,((C_word*)t0)[2]);}

/* loop962 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6605(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6605,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_list(&a,2,t3,lf[156]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop962975 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop962975 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6420,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6426,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word)li61),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_6426(t11,t7,((C_word*)t0)[2]);}

/* loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6426(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6426,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6453,a[2]=((C_word*)t0)[5],a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6599,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10021003 */
t6=t3;
f_6453(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6597 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6599,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop986999 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6426(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop986999 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6426(t6,((C_word*)t0)[3],t5);}}

/* g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6453(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6453,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6481,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=C_i_car(t2);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6551,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=((C_word*)t0)[2],a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_6551(t16,t11,t12);}

/* loop1010 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6551(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6551,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_6393(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10101023 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10101023 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6479 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6489,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_car(((C_word*)t0)[3]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6495,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=((C_word)li58),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_6495(t12,t7,t8);}

/* loop1033 in k6479 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6495(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6495,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6522,a[2]=((C_word*)t0)[5],a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_6522(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop10331046 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop10331046 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1049 in loop1033 in k6479 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static C_word C_fcall f_6522(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t2=f_6393(((C_word*)t0)[2],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
return(C_a_i_cons(&a,2,lf[155],t4));}

/* k6487 in k6479 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6483 in k6479 in g1002 in loop986 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6485,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[77],t5));}

/* k6418 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6424,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k6422 in k6418 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6414 in k6410 in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* lookup in k6390 in k6387 in k6378 in a6375 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static C_word C_fcall f_6393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k6372 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:399: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[154],C_SCHEME_END_OF_LIST,t1);}

/* k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6370,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:421: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[151]);}

/* k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6370,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[151],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6294,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6296,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:422: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a6295 in k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6296,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6300,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:424: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[152],t2,lf[153]);}

/* k6298 in a6295 in k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:425: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k6301 in k6298 in a6295 in k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6303,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6338,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:428: r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[151]);}

/* k6336 in k6301 in k6298 in a6295 in k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6338,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],t6);
t8=C_a_i_cons(&a,2,lf[32],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_cons(&a,2,lf[77],t10));}

/* k6292 in k6368 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:419: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[152],((C_word*)t0)[2],t1);}

/* k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6176,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:432: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6176,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6179,a[2]=t3,a[3]=t4,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6278,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6282,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(t2);
/* chicken-syntax.scm:449: quotify-proc */
t9=t5;
f_6179(t9,t7,t8,lf[147]);}

/* k6280 in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6276 in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6278,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[150],t1));}

/* quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6179(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6179,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:436: ##sys#check-syntax */
t5=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t3,t2,lf[149]);}

/* k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6183,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_cdr(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6258,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[5]);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t6=t5;
f_6192(t6,C_i_cadr(((C_word*)t0)[5]));}}

/* k6256 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6192(t3,C_a_i_cons(&a,2,lf[32],t2));}

/* k6190 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6192(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6192,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6195,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_pairp(t1);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6204,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_6204(t6,t4);}
else{
t6=C_i_car(t1);
t7=C_eqp(lf[32],t6);
if(C_truep(t7)){
t8=t5;
f_6204(t8,C_SCHEME_FALSE);}
else{
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6220,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6224,a[2]=t8,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:444: r */
t10=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,lf[21]);}}}

/* k6222 in k6190 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[4]);
/* chicken-syntax.scm:444: c */
t3=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k6218 in k6190 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_6204(t2,C_i_not(t1));}

/* k6202 in k6190 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6204(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6204,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm:445: syntax-error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],lf[147],lf[148],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]));}}

/* k6193 in k6190 in k6181 in quotify-proc in a6175 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6195,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k6172 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:430: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[147],C_SCHEME_END_OF_LIST,t1);}

/* k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1997,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6021,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6023,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:453: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6023(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6023,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6027,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:455: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[145],t2,lf[146]);}

/* k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6027,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6038,a[2]=t5,a[3]=t3,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6038(t7,((C_word*)t0)[2],t2);}

/* fold in k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_6038(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_6038,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6052,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
if(C_truep(C_i_pairp(t3))){
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6108,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:464: fold */
t17=t7;
t18=t4;
t1=t17;
t2=t18;
goto loop;}
else{
t6=C_i_car(t3);
t7=C_i_cadr(t3);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6146,a[2]=t1,a[3]=t10,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:468: fold */
t17=t11;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6079,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:463: fold */
t17=t5;
t18=t4;
t1=t17;
t2=t18;
goto loop;}}}

/* k6077 in fold in k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6079,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k6144 in fold in k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6146,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[92],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[37],t7));}

/* k6106 in fold in k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6108,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k6050 in fold in k6025 in a6022 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6052,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[44],t1));}

/* k6019 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_6021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:451: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[145],C_SCHEME_END_OF_LIST,t1);}

/* k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_1997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:472: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5808,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5812,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:474: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[133],t2,lf[144]);}

/* k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5812,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_cddr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5821,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:477: r */
t5=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[113]);}

/* k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:478: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[61]);}

/* k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5827,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:479: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[143]);}

/* k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5827,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5846,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=t7,a[7]=((C_word)li49),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_5848(t9,t5,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5848,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[134]);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=C_slot(t2,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5873,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t5,a[8]=((C_word*)t0)[6],a[9]=t4,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:490: ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[133],t4,lf[140]);}
else{
/* chicken-syntax.scm:486: ##sys#syntax-error */
t4=*((C_word*)lf[141]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[133],lf[142],t2);}}}

/* k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5873,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5879,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm:491: c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5879,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5882,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:492: expand */
t3=((C_word*)((C_word*)t0)[6])[1];
f_5848(t3,t2,((C_word*)t0)[5],C_SCHEME_TRUE);}
else{
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5899,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5906,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:497: ##sys#strip-syntax */
t4=*((C_word*)lf[138]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5945,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5949,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_car(((C_word*)t0)[7]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5955,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[2],a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_5955(t12,t7,t8);}}}

/* loop1155 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(16);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5955,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5982,a[2]=((C_word*)t0)[5],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_5982(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop11551168 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop11551168 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1171 in loop1155 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static C_word C_fcall f_5982(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],t2);
return(C_a_i_cons(&a,2,lf[139],t3));}

/* k5947 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k5943 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5945,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}

/* k5935 in k5943 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5937,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[44],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5933,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:505: expand */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5848(t4,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5931 in k5935 in k5943 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5933,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k5904 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:495: ##sys#notice */
t2=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[137],t1);}

/* k5897 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5902,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:498: expand */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5848(t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k5900 in k5897 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[135]);}

/* k5880 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5889,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k5887 in k5880 in k5877 in k5871 in expand in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[44],t1));}

/* k5844 in k5825 in k5822 in k5819 in k5810 in a5807 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5846,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k5804 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:470: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[133],C_SCHEME_END_OF_LIST,t1);}

/* k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2003,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5802,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:586: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5798,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:587: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5798,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5222,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5224,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:588: ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5224,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5228,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:590: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[119],t2,lf[132]);}

/* k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[3],a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5537,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:631: ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[119],t3,lf[131]);}

/* k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:632: ##sys#check-syntax */
t3=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[119],((C_word*)t0)[6],lf[130]);}

/* k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5540,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5749,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5749(t10,t6,((C_word*)t0)[2]);}

/* loop1229 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5749(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5749,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5778,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g12451246 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5776 in loop1229 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5778,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12291242 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5749(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12291242 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5749(t6,((C_word*)t0)[3],t5);}}

/* k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5544,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5559,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5705,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word)li44),tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_5705(t11,t7,t1);}

/* loop1256 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5705(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5705,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5732,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g12721273 */
t6=t3;
f_5732(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5741 in loop1256 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12561269 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5705(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12561269 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5705(t6,((C_word*)t0)[3],t5);}}

/* g1272 in loop1256 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5732(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5732,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5740,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:640: prefix-sym */
f_5544(t3,lf[129],t2);}

/* k5738 in g1272 in loop1256 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:640: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5559,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5562,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5670,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li42),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_5670(t10,t6,((C_word*)t0)[2]);}

/* loop1281 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5670(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5670,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[128]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5699,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g12971298 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5697 in loop1281 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5699,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12811294 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5670(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12811294 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5670(t6,((C_word*)t0)[3],t5);}}

/* k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5562,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5565,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:644: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[127]);}

/* k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:647: r */
t3=((C_word*)t0)[6];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[126]);}

/* k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5571,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5626,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[6],a[7]=((C_word)li41),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_5626(t10,t6,((C_word*)t0)[10]);}

/* loop1307 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5626(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5626,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5653,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5664,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g13231324 */
t6=t3;
f_5653(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5662 in loop1307 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5664,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13071320 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5626(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13071320 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5626(t6,((C_word*)t0)[3],t5);}}

/* g1323 in loop1307 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5653(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5653,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5661,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:649: prefix-sym */
f_5544(t3,lf[125],t2);}

/* k5659 in g1323 in loop1307 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:649: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5571,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5574,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[7];
t5=t1;
t6=((C_word*)t0)[2];
t7=*((C_word*)lf[38]+1);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5247,a[2]=t5,a[3]=t6,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:599: reverse */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}

/* k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:600: reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:601: reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5255,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5257,a[2]=t3,a[3]=((C_word)li39),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5257(t5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* recur in k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5257(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5257,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t2);
t7=C_i_car(t3);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5310,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t1,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:606: reverse */
t9=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t6);}}

/* k5308 in recur in k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5326,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:607: reverse */
t4=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5324 in k5308 in recur in k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t1,t3);}

/* k5320 in k5308 in recur in k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[8],t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[7],t6);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5278,a[2]=t7,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t9=C_i_cdr(((C_word*)t0)[5]);
t10=C_i_cdr(((C_word*)t0)[4]);
t11=C_i_car(((C_word*)t0)[5]);
/* chicken-syntax.scm:608: recur */
t12=((C_word*)((C_word*)t0)[3])[1];
f_5257(t12,t8,((C_word*)t0)[2],t9,t10,t11);}

/* k5276 in k5320 in k5308 in recur in k5253 in k5249 in k5245 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5278,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5577,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:654: make-if-tree */
t3=((C_word*)t0)[4];
f_5336(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[10]);}

/* k5575 in k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5577,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:657: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[124]);}

/* k5582 in k5575 in k5572 in k5569 in k5566 in k5563 in k5560 in k5557 in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)t0)[6]);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],t6);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=C_a_i_cons(&a,2,t3,t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t9,t10);
t12=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,t1,t11));}

/* prefix-sym in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5544(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5544,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5552,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5556,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:635: symbol->string */
t6=*((C_word*)lf[123]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}

/* k5554 in prefix-sym in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:635: string-append */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5550 in prefix-sym in k5541 in k5538 in k5535 in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:635: string->symbol */
t2=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5336(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5336,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5342,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t5,a[6]=((C_word)li36),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_5342(t9,t1,t2,t3,C_SCHEME_END_OF_LIST);}

/* recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_5342(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5342,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5416,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:619: r */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[107]);}
else{
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[107],t6);
t8=C_i_car(t3);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,a[7]=t1,a[8]=t7,a[9]=t5,a[10]=((C_word*)t0)[5],a[11]=t8,tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:624: reverse */
t10=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t4);}}

/* k5528 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],t1);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:625: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k5516 in k5528 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[10],t4);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5502,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t5,a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:626: r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[88]);}

/* k5500 in k5516 in k5528 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5502,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[10],t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5466,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t9=C_i_cdr(((C_word*)t0)[6]);
t10=C_i_cdr(((C_word*)t0)[5]);
t11=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* chicken-syntax.scm:627: recur */
t12=((C_word*)((C_word*)t0)[2])[1];
f_5342(t12,t8,t9,t10,t11);}

/* k5464 in k5500 in k5516 in k5528 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5466,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,lf[37],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[92],t7));}

/* k5414 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5416,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[51],t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5404,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:620: reverse */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}

/* k5402 in k5414 in recur in make-if-tree in k5226 in a5223 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5404,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[120],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[110],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[111],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t2,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[3],t11);
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_a_i_cons(&a,2,lf[92],t12));}

/* k5220 in k5796 in k5800 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:584: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[119],((C_word*)t0)[2],t1);}

/* k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2003,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5214,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:677: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[107],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5210,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:678: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5210,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:679: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5206,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5004,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5006,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:680: ##sys#er-transformer */
t8=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}

/* a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5006,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5010,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:682: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[115],t2,lf[118]);}

/* k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:683: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:685: r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[107]);}

/* k5164 in k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_5051(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_5051(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[111]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[117],t4);}}}

/* k5049 in k5164 in k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:687: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[107]);}

/* k5125 in k5049 in k5164 in k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5139,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:687: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k5137 in k5125 in k5049 in k5164 in k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5139,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[51],t6);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5111,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t7,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:688: r */
t9=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,lf[57]);}

/* k5109 in k5137 in k5125 in k5049 in k5164 in k5011 in k5008 in a5005 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5111,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[116],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[82],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[110],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=C_a_i_cons(&a,2,lf[111],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t3,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[6],t12);
t14=C_a_i_cons(&a,2,lf[92],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,((C_word*)t0)[5],t15);
t17=C_a_i_cons(&a,2,((C_word*)t0)[4],t16);
t18=C_a_i_cons(&a,2,lf[92],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,((C_word*)t0)[3],t19);
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_a_i_cons(&a,2,lf[37],t20));}

/* k5002 in k5204 in k5208 in k5212 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:675: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[115],((C_word*)t0)[2],t1);}

/* k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4996,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:711: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[107]);}

/* k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[107],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4696,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4698,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:712: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4698,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4702,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:714: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[108],t2,lf[114]);}

/* k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4702,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_cdddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4714,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:718: r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[107]);}

/* k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:719: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:720: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:721: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[113]);}

/* k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[8],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4744,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li33),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_4744(t9,t5,t1,((C_word*)t0)[2]);}

/* loop in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4744(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4744,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[51],t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4810,a[2]=t1,a[3]=t7,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t3);
if(C_truep(C_i_pairp(t4))){
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t4,tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:733: r */
t6=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[112]);}
else{
t5=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4972,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);}}}

/* k4970 in loop in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k4832 in loop in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[76],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[9]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[7],t3);
t5=C_i_cadr(((C_word*)t0)[9]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=C_a_i_cons(&a,2,t4,t9);
t11=C_a_i_cons(&a,2,lf[92],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t2,t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,((C_word*)t0)[7],t14);
t16=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,lf[82],t16);
t18=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,((C_word*)t0)[5],t18);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t17,t20);
t22=C_a_i_cons(&a,2,t15,t21);
t23=C_a_i_cons(&a,2,lf[92],t22);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,t1,t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,t13,t26);
t28=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[4],a[3]=t27,tmp=(C_word)a,a+=4,tmp);
t29=C_i_cdr(((C_word*)t0)[3]);
/* chicken-syntax.scm:740: loop */
t30=((C_word*)((C_word*)t0)[2])[1];
f_4744(t30,t28,t1,t29);}

/* k4851 in k4832 in loop in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4853,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k4808 in loop in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,lf[109],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[82],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[110],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=C_a_i_cons(&a,2,lf[111],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t3,t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[3],t12);
t14=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_cons(&a,2,lf[92],t13));}

/* k4740 in k4721 in k4718 in k4715 in k4712 in k4700 in a4697 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k4694 in k4994 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:709: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[108],((C_word*)t0)[2],t1);}

/* k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4688,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:748: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[87]);}

/* k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[87],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4684,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:749: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[57]);}

/* k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4684,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[57],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:750: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[88]);}

/* k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4680,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[88],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:751: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[89]);}

/* k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4676,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[89],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4157,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4159,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:752: ##sys#er-transformer */
t9=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4159,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4163,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:754: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[90],t2,lf[106]);}

/* k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[4],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4200,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:760: require */
t4=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[105]);}

/* k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4593,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(((C_word*)t0)[3]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4599,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word)li31),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_4599(t12,t7,t8);}

/* loop1399 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4640,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4636,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:762: ##sys#decompose-lambda-list */
t7=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t3,t5,t6);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a4635 in loop1399 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4636(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4636,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* k4638 in loop1399 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4640,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13991412 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4599(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13991412 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4599(t6,((C_word*)t0)[3],t5);}}

/* k4591 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[103]+1),t1);}

/* k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4206,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:766: genvars */
t3=((C_word*)t0)[2];
f_4165(t3,t2,t1);}

/* k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:767: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[102]);}

/* k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:768: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[101]);}

/* k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:769: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[87]);}

/* k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4218,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:770: r */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[89]);}

/* k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4221,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* chicken-syntax.scm:771: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[57]);}

/* k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:772: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[88]);}

/* k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* chicken-syntax.scm:774: append */
t3=*((C_word*)lf[100]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)t0)[11]);}

/* k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[91],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4261,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word)li29),tmp=(C_word)a,a+=12,tmp);
t9=C_i_cdr(((C_word*)t0)[2]);
/* chicken-syntax.scm:777: fold-right */
t10=*((C_word*)lf[98]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t7,t8,lf[99],t9);}

/* a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4261(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4261,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=((C_word*)t0)[10],a[13]=((C_word)li28),tmp=(C_word)a,a+=14,tmp);
/* chicken-syntax.scm:779: ##sys#decompose-lambda-list */
t6=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,t4,t5);}

/* a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4271,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_4275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=t1,a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],a[16]=t3,tmp=(C_word)a,a+=17,tmp);
t6=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm:782: ##sys#check-syntax */
t7=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,lf[90],t6,lf[96]);}

/* k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4275,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[16],((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t3;
f_4289(t5,C_SCHEME_TRUE);}
else{
t5=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=t3;
f_4289(t7,C_a_i_cons(&a,2,((C_word*)t0)[3],t6));}}
else{
t4=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=t3;
f_4289(t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}}

/* k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4289,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4297,a[2]=((C_word*)t0)[12],a[3]=t1,a[4]=((C_word*)t0)[13],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4303,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word)li27),tmp=(C_word)a,a+=10,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4313(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4313,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4389,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li26),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_4389(t8,t4,t3,((C_word*)t0)[2]);}

/* build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4389(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4389,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(((C_word*)t0)[7])){
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[7],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4414,a[2]=t1,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_cddr(((C_word*)t0)[6]);
if(C_truep(C_i_nullp(t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_cadr(((C_word*)t0)[6]));}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4446,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(((C_word*)t0)[6]);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4457,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4537,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:797: gensym */
t6=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k4535 in build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:797: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4455 in build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4457,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[4],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t1,t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t6,t11);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp);
t14=C_i_cdr(((C_word*)t0)[7]);
if(C_truep(C_i_pairp(t14))){
t15=C_i_cdr(((C_word*)t0)[7]);
/* chicken-syntax.scm:801: build */
t16=((C_word*)((C_word*)t0)[2])[1];
f_4389(t16,t13,t15,t1);}
else{
/* chicken-syntax.scm:802: build */
t15=((C_word*)((C_word*)t0)[2])[1];
f_4389(t15,t13,C_SCHEME_END_OF_LIST,t1);}}

/* k4474 in k4455 in build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* k4444 in build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4446,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k4412 in build in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4414,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[37],t2));}

/* k4315 in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4317,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4334,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4340,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li25),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_4340(t10,t6,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop1474 in k4315 in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4340(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4340,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[95]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g14931494 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4371 in loop1474 in k4315 in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4353,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_4353(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_4353(t5,t4);}}

/* k4351 in k4371 in loop1474 in k4315 in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4353(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop14741488 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4340(t5,((C_word*)t0)[2],t3,t4);}

/* k4332 in k4315 in a4312 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4334,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[37],t3));}

/* a4302 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4311,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:790: take */
t3=*((C_word*)lf[94]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4309 in a4302 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:790: split-at! */
t2=*((C_word*)lf[93]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4295 in k4287 in k4273 in a4270 in a4260 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4297,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[92],t4));}

/* k4257 in k4233 in k4222 in k4219 in k4216 in k4213 in k4210 in k4207 in k4204 in k4201 in k4198 in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,lf[37],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],t5);
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[32],t6));}

/* genvars in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4165(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4165,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4171,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t2,a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_4171(t6,t1,C_fix(0));}

/* loop in genvars in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_4171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4171,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4197,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:759: gensym */
t5=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4195 in loop in genvars in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:759: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4183 in loop in genvars in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4189,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
/* chicken-syntax.scm:759: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4171(t4,t2,t3);}

/* k4187 in k4183 in loop in genvars in k4161 in a4158 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4189,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4155 in k4674 in k4678 in k4682 in k4686 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:746: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2],t1);}

/* k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4059,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4061,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:815: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4061,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4065,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:817: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[81],t2,lf[86]);}

/* k4063 in a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
t3=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4080,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm:821: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[81],t5,lf[84]);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4126,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_cons(&a,2,t2,t3);
/* chicken-syntax.scm:828: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,lf[81],t5,lf[85]);}}

/* k4124 in k4063 in a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4126,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[82],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4139 in k4124 in k4063 in a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[83],t2));}

/* k4078 in k4063 in a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4080,2,t0,t1);}
t2=C_slot(((C_word*)t0)[4],C_fix(0));
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[82],t3);
t5=C_slot(((C_word*)t0)[4],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k4109 in k4078 in k4063 in a4060 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[83],t5));}

/* k4057 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:813: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[81],C_SCHEME_END_OF_LIST,t1);}

/* k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2015,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:836: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[73]);}

/* k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[73],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:837: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[74]);}

/* k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[74],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3848,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3850,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:838: ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3850,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3854,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:840: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[68],t2,lf[80]);}

/* k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:841: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[79]);}

/* k3855 in k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3857,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3860,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:842: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[78]);}

/* k3858 in k3855 in k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:843: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[73]);}

/* k3869 in k3858 in k3855 in k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3871,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:846: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[74]);}

/* k3897 in k3869 in k3858 in k3855 in k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_i_caddr(((C_word*)t0)[7]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t5);
t7=C_a_i_cons(&a,2,lf[32],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t3,t10);
t12=C_a_i_cons(&a,2,lf[32],t11);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3991,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t12,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t14=C_i_cdddr(((C_word*)t0)[7]);
/* ##sys#append */
t15=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,C_SCHEME_END_OF_LIST);}

/* k3989 in k3897 in k3869 in k3858 in k3855 in k3852 in a3849 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[84],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3991,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[75],t4);
t6=C_a_i_cons(&a,2,lf[76],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t7);
t9=C_a_i_cons(&a,2,lf[32],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,((C_word*)t0)[7],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,((C_word*)t0)[8],t12);
t14=C_a_i_cons(&a,2,lf[32],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t3,t15);
t17=C_a_i_cons(&a,2,lf[77],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t18);
t20=C_a_i_cons(&a,2,lf[32],t19);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=C_a_i_cons(&a,2,((C_word*)t0)[6],t21);
t23=C_a_i_cons(&a,2,((C_word*)t0)[5],t22);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,((C_word*)t0)[4],t24);
t26=C_a_i_cons(&a,2,lf[32],t25);
t27=C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=C_a_i_cons(&a,2,((C_word*)t0)[3],t27);
t29=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST));}

/* k3846 in k4049 in k4053 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:834: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[68],((C_word*)t0)[2],t1);}

/* k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2021,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3840,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:858: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[61]);}

/* k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3840,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[61],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:859: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[62]);}

/* k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3836,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[62],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3431,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3433,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:860: ##sys#er-transformer */
t7=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}

/* a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3433(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3433,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3437,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:862: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[63],t2,lf[72]);}

/* k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:863: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[71]);}

/* k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3443,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:864: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[70]);}

/* k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3446,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:865: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[69]);}

/* k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3446,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3449,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:866: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[62]);}

/* k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3449,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:867: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[61]);}

/* k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],a[7]=((C_word)li17),tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3661,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:881: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[68]);}

/* k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3661,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[64],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[9],t4);
t6=C_a_i_cons(&a,2,lf[49],t5);
t7=C_a_i_cons(&a,2,C_fix(1),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[9],t7);
t9=C_a_i_cons(&a,2,lf[65],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t6,t10);
t12=C_a_i_cons(&a,2,((C_word*)t0)[8],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[7],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3701,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=t15,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:884: r */
t17=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t16,lf[67]);}

/* k3699 in k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3701,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3709,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t8=C_i_cddr(((C_word*)t0)[7]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3735,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t10,a[5]=t6,a[6]=((C_word)li18),tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_3735(t12,t7,t8);}

/* loop1598 in k3699 in k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3735(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3735,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3764,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16141615 */
t5=((C_word*)t0)[2];
f_3454(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3762 in loop1598 in k3699 in k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3764,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15981611 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3735(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15981611 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3735(t6,((C_word*)t0)[3],t5);}}

/* k3707 in k3699 in k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3709,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[66],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t1,t6);}

/* k3703 in k3699 in k3659 in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[6],t3);
t5=C_a_i_cons(&a,2,lf[37],t4);
t6=C_i_cadr(((C_word*)t0)[5]);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t5,t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,((C_word*)t0)[2],t9));}

/* parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3454,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_symbolp(t3);
t5=(C_truep(t4)?C_i_car(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_i_cadr(t2):C_i_car(t2));
t7=(C_truep(t5)?C_i_cddr(t2):C_i_cdr(t2));
if(C_truep(C_i_nullp(t6))){
if(C_truep(t5)){
t8=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t5,t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3496,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t12=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t7,C_SCHEME_END_OF_LIST);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3515,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t9=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t7,C_SCHEME_END_OF_LIST);}}
else{
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3572,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=t5,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3578,a[2]=t10,a[3]=t15,a[4]=t12,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[4],a[7]=((C_word)li16),tmp=(C_word)a,a+=8,tmp));
t17=((C_word*)t15)[1];
f_3578(t17,t13,t6);}}

/* loop1565 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3578(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(23);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3578,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3605,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3605(C_a_i(&a,15),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop15651578 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop15651578 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1581 in loop1565 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static C_word C_fcall f_3605(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
return(C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k3574 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3570 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3572,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],t2);
if(C_truep(((C_word*)t0)[5])){
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3545,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* ##sys#append */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3564,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k3562 in k3570 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3564,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3543 in k3570 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3545,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3513 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3515,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3494 in parse-clause in k3450 in k3447 in k3444 in k3441 in k3438 in k3435 in a3432 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3496(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3496,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,lf[37],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,((C_word*)t0)[2],t4));}

/* k3429 in k3834 in k3838 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:856: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[63],((C_word*)t0)[2],t1);}

/* k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3423,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:893: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[45]);}

/* k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[45],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:894: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2874,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2878,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:896: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[46],t2,lf[60]);}

/* k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_caddr(((C_word*)t0)[5]);
t4=C_i_cadddr(((C_word*)t0)[5]);
t5=C_i_cddddr(((C_word*)t0)[5]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2893,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t2,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* chicken-syntax.scm:904: r */
t7=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,lf[28]);}

/* k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* chicken-syntax.scm:905: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[45]);}

/* k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2896,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2902,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:907: r */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[59]);}

/* k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* chicken-syntax.scm:908: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[58]);}

/* k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2905,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3382,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3382(t10,t6,((C_word*)t0)[3]);}

/* loop1639 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3382,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[57]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g16551656 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3409 in loop1639 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16391652 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3382(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16391652 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3382(t6,((C_word*)t0)[3],t5);}}

/* k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[35],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2908,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[47],t2);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t3,tmp=(C_word)a,a+=13,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3335,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=((C_word)li12),tmp=(C_word)a,a+=7,tmp));
t13=((C_word*)t11)[1];
f_3335(t13,t9,t1);}

/* loop1665 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(7);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3335,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3362,a[2]=((C_word*)t0)[5],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3362(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop16651678 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop16651678 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1681 in loop1665 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static C_word C_fcall f_3362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
if(C_truep(C_i_memq(t1,((C_word*)t0)[2]))){
t2=t1;
return(t2);}
else{
return(lf[56]);}}

/* k3331 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[65],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3329,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[12],t1);
t3=C_a_i_cons(&a,2,lf[48],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[11],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[10],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[9],C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[8],t7);
t9=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[47],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,((C_word*)t0)[9],t11);
t13=C_a_i_cons(&a,2,lf[49],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t8,t14);
t16=C_a_i_cons(&a,2,((C_word*)t0)[10],t15);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2931,a[2]=((C_word*)t0)[6],a[3]=t6,a[4]=t16,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2937,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t20,a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[9],a[9]=((C_word)li10),tmp=(C_word)a,a+=10,tmp));
t22=((C_word*)t20)[1];
f_2937(t22,t18,((C_word*)t0)[2],C_fix(1));}

/* loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2937(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2937,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=C_i_cddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_caddr(t4):C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=t2,a[9]=t1,a[10]=((C_word*)t0)[6],a[11]=t3,a[12]=t4,a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_pairp(t7))){
t9=C_i_cdr(t7);
if(C_truep(C_i_pairp(t9))){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3251,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t11=C_i_car(t7);
/* chicken-syntax.scm:928: c */
t12=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,lf[55],t11);}
else{
t10=t8;
f_2956(t10,C_SCHEME_FALSE);}}
else{
t9=t8;
f_2956(t9,C_SCHEME_FALSE);}}}

/* k3249 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_2956(t2,(C_truep(t1)?C_i_cadr(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2956(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[128],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2956,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[14],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[47],t3);
t5=C_i_cadr(((C_word*)t0)[12]);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[47],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t4,t8);
t10=C_a_i_cons(&a,2,((C_word*)t0)[14],t9);
t11=C_a_i_cons(&a,2,lf[50],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[51],t12);
t14=C_a_i_cons(&a,2,((C_word*)t0)[11],C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,((C_word*)t0)[14],t14);
t16=C_a_i_cons(&a,2,lf[52],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t13,t17);
t19=C_a_i_cons(&a,2,t2,t18);
t20=C_a_i_cons(&a,2,lf[32],t19);
t21=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[3],a[3]=t20,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[6])){
t22=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,((C_word*)t0)[14],t22);
t24=C_a_i_cons(&a,2,((C_word*)t0)[13],C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[47],t24);
t26=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[47],t26);
t28=C_a_i_cons(&a,2,t27,C_SCHEME_END_OF_LIST);
t29=C_a_i_cons(&a,2,t25,t28);
t30=C_a_i_cons(&a,2,((C_word*)t0)[14],t29);
t31=C_a_i_cons(&a,2,lf[50],t30);
t32=C_a_i_cons(&a,2,t31,C_SCHEME_END_OF_LIST);
t33=C_a_i_cons(&a,2,lf[51],t32);
t34=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,((C_word*)t0)[11],t34);
t36=C_a_i_cons(&a,2,((C_word*)t0)[14],t35);
t37=C_a_i_cons(&a,2,lf[54],t36);
t38=C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t33,t38);
t40=C_a_i_cons(&a,2,t23,t39);
t41=t21;
f_2962(t41,C_a_i_cons(&a,2,lf[32],t40));}
else{
t22=t21;
f_2962(t22,C_SCHEME_FALSE);}}

/* k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2962(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2962,NULL,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[13],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3067,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=C_i_cadr(((C_word*)t0)[13]);
/* chicken-syntax.scm:949: c */
t6=((C_word*)t0)[5];
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,((C_word*)t0)[6],t5);}
else{
t5=t4;
f_3067(2,t5,C_SCHEME_FALSE);}}

/* k3065 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3067,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_3060(t5,C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[2];
f_3060(t2,C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST));}}

/* k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_3060(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3060,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[13],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[12],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=t3,a[3]=((C_word*)t0)[11],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2977,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
if(C_truep(((C_word*)t0)[6])){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3029,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=C_i_cadr(((C_word*)t0)[4]);
/* chicken-syntax.scm:954: c */
t8=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[6],t7);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[2],t6);
t8=C_a_i_cons(&a,2,((C_word*)t0)[12],t7);
t9=t5;
f_2977(t9,C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST));}}
else{
t6=t5;
f_2977(t6,C_SCHEME_END_OF_LIST);}}

/* k3027 in k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_3029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3029,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_2977(t2,C_SCHEME_END_OF_LIST);}
else{
t2=C_a_i_cons(&a,2,lf[53],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[53],t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_cons(&a,2,t3,t5);
t7=((C_word*)t0)[4];
f_2977(t7,C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}}

/* k2975 in k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2977,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2981,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2985,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[4]);
t5=C_fixnum_increase(((C_word*)t0)[3]);
/* chicken-syntax.scm:959: loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2937(t6,t3,t4,t5);}

/* k2983 in k2975 in k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2979 in k2975 in k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2971 in k3058 in k2960 in k2954 in loop in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2933 in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2929 in k3327 in k2906 in k2903 in k2900 in k2894 in k2891 in k2876 in a2873 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2931,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[44],t3));}

/* k2870 in k3421 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:891: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[46],((C_word*)t0)[2],t1);}

/* k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2864,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:966: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[35]);}

/* k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2864,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2678,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:967: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2680,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2684,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:969: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[41]);}

/* k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2687,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:970: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[40]);}

/* k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2687(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2687,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:971: r */
t3=((C_word*)t0)[5];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[35]);}

/* k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word)li8),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2699(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2699(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2699,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2709,a[2]=t4,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:974: reverse */
t7=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t3);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=t4,a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
t7=C_i_car(t2);
/* chicken-syntax.scm:982: c */
t8=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)t0)[2],t7);}}

/* k2800 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2824,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:983: gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[9]);
/* chicken-syntax.scm:985: c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2828 in k2800 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm:985: loop */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2699(t2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_TRUE);}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[3]);
/* chicken-syntax.scm:986: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2699(t5,((C_word*)t0)[5],t2,((C_word*)t0)[4],t4,C_SCHEME_FALSE);}}

/* k2822 in k2800 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:983: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2803 in k2800 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2805,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* chicken-syntax.scm:984: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2699(t5,((C_word*)t0)[2],t2,t3,t4,C_SCHEME_FALSE);}

/* k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2712,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:975: reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2712,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2761,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:977: gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[44],t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2784,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cdr(t1);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}}

/* k2782 in k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2784,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[32],t4));}

/* k2759 in k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:977: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2716 in k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2727 in k2716 in k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2749,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(((C_word*)t0)[5]);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2747 in k2727 in k2716 in k2710 in k2707 in loop in k2688 in k2685 in k2682 in a2679 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[32],t5));}

/* k2676 in k2862 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:964: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[43],((C_word*)t0)[2],t1);}

/* k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2670,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:990: ##sys#primitive-alias */
t4=*((C_word*)lf[42]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[35]);}

/* k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2670,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[35],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2453,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2455,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:991: ##sys#er-transformer */
t6=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2455,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2459,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-syntax.scm:993: r */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[35]);}

/* k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* chicken-syntax.scm:994: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[41]);}

/* k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:995: r */
t3=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[40]);}

/* k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word)li6),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_2474(t6,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2474,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
if(C_truep(C_i_nullp(t2))){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2484,a[2]=t5,a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=t4,a[6]=((C_word*)t0)[7],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:998: reverse */
t8=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t3);}
else{
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2593,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
t8=C_i_car(t2);
/* chicken-syntax.scm:1008: c */
t9=((C_word*)t0)[4];
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,((C_word*)t0)[2],t8);}}

/* k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2593,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2596,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2615,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1009: gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=C_i_car(((C_word*)t0)[10]);
/* chicken-syntax.scm:1011: c */
t4=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* k2619 in k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
if(C_truep(t1)){
/* chicken-syntax.scm:1011: loop */
t2=((C_word*)((C_word*)t0)[8])[1];
f_2474(t2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2627,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2654,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1013: gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2652 in k2619 in k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1013: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2625 in k2619 in k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2627,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_i_car(((C_word*)t0)[7]);
t4=C_a_i_list(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[6]);
t6=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm:1014: loop */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2474(t7,((C_word*)t0)[3],t2,((C_word*)t0)[2],t5,t6,C_SCHEME_FALSE);}

/* k2613 in k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1009: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2594 in k2591 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2596,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* chicken-syntax.scm:1010: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2474(t5,((C_word*)t0)[3],t2,t3,((C_word*)t0)[2],t4,C_SCHEME_FALSE);}

/* k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2487,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* chicken-syntax.scm:999: reverse */
t3=*((C_word*)lf[39]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2487,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2548,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1001: gensym */
t4=*((C_word*)lf[38]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_i_car(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2583,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cdr(t1);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2581 in k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2583,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],t3);
t5=C_a_i_cons(&a,2,lf[32],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[37],t7));}

/* k2546 in k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1001: r */
t2=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2491 in k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2516,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* ##sys#append */
t3=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k2514 in k2491 in k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t4=C_i_cdr(((C_word*)t0)[6]);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
/* ##sys#append */
t6=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* k2534 in k2514 in k2491 in k2485 in k2482 in loop in k2463 in k2460 in k2457 in a2454 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,lf[32],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,lf[37],t8));}

/* k2451 in k2668 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:988: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}

/* k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2352,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2354,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1024: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2353 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2354,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2358,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1026: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[31],t2,lf[34]);}

/* k2356 in a2353 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2358,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2414,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2441,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* ##sys#append */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,C_SCHEME_END_OF_LIST);}}

/* k2439 in k2356 in a2353 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2441,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t3,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[33],t5));}

/* k2412 in k2356 in a2353 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2414,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,lf[32],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_i_car(((C_word*)t0)[3]);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t6,t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[33],t9));}

/* k2350 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1022: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[31],C_SCHEME_END_OF_LIST,t1);}

/* k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2315,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2317,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1040: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2316 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2317,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2321,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1042: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[26],t2,lf[30]);}

/* k2319 in a2316 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1043: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[29]);}

/* k2326 in k2319 in a2316 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-syntax.scm:1044: r */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[28]);}

/* k2338 in k2326 in k2319 in a2316 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* ##sys#append */
t4=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_SCHEME_END_OF_LIST);}

/* k2342 in k2338 in k2326 in k2319 in a2316 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2344,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k2313 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1038: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[26],C_SCHEME_END_OF_LIST,t1);}

/* k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2039,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2290,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2292,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1051: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2291 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2292,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2296,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* chicken-syntax.scm:1053: ##sys#check-syntax */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[22],t2,lf[25]);}

/* k2294 in a2291 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2296,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[23],t4));}

/* k2288 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1049: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[22],C_SCHEME_END_OF_LIST,t1);}

/* k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2124,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2126,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1061: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2126,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2136,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_cdr(t5);
t8=t6;
f_2136(t8,C_eqp(t7,C_SCHEME_END_OF_LIST));}
else{
t7=t6;
f_2136(t7,C_SCHEME_FALSE);}}

/* k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2136(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2136,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* rename18191824 */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[20]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(((C_word*)t0)[5]);
/* ##sys#list? */
t5=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}
else{
t4=t2;
f_2160(2,t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2160(2,t3,C_SCHEME_FALSE);}}}

/* k2158 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2160,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[5]);
t5=C_i_cdr(t4);
t6=C_i_cdr(((C_word*)t0)[5]);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* rename18191824 */
t8=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,lf[19]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2210,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_cdr(((C_word*)t0)[5]);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=t2;
f_2210(t5,C_eqp(t4,C_SCHEME_END_OF_LIST));}
else{
t4=t2;
f_2210(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_2210(t3,C_SCHEME_FALSE);}}}

/* k2208 in k2158 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_fcall f_2210(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2210,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* rename18191824 */
t6=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,lf[20]);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k2221 in k2208 in k2158 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2223,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k2174 in k2158 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2192,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* rename18191824 */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[21]);}

/* k2190 in k2174 in k2158 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,((C_word*)t0)[2],t5));}

/* k2144 in k2134 in a2125 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t1,t3));}

/* k2122 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1059: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[19],C_SCHEME_END_OF_LIST,t1);}

/* k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2042,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2068,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2070,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1072: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2069 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2070(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2070,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2080,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t5))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2109,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=C_i_car(t5);
/* ##sys#list? */
t9=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}
else{
t7=t6;
f_2080(2,t7,C_SCHEME_FALSE);}}

/* k2107 in a2069 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
/* ##sys#list? */
t3=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
f_2080(2,t2,C_SCHEME_FALSE);}}

/* k2078 in a2069 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2080,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2093,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* rename18601865 */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[16]);}
else{
/* ##sys#syntax-rules-mismatch */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k2091 in k2078 in a2069 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2093,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k2066 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1070: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[15],C_SCHEME_END_OF_LIST,t1);}

/* k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2048,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1082: ##sys#er-transformer */
t5=*((C_word*)lf[14]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a2059 in k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2060,5,t0,t1,t2,t3,t4);}
/* chicken-syntax.scm:1084: syntax-error */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,lf[11],lf[13]);}

/* k2056 in k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-syntax.scm:1080: ##sys#extend-macro-environment */
t2=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[11],C_SCHEME_END_OF_LIST,t1);}

/* k2046 in k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1087: ##sys#macro-subset */
t3=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],*((C_word*)lf[9]+1));}

/* k2049 in k2046 in k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##sys#chicken-macro-environment ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-syntax.scm:1092: register-feature! */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,lf[2],lf[3],lf[4],lf[5],lf[6],lf[7]);}

/* k2052 in k2049 in k2046 in k2043 in k2040 in k2037 in k2034 in k2031 in k2028 in k2025 in k2022 in k2019 in k2016 in k2013 in k2010 in k2007 in k2004 in k2001 in k1998 in k1995 in k1992 in k1989 in k1986 in k1983 in k1980 in k1977 in k1974 in k1971 in k1968 in k1965 in k1962 in k1959 in k1956 in k1953 in k1950 in k1947 in k1944 in k1941 in k1938 in k1935 in k1932 in k1928 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[598] = {
{"toplevel:chicken_syntax_scm",(void*)C_chicken_syntax_toplevel},
{"f_1930:chicken_syntax_scm",(void*)f_1930},
{"f_1934:chicken_syntax_scm",(void*)f_1934},
{"f_9896:chicken_syntax_scm",(void*)f_9896},
{"f_9900:chicken_syntax_scm",(void*)f_9900},
{"f_9907:chicken_syntax_scm",(void*)f_9907},
{"f_9894:chicken_syntax_scm",(void*)f_9894},
{"f_1937:chicken_syntax_scm",(void*)f_1937},
{"f_9458:chicken_syntax_scm",(void*)f_9458},
{"f_9462:chicken_syntax_scm",(void*)f_9462},
{"f_9471:chicken_syntax_scm",(void*)f_9471},
{"f_9477:chicken_syntax_scm",(void*)f_9477},
{"f_9480:chicken_syntax_scm",(void*)f_9480},
{"f_9890:chicken_syntax_scm",(void*)f_9890},
{"f_9850:chicken_syntax_scm",(void*)f_9850},
{"f_9882:chicken_syntax_scm",(void*)f_9882},
{"f_9842:chicken_syntax_scm",(void*)f_9842},
{"f_9798:chicken_syntax_scm",(void*)f_9798},
{"f_9509:chicken_syntax_scm",(void*)f_9509},
{"f_9519:chicken_syntax_scm",(void*)f_9519},
{"f_9786:chicken_syntax_scm",(void*)f_9786},
{"f_9522:chicken_syntax_scm",(void*)f_9522},
{"f_9782:chicken_syntax_scm",(void*)f_9782},
{"f_9525:chicken_syntax_scm",(void*)f_9525},
{"f_9572:chicken_syntax_scm",(void*)f_9572},
{"f_9536:chicken_syntax_scm",(void*)f_9536},
{"f_9507:chicken_syntax_scm",(void*)f_9507},
{"f_9503:chicken_syntax_scm",(void*)f_9503},
{"f_9456:chicken_syntax_scm",(void*)f_9456},
{"f_1940:chicken_syntax_scm",(void*)f_1940},
{"f_9321:chicken_syntax_scm",(void*)f_9321},
{"f_9325:chicken_syntax_scm",(void*)f_9325},
{"f_9361:chicken_syntax_scm",(void*)f_9361},
{"f_9376:chicken_syntax_scm",(void*)f_9376},
{"f_9430:chicken_syntax_scm",(void*)f_9430},
{"f_9391:chicken_syntax_scm",(void*)f_9391},
{"f_9354:chicken_syntax_scm",(void*)f_9354},
{"f_9319:chicken_syntax_scm",(void*)f_9319},
{"f_1943:chicken_syntax_scm",(void*)f_1943},
{"f_9228:chicken_syntax_scm",(void*)f_9228},
{"f_9232:chicken_syntax_scm",(void*)f_9232},
{"f_9311:chicken_syntax_scm",(void*)f_9311},
{"f_9226:chicken_syntax_scm",(void*)f_9226},
{"f_1946:chicken_syntax_scm",(void*)f_1946},
{"f_9210:chicken_syntax_scm",(void*)f_9210},
{"f_9218:chicken_syntax_scm",(void*)f_9218},
{"f_9208:chicken_syntax_scm",(void*)f_9208},
{"f_1949:chicken_syntax_scm",(void*)f_1949},
{"f_9189:chicken_syntax_scm",(void*)f_9189},
{"f_9193:chicken_syntax_scm",(void*)f_9193},
{"f_9187:chicken_syntax_scm",(void*)f_9187},
{"f_1952:chicken_syntax_scm",(void*)f_1952},
{"f_9087:chicken_syntax_scm",(void*)f_9087},
{"f_9091:chicken_syntax_scm",(void*)f_9091},
{"f_9097:chicken_syntax_scm",(void*)f_9097},
{"f_9106:chicken_syntax_scm",(void*)f_9106},
{"f_9166:chicken_syntax_scm",(void*)f_9166},
{"f_9141:chicken_syntax_scm",(void*)f_9141},
{"f_9085:chicken_syntax_scm",(void*)f_9085},
{"f_1955:chicken_syntax_scm",(void*)f_1955},
{"f_8956:chicken_syntax_scm",(void*)f_8956},
{"f_8960:chicken_syntax_scm",(void*)f_8960},
{"f_8972:chicken_syntax_scm",(void*)f_8972},
{"f_9019:chicken_syntax_scm",(void*)f_9019},
{"f_8954:chicken_syntax_scm",(void*)f_8954},
{"f_1958:chicken_syntax_scm",(void*)f_1958},
{"f_8276:chicken_syntax_scm",(void*)f_8276},
{"f_8280:chicken_syntax_scm",(void*)f_8280},
{"f_8917:chicken_syntax_scm",(void*)f_8917},
{"f_8946:chicken_syntax_scm",(void*)f_8946},
{"f_8289:chicken_syntax_scm",(void*)f_8289},
{"f_8873:chicken_syntax_scm",(void*)f_8873},
{"f_8911:chicken_syntax_scm",(void*)f_8911},
{"f_8900:chicken_syntax_scm",(void*)f_8900},
{"f_8908:chicken_syntax_scm",(void*)f_8908},
{"f_8292:chicken_syntax_scm",(void*)f_8292},
{"f_8829:chicken_syntax_scm",(void*)f_8829},
{"f_8867:chicken_syntax_scm",(void*)f_8867},
{"f_8856:chicken_syntax_scm",(void*)f_8856},
{"f_8864:chicken_syntax_scm",(void*)f_8864},
{"f_8295:chicken_syntax_scm",(void*)f_8295},
{"f_8794:chicken_syntax_scm",(void*)f_8794},
{"f_8823:chicken_syntax_scm",(void*)f_8823},
{"f_8743:chicken_syntax_scm",(void*)f_8743},
{"f_8745:chicken_syntax_scm",(void*)f_8745},
{"f_8778:chicken_syntax_scm",(void*)f_8778},
{"f_8758:chicken_syntax_scm",(void*)f_8758},
{"f_8654:chicken_syntax_scm",(void*)f_8654},
{"f_8721:chicken_syntax_scm",(void*)f_8721},
{"f_8735:chicken_syntax_scm",(void*)f_8735},
{"f_8666:chicken_syntax_scm",(void*)f_8666},
{"f_8668:chicken_syntax_scm",(void*)f_8668},
{"f_8701:chicken_syntax_scm",(void*)f_8701},
{"f_8681:chicken_syntax_scm",(void*)f_8681},
{"f_8662:chicken_syntax_scm",(void*)f_8662},
{"f_8658:chicken_syntax_scm",(void*)f_8658},
{"f_8306:chicken_syntax_scm",(void*)f_8306},
{"f_8590:chicken_syntax_scm",(void*)f_8590},
{"f_8603:chicken_syntax_scm",(void*)f_8603},
{"f_8510:chicken_syntax_scm",(void*)f_8510},
{"f_8528:chicken_syntax_scm",(void*)f_8528},
{"f_8541:chicken_syntax_scm",(void*)f_8541},
{"f_8518:chicken_syntax_scm",(void*)f_8518},
{"f_8514:chicken_syntax_scm",(void*)f_8514},
{"f_8506:chicken_syntax_scm",(void*)f_8506},
{"f_8498:chicken_syntax_scm",(void*)f_8498},
{"f_8430:chicken_syntax_scm",(void*)f_8430},
{"f_8443:chicken_syntax_scm",(void*)f_8443},
{"f_8350:chicken_syntax_scm",(void*)f_8350},
{"f_8368:chicken_syntax_scm",(void*)f_8368},
{"f_8381:chicken_syntax_scm",(void*)f_8381},
{"f_8358:chicken_syntax_scm",(void*)f_8358},
{"f_8354:chicken_syntax_scm",(void*)f_8354},
{"f_8346:chicken_syntax_scm",(void*)f_8346},
{"f_8274:chicken_syntax_scm",(void*)f_8274},
{"f_1961:chicken_syntax_scm",(void*)f_1961},
{"f_8158:chicken_syntax_scm",(void*)f_8158},
{"f_8162:chicken_syntax_scm",(void*)f_8162},
{"f_8266:chicken_syntax_scm",(void*)f_8266},
{"f_8171:chicken_syntax_scm",(void*)f_8171},
{"f_8174:chicken_syntax_scm",(void*)f_8174},
{"f_8177:chicken_syntax_scm",(void*)f_8177},
{"f_8217:chicken_syntax_scm",(void*)f_8217},
{"f_8240:chicken_syntax_scm",(void*)f_8240},
{"f_8247:chicken_syntax_scm",(void*)f_8247},
{"f_8254:chicken_syntax_scm",(void*)f_8254},
{"f_8230:chicken_syntax_scm",(void*)f_8230},
{"f_8180:chicken_syntax_scm",(void*)f_8180},
{"f_8156:chicken_syntax_scm",(void*)f_8156},
{"f_1964:chicken_syntax_scm",(void*)f_1964},
{"f_7678:chicken_syntax_scm",(void*)f_7678},
{"f_7682:chicken_syntax_scm",(void*)f_7682},
{"f_7691:chicken_syntax_scm",(void*)f_7691},
{"f_8119:chicken_syntax_scm",(void*)f_8119},
{"f_8148:chicken_syntax_scm",(void*)f_8148},
{"f_7694:chicken_syntax_scm",(void*)f_7694},
{"f_8084:chicken_syntax_scm",(void*)f_8084},
{"f_8113:chicken_syntax_scm",(void*)f_8113},
{"f_7697:chicken_syntax_scm",(void*)f_7697},
{"f_8040:chicken_syntax_scm",(void*)f_8040},
{"f_8078:chicken_syntax_scm",(void*)f_8078},
{"f_8067:chicken_syntax_scm",(void*)f_8067},
{"f_8075:chicken_syntax_scm",(void*)f_8075},
{"f_7700:chicken_syntax_scm",(void*)f_7700},
{"f_7996:chicken_syntax_scm",(void*)f_7996},
{"f_8034:chicken_syntax_scm",(void*)f_8034},
{"f_8023:chicken_syntax_scm",(void*)f_8023},
{"f_8031:chicken_syntax_scm",(void*)f_8031},
{"f_7703:chicken_syntax_scm",(void*)f_7703},
{"f_7947:chicken_syntax_scm",(void*)f_7947},
{"f_7980:chicken_syntax_scm",(void*)f_7980},
{"f_7960:chicken_syntax_scm",(void*)f_7960},
{"f_7892:chicken_syntax_scm",(void*)f_7892},
{"f_7898:chicken_syntax_scm",(void*)f_7898},
{"f_7931:chicken_syntax_scm",(void*)f_7931},
{"f_7911:chicken_syntax_scm",(void*)f_7911},
{"f_7896:chicken_syntax_scm",(void*)f_7896},
{"f_7714:chicken_syntax_scm",(void*)f_7714},
{"f_7788:chicken_syntax_scm",(void*)f_7788},
{"f_7801:chicken_syntax_scm",(void*)f_7801},
{"f_7786:chicken_syntax_scm",(void*)f_7786},
{"f_7782:chicken_syntax_scm",(void*)f_7782},
{"f_7762:chicken_syntax_scm",(void*)f_7762},
{"f_7676:chicken_syntax_scm",(void*)f_7676},
{"f_1967:chicken_syntax_scm",(void*)f_1967},
{"f_7641:chicken_syntax_scm",(void*)f_7641},
{"f_7645:chicken_syntax_scm",(void*)f_7645},
{"f_7668:chicken_syntax_scm",(void*)f_7668},
{"f_7639:chicken_syntax_scm",(void*)f_7639},
{"f_1970:chicken_syntax_scm",(void*)f_1970},
{"f_7596:chicken_syntax_scm",(void*)f_7596},
{"f_7600:chicken_syntax_scm",(void*)f_7600},
{"f_7631:chicken_syntax_scm",(void*)f_7631},
{"f_7594:chicken_syntax_scm",(void*)f_7594},
{"f_1973:chicken_syntax_scm",(void*)f_1973},
{"f_7371:chicken_syntax_scm",(void*)f_7371},
{"f_7375:chicken_syntax_scm",(void*)f_7375},
{"f_7553:chicken_syntax_scm",(void*)f_7553},
{"f_7582:chicken_syntax_scm",(void*)f_7582},
{"f_7450:chicken_syntax_scm",(void*)f_7450},
{"f_7483:chicken_syntax_scm",(void*)f_7483},
{"f_7496:chicken_syntax_scm",(void*)f_7496},
{"f_7481:chicken_syntax_scm",(void*)f_7481},
{"f_7477:chicken_syntax_scm",(void*)f_7477},
{"f_7369:chicken_syntax_scm",(void*)f_7369},
{"f_1976:chicken_syntax_scm",(void*)f_1976},
{"f_7329:chicken_syntax_scm",(void*)f_7329},
{"f_7333:chicken_syntax_scm",(void*)f_7333},
{"f_7353:chicken_syntax_scm",(void*)f_7353},
{"f_7361:chicken_syntax_scm",(void*)f_7361},
{"f_7336:chicken_syntax_scm",(void*)f_7336},
{"f_7343:chicken_syntax_scm",(void*)f_7343},
{"f_7347:chicken_syntax_scm",(void*)f_7347},
{"f_7327:chicken_syntax_scm",(void*)f_7327},
{"f_1979:chicken_syntax_scm",(void*)f_1979},
{"f_6810:chicken_syntax_scm",(void*)f_6810},
{"f_6814:chicken_syntax_scm",(void*)f_6814},
{"f_7290:chicken_syntax_scm",(void*)f_7290},
{"f_7319:chicken_syntax_scm",(void*)f_7319},
{"f_6895:chicken_syntax_scm",(void*)f_6895},
{"f_7250:chicken_syntax_scm",(void*)f_7250},
{"f_7263:chicken_syntax_scm",(void*)f_7263},
{"f_6898:chicken_syntax_scm",(void*)f_6898},
{"f_7202:chicken_syntax_scm",(void*)f_7202},
{"f_7244:chicken_syntax_scm",(void*)f_7244},
{"f_7229:chicken_syntax_scm",(void*)f_7229},
{"f_7241:chicken_syntax_scm",(void*)f_7241},
{"f_7237:chicken_syntax_scm",(void*)f_7237},
{"f_6901:chicken_syntax_scm",(void*)f_6901},
{"f_7156:chicken_syntax_scm",(void*)f_7156},
{"f_7189:chicken_syntax_scm",(void*)f_7189},
{"f_7196:chicken_syntax_scm",(void*)f_7196},
{"f_6913:chicken_syntax_scm",(void*)f_6913},
{"f_7116:chicken_syntax_scm",(void*)f_7116},
{"f_6920:chicken_syntax_scm",(void*)f_6920},
{"f_6922:chicken_syntax_scm",(void*)f_6922},
{"f_7110:chicken_syntax_scm",(void*)f_7110},
{"f_6994:chicken_syntax_scm",(void*)f_6994},
{"f_7076:chicken_syntax_scm",(void*)f_7076},
{"f_7033:chicken_syntax_scm",(void*)f_7033},
{"f_7013:chicken_syntax_scm",(void*)f_7013},
{"f_6946:chicken_syntax_scm",(void*)f_6946},
{"f_6984:chicken_syntax_scm",(void*)f_6984},
{"f_6973:chicken_syntax_scm",(void*)f_6973},
{"f_6981:chicken_syntax_scm",(void*)f_6981},
{"f_6940:chicken_syntax_scm",(void*)f_6940},
{"f_6944:chicken_syntax_scm",(void*)f_6944},
{"f_6902:chicken_syntax_scm",(void*)f_6902},
{"f_6853:chicken_syntax_scm",(void*)f_6853},
{"f_6876:chicken_syntax_scm",(void*)f_6876},
{"f_6880:chicken_syntax_scm",(void*)f_6880},
{"f_6822:chicken_syntax_scm",(void*)f_6822},
{"f_6843:chicken_syntax_scm",(void*)f_6843},
{"f_6808:chicken_syntax_scm",(void*)f_6808},
{"f_1982:chicken_syntax_scm",(void*)f_1982},
{"f_6741:chicken_syntax_scm",(void*)f_6741},
{"f_6745:chicken_syntax_scm",(void*)f_6745},
{"f_6754:chicken_syntax_scm",(void*)f_6754},
{"f_6759:chicken_syntax_scm",(void*)f_6759},
{"f_6796:chicken_syntax_scm",(void*)f_6796},
{"f_6777:chicken_syntax_scm",(void*)f_6777},
{"f_6739:chicken_syntax_scm",(void*)f_6739},
{"f_1985:chicken_syntax_scm",(void*)f_1985},
{"f_6376:chicken_syntax_scm",(void*)f_6376},
{"f_6380:chicken_syntax_scm",(void*)f_6380},
{"f_6697:chicken_syntax_scm",(void*)f_6697},
{"f_6695:chicken_syntax_scm",(void*)f_6695},
{"f_6389:chicken_syntax_scm",(void*)f_6389},
{"f_6645:chicken_syntax_scm",(void*)f_6645},
{"f_6687:chicken_syntax_scm",(void*)f_6687},
{"f_6672:chicken_syntax_scm",(void*)f_6672},
{"f_6684:chicken_syntax_scm",(void*)f_6684},
{"f_6680:chicken_syntax_scm",(void*)f_6680},
{"f_6392:chicken_syntax_scm",(void*)f_6392},
{"f_6605:chicken_syntax_scm",(void*)f_6605},
{"f_6412:chicken_syntax_scm",(void*)f_6412},
{"f_6426:chicken_syntax_scm",(void*)f_6426},
{"f_6599:chicken_syntax_scm",(void*)f_6599},
{"f_6453:chicken_syntax_scm",(void*)f_6453},
{"f_6551:chicken_syntax_scm",(void*)f_6551},
{"f_6481:chicken_syntax_scm",(void*)f_6481},
{"f_6495:chicken_syntax_scm",(void*)f_6495},
{"f_6522:chicken_syntax_scm",(void*)f_6522},
{"f_6489:chicken_syntax_scm",(void*)f_6489},
{"f_6485:chicken_syntax_scm",(void*)f_6485},
{"f_6420:chicken_syntax_scm",(void*)f_6420},
{"f_6424:chicken_syntax_scm",(void*)f_6424},
{"f_6416:chicken_syntax_scm",(void*)f_6416},
{"f_6393:chicken_syntax_scm",(void*)f_6393},
{"f_6374:chicken_syntax_scm",(void*)f_6374},
{"f_1988:chicken_syntax_scm",(void*)f_1988},
{"f_6370:chicken_syntax_scm",(void*)f_6370},
{"f_6296:chicken_syntax_scm",(void*)f_6296},
{"f_6300:chicken_syntax_scm",(void*)f_6300},
{"f_6303:chicken_syntax_scm",(void*)f_6303},
{"f_6338:chicken_syntax_scm",(void*)f_6338},
{"f_6294:chicken_syntax_scm",(void*)f_6294},
{"f_1991:chicken_syntax_scm",(void*)f_1991},
{"f_6176:chicken_syntax_scm",(void*)f_6176},
{"f_6282:chicken_syntax_scm",(void*)f_6282},
{"f_6278:chicken_syntax_scm",(void*)f_6278},
{"f_6179:chicken_syntax_scm",(void*)f_6179},
{"f_6183:chicken_syntax_scm",(void*)f_6183},
{"f_6258:chicken_syntax_scm",(void*)f_6258},
{"f_6192:chicken_syntax_scm",(void*)f_6192},
{"f_6224:chicken_syntax_scm",(void*)f_6224},
{"f_6220:chicken_syntax_scm",(void*)f_6220},
{"f_6204:chicken_syntax_scm",(void*)f_6204},
{"f_6195:chicken_syntax_scm",(void*)f_6195},
{"f_6174:chicken_syntax_scm",(void*)f_6174},
{"f_1994:chicken_syntax_scm",(void*)f_1994},
{"f_6023:chicken_syntax_scm",(void*)f_6023},
{"f_6027:chicken_syntax_scm",(void*)f_6027},
{"f_6038:chicken_syntax_scm",(void*)f_6038},
{"f_6079:chicken_syntax_scm",(void*)f_6079},
{"f_6146:chicken_syntax_scm",(void*)f_6146},
{"f_6108:chicken_syntax_scm",(void*)f_6108},
{"f_6052:chicken_syntax_scm",(void*)f_6052},
{"f_6021:chicken_syntax_scm",(void*)f_6021},
{"f_1997:chicken_syntax_scm",(void*)f_1997},
{"f_5808:chicken_syntax_scm",(void*)f_5808},
{"f_5812:chicken_syntax_scm",(void*)f_5812},
{"f_5821:chicken_syntax_scm",(void*)f_5821},
{"f_5824:chicken_syntax_scm",(void*)f_5824},
{"f_5827:chicken_syntax_scm",(void*)f_5827},
{"f_5848:chicken_syntax_scm",(void*)f_5848},
{"f_5873:chicken_syntax_scm",(void*)f_5873},
{"f_5879:chicken_syntax_scm",(void*)f_5879},
{"f_5955:chicken_syntax_scm",(void*)f_5955},
{"f_5982:chicken_syntax_scm",(void*)f_5982},
{"f_5949:chicken_syntax_scm",(void*)f_5949},
{"f_5945:chicken_syntax_scm",(void*)f_5945},
{"f_5937:chicken_syntax_scm",(void*)f_5937},
{"f_5933:chicken_syntax_scm",(void*)f_5933},
{"f_5906:chicken_syntax_scm",(void*)f_5906},
{"f_5899:chicken_syntax_scm",(void*)f_5899},
{"f_5902:chicken_syntax_scm",(void*)f_5902},
{"f_5882:chicken_syntax_scm",(void*)f_5882},
{"f_5889:chicken_syntax_scm",(void*)f_5889},
{"f_5846:chicken_syntax_scm",(void*)f_5846},
{"f_5806:chicken_syntax_scm",(void*)f_5806},
{"f_2000:chicken_syntax_scm",(void*)f_2000},
{"f_5802:chicken_syntax_scm",(void*)f_5802},
{"f_5798:chicken_syntax_scm",(void*)f_5798},
{"f_5224:chicken_syntax_scm",(void*)f_5224},
{"f_5228:chicken_syntax_scm",(void*)f_5228},
{"f_5537:chicken_syntax_scm",(void*)f_5537},
{"f_5540:chicken_syntax_scm",(void*)f_5540},
{"f_5749:chicken_syntax_scm",(void*)f_5749},
{"f_5778:chicken_syntax_scm",(void*)f_5778},
{"f_5543:chicken_syntax_scm",(void*)f_5543},
{"f_5705:chicken_syntax_scm",(void*)f_5705},
{"f_5743:chicken_syntax_scm",(void*)f_5743},
{"f_5732:chicken_syntax_scm",(void*)f_5732},
{"f_5740:chicken_syntax_scm",(void*)f_5740},
{"f_5559:chicken_syntax_scm",(void*)f_5559},
{"f_5670:chicken_syntax_scm",(void*)f_5670},
{"f_5699:chicken_syntax_scm",(void*)f_5699},
{"f_5562:chicken_syntax_scm",(void*)f_5562},
{"f_5565:chicken_syntax_scm",(void*)f_5565},
{"f_5568:chicken_syntax_scm",(void*)f_5568},
{"f_5626:chicken_syntax_scm",(void*)f_5626},
{"f_5664:chicken_syntax_scm",(void*)f_5664},
{"f_5653:chicken_syntax_scm",(void*)f_5653},
{"f_5661:chicken_syntax_scm",(void*)f_5661},
{"f_5571:chicken_syntax_scm",(void*)f_5571},
{"f_5247:chicken_syntax_scm",(void*)f_5247},
{"f_5251:chicken_syntax_scm",(void*)f_5251},
{"f_5255:chicken_syntax_scm",(void*)f_5255},
{"f_5257:chicken_syntax_scm",(void*)f_5257},
{"f_5310:chicken_syntax_scm",(void*)f_5310},
{"f_5326:chicken_syntax_scm",(void*)f_5326},
{"f_5322:chicken_syntax_scm",(void*)f_5322},
{"f_5278:chicken_syntax_scm",(void*)f_5278},
{"f_5574:chicken_syntax_scm",(void*)f_5574},
{"f_5577:chicken_syntax_scm",(void*)f_5577},
{"f_5584:chicken_syntax_scm",(void*)f_5584},
{"f_5544:chicken_syntax_scm",(void*)f_5544},
{"f_5556:chicken_syntax_scm",(void*)f_5556},
{"f_5552:chicken_syntax_scm",(void*)f_5552},
{"f_5336:chicken_syntax_scm",(void*)f_5336},
{"f_5342:chicken_syntax_scm",(void*)f_5342},
{"f_5530:chicken_syntax_scm",(void*)f_5530},
{"f_5518:chicken_syntax_scm",(void*)f_5518},
{"f_5502:chicken_syntax_scm",(void*)f_5502},
{"f_5466:chicken_syntax_scm",(void*)f_5466},
{"f_5416:chicken_syntax_scm",(void*)f_5416},
{"f_5404:chicken_syntax_scm",(void*)f_5404},
{"f_5222:chicken_syntax_scm",(void*)f_5222},
{"f_2003:chicken_syntax_scm",(void*)f_2003},
{"f_5214:chicken_syntax_scm",(void*)f_5214},
{"f_5210:chicken_syntax_scm",(void*)f_5210},
{"f_5206:chicken_syntax_scm",(void*)f_5206},
{"f_5006:chicken_syntax_scm",(void*)f_5006},
{"f_5010:chicken_syntax_scm",(void*)f_5010},
{"f_5013:chicken_syntax_scm",(void*)f_5013},
{"f_5166:chicken_syntax_scm",(void*)f_5166},
{"f_5051:chicken_syntax_scm",(void*)f_5051},
{"f_5127:chicken_syntax_scm",(void*)f_5127},
{"f_5139:chicken_syntax_scm",(void*)f_5139},
{"f_5111:chicken_syntax_scm",(void*)f_5111},
{"f_5004:chicken_syntax_scm",(void*)f_5004},
{"f_2006:chicken_syntax_scm",(void*)f_2006},
{"f_4996:chicken_syntax_scm",(void*)f_4996},
{"f_4698:chicken_syntax_scm",(void*)f_4698},
{"f_4702:chicken_syntax_scm",(void*)f_4702},
{"f_4714:chicken_syntax_scm",(void*)f_4714},
{"f_4717:chicken_syntax_scm",(void*)f_4717},
{"f_4720:chicken_syntax_scm",(void*)f_4720},
{"f_4723:chicken_syntax_scm",(void*)f_4723},
{"f_4744:chicken_syntax_scm",(void*)f_4744},
{"f_4972:chicken_syntax_scm",(void*)f_4972},
{"f_4834:chicken_syntax_scm",(void*)f_4834},
{"f_4853:chicken_syntax_scm",(void*)f_4853},
{"f_4810:chicken_syntax_scm",(void*)f_4810},
{"f_4742:chicken_syntax_scm",(void*)f_4742},
{"f_4696:chicken_syntax_scm",(void*)f_4696},
{"f_2009:chicken_syntax_scm",(void*)f_2009},
{"f_4688:chicken_syntax_scm",(void*)f_4688},
{"f_4684:chicken_syntax_scm",(void*)f_4684},
{"f_4680:chicken_syntax_scm",(void*)f_4680},
{"f_4676:chicken_syntax_scm",(void*)f_4676},
{"f_4159:chicken_syntax_scm",(void*)f_4159},
{"f_4163:chicken_syntax_scm",(void*)f_4163},
{"f_4200:chicken_syntax_scm",(void*)f_4200},
{"f_4599:chicken_syntax_scm",(void*)f_4599},
{"f_4636:chicken_syntax_scm",(void*)f_4636},
{"f_4640:chicken_syntax_scm",(void*)f_4640},
{"f_4593:chicken_syntax_scm",(void*)f_4593},
{"f_4203:chicken_syntax_scm",(void*)f_4203},
{"f_4206:chicken_syntax_scm",(void*)f_4206},
{"f_4209:chicken_syntax_scm",(void*)f_4209},
{"f_4212:chicken_syntax_scm",(void*)f_4212},
{"f_4215:chicken_syntax_scm",(void*)f_4215},
{"f_4218:chicken_syntax_scm",(void*)f_4218},
{"f_4221:chicken_syntax_scm",(void*)f_4221},
{"f_4224:chicken_syntax_scm",(void*)f_4224},
{"f_4235:chicken_syntax_scm",(void*)f_4235},
{"f_4261:chicken_syntax_scm",(void*)f_4261},
{"f_4271:chicken_syntax_scm",(void*)f_4271},
{"f_4275:chicken_syntax_scm",(void*)f_4275},
{"f_4289:chicken_syntax_scm",(void*)f_4289},
{"f_4313:chicken_syntax_scm",(void*)f_4313},
{"f_4389:chicken_syntax_scm",(void*)f_4389},
{"f_4537:chicken_syntax_scm",(void*)f_4537},
{"f_4457:chicken_syntax_scm",(void*)f_4457},
{"f_4476:chicken_syntax_scm",(void*)f_4476},
{"f_4446:chicken_syntax_scm",(void*)f_4446},
{"f_4414:chicken_syntax_scm",(void*)f_4414},
{"f_4317:chicken_syntax_scm",(void*)f_4317},
{"f_4340:chicken_syntax_scm",(void*)f_4340},
{"f_4373:chicken_syntax_scm",(void*)f_4373},
{"f_4353:chicken_syntax_scm",(void*)f_4353},
{"f_4334:chicken_syntax_scm",(void*)f_4334},
{"f_4303:chicken_syntax_scm",(void*)f_4303},
{"f_4311:chicken_syntax_scm",(void*)f_4311},
{"f_4297:chicken_syntax_scm",(void*)f_4297},
{"f_4259:chicken_syntax_scm",(void*)f_4259},
{"f_4165:chicken_syntax_scm",(void*)f_4165},
{"f_4171:chicken_syntax_scm",(void*)f_4171},
{"f_4197:chicken_syntax_scm",(void*)f_4197},
{"f_4185:chicken_syntax_scm",(void*)f_4185},
{"f_4189:chicken_syntax_scm",(void*)f_4189},
{"f_4157:chicken_syntax_scm",(void*)f_4157},
{"f_2012:chicken_syntax_scm",(void*)f_2012},
{"f_4061:chicken_syntax_scm",(void*)f_4061},
{"f_4065:chicken_syntax_scm",(void*)f_4065},
{"f_4126:chicken_syntax_scm",(void*)f_4126},
{"f_4141:chicken_syntax_scm",(void*)f_4141},
{"f_4080:chicken_syntax_scm",(void*)f_4080},
{"f_4111:chicken_syntax_scm",(void*)f_4111},
{"f_4059:chicken_syntax_scm",(void*)f_4059},
{"f_2015:chicken_syntax_scm",(void*)f_2015},
{"f_4055:chicken_syntax_scm",(void*)f_4055},
{"f_4051:chicken_syntax_scm",(void*)f_4051},
{"f_3850:chicken_syntax_scm",(void*)f_3850},
{"f_3854:chicken_syntax_scm",(void*)f_3854},
{"f_3857:chicken_syntax_scm",(void*)f_3857},
{"f_3860:chicken_syntax_scm",(void*)f_3860},
{"f_3871:chicken_syntax_scm",(void*)f_3871},
{"f_3899:chicken_syntax_scm",(void*)f_3899},
{"f_3991:chicken_syntax_scm",(void*)f_3991},
{"f_3848:chicken_syntax_scm",(void*)f_3848},
{"f_2018:chicken_syntax_scm",(void*)f_2018},
{"f_3840:chicken_syntax_scm",(void*)f_3840},
{"f_3836:chicken_syntax_scm",(void*)f_3836},
{"f_3433:chicken_syntax_scm",(void*)f_3433},
{"f_3437:chicken_syntax_scm",(void*)f_3437},
{"f_3440:chicken_syntax_scm",(void*)f_3440},
{"f_3443:chicken_syntax_scm",(void*)f_3443},
{"f_3446:chicken_syntax_scm",(void*)f_3446},
{"f_3449:chicken_syntax_scm",(void*)f_3449},
{"f_3452:chicken_syntax_scm",(void*)f_3452},
{"f_3661:chicken_syntax_scm",(void*)f_3661},
{"f_3701:chicken_syntax_scm",(void*)f_3701},
{"f_3735:chicken_syntax_scm",(void*)f_3735},
{"f_3764:chicken_syntax_scm",(void*)f_3764},
{"f_3709:chicken_syntax_scm",(void*)f_3709},
{"f_3705:chicken_syntax_scm",(void*)f_3705},
{"f_3454:chicken_syntax_scm",(void*)f_3454},
{"f_3578:chicken_syntax_scm",(void*)f_3578},
{"f_3605:chicken_syntax_scm",(void*)f_3605},
{"f_3576:chicken_syntax_scm",(void*)f_3576},
{"f_3572:chicken_syntax_scm",(void*)f_3572},
{"f_3564:chicken_syntax_scm",(void*)f_3564},
{"f_3545:chicken_syntax_scm",(void*)f_3545},
{"f_3515:chicken_syntax_scm",(void*)f_3515},
{"f_3496:chicken_syntax_scm",(void*)f_3496},
{"f_3431:chicken_syntax_scm",(void*)f_3431},
{"f_2021:chicken_syntax_scm",(void*)f_2021},
{"f_3423:chicken_syntax_scm",(void*)f_3423},
{"f_2874:chicken_syntax_scm",(void*)f_2874},
{"f_2878:chicken_syntax_scm",(void*)f_2878},
{"f_2893:chicken_syntax_scm",(void*)f_2893},
{"f_2896:chicken_syntax_scm",(void*)f_2896},
{"f_2902:chicken_syntax_scm",(void*)f_2902},
{"f_2905:chicken_syntax_scm",(void*)f_2905},
{"f_3382:chicken_syntax_scm",(void*)f_3382},
{"f_3411:chicken_syntax_scm",(void*)f_3411},
{"f_2908:chicken_syntax_scm",(void*)f_2908},
{"f_3335:chicken_syntax_scm",(void*)f_3335},
{"f_3362:chicken_syntax_scm",(void*)f_3362},
{"f_3333:chicken_syntax_scm",(void*)f_3333},
{"f_3329:chicken_syntax_scm",(void*)f_3329},
{"f_2937:chicken_syntax_scm",(void*)f_2937},
{"f_3251:chicken_syntax_scm",(void*)f_3251},
{"f_2956:chicken_syntax_scm",(void*)f_2956},
{"f_2962:chicken_syntax_scm",(void*)f_2962},
{"f_3067:chicken_syntax_scm",(void*)f_3067},
{"f_3060:chicken_syntax_scm",(void*)f_3060},
{"f_3029:chicken_syntax_scm",(void*)f_3029},
{"f_2977:chicken_syntax_scm",(void*)f_2977},
{"f_2985:chicken_syntax_scm",(void*)f_2985},
{"f_2981:chicken_syntax_scm",(void*)f_2981},
{"f_2973:chicken_syntax_scm",(void*)f_2973},
{"f_2935:chicken_syntax_scm",(void*)f_2935},
{"f_2931:chicken_syntax_scm",(void*)f_2931},
{"f_2872:chicken_syntax_scm",(void*)f_2872},
{"f_2024:chicken_syntax_scm",(void*)f_2024},
{"f_2864:chicken_syntax_scm",(void*)f_2864},
{"f_2680:chicken_syntax_scm",(void*)f_2680},
{"f_2684:chicken_syntax_scm",(void*)f_2684},
{"f_2687:chicken_syntax_scm",(void*)f_2687},
{"f_2690:chicken_syntax_scm",(void*)f_2690},
{"f_2699:chicken_syntax_scm",(void*)f_2699},
{"f_2802:chicken_syntax_scm",(void*)f_2802},
{"f_2830:chicken_syntax_scm",(void*)f_2830},
{"f_2824:chicken_syntax_scm",(void*)f_2824},
{"f_2805:chicken_syntax_scm",(void*)f_2805},
{"f_2709:chicken_syntax_scm",(void*)f_2709},
{"f_2712:chicken_syntax_scm",(void*)f_2712},
{"f_2784:chicken_syntax_scm",(void*)f_2784},
{"f_2761:chicken_syntax_scm",(void*)f_2761},
{"f_2718:chicken_syntax_scm",(void*)f_2718},
{"f_2729:chicken_syntax_scm",(void*)f_2729},
{"f_2749:chicken_syntax_scm",(void*)f_2749},
{"f_2678:chicken_syntax_scm",(void*)f_2678},
{"f_2027:chicken_syntax_scm",(void*)f_2027},
{"f_2670:chicken_syntax_scm",(void*)f_2670},
{"f_2455:chicken_syntax_scm",(void*)f_2455},
{"f_2459:chicken_syntax_scm",(void*)f_2459},
{"f_2462:chicken_syntax_scm",(void*)f_2462},
{"f_2465:chicken_syntax_scm",(void*)f_2465},
{"f_2474:chicken_syntax_scm",(void*)f_2474},
{"f_2593:chicken_syntax_scm",(void*)f_2593},
{"f_2621:chicken_syntax_scm",(void*)f_2621},
{"f_2654:chicken_syntax_scm",(void*)f_2654},
{"f_2627:chicken_syntax_scm",(void*)f_2627},
{"f_2615:chicken_syntax_scm",(void*)f_2615},
{"f_2596:chicken_syntax_scm",(void*)f_2596},
{"f_2484:chicken_syntax_scm",(void*)f_2484},
{"f_2487:chicken_syntax_scm",(void*)f_2487},
{"f_2583:chicken_syntax_scm",(void*)f_2583},
{"f_2548:chicken_syntax_scm",(void*)f_2548},
{"f_2493:chicken_syntax_scm",(void*)f_2493},
{"f_2516:chicken_syntax_scm",(void*)f_2516},
{"f_2536:chicken_syntax_scm",(void*)f_2536},
{"f_2453:chicken_syntax_scm",(void*)f_2453},
{"f_2030:chicken_syntax_scm",(void*)f_2030},
{"f_2354:chicken_syntax_scm",(void*)f_2354},
{"f_2358:chicken_syntax_scm",(void*)f_2358},
{"f_2441:chicken_syntax_scm",(void*)f_2441},
{"f_2414:chicken_syntax_scm",(void*)f_2414},
{"f_2352:chicken_syntax_scm",(void*)f_2352},
{"f_2033:chicken_syntax_scm",(void*)f_2033},
{"f_2317:chicken_syntax_scm",(void*)f_2317},
{"f_2321:chicken_syntax_scm",(void*)f_2321},
{"f_2328:chicken_syntax_scm",(void*)f_2328},
{"f_2340:chicken_syntax_scm",(void*)f_2340},
{"f_2344:chicken_syntax_scm",(void*)f_2344},
{"f_2315:chicken_syntax_scm",(void*)f_2315},
{"f_2036:chicken_syntax_scm",(void*)f_2036},
{"f_2292:chicken_syntax_scm",(void*)f_2292},
{"f_2296:chicken_syntax_scm",(void*)f_2296},
{"f_2290:chicken_syntax_scm",(void*)f_2290},
{"f_2039:chicken_syntax_scm",(void*)f_2039},
{"f_2126:chicken_syntax_scm",(void*)f_2126},
{"f_2136:chicken_syntax_scm",(void*)f_2136},
{"f_2160:chicken_syntax_scm",(void*)f_2160},
{"f_2210:chicken_syntax_scm",(void*)f_2210},
{"f_2223:chicken_syntax_scm",(void*)f_2223},
{"f_2176:chicken_syntax_scm",(void*)f_2176},
{"f_2192:chicken_syntax_scm",(void*)f_2192},
{"f_2146:chicken_syntax_scm",(void*)f_2146},
{"f_2124:chicken_syntax_scm",(void*)f_2124},
{"f_2042:chicken_syntax_scm",(void*)f_2042},
{"f_2070:chicken_syntax_scm",(void*)f_2070},
{"f_2109:chicken_syntax_scm",(void*)f_2109},
{"f_2080:chicken_syntax_scm",(void*)f_2080},
{"f_2093:chicken_syntax_scm",(void*)f_2093},
{"f_2068:chicken_syntax_scm",(void*)f_2068},
{"f_2045:chicken_syntax_scm",(void*)f_2045},
{"f_2060:chicken_syntax_scm",(void*)f_2060},
{"f_2058:chicken_syntax_scm",(void*)f_2058},
{"f_2048:chicken_syntax_scm",(void*)f_2048},
{"f_2051:chicken_syntax_scm",(void*)f_2051},
{"f_2054:chicken_syntax_scm",(void*)f_2054},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
