/* Generated from optimizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: optimizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file optimizer.c
   unit: optimizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[268];
static double C_possibly_force_alignment;


C_noret_decl(C_optimizer_toplevel)
C_externexport void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3221)
static void C_ccall f_3221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3570)
static void C_ccall f_3570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14208)
static void C_ccall f_14208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_14216)
static void C_ccall f_14216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14221)
static void C_fcall f_14221(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14271)
static void C_ccall f_14271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14275)
static void C_ccall f_14275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14231)
static void C_ccall f_14231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_14235)
static void C_fcall f_14235(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_14257)
static void C_ccall f_14257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5819)
static void C_ccall f_5819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13117)
static void C_ccall f_13117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_13163)
static void C_ccall f_13163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13265)
static void C_ccall f_13265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13275)
static void C_fcall f_13275(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13612)
static void C_ccall f_13612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13604)
static void C_ccall f_13604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13381)
static void C_ccall f_13381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13410)
static void C_fcall f_13410(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_13580)
static void C_ccall f_13580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13572)
static void C_ccall f_13572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13441)
static void C_fcall f_13441(C_word t0,C_word t1) C_noret;
C_noret_decl(f_13494)
static void C_ccall f_13494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_13484)
static void C_ccall f_13484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13492)
static void C_ccall f_13492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13666)
static void C_ccall f_13666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10) C_noret;
C_noret_decl(f_13679)
static void C_ccall f_13679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13721)
static void C_ccall f_13721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13705)
static void C_ccall f_13705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13709)
static void C_ccall f_13709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13701)
static void C_ccall f_13701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13887)
static void C_ccall f_13887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13) C_noret;
C_noret_decl(f_13900)
static void C_ccall f_13900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13906)
static void C_ccall f_13906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13958)
static void C_ccall f_13958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13950)
static void C_ccall f_13950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13934)
static void C_ccall f_13934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13938)
static void C_ccall f_13938(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_13942)
static void C_ccall f_13942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5822)
static void C_ccall f_5822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12758)
static void C_ccall f_12758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_12780)
static void C_ccall f_12780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12860)
static void C_ccall f_12860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12818)
static void C_ccall f_12818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12852)
static void C_ccall f_12852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12856)
static void C_ccall f_12856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12844)
static void C_ccall f_12844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12816)
static void C_ccall f_12816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12954)
static void C_ccall f_12954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9) C_noret;
C_noret_decl(f_12974)
static void C_ccall f_12974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5825)
static void C_ccall f_5825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6314)
static void C_ccall f_6314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10136)
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12631)
static void C_ccall f_12631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12634)
static void C_ccall f_12634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12637)
static void C_ccall f_12637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12640)
static void C_ccall f_12640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12643)
static void C_ccall f_12643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12646)
static void C_ccall f_12646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12729)
static void C_ccall f_12729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12649)
static void C_ccall f_12649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12652)
static void C_ccall f_12652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12655)
static void C_ccall f_12655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12723)
static void C_ccall f_12723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12658)
static void C_ccall f_12658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12661)
static void C_ccall f_12661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12720)
static void C_ccall f_12720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10910)
static void C_fcall f_10910(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10928)
static void C_ccall f_10928(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10934)
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10914)
static void C_ccall f_10914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12664)
static void C_ccall f_12664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12712)
static void C_ccall f_12712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12710)
static void C_ccall f_12710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12667)
static void C_ccall f_12667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12670)
static void C_ccall f_12670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12673)
static void C_ccall f_12673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12697)
static void C_ccall f_12697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12676)
static void C_ccall f_12676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12679)
static void C_ccall f_12679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12682)
static void C_ccall f_12682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12685)
static void C_ccall f_12685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12688)
static void C_ccall f_12688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12691)
static void C_ccall f_12691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12390)
static void C_fcall f_12390(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12396)
static void C_fcall f_12396(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12607)
static void C_fcall f_12607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12617)
static void C_ccall f_12617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12581)
static void C_fcall f_12581(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12591)
static void C_ccall f_12591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12551)
static void C_ccall f_12551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12560)
static void C_ccall f_12560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12563)
static void C_ccall f_12563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12521)
static void C_fcall f_12521(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12531)
static void C_ccall f_12531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12430)
static void C_ccall f_12430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12435)
static void C_fcall f_12435(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12473)
static void C_ccall f_12473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12458)
static void C_ccall f_12458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12469)
static void C_ccall f_12469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12465)
static void C_ccall f_12465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12192)
static void C_fcall f_12192(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12198)
static void C_fcall f_12198(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12367)
static void C_fcall f_12367(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12377)
static void C_ccall f_12377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12307)
static void C_fcall f_12307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12336)
static void C_ccall f_12336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12297)
static void C_ccall f_12297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12293)
static void C_ccall f_12293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12235)
static void C_ccall f_12235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12249)
static void C_fcall f_12249(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12259)
static void C_ccall f_12259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11664)
static void C_fcall f_11664(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11678)
static void C_ccall f_11678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11685)
static void C_ccall f_11685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11688)
static void C_ccall f_11688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11697)
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11849)
static void C_fcall f_11849(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11704)
static void C_ccall f_11704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11800)
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11833)
static void C_ccall f_11833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11813)
static void C_fcall f_11813(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11707)
static void C_ccall f_11707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11928)
static void C_fcall f_11928(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12169)
static void C_fcall f_12169(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12179)
static void C_ccall f_12179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12110)
static void C_ccall f_12110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12131)
static void C_fcall f_12131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12129)
static void C_ccall f_12129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12125)
static void C_ccall f_12125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12057)
static void C_ccall f_12057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12062)
static void C_fcall f_12062(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12072)
static void C_ccall f_12072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11994)
static void C_fcall f_11994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11992)
static void C_ccall f_11992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11962)
static void C_ccall f_11962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11967)
static void C_fcall f_11967(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11977)
static void C_ccall f_11977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11913)
static C_word C_fcall f_11913(C_word t0,C_word t1);
C_noret_decl(f_11710)
static void C_ccall f_11710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11785)
static void C_ccall f_11785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11773)
static void C_ccall f_11773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11769)
static void C_ccall f_11769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11676)
static void C_ccall f_11676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11255)
static void C_fcall f_11255(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11616)
static void C_fcall f_11616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11381)
static void C_ccall f_11381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11593)
static void C_fcall f_11593(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11603)
static void C_ccall f_11603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11514)
static void C_ccall f_11514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11519)
static void C_fcall f_11519(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11587)
static void C_ccall f_11587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11546)
static void C_fcall f_11546(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11584)
static void C_ccall f_11584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11264)
static void C_fcall f_11264(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11357)
static void C_fcall f_11357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11367)
static void C_ccall f_11367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11340)
static void C_ccall f_11340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11345)
static void C_ccall f_11345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11299)
static void C_ccall f_11299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11304)
static void C_fcall f_11304(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11314)
static void C_ccall f_11314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11262)
static void C_ccall f_11262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11576)
static void C_ccall f_11576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11562)
static void C_ccall f_11562(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11560)
static void C_ccall f_11560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11383)
static void C_fcall f_11383(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11507)
static void C_ccall f_11507(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11505)
static void C_ccall f_11505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11471)
static void C_fcall f_11471(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11490)
static void C_ccall f_11490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11479)
static void C_fcall f_11479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11403)
static void C_ccall f_11403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11427)
static void C_fcall f_11427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11454)
static C_word C_fcall f_11454(C_word t0,C_word t1);
C_noret_decl(f_11425)
static void C_ccall f_11425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11421)
static void C_ccall f_11421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11413)
static void C_ccall f_11413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10944)
static void C_fcall f_10944(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10950)
static void C_fcall f_10950(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10984)
static void C_fcall f_10984(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11206)
static void C_fcall f_11206(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11221)
static void C_ccall f_11221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11214)
static void C_fcall f_11214(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11103)
static void C_ccall f_11103(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11119)
static void C_fcall f_11119(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11172)
static void C_ccall f_11172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11176)
static void C_ccall f_11176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11139)
static void C_ccall f_11139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11148)
static void C_fcall f_11148(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11158)
static void C_ccall f_11158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11070)
static void C_ccall f_11070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11075)
static void C_fcall f_11075(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11090)
static void C_ccall f_11090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11083)
static void C_fcall f_11083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11046)
static void C_ccall f_11046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11058)
static void C_ccall f_11058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10995)
static void C_fcall f_10995(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11016)
static void C_ccall f_11016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11013)
static void C_ccall f_11013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10948)
static void C_ccall f_10948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10663)
static void C_fcall f_10663(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10669)
static void C_fcall f_10669(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10703)
static void C_fcall f_10703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10805)
static void C_fcall f_10805(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10820)
static void C_ccall f_10820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10813)
static void C_fcall f_10813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10796)
static void C_ccall f_10796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10762)
static void C_fcall f_10762(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10771)
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10783)
static void C_ccall f_10783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10714)
static void C_fcall f_10714(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10735)
static void C_ccall f_10735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10732)
static void C_ccall f_10732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10667)
static void C_ccall f_10667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10530)
static void C_fcall f_10530(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10536)
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10580)
static void C_ccall f_10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10585)
static void C_fcall f_10585(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10592)
static void C_ccall f_10592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10653)
static void C_ccall f_10653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10649)
static void C_ccall f_10649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10607)
static void C_fcall f_10607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10641)
static void C_ccall f_10641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10634)
static void C_fcall f_10634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10605)
static void C_ccall f_10605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10570)
static void C_ccall f_10570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10548)
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10555)
static void C_ccall f_10555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10242)
static void C_fcall f_10242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10455)
static void C_fcall f_10455(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10517)
static void C_ccall f_10517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10463)
static void C_fcall f_10463(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10488)
static void C_ccall f_10488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10478)
static void C_ccall f_10478(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10482)
static void C_ccall f_10482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10453)
static void C_ccall f_10453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10245)
static void C_fcall f_10245(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10421)
static void C_fcall f_10421(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10436)
static void C_ccall f_10436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10429)
static void C_fcall f_10429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10404)
static void C_ccall f_10404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_10416)
static void C_ccall f_10416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10350)
static void C_fcall f_10350(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10374)
static void C_ccall f_10374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10368)
static void C_ccall f_10368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10285)
static void C_fcall f_10285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10288)
static void C_fcall f_10288(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10293)
static void C_fcall f_10293(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10308)
static void C_ccall f_10308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10301)
static void C_fcall f_10301(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10139)
static void C_fcall f_10139(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10145)
static void C_ccall f_10145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10173)
static void C_fcall f_10173(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10177)
static void C_ccall f_10177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10181)
static void C_ccall f_10181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10143)
static void C_ccall f_10143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8751)
static void C_ccall f_8751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10131)
static void C_ccall f_10131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10134)
static void C_ccall f_10134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9407)
static void C_fcall f_9407(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7) C_noret;
C_noret_decl(f_10121)
static void C_ccall f_10121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10119)
static void C_ccall f_10119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9411)
static void C_ccall f_9411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9426)
static void C_ccall f_9426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9435)
static void C_fcall f_9435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9441)
static void C_ccall f_9441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9444)
static void C_ccall f_9444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9450)
static void C_ccall f_9450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9733)
static void C_fcall f_9733(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10048)
static void C_fcall f_10048(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10058)
static void C_ccall f_10058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10022)
static void C_fcall f_10022(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10032)
static void C_ccall f_10032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10007)
static void C_ccall f_10007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10010)
static void C_ccall f_10010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9955)
static void C_ccall f_9955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9958)
static void C_ccall f_9958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9802)
static void C_ccall f_9802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9849)
static void C_fcall f_9849(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9859)
static void C_ccall f_9859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9862)
static void C_ccall f_9862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9896)
static void C_ccall f_9896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9865)
static void C_ccall f_9865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9868)
static void C_ccall f_9868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9811)
static void C_ccall f_9811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9814)
static void C_ccall f_9814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9817)
static void C_ccall f_9817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9453)
static void C_ccall f_9453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9715)
static void C_ccall f_9715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9624)
static void C_ccall f_9624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9626)
static void C_fcall f_9626(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9702)
static void C_ccall f_9702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9634)
static void C_fcall f_9634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9649)
static void C_ccall f_9649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9456)
static void C_ccall f_9456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9473)
static void C_ccall f_9473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9544)
static void C_ccall f_9544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9476)
static void C_ccall f_9476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9479)
static void C_ccall f_9479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9484)
static void C_fcall f_9484(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9528)
static void C_ccall f_9528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_fcall f_8953(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_9398)
static void C_ccall f_9398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9405)
static void C_ccall f_9405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8956)
static void C_fcall f_8956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_9385)
static void C_ccall f_9385(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9361)
static void C_ccall f_9361(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9372)
static void C_ccall f_9372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9328)
static void C_ccall f_9328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9219)
static void C_fcall f_9219(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9224)
static void C_ccall f_9224(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9166)
static void C_ccall f_9166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_fcall f_9172(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9177)
static void C_ccall f_9177(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_fcall f_9131(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9136)
static void C_ccall f_9136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9109)
static void C_ccall f_9109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9105)
static void C_ccall f_9105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9075)
static void C_ccall f_9075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9038)
static void C_ccall f_9038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_9054)
static void C_ccall f_9054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9020)
static void C_ccall f_9020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8754)
static void C_fcall f_8754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8925)
static void C_fcall f_8925(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8940)
static void C_ccall f_8940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8933)
static void C_fcall f_8933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8879)
static void C_ccall f_8879(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8825)
static void C_ccall f_8825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8831)
static void C_ccall f_8831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8837)
static void C_ccall f_8837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8794)
static void C_ccall f_8794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6336)
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_8618)
static void C_ccall f_8618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8647)
static void C_ccall f_8647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8659)
static void C_ccall f_8659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8673)
static void C_fcall f_8673(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8722)
static void C_ccall f_8722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6361)
static void C_fcall f_6361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8693)
static void C_ccall f_8693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8697)
static void C_ccall f_8697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8667)
static void C_ccall f_8667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8653)
static void C_ccall f_8653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8651)
static void C_ccall f_8651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8643)
static void C_ccall f_8643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8538)
static void C_ccall f_8538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8582)
static void C_ccall f_8582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8343)
static void C_ccall f_8343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8349)
static void C_ccall f_8349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8465)
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8358)
static void C_ccall f_8358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8420)
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8418)
static void C_ccall f_8418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static void C_ccall f_8380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8258)
static void C_ccall f_8258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8299)
static void C_ccall f_8299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8311)
static void C_ccall f_8311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8289)
static void C_ccall f_8289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8287)
static void C_ccall f_8287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8182)
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8085)
static void C_ccall f_8085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8156)
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8154)
static void C_ccall f_8154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8107)
static void C_ccall f_8107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8036)
static void C_ccall f_8036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8052)
static void C_ccall f_8052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7957)
static void C_ccall f_7957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7986)
static void C_fcall f_7986(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7812)
static void C_ccall f_7812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7835)
static void C_ccall f_7835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7899)
static void C_fcall f_7899(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7873)
static void C_ccall f_7873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7869)
static void C_fcall f_7869(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7727)
static void C_ccall f_7727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7749)
static void C_ccall f_7749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7633)
static void C_ccall f_7633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7556)
static void C_ccall f_7556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7580)
static void C_fcall f_7580(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7584)
static void C_ccall f_7584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7468)
static void C_ccall f_7468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7524)
static void C_ccall f_7524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7520)
static void C_ccall f_7520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7397)
static void C_ccall f_7397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7409)
static void C_fcall f_7409(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7429)
static void C_ccall f_7429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7298)
static void C_ccall f_7298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7327)
static void C_ccall f_7327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7335)
static void C_ccall f_7335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7339)
static void C_ccall f_7339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7055)
static void C_ccall f_7055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7083)
static void C_fcall f_7083(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7086)
static void C_fcall f_7086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7199)
static void C_fcall f_7199(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7233)
static void C_ccall f_7233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7089)
static void C_ccall f_7089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7164)
static void C_fcall f_7164(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7193)
static void C_ccall f_7193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7092)
static void C_ccall f_7092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7136)
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7134)
static void C_ccall f_7134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7097)
static void C_ccall f_7097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7077)
static void C_ccall f_7077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7029)
static void C_ccall f_7029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6956)
static void C_ccall f_6956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6993)
static void C_ccall f_6993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_ccall f_6985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6867)
static void C_ccall f_6867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6762)
static void C_ccall f_6762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6817)
static void C_ccall f_6817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6694)
static void C_ccall f_6694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6714)
static void C_ccall f_6714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6722)
static void C_ccall f_6722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6618)
static void C_ccall f_6618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6623)
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6644)
static void C_ccall f_6644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6398)
static void C_ccall f_6398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6401)
static void C_fcall f_6401(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_6316)
static void C_ccall f_6316r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_6320)
static void C_ccall f_6320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_ccall f_6330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6263)
static void C_fcall f_6263(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6296)
static void C_ccall f_6296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6276)
static void C_fcall f_6276(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5831)
static void C_ccall f_5831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6216)
static void C_fcall f_6216(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6236)
static void C_ccall f_6236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6224)
static void C_fcall f_6224(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6233)
static void C_ccall f_6233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6229)
static void C_ccall f_6229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6136)
static void C_fcall f_6136(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6203)
static void C_ccall f_6203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6144)
static void C_fcall f_6144(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6176)
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6189)
static void C_ccall f_6189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6154)
static void C_ccall f_6154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6170)
static void C_ccall f_6170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6158)
static void C_ccall f_6158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6162)
static void C_ccall f_6162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6055)
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6123)
static void C_ccall f_6123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6063)
static void C_fcall f_6063(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6112)
static void C_ccall f_6112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6070)
static void C_ccall f_6070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6080)
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6093)
static void C_ccall f_6093(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6078)
static void C_ccall f_6078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6074)
static void C_ccall f_6074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5884)
static void C_ccall f_5884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5887)
static void C_ccall f_5887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5907)
static void C_ccall f_5907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5920)
static void C_fcall f_5920(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5981)
static void C_ccall f_5981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6027)
static void C_ccall f_6027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5979)
static void C_ccall f_5979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5949)
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5890)
static void C_ccall f_5890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5899)
static void C_ccall f_5899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5833)
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5839)
static void C_fcall f_5839(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5493)
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_fcall f_5547(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5565)
static void C_ccall f_5565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5574)
static void C_fcall f_5574(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5594)
static void C_fcall f_5594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5606)
static void C_fcall f_5606(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5615)
static void C_fcall f_5615(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5496)
static C_word C_fcall f_5496(C_word t0);
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5375)
static void C_ccall f_5375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5381)
static void C_ccall f_5381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5385)
static void C_ccall f_5385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5388)
static void C_ccall f_5388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5424)
static void C_ccall f_5424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5429)
static void C_fcall f_5429(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5441)
static void C_ccall f_5441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5468)
static void C_ccall f_5468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5391)
static void C_ccall f_5391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5394)
static void C_ccall f_5394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5397)
static void C_ccall f_5397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5345)
static void C_fcall f_5345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_5365)
static void C_ccall f_5365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5349)
static void C_ccall f_5349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4028)
static void C_fcall f_4028(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5235)
static void C_ccall f_5235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5238)
static void C_ccall f_5238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5337)
static void C_ccall f_5337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5295)
static void C_fcall f_5295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5322)
static void C_ccall f_5322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5314)
static void C_ccall f_5314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5255)
static void C_fcall f_5255(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5261)
static void C_ccall f_5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5209)
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_ccall f_5167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4410)
static void C_ccall f_4410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4419)
static void C_ccall f_4419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_fcall f_4706(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4722)
static void C_ccall f_4722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5127)
static void C_ccall f_5127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5101)
static void C_ccall f_5101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5074)
static void C_ccall f_5074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_fcall f_4973(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5038)
static void C_ccall f_5038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5018)
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5016)
static void C_ccall f_5016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4809)
static void C_fcall f_4809(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4854)
static void C_ccall f_4854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4886)
static void C_ccall f_4886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4848)
static void C_ccall f_4848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4743)
static void C_ccall f_4743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4777)
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4746)
static void C_ccall f_4746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4752)
static void C_ccall f_4752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_fcall f_4502(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4662)
static void C_ccall f_4662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4538)
static void C_ccall f_4538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4541)
static void C_fcall f_4541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4597)
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4595)
static void C_ccall f_4595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4578)
static void C_ccall f_4578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4487)
static void C_fcall f_4487(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4314)
static void C_ccall f_4314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4319)
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4326)
static void C_ccall f_4326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4366)
static void C_ccall f_4366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4346)
static void C_ccall f_4346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4265)
static void C_ccall f_4265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4149)
static void C_ccall f_4149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_fcall f_4152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_fcall f_4068(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4072)
static void C_ccall f_4072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4084)
static void C_ccall f_4084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3747)
static void C_fcall f_3747(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3761)
static void C_ccall f_3761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3927)
static void C_ccall f_3927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3913)
static void C_ccall f_3913r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3919)
static void C_ccall f_3919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3888)
static void C_ccall f_3888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3858)
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3864)
static void C_ccall f_3864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_fcall f_3868(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3872)
static void C_ccall f_3872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3780)
static void C_ccall f_3780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3620)
static void C_ccall f_3620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3641)
static void C_ccall f_3641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3690)
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3717)
static C_word C_fcall f_3717(C_word t0,C_word t1);
C_noret_decl(f_3688)
static void C_ccall f_3688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3647)
static void C_ccall f_3647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3623)
static void C_ccall f_3623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3612)
static C_word C_fcall f_3612(C_word t0);
C_noret_decl(f_3582)
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3576)
static void C_fcall f_3576(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3517)
static void C_ccall f_3517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3566)
static void C_ccall f_3566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3520)
static void C_ccall f_3520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_fcall f_3295(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3376)
static void C_fcall f_3376(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3426)
static void C_fcall f_3426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3453)
static void C_ccall f_3453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3471)
static void C_fcall f_3471(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3459)
static void C_ccall f_3459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3402)
static void C_ccall f_3402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3413)
static void C_ccall f_3413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3349)
static void C_fcall f_3349(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3332)
static void C_fcall f_3332(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3336)
static void C_ccall f_3336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3261)
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3267)
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3282)
static void C_ccall f_3282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3256)
static C_word C_fcall f_3256(C_word t0);
C_noret_decl(f_3249)
static void C_fcall f_3249(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3226)
static void C_fcall f_3226(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3233)
static void C_fcall f_3233(C_word t0,C_word t1) C_noret;

C_noret_decl(trf_14221)
static void C_fcall trf_14221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14221(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14221(t0,t1,t2);}

C_noret_decl(trf_14235)
static void C_fcall trf_14235(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_14235(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_14235(t0,t1,t2);}

C_noret_decl(trf_13275)
static void C_fcall trf_13275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13275(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_13275(t0,t1,t2,t3);}

C_noret_decl(trf_13410)
static void C_fcall trf_13410(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13410(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_13410(t0,t1,t2,t3,t4);}

C_noret_decl(trf_13441)
static void C_fcall trf_13441(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_13441(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_13441(t0,t1);}

C_noret_decl(trf_10910)
static void C_fcall trf_10910(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10910(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10910(t0,t1,t2,t3);}

C_noret_decl(trf_12390)
static void C_fcall trf_12390(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12390(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12390(t0,t1,t2);}

C_noret_decl(trf_12396)
static void C_fcall trf_12396(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12396(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12396(t0,t1,t2);}

C_noret_decl(trf_12607)
static void C_fcall trf_12607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12607(t0,t1,t2);}

C_noret_decl(trf_12581)
static void C_fcall trf_12581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12581(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12581(t0,t1,t2);}

C_noret_decl(trf_12521)
static void C_fcall trf_12521(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12521(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12521(t0,t1,t2);}

C_noret_decl(trf_12435)
static void C_fcall trf_12435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12435(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12435(t0,t1,t2,t3);}

C_noret_decl(trf_12192)
static void C_fcall trf_12192(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12192(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12192(t0,t1,t2);}

C_noret_decl(trf_12198)
static void C_fcall trf_12198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12198(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12198(t0,t1,t2);}

C_noret_decl(trf_12367)
static void C_fcall trf_12367(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12367(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12367(t0,t1,t2);}

C_noret_decl(trf_12307)
static void C_fcall trf_12307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12307(t0,t1,t2);}

C_noret_decl(trf_12249)
static void C_fcall trf_12249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12249(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12249(t0,t1,t2);}

C_noret_decl(trf_11664)
static void C_fcall trf_11664(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11664(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11664(t0,t1,t2,t3);}

C_noret_decl(trf_11849)
static void C_fcall trf_11849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11849(t0,t1,t2);}

C_noret_decl(trf_11800)
static void C_fcall trf_11800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11800(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11800(t0,t1,t2,t3);}

C_noret_decl(trf_11813)
static void C_fcall trf_11813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11813(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11813(t0,t1);}

C_noret_decl(trf_11928)
static void C_fcall trf_11928(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11928(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11928(t0,t1,t2);}

C_noret_decl(trf_12169)
static void C_fcall trf_12169(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12169(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12169(t0,t1,t2);}

C_noret_decl(trf_12131)
static void C_fcall trf_12131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12131(t0,t1,t2);}

C_noret_decl(trf_12062)
static void C_fcall trf_12062(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12062(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12062(t0,t1,t2);}

C_noret_decl(trf_11994)
static void C_fcall trf_11994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11994(t0,t1,t2);}

C_noret_decl(trf_11967)
static void C_fcall trf_11967(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11967(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11967(t0,t1,t2);}

C_noret_decl(trf_11255)
static void C_fcall trf_11255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11255(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11255(t0,t1,t2);}

C_noret_decl(trf_11616)
static void C_fcall trf_11616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11616(t0,t1,t2);}

C_noret_decl(trf_11593)
static void C_fcall trf_11593(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11593(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11593(t0,t1,t2);}

C_noret_decl(trf_11519)
static void C_fcall trf_11519(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11519(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11519(t0,t1,t2);}

C_noret_decl(trf_11546)
static void C_fcall trf_11546(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11546(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11546(t0,t1,t2);}

C_noret_decl(trf_11264)
static void C_fcall trf_11264(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11264(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11264(t0,t1,t2);}

C_noret_decl(trf_11357)
static void C_fcall trf_11357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11357(t0,t1,t2);}

C_noret_decl(trf_11304)
static void C_fcall trf_11304(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11304(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11304(t0,t1,t2);}

C_noret_decl(trf_11383)
static void C_fcall trf_11383(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11383(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11383(t0,t1,t2);}

C_noret_decl(trf_11471)
static void C_fcall trf_11471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11471(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11471(t0,t1,t2);}

C_noret_decl(trf_11479)
static void C_fcall trf_11479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11479(t0,t1,t2);}

C_noret_decl(trf_11427)
static void C_fcall trf_11427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11427(t0,t1,t2);}

C_noret_decl(trf_10944)
static void C_fcall trf_10944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10944(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10944(t0,t1,t2);}

C_noret_decl(trf_10950)
static void C_fcall trf_10950(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10950(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10950(t0,t1,t2,t3);}

C_noret_decl(trf_10984)
static void C_fcall trf_10984(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10984(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10984(t0,t1);}

C_noret_decl(trf_11206)
static void C_fcall trf_11206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11206(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11206(t0,t1,t2);}

C_noret_decl(trf_11214)
static void C_fcall trf_11214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11214(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11214(t0,t1,t2);}

C_noret_decl(trf_11119)
static void C_fcall trf_11119(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11119(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11119(t0,t1,t2);}

C_noret_decl(trf_11148)
static void C_fcall trf_11148(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11148(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11148(t0,t1,t2);}

C_noret_decl(trf_11075)
static void C_fcall trf_11075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11075(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11075(t0,t1,t2);}

C_noret_decl(trf_11083)
static void C_fcall trf_11083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11083(t0,t1,t2);}

C_noret_decl(trf_10995)
static void C_fcall trf_10995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10995(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10995(t0,t1,t2,t3);}

C_noret_decl(trf_10663)
static void C_fcall trf_10663(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10663(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10663(t0,t1,t2);}

C_noret_decl(trf_10669)
static void C_fcall trf_10669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10669(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10669(t0,t1,t2,t3);}

C_noret_decl(trf_10703)
static void C_fcall trf_10703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10703(t0,t1);}

C_noret_decl(trf_10805)
static void C_fcall trf_10805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10805(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10805(t0,t1,t2);}

C_noret_decl(trf_10813)
static void C_fcall trf_10813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10813(t0,t1,t2);}

C_noret_decl(trf_10762)
static void C_fcall trf_10762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10762(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10762(t0,t1);}

C_noret_decl(trf_10714)
static void C_fcall trf_10714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10714(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10714(t0,t1,t2,t3);}

C_noret_decl(trf_10530)
static void C_fcall trf_10530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10530(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10530(t0,t1,t2,t3);}

C_noret_decl(trf_10585)
static void C_fcall trf_10585(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10585(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10585(t0,t1,t2,t3);}

C_noret_decl(trf_10607)
static void C_fcall trf_10607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10607(t0,t1,t2);}

C_noret_decl(trf_10634)
static void C_fcall trf_10634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10634(t0,t1,t2);}

C_noret_decl(trf_10242)
static void C_fcall trf_10242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10242(t0,t1,t2);}

C_noret_decl(trf_10455)
static void C_fcall trf_10455(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10455(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10455(t0,t1,t2);}

C_noret_decl(trf_10463)
static void C_fcall trf_10463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10463(t0,t1,t2);}

C_noret_decl(trf_10245)
static void C_fcall trf_10245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10245(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10245(t0,t1,t2,t3);}

C_noret_decl(trf_10421)
static void C_fcall trf_10421(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10421(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10421(t0,t1,t2);}

C_noret_decl(trf_10429)
static void C_fcall trf_10429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10429(t0,t1,t2);}

C_noret_decl(trf_10350)
static void C_fcall trf_10350(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10350(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_10350(t0,t1,t2,t3);}

C_noret_decl(trf_10285)
static void C_fcall trf_10285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10285(t0,t1);}

C_noret_decl(trf_10288)
static void C_fcall trf_10288(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10288(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10288(t0,t1);}

C_noret_decl(trf_10293)
static void C_fcall trf_10293(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10293(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10293(t0,t1,t2);}

C_noret_decl(trf_10301)
static void C_fcall trf_10301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10301(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10301(t0,t1,t2);}

C_noret_decl(trf_10139)
static void C_fcall trf_10139(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10139(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10139(t0,t1);}

C_noret_decl(trf_10173)
static void C_fcall trf_10173(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10173(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10173(t0,t1);}

C_noret_decl(trf_9407)
static void C_fcall trf_9407(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9407(void *dummy){
C_word t7=C_pick(0);
C_word t6=C_pick(1);
C_word t5=C_pick(2);
C_word t4=C_pick(3);
C_word t3=C_pick(4);
C_word t2=C_pick(5);
C_word t1=C_pick(6);
C_word t0=C_pick(7);
C_adjust_stack(-8);
f_9407(t0,t1,t2,t3,t4,t5,t6,t7);}

C_noret_decl(trf_9435)
static void C_fcall trf_9435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9435(t0,t1);}

C_noret_decl(trf_9733)
static void C_fcall trf_9733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9733(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9733(t0,t1,t2);}

C_noret_decl(trf_10048)
static void C_fcall trf_10048(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10048(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10048(t0,t1,t2);}

C_noret_decl(trf_10022)
static void C_fcall trf_10022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10022(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10022(t0,t1,t2);}

C_noret_decl(trf_9849)
static void C_fcall trf_9849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9849(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9849(t0,t1,t2);}

C_noret_decl(trf_9626)
static void C_fcall trf_9626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9626(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9626(t0,t1,t2);}

C_noret_decl(trf_9634)
static void C_fcall trf_9634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9634(t0,t1,t2);}

C_noret_decl(trf_9484)
static void C_fcall trf_9484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9484(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9484(t0,t1,t2);}

C_noret_decl(trf_8953)
static void C_fcall trf_8953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8953(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_8953(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_8956)
static void C_fcall trf_8956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8956(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_8956(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_9219)
static void C_fcall trf_9219(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9219(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9219(t0,t1);}

C_noret_decl(trf_9172)
static void C_fcall trf_9172(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9172(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9172(t0,t1);}

C_noret_decl(trf_9131)
static void C_fcall trf_9131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9131(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9131(t0,t1);}

C_noret_decl(trf_8754)
static void C_fcall trf_8754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8754(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_8754(t0,t1,t2,t3,t4);}

C_noret_decl(trf_8925)
static void C_fcall trf_8925(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8925(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8925(t0,t1,t2);}

C_noret_decl(trf_8933)
static void C_fcall trf_8933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8933(t0,t1,t2);}

C_noret_decl(trf_8673)
static void C_fcall trf_8673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8673(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8673(t0,t1,t2,t3);}

C_noret_decl(trf_6361)
static void C_fcall trf_6361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6361(t0,t1);}

C_noret_decl(trf_7986)
static void C_fcall trf_7986(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7986(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7986(t0,t1);}

C_noret_decl(trf_7899)
static void C_fcall trf_7899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7899(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7899(t0,t1);}

C_noret_decl(trf_7869)
static void C_fcall trf_7869(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7869(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7869(t0,t1);}

C_noret_decl(trf_7580)
static void C_fcall trf_7580(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7580(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7580(t0,t1);}

C_noret_decl(trf_7409)
static void C_fcall trf_7409(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7409(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7409(t0,t1);}

C_noret_decl(trf_7083)
static void C_fcall trf_7083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7083(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7083(t0,t1);}

C_noret_decl(trf_7086)
static void C_fcall trf_7086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7086(t0,t1);}

C_noret_decl(trf_7199)
static void C_fcall trf_7199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7199(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7199(t0,t1,t2);}

C_noret_decl(trf_7164)
static void C_fcall trf_7164(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7164(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7164(t0,t1,t2);}

C_noret_decl(trf_6401)
static void C_fcall trf_6401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6401(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6401(t0,t1);}

C_noret_decl(trf_6263)
static void C_fcall trf_6263(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6263(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6263(t0,t1,t2,t3);}

C_noret_decl(trf_6276)
static void C_fcall trf_6276(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6276(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6276(t0,t1);}

C_noret_decl(trf_6216)
static void C_fcall trf_6216(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6216(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6216(t0,t1,t2,t3);}

C_noret_decl(trf_6224)
static void C_fcall trf_6224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6224(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6224(t0,t1,t2,t3);}

C_noret_decl(trf_6136)
static void C_fcall trf_6136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6136(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6136(t0,t1,t2);}

C_noret_decl(trf_6144)
static void C_fcall trf_6144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6144(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6144(t0,t1,t2);}

C_noret_decl(trf_6055)
static void C_fcall trf_6055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6055(t0,t1,t2);}

C_noret_decl(trf_6063)
static void C_fcall trf_6063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6063(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6063(t0,t1,t2);}

C_noret_decl(trf_5920)
static void C_fcall trf_5920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5920(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5920(t0,t1);}

C_noret_decl(trf_5833)
static void C_fcall trf_5833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5833(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5833(t0,t1,t2,t3);}

C_noret_decl(trf_5839)
static void C_fcall trf_5839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5839(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5839(t0,t1,t2,t3);}

C_noret_decl(trf_5539)
static void C_fcall trf_5539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5539(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5539(t0,t1,t2);}

C_noret_decl(trf_5547)
static void C_fcall trf_5547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5547(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5547(t0,t1,t2);}

C_noret_decl(trf_5574)
static void C_fcall trf_5574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5574(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5574(t0,t1);}

C_noret_decl(trf_5594)
static void C_fcall trf_5594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5594(t0,t1);}

C_noret_decl(trf_5606)
static void C_fcall trf_5606(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5606(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5606(t0,t1);}

C_noret_decl(trf_5615)
static void C_fcall trf_5615(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5615(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5615(t0,t1);}

C_noret_decl(trf_5500)
static void C_fcall trf_5500(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5500(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5500(t0,t1,t2,t3);}

C_noret_decl(trf_5429)
static void C_fcall trf_5429(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5429(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5429(t0,t1,t2);}

C_noret_decl(trf_5345)
static void C_fcall trf_5345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5345(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_5345(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_4028)
static void C_fcall trf_4028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4028(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4028(t0,t1,t2,t3);}

C_noret_decl(trf_5295)
static void C_fcall trf_5295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5295(t0,t1);}

C_noret_decl(trf_5255)
static void C_fcall trf_5255(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5255(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5255(t0,t1);}

C_noret_decl(trf_4706)
static void C_fcall trf_4706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4706(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4706(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4740(t0,t1);}

C_noret_decl(trf_4973)
static void C_fcall trf_4973(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4973(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4973(t0,t1);}

C_noret_decl(trf_4809)
static void C_fcall trf_4809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4809(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4809(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4480)
static void C_fcall trf_4480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4480(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4480(t0,t1,t2);}

C_noret_decl(trf_4502)
static void C_fcall trf_4502(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4502(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4502(t0,t1);}

C_noret_decl(trf_4541)
static void C_fcall trf_4541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4541(t0,t1);}

C_noret_decl(trf_4487)
static void C_fcall trf_4487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4487(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4487(t0,t1);}

C_noret_decl(trf_4152)
static void C_fcall trf_4152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4152(t0,t1);}

C_noret_decl(trf_4068)
static void C_fcall trf_4068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4068(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4068(t0,t1,t2);}

C_noret_decl(trf_3747)
static void C_fcall trf_3747(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3747(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3747(t0,t1,t2,t3);}

C_noret_decl(trf_3933)
static void C_fcall trf_3933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3933(t0,t1,t2);}

C_noret_decl(trf_3868)
static void C_fcall trf_3868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3868(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3868(t0,t1);}

C_noret_decl(trf_3616)
static void C_fcall trf_3616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3616(t0,t1,t2);}

C_noret_decl(trf_3690)
static void C_fcall trf_3690(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3690(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3690(t0,t1,t2);}

C_noret_decl(trf_3576)
static void C_fcall trf_3576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3576(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3576(t0,t1,t2,t3);}

C_noret_decl(trf_3295)
static void C_fcall trf_3295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3295(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3295(t0,t1,t2,t3);}

C_noret_decl(trf_3376)
static void C_fcall trf_3376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3376(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3376(t0,t1);}

C_noret_decl(trf_3426)
static void C_fcall trf_3426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3426(t0,t1);}

C_noret_decl(trf_3471)
static void C_fcall trf_3471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3471(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3471(t0,t1);}

C_noret_decl(trf_3349)
static void C_fcall trf_3349(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3349(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3349(t0,t1);}

C_noret_decl(trf_3332)
static void C_fcall trf_3332(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3332(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3332(t0,t1);}

C_noret_decl(trf_3261)
static void C_fcall trf_3261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3261(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3261(t0,t1,t2,t3);}

C_noret_decl(trf_3267)
static void C_fcall trf_3267(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3267(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3267(t0,t1,t2);}

C_noret_decl(trf_3275)
static void C_fcall trf_3275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3275(t0,t1,t2);}

C_noret_decl(trf_3249)
static void C_fcall trf_3249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3249(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3249(t0,t1,t2,t3);}

C_noret_decl(trf_3226)
static void C_fcall trf_3226(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3226(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3226(t0,t1,t2);}

C_noret_decl(trf_3233)
static void C_fcall trf_3233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3233(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr10)
static void C_fcall tr10(C_proc10 k) C_regparm C_noret;
C_regparm static void C_fcall tr10(C_proc10 k){
C_word t9=C_pick(0);
C_word t8=C_pick(1);
C_word t7=C_pick(2);
C_word t6=C_pick(3);
C_word t5=C_pick(4);
C_word t4=C_pick(5);
C_word t3=C_pick(6);
C_word t2=C_pick(7);
C_word t1=C_pick(8);
C_word t0=C_pick(9);
C_adjust_stack(-10);
(k)(10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}

C_noret_decl(tr14)
static void C_fcall tr14(C_proc14 k) C_regparm C_noret;
C_regparm static void C_fcall tr14(C_proc14 k){
C_word t13=C_pick(0);
C_word t12=C_pick(1);
C_word t11=C_pick(2);
C_word t10=C_pick(3);
C_word t9=C_pick(4);
C_word t8=C_pick(5);
C_word t7=C_pick(6);
C_word t6=C_pick(7);
C_word t5=C_pick(8);
C_word t4=C_pick(9);
C_word t3=C_pick(10);
C_word t2=C_pick(11);
C_word t1=C_pick(12);
C_word t0=C_pick(13);
C_adjust_stack(-14);
(k)(14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}

C_noret_decl(tr11)
static void C_fcall tr11(C_proc11 k) C_regparm C_noret;
C_regparm static void C_fcall tr11(C_proc11 k){
C_word t10=C_pick(0);
C_word t9=C_pick(1);
C_word t8=C_pick(2);
C_word t7=C_pick(3);
C_word t6=C_pick(4);
C_word t5=C_pick(5);
C_word t4=C_pick(6);
C_word t3=C_pick(7);
C_word t2=C_pick(8);
C_word t1=C_pick(9);
C_word t0=C_pick(10);
C_adjust_stack(-11);
(k)(11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_optimizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_optimizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("optimizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1991)){
C_save(t1);
C_rereclaim2(1991*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,268);
lf[0]=C_h_intern(&lf[0],34,"\010compilerscan-toplevel-assignments");
lf[1]=C_h_intern(&lf[1],13,"alist-update!");
lf[2]=C_h_intern(&lf[2],13,"\004corevariable");
lf[3]=C_h_intern(&lf[3],6,"remove");
lf[4]=C_h_intern(&lf[4],2,"if");
lf[5]=C_h_intern(&lf[5],3,"let");
lf[6]=C_h_intern(&lf[6],6,"append");
lf[7]=C_h_intern(&lf[7],6,"lambda");
lf[8]=C_h_intern(&lf[8],9,"\004corecall");
lf[9]=C_h_intern(&lf[9],4,"set!");
lf[10]=C_h_intern(&lf[10],4,"node");
lf[11]=C_h_intern(&lf[11],14,"\004coreundefined");
lf[12]=C_h_intern(&lf[12],19,"\010compilercopy-node!");
lf[13]=C_h_intern(&lf[13],9,"alist-ref");
lf[14]=C_h_intern(&lf[14],11,"\004corelambda");
lf[15]=C_h_intern(&lf[15],13,"\004corecallunit");
lf[16]=C_h_intern(&lf[16],9,"\004corecond");
lf[17]=C_h_intern(&lf[17],11,"\004coreswitch");
lf[18]=C_h_intern(&lf[18],8,"\003sysput!");
lf[19]=C_h_intern(&lf[19],21,"\010compileralways-bound");
lf[20]=C_h_intern(&lf[20],9,"\003syserror");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[22]=C_h_intern(&lf[22],12,"\003sysfor-each");
lf[23]=C_h_intern(&lf[23],18,"\010compilerdebugging");
lf[24]=C_h_intern(&lf[24],1,"o");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\014safe globals");
lf[26]=C_h_intern(&lf[26],17,"delete-duplicates");
lf[27]=C_h_intern(&lf[27],3,"eq\077");
lf[28]=C_h_intern(&lf[28],1,"p");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000 scanning toplevel assignments...");
lf[30]=C_h_intern(&lf[30],24,"\010compilersimplifications");
lf[31]=C_h_intern(&lf[31],23,"\010compilersimplified-ops");
lf[32]=C_h_intern(&lf[32],41,"\010compilerperform-high-level-optimizations");
lf[33]=C_h_intern(&lf[33],12,"\010compilerget");
lf[34]=C_h_intern(&lf[34],5,"quote");
lf[35]=C_h_intern(&lf[35],10,"alist-cons");
lf[36]=C_h_intern(&lf[36],4,"caar");
lf[37]=C_h_intern(&lf[37],19,"\010compilermatch-node");
lf[38]=C_h_intern(&lf[38],3,"any");
lf[39]=C_h_intern(&lf[39],18,"\003syshash-table-ref");
lf[40]=C_h_intern(&lf[40],30,"\010compilerbroken-constant-nodes");
lf[41]=C_h_intern(&lf[41],11,"lset-adjoin");
lf[42]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[43]=C_h_intern(&lf[43],14,"\010compilerqnode");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\033folding constant expression");
lf[45]=C_h_intern(&lf[45],4,"eval");
lf[46]=C_h_intern(&lf[46],22,"with-exception-handler");
lf[47]=C_h_intern(&lf[47],30,"call-with-current-continuation");
lf[48]=C_h_intern(&lf[48],5,"every");
lf[49]=C_h_intern(&lf[49],9,"foldable\077");
lf[50]=C_h_intern(&lf[50],7,"\003sysget");
lf[51]=C_h_intern(&lf[51],18,"\010compilerintrinsic");
lf[52]=C_h_intern(&lf[52],5,"value");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\035substituted constant variable");
lf[54]=C_h_intern(&lf[54],16,"\010compilervarnode");
lf[55]=C_h_intern(&lf[55],11,"collapsable");
lf[56]=C_h_intern(&lf[56],10,"replacable");
lf[57]=C_h_intern(&lf[57],7,"\003sysmap");
lf[58]=C_h_intern(&lf[58],9,"replacing");
lf[59]=C_h_intern(&lf[59],12,"contractable");
lf[60]=C_h_intern(&lf[60],9,"removable");
lf[61]=C_h_intern(&lf[61],6,"unused");
lf[62]=C_h_intern(&lf[62],9,"partition");
lf[63]=C_h_intern(&lf[63],26,"\010compilerbuild-lambda-list");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[65]=C_h_intern(&lf[65],13,"explicit-rest");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000 removed unused formal parameters");
lf[67]=C_h_intern(&lf[67],30,"\010compilerdecompose-lambda-list");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\047merged explicitly consed rest parameter");
lf[69]=C_h_intern(&lf[69],21,"has-unused-parameters");
lf[70]=C_h_intern(&lf[70],31,"\010compilerinline-lambda-bindings");
lf[71]=C_h_intern(&lf[71],13,"\010compilerput!");
lf[72]=C_h_intern(&lf[72],13,"inline-target");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\024contracted procedure");
lf[74]=C_h_intern(&lf[74],24,"\010compilercheck-signature");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\0001removed call to pure procedure with unused result");
lf[77]=C_h_intern(&lf[77],28,"\010compilersource-info->string");
lf[78]=C_h_intern(&lf[78],37,"\010compilerexpression-has-side-effects\077");
lf[79]=C_h_intern(&lf[79],8,"assigned");
lf[80]=C_h_intern(&lf[80],10,"references");
lf[81]=C_h_intern(&lf[81],7,"unknown");
lf[82]=C_h_intern(&lf[82],8,"internal");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\022inlining procedure");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\017global inlining");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\010inlining");
lf[86]=C_h_intern(&lf[86],1,"i");
lf[87]=C_h_intern(&lf[87],14,"append-reverse");
lf[88]=C_h_intern(&lf[88],6,"gensym");
lf[89]=C_h_intern(&lf[89],1,"t");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000+removed unused parameter to known procedure");
lf[91]=C_h_intern(&lf[91],8,"split-at");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[93]=C_h_intern(&lf[93],20,"\004coreinline_allocate");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\042consed rest parameter at call site");
lf[95]=C_h_intern(&lf[95],21,"\010compilerllist-length");
lf[96]=C_h_intern(&lf[96],23,"\010compilerinline-locally");
lf[97]=C_h_intern(&lf[97],3,"yes");
lf[98]=C_h_intern(&lf[98],2,"no");
lf[99]=C_h_intern(&lf[99],24,"\010compilerinline-max-size");
lf[100]=C_h_intern(&lf[100],15,"\010compilerinline");
lf[101]=C_h_intern(&lf[101],9,"inlinable");
lf[102]=C_h_intern(&lf[102],22,"\010compilerinline-global");
lf[103]=C_h_intern(&lf[103],13,"\010compilerpure");
lf[104]=C_h_intern(&lf[104],11,"local-value");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\0006removed side-effect free assignment to unused variable");
lf[106]=C_h_intern(&lf[106],16,"inline-transient");
lf[107]=C_h_intern(&lf[107],26,"\010compilervariable-visible\077");
lf[108]=C_h_intern(&lf[108],6,"global");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\031removed conditional forms");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\025removed binding forms");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\022replaced variables");
lf[112]=C_h_intern(&lf[112],5,"print");
lf[113]=C_h_intern(&lf[113],7,"newline");
lf[114]=C_h_intern(&lf[114],6,"print*");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\027  call simplifications:");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\017simplifications");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\022traversal phase...");
lf[118]=C_h_intern(&lf[118],34,"\010compilerperform-pre-optimization!");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\023Removed `not\047 forms");
lf[120]=C_h_intern(&lf[120],24,"node-subexpressions-set!");
lf[121]=C_h_intern(&lf[121],7,"reverse");
lf[122]=C_h_intern(&lf[122],20,"node-parameters-set!");
lf[123]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[124]=C_h_intern(&lf[124],17,"\010compilerget-list");
lf[125]=C_h_intern(&lf[125],3,"not");
lf[126]=C_h_intern(&lf[126],10,"call-sites");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\031pre-optimization phase...");
lf[128]=C_h_intern(&lf[128],24,"register-simplifications");
lf[129]=C_h_intern(&lf[129],19,"\003syshash-table-set!");
lf[130]=C_h_intern(&lf[130],38,"\010compilerreorganize-recursive-bindings");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000!converted assignments to bindings");
lf[132]=C_h_intern(&lf[132],10,"fold-right");
lf[133]=C_h_intern(&lf[133],4,"fold");
lf[134]=C_h_intern(&lf[134],16,"topological-sort");
lf[135]=C_h_intern(&lf[135],6,"lset<=");
lf[136]=C_h_intern(&lf[136],10,"filter-map");
lf[137]=C_h_intern(&lf[137],6,"filter");
lf[138]=C_h_intern(&lf[138],10,"append-map");
lf[139]=C_h_intern(&lf[139],28,"\010compilerscan-used-variables");
lf[140]=C_h_intern(&lf[140],4,"cons");
lf[141]=C_h_intern(&lf[141],27,"\010compilersubstitution-table");
lf[142]=C_h_intern(&lf[142],16,"\010compilerrewrite");
lf[143]=C_h_intern(&lf[143],28,"\010compilersimplify-named-call");
lf[144]=C_h_intern(&lf[144],37,"\010compilerinline-substitutions-enabled");
lf[145]=C_h_intern(&lf[145],11,"\004coreinline");
lf[146]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[147]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[148]=C_h_intern(&lf[148],6,"unsafe");
lf[149]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[151]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[152]=C_h_intern(&lf[152],11,"number-type");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[154]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[156]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[157]=C_h_intern(&lf[157],6,"fixnum");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[159]=C_h_intern(&lf[159],21,"\010compilerfold-boolean");
lf[160]=C_h_intern(&lf[160],6,"flonum");
lf[161]=C_h_intern(&lf[161],7,"generic");
lf[162]=C_h_intern(&lf[162],5,"cons*");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[164]=C_h_intern(&lf[164],9,"\004coreproc");
lf[165]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[166]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[167]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[168]=C_h_intern(&lf[168],4,"conc");
lf[169]=C_h_intern(&lf[169],5,"fifth");
lf[170]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[171]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[172]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[173]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[174]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[175]=C_h_intern(&lf[175],19,"\010compilerfold-inner");
lf[176]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[177]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[178]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[179]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[180]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[181]=C_h_intern(&lf[181],13,"\010compilerbomb");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\023bad type (optimize)");
lf[183]=C_h_intern(&lf[183],34,"\010compilertransform-direct-lambdas!");
lf[184]=C_h_intern(&lf[184],5,"boxed");
lf[185]=C_h_intern(&lf[185],18,"\004coredirect_lambda");
lf[186]=C_h_intern(&lf[186],15,"\004coreinline_ref");
lf[187]=C_h_intern(&lf[187],37,"\010compilerestimate-foreign-result-size");
lf[188]=C_h_intern(&lf[188],19,"\004coreinline_loc_ref");
lf[189]=C_h_intern(&lf[189],16,"\004coredirect_call");
lf[190]=C_h_intern(&lf[190],5,"lset=");
lf[191]=C_h_intern(&lf[191],6,"delete");
lf[192]=C_h_intern(&lf[192],4,"quit");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000;known procedure called with wrong number of arguments: `~A\047");
lf[194]=C_h_intern(&lf[194],15,"lset-difference");
lf[195]=C_h_intern(&lf[195],15,"node-class-set!");
lf[196]=C_h_intern(&lf[196],12,"\004corerecurse");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[198]=C_h_intern(&lf[198],4,"take");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000Gknown procedure called recursively with wrong number of arguments: `~A\047");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\014missing kvar");
lf[201]=C_h_intern(&lf[201],11,"\004corereturn");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\017bad call (leaf)");
lf[203]=C_h_intern(&lf[203],6,"cdaddr");
lf[204]=C_h_intern(&lf[204],6,"caaddr");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\026invalid parameter list");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\0006direct leaf routine with hoistable closures/allocation");
lf[207]=C_h_intern(&lf[207],6,"unzip1");
lf[208]=C_h_intern(&lf[208],16,"\003sysmake-promise");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\036direct leaf routine/allocation");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000(direct leaf routine optimization pass...");
lf[211]=C_h_intern(&lf[211],32,"\010compilerperform-lambda-lifting!");
lf[212]=C_h_intern(&lf[212],23,"\003syshash-table-for-each");
lf[213]=C_h_intern(&lf[213],1,"+");
lf[214]=C_h_intern(&lf[214],14,"\004coreprimitive");
lf[215]=C_h_intern(&lf[215],7,"delete!");
lf[216]=C_h_intern(&lf[216],11,"concatenate");
lf[217]=C_h_intern(&lf[217],5,"count");
lf[218]=C_h_intern(&lf[218],22,"\010compilerhide-variable");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\037moving liftables to toplevel...");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\032removing local bindings...");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\026changing call sites...");
lf[222]=C_h_intern(&lf[222],12,"pretty-print");
lf[223]=C_h_intern(&lf[223],1,"l");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\026additional parameters:");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\035gathering extra parameters...");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031liftable local procedures");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000Aeliminating liftables by access-lists and non-liftable callees...");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\014accessibles:");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\031computing access-lists...");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\013call-graph:");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000\034eliminating non-liftables...");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\026building call graph...");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\026gathering liftables...");
lf[234]=C_h_intern(&lf[234],11,"make-vector");
lf[235]=C_h_intern(&lf[235],3,"var");
lf[236]=C_h_intern(&lf[236],1,"y");
lf[237]=C_h_intern(&lf[237],2,"d2");
lf[238]=C_h_intern(&lf[238],1,"z");
lf[239]=C_h_intern(&lf[239],2,"d3");
lf[240]=C_h_intern(&lf[240],1,"x");
lf[241]=C_h_intern(&lf[241],2,"d1");
lf[242]=C_h_intern(&lf[242],2,"op");
lf[243]=C_h_intern(&lf[243],5,"clist");
lf[244]=C_h_intern(&lf[244],34,"\010compilermembership-test-operators");
lf[245]=C_h_intern(&lf[245],32,"\010compilermembership-unfold-limit");
lf[246]=C_h_intern(&lf[246],4,"var1");
lf[247]=C_h_intern(&lf[247],4,"var0");
lf[248]=C_h_intern(&lf[248],6,"const1");
lf[249]=C_h_intern(&lf[249],4,"var2");
lf[250]=C_h_intern(&lf[250],6,"const2");
lf[251]=C_h_intern(&lf[251],4,"rest");
lf[252]=C_h_intern(&lf[252],5,"body2");
lf[253]=C_h_intern(&lf[253],5,"body1");
lf[254]=C_h_intern(&lf[254],27,"\010compilereq-inline-operator");
lf[255]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\002\376\377\016");
lf[256]=C_h_intern(&lf[256],19,"\010compilerimmediate\077");
lf[257]=C_h_intern(&lf[257],5,"const");
lf[258]=C_h_intern(&lf[258],1,"n");
lf[259]=C_h_intern(&lf[259],7,"clauses");
lf[260]=C_h_intern(&lf[260],4,"body");
lf[261]=C_h_intern(&lf[261],1,"d");
lf[262]=C_h_intern(&lf[262],4,"more");
lf[263]=C_h_intern(&lf[263],4,"args");
lf[264]=C_h_intern(&lf[264],1,"a");
lf[265]=C_h_intern(&lf[265],1,"b");
lf[266]=C_h_intern(&lf[266],1,"c");
lf[267]=C_h_intern(&lf[267],4,"cdar");
C_register_lf2(lf,268,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3218,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3216 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3221,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3219 in k3216 */
static void C_ccall f_3221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3221,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#scan-toplevel-assignments ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3223,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3570,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:128: make-vector */
t4=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k3568 in k3219 in k3216 */
static void C_ccall f_3570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[56],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3570,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! ##compiler#simplifications ...) */,t1);
t3=C_set_block_item(lf[31] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t4=C_mutate((C_word*)lf[32]+1 /* (set! ##compiler#perform-high-level-optimizations ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3573,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[118]+1 /* (set! ##compiler#perform-pre-optimization! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5493,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[128]+1 /* (set! register-simplifications ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5812,tmp=(C_word)a,a+=2,tmp));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5819,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_cons(&a,2,lf[264],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[2],t9);
t11=C_a_i_cons(&a,2,lf[265],lf[266]);
t12=C_a_i_cons(&a,2,t10,t11);
t13=C_a_i_cons(&a,2,lf[261],t12);
t14=C_a_i_cons(&a,2,lf[8],t13);
t15=C_a_i_cons(&a,2,lf[261],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,lf[266],t15);
t17=C_a_i_cons(&a,2,lf[265],t16);
t18=C_a_i_cons(&a,2,lf[264],t17);
t19=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_14208,tmp=(C_word)a,a+=2,tmp);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t18,t20);
t22=C_a_i_cons(&a,2,t14,t21);
t23=C_a_i_list(&a,1,t22);
/* optimizer.scm:506: ##sys#hash-table-set! */
t24=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t24+1)))(5,t24,t7,*((C_word*)lf[30]+1),lf[8],t23);}

/* a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14208(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_14208,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14216,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=t6,a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:515: ##sys#hash-table-ref */
t8=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,*((C_word*)lf[141]+1),t3);}

/* k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14216,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_14221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_14221(t6,((C_word*)t0)[2],t2);}

/* loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_fcall f_14221(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14221,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_14231,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14271,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t3,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:517: caar */
t5=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k14269 in loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_14275,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:517: cdar */
t3=*((C_word*)lf[267]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k14273 in k14269 in loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:517: simplify-named-call */
t2=*((C_word*)lf[143]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k14229 in loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_14231,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_14235,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* g859860 */
t3=t2;
f_14235(t3,((C_word*)t0)[4],t1);}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:524: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_14221(t3,((C_word*)t0)[4],t2);}}

/* g859 in k14229 in loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_fcall f_14235(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_14235,NULL,3,t0,t1,t2);}
t3=C_i_assq(((C_word*)t0)[2],*((C_word*)lf[31]+1));
if(C_truep(t3)){
t4=C_i_cdr(t3);
t5=C_a_i_plus(&a,2,t4,C_fix(1));
t6=C_i_set_cdr(t3,t5);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_14257,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:522: alist-cons */
t5=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],C_fix(1),*((C_word*)lf[31]+1));}}

/* k14255 in g859 in k14229 in loop in k14214 in a14207 in k3568 in k3219 in k3216 */
static void C_ccall f_14257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[31]+1 /* (set! ##compiler#simplified-ops ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word ab[446],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5822,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[2],t6);
t8=C_a_i_cons(&a,2,lf[248],C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,lf[34],t9);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t7,t11);
t13=C_a_i_cons(&a,2,t4,t12);
t14=C_a_i_cons(&a,2,lf[145],t13);
t15=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,lf[2],t16);
t18=C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t19=C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t20,C_SCHEME_END_OF_LIST);
t22=C_a_i_cons(&a,2,lf[2],t21);
t23=C_a_i_cons(&a,2,lf[250],C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,t23,C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,lf[34],t24);
t26=C_a_i_cons(&a,2,t25,C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,t22,t26);
t28=C_a_i_cons(&a,2,t19,t27);
t29=C_a_i_cons(&a,2,lf[145],t28);
t30=C_a_i_cons(&a,2,lf[249],C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t30,C_SCHEME_END_OF_LIST);
t32=C_a_i_cons(&a,2,lf[2],t31);
t33=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t34=C_a_i_cons(&a,2,lf[252],t33);
t35=C_a_i_cons(&a,2,t32,t34);
t36=C_a_i_cons(&a,2,lf[237],t35);
t37=C_a_i_cons(&a,2,lf[4],t36);
t38=C_a_i_cons(&a,2,t37,C_SCHEME_END_OF_LIST);
t39=C_a_i_cons(&a,2,t29,t38);
t40=C_a_i_cons(&a,2,t18,t39);
t41=C_a_i_cons(&a,2,lf[5],t40);
t42=C_a_i_cons(&a,2,t41,C_SCHEME_END_OF_LIST);
t43=C_a_i_cons(&a,2,lf[253],t42);
t44=C_a_i_cons(&a,2,t17,t43);
t45=C_a_i_cons(&a,2,lf[241],t44);
t46=C_a_i_cons(&a,2,lf[4],t45);
t47=C_a_i_cons(&a,2,t46,C_SCHEME_END_OF_LIST);
t48=C_a_i_cons(&a,2,t14,t47);
t49=C_a_i_cons(&a,2,t3,t48);
t50=C_a_i_cons(&a,2,lf[5],t49);
t51=C_a_i_cons(&a,2,lf[251],C_SCHEME_END_OF_LIST);
t52=C_a_i_cons(&a,2,lf[237],t51);
t53=C_a_i_cons(&a,2,lf[241],t52);
t54=C_a_i_cons(&a,2,lf[252],t53);
t55=C_a_i_cons(&a,2,lf[253],t54);
t56=C_a_i_cons(&a,2,lf[250],t55);
t57=C_a_i_cons(&a,2,lf[248],t56);
t58=C_a_i_cons(&a,2,lf[242],t57);
t59=C_a_i_cons(&a,2,lf[249],t58);
t60=C_a_i_cons(&a,2,lf[246],t59);
t61=C_a_i_cons(&a,2,lf[247],t60);
t62=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13887,tmp=(C_word)a,a+=2,tmp);
t63=C_a_i_cons(&a,2,t62,C_SCHEME_END_OF_LIST);
t64=C_a_i_cons(&a,2,t61,t63);
t65=C_a_i_cons(&a,2,t50,t64);
t66=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t67=C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t68=C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t69=C_a_i_cons(&a,2,t68,C_SCHEME_END_OF_LIST);
t70=C_a_i_cons(&a,2,lf[2],t69);
t71=C_a_i_cons(&a,2,lf[257],C_SCHEME_END_OF_LIST);
t72=C_a_i_cons(&a,2,t71,C_SCHEME_END_OF_LIST);
t73=C_a_i_cons(&a,2,lf[34],t72);
t74=C_a_i_cons(&a,2,t73,C_SCHEME_END_OF_LIST);
t75=C_a_i_cons(&a,2,t70,t74);
t76=C_a_i_cons(&a,2,t67,t75);
t77=C_a_i_cons(&a,2,lf[145],t76);
t78=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t79=C_a_i_cons(&a,2,t78,C_SCHEME_END_OF_LIST);
t80=C_a_i_cons(&a,2,lf[2],t79);
t81=C_a_i_cons(&a,2,lf[258],C_SCHEME_END_OF_LIST);
t82=C_a_i_cons(&a,2,lf[247],C_SCHEME_END_OF_LIST);
t83=C_a_i_cons(&a,2,t82,C_SCHEME_END_OF_LIST);
t84=C_a_i_cons(&a,2,lf[2],t83);
t85=C_a_i_cons(&a,2,t84,lf[259]);
t86=C_a_i_cons(&a,2,t81,t85);
t87=C_a_i_cons(&a,2,lf[17],t86);
t88=C_a_i_cons(&a,2,t87,C_SCHEME_END_OF_LIST);
t89=C_a_i_cons(&a,2,lf[260],t88);
t90=C_a_i_cons(&a,2,t80,t89);
t91=C_a_i_cons(&a,2,lf[261],t90);
t92=C_a_i_cons(&a,2,lf[4],t91);
t93=C_a_i_cons(&a,2,t92,C_SCHEME_END_OF_LIST);
t94=C_a_i_cons(&a,2,t77,t93);
t95=C_a_i_cons(&a,2,t66,t94);
t96=C_a_i_cons(&a,2,lf[5],t95);
t97=C_a_i_cons(&a,2,lf[259],C_SCHEME_END_OF_LIST);
t98=C_a_i_cons(&a,2,lf[258],t97);
t99=C_a_i_cons(&a,2,lf[260],t98);
t100=C_a_i_cons(&a,2,lf[261],t99);
t101=C_a_i_cons(&a,2,lf[257],t100);
t102=C_a_i_cons(&a,2,lf[247],t101);
t103=C_a_i_cons(&a,2,lf[242],t102);
t104=C_a_i_cons(&a,2,lf[235],t103);
t105=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13666,tmp=(C_word)a,a+=2,tmp);
t106=C_a_i_cons(&a,2,t105,C_SCHEME_END_OF_LIST);
t107=C_a_i_cons(&a,2,t104,t106);
t108=C_a_i_cons(&a,2,t96,t107);
t109=C_a_i_cons(&a,2,lf[246],C_SCHEME_END_OF_LIST);
t110=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t111=C_a_i_cons(&a,2,lf[11],t110);
t112=C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t113=C_a_i_cons(&a,2,t111,t112);
t114=C_a_i_cons(&a,2,t109,t113);
t115=C_a_i_cons(&a,2,lf[5],t114);
t116=C_a_i_cons(&a,2,lf[262],C_SCHEME_END_OF_LIST);
t117=C_a_i_cons(&a,2,lf[246],t116);
t118=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13265,tmp=(C_word)a,a+=2,tmp);
t119=C_a_i_cons(&a,2,t118,C_SCHEME_END_OF_LIST);
t120=C_a_i_cons(&a,2,t117,t119);
t121=C_a_i_cons(&a,2,t115,t120);
t122=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t123=C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t124=C_a_i_cons(&a,2,t123,lf[263]);
t125=C_a_i_cons(&a,2,lf[145],t124);
t126=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t127=C_a_i_cons(&a,2,t126,C_SCHEME_END_OF_LIST);
t128=C_a_i_cons(&a,2,lf[2],t127);
t129=C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t130=C_a_i_cons(&a,2,lf[240],t129);
t131=C_a_i_cons(&a,2,t128,t130);
t132=C_a_i_cons(&a,2,lf[261],t131);
t133=C_a_i_cons(&a,2,lf[4],t132);
t134=C_a_i_cons(&a,2,t133,C_SCHEME_END_OF_LIST);
t135=C_a_i_cons(&a,2,t125,t134);
t136=C_a_i_cons(&a,2,t122,t135);
t137=C_a_i_cons(&a,2,lf[5],t136);
t138=C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t139=C_a_i_cons(&a,2,lf[240],t138);
t140=C_a_i_cons(&a,2,lf[261],t139);
t141=C_a_i_cons(&a,2,lf[263],t140);
t142=C_a_i_cons(&a,2,lf[242],t141);
t143=C_a_i_cons(&a,2,lf[235],t142);
t144=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13117,tmp=(C_word)a,a+=2,tmp);
t145=C_a_i_cons(&a,2,t144,C_SCHEME_END_OF_LIST);
t146=C_a_i_cons(&a,2,t143,t145);
t147=C_a_i_cons(&a,2,t137,t146);
t148=C_a_i_list(&a,4,t65,t108,t121,t147);
/* optimizer.scm:506: ##sys#hash-table-set! */
t149=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t149+1)))(5,t149,t2,*((C_word*)lf[30]+1),lf[5],t148);}

/* a13116 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13117(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_13117,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
if(C_truep(C_i_equalp(t4,*((C_word*)lf[254]+1)))){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13163,a[2]=t6,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t5,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:665: get-list */
t10=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,t2,t3,lf[80]);}}

/* k13161 in a13116 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13163,2,t0,t1);}
t2=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t2))){
t3=C_a_i_list(&a,1,((C_word*)t0)[7]);
t4=((C_word*)t0)[6];
t5=C_a_i_record(&a,4,lf[10],lf[145],t3,t4);
t6=C_a_i_list(&a,3,t5,((C_word*)t0)[5],((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[2];
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record(&a,4,lf[10],lf[4],t8,t6));}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13265(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_13265,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t3);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13275,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_13275(t9,t1,t5,t4);}

/* loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_13275(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13275,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t3;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[5]);
if(C_truep(t10)){
t11=C_i_cdr(t7);
if(C_truep(C_i_nullp(t11))){
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t7,a[6]=t9,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t13=C_i_car(t7);
/* optimizer.scm:604: get */
t14=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t12,((C_word*)t0)[2],t13,lf[106]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13612,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:605: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],t3,lf[80]);}}

/* k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13604,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_car(((C_word*)t0)[6]);
t3=C_slot(t2,C_fix(2));
t4=C_slot(t2,C_fix(3));
t5=C_slot(t2,C_fix(1));
t6=C_eqp(t5,lf[11]);
if(C_truep(t6)){
t7=C_i_car(((C_word*)t0)[5]);
t8=C_a_i_cons(&a,2,t7,((C_word*)t0)[4]);
t9=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:610: loop1 */
t10=((C_word*)((C_word*)t0)[3])[1];
f_13275(t10,((C_word*)t0)[7],t8,t9);}
else{
t7=C_eqp(t5,lf[9]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13381,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:612: reverse */
t9=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[4]);}
else{
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}

/* k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13381,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_car(t1);
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_list(&a,1,t5);
t7=C_i_cdr(t1);
t8=C_i_cadr(((C_word*)t0)[4]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13410,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_13410(t12,((C_word*)t0)[2],t6,t7,t8);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_13410(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13410,NULL,5,t0,t1,t2,t3,t4);}
t5=t4;
t6=C_slot(t5,C_fix(1));
t7=t4;
t8=C_slot(t7,C_fix(2));
t9=t4;
t10=C_slot(t9,C_fix(3));
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13441,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t10,tmp=(C_word)a,a+=9,tmp);
t12=C_eqp(t6,lf[5]);
if(C_truep(t12)){
t13=C_i_cdr(t8);
if(C_truep(C_i_nullp(t13))){
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_13580,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t10,a[5]=t3,a[6]=t11,tmp=(C_word)a,a+=7,tmp);
t15=C_i_car(t8);
/* optimizer.scm:623: get */
t16=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t14,((C_word*)t0)[2],t15,lf[106]);}
else{
t14=t11;
f_13441(t14,C_SCHEME_FALSE);}}
else{
t13=t11;
f_13441(t13,C_SCHEME_FALSE);}}

/* k13578 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13580,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_13441(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13572,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:624: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],t3,lf[80]);}}

/* k13570 in k13578 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_13441(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[9],t3);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=C_i_car(((C_word*)t0)[2]);
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=((C_word*)t0)[4];
f_13441(t9,C_eqp(t5,t8));}
else{
t5=((C_word*)t0)[4];
f_13441(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
f_13441(t2,C_SCHEME_FALSE);}}}

/* k13439 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_13441(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_13441,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[8]);
t3=C_slot(t2,C_fix(3));
t4=C_i_car(t3);
t5=C_a_i_cons(&a,2,t4,((C_word*)t0)[7]);
t6=C_i_cdr(((C_word*)t0)[6]);
t7=C_i_cadr(((C_word*)t0)[8]);
/* optimizer.scm:628: loop2 */
t8=((C_word*)((C_word*)t0)[5])[1];
f_13410(t8,((C_word*)t0)[4],t5,t6,t7);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13484,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_13494,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[4],t2,t3);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* a13493 in k13439 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13494(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_13494,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t2:C_SCHEME_FALSE));}

/* a13483 in k13439 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13484,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_13492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:633: reverse */
t3=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k13490 in a13483 in k13439 in loop2 in k13379 in k13602 in k13610 in loop1 in a13264 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:633: reorganize-recursive-bindings */
t2=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13666(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10){
C_word tmp;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr11,(void*)f_13666,11,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10);}
if(C_truep(C_i_equalp(t4,*((C_word*)lf[254]+1)))){
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_13679,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t6,a[6]=t10,a[7]=t8,a[8]=t1,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:574: immediate? */
t12=*((C_word*)lf[256]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,t6);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}

/* k13677 in a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13679,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13721,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:575: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[80]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13719 in k13677 in a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13721,2,t0,t1);}
t2=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t2))){
t3=C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_13701,a[2]=t4,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13705,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:579: varnode */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k13703 in k13719 in k13677 in a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_13709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:580: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k13707 in k13703 in k13719 in k13677 in a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:579: cons* */
t2=*((C_word*)lf[162]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k13699 in k13719 in k13677 in a13665 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13701,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[17],((C_word*)t0)[2],t1));}

/* a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13887(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9,C_word t10,C_word t11,C_word t12,C_word t13){
C_word tmp;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr14,(void*)f_13887,14,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11,t12,t13);}
if(C_truep(C_i_equalp(t6,*((C_word*)lf[254]+1)))){
t14=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13900,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t3,a[6]=t7,a[7]=t8,a[8]=t1,a[9]=t13,a[10]=t10,a[11]=t9,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:547: immediate? */
t15=*((C_word*)lf[256]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t7);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}

/* k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13900,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_13906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:548: immediate? */
t3=*((C_word*)lf[256]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13906,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_13958,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:549: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[80]);}
else{
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k13956 in k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13958,2,t0,t1);}
t2=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t2))){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_13950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:550: get-list */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[80]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k13948 in k13956 in k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13950,2,t0,t1);}
t2=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:554: varnode */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k13932 in k13948 in k13956 in k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13938,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:555: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k13936 in k13932 in k13948 in k13956 in k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13938(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13938,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_13942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:557: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k13940 in k13936 in k13932 in k13948 in k13956 in k13904 in k13898 in a13886 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_13942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_13942,2,t0,t1);}
t2=C_a_i_list(&a,6,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t1,((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[17],lf[255],t2));}

/* k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word ab[166],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5825,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[2],t4);
t6=C_a_i_cons(&a,2,lf[236],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=C_a_i_cons(&a,2,lf[237],t7);
t9=C_a_i_cons(&a,2,lf[8],t8);
t10=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,lf[2],t11);
t13=C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t12,t13);
t15=C_a_i_cons(&a,2,lf[239],t14);
t16=C_a_i_cons(&a,2,lf[8],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t9,t17);
t19=C_a_i_cons(&a,2,lf[240],t18);
t20=C_a_i_cons(&a,2,lf[241],t19);
t21=C_a_i_cons(&a,2,lf[4],t20);
t22=C_a_i_cons(&a,2,lf[235],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,lf[238],t22);
t24=C_a_i_cons(&a,2,lf[236],t23);
t25=C_a_i_cons(&a,2,lf[240],t24);
t26=C_a_i_cons(&a,2,lf[239],t25);
t27=C_a_i_cons(&a,2,lf[237],t26);
t28=C_a_i_cons(&a,2,lf[241],t27);
t29=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12954,tmp=(C_word)a,a+=2,tmp);
t30=C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t28,t30);
t32=C_a_i_cons(&a,2,t21,t31);
t33=C_a_i_cons(&a,2,lf[242],C_SCHEME_END_OF_LIST);
t34=C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,t34,C_SCHEME_END_OF_LIST);
t36=C_a_i_cons(&a,2,lf[34],t35);
t37=C_a_i_cons(&a,2,t36,C_SCHEME_END_OF_LIST);
t38=C_a_i_cons(&a,2,lf[240],t37);
t39=C_a_i_cons(&a,2,t33,t38);
t40=C_a_i_cons(&a,2,lf[145],t39);
t41=C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t42=C_a_i_cons(&a,2,lf[236],t41);
t43=C_a_i_cons(&a,2,t40,t42);
t44=C_a_i_cons(&a,2,lf[241],t43);
t45=C_a_i_cons(&a,2,lf[4],t44);
t46=C_a_i_cons(&a,2,lf[238],C_SCHEME_END_OF_LIST);
t47=C_a_i_cons(&a,2,lf[236],t46);
t48=C_a_i_cons(&a,2,lf[243],t47);
t49=C_a_i_cons(&a,2,lf[240],t48);
t50=C_a_i_cons(&a,2,lf[242],t49);
t51=C_a_i_cons(&a,2,lf[241],t50);
t52=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12758,tmp=(C_word)a,a+=2,tmp);
t53=C_a_i_cons(&a,2,t52,C_SCHEME_END_OF_LIST);
t54=C_a_i_cons(&a,2,t51,t53);
t55=C_a_i_cons(&a,2,t45,t54);
t56=C_a_i_list(&a,2,t32,t55);
/* optimizer.scm:506: ##sys#hash-table-set! */
t57=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t57+1)))(5,t57,t2,*((C_word*)lf[30]+1),lf[4],t56);}

/* a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12758(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_12758,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_i_assoc(t4,*((C_word*)lf[244]+1));
if(C_truep(t9)){
if(C_truep(C_i_listp(t6))){
t10=C_i_length(t6);
if(C_truep(C_i_lessp(t10,*((C_word*)lf[245]+1)))){
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12780,a[2]=t6,a[3]=t1,a[4]=t5,a[5]=t3,a[6]=t8,a[7]=t7,a[8]=t9,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:703: gensym */
t12=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,t11);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12780,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[8]);
t3=C_a_i_list(&a,1,t2);
t4=C_a_i_list(&a,1,t1);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12816,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12818,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12860,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:720: qnode */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_SCHEME_FALSE);}

/* k12858 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:712: fold-right */
t2=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a12817 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12818,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12852,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:717: varnode */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k12850 in a12817 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12856,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:717: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k12854 in k12850 in a12817 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12856,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_record(&a,4,lf[10],lf[145],((C_word*)t0)[4],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12844,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:718: qnode */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_TRUE);}

/* k12842 in k12854 in k12850 in a12817 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12844,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[4],t1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[16],C_SCHEME_END_OF_LIST,t2));}

/* k12814 in k12778 in a12757 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12816,2,t0,t1);}
t2=C_a_i_list(&a,3,t1,((C_word*)t0)[7],((C_word*)t0)[6]);
t3=((C_word*)t0)[5];
t4=C_a_i_record(&a,4,lf[10],lf[4],t3,t2);
t5=C_a_i_list(&a,2,((C_word*)t0)[4],t4);
t6=((C_word*)t0)[3];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t5));}

/* a12953 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8,C_word t9){
C_word tmp;
C_word t10;
C_word t11;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr10,(void*)f_12954,10,t0,t1,t2,t3,t4,t5,t6,t7,t8,t9);}
if(C_truep(*((C_word*)lf[144]+1))){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12974,a[2]=t4,a[3]=t1,a[4]=t8,a[5]=t7,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:688: varnode */
t11=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t10,t9);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}

/* k12972 in a12953 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12974,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_a_i_record(&a,4,lf[10],lf[16],C_SCHEME_END_OF_LIST,t2);
t4=C_a_i_list(&a,2,t1,t3);
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],t6,t4));}

/* k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5825,2,t0,t1);}
t2=C_mutate((C_word*)lf[130]+1 /* (set! ##compiler#reorganize-recursive-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5827,tmp=(C_word)a,a+=2,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6314,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:815: make-vector */
t4=*((C_word*)lf[234]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_fix(301),C_SCHEME_END_OF_LIST);}

/* k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6314,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1 /* (set! ##compiler#substitution-table ...) */,t1);
t3=C_mutate((C_word*)lf[142]+1 /* (set! ##compiler#rewrite ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6316,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[143]+1 /* (set! ##compiler#simplify-named-call ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6336,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[183]+1 /* (set! ##compiler#transform-direct-lambdas! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8751,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[211]+1 /* (set! ##compiler#perform-lambda-lifting! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10136,tmp=(C_word)a,a+=2,tmp));
t7=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_UNDEFINED);}

/* ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[62],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10136,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10139,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t25=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10242,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t26=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10530,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t27=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10663,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t28=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10944,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t29=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11255,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t30=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11664,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t31=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12192,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t32=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12390,a[2]=t2,tmp=(C_word)a,a+=3,tmp));
t33=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12631,a[2]=t7,a[3]=t9,a[4]=t11,a[5]=t13,a[6]=t15,a[7]=t17,a[8]=t21,a[9]=t23,a[10]=t1,a[11]=t19,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1793: debugging */
t34=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t34+1)))(4,t34,t33,lf[28],lf[233]);}

/* k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1794: find-lifting-candidates */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10139(t3,t2);}

/* k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12637,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1795: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[232]);}

/* k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1796: build-call-graph */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10242(t3,t2,((C_word*)t0)[3]);}

/* k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_12643,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1797: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[231]);}

/* k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12646,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1798: eliminate */
t3=((C_word*)((C_word*)t0)[4])[1];
f_10530(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12649,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12729,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1799: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[223],lf[230]);}

/* k12727 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:1799: pretty-print */
t2=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_12649(2,t2,C_SCHEME_UNDEFINED);}}

/* k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1800: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[229]);}

/* k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1801: collect-accessibles */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10663(t3,t2,((C_word*)t0)[3]);}

/* k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12658,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12723,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1802: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[223],lf[228]);}

/* k12721 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:1802: pretty-print */
t2=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_12658(2,t2,C_SCHEME_UNDEFINED);}}

/* k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1803: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[227]);}

/* k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12664,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12720,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1804: eliminate4 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10944(t4,t3,((C_word*)t0)[2]);}

/* k12718 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12720,2,t0,t1);}
t2=C_i_length(t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10910,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_10910(t6,((C_word*)t0)[2],t1,t2);}

/* loop in k12718 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10910(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10910,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10914,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10928,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1598: filter */
t6=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a10927 in loop in k12718 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10928(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10928,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10934,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cddr(t2);
/* optimizer.scm:1598: every */
t5=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a10933 in a10927 in loop in k12718 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10934,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* k10912 in loop in k12718 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_length(t1);
if(C_truep(C_i_nequalp(((C_word*)t0)[4],t2))){
t3=t1;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* optimizer.scm:1602: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_10910(t3,((C_word*)t0)[3],t1,t2);}}

/* k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12667,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(t1))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12710,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12712,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t5=*((C_word*)lf[208]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t3=t2;
f_12667(2,t3,C_SCHEME_UNDEFINED);}}

/* a12711 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12712,2,t0,t1);}
/* optimizer.scm:1806: unzip1 */
t2=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k12708 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1806: debugging */
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[24],lf[226],t1);}

/* k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1807: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[225]);}

/* k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12673,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1808: compute-extra-variables */
t3=((C_word*)((C_word*)t0)[2])[1];
f_11255(t3,t2,((C_word*)t0)[5]);}

/* k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12673,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12676,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12697,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1809: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[223],lf[224]);}

/* k12695 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:1809: pretty-print */
t2=*((C_word*)lf[222]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_12676(2,t2,C_SCHEME_UNDEFINED);}}

/* k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12676,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12679,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:1810: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[221]);}

/* k12677 in k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12682,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1811: extend-call-sites! */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12192(t3,t2,((C_word*)t0)[4]);}

/* k12680 in k12677 in k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1812: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[220]);}

/* k12683 in k12680 in k12677 in k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12688,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1813: remove-local-bindings! */
t3=((C_word*)((C_word*)t0)[2])[1];
f_12390(t3,t2,((C_word*)t0)[4]);}

/* k12686 in k12683 in k12680 in k12677 in k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1814: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[219]);}

/* k12689 in k12686 in k12683 in k12680 in k12677 in k12674 in k12671 in k12668 in k12665 in k12662 in k12659 in k12656 in k12653 in k12650 in k12647 in k12644 in k12641 in k12638 in k12635 in k12632 in k12629 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1815: reconstruct! */
t2=((C_word*)((C_word*)t0)[5])[1];
f_11664(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12390(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12390,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12396,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_12396(t6,t1,((C_word*)t0)[2]);}

/* walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12396(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12396,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12430,a[2]=t8,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t11=t2;
t12=C_slot(t11,C_fix(3));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12521,a[2]=((C_word*)t0)[2],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_12521(t16,t10,t12);}
else{
t10=C_eqp(t4,lf[9]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12551,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t12=t2;
t13=C_slot(t12,C_fix(3));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12581,a[2]=((C_word*)t0)[2],a[3]=t15,tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_12581(t17,t11,t13);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12607,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_12607(t14,t1,t8);}}}

/* loop3148 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12607,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12617,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g31553156 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12396(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12615 in loop3148 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12607(t3,((C_word*)t0)[2],t2);}

/* loop3129 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12581(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12581,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12591,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g31363137 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12396(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12589 in loop3129 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12581(t3,((C_word*)t0)[2],t2);}

/* k12549 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12551,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_i_assq(t2,((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1788: node-class-set! */
t4=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[11]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12558 in k12549 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1789: node-parameters-set! */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k12561 in k12558 in k12549 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1790: node-subexpressions-set! */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop3099 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12521(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12521,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12531,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g31063107 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12396(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12529 in loop3099 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12521(t3,((C_word*)t0)[2],t2);}

/* k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12430,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12435,a[2]=t7,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_12435(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop3115 in k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12435(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12435,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[6])[1]))){
t4=C_i_car(t3);
/* optimizer.scm:1778: copy-node! */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12458,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12473,a[2]=((C_word*)t0)[5],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1780: reverse */
t6=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)((C_word*)t0)[6])[1]);}}
else{
t4=C_i_car(t2);
if(C_truep(C_i_assq(t4,((C_word*)t0)[3]))){
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
t19=t1;
t20=t5;
t21=t6;
t1=t19;
t2=t20;
t3=t21;
goto loop;}
else{
t5=C_i_car(t2);
t6=C_a_i_cons(&a,2,t5,((C_word*)((C_word*)t0)[6])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[6])+1,t6);
t8=C_i_car(t3);
t9=C_a_i_cons(&a,2,t8,((C_word*)((C_word*)t0)[4])[1]);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
t11=C_i_cdr(t2);
t12=C_i_cdr(t3);
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* k12471 in doloop3115 in k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1780: node-parameters-set! */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k12456 in doloop3115 in k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12458,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12465,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12469,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1781: reverse */
t4=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k12467 in k12456 in doloop3115 in k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1781: append */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k12463 in k12456 in doloop3115 in k12428 in walk in remove-local-bindings! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1781: node-subexpressions-set! */
t2=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12192(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12192,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12198,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_12198(t6,t1,((C_word*)t0)[2]);}

/* walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12198(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12198,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[8]);
if(C_truep(t9)){
t10=C_i_car(t8);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12235,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t12=C_slot(t10,C_fix(1));
t13=C_eqp(lf[2],t12);
if(C_truep(t13)){
t14=C_slot(t10,C_fix(2));
t15=C_i_car(t14);
t16=C_i_assq(t15,((C_word*)t0)[2]);
if(C_truep(t16)){
t17=C_i_set_car(t6,C_SCHEME_TRUE);
t18=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12293,a[2]=t2,a[3]=t11,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
t19=C_SCHEME_END_OF_LIST;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_FALSE;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12297,a[2]=t18,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t24=C_i_cdr(t16);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12307,a[2]=t20,a[3]=t26,a[4]=t22,tmp=(C_word)a,a+=5,tmp));
t28=((C_word*)t26)[1];
f_12307(t28,t23,t24);}
else{
t17=C_SCHEME_UNDEFINED;
t18=t11;
f_12235(2,t18,t17);}}
else{
t14=t11;
f_12235(2,t14,C_SCHEME_UNDEFINED);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12367,a[2]=((C_word*)t0)[3],a[3]=t11,tmp=(C_word)a,a+=4,tmp));
t13=((C_word*)t11)[1];
f_12367(t13,t1,t8);}}

/* loop3065 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12367(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12367,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12377,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g30723073 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12198(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12375 in loop3065 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12367(t3,((C_word*)t0)[2],t2);}

/* loop3024 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12307,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12336,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g30403041 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12334 in loop3024 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12336,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop30243037 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12307(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop30243037 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_12307(t6,((C_word*)t0)[3],t5);}}

/* k12295 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:1760: append */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t1,t2);}

/* k12291 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12293,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm:1758: node-subexpressions-set! */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k12233 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12235,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=C_slot(t2,C_fix(3));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12249,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_12249(t7,((C_word*)t0)[2],t3);}

/* loop3048 in k12233 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12249(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12249,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12259,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g30553056 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_12198(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12257 in loop3048 in k12233 in walk in extend-call-sites! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12249(t3,((C_word*)t0)[2],t2);}

/* reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11664(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11664,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11676,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11678,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=((C_word*)t0)[3];
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
/* optimizer.scm:1694: fold-right */
t9=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t5,t8,t2);}

/* a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11678(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11678,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11685,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1697: get */
t6=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[2],t4,lf[52]);}

/* k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1698: hide-variable */
t3=*((C_word*)lf[218]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}

/* k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11688,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=C_slot(t2,C_fix(2));
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1699: decompose-lambda-list */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t4,t5);}

/* a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11697,5,t0,t1,t2,t3,t4);}
t5=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t6=C_i_cdr(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_11704,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11849,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_11849(t15,t11,t6);}

/* loop2803 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11849,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[88]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11878,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g28192820 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11876 in loop2803 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11878,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28032816 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11849(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop28032816 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11849(t6,((C_word*)t0)[3],t5);}}

/* k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11704,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11707,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11800,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_11800(t10,t6,((C_word*)t0)[5],t1);}

/* loop2827 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11800(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11800,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[140]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11833,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g28462847 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k11831 in loop2827 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11833,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_11813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_11813(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_11813(t5,t4);}}

/* k11811 in k11831 in loop2827 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11813(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop28272841 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_11800(t5,((C_word*)t0)[2],t3,t4);}

/* k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11707,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11710,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[9];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11913,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11928,a[2]=t6,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t10=((C_word*)t8)[1];
f_11928(t10,t2,t5);}

/* walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11928(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11928,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11962,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11992,a[2]=t2,a[3]=t10,tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11994,a[2]=t12,a[3]=t17,a[4]=t14,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_11994(t19,t15,t6);}
else{
t10=C_eqp(t4,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t6);
t12=f_11913(((C_word*)t0)[2],t11);
t13=C_a_i_list(&a,1,t12);
/* optimizer.scm:1733: node-parameters-set! */
t14=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,t2,t13);}
else{
t11=C_eqp(t4,lf[9]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12057,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t13=C_i_car(t6);
t14=f_11913(((C_word*)t0)[2],t13);
t15=C_a_i_list(&a,1,t14);
/* optimizer.scm:1735: node-parameters-set! */
t16=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t12,t2,t15);}
else{
t12=C_eqp(t4,lf[7]);
if(C_truep(t12)){
t13=C_i_car(t6);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12110,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1738: decompose-lambda-list */
t15=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12169,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_12169(t16,t1,t8);}}}}}

/* loop2981 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12169(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12169,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12179,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g29882989 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11928(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12177 in loop2981 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12169(t3,((C_word*)t0)[2],t2);}

/* a12109 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12110(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12110,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12125,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12129,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12131,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_12131(t14,t10,t2);}

/* loop2957 in a12109 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_12131,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_11913(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop29572970 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop29572970 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12127 in a12109 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1741: build-lambda-list */
t2=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12123 in a12109 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_car(((C_word*)t0)[5],t1);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:1742: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11928(t4,((C_word*)t0)[2],t3);}

/* k12055 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12057,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12062,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_12062(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2940 in k12055 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_12062(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12062,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12072,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g29472948 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11928(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12070 in loop2940 in k12055 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_12072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12062(t3,((C_word*)t0)[2],t2);}

/* loop2903 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(3);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11994,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=f_11913(((C_word*)t0)[5],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop29032916 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop29032916 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11990 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1730: node-parameters-set! */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11960 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11962,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11967,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_11967(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2926 in k11960 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11967(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11967,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11977,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g29332934 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11928(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11975 in loop2926 in k11960 in walk in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11967(t3,((C_word*)t0)[2],t2);}

/* rename in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static C_word C_fcall f_11913(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
if(C_truep(t2)){
return(C_i_cdr(t2));}
else{
t3=t1;
return(t3);}}

/* k11708 in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11710,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1707: gensym */
t3=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[89]);}

/* k11783 in k11708 in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11785,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,1,((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11769,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t3,a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11773,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1713: append */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11771 in k11783 in k11708 in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11773,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[5]);
t3=C_a_i_plus(&a,2,((C_word*)t0)[4],t2);
/* optimizer.scm:1713: build-lambda-list */
t4=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],t1,t3,((C_word*)t0)[2]);}

/* k11767 in k11783 in k11708 in k11705 in k11702 in a11696 in k11686 in k11683 in a11677 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11769,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[6];
t4=C_slot(t3,C_fix(3));
t5=C_a_i_record(&a,4,lf[10],lf[7],t2,t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_record(&a,4,lf[10],lf[9],((C_word*)t0)[5],t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[4]);
t9=((C_word*)t0)[3];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t8));}

/* k11674 in reconstruct! in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11676,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:1691: node-subexpressions-set! */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11255(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11255,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11381,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11616,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_11616(t11,t7,t2);}

/* loop2667 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11616,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_car(t3);
t5=C_i_cadr(t3);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t8=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop26672680 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}
else{
t8=C_mutate(((C_word *)((C_word*)t0)[2])+1,t7);
t9=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t10=C_slot(t2,C_fix(1));
/* loop26672680 */
t16=t1;
t17=t10;
t1=t16;
t2=t17;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11381,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11383,a[2]=t5,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11514,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11593,a[2]=t5,a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_11593(t11,t7,((C_word*)t0)[4]);}

/* loop2691 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11593(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11593,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11603,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g27502751 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11383(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11601 in loop2691 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11593(t3,((C_word*)t0)[2],t2);}

/* k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11514,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11519,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_11519(t9,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11519(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11519,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11546,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11587,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g27722773 */
t6=t3;
f_11546(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11585 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11587,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop27562769 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11519(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop27562769 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_11519(t6,((C_word*)t0)[3],t5);}}

/* g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11546(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11546,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11584,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1680: get */
t5=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t3,lf[52]);}

/* k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11584,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11262,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11264,a[2]=t6,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11264(t8,t4,t1);}

/* walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11264(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11264,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(3));
t9=C_eqp(t4,lf[5]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11299,a[2]=t8,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1656: append */
t11=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t6,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=C_eqp(t4,lf[7]);
if(C_truep(t10)){
t11=C_i_car(t6);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11340,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1659: decompose-lambda-list */
t13=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,t11,t12);}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11357,a[2]=((C_word*)t0)[2],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_11357(t14,t1,t8);}}}

/* loop2650 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11357,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11367,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g26572658 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11264(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11365 in loop2650 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11357(t3,((C_word*)t0)[2],t2);}

/* a11339 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11340(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11340,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11345,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1662: append */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k11343 in a11339 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:1663: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_11264(t4,((C_word*)t0)[2],t3);}

/* k11297 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11299,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11304,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11304(t6,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2632 in k11297 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11304(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11304,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11314,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g26392640 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11264(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11312 in loop2632 in k11297 in walk in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11304(t3,((C_word*)t0)[2],t2);}

/* k11260 in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11262,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[6])[1];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11562,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11576,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:1686: delete-duplicates */
t7=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,*((C_word*)lf[27]+1));}

/* k11574 in k11260 in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1682: remove */
t2=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a11561 in k11260 in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11562(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11562,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[3]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,((C_word*)t0)[2])));}

/* k11558 in k11260 in k11582 in g2772 in loop2756 in k11512 in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11560,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11383(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11383,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_11505,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11507,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1671: count */
t6=*((C_word*)lf[217]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)((C_word*)t0)[5])[1]);}

/* a11506 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11507(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11507,3,t0,t1,t2);}
t3=*((C_word*)lf[27]+1);
/* g27042705 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,((C_word*)t0)[2],t2);}

/* k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11505,2,t0,t1);}
if(C_truep(C_i_greaterp(t1,C_fix(1)))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11403,a[2]=t4,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11471,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_11471(t9,t5,t4);}}

/* loop2709 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11471(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11471,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11490,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g27162717 */
t6=t3;
f_11479(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11488 in loop2709 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11471(t3,((C_word*)t0)[2],t2);}

/* g2716 in loop2709 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11479,NULL,3,t0,t1,t2);}
t3=C_i_assq(t2,((C_word*)t0)[3]);
/* optimizer.scm:1674: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_11383(t4,t1,t3);}

/* k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11403,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11413,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11421,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11425,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11427,a[2]=t7,a[3]=t12,a[4]=t9,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_11427(t14,t10,((C_word*)t0)[2]);}

/* loop2724 in k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11427,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11454,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_11454(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop27242737 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop27242737 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g2740 in loop2724 in k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static C_word C_fcall f_11454(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k11423 in k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1676: concatenate */
t2=*((C_word*)lf[216]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11419 in k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1676: append */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11411 in k11401 in k11503 in walk in k11379 in compute-extra-variables in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_cdr(((C_word*)t0)[2],t1));}

/* eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10944(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10944,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10948,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10950,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_10950(t8,t4,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10950(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10950,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10984,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t3,a[5]=t7,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t10)){
t12=t11;
f_10984(t12,t10);}
else{
t12=C_eqp(t5,lf[34]);
if(C_truep(t12)){
t13=t11;
f_10984(t13,t12);}
else{
t13=C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=t11;
f_10984(t14,t13);}
else{
t14=C_eqp(t5,lf[214]);
t15=t11;
f_10984(t15,(C_truep(t14)?t14:C_eqp(t5,lf[164])));}}}}

/* k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10984(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10984,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[7],lf[5]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10995,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10995(t6,((C_word*)t0)[8],((C_word*)t0)[5],((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[7],lf[7]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11046,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1621: decompose-lambda-list */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[8],t4,t5);}
else{
t4=C_eqp(((C_word*)t0)[7],lf[8]);
if(C_truep(t4)){
t5=C_i_car(((C_word*)t0)[3]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11103,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1627: call-with-current-continuation */
t8=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t6,t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11206,a[2]=t6,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_11206(t8,((C_word*)t0)[8],((C_word*)t0)[3]);}}}}}

/* loop2593 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11206(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11206,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11221,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g26002601 */
t6=t3;
f_11214(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11219 in loop2593 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11206(t3,((C_word*)t0)[2],t2);}

/* g2600 in loop2593 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11214(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11214,NULL,3,t0,t1,t2);}
/* optimizer.scm:1642: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10950(t3,t1,t2,((C_word*)t0)[2]);}

/* a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11103(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11103,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=C_eqp(lf[2],t3);
if(C_truep(t4)){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_slot(((C_word*)t0)[4],C_fix(2));
t8=C_i_car(t7);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11119,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t12=((C_word*)t10)[1];
f_11119(t12,t1,t8);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11119(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11119,NULL,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[6])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[6])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t5=C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11139,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11172,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=C_i_cadr(t5);
/* optimizer.scm:1636: lset<= */
t9=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,*((C_word*)lf[27]+1),t8,((C_word*)t0)[2]);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}}

/* k11170 in loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11172,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_11139(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11176,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1638: delete! */
t3=*((C_word*)lf[215]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1],*((C_word*)lf[27]+1));}}

/* k11174 in k11170 in loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* optimizer.scm:1639: return */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k11137 in loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11139,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[4]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11148,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_11148(t6,((C_word*)t0)[2],t2);}

/* loop2559 in k11137 in loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11148(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11148,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11158,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g25662567 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11119(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11156 in loop2559 in k11137 in loop in a11102 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11148(t3,((C_word*)t0)[2],t2);}

/* k11068 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11070,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11075,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_11075(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2578 in k11068 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11075(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11075,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11083,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11090,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g25852586 */
t6=t3;
f_11083(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11088 in loop2578 in k11068 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11075(t3,((C_word*)t0)[2],t2);}

/* g2585 in loop2578 in k11068 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_11083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11083,NULL,3,t0,t1,t2);}
/* optimizer.scm:1641: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10950(t3,t1,t2,((C_word*)t0)[2]);}

/* a11045 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11046(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11046,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11058,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1624: append */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k11056 in a11045 in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1624: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10950(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10995(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10995,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11013,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1616: append */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11016,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* optimizer.scm:1618: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10950(t6,t4,t5,((C_word*)t0)[3]);}}

/* k11014 in loop in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1619: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10995(t4,((C_word*)t0)[2],t2,t3);}

/* k11011 in loop in k10982 in walk in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_11013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1616: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10950(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10946 in eliminate4 in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10663(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10663,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10667,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10669,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_10669(t9,t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10669(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10669,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_10703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t9,a[7]=t3,a[8]=t7,a[9]=((C_word*)t0)[5],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t10)){
t12=t11;
f_10703(t12,t10);}
else{
t12=C_eqp(t5,lf[34]);
if(C_truep(t12)){
t13=t11;
f_10703(t13,t12);}
else{
t13=C_eqp(t5,lf[11]);
if(C_truep(t13)){
t14=t11;
f_10703(t14,t13);}
else{
t14=C_eqp(t5,lf[214]);
t15=t11;
f_10703(t15,(C_truep(t14)?t14:C_eqp(t5,lf[164])));}}}}

/* k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10703,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[10],lf[5]);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10714,a[2]=t4,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_10714(t6,((C_word*)t0)[11],((C_word*)t0)[8],((C_word*)t0)[6]);}
else{
t3=C_eqp(((C_word*)t0)[10],lf[7]);
if(C_truep(t3)){
t4=C_i_assq(((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10762,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=C_i_cdr(t4);
if(C_truep(C_i_assq(t6,((C_word*)t0)[3]))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10796,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t4);
/* optimizer.scm:1573: alist-cons */
t9=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t7,t8,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t5;
f_10762(t8,t7);}}
else{
t6=t5;
f_10762(t6,C_SCHEME_UNDEFINED);}}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10805,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_10805(t7,((C_word*)t0)[11],((C_word*)t0)[6]);}}}}

/* loop2476 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10805(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10805,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10813,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10820,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g24832484 */
t6=t3;
f_10813(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10818 in loop2476 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10805(t3,((C_word*)t0)[2],t2);}

/* g2483 in loop2476 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10813,NULL,3,t0,t1,t2);}
/* optimizer.scm:1579: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10669(t3,t1,t2,((C_word*)t0)[2]);}

/* k10794 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_10762(t3,t2);}

/* k10760 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10762(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10762,NULL,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10771,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1574: decompose-lambda-list */
t4=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}

/* a10770 in k10760 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10771(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10771,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10783,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1577: append */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10781 in a10770 in k10760 in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1577: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10669(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10714(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10714,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10732,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1564: append */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10735,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* optimizer.scm:1566: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_10669(t6,t4,t5,((C_word*)t0)[3]);}}

/* k10733 in loop in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1567: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10714(t4,((C_word*)t0)[2],t2,t3);}

/* k10730 in loop in k10701 in walk in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1564: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10669(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10665 in collect-accessibles in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10530(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10530,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10536,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1534: remove */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t3);}

/* a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10536,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10570,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10580,a[2]=t4,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1544: unzip1 */
t7=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10580,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10585,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10585(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10585(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10585,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10592,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=C_i_cddr(t4);
/* optimizer.scm:1547: lset-difference */
t7=*((C_word*)lf[194]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t5,*((C_word*)lf[27]+1),t6,t3,((C_word*)t0)[2]);}

/* k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10653,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:1548: delete-duplicates */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,*((C_word*)lf[27]+1));}

/* k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10653,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1549: append */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k10647 in k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10649,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10605,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10607,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_10607(t11,t7,((C_word*)t0)[2]);}

/* loop2406 in k10647 in k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10607,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10634,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10641,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g24222423 */
t6=t3;
f_10634(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10639 in loop2406 in k10647 in k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10641,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop24062419 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10607(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop24062419 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_10607(t6,((C_word*)t0)[3],t5);}}

/* g2422 in loop2406 in k10647 in k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10634,NULL,3,t0,t1,t2);}
/* optimizer.scm:1550: count */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10585(t3,t1,t2,((C_word*)t0)[2]);}

/* k10603 in k10647 in k10651 in k10590 in count in k10578 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1550: fold */
t2=*((C_word*)lf[133]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[213]+1),((C_word*)t0)[2],t1);}

/* k10568 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10570,2,t0,t1);}
t2=C_i_greaterp(t1,C_fix(16));
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10548,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:1537: any */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],t3,t4);}}

/* a10547 in k10568 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10548(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10548,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10555,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1538: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,lf[79]);}

/* k10553 in a10547 in k10568 in a10535 in eliminate in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10242,NULL,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10245,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t8,a[5]=t2,a[6]=t10,tmp=(C_word)a,a+=7,tmp));
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10453,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10455,a[2]=t14,a[3]=t10,a[4]=t4,a[5]=t8,a[6]=t6,tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_10455(t16,t12,t2);}

/* loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10455(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10455,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10517,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g23642365 */
t6=t3;
f_10463(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10515 in loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10455(t3,((C_word*)t0)[2],t2);}

/* g2364 in loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10463,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=C_slot(t4,C_fix(2));
t6=C_i_car(t5);
t7=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_END_OF_LIST);
t8=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_END_OF_LIST);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10478,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10488,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1523: decompose-lambda-list */
t11=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t6,t10);}

/* a10487 in g2364 in loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10488(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10488,5,t0,t1,t2,t3,t4);}
t5=C_slot(((C_word*)t0)[3],C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm:1526: walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_10245(t7,t1,t6,t2);}

/* k10476 in g2364 in loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10478(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10478,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10482,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_cons(&a,2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
/* optimizer.scm:1527: alist-cons */
t4=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[2],t3,((C_word*)((C_word*)t0)[6])[1]);}

/* k10480 in k10476 in g2364 in loop2291 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10451 in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10245(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10245,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=C_eqp(t5,lf[2]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[9]));
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_10285,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t12,a[5]=t9,a[6]=t1,a[7]=t3,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t14=C_i_memq(t12,t3);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10332,a[2]=((C_word*)t0)[3],a[3]=t12,a[4]=t13,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t14)){
t16=t15;
f_10332(2,t16,t14);}
else{
/* optimizer.scm:1499: get */
t16=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t15,((C_word*)t0)[2],t12,lf[108]);}}
else{
t12=C_eqp(t5,lf[5]);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10350,a[2]=t14,a[3]=t3,a[4]=t7,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_10350(t16,t1,t7,t9);}
else{
t13=C_eqp(t5,lf[7]);
if(C_truep(t13)){
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10404,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1511: decompose-lambda-list */
t16=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,t14,t15);}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10421,a[2]=t15,a[3]=t3,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_10421(t17,t1,t9);}}}}

/* loop2350 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10421(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10421,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10429,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10436,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g23572358 */
t6=t3;
f_10429(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10434 in loop2350 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10421(t3,((C_word*)t0)[2],t2);}

/* g2357 in loop2350 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10429,NULL,3,t0,t1,t2);}
/* optimizer.scm:1514: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10245(t3,t1,t2,((C_word*)t0)[2]);}

/* a10403 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10404(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_10404,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10416,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1513: append */
t7=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k10414 in a10403 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1513: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10245(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10350(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10350,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10368,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1506: append */
t6=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10374,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t3);
/* optimizer.scm:1508: walk */
t7=((C_word*)((C_word*)t0)[5])[1];
f_10245(t7,t5,t6,((C_word*)t0)[3]);}}

/* k10372 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1509: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_10350(t4,((C_word*)t0)[2],t2,t3);}

/* k10366 in loop in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1506: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_10245(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k10330 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10332,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_10285(t2,C_SCHEME_UNDEFINED);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=((C_word*)t0)[4];
f_10285(t4,t3);}}

/* k10283 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10285,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10288,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_assq(((C_word*)t0)[4],((C_word*)t0)[3]))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_10288(t5,t4);}
else{
t3=t2;
f_10288(t3,C_SCHEME_UNDEFINED);}}

/* k10286 in k10283 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10288(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10288,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10293,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_10293(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2325 in k10286 in k10283 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10293(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10293,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10308,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g23322333 */
t6=t3;
f_10301(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10306 in loop2325 in k10286 in k10283 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10293(t3,((C_word*)t0)[2],t2);}

/* g2332 in loop2325 in k10286 in k10283 in walk in build-call-graph in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10301(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10301,NULL,3,t0,t1,t2);}
/* optimizer.scm:1502: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_10245(t3,t1,t2,((C_word*)t0)[2]);}

/* find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10139(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10139,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10143,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10145,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1470: ##sys#hash-table-for-each */
t6=*((C_word*)lf[212]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a10144 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10145(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10145,4,t0,t1,t2,t3);}
t4=C_i_assq(lf[52],t3);
if(C_truep(t4)){
t5=C_i_assq(lf[80],t3);
if(C_truep(t5)){
t6=C_i_assq(lf[126],t3);
if(C_truep(t6)){
t7=C_i_cdr(t5);
t8=C_i_length(t7);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10173,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(lf[81],t3))){
t10=t9;
f_10173(t10,C_SCHEME_FALSE);}
else{
t10=C_i_cdr(t4);
t11=C_slot(t10,C_fix(1));
t12=C_eqp(lf[7],t11);
if(C_truep(t12)){
if(C_truep(C_i_assq(lf[108],t3))){
t13=t9;
f_10173(t13,C_SCHEME_FALSE);}
else{
t13=C_i_cdr(t6);
t14=C_i_length(t13);
t15=t9;
f_10173(t15,C_i_nequalp(t8,t14));}}
else{
t13=t9;
f_10173(t13,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k10171 in a10144 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10173(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10173,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:1481: alist-cons */
t4=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[6])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k10175 in k10171 in a10144 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10177,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10181,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:1482: alist-cons */
t5=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[2],t4,((C_word*)((C_word*)t0)[5])[1]);}

/* k10179 in k10175 in k10171 in a10144 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k10141 in find-lifting-candidates in ##compiler#perform-lambda-lifting! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8751(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8751,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_fix(0);
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8754,a[2]=t3,a[3]=t15,a[4]=t13,a[5]=t11,a[6]=t9,a[7]=t7,a[8]=t17,tmp=(C_word)a,a+=9,tmp));
t19=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8953,a[2]=t7,a[3]=t9,a[4]=t3,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t20=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9407,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10131,a[2]=t2,a[3]=t13,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1449: debugging */
t22=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t21,lf[28],lf[210]);}

/* k10129 in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10134,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1450: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8754(t3,t2,C_SCHEME_FALSE,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k10132 in k10129 in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9407(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9407,NULL,8,t0,t1,t2,t3,t4,t5,t6,t7);}
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9411,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t3,a[5]=t7,a[6]=t1,a[7]=t5,a[8]=t6,a[9]=t2,a[10]=((C_word*)t0)[3],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_pairp(t5))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10119,a[2]=t7,a[3]=t3,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10121,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#make-promise */
t11=*((C_word*)lf[208]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
/* optimizer.scm:1340: debugging */
t9=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,lf[24],lf[209],t3,t7);}}

/* a10120 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10121,2,t0,t1);}
/* optimizer.scm:1339: unzip1 */
t2=*((C_word*)lf[207]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* k10117 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1339: debugging */
t2=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],lf[24],lf[206],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9411,2,t0,t1);}
t2=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t3=((C_word*)t0)[9];
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_length(t5);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_9426,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=t6,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=t4,tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:1345: get */
t10=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t9,((C_word*)t0)[2],((C_word*)t0)[4],lf[126]);}

/* k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9426,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_9435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[11]))){
t6=C_i_length(((C_word*)t0)[11]);
if(C_truep(C_i_nequalp(t6,C_fix(4)))){
t7=C_i_caddr(((C_word*)t0)[11]);
t8=t5;
f_9435(t8,C_i_listp(t7));}
else{
t7=t5;
f_9435(t7,C_SCHEME_FALSE);}}
else{
t6=t5;
f_9435(t6,C_SCHEME_FALSE);}}

/* k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9435,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9441,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t2,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1349: caaddr */
t4=*((C_word*)lf[204]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[13]);}
else{
/* optimizer.scm:1447: bomb */
t2=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[10],lf[205],((C_word*)t0)[13]);}}

/* k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_9444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],tmp=(C_word)a,a+=16,tmp);
/* optimizer.scm:1350: cdaddr */
t3=*((C_word*)lf[203]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[14]);}

/* k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9444,2,t0,t1);}
t2=C_i_cddr(((C_word*)t0)[15]);
t3=C_i_set_car(t2,t1);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_9450,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
/* optimizer.scm:1354: node-class-set! */
t5=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],lf[185]);}

/* k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9453,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
t3=((C_word*)t0)[5];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9733,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp));
t9=((C_word*)t7)[1];
f_9733(t9,t2,t5);}

/* rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9733(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9733,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=t2;
t6=C_slot(t5,C_fix(3));
t7=t2;
t8=C_slot(t7,C_fix(1));
t9=C_eqp(t8,lf[8]);
if(C_truep(t9)){
t10=C_i_car(t6);
t11=C_i_cadr(t6);
t12=C_slot(t10,C_fix(2));
t13=C_slot(t11,C_fix(2));
t14=C_slot(t10,C_fix(1));
t15=C_eqp(lf[2],t14);
if(C_truep(t15)){
t16=C_i_car(t12);
t17=C_eqp(((C_word*)t0)[9],t16);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_9802,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=t6,a[10]=((C_word*)t0)[7],a[11]=t13,a[12]=((C_word*)t0)[8],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm:1368: alist-cons */
t19=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t19+1)))(5,t19,t18,C_SCHEME_FALSE,t2,((C_word*)((C_word*)t0)[8])[1]);}
else{
t18=C_i_car(t12);
t19=C_eqp(((C_word*)t0)[7],t18);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9955,a[2]=t2,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1393: node-class-set! */
t21=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t20,t2,lf[201]);}
else{
/* optimizer.scm:1396: bomb */
t20=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t20+1)))(3,t20,t1,lf[202]);}}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=C_eqp(t8,lf[5]);
if(C_truep(t10)){
t11=C_i_car(t4);
t12=C_i_car(t6);
if(C_truep(C_i_memq(t11,((C_word*)t0)[2]))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_10007,a[2]=t6,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1401: alist-cons */
t14=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t13,t11,t12,((C_word*)((C_word*)t0)[4])[1]);}
else{
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10022,a[2]=((C_word*)t0)[3],a[3]=t14,tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_10022(t16,t1,t6);}}
else{
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10048,a[2]=((C_word*)t0)[3],a[3]=t12,tmp=(C_word)a,a+=4,tmp));
t14=((C_word*)t12)[1];
f_10048(t14,t1,t6);}}}

/* loop2141 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10048(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10048,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10058,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g21482149 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9733(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10056 in loop2141 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10048(t3,((C_word*)t0)[2],t2);}

/* loop2128 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_10022(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10022,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10032,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g21352136 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_9733(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k10030 in loop2128 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_10022(t3,((C_word*)t0)[2],t2);}

/* k10005 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10007,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:1402: copy-node! */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[3]);}

/* k10008 in k10005 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_10010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1403: rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9733(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9953 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9955,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9958,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1394: node-parameters-set! */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k9956 in k9953 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:1395: node-subexpressions-set! */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9802,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[12])+1,t1);
t3=C_i_car(((C_word*)t0)[11]);
t4=C_eqp(((C_word*)t0)[10],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9811,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t6=C_i_cdr(((C_word*)t0)[9]);
t7=C_i_length(t6);
if(C_truep(C_i_nequalp(((C_word*)t0)[5],t7))){
t8=t5;
f_9811(2,t8,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1371: quit */
t8=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,lf[197],((C_word*)t0)[4]);}}
else{
t5=C_i_car(((C_word*)t0)[11]);
t6=C_i_assq(t5,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9849,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
/* g20962097 */
t8=t7;
f_9849(t8,((C_word*)t0)[8],t6);}
else{
/* optimizer.scm:1391: bomb */
t7=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[8],lf[200],((C_word*)t0)[11]);}}}

/* g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9849(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9849,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9859,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
t8=C_i_length(t7);
if(C_truep(C_i_nequalp(((C_word*)t0)[3],t8))){
t9=t6;
f_9859(2,t9,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1382: quit */
t9=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,lf[199],((C_word*)t0)[2]);}}

/* k9857 in g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:1385: node-class-set! */
t3=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[5]);}

/* k9860 in k9857 in g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9862,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9896,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[2],C_fix(2));
t5=C_i_caddr(t4);
/* optimizer.scm:1386: take */
t6=*((C_word*)lf[198]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_fix(1));}

/* k9894 in k9860 in k9857 in g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1386: node-parameters-set! */
t2=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9863 in k9860 in k9857 in g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9868,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t4=C_i_cddr(((C_word*)t0)[3]);
t5=C_a_i_record(&a,4,lf[10],lf[196],t3,t4);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[5]);
/* optimizer.scm:1387: node-subexpressions-set! */
t7=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,((C_word*)t0)[2],t6);}

/* k9866 in k9863 in k9860 in k9857 in g2096 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1390: rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_9733(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9809 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9811,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1374: node-class-set! */
t3=*((C_word*)lf[195]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[196]);}

/* k9812 in k9809 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,C_SCHEME_TRUE,((C_word*)t0)[2]);
/* optimizer.scm:1375: node-parameters-set! */
t4=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[3],t3);}

/* k9815 in k9812 in k9809 in k9800 in rec in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm:1376: node-subexpressions-set! */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9456,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9624,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9715,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1424: lset-difference */
t5=*((C_word*)lf[194]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* a9714 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9715,4,t0,t1,t2,t3);}
t4=C_i_cdr(t2);
t5=C_i_cdr(t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_eqp(t4,t5));}

/* k9622 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9624,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9626,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_9626(t5,((C_word*)t0)[2],t1);}

/* loop2158 in k9622 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9626(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9626,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9634,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9702,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g21652166 */
t6=t3;
f_9634(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9700 in loop2158 in k9622 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9626(t3,((C_word*)t0)[2],t2);}

/* g2165 in loop2158 in k9622 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9634,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9649,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_i_cdr(t4);
t7=C_i_length(t6);
if(C_truep(C_i_nequalp(((C_word*)t0)[3],t7))){
t8=t5;
f_9649(2,t8,C_SCHEME_UNDEFINED);}
else{
/* optimizer.scm:1414: quit */
t8=*((C_word*)lf[192]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,lf[193],((C_word*)t0)[2]);}}

/* k9647 in g2165 in loop2158 in k9622 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9649,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_list(&a,4,C_SCHEME_TRUE,C_SCHEME_FALSE,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[6]);
t5=C_i_cddr(((C_word*)t0)[6]);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_record(&a,4,lf[10],lf[189],t3,t6);
t8=C_a_i_list(&a,2,t2,t7);
/* optimizer.scm:1417: node-subexpressions-set! */
t9=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,((C_word*)t0)[3],((C_word*)t0)[2],t8);}

/* k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9456,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[4])?C_i_pairp(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_a_i_record(&a,4,lf[10],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9473,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1429: copy-node! */
t5=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[4],t3);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9544,tmp=(C_word)a,a+=2,tmp);
/* optimizer.scm:1431: fold-right */
t4=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* a9543 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9544(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9544,4,t0,t1,t2,t3);}
t4=C_i_car(t2);
t5=C_a_i_list(&a,1,t4);
t6=C_i_cdr(t2);
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_slot(t8,C_fix(2));
t11=C_slot(t8,C_fix(3));
t12=C_a_i_record(&a,4,lf[10],t9,t10,t11);
t13=C_a_i_list(&a,2,t12,t3);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_record(&a,4,lf[10],lf[5],t5,t13));}

/* k9474 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1440: copy-node! */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k9477 in k9474 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9479,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9484,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_9484(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2218 in k9477 in k9474 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9484(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9484,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cdr(t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9499,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9528,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1444: gensym */
t7=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9526 in loop2218 in k9477 in k9474 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9528,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:1444: node-parameters-set! */
t3=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k9497 in loop2218 in k9477 in k9474 in k9471 in k9454 in k9451 in k9448 in k9442 in k9439 in k9433 in k9424 in k9409 in transform in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9499,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(3));
t3=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t4=C_i_set_car(t2,t3);
t5=C_slot(((C_word*)t0)[4],C_fix(1));
t6=((C_word*)((C_word*)t0)[3])[1];
f_9484(t6,((C_word*)t0)[2],t5);}

/* scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8953(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8953,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_8956,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=t5,a[7]=t12,a[8]=t8,a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],a[11]=t10,a[12]=t6,tmp=(C_word)a,a+=13,tmp));
t14=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
t15=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_END_OF_LIST);
t16=C_set_block_item(((C_word*)t0)[5],0,C_fix(0));
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9398,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t8,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:1334: rec */
t18=((C_word*)t12)[1];
f_8956(t18,t17,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,t6);}

/* k9396 in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9405,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1335: delete */
t3=*((C_word*)lf[191]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[27]+1));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9403 in k9396 in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1335: lset= */
t2=*((C_word*)lf[190]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[27]+1),((C_word*)((C_word*)t0)[2])[1],t1);}

/* rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8956(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8956,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(3));
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=C_eqp(t11,lf[2]);
if(C_truep(t12)){
t13=C_i_car(t7);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9020,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t13,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1266: get */
t15=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t14,((C_word*)t0)[9],t13,lf[184]);}
else{
t13=C_eqp(t11,lf[14]);
if(C_truep(t13)){
if(C_truep(t3)){
t14=C_i_caddr(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9038,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=t9,a[5]=((C_word*)t0)[8],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1274: decompose-lambda-list */
t16=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,t14,t15);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=C_eqp(t11,lf[93]);
if(C_truep(t14)){
t15=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}
else{
t16=C_i_cadr(t7);
t17=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[10])[1],t16);
t18=C_mutate(((C_word *)((C_word*)t0)[10])+1,t17);
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9075,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1283: every */
t20=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t20+1)))(4,t20,t1,t19,t9);}}
else{
t15=C_eqp(t11,lf[185]);
if(C_truep(t15)){
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[6])){
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9109,a[2]=t4,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t17=C_i_car(t9);
/* optimizer.scm:1286: scan-used-variables */
t18=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t16,t17,t5);}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_FALSE);}}
else{
t16=C_eqp(t11,lf[186]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t18=C_i_cadr(t7);
/* optimizer.scm:1291: estimate-foreign-result-size */
t19=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t17,t18);}
else{
t17=C_eqp(t11,lf[188]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9166,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=t9,a[5]=t1,a[6]=t5,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t19=C_i_car(t7);
/* optimizer.scm:1299: estimate-foreign-result-size */
t20=*((C_word*)lf[187]+1);
((C_proc3)(void*)(*((C_word*)t20+1)))(3,t20,t18,t19);}
else{
t18=C_eqp(t11,lf[8]);
if(C_truep(t18)){
t19=C_i_car(t9);
t20=C_slot(t19,C_fix(1));
t21=C_eqp(lf[2],t20);
if(C_truep(t21)){
t22=C_slot(t19,C_fix(2));
t23=C_i_car(t22);
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9219,a[2]=t1,a[3]=t9,a[4]=t5,a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t25=C_eqp(t23,((C_word*)t0)[4]);
if(C_truep(t25)){
if(C_truep(C_i_zerop(((C_word*)((C_word*)t0)[10])[1]))){
t26=C_i_cadr(t9);
t27=C_slot(t26,C_fix(1));
t28=C_eqp(lf[2],t27);
if(C_truep(t28)){
t29=C_slot(t26,C_fix(2));
t30=C_i_car(t29);
t31=C_a_i_cons(&a,2,t30,((C_word*)((C_word*)t0)[3])[1]);
t32=C_mutate(((C_word *)((C_word*)t0)[3])+1,t31);
t33=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t34=t24;
f_9219(t34,C_SCHEME_TRUE);}
else{
t29=C_set_block_item(((C_word*)t0)[11],0,C_SCHEME_TRUE);
t30=t24;
f_9219(t30,C_SCHEME_TRUE);}}
else{
t26=t24;
f_9219(t26,C_SCHEME_FALSE);}}
else{
t26=t24;
f_9219(t26,C_eqp(t23,((C_word*)t0)[2]));}}
else{
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_SCHEME_FALSE);}}
else{
t19=C_eqp(t11,lf[189]);
if(C_truep(t19)){
t20=C_i_cadddr(t7);
t21=C_i_zerop(t20);
if(C_truep(t21)){
t22=t1;
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,t21);}
else{
t22=((C_word*)((C_word*)t0)[11])[1];
if(C_truep(t22)){
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,C_SCHEME_FALSE);}
else{
t23=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[10])[1],t20);
t24=C_mutate(((C_word *)((C_word*)t0)[10])+1,t23);
t25=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9328,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1325: every */
t26=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t26+1)))(4,t26,t1,t25,t9);}}}
else{
t20=C_eqp(t11,lf[9]);
if(C_truep(t20)){
t21=C_i_car(t9);
t22=C_i_car(t7);
/* optimizer.scm:1326: rec */
t66=t1;
t67=t21;
t68=t22;
t69=C_SCHEME_FALSE;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t21=C_eqp(t11,lf[5]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9361,a[2]=t5,a[3]=t7,a[4]=t1,a[5]=((C_word*)t0)[7],a[6]=t9,tmp=(C_word)a,a+=7,tmp);
t23=C_i_car(t9);
t24=C_i_car(t7);
/* optimizer.scm:1328: rec */
t66=t22;
t67=t23;
t68=t24;
t69=t2;
t70=t5;
t1=t66;
t2=t67;
t3=t68;
t4=t69;
t5=t70;
goto loop;}
else{
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9385,a[2]=t5,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1330: every */
t23=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t1,t22,t9);}}}}}}}}}}}

/* a9384 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9385(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9385,3,t0,t1,t2);}
/* optimizer.scm:1330: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9359 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9361(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9361,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9372,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1329: append */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9370 in k9359 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1329: rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8956(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* a9327 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9328,3,t0,t1,t2);}
/* optimizer.scm:1325: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9217 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9219(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9219,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9224,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:1318: every */
t4=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9223 in k9217 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9224(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9224,3,t0,t1,t2);}
/* optimizer.scm:1318: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9164 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9166,2,t0,t1);}
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9172(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_9172(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_9172(t7,C_SCHEME_TRUE);}}}

/* k9170 in k9164 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9172(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9172,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9177,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1305: every */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9176 in k9170 in k9164 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9177(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9177,3,t0,t1,t2);}
/* optimizer.scm:1305: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9123 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
t2=C_i_zerop(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_9131(t4,t2);}
else{
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_9131(t5,C_SCHEME_FALSE);}
else{
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],t1);
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=t3;
f_9131(t7,C_SCHEME_TRUE);}}}

/* k9129 in k9123 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_9131(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9131,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9136,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1297: every */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a9135 in k9129 in k9123 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9136,3,t0,t1,t2);}
/* optimizer.scm:1297: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k9107 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9109,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9105,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1288: alist-cons */
t3=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k9103 in k9107 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* a9074 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9075,3,t0,t1,t2);}
/* optimizer.scm:1283: rec */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8956(t3,t1,t2,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* a9037 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9038(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_9038,5,t0,t1,t2,t3,t4);}
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t6=C_mutate(((C_word *)((C_word*)t0)[5])+1,t5);
t7=C_i_car(((C_word*)t0)[4]);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9054,a[2]=t7,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1278: append */
t9=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t8,t2,((C_word*)t0)[2]);}

/* k9052 in a9037 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1278: rec */
t2=((C_word*)((C_word*)t0)[4])[1];
f_8956(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,C_SCHEME_FALSE,t1);}

/* k9018 in rec in scan in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_9020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9020,2,t0,t1);}
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_memq(((C_word*)t0)[5],((C_word*)t0)[4]);
t4=C_i_not(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t5)){
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(2));
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}}}}

/* walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8754(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word *a;
loop:
a=C_alloc(22);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8754,NULL,5,t0,t1,t2,t3,t4);}
t5=t3;
t6=C_slot(t5,C_fix(2));
t7=t3;
t8=C_slot(t7,C_fix(3));
t9=t3;
t10=C_slot(t9,C_fix(1));
t11=C_eqp(t10,lf[14]);
if(C_truep(t11)){
t12=C_i_caddr(t6);
t13=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_8794,a[2]=((C_word*)t0)[4],a[3]=t8,a[4]=((C_word*)t0)[5],a[5]=t4,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[8],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t2)){
if(C_truep(C_i_cadr(t6))){
t14=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8879,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=t8,a[7]=t3,a[8]=t12,a[9]=t13,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1241: get */
t15=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t14,((C_word*)t0)[2],t2,lf[81]);}
else{
t14=t13;
f_8794(2,t14,C_SCHEME_FALSE);}}
else{
t14=t13;
f_8794(2,t14,C_SCHEME_FALSE);}}
else{
t12=C_eqp(t10,lf[9]);
if(C_truep(t12)){
t13=C_i_car(t6);
t14=C_i_car(t8);
/* optimizer.scm:1251: walk */
t26=t1;
t27=t13;
t28=t14;
t29=C_SCHEME_FALSE;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t13=C_eqp(t10,lf[5]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8905,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t15=C_i_car(t6);
t16=C_i_car(t8);
/* optimizer.scm:1253: walk */
t26=t14;
t27=t15;
t28=t16;
t29=t3;
t1=t26;
t2=t27;
t3=t28;
t4=t29;
goto loop;}
else{
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8925,a[2]=t15,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t17=((C_word*)t15)[1];
f_8925(t17,t1,t8);}}}}

/* loop1917 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8925(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8925,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8933,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8940,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g19241925 */
t6=t3;
f_8933(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8938 in loop1917 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8925(t3,((C_word*)t0)[2],t2);}

/* g1924 in loop1917 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8933,NULL,3,t0,t1,t2);}
/* optimizer.scm:1255: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8754(t3,t1,C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8903 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:1254: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_8754(t3,((C_word*)t0)[2],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}

/* k8877 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8879(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8879,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
f_8794(2,t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_8825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:1243: get */
t3=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5],lf[52]);}
else{
t2=((C_word*)t0)[9];
f_8794(2,t2,C_SCHEME_FALSE);}}}

/* k8823 in k8877 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8825,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1244: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[80]);}
else{
t2=((C_word*)t0)[4];
f_8794(2,t2,C_SCHEME_FALSE);}}

/* k8829 in k8823 in k8877 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8831,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_8837,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:1245: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[6],lf[126]);}
else{
t2=((C_word*)t0)[4];
f_8794(2,t2,C_SCHEME_FALSE);}}

/* k8835 in k8829 in k8823 in k8877 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8837,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[10],((C_word*)t0)[9]);
if(C_truep(t2)){
t3=C_i_length(((C_word*)t0)[8]);
t4=C_i_length(t1);
if(C_truep(C_i_nequalp(t3,t4))){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_i_car(((C_word*)t0)[6]);
t7=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
/* optimizer.scm:1248: scan */
t8=((C_word*)((C_word*)t0)[4])[1];
f_8953(t8,((C_word*)t0)[3],t5,t6,((C_word*)t0)[5],((C_word*)t0)[2],t7);}
else{
t5=((C_word*)t0)[3];
f_8794(2,t5,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_8794(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
f_8794(2,t2,C_SCHEME_FALSE);}}

/* k8792 in walk in ##compiler#transform-direct-lambdas! in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:1249: transform */
t2=((C_word*)((C_word*)t0)[11])[1];
f_9407(t2,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:1250: walk */
t3=((C_word*)((C_word*)t0)[2])[1];
f_8754(t3,((C_word*)t0)[10],C_SCHEME_FALSE,t2,C_SCHEME_FALSE);}}

/* ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6336(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_6336,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
switch(t6){
case C_fix(1):
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6398,a[2]=t5,a[3]=t8,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);
case C_fix(2):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_length(t8);
t10=C_i_car(t7);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6549,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:47: ##sys#get */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[51]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(3):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6618,a[2]=t7,a[3]=t8,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(4):
if(C_truep(*((C_word*)lf[144]+1))){
if(C_truep(*((C_word*)lf[148]+1))){
t9=C_i_length(t8);
if(C_truep(C_i_nequalp(C_fix(2),t9))){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6694,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t11=t4;
/* tweaks.scm:47: ##sys#get */
t12=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t10,t11,lf[51]);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(5):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6762,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(6):
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[148]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[144]+1))){
t11=C_i_length(t8);
if(C_truep(C_i_nequalp(C_fix(1),t11))){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6867,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:47: ##sys#get */
t14=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,lf[51]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(7):
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[148]+1));
if(C_truep(t10)){
if(C_truep(*((C_word*)lf[144]+1))){
t11=C_i_length(t8);
t12=C_i_car(t7);
if(C_truep(C_i_nequalp(t11,t12))){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6956,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t14=t4;
/* tweaks.scm:47: ##sys#get */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[51]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}
case C_fix(8):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7029,a[2]=t8,a[3]=t5,a[4]=t2,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(9):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7055,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(10):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_cadddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[148]+1));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7298,a[2]=t1,a[3]=t5,a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:47: ##sys#get */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[51]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(11):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_caddr(t7);
t10=(C_truep(t9)?t9:*((C_word*)lf[148]+1));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7397,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:47: ##sys#get */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[51]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(12):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7468,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(13):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7556,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(14):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_cadr(t7);
t10=C_i_length(t8);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7633,a[2]=t1,a[3]=t5,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:47: ##sys#get */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[51]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(15):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_length(t8);
if(C_truep(C_i_nequalp(C_fix(1),t9))){
t10=*((C_word*)lf[148]+1);
t11=(C_truep(t10)?t10:C_i_cadddr(t7));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7727,a[2]=t8,a[3]=t5,a[4]=t1,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=t4;
/* tweaks.scm:47: ##sys#get */
t14=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,lf[51]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(16):
t9=C_i_car(t7);
t10=C_i_length(t8);
t11=C_i_cadddr(t7);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7812,a[2]=t4,a[3]=t11,a[4]=t1,a[5]=t5,a[6]=t8,a[7]=t7,a[8]=t10,a[9]=t9,tmp=(C_word)a,a+=10,tmp);
t13=C_i_cddddr(t7);
if(C_truep(C_i_pairp(t13))){
/* optimizer.scm:1048: fifth */
t14=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t12,t7);}
else{
t14=t12;
f_7812(2,t14,C_SCHEME_FALSE);}
case C_fix(17):
if(C_truep(*((C_word*)lf[144]+1))){
t9=C_i_length(t8);
t10=C_i_car(t7);
if(C_truep(C_i_nequalp(t9,t10))){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7957,a[2]=t7,a[3]=t1,a[4]=t5,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t12=t4;
/* tweaks.scm:47: ##sys#get */
t13=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t11,t12,lf[51]);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(18):
if(C_truep(*((C_word*)lf[144]+1))){
if(C_truep(C_i_nullp(t8))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8036,a[2]=t7,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(19):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8076,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(20):
t9=C_i_length(t8);
t10=C_i_cadddr(t7);
t11=(C_truep(t10)?t10:*((C_word*)lf[148]+1));
if(C_truep(t11)){
if(C_truep(*((C_word*)lf[144]+1))){
t12=C_i_car(t7);
if(C_truep(C_i_nequalp(t9,t12))){
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8258,a[2]=t8,a[3]=t9,a[4]=t1,a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t14=t4;
/* tweaks.scm:47: ##sys#get */
t15=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[51]);}
else{
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(21):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8343,a[2]=t8,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
case C_fix(22):
t9=C_i_car(t7);
t10=C_i_length(t8);
t11=C_i_cadddr(t7);
if(C_truep(*((C_word*)lf[144]+1))){
if(C_truep(C_i_nequalp(t10,t9))){
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8538,a[2]=t11,a[3]=t1,a[4]=t5,a[5]=t8,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t13=t4;
/* tweaks.scm:47: ##sys#get */
t14=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t12,t13,lf[51]);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}
case C_fix(23):
if(C_truep(*((C_word*)lf[144]+1))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8618,a[2]=t5,a[3]=t1,a[4]=t8,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t10=t4;
/* tweaks.scm:47: ##sys#get */
t11=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[51]);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}
default:
/* optimizer.scm:1216: bomb */
t9=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t1,lf[182]);}}

/* k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8618,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_length(((C_word*)t0)[4]);
t4=C_i_car(((C_word*)t0)[5]);
if(C_truep(C_i_greater_or_equalp(t3,t4))){
t5=C_i_cadr(((C_word*)t0)[5]);
t6=C_a_i_list(&a,2,C_SCHEME_TRUE,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8643,a[2]=t6,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8647,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
t9=C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm:1202: varnode */
t10=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t8,t9);}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8647,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8651,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8659,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8659(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8659,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8667,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8673,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_8673(t9,t4,t3,t5);}

/* loop in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_8673(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8673,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8693,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t3);
if(C_truep(C_i_symbolp(t5))){
/* optimizer.scm:824: varnode */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6361,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t5))){
t7=C_i_car(t5);
t8=t6;
f_6361(t8,C_eqp(lf[34],t7));}
else{
t7=t6;
f_6361(t7,C_SCHEME_FALSE);}}}}
else{
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8722,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
t7=C_i_cdr(t3);
/* optimizer.scm:1214: loop */
t13=t5;
t14=t6;
t15=t7;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k8720 in loop in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8722,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k6359 in loop in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[3]);
/* optimizer.scm:825: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
/* optimizer.scm:826: qnode */
t2=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k8691 in loop in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8697,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:1212: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_8673(t4,t2,C_SCHEME_END_OF_LIST,t3);}

/* k8695 in k8691 in loop in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8697,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k8665 in a8658 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1205: append */
t2=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8652 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8653,2,t0,t1);}
/* optimizer.scm:1204: split-at */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8649 in k8645 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1201: cons* */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k8641 in k8616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8643,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k8536 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8538,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:*((C_word*)lf[148]+1));
if(C_truep(t3)){
t4=C_eqp(*((C_word*)lf[152]+1),lf[157]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1183: fifth */
t6=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[6]);}
else{
t5=C_i_cadr(((C_word*)t0)[6]);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[2]);
t7=((C_word*)t0)[5];
t8=C_a_i_record(&a,4,lf[10],lf[93],t6,t7);
t9=C_a_i_list(&a,2,((C_word*)t0)[4],t8);
t10=((C_word*)t0)[3];
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_record(&a,4,lf[10],lf[8],lf[180],t9));}}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8580 in k8536 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8582,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=C_a_i_record(&a,4,lf[10],lf[145],t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],lf[180],t5));}

/* k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8343,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8349,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:1143: fifth */
t4=*((C_word*)lf[169]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8349,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[6]);
t3=(C_truep(*((C_word*)lf[148]+1))?C_i_caddr(((C_word*)t0)[6]):C_i_cadr(((C_word*)t0)[6]));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8358,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8465,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1147: remove */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a8464 in k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8465(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8465,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k8356 in k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8358,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8380,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1152: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[5]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_i_car(t1);
t4=C_a_i_list(&a,2,((C_word*)t0)[7],t3);
t5=((C_word*)t0)[6];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[178],t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8418,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:1160: fold-inner */
t5=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,t1);}}}

/* a8419 in k8356 in k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8420,4,t0,t1,t2,t3);}
t4=C_eqp(*((C_word*)lf[152]+1),lf[157]);
if(C_truep(t4)){
t5=C_a_i_list(&a,1,((C_word*)t0)[4]);
t6=C_a_i_list(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[145],t5,t6));}
else{
t5=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t6=C_a_i_list(&a,2,t2,t3);
t7=t1;
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[93],t5,t6));}}

/* k8416 in k8356 in k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8418,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[179],t2));}

/* k8378 in k8356 in k8347 in k8341 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8380,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[177],t2));}

/* k8256 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8258,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8287,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8289,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8299,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8298 in k8256 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8299(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8299,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8311,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:1131: qnode */
t6=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k8309 in a8298 in k8256 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8311,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:1130: append */
t3=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a8288 in k8256 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8289,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
/* optimizer.scm:1129: split-at */
t3=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,((C_word*)t0)[2],t2);}

/* k8285 in k8256 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8287,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[145],((C_word*)t0)[4],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],lf[176],t3));}

/* k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(C_truep(*((C_word*)lf[148]+1))?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5]));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8085,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8182,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1098: remove */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a8181 in k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8182(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8182,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(lf[34],t4);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=C_i_car(t7);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}

/* k8083 in k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8085,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8107,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:1103: qnode */
t3=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=C_i_car(t1);
t4=C_a_i_list(&a,2,((C_word*)t0)[6],t3);
t5=((C_word*)t0)[5];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[173],t4));}
else{
t3=C_i_cadddr(((C_word*)t0)[3]);
t4=(C_truep(t3)?t3:C_eqp(*((C_word*)lf[152]+1),lf[157]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8154,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8156,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:1111: fold-inner */
t7=*((C_word*)lf[175]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}}}

/* a8155 in k8083 in k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8156(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8156,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
t5=C_a_i_list(&a,2,t2,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[145],t4,t5));}

/* k8152 in k8083 in k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8154,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[174],t2));}

/* k8105 in k8083 in k8074 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8107,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[172],t2));}

/* k8034 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8036,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8052,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:1085: qnode */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8050 in k8034 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_8052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8052,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[171],t2));}

/* k7955 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7957,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7986,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[148]+1))){
t3=C_i_cddr(((C_word*)t0)[2]);
t4=C_i_pairp(t3);
t5=t2;
f_7986(t5,(C_truep(t4)?C_i_caddr(((C_word*)t0)[2]):C_i_cadr(((C_word*)t0)[2])));}
else{
t3=t2;
f_7986(t3,C_i_cadr(((C_word*)t0)[2]));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7984 in k7955 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7986(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7986,NULL,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[4];
t4=C_a_i_record(&a,4,lf[10],lf[145],t2,t3);
t5=C_a_i_list(&a,2,((C_word*)t0)[3],t4);
t6=((C_word*)t0)[2];
t7=t6;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[8],lf[170],t5));}

/* k7810 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7812,2,t0,t1);}
if(C_truep(*((C_word*)lf[144]+1))){
t2=C_i_not(((C_word*)t0)[9]);
t3=(C_truep(t2)?t2:C_i_nequalp(((C_word*)t0)[8],((C_word*)t0)[9]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7835,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
/* tweaks.scm:47: ##sys#get */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,lf[51]);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7833 in k7810 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7835,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:*((C_word*)lf[148]+1));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7869,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7873,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7899,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t7=C_i_positivep(((C_word*)t0)[3]);
t8=t6;
f_7899(t8,(C_truep(t7)?C_i_less_or_equalp(((C_word*)t0)[3],C_fix(8)):C_SCHEME_FALSE));}
else{
t7=t6;
f_7899(t7,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7897 in k7833 in k7810 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7899(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:1059: conc */
t3=*((C_word*)lf[168]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_7873(2,t2,C_i_cadr(((C_word*)t0)[4]));}}

/* k7871 in k7833 in k7810 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7873,2,t0,t1);}
t2=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[4]);
if(C_truep(t2)){
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
f_7869(t4,C_a_i_list(&a,2,t1,t3));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=C_i_car(((C_word*)t0)[4]);
t4=C_a_i_times(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
f_7869(t5,C_a_i_list(&a,2,t1,t4));}
else{
t3=((C_word*)t0)[2];
f_7869(t3,C_a_i_list(&a,2,t1,((C_word*)t0)[4]));}}}

/* k7867 in k7833 in k7810 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7869(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7869,NULL,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=C_a_i_record(&a,4,lf[10],lf[93],t1,t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[167],t4));}

/* k7725 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7727,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(*((C_word*)lf[152]+1),t2);
if(C_truep(t3)){
t4=C_i_caddr(((C_word*)t0)[5]);
t5=C_a_i_list(&a,2,C_SCHEME_TRUE,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7749,a[2]=t5,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm:1031: varnode */
t9=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}
else{
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_eqp(*((C_word*)lf[152]+1),t4);
if(C_truep(t5)){
t6=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t7=((C_word*)t0)[4];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[8],lf[166],t6));}
else{
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7751 in k7725 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:1031: cons* */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7747 in k7725 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7749,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k7631 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7633,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(*((C_word*)lf[152]+1),t2);
if(C_truep(t3)){
t4=C_i_cadddr(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:*((C_word*)lf[148]+1));
if(C_truep(t5)){
t6=(C_truep(*((C_word*)lf[148]+1))?C_i_cadddr(((C_word*)t0)[5]):C_i_caddr(((C_word*)t0)[5]));
t7=C_a_i_list(&a,1,t6);
t8=((C_word*)t0)[4];
t9=C_a_i_record(&a,4,lf[10],lf[145],t7,t8);
t10=C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[10],lf[8],lf[165],t10));}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7554 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7556,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(C_truep(t2)?t2:*((C_word*)lf[148]+1));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7580,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t6=C_i_cdr(((C_word*)t0)[2]);
t7=t5;
f_7580(t7,C_a_i_cons(&a,2,C_SCHEME_TRUE,t6));}
else{
t6=t5;
f_7580(t6,((C_word*)t0)[2]);}}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7578 in k7554 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7580(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7580,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7584,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],C_SCHEME_TRUE);
t4=C_a_i_record(&a,4,lf[10],lf[164],t3,C_SCHEME_END_OF_LIST);
/* optimizer.scm:1004: cons* */
t5=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7582 in k7578 in k7554 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7584,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],t3,t1));}

/* k7466 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7468,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:*((C_word*)lf[148]+1));
if(C_truep(t3)){
t4=C_i_length(((C_word*)t0)[4]);
t5=C_i_caddr(((C_word*)t0)[5]);
if(C_truep(C_i_less_or_equalp(t4,t5))){
t6=C_eqp(t4,C_fix(1));
if(C_truep(t6)){
t7=C_a_i_cons(&a,2,((C_word*)t0)[3],((C_word*)t0)[4]);
t8=((C_word*)t0)[2];
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record(&a,4,lf[10],lf[8],lf[163],t7));}
else{
t7=C_i_car(((C_word*)t0)[5]);
t8=C_a_i_list(&a,2,C_SCHEME_TRUE,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7520,a[2]=t8,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7524,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
t11=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:994: varnode */
t12=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t10,t11);}}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7522 in k7466 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:994: cons* */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7518 in k7466 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7520,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k7395 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7397,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t5=t4;
f_7409(t5,t3);}
else{
t5=C_i_length(((C_word*)t0)[2]);
t6=C_i_car(((C_word*)t0)[5]);
t7=t4;
f_7409(t7,C_i_nequalp(t5,t6));}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7407 in k7395 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7409(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7409,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,C_SCHEME_TRUE,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7425,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7429,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=C_i_cadr(((C_word*)t0)[5]);
/* optimizer.scm:979: varnode */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7427 in k7407 in k7395 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:979: cons* */
t2=*((C_word*)lf[162]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7423 in k7407 in k7395 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7425,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k7296 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7298,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:959: < */
C_lessp(5,0,t3,C_fix(0),t2,C_fix(3));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7305 in k7296 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7307,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7327,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:961: varnode */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7325 in k7305 in k7296 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7327,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=((C_word*)t0)[5],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:964: qnode */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k7333 in k7325 in k7305 in k7296 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7339,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t3))){
t4=C_i_caddr(((C_word*)t0)[2]);
/* optimizer.scm:966: varnode */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}
else{
t4=t2;
f_7339(2,t4,C_i_cadr(((C_word*)t0)[3]));}}

/* k7337 in k7333 in k7325 in k7305 in k7296 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7339,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t2));}

/* k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7055,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
if(C_truep(C_i_lessp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7077,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:932: qnode */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7083,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(*((C_word*)lf[148]+1))){
t4=C_eqp(*((C_word*)lf[152]+1),lf[161]);
t5=t3;
f_7083(t5,C_i_not(t4));}
else{
t4=t3;
f_7083(t4,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7083(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7083,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=t2;
f_7086(t3,t1);}
else{
t3=C_eqp(*((C_word*)lf[152]+1),lf[157]);
t4=(C_truep(t3)?C_i_caddr(((C_word*)t0)[5]):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=t2;
f_7086(t5,t4);}
else{
t5=C_eqp(*((C_word*)lf[152]+1),lf[160]);
t6=t2;
f_7086(t6,(C_truep(t5)?C_i_cadddr(((C_word*)t0)[5]):C_SCHEME_FALSE));}}}

/* k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7199,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7199(t10,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop1445 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7199(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7199,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7233,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* optimizer.scm:936: gensym */
t5=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7231 in loop1445 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7233,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14451458 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7199(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14451458 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7199(t6,((C_word*)t0)[3],t5);}}

/* k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7089,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7092,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7164,a[2]=t3,a[3]=t8,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_7164(t10,t6,t1);}

/* loop1470 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_7164(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7164,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7193,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g14861487 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7191 in loop1470 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7193,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14701483 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7164(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop14701483 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7164(t6,((C_word*)t0)[3],t5);}}

/* k7090 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7097,tmp=(C_word)a,a+=2,tmp);
t3=C_eqp(*((C_word*)lf[152]+1),lf[157]);
t4=(C_truep(t3)?C_i_car(((C_word*)t0)[6]):C_i_cadr(((C_word*)t0)[6]));
t5=C_a_i_list(&a,1,t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7136,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:948: fold-boolean */
t8=*((C_word*)lf[159]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,t1);}

/* a7135 in k7090 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7136(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7136,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,2,t2,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[145],((C_word*)t0)[2],t4));}

/* k7132 in k7090 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7134,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_record(&a,4,lf[10],lf[8],lf[158],t2);
/* optimizer.scm:938: fold-right */
t4=*((C_word*)lf[132]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[5],((C_word*)t0)[4],t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7096 in k7090 in k7087 in k7084 in k7081 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7097(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7097,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t3);
t6=C_a_i_list(&a,2,t2,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],t5,t6));}

/* k7075 in k7053 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7077,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[156],t2));}

/* k7027 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_7029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[6]);
/* g14201421 */
t3=t2;
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6954 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6956,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6985,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6993,a[2]=((C_word*)t0)[2],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_caddr(((C_word*)t0)[5]);
/* optimizer.scm:918: qnode */
t7=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t5,t6);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6991 in k6954 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6993,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:917: append */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k6983 in k6954 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6985,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[145],((C_word*)t0)[4],t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],lf[155],t3));}

/* k6865 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6867,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
t4=C_i_cadr(((C_word*)t0)[5]);
t5=C_a_i_list(&a,1,t4);
t6=((C_word*)t0)[4];
t7=C_a_i_record(&a,4,lf[10],lf[145],t5,t6);
t8=C_a_i_list(&a,1,t7);
t9=C_a_i_record(&a,4,lf[10],lf[145],t3,t8);
t10=C_a_i_list(&a,2,((C_word*)t0)[3],t9);
t11=((C_word*)t0)[2];
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[10],lf[8],lf[154],t10));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6760 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6762,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[5]);
if(C_truep(C_i_nequalp(C_fix(1),t2))){
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_i_not(t3);
t5=(C_truep(t4)?t4:C_eqp(t3,*((C_word*)lf[152]+1)));
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[4]);
t7=C_a_i_list(&a,1,t6);
t8=C_i_car(((C_word*)t0)[5]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t7,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=C_i_cadr(((C_word*)t0)[4]);
/* optimizer.scm:894: qnode */
t11=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t11+1)))(3,t11,t9,t10);}
else{
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6815 in k6760 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6817,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_record(&a,4,lf[10],lf[145],((C_word*)t0)[4],t2);
t4=C_a_i_list(&a,2,((C_word*)t0)[3],t3);
t5=((C_word*)t0)[2];
t6=t5;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],lf[8],lf[153],t4));}

/* k6692 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6694,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_a_i_list(&a,2,C_SCHEME_FALSE,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6714,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(((C_word*)t0)[5]);
/* optimizer.scm:876: varnode */
t6=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6712 in k6692 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6714,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
/* optimizer.scm:879: qnode */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k6720 in k6712 in k6692 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6722,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[7]);
t3=C_a_i_list(&a,5,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],t1,t2);
t4=((C_word*)t0)[3];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t3));}

/* k6616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6618,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6623,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6661,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* optimizer.scm:866: varnode */
t5=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6659 in k6616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6661,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_record(&a,4,lf[10],lf[8],lf[151],t2);
/* optimizer.scm:863: fold-right */
t4=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* a6622 in k6616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6623(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6623,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6644,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:865: gensym */
t5=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[150]);}

/* k6642 in a6622 in k6616 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6644,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
t4=((C_word*)t0)[2];
t5=t4;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[10],lf[5],t2,t3));}

/* k6547 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6549,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[5]);
t3=(C_truep(t2)?t2:*((C_word*)lf[148]+1));
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[4]);
t5=C_i_cadr(((C_word*)t0)[5]);
t6=C_a_i_list(&a,1,t5);
t7=((C_word*)t0)[4];
t8=C_a_i_record(&a,4,lf[10],lf[145],t6,t7);
t9=C_a_i_list(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_record(&a,4,lf[10],lf[8],lf[149],t9));}
else{
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6396 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_length(((C_word*)t0)[3]);
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_nequalp(t3,t4))){
t5=C_i_car(((C_word*)t0)[3]);
t6=C_i_cadr(((C_word*)t0)[3]);
t7=C_slot(t5,C_fix(1));
t8=C_eqp(lf[2],t7);
if(C_truep(t8)){
t9=C_slot(t6,C_fix(1));
t10=C_eqp(lf[2],t9);
if(C_truep(t10)){
t11=C_slot(t5,C_fix(2));
t12=C_slot(t6,C_fix(2));
if(C_truep(C_i_equalp(t11,t12))){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6479,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:840: qnode */
t14=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t14+1)))(3,t14,t13,C_SCHEME_TRUE);}
else{
t13=t2;
f_6401(t13,C_SCHEME_FALSE);}}
else{
t11=t2;
f_6401(t11,C_SCHEME_FALSE);}}
else{
t9=t2;
f_6401(t9,C_SCHEME_FALSE);}}
else{
t5=t2;
f_6401(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6477 in k6396 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6479,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_6401(t3,C_a_i_record(&a,4,lf[10],lf[8],lf[147],t2));}

/* k6399 in k6396 in ##compiler#simplify-named-call in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6401(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6401,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(*((C_word*)lf[144]+1))){
t2=C_i_cadr(((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
t4=((C_word*)t0)[3];
t5=C_a_i_record(&a,4,lf[10],lf[145],t3,t4);
t6=C_a_i_list(&a,2,((C_word*)t0)[2],t5);
t7=((C_word*)t0)[5];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[8],lf[146],t6));}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* ##compiler#rewrite in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6316(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_6316r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_6316r(t0,t1,t2,t3);}}

static void C_ccall f_6316r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6320,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:818: ##sys#hash-table-ref */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[141]+1),t2);}

/* k6318 in ##compiler#rewrite in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6320,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* optimizer.scm:819: append */
t5=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t2,t4);}

/* k6328 in k6318 in ##compiler#rewrite in k6312 in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:819: ##sys#hash-table-set! */
t2=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[141]+1),((C_word*)t0)[2],t1);}

/* ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5827,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5831,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,a[6]=t6,tmp=(C_word)a,a+=7,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6263,a[2]=t8,a[3]=t13,a[4]=t10,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_6263(t15,t11,t2,t3);}

/* loop1083 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6263(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6263,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[140]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6296,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g11021103 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6294 in loop1083 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6296,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6276,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_6276(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_6276(t5,t4);}}

/* k6274 in k6294 in loop1083 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6276(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop10831097 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6263(t5,((C_word*)t0)[2],t3,t4);}

/* k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5833,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6216,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_6216(t7,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1109 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6216(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6216,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6224,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6236,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g11331134 */
t10=t6;
f_6224(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6234 in loop1109 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6216(t4,((C_word*)t0)[2],t2,t3);}

/* g1133 in loop1109 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6224(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6224,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6229,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6233,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:742: scan-used-variables */
t6=*((C_word*)lf[139]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,((C_word*)t0)[2]);}

/* k6231 in g1133 in loop1109 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:742: alist-cons */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6227 in g1133 in loop1109 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6136,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_6136(t10,t6,((C_word*)t0)[2]);}

/* loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6136(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6136,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6144,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6203,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11501151 */
t6=t3;
f_6144(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6201 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6136(t3,((C_word*)t0)[2],t2);}

/* g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6144(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6144,NULL,3,t0,t1,t2);}
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[5])[1]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6154,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6176,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:751: filter */
t5=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}}

/* a6175 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6176(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6176,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6189,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:752: find-path */
t5=((C_word*)t0)[2];
f_5833(t5,t4,((C_word*)t0)[3],t2);}}

/* k6187 in a6175 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* optimizer.scm:752: find-path */
t2=((C_word*)t0)[5];
f_5833(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k6152 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6158,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6170,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:754: gensym */
t4=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k6168 in k6152 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6170,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* optimizer.scm:754: alist-cons */
t3=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],t1,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k6156 in k6152 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6158,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6162,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[3]);
/* optimizer.scm:755: append */
t5=*((C_word*)lf[6]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);}

/* k6160 in k6156 in k6152 in g1150 in loop1143 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5881,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5884,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6055,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[7],a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_6055(t8,t4,((C_word*)((C_word*)t0)[7])[1]);}

/* loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6055,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6123,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11701171 */
t6=t3;
f_6063(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6121 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6055(t3,((C_word*)t0)[2],t2);}

/* g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_6063(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6063,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6070,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* optimizer.scm:764: append-map */
t7=*((C_word*)lf[138]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}

/* a6105 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6106,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6112,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:765: filter */
t4=*((C_word*)lf[137]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a6111 in a6105 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6112,3,t0,t1,t2);}
/* optimizer.scm:765: find-path */
t3=((C_word*)t0)[3];
f_5833(t3,t1,((C_word*)t0)[2],t2);}

/* k6068 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6074,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6078,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6080,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:770: filter-map */
t5=*((C_word*)lf[136]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* a6079 in k6068 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6080(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6080,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6093,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* optimizer.scm:771: lset<= */
t6=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,*((C_word*)lf[27]+1),t5,((C_word*)t0)[2]);}}

/* k6091 in a6079 in k6068 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6093(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE));}

/* k6076 in k6068 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:768: alist-cons */
t2=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6072 in k6068 in g1170 in loop1163 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5884,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5887,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:777: topological-sort */
t3=*((C_word*)lf[134]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[27]+1));}

/* k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5887,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5907,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:782: fold */
t6=*((C_word*)lf[133]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,((C_word*)t0)[2],t1);}

/* a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5907(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5907,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[5])[1]);
t5=C_i_cdr(t4);
t6=C_i_car(t5);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5920,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
t8=C_i_cdr(t5);
if(C_truep(C_i_nullp(t8))){
t9=C_i_assq(t6,((C_word*)((C_word*)t0)[2])[1]);
t10=C_i_cdr(t9);
t11=C_i_memq(t6,t10);
t12=t7;
f_5920(t12,C_i_not(t11));}
else{
t9=t7;
f_5920(t9,C_SCHEME_FALSE);}}

/* k5918 in a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_5920(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5920,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_assq(((C_word*)t0)[7],((C_word*)t0)[5]);
t5=C_i_cdr(t4);
t6=C_a_i_list(&a,2,t5,((C_word*)t0)[4]);
t7=((C_word*)t0)[3];
t8=t7;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t6));}
else{
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5949,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5979,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5981,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:796: fold-right */
t5=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,t4,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* a5980 in k5918 in a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5981,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6027,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:799: gensym */
t5=*((C_word*)lf[88]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k6025 in a5980 in k5918 in a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_6027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6027,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_a_i_list(&a,1,((C_word*)t0)[5]);
t4=C_i_assq(((C_word*)t0)[5],((C_word*)t0)[4]);
t5=C_i_cdr(t4);
t6=C_a_i_list(&a,1,t5);
t7=C_a_i_record(&a,4,lf[10],lf[9],t3,t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_record(&a,4,lf[10],lf[5],t2,t8));}

/* k5977 in k5918 in a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:791: fold-right */
t2=*((C_word*)lf[132]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a5948 in k5918 in a5906 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5949,4,t0,t1,t2,t3);}
t4=C_a_i_list(&a,1,t2);
t5=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t6=C_a_i_list(&a,2,t5,t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[10],lf[5],t4,t6));}

/* k5888 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5890,2,t0,t1);}
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[3])[1]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5899,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:808: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[131],((C_word*)((C_word*)t0)[3])[1]);}
else{
/* optimizer.scm:810: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}}

/* k5897 in k5888 in k5885 in k5882 in k5879 in k5876 in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:809: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* find-path in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_5833(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5833,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5839,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_5839(t7,t1,t2,C_SCHEME_END_OF_LIST);}

/* find in find-path in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_fcall f_5839(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5839,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_memq(t2,t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_i_cdr(t4);
t6=C_i_memq(((C_word*)t0)[3],t5);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_a_i_cons(&a,2,t2,t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5863,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:738: any */
t9=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,t8,t5);}}}

/* a5862 in find in find-path in k5829 in ##compiler#reorganize-recursive-bindings in k5823 in k5820 in k5817 in k3568 in k3219 in k3216 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5863,3,t0,t1,t2);}
/* optimizer.scm:738: find */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5839(t3,t1,t2,((C_word*)t0)[2]);}

/* register-simplifications in k3568 in k3219 in k3216 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_5812r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5812r(t0,t1,t2,t3);}}

static void C_ccall f_5812r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* optimizer.scm:506: ##sys#hash-table-set! */
t4=*((C_word*)lf[129]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[30]+1),t2,t3);}

/* ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5493(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5493,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5496,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5500,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5507,a[2]=t11,a[3]=t3,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:458: debugging */
t15=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t14,lf[28],lf[127]);}

/* k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5527,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* tweaks.scm:47: ##sys#get */
t4=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[125],lf[51]);}

/* k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5534,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:497: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5500(t3,t2,lf[125],lf[126]);}
else{
t2=((C_word*)t0)[2];
f_5510(2,t2,C_SCHEME_UNDEFINED);}}

/* k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5539,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_5539(t6,((C_word*)t0)[2],t2);}

/* loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5539(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5539,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5547,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5799,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g775776 */
t6=t3;
f_5547(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5797 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5539(t3,((C_word*)t0)[2],t2);}

/* g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5547(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5547,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_slot(t3,C_fix(3));
t5=C_i_cadr(t4);
t6=C_slot(t5,C_fix(2));
t7=C_i_car(t6);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5565,a[2]=t7,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t4,a[6]=((C_word*)t0)[4],a[7]=t1,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5783,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:467: test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5500(t10,t9,t7,lf[81]);}

/* k5781 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5565(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm:467: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5500(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[52]);}}

/* k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5565,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5568,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:468: get-list */
t3=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[80]);}

/* k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5574,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[8])){
if(C_truep(t1)){
t3=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t3))){
t4=C_i_length(((C_word*)t0)[4]);
if(C_truep(C_i_nequalp(C_fix(3),t4))){
t5=((C_word*)t0)[8];
t6=C_slot(t5,C_fix(1));
t7=t2;
f_5574(t7,C_eqp(lf[14],t6));}
else{
t5=t2;
f_5574(t5,C_SCHEME_FALSE);}}
else{
t4=t2;
f_5574(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5574(t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5574(t3,C_SCHEME_FALSE);}}

/* k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5574(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5574,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=((C_word*)t0)[8];
t6=C_slot(t5,C_fix(3));
t7=C_i_car(t6);
t8=C_slot(t7,C_fix(3));
t9=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5594,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t8,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t7,a[10]=t4,tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_listp(t4))){
t10=C_i_cdr(t4);
t11=t9;
f_5594(t11,C_i_nullp(t10));}
else{
t10=t9;
f_5594(t10,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5600,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:479: get-list */
t4=*((C_word*)lf[124]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t2,lf[80]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5606,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(t1)){
t3=C_i_length(t1);
if(C_truep(C_i_nequalp(C_fix(1),t3))){
t4=C_slot(((C_word*)t0)[9],C_fix(1));
t5=t2;
f_5606(t5,C_eqp(lf[4],t4));}
else{
t4=t2;
f_5606(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_5606(t3,C_SCHEME_FALSE);}}

/* k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5606(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5606,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[9],C_fix(3));
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5615,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t5=C_slot(t3,C_fix(1));
t6=C_eqp(lf[2],t5);
if(C_truep(t6)){
t7=C_slot(t3,C_fix(2));
t8=C_i_car(t7);
t9=t4;
f_5615(t9,C_eqp(((C_word*)t0)[2],t8));}
else{
t7=t4;
f_5615(t7,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k5613 in k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5615(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5615,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:491: node-parameters-set! */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[123]);}
else{
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5620 in k5613 in k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:492: node-subexpressions-set! */
t4=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* k5623 in k5620 in k5613 in k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:495: reverse */
t6=*((C_word*)lf[121]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}

/* k5641 in k5623 in k5620 in k5613 in k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* optimizer.scm:493: node-subexpressions-set! */
t3=*((C_word*)lf[120]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5626 in k5623 in k5620 in k5613 in k5604 in k5598 in k5592 in k5572 in k5566 in k5563 in g775 in loop768 in k5532 in k5525 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:496: touch */
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,f_5496(((C_word*)((C_word*)t0)[2])[1]));}

/* k5508 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5510,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5513,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* optimizer.scm:499: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[119],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[3])[1]);}}

/* k5511 in k5508 in k5505 in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* test in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static void C_fcall f_5500(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5500,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm:456: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* touch in ##compiler#perform-pre-optimization! in k3568 in k3219 in k3216 */
static C_word C_fcall f_5496(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(C_SCHEME_TRUE);}

/* ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[72],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3573,4,t0,t1,t2,t3);}
t4=C_fix(0);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_fix(0);
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t31=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3582,tmp=(C_word)a,a+=2,tmp));
t32=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3612,a[2]=t15,tmp=(C_word)a,a+=3,tmp));
t33=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3616,a[2]=t3,a[3]=t23,a[4]=t21,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t34=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3747,a[2]=t27,a[3]=t19,a[4]=t25,a[5]=t21,a[6]=t7,a[7]=t23,a[8]=t15,tmp=(C_word)a,a+=9,tmp));
t35=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4028,a[2]=t11,a[3]=t3,a[4]=t29,a[5]=t25,a[6]=t5,a[7]=t9,a[8]=t17,a[9]=t21,tmp=(C_word)a,a+=10,tmp));
t36=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5345,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t37=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5375,a[2]=t25,a[3]=t13,a[4]=t9,a[5]=t5,a[6]=t7,a[7]=t15,a[8]=t2,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:424: perform-pre-optimization! */
t38=*((C_word*)lf[118]+1);
((C_proc4)(void*)(*((C_word*)t38+1)))(4,t38,t37,t2,t3);}

/* k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5375,2,t0,t1);}
if(C_truep(t1)){
/* optimizer.scm:425: values */
C_values(4,0,((C_word*)t0)[9],((C_word*)t0)[8],C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5381,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:427: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],lf[117]);}}

/* k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5381,2,t0,t1);}
t2=C_set_block_item(lf[31] /* simplified-ops */,0,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5385,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:429: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3747(t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5388,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* optimizer.scm:430: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[116],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5388(2,t3,C_SCHEME_UNDEFINED);}}

/* k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5424,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[31]+1)))){
/* optimizer.scm:431: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[24],lf[115]);}
else{
t4=t3;
f_5424(2,t4,C_SCHEME_FALSE);}}

/* k5422 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5424,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5429,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5429(t5,((C_word*)t0)[2],*((C_word*)lf[31]+1));}
else{
t2=((C_word*)t0)[2];
f_5391(2,t2,C_SCHEME_UNDEFINED);}}

/* loop726 in k5422 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_5429(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5429,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5468,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5441,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_car(t4);
/* optimizer.scm:434: print* */
t7=*((C_word*)lf[114]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,C_make_character(9),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5439 in loop726 in k5422 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_greaterp(t2,C_fix(1)))){
t3=C_i_cdr(((C_word*)t0)[3]);
/* optimizer.scm:436: print */
t4=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],C_make_character(9),t3);}
else{
/* optimizer.scm:437: newline */
t3=*((C_word*)lf[113]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k5466 in loop726 in k5422 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5429(t3,((C_word*)t0)[2],t2);}

/* k5389 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5394,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* optimizer.scm:439: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[111],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5394(2,t3,C_SCHEME_UNDEFINED);}}

/* k5392 in k5389 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* optimizer.scm:440: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[110],((C_word*)((C_word*)t0)[2])[1]);}
else{
t3=t2;
f_5397(2,t3,C_SCHEME_UNDEFINED);}}

/* k5395 in k5392 in k5389 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5400,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
/* optimizer.scm:441: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[109],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* optimizer.scm:442: values */
C_values(4,0,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k5398 in k5395 in k5392 in k5389 in k5386 in k5383 in k5379 in k5373 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:442: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* walk-generic in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_5345(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5345,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5349,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5365,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* map */
t9=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,t5);}

/* a5364 in walk-generic in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5365,3,t0,t1,t2);}
/* g715716 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3747(t3,t1,t2,((C_word*)t0)[2]);}

/* k5347 in walk-generic in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5355,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:420: every */
t3=*((C_word*)lf[48]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[27]+1),((C_word*)t0)[2],t1);}

/* k5353 in k5347 in walk-generic in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=t2;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[10],t3,t4,t5));}}

/* walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4028(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4028,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t13,tmp=(C_word)a,a+=7,tmp));
t15=((C_word*)t13)[1];
f_4068(t15,t1,t11);}
else{
t11=C_eqp(t9,lf[5]);
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4149,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t7,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t5,a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:227: test */
t14=((C_word*)((C_word*)t0)[8])[1];
f_3576(t14,t13,t12,lf[60]);}
else{
t12=C_eqp(t9,lf[14]);
if(C_truep(t12)){
t13=C_i_caddr(t7);
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4215,a[2]=t9,a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t13,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t14,a[10]=t5,a[11]=t7,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* optimizer.scm:237: test */
t16=((C_word*)((C_word*)t0)[8])[1];
f_3576(t16,t15,t14,lf[69]);}
else{
t13=C_eqp(t9,lf[8]);
if(C_truep(t13)){
t14=C_i_car(t5);
t15=C_slot(t14,C_fix(1));
t16=C_eqp(t15,lf[2]);
if(C_truep(t16)){
t17=C_slot(t14,C_fix(2));
t18=C_i_car(t17);
t19=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4410,a[2]=((C_word*)t0)[2],a[3]=t14,a[4]=((C_word*)t0)[8],a[5]=t7,a[6]=t9,a[7]=t2,a[8]=((C_word*)t0)[4],a[9]=t18,a[10]=((C_word*)t0)[3],a[11]=t3,a[12]=t1,a[13]=((C_word*)t0)[5],a[14]=((C_word*)t0)[9],a[15]=t5,tmp=(C_word)a,a+=16,tmp);
t20=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5167,a[2]=t18,a[3]=((C_word*)t0)[8],a[4]=t19,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:275: test */
t21=((C_word*)((C_word*)t0)[8])[1];
f_3576(t21,t20,t18,lf[81]);}
else{
t17=C_eqp(t15,lf[14]);
if(C_truep(t17)){
if(C_truep(C_i_car(t7))){
/* optimizer.scm:397: walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_5345(t18,t1,t2,t9,t7,t5,t3);}
else{
t18=C_i_cdr(t7);
t19=C_a_i_cons(&a,2,C_SCHEME_TRUE,t18);
t20=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5207,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5209,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t22=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t22+1)))(4,t22,t20,t21,t5);}}
else{
/* optimizer.scm:399: walk-generic */
t18=((C_word*)((C_word*)t0)[4])[1];
f_5345(t18,t1,t2,t9,t7,t5,t3);}}}
else{
t14=C_eqp(t9,lf[9]);
if(C_truep(t14)){
t15=C_i_car(t7);
t16=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5235,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=t7,a[8]=t15,a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:403: test */
t17=((C_word*)((C_word*)t0)[8])[1];
f_3576(t17,t16,t15,lf[59]);}
else{
/* optimizer.scm:416: walk-generic */
t15=((C_word*)((C_word*)t0)[4])[1];
f_5345(t15,t1,t2,t9,t7,t5,t3);}}}}}}

/* k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=t2;
f_5238(2,t3,t1);}
else{
/* optimizer.scm:403: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3576(t3,t2,((C_word*)t0)[8],lf[56]);}}

/* k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5238,2,t0,t1);}
if(C_truep(t1)){
t2=f_3612(((C_word*)((C_word*)t0)[10])[1]);
t3=((C_word*)t0)[9];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5255,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5337,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:406: test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3576(t4,t3,((C_word*)t0)[8],lf[108]);}}

/* k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5337,2,t0,t1);}
t2=C_i_not(t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_5295(t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5333,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:407: variable-visible? */
t5=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}}

/* k5331 in k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5295(t2,C_i_not(t1));}

/* k5293 in k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_5295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5295,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:408: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[106]);}
else{
t2=((C_word*)t0)[6];
f_5255(t2,C_SCHEME_FALSE);}}

/* k5324 in k5293 in k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_5255(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5322,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:409: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[80]);}}

/* k5320 in k5324 in k5293 in k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5322,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_5255(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5314,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:410: expression-has-side-effects? */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}}

/* k5312 in k5320 in k5324 in k5293 in k5335 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5255(t2,C_i_not(t1));}

/* k5253 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_5255(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5255,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3612(((C_word*)((C_word*)t0)[8])[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5261,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:412: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[24],lf[105],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* optimizer.scm:414: walk */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3747(t4,t2,t3,((C_word*)t0)[2]);}}

/* k5283 in k5253 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5285,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[9],((C_word*)t0)[2],t2));}

/* k5259 in k5253 in k5236 in k5233 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5261,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST));}

/* a5208 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5209,3,t0,t1,t2);}
/* g659660 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3747(t3,t1,t2,((C_word*)t0)[2]);}

/* k5205 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5207,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k5165 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5167,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4410(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:276: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[52]);}}

/* k5155 in k5165 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_4410(2,t3,t2);}
else{
/* optimizer.scm:277: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3576(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[104]);}}

/* k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4410,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[15]);
t3=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4419,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[15],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=t2,a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],a[17]=t1,tmp=(C_word)a,a+=18,tmp);
/* optimizer.scm:279: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3576(t4,t3,((C_word*)t0)[9],lf[59]);}

/* k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4419,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=t4,a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:282: check-signature */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,((C_word*)t0)[10],((C_word*)t0)[12],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[16],a[6]=((C_word*)t0)[17],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[5],a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[9],a[17]=((C_word*)t0)[12],tmp=(C_word)a,a+=18,tmp);
/* tweaks.scm:53: ##sys#get */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[10],lf[103]);}}

/* k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4480,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[17],tmp=(C_word)a,a+=12,tmp);
/* g430431 */
t3=t2;
f_4480(t3,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[15],a[10]=((C_word*)t0)[16],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[17],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[4],a[16]=((C_word*)t0)[5],a[17]=((C_word*)t0)[6],tmp=(C_word)a,a+=18,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=((C_word*)t0)[6];
t4=C_slot(t3,C_fix(1));
t5=t2;
f_4706(t5,C_eqp(lf[14],t4));}
else{
t3=t2;
f_4706(t3,C_SCHEME_FALSE);}}}

/* k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4706(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4706,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[17];
t3=C_slot(t2,C_fix(2));
t4=C_i_caddr(t3);
t5=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_4722,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=t4,a[14]=((C_word*)t0)[17],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=t3,tmp=(C_word)a,a+=19,tmp);
/* optimizer.scm:317: decompose-lambda-list */
t6=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,((C_word*)t0)[2],t4,t5);}
else{
/* optimizer.scm:394: walk-generic */
t2=((C_word*)((C_word*)t0)[10])[1];
f_5345(t2,((C_word*)t0)[2],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[14]);}}

/* a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4722,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[18]);
t6=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=t3,a[12]=t5,a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[10],a[15]=((C_word*)t0)[11],a[16]=((C_word*)t0)[12],a[17]=((C_word*)t0)[13],a[18]=((C_word*)t0)[14],a[19]=((C_word*)t0)[15],a[20]=t1,a[21]=((C_word*)t0)[16],a[22]=((C_word*)t0)[17],tmp=(C_word)a,a+=23,tmp);
/* tweaks.scm:53: ##sys#get */
t7=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,((C_word*)t0)[10],lf[102]);}

/* k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=C_i_structurep(t1,lf[10]);
t3=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_4740,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=t2,a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[96]+1))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5087,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[14],a[5]=((C_word*)t0)[13],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:323: test */
t5=((C_word*)((C_word*)t0)[4])[1];
f_3576(t5,t4,((C_word*)t0)[14],lf[101]);}
else{
t4=t3;
f_4740(t4,C_SCHEME_FALSE);}}

/* k5085 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5127,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:324: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[72]);}
else{
t2=((C_word*)t0)[7];
f_4740(t2,C_SCHEME_FALSE);}}

/* k5125 in k5085 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5127,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4740(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5101,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tweaks.scm:53: ##sys#get */
t3=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[100]);}}

/* k5099 in k5125 in k5085 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(t1,lf[97]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
f_4740(t3,C_SCHEME_TRUE);}
else{
t3=C_eqp(t1,lf[98]);
if(C_truep(t3)){
t4=((C_word*)t0)[4];
f_4740(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[3])){
t4=((C_word*)t0)[4];
f_4740(t4,((C_word*)t0)[3]);}
else{
t4=C_i_cadddr(((C_word*)t0)[2]);
t5=((C_word*)t0)[4];
f_4740(t5,C_i_lessp(t4,*((C_word*)lf[99]+1)));}}}}

/* k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4740(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4740,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4743,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[16],a[4]=((C_word*)t0)[17],a[5]=((C_word*)t0)[18],a[6]=((C_word*)t0)[19],a[7]=((C_word*)t0)[20],a[8]=((C_word*)t0)[21],a[9]=((C_word*)t0)[22],a[10]=((C_word*)t0)[23],tmp=(C_word)a,a+=11,tmp);
t3=(C_truep(((C_word*)t0)[14])?lf[84]:lf[85]);
t4=C_i_cadddr(((C_word*)t0)[13]);
/* optimizer.scm:330: debugging */
t5=*((C_word*)lf[23]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,t2,lf[86],t3,((C_word*)t0)[15],((C_word*)t0)[12],t4);}
else{
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_4795,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[18],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[15],a[8]=((C_word*)t0)[16],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[22],a[11]=((C_word*)t0)[23],a[12]=((C_word*)t0)[20],a[13]=((C_word*)t0)[6],a[14]=((C_word*)t0)[7],a[15]=((C_word*)t0)[8],a[16]=((C_word*)t0)[9],a[17]=((C_word*)t0)[21],a[18]=((C_word*)t0)[10],a[19]=((C_word*)t0)[11],a[20]=((C_word*)t0)[17],tmp=(C_word)a,a+=21,tmp);
/* optimizer.scm:343: test */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3576(t3,t2,((C_word*)t0)[12],lf[69]);}}

/* k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4795,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_length(((C_word*)t0)[20]);
if(C_truep(C_i_lessp(t2,((C_word*)t0)[19]))){
/* optimizer.scm:345: walk-generic */
t3=((C_word*)((C_word*)t0)[18])[1];
f_5345(t3,((C_word*)t0)[17],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4809,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t4,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp));
t6=((C_word*)t4)[1];
f_4809(t6,((C_word*)t0)[17],((C_word*)t0)[5],((C_word*)t0)[19],((C_word*)t0)[20],C_SCHEME_END_OF_LIST);}}
else{
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4973,a[2]=((C_word*)t0)[16],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[13],a[10]=((C_word*)t0)[14],a[11]=((C_word*)t0)[15],a[12]=((C_word*)t0)[17],a[13]=((C_word*)t0)[18],a[14]=((C_word*)t0)[20],tmp=(C_word)a,a+=15,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5074,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[16],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:369: test */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3576(t4,t3,((C_word*)t0)[2],lf[65]);}}

/* k5072 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_memq(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=((C_word*)t0)[2];
f_4973(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_4973(t2,C_SCHEME_FALSE);}}

/* k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4973(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4973,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],a[11]=((C_word*)t0)[13],a[12]=((C_word*)t0)[14],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm:371: llist-length */
t3=*((C_word*)lf[95]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
/* optimizer.scm:393: walk-generic */
t2=((C_word*)((C_word*)t0)[13])[1];
f_5345(t2,((C_word*)t0)[12],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8]);}}

/* k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[12]);
if(C_truep(C_i_lessp(t2,t1))){
/* optimizer.scm:373: walk-generic */
t3=((C_word*)((C_word*)t0)[11])[1];
f_5345(t3,((C_word*)t0)[10],t1,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:375: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,lf[24],lf[94],((C_word*)t0)[2],t1);}}

/* k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4998 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4999,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5016,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5030,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5038,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* optimizer.scm:386: qnode */
t8=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,C_SCHEME_END_OF_LIST);}
else{
t8=C_i_length(t3);
t9=C_a_i_times(&a,2,C_fix(3),t8);
t10=C_a_i_list(&a,2,lf[92],t9);
t11=t3;
t12=C_a_i_record(&a,4,lf[10],lf[93],t10,t11);
t13=C_a_i_list(&a,1,t12);
/* optimizer.scm:382: append */
t14=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t6,t2,t13);}}

/* k5036 in a4998 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5038,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* optimizer.scm:382: append */
t3=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5028 in a4998 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a5017 in a4998 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5018,3,t0,t1,t2);}
/* g628629 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3747(t3,t1,t2,((C_word*)t0)[2]);}

/* k5014 in a4998 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_5016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5016,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a4992 in k4986 in k4974 in k4971 in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
/* optimizer.scm:376: split-at */
t2=*((C_word*)lf[91]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4809(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4809,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_nullp(t2);
t7=(C_truep(t6)?t6:C_i_zerop(t3));
if(C_truep(t7)){
t8=f_3612(((C_word*)((C_word*)t0)[10])[1]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[9],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4848,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:352: append-reverse */
t12=*((C_word*)lf[87]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t5,t4);}
else{
t8=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4854,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t5,a[7]=((C_word*)t0)[5],a[8]=t4,a[9]=t3,a[10]=t2,a[11]=t1,a[12]=((C_word*)t0)[10],tmp=(C_word)a,a+=13,tmp);
t9=C_i_car(t2);
/* optimizer.scm:353: test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_3576(t10,t8,t9,lf[61]);}}

/* k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4854,2,t0,t1);}
if(C_truep(t1)){
t2=f_3612(((C_word*)((C_word*)t0)[12])[1]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t4=C_i_car(((C_word*)t0)[10]);
/* optimizer.scm:355: debugging */
t5=*((C_word*)lf[23]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t3,lf[24],lf[90],t4,((C_word*)t0)[2]);}
else{
t2=C_i_cdr(((C_word*)t0)[10]);
t3=C_a_i_minus(&a,2,((C_word*)t0)[9],C_fix(1));
t4=C_i_cdr(((C_word*)t0)[8]);
t5=C_i_car(((C_word*)t0)[8]);
t6=C_a_i_cons(&a,2,t5,((C_word*)t0)[6]);
/* optimizer.scm:365: loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_4809(t7,((C_word*)t0)[11],t2,t3,t4,t6);}}

/* k4858 in k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[7]);
/* optimizer.scm:358: expression-has-side-effects? */
t4=*((C_word*)lf[78]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k4864 in k4858 in k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4866,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:361: gensym */
t3=*((C_word*)lf[88]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[89]);}
else{
t2=C_i_cdr(((C_word*)t0)[8]);
t3=C_a_i_minus(&a,2,((C_word*)t0)[7],C_fix(1));
t4=C_i_cdr(((C_word*)t0)[6]);
/* optimizer.scm:364: loop */
t5=((C_word*)((C_word*)t0)[5])[1];
f_4809(t5,((C_word*)t0)[9],t2,t3,t4,((C_word*)t0)[4]);}}

/* k4908 in k4864 in k4858 in k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4910,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4886,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t2,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=C_i_car(((C_word*)t0)[6]);
/* optimizer.scm:362: walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3747(t5,t3,t4,((C_word*)t0)[2]);}

/* k4884 in k4908 in k4864 in k4858 in k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4890,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[6]);
t4=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t5=C_i_cdr(((C_word*)t0)[4]);
/* optimizer.scm:363: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_4809(t6,t2,t3,t4,t5,((C_word*)t0)[2]);}

/* k4888 in k4884 in k4908 in k4864 in k4858 in k4852 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4890,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t2));}

/* k4846 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4848,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
/* map */
t3=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4835 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4836,3,t0,t1,t2);}
/* g584585 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3747(t3,t1,t2,((C_word*)t0)[2]);}

/* k4832 in loop in k4793 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4834,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[8],((C_word*)t0)[2],t1));}

/* k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4777,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[7]);}

/* a4776 in k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4777(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4777,3,t0,t1,t2);}
t3=*((C_word*)lf[71]+1);
/* g541542 */
t4=t3;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[2],t2,lf[72],C_SCHEME_TRUE);}

/* k4744 in k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:337: check-signature */
t3=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4],((C_word*)t0)[5]);}

/* k4747 in k4744 in k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4752,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:338: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[83],((C_word*)t0)[2]);}

/* k4750 in k4747 in k4744 in k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4752,2,t0,t1);}
t2=f_3612(((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[5];
t5=C_slot(t4,C_fix(3));
t6=C_i_car(t5);
/* optimizer.scm:341: inline-lambda-bindings */
t7=*((C_word*)lf[70]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t3,((C_word*)t0)[4],((C_word*)t0)[3],t6,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* k4760 in k4750 in k4747 in k4744 in k4741 in k4738 in k5134 in a4721 in k4704 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:340: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3747(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4480(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4480,NULL,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4487,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=C_eqp(C_SCHEME_TRUE,t2);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4502,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=t4,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_4502(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4688,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tweaks.scm:53: ##sys#get */
t8=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,((C_word*)t0)[4],lf[51]);}}
else{
t5=t4;
f_4487(t5,C_SCHEME_FALSE);}}

/* k4686 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,lf[82]);
t3=((C_word*)t0)[3];
f_4502(t3,(C_truep(t2)?t2:C_eqp(t1,((C_word*)t0)[2])));}

/* k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4502(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4502,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[8],C_fix(1));
t3=C_eqp(lf[2],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[8],C_fix(2));
t5=C_i_car(t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4662,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:297: test */
t8=((C_word*)((C_word*)t0)[2])[1];
f_3576(t8,t7,t5,lf[81]);}
else{
t6=((C_word*)t0)[7];
f_4487(t6,C_SCHEME_FALSE);}}
else{
t4=((C_word*)t0)[7];
f_4487(t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[7];
f_4487(t2,C_SCHEME_FALSE);}}

/* k4660 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4517(2,t2,C_SCHEME_FALSE);}
else{
/* optimizer.scm:297: test */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3576(t2,((C_word*)t0)[4],((C_word*)t0)[2],lf[52]);}}

/* k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4517,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_slot(t2,C_fix(1));
t4=C_eqp(lf[14],t3);
if(C_truep(t4)){
t5=t1;
t6=C_slot(t5,C_fix(2));
t7=C_i_caddr(t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4538,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t9=C_i_car(t7);
/* optimizer.scm:300: test */
t10=((C_word*)((C_word*)t0)[2])[1];
f_3576(t10,t8,t9,lf[61]);}
else{
t8=((C_word*)t0)[8];
f_4487(t8,C_SCHEME_FALSE);}}
else{
t5=((C_word*)t0)[8];
f_4487(t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[8];
f_4487(t2,C_SCHEME_FALSE);}}

/* k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4541,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t3=t2;
f_4541(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:301: test */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3576(t5,t3,t4,lf[80]);}}

/* k4624 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4541(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* optimizer.scm:302: test */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3576(t4,t2,t3,lf[79]);}}

/* k4616 in k4624 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4541(t2,C_i_not(t1));}

/* k4539 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4541,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4595,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4597,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_i_cdr(((C_word*)t0)[2]);
/* optimizer.scm:303: any */
t5=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=((C_word*)t0)[7];
f_4487(t2,C_SCHEME_FALSE);}}

/* a4596 in k4539 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4597(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4597,3,t0,t1,t2);}
t3=*((C_word*)lf[78]+1);
/* g473474 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k4593 in k4539 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4595,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4487(t2,C_SCHEME_FALSE);}
else{
t2=C_i_cdr(((C_word*)t0)[4]);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4578,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:308: source-info->string */
t7=*((C_word*)lf[77]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t4);}}

/* k4576 in k4593 in k4539 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* optimizer.scm:305: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[24],lf[76],t2);}
else{
/* optimizer.scm:305: debugging */
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[24],lf[76],((C_word*)t0)[2]);}}

/* k4551 in k4593 in k4539 in k4536 in k4515 in k4500 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
t3=C_a_i_list(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
f_4487(t4,C_a_i_record(&a,4,lf[10],lf[8],lf[75],t3));}

/* k4485 in g430 in k4474 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4487(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* optimizer.scm:312: walk-generic */
t2=((C_word*)((C_word*)t0)[7])[1];
f_5345(t2,((C_word*)t0)[8],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4431 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:283: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[73],((C_word*)t0)[2]);}

/* k4434 in k4431 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=f_3612(((C_word*)((C_word*)t0)[9])[1]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t5=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[6]);}

/* a4463 in k4434 in k4431 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4464,3,t0,t1,t2);}
t3=*((C_word*)lf[71]+1);
/* g416417 */
t4=t3;
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t1,((C_word*)t0)[2],t2,lf[72],C_SCHEME_TRUE);}

/* k4440 in k4434 in k4431 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4449,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[5];
t4=C_slot(t3,C_fix(3));
t5=C_i_car(t4);
/* optimizer.scm:287: inline-lambda-bindings */
t6=*((C_word*)lf[70]+1);
((C_proc7)(void*)(*((C_word*)t6+1)))(7,t6,t2,((C_word*)t0)[4],((C_word*)t0)[3],t5,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* k4447 in k4440 in k4434 in k4431 in k4417 in k4408 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:286: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3747(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4215,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:238: decompose-lambda-list */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* optimizer.scm:253: test */
t3=((C_word*)((C_word*)t0)[13])[1];
f_3576(t3,t2,((C_word*)t0)[9],lf[65]);}}

/* k4312 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4314,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4319,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:254: decompose-lambda-list */
t3=*((C_word*)lf[67]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[6],((C_word*)t0)[5],t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],((C_word*)t0)[8]);
/* optimizer.scm:266: walk-generic */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5345(t3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[11],((C_word*)t0)[10],t2);}}

/* a4318 in k4312 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4319,5,t0,t1,t2,t3,t4);}
t5=f_3612(((C_word*)((C_word*)t0)[7])[1]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4326,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:258: debugging */
t7=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,lf[24],lf[68],t4);}

/* k4324 in a4318 in k4312 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4326,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[9]);
t3=C_i_cadr(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4366,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t5=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* optimizer.scm:263: build-lambda-list */
t6=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[2],t5,C_SCHEME_FALSE);}

/* k4364 in k4324 in a4318 in k4312 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4366,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[9]);
t3=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4346,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm:265: walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3747(t7,t4,t5,t6);}

/* k4344 in k4364 in k4324 in a4318 in k4312 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4346,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[14],((C_word*)t0)[2],t2));}

/* a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4220,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4226,a[2]=t2,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[8],a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4238,4,t0,t1,t2,t3);}
t4=f_3612(((C_word*)((C_word*)t0)[10])[1]);
t5=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=t1,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* optimizer.scm:243: debugging */
t6=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,lf[24],lf[66],t2);}

/* k4243 in a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4245,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[11]);
t3=C_i_cadr(((C_word*)t0)[11]);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t3,a[8]=t2,a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* optimizer.scm:247: test */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3576(t6,t5,((C_word*)t0)[8],lf[65]);}
else{
t6=t5;
f_4292(2,t6,C_SCHEME_FALSE);}}

/* k4290 in k4243 in a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:248: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[64],((C_word*)t0)[2]);}
else{
/* optimizer.scm:250: build-lambda-list */
t2=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k4293 in k4290 in k4243 in a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* optimizer.scm:249: build-lambda-list */
t3=*((C_word*)lf[63]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2,C_SCHEME_FALSE);}

/* k4283 in k4243 in a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[9]);
t3=C_a_i_list(&a,4,((C_word*)t0)[8],((C_word*)t0)[7],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4265,a[2]=t3,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(((C_word*)t0)[5]);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* optimizer.scm:252: walk */
t7=((C_word*)((C_word*)t0)[2])[1];
f_3747(t7,t4,t5,t6);}

/* k4263 in k4283 in k4243 in a4237 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4265,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[14],((C_word*)t0)[2],t2));}

/* a4225 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:241: partition */
t3=*((C_word*)lf[62]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a4231 in a4225 in a4219 in k4213 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4232,3,t0,t1,t2);}
/* optimizer.scm:241: test */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3576(t3,t1,t2,lf[61]);}

/* k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4152,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_4152(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:228: test */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3576(t4,t3,((C_word*)t0)[2],lf[59]);}}

/* k4188 in k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4190,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:228: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[58]);}
else{
t2=((C_word*)t0)[4];
f_4152(t2,C_SCHEME_FALSE);}}

/* k4195 in k4188 in k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4152(t2,C_i_not(t1));}

/* k4150 in k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4152,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=f_3612(((C_word*)((C_word*)t0)[8])[1]);
t3=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[7])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=C_i_cadr(((C_word*)t0)[6]);
/* optimizer.scm:231: walk */
t6=((C_word*)((C_word*)t0)[5])[1];
f_3747(t6,((C_word*)t0)[4],t5,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[57]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[6]);}}

/* a4179 in k4150 in k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4180,3,t0,t1,t2);}
/* g341342 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3747(t3,t1,t2,((C_word*)t0)[2]);}

/* k4176 in k4150 in k4147 in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[10],lf[5],((C_word*)t0)[2],t1));}

/* replace in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_4068(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4068,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4072,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:213: test */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3576(t4,t3,t2,lf[56]);}

/* k4070 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4072,2,t0,t1);}
if(C_truep(t1)){
/* replace294 */
t2=((C_word*)((C_word*)t0)[8])[1];
f_4068(t2,((C_word*)t0)[7],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* optimizer.scm:214: test */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3576(t3,t2,((C_word*)t0)[4],lf[55]);}}

/* k4082 in k4070 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4084,2,t0,t1);}
if(C_truep(t1)){
t2=f_3612(((C_word*)((C_word*)t0)[7])[1]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:216: debugging */
t4=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[24],lf[53],((C_word*)t0)[4]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
/* optimizer.scm:223: varnode */
t4=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[6],((C_word*)t0)[4]);}
else{
t4=f_3612(((C_word*)((C_word*)t0)[7])[1]);
t5=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
/* optimizer.scm:223: varnode */
t7=*((C_word*)lf[54]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,((C_word*)t0)[6],((C_word*)t0)[4]);}}}

/* k4088 in k4082 in k4070 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:217: test */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3576(t3,t2,((C_word*)t0)[2],lf[52]);}

/* k4108 in k4088 in k4082 in k4070 in replace in walk1 in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(t1,C_fix(2));
t3=C_i_car(t2);
/* optimizer.scm:217: qnode */
t4=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[2],t3);}

/* walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3747(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3747,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_memq(t2,*((C_word*)lf[40]+1)))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=((C_word*)((C_word*)t0)[8])[1];
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* optimizer.scm:166: walk1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_4028(t6,t5,t2,t3);}}

/* k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3761,2,t0,t1);}
t2=t1;
t3=C_slot(t2,C_fix(3));
t4=t1;
t5=C_slot(t4,C_fix(1));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3780,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(t5,lf[4]);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[34],t9);
if(C_truep(t10)){
t11=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[8])[1],C_fix(1));
t12=C_mutate(((C_word *)((C_word*)t0)[8])+1,t11);
t13=f_3612(((C_word*)((C_word*)t0)[7])[1]);
t14=C_i_car(t3);
t15=C_slot(t14,C_fix(2));
t16=C_i_car(t15);
t17=(C_truep(t16)?C_i_cadr(t3):C_i_caddr(t3));
/* optimizer.scm:174: walk */
t18=((C_word*)((C_word*)t0)[6])[1];
f_3747(t18,t6,t17,((C_word*)t0)[5]);}
else{
t11=t1;
/* optimizer.scm:164: simplify */
t12=((C_word*)((C_word*)t0)[10])[1];
f_3616(t12,((C_word*)t0)[9],t11);}}
else{
t8=C_eqp(t5,lf[8]);
if(C_truep(t8)){
t9=C_i_car(t3);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[2],t10);
if(C_truep(t11)){
t12=C_i_car(t3);
t13=C_slot(t12,C_fix(2));
t14=C_i_car(t13);
t15=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t1,a[9]=t6,a[10]=t14,tmp=(C_word)a,a+=11,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3987,a[2]=t14,a[3]=((C_word*)t0)[2],a[4]=t15,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* tweaks.scm:47: ##sys#get */
t17=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t16,t14,lf[51]);}
else{
t12=t1;
/* optimizer.scm:164: simplify */
t13=((C_word*)((C_word*)t0)[10])[1];
f_3616(t13,((C_word*)t0)[9],t12);}}
else{
t9=t1;
/* optimizer.scm:164: simplify */
t10=((C_word*)((C_word*)t0)[10])[1];
f_3616(t10,((C_word*)t0)[9],t9);}}}

/* k3985 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3987,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3993,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:184: foldable? */
t3=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_3841(2,t2,C_SCHEME_FALSE);}}

/* k3991 in k3985 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[4]);
/* optimizer.scm:185: every */
t3=*((C_word*)lf[48]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=((C_word*)t0)[3];
f_3841(2,t2,C_SCHEME_FALSE);}}

/* k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3841,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3927,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t7=C_i_cddr(((C_word*)t0)[4]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3933,a[2]=t3,a[3]=t9,a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_3933(t11,t6,t7);}
else{
t2=((C_word*)t0)[8];
/* optimizer.scm:164: simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3616(t3,((C_word*)t0)[2],t2);}}

/* loop233 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
loop:
a=C_alloc(9);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3933,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[34],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t9=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop233246 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}
else{
t9=C_mutate(((C_word *)((C_word*)t0)[2])+1,t8);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_slot(t2,C_fix(1));
/* loop233246 */
t17=t1;
t18=t11;
t1=t17;
t2=t18;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3927,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[8],t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3852,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[47]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3852,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3858,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3875,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[46]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3912 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3913(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3913r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3913r(t0,t1,t2);}}

static void C_ccall f_3913r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3919,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k258262 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3918 in a3912 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3919,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3880 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:193: eval */
t3=*((C_word*)lf[45]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3883 in a3880 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3888,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:194: debugging */
t3=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[24],lf[44],((C_word*)t0)[2]);}

/* k3886 in k3883 in a3880 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3888,2,t0,t1);}
t2=f_3612(((C_word*)((C_word*)t0)[5])[1]);
t3=C_i_cadr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:199: qnode */
t5=*((C_word*)lf[43]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k3909 in k3886 in k3883 in a3880 in a3874 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[10],lf[8],lf[42],t2));}

/* a3857 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3864,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* k258262 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a3863 in a3857 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_3868(t3,C_SCHEME_UNDEFINED);}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t2;
f_3868(t4,t3);}}

/* k3866 in a3863 in a3857 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3868(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3868,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:191: lset-adjoin */
t3=*((C_word*)lf[41]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[27]+1),*((C_word*)lf[40]+1),((C_word*)t0)[2]);}

/* k3870 in k3866 in a3863 in a3857 in a3851 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[40]+1 /* (set! ##compiler#broken-constant-nodes ...) */,t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* k3845 in k3925 in k3839 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g260261 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k3778 in k3759 in walk in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:164: simplify */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3616(t2,((C_word*)t0)[2],t1);}

/* simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3616,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3620,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=t2;
t5=C_slot(t4,C_fix(1));
/* optimizer.scm:145: ##sys#hash-table-ref */
t6=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,*((C_word*)lf[30]+1),t5);}

/* k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3620,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3623,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:146: any */
t4=*((C_word*)lf[38]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}
else{
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3631,3,t0,t1,t2);}
t3=C_i_cadr(t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3641,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t5=C_i_car(t2);
/* optimizer.scm:148: match-node */
t6=*((C_word*)lf[37]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[2],t5,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3641,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3647,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3688,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3690,a[2]=t5,a[3]=t10,a[4]=t7,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_3690(t12,t8,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop171 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3690(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3690,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3717(t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop171184 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop171184 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g187 in loop171 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static C_word C_fcall f_3717(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_assq(t1,((C_word*)t0)[2]);
return(C_i_cdr(t2));}

/* k3686 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3645 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3647,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3653,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:151: caar */
t3=*((C_word*)lf[36]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k3651 in k3645 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=C_i_assq(t1,((C_word*)((C_word*)t0)[6])[1]);
if(C_truep(t2)){
t3=C_i_cdr(t2);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
t5=C_i_set_cdr(t2,t4);
t6=f_3612(((C_word*)((C_word*)t0)[5])[1]);
/* optimizer.scm:157: simplify */
t7=((C_word*)((C_word*)t0)[4])[1];
f_3616(t7,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* optimizer.scm:155: alist-cons */
t4=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,t1,C_fix(1),((C_word*)((C_word*)t0)[6])[1]);}}

/* k3678 in k3651 in k3645 in k3639 in a3630 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=f_3612(((C_word*)((C_word*)t0)[5])[1]);
/* optimizer.scm:157: simplify */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3616(t4,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3621 in k3618 in simplify in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* touch in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static C_word C_fcall f_3612(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
return(t1);}

/* constant-node? in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_ccall f_3582(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3582,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[34],t3));}

/* test in ##compiler#perform-high-level-optimizations in k3568 in k3219 in k3216 */
static void C_fcall f_3576(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3576,NULL,4,t0,t1,t2,t3);}
/* optimizer.scm:139: get */
t4=*((C_word*)lf[33]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],t2,t3);}

/* ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[49],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3223,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3226,a[2]=t6,a[3]=t8,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t22=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3249,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t23=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3256,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t24=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3261,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t25=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3295,a[2]=t12,a[3]=t14,a[4]=t20,a[5]=t18,a[6]=t16,a[7]=t4,a[8]=t6,a[9]=t10,tmp=(C_word)a,a+=10,tmp));
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3514,a[2]=t2,a[3]=t20,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* optimizer.scm:105: debugging */
t27=*((C_word*)lf[23]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t26,lf[28],lf[29]);}

/* k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3517,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:106: scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3295(t3,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3515 in k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3517,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3566,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:108: delete-duplicates */
t4=*((C_word*)lf[26]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)((C_word*)t0)[2])[1],*((C_word*)lf[27]+1));}
else{
t3=t2;
f_3520(2,t3,C_SCHEME_UNDEFINED);}}

/* k3564 in k3515 in k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:108: debugging */
t2=*((C_word*)lf[23]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[24],lf[25],t1);}

/* k3518 in k3515 in k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3525,tmp=(C_word)a,a+=2,tmp);
/* for-each */
t3=*((C_word*)lf[22]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)((C_word*)t0)[2])[1]);}

/* a3524 in k3518 in k3515 in k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3525,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3531,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:50: ##sys#put! */
t5=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,lf[19],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* tweaks.scm:50: ##sys#put! */
t7=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[19],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[20]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[21],t3);}}}

/* k3529 in a3524 in k3518 in k3515 in k3512 in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[18]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[19],t1);}

/* scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3295(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3295,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(2));
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[2]);
if(C_truep(t10)){
t11=C_i_car(t5);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3332,a[2]=t11,a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3349,a[2]=t12,a[3]=((C_word*)t0)[8],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t11,t3))){
t14=t13;
f_3349(t14,C_SCHEME_FALSE);}
else{
t14=C_i_memq(t11,((C_word*)((C_word*)t0)[7])[1]);
t15=t13;
f_3349(t15,C_i_not(t14));}}
else{
t11=C_eqp(t9,lf[4]);
t12=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3376,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=t5,a[8]=t9,a[9]=((C_word*)t0)[4],a[10]=t3,a[11]=t1,a[12]=((C_word*)t0)[5],a[13]=t7,a[14]=((C_word*)t0)[6],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t11)){
t13=t12;
f_3376(t13,t11);}
else{
t13=C_eqp(t9,lf[16]);
t14=t12;
f_3376(t14,(C_truep(t13)?t13:C_eqp(t9,lf[17])));}}}

/* k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3376(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3376,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[13],a[6]=((C_word*)t0)[14],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[13]);
/* optimizer.scm:75: scan */
t4=((C_word*)((C_word*)t0)[9])[1];
f_3295(t4,t2,t3,((C_word*)t0)[10]);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[5]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3402,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[13],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[13]);
/* optimizer.scm:80: scan */
t5=((C_word*)((C_word*)t0)[9])[1];
f_3295(t5,t3,t4,((C_word*)t0)[10]);}
else{
t3=C_eqp(((C_word*)t0)[8],lf[7]);
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_3426,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[13],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[14],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[11],tmp=(C_word)a,a+=15,tmp);
if(C_truep(t3)){
t5=t4;
f_3426(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[8],lf[14]);
t6=t4;
f_3426(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[8],lf[15])));}}}}

/* k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3426,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[13],lf[8]);
if(C_truep(t2)){
/* optimizer.scm:85: touch */
t3=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_3256(((C_word*)((C_word*)t0)[12])[1]));}
else{
t3=C_eqp(((C_word*)t0)[13],lf[9]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[11]);
t5=C_i_car(((C_word*)t0)[10]);
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t4,a[8]=((C_word*)t0)[14],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* optimizer.scm:90: scan */
t7=((C_word*)((C_word*)t0)[3])[1];
f_3295(t7,t6,t5,((C_word*)t0)[7]);}
else{
/* optimizer.scm:103: scan-each */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3261(t4,((C_word*)t0)[14],((C_word*)t0)[10],((C_word*)t0)[7]);}}}}

/* k3448 in k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3453,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* optimizer.scm:91: alist-ref */
t3=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[2])[1]);}

/* k3451 in k3448 in k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3471,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t4=C_i_memq(((C_word*)t0)[6],((C_word*)((C_word*)t0)[2])[1]);
t5=t3;
f_3471(t5,C_i_not(t4));}
else{
t4=t3;
f_3471(t4,C_SCHEME_FALSE);}}

/* k3469 in k3451 in k3448 in k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3471(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3471,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_record(&a,4,lf[10],lf[11],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);
/* optimizer.scm:97: copy-node! */
t3=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_3456(2,t2,C_SCHEME_UNDEFINED);}}

/* k3454 in k3451 in k3448 in k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3459,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_memq(((C_word*)t0)[5],((C_word*)t0)[3]))){
/* optimizer.scm:101: remember */
t3=((C_word*)((C_word*)t0)[7])[1];
f_3249(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
/* optimizer.scm:100: mark */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3226(t3,t2,((C_word*)t0)[5]);}}

/* k3457 in k3454 in k3451 in k3448 in k3424 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:101: remember */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3249(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3400 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3402,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3413,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* optimizer.scm:81: append */
t4=*((C_word*)lf[6]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3411 in k3400 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* optimizer.scm:81: scan */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3295(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3377 in k3374 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=f_3256(((C_word*)((C_word*)t0)[6])[1]);
t3=C_i_cdr(((C_word*)t0)[5]);
/* optimizer.scm:77: scan-each */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3261(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k3347 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3349(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3349,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_3332(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_3332(t2,C_SCHEME_UNDEFINED);}}

/* k3330 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3332(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3332,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* optimizer.scm:72: remove */
t4=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[4])[1]);}

/* a3337 in k3330 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3338,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(t3,((C_word*)t0)[2]));}

/* k3334 in k3330 in scan in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* scan-each in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3261(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3261,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3267,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3267(t7,t1,t2);}

/* loop36 in scan-each in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3267(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3267,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3282,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g4344 */
t6=t3;
f_3275(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3280 in loop36 in scan-each in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3267(t3,((C_word*)t0)[2],t2);}

/* g43 in loop36 in scan-each in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3275,NULL,3,t0,t1,t2);}
/* optimizer.scm:60: scan */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3295(t3,t1,t2,((C_word*)t0)[2]);}

/* touch in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static C_word C_fcall f_3256(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_stack_check;
t1=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t2=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_END_OF_LIST);
return(t2);}

/* remember in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3249(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3249,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3254,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* optimizer.scm:53: alist-update! */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3252 in remember in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* mark in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3226(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3226,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3233,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)((C_word*)t0)[3])[1];
if(C_truep(t4)){
t5=t3;
f_3233(t5,C_SCHEME_FALSE);}
else{
t5=C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]);
t6=t3;
f_3233(t6,C_i_not(t5));}}

/* k3231 in mark in ##compiler#scan-toplevel-assignments in k3219 in k3216 */
static void C_fcall f_3233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3233,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[684] = {
{"toplevel:optimizer_scm",(void*)C_optimizer_toplevel},
{"f_3218:optimizer_scm",(void*)f_3218},
{"f_3221:optimizer_scm",(void*)f_3221},
{"f_3570:optimizer_scm",(void*)f_3570},
{"f_14208:optimizer_scm",(void*)f_14208},
{"f_14216:optimizer_scm",(void*)f_14216},
{"f_14221:optimizer_scm",(void*)f_14221},
{"f_14271:optimizer_scm",(void*)f_14271},
{"f_14275:optimizer_scm",(void*)f_14275},
{"f_14231:optimizer_scm",(void*)f_14231},
{"f_14235:optimizer_scm",(void*)f_14235},
{"f_14257:optimizer_scm",(void*)f_14257},
{"f_5819:optimizer_scm",(void*)f_5819},
{"f_13117:optimizer_scm",(void*)f_13117},
{"f_13163:optimizer_scm",(void*)f_13163},
{"f_13265:optimizer_scm",(void*)f_13265},
{"f_13275:optimizer_scm",(void*)f_13275},
{"f_13612:optimizer_scm",(void*)f_13612},
{"f_13604:optimizer_scm",(void*)f_13604},
{"f_13381:optimizer_scm",(void*)f_13381},
{"f_13410:optimizer_scm",(void*)f_13410},
{"f_13580:optimizer_scm",(void*)f_13580},
{"f_13572:optimizer_scm",(void*)f_13572},
{"f_13441:optimizer_scm",(void*)f_13441},
{"f_13494:optimizer_scm",(void*)f_13494},
{"f_13484:optimizer_scm",(void*)f_13484},
{"f_13492:optimizer_scm",(void*)f_13492},
{"f_13666:optimizer_scm",(void*)f_13666},
{"f_13679:optimizer_scm",(void*)f_13679},
{"f_13721:optimizer_scm",(void*)f_13721},
{"f_13705:optimizer_scm",(void*)f_13705},
{"f_13709:optimizer_scm",(void*)f_13709},
{"f_13701:optimizer_scm",(void*)f_13701},
{"f_13887:optimizer_scm",(void*)f_13887},
{"f_13900:optimizer_scm",(void*)f_13900},
{"f_13906:optimizer_scm",(void*)f_13906},
{"f_13958:optimizer_scm",(void*)f_13958},
{"f_13950:optimizer_scm",(void*)f_13950},
{"f_13934:optimizer_scm",(void*)f_13934},
{"f_13938:optimizer_scm",(void*)f_13938},
{"f_13942:optimizer_scm",(void*)f_13942},
{"f_5822:optimizer_scm",(void*)f_5822},
{"f_12758:optimizer_scm",(void*)f_12758},
{"f_12780:optimizer_scm",(void*)f_12780},
{"f_12860:optimizer_scm",(void*)f_12860},
{"f_12818:optimizer_scm",(void*)f_12818},
{"f_12852:optimizer_scm",(void*)f_12852},
{"f_12856:optimizer_scm",(void*)f_12856},
{"f_12844:optimizer_scm",(void*)f_12844},
{"f_12816:optimizer_scm",(void*)f_12816},
{"f_12954:optimizer_scm",(void*)f_12954},
{"f_12974:optimizer_scm",(void*)f_12974},
{"f_5825:optimizer_scm",(void*)f_5825},
{"f_6314:optimizer_scm",(void*)f_6314},
{"f_10136:optimizer_scm",(void*)f_10136},
{"f_12631:optimizer_scm",(void*)f_12631},
{"f_12634:optimizer_scm",(void*)f_12634},
{"f_12637:optimizer_scm",(void*)f_12637},
{"f_12640:optimizer_scm",(void*)f_12640},
{"f_12643:optimizer_scm",(void*)f_12643},
{"f_12646:optimizer_scm",(void*)f_12646},
{"f_12729:optimizer_scm",(void*)f_12729},
{"f_12649:optimizer_scm",(void*)f_12649},
{"f_12652:optimizer_scm",(void*)f_12652},
{"f_12655:optimizer_scm",(void*)f_12655},
{"f_12723:optimizer_scm",(void*)f_12723},
{"f_12658:optimizer_scm",(void*)f_12658},
{"f_12661:optimizer_scm",(void*)f_12661},
{"f_12720:optimizer_scm",(void*)f_12720},
{"f_10910:optimizer_scm",(void*)f_10910},
{"f_10928:optimizer_scm",(void*)f_10928},
{"f_10934:optimizer_scm",(void*)f_10934},
{"f_10914:optimizer_scm",(void*)f_10914},
{"f_12664:optimizer_scm",(void*)f_12664},
{"f_12712:optimizer_scm",(void*)f_12712},
{"f_12710:optimizer_scm",(void*)f_12710},
{"f_12667:optimizer_scm",(void*)f_12667},
{"f_12670:optimizer_scm",(void*)f_12670},
{"f_12673:optimizer_scm",(void*)f_12673},
{"f_12697:optimizer_scm",(void*)f_12697},
{"f_12676:optimizer_scm",(void*)f_12676},
{"f_12679:optimizer_scm",(void*)f_12679},
{"f_12682:optimizer_scm",(void*)f_12682},
{"f_12685:optimizer_scm",(void*)f_12685},
{"f_12688:optimizer_scm",(void*)f_12688},
{"f_12691:optimizer_scm",(void*)f_12691},
{"f_12390:optimizer_scm",(void*)f_12390},
{"f_12396:optimizer_scm",(void*)f_12396},
{"f_12607:optimizer_scm",(void*)f_12607},
{"f_12617:optimizer_scm",(void*)f_12617},
{"f_12581:optimizer_scm",(void*)f_12581},
{"f_12591:optimizer_scm",(void*)f_12591},
{"f_12551:optimizer_scm",(void*)f_12551},
{"f_12560:optimizer_scm",(void*)f_12560},
{"f_12563:optimizer_scm",(void*)f_12563},
{"f_12521:optimizer_scm",(void*)f_12521},
{"f_12531:optimizer_scm",(void*)f_12531},
{"f_12430:optimizer_scm",(void*)f_12430},
{"f_12435:optimizer_scm",(void*)f_12435},
{"f_12473:optimizer_scm",(void*)f_12473},
{"f_12458:optimizer_scm",(void*)f_12458},
{"f_12469:optimizer_scm",(void*)f_12469},
{"f_12465:optimizer_scm",(void*)f_12465},
{"f_12192:optimizer_scm",(void*)f_12192},
{"f_12198:optimizer_scm",(void*)f_12198},
{"f_12367:optimizer_scm",(void*)f_12367},
{"f_12377:optimizer_scm",(void*)f_12377},
{"f_12307:optimizer_scm",(void*)f_12307},
{"f_12336:optimizer_scm",(void*)f_12336},
{"f_12297:optimizer_scm",(void*)f_12297},
{"f_12293:optimizer_scm",(void*)f_12293},
{"f_12235:optimizer_scm",(void*)f_12235},
{"f_12249:optimizer_scm",(void*)f_12249},
{"f_12259:optimizer_scm",(void*)f_12259},
{"f_11664:optimizer_scm",(void*)f_11664},
{"f_11678:optimizer_scm",(void*)f_11678},
{"f_11685:optimizer_scm",(void*)f_11685},
{"f_11688:optimizer_scm",(void*)f_11688},
{"f_11697:optimizer_scm",(void*)f_11697},
{"f_11849:optimizer_scm",(void*)f_11849},
{"f_11878:optimizer_scm",(void*)f_11878},
{"f_11704:optimizer_scm",(void*)f_11704},
{"f_11800:optimizer_scm",(void*)f_11800},
{"f_11833:optimizer_scm",(void*)f_11833},
{"f_11813:optimizer_scm",(void*)f_11813},
{"f_11707:optimizer_scm",(void*)f_11707},
{"f_11928:optimizer_scm",(void*)f_11928},
{"f_12169:optimizer_scm",(void*)f_12169},
{"f_12179:optimizer_scm",(void*)f_12179},
{"f_12110:optimizer_scm",(void*)f_12110},
{"f_12131:optimizer_scm",(void*)f_12131},
{"f_12129:optimizer_scm",(void*)f_12129},
{"f_12125:optimizer_scm",(void*)f_12125},
{"f_12057:optimizer_scm",(void*)f_12057},
{"f_12062:optimizer_scm",(void*)f_12062},
{"f_12072:optimizer_scm",(void*)f_12072},
{"f_11994:optimizer_scm",(void*)f_11994},
{"f_11992:optimizer_scm",(void*)f_11992},
{"f_11962:optimizer_scm",(void*)f_11962},
{"f_11967:optimizer_scm",(void*)f_11967},
{"f_11977:optimizer_scm",(void*)f_11977},
{"f_11913:optimizer_scm",(void*)f_11913},
{"f_11710:optimizer_scm",(void*)f_11710},
{"f_11785:optimizer_scm",(void*)f_11785},
{"f_11773:optimizer_scm",(void*)f_11773},
{"f_11769:optimizer_scm",(void*)f_11769},
{"f_11676:optimizer_scm",(void*)f_11676},
{"f_11255:optimizer_scm",(void*)f_11255},
{"f_11616:optimizer_scm",(void*)f_11616},
{"f_11381:optimizer_scm",(void*)f_11381},
{"f_11593:optimizer_scm",(void*)f_11593},
{"f_11603:optimizer_scm",(void*)f_11603},
{"f_11514:optimizer_scm",(void*)f_11514},
{"f_11519:optimizer_scm",(void*)f_11519},
{"f_11587:optimizer_scm",(void*)f_11587},
{"f_11546:optimizer_scm",(void*)f_11546},
{"f_11584:optimizer_scm",(void*)f_11584},
{"f_11264:optimizer_scm",(void*)f_11264},
{"f_11357:optimizer_scm",(void*)f_11357},
{"f_11367:optimizer_scm",(void*)f_11367},
{"f_11340:optimizer_scm",(void*)f_11340},
{"f_11345:optimizer_scm",(void*)f_11345},
{"f_11299:optimizer_scm",(void*)f_11299},
{"f_11304:optimizer_scm",(void*)f_11304},
{"f_11314:optimizer_scm",(void*)f_11314},
{"f_11262:optimizer_scm",(void*)f_11262},
{"f_11576:optimizer_scm",(void*)f_11576},
{"f_11562:optimizer_scm",(void*)f_11562},
{"f_11560:optimizer_scm",(void*)f_11560},
{"f_11383:optimizer_scm",(void*)f_11383},
{"f_11507:optimizer_scm",(void*)f_11507},
{"f_11505:optimizer_scm",(void*)f_11505},
{"f_11471:optimizer_scm",(void*)f_11471},
{"f_11490:optimizer_scm",(void*)f_11490},
{"f_11479:optimizer_scm",(void*)f_11479},
{"f_11403:optimizer_scm",(void*)f_11403},
{"f_11427:optimizer_scm",(void*)f_11427},
{"f_11454:optimizer_scm",(void*)f_11454},
{"f_11425:optimizer_scm",(void*)f_11425},
{"f_11421:optimizer_scm",(void*)f_11421},
{"f_11413:optimizer_scm",(void*)f_11413},
{"f_10944:optimizer_scm",(void*)f_10944},
{"f_10950:optimizer_scm",(void*)f_10950},
{"f_10984:optimizer_scm",(void*)f_10984},
{"f_11206:optimizer_scm",(void*)f_11206},
{"f_11221:optimizer_scm",(void*)f_11221},
{"f_11214:optimizer_scm",(void*)f_11214},
{"f_11103:optimizer_scm",(void*)f_11103},
{"f_11119:optimizer_scm",(void*)f_11119},
{"f_11172:optimizer_scm",(void*)f_11172},
{"f_11176:optimizer_scm",(void*)f_11176},
{"f_11139:optimizer_scm",(void*)f_11139},
{"f_11148:optimizer_scm",(void*)f_11148},
{"f_11158:optimizer_scm",(void*)f_11158},
{"f_11070:optimizer_scm",(void*)f_11070},
{"f_11075:optimizer_scm",(void*)f_11075},
{"f_11090:optimizer_scm",(void*)f_11090},
{"f_11083:optimizer_scm",(void*)f_11083},
{"f_11046:optimizer_scm",(void*)f_11046},
{"f_11058:optimizer_scm",(void*)f_11058},
{"f_10995:optimizer_scm",(void*)f_10995},
{"f_11016:optimizer_scm",(void*)f_11016},
{"f_11013:optimizer_scm",(void*)f_11013},
{"f_10948:optimizer_scm",(void*)f_10948},
{"f_10663:optimizer_scm",(void*)f_10663},
{"f_10669:optimizer_scm",(void*)f_10669},
{"f_10703:optimizer_scm",(void*)f_10703},
{"f_10805:optimizer_scm",(void*)f_10805},
{"f_10820:optimizer_scm",(void*)f_10820},
{"f_10813:optimizer_scm",(void*)f_10813},
{"f_10796:optimizer_scm",(void*)f_10796},
{"f_10762:optimizer_scm",(void*)f_10762},
{"f_10771:optimizer_scm",(void*)f_10771},
{"f_10783:optimizer_scm",(void*)f_10783},
{"f_10714:optimizer_scm",(void*)f_10714},
{"f_10735:optimizer_scm",(void*)f_10735},
{"f_10732:optimizer_scm",(void*)f_10732},
{"f_10667:optimizer_scm",(void*)f_10667},
{"f_10530:optimizer_scm",(void*)f_10530},
{"f_10536:optimizer_scm",(void*)f_10536},
{"f_10580:optimizer_scm",(void*)f_10580},
{"f_10585:optimizer_scm",(void*)f_10585},
{"f_10592:optimizer_scm",(void*)f_10592},
{"f_10653:optimizer_scm",(void*)f_10653},
{"f_10649:optimizer_scm",(void*)f_10649},
{"f_10607:optimizer_scm",(void*)f_10607},
{"f_10641:optimizer_scm",(void*)f_10641},
{"f_10634:optimizer_scm",(void*)f_10634},
{"f_10605:optimizer_scm",(void*)f_10605},
{"f_10570:optimizer_scm",(void*)f_10570},
{"f_10548:optimizer_scm",(void*)f_10548},
{"f_10555:optimizer_scm",(void*)f_10555},
{"f_10242:optimizer_scm",(void*)f_10242},
{"f_10455:optimizer_scm",(void*)f_10455},
{"f_10517:optimizer_scm",(void*)f_10517},
{"f_10463:optimizer_scm",(void*)f_10463},
{"f_10488:optimizer_scm",(void*)f_10488},
{"f_10478:optimizer_scm",(void*)f_10478},
{"f_10482:optimizer_scm",(void*)f_10482},
{"f_10453:optimizer_scm",(void*)f_10453},
{"f_10245:optimizer_scm",(void*)f_10245},
{"f_10421:optimizer_scm",(void*)f_10421},
{"f_10436:optimizer_scm",(void*)f_10436},
{"f_10429:optimizer_scm",(void*)f_10429},
{"f_10404:optimizer_scm",(void*)f_10404},
{"f_10416:optimizer_scm",(void*)f_10416},
{"f_10350:optimizer_scm",(void*)f_10350},
{"f_10374:optimizer_scm",(void*)f_10374},
{"f_10368:optimizer_scm",(void*)f_10368},
{"f_10332:optimizer_scm",(void*)f_10332},
{"f_10285:optimizer_scm",(void*)f_10285},
{"f_10288:optimizer_scm",(void*)f_10288},
{"f_10293:optimizer_scm",(void*)f_10293},
{"f_10308:optimizer_scm",(void*)f_10308},
{"f_10301:optimizer_scm",(void*)f_10301},
{"f_10139:optimizer_scm",(void*)f_10139},
{"f_10145:optimizer_scm",(void*)f_10145},
{"f_10173:optimizer_scm",(void*)f_10173},
{"f_10177:optimizer_scm",(void*)f_10177},
{"f_10181:optimizer_scm",(void*)f_10181},
{"f_10143:optimizer_scm",(void*)f_10143},
{"f_8751:optimizer_scm",(void*)f_8751},
{"f_10131:optimizer_scm",(void*)f_10131},
{"f_10134:optimizer_scm",(void*)f_10134},
{"f_9407:optimizer_scm",(void*)f_9407},
{"f_10121:optimizer_scm",(void*)f_10121},
{"f_10119:optimizer_scm",(void*)f_10119},
{"f_9411:optimizer_scm",(void*)f_9411},
{"f_9426:optimizer_scm",(void*)f_9426},
{"f_9435:optimizer_scm",(void*)f_9435},
{"f_9441:optimizer_scm",(void*)f_9441},
{"f_9444:optimizer_scm",(void*)f_9444},
{"f_9450:optimizer_scm",(void*)f_9450},
{"f_9733:optimizer_scm",(void*)f_9733},
{"f_10048:optimizer_scm",(void*)f_10048},
{"f_10058:optimizer_scm",(void*)f_10058},
{"f_10022:optimizer_scm",(void*)f_10022},
{"f_10032:optimizer_scm",(void*)f_10032},
{"f_10007:optimizer_scm",(void*)f_10007},
{"f_10010:optimizer_scm",(void*)f_10010},
{"f_9955:optimizer_scm",(void*)f_9955},
{"f_9958:optimizer_scm",(void*)f_9958},
{"f_9802:optimizer_scm",(void*)f_9802},
{"f_9849:optimizer_scm",(void*)f_9849},
{"f_9859:optimizer_scm",(void*)f_9859},
{"f_9862:optimizer_scm",(void*)f_9862},
{"f_9896:optimizer_scm",(void*)f_9896},
{"f_9865:optimizer_scm",(void*)f_9865},
{"f_9868:optimizer_scm",(void*)f_9868},
{"f_9811:optimizer_scm",(void*)f_9811},
{"f_9814:optimizer_scm",(void*)f_9814},
{"f_9817:optimizer_scm",(void*)f_9817},
{"f_9453:optimizer_scm",(void*)f_9453},
{"f_9715:optimizer_scm",(void*)f_9715},
{"f_9624:optimizer_scm",(void*)f_9624},
{"f_9626:optimizer_scm",(void*)f_9626},
{"f_9702:optimizer_scm",(void*)f_9702},
{"f_9634:optimizer_scm",(void*)f_9634},
{"f_9649:optimizer_scm",(void*)f_9649},
{"f_9456:optimizer_scm",(void*)f_9456},
{"f_9473:optimizer_scm",(void*)f_9473},
{"f_9544:optimizer_scm",(void*)f_9544},
{"f_9476:optimizer_scm",(void*)f_9476},
{"f_9479:optimizer_scm",(void*)f_9479},
{"f_9484:optimizer_scm",(void*)f_9484},
{"f_9528:optimizer_scm",(void*)f_9528},
{"f_9499:optimizer_scm",(void*)f_9499},
{"f_8953:optimizer_scm",(void*)f_8953},
{"f_9398:optimizer_scm",(void*)f_9398},
{"f_9405:optimizer_scm",(void*)f_9405},
{"f_8956:optimizer_scm",(void*)f_8956},
{"f_9385:optimizer_scm",(void*)f_9385},
{"f_9361:optimizer_scm",(void*)f_9361},
{"f_9372:optimizer_scm",(void*)f_9372},
{"f_9328:optimizer_scm",(void*)f_9328},
{"f_9219:optimizer_scm",(void*)f_9219},
{"f_9224:optimizer_scm",(void*)f_9224},
{"f_9166:optimizer_scm",(void*)f_9166},
{"f_9172:optimizer_scm",(void*)f_9172},
{"f_9177:optimizer_scm",(void*)f_9177},
{"f_9125:optimizer_scm",(void*)f_9125},
{"f_9131:optimizer_scm",(void*)f_9131},
{"f_9136:optimizer_scm",(void*)f_9136},
{"f_9109:optimizer_scm",(void*)f_9109},
{"f_9105:optimizer_scm",(void*)f_9105},
{"f_9075:optimizer_scm",(void*)f_9075},
{"f_9038:optimizer_scm",(void*)f_9038},
{"f_9054:optimizer_scm",(void*)f_9054},
{"f_9020:optimizer_scm",(void*)f_9020},
{"f_8754:optimizer_scm",(void*)f_8754},
{"f_8925:optimizer_scm",(void*)f_8925},
{"f_8940:optimizer_scm",(void*)f_8940},
{"f_8933:optimizer_scm",(void*)f_8933},
{"f_8905:optimizer_scm",(void*)f_8905},
{"f_8879:optimizer_scm",(void*)f_8879},
{"f_8825:optimizer_scm",(void*)f_8825},
{"f_8831:optimizer_scm",(void*)f_8831},
{"f_8837:optimizer_scm",(void*)f_8837},
{"f_8794:optimizer_scm",(void*)f_8794},
{"f_6336:optimizer_scm",(void*)f_6336},
{"f_8618:optimizer_scm",(void*)f_8618},
{"f_8647:optimizer_scm",(void*)f_8647},
{"f_8659:optimizer_scm",(void*)f_8659},
{"f_8673:optimizer_scm",(void*)f_8673},
{"f_8722:optimizer_scm",(void*)f_8722},
{"f_6361:optimizer_scm",(void*)f_6361},
{"f_8693:optimizer_scm",(void*)f_8693},
{"f_8697:optimizer_scm",(void*)f_8697},
{"f_8667:optimizer_scm",(void*)f_8667},
{"f_8653:optimizer_scm",(void*)f_8653},
{"f_8651:optimizer_scm",(void*)f_8651},
{"f_8643:optimizer_scm",(void*)f_8643},
{"f_8538:optimizer_scm",(void*)f_8538},
{"f_8582:optimizer_scm",(void*)f_8582},
{"f_8343:optimizer_scm",(void*)f_8343},
{"f_8349:optimizer_scm",(void*)f_8349},
{"f_8465:optimizer_scm",(void*)f_8465},
{"f_8358:optimizer_scm",(void*)f_8358},
{"f_8420:optimizer_scm",(void*)f_8420},
{"f_8418:optimizer_scm",(void*)f_8418},
{"f_8380:optimizer_scm",(void*)f_8380},
{"f_8258:optimizer_scm",(void*)f_8258},
{"f_8299:optimizer_scm",(void*)f_8299},
{"f_8311:optimizer_scm",(void*)f_8311},
{"f_8289:optimizer_scm",(void*)f_8289},
{"f_8287:optimizer_scm",(void*)f_8287},
{"f_8076:optimizer_scm",(void*)f_8076},
{"f_8182:optimizer_scm",(void*)f_8182},
{"f_8085:optimizer_scm",(void*)f_8085},
{"f_8156:optimizer_scm",(void*)f_8156},
{"f_8154:optimizer_scm",(void*)f_8154},
{"f_8107:optimizer_scm",(void*)f_8107},
{"f_8036:optimizer_scm",(void*)f_8036},
{"f_8052:optimizer_scm",(void*)f_8052},
{"f_7957:optimizer_scm",(void*)f_7957},
{"f_7986:optimizer_scm",(void*)f_7986},
{"f_7812:optimizer_scm",(void*)f_7812},
{"f_7835:optimizer_scm",(void*)f_7835},
{"f_7899:optimizer_scm",(void*)f_7899},
{"f_7873:optimizer_scm",(void*)f_7873},
{"f_7869:optimizer_scm",(void*)f_7869},
{"f_7727:optimizer_scm",(void*)f_7727},
{"f_7753:optimizer_scm",(void*)f_7753},
{"f_7749:optimizer_scm",(void*)f_7749},
{"f_7633:optimizer_scm",(void*)f_7633},
{"f_7556:optimizer_scm",(void*)f_7556},
{"f_7580:optimizer_scm",(void*)f_7580},
{"f_7584:optimizer_scm",(void*)f_7584},
{"f_7468:optimizer_scm",(void*)f_7468},
{"f_7524:optimizer_scm",(void*)f_7524},
{"f_7520:optimizer_scm",(void*)f_7520},
{"f_7397:optimizer_scm",(void*)f_7397},
{"f_7409:optimizer_scm",(void*)f_7409},
{"f_7429:optimizer_scm",(void*)f_7429},
{"f_7425:optimizer_scm",(void*)f_7425},
{"f_7298:optimizer_scm",(void*)f_7298},
{"f_7307:optimizer_scm",(void*)f_7307},
{"f_7327:optimizer_scm",(void*)f_7327},
{"f_7335:optimizer_scm",(void*)f_7335},
{"f_7339:optimizer_scm",(void*)f_7339},
{"f_7055:optimizer_scm",(void*)f_7055},
{"f_7083:optimizer_scm",(void*)f_7083},
{"f_7086:optimizer_scm",(void*)f_7086},
{"f_7199:optimizer_scm",(void*)f_7199},
{"f_7233:optimizer_scm",(void*)f_7233},
{"f_7089:optimizer_scm",(void*)f_7089},
{"f_7164:optimizer_scm",(void*)f_7164},
{"f_7193:optimizer_scm",(void*)f_7193},
{"f_7092:optimizer_scm",(void*)f_7092},
{"f_7136:optimizer_scm",(void*)f_7136},
{"f_7134:optimizer_scm",(void*)f_7134},
{"f_7097:optimizer_scm",(void*)f_7097},
{"f_7077:optimizer_scm",(void*)f_7077},
{"f_7029:optimizer_scm",(void*)f_7029},
{"f_6956:optimizer_scm",(void*)f_6956},
{"f_6993:optimizer_scm",(void*)f_6993},
{"f_6985:optimizer_scm",(void*)f_6985},
{"f_6867:optimizer_scm",(void*)f_6867},
{"f_6762:optimizer_scm",(void*)f_6762},
{"f_6817:optimizer_scm",(void*)f_6817},
{"f_6694:optimizer_scm",(void*)f_6694},
{"f_6714:optimizer_scm",(void*)f_6714},
{"f_6722:optimizer_scm",(void*)f_6722},
{"f_6618:optimizer_scm",(void*)f_6618},
{"f_6661:optimizer_scm",(void*)f_6661},
{"f_6623:optimizer_scm",(void*)f_6623},
{"f_6644:optimizer_scm",(void*)f_6644},
{"f_6549:optimizer_scm",(void*)f_6549},
{"f_6398:optimizer_scm",(void*)f_6398},
{"f_6479:optimizer_scm",(void*)f_6479},
{"f_6401:optimizer_scm",(void*)f_6401},
{"f_6316:optimizer_scm",(void*)f_6316},
{"f_6320:optimizer_scm",(void*)f_6320},
{"f_6330:optimizer_scm",(void*)f_6330},
{"f_5827:optimizer_scm",(void*)f_5827},
{"f_6263:optimizer_scm",(void*)f_6263},
{"f_6296:optimizer_scm",(void*)f_6296},
{"f_6276:optimizer_scm",(void*)f_6276},
{"f_5831:optimizer_scm",(void*)f_5831},
{"f_6216:optimizer_scm",(void*)f_6216},
{"f_6236:optimizer_scm",(void*)f_6236},
{"f_6224:optimizer_scm",(void*)f_6224},
{"f_6233:optimizer_scm",(void*)f_6233},
{"f_6229:optimizer_scm",(void*)f_6229},
{"f_5878:optimizer_scm",(void*)f_5878},
{"f_6136:optimizer_scm",(void*)f_6136},
{"f_6203:optimizer_scm",(void*)f_6203},
{"f_6144:optimizer_scm",(void*)f_6144},
{"f_6176:optimizer_scm",(void*)f_6176},
{"f_6189:optimizer_scm",(void*)f_6189},
{"f_6154:optimizer_scm",(void*)f_6154},
{"f_6170:optimizer_scm",(void*)f_6170},
{"f_6158:optimizer_scm",(void*)f_6158},
{"f_6162:optimizer_scm",(void*)f_6162},
{"f_5881:optimizer_scm",(void*)f_5881},
{"f_6055:optimizer_scm",(void*)f_6055},
{"f_6123:optimizer_scm",(void*)f_6123},
{"f_6063:optimizer_scm",(void*)f_6063},
{"f_6106:optimizer_scm",(void*)f_6106},
{"f_6112:optimizer_scm",(void*)f_6112},
{"f_6070:optimizer_scm",(void*)f_6070},
{"f_6080:optimizer_scm",(void*)f_6080},
{"f_6093:optimizer_scm",(void*)f_6093},
{"f_6078:optimizer_scm",(void*)f_6078},
{"f_6074:optimizer_scm",(void*)f_6074},
{"f_5884:optimizer_scm",(void*)f_5884},
{"f_5887:optimizer_scm",(void*)f_5887},
{"f_5907:optimizer_scm",(void*)f_5907},
{"f_5920:optimizer_scm",(void*)f_5920},
{"f_5981:optimizer_scm",(void*)f_5981},
{"f_6027:optimizer_scm",(void*)f_6027},
{"f_5979:optimizer_scm",(void*)f_5979},
{"f_5949:optimizer_scm",(void*)f_5949},
{"f_5890:optimizer_scm",(void*)f_5890},
{"f_5899:optimizer_scm",(void*)f_5899},
{"f_5833:optimizer_scm",(void*)f_5833},
{"f_5839:optimizer_scm",(void*)f_5839},
{"f_5863:optimizer_scm",(void*)f_5863},
{"f_5812:optimizer_scm",(void*)f_5812},
{"f_5493:optimizer_scm",(void*)f_5493},
{"f_5507:optimizer_scm",(void*)f_5507},
{"f_5527:optimizer_scm",(void*)f_5527},
{"f_5534:optimizer_scm",(void*)f_5534},
{"f_5539:optimizer_scm",(void*)f_5539},
{"f_5799:optimizer_scm",(void*)f_5799},
{"f_5547:optimizer_scm",(void*)f_5547},
{"f_5783:optimizer_scm",(void*)f_5783},
{"f_5565:optimizer_scm",(void*)f_5565},
{"f_5568:optimizer_scm",(void*)f_5568},
{"f_5574:optimizer_scm",(void*)f_5574},
{"f_5594:optimizer_scm",(void*)f_5594},
{"f_5600:optimizer_scm",(void*)f_5600},
{"f_5606:optimizer_scm",(void*)f_5606},
{"f_5615:optimizer_scm",(void*)f_5615},
{"f_5622:optimizer_scm",(void*)f_5622},
{"f_5625:optimizer_scm",(void*)f_5625},
{"f_5643:optimizer_scm",(void*)f_5643},
{"f_5628:optimizer_scm",(void*)f_5628},
{"f_5510:optimizer_scm",(void*)f_5510},
{"f_5513:optimizer_scm",(void*)f_5513},
{"f_5500:optimizer_scm",(void*)f_5500},
{"f_5496:optimizer_scm",(void*)f_5496},
{"f_3573:optimizer_scm",(void*)f_3573},
{"f_5375:optimizer_scm",(void*)f_5375},
{"f_5381:optimizer_scm",(void*)f_5381},
{"f_5385:optimizer_scm",(void*)f_5385},
{"f_5388:optimizer_scm",(void*)f_5388},
{"f_5424:optimizer_scm",(void*)f_5424},
{"f_5429:optimizer_scm",(void*)f_5429},
{"f_5441:optimizer_scm",(void*)f_5441},
{"f_5468:optimizer_scm",(void*)f_5468},
{"f_5391:optimizer_scm",(void*)f_5391},
{"f_5394:optimizer_scm",(void*)f_5394},
{"f_5397:optimizer_scm",(void*)f_5397},
{"f_5400:optimizer_scm",(void*)f_5400},
{"f_5345:optimizer_scm",(void*)f_5345},
{"f_5365:optimizer_scm",(void*)f_5365},
{"f_5349:optimizer_scm",(void*)f_5349},
{"f_5355:optimizer_scm",(void*)f_5355},
{"f_4028:optimizer_scm",(void*)f_4028},
{"f_5235:optimizer_scm",(void*)f_5235},
{"f_5238:optimizer_scm",(void*)f_5238},
{"f_5337:optimizer_scm",(void*)f_5337},
{"f_5333:optimizer_scm",(void*)f_5333},
{"f_5295:optimizer_scm",(void*)f_5295},
{"f_5326:optimizer_scm",(void*)f_5326},
{"f_5322:optimizer_scm",(void*)f_5322},
{"f_5314:optimizer_scm",(void*)f_5314},
{"f_5255:optimizer_scm",(void*)f_5255},
{"f_5285:optimizer_scm",(void*)f_5285},
{"f_5261:optimizer_scm",(void*)f_5261},
{"f_5209:optimizer_scm",(void*)f_5209},
{"f_5207:optimizer_scm",(void*)f_5207},
{"f_5167:optimizer_scm",(void*)f_5167},
{"f_5157:optimizer_scm",(void*)f_5157},
{"f_4410:optimizer_scm",(void*)f_4410},
{"f_4419:optimizer_scm",(void*)f_4419},
{"f_4476:optimizer_scm",(void*)f_4476},
{"f_4706:optimizer_scm",(void*)f_4706},
{"f_4722:optimizer_scm",(void*)f_4722},
{"f_5136:optimizer_scm",(void*)f_5136},
{"f_5087:optimizer_scm",(void*)f_5087},
{"f_5127:optimizer_scm",(void*)f_5127},
{"f_5101:optimizer_scm",(void*)f_5101},
{"f_4740:optimizer_scm",(void*)f_4740},
{"f_4795:optimizer_scm",(void*)f_4795},
{"f_5074:optimizer_scm",(void*)f_5074},
{"f_4973:optimizer_scm",(void*)f_4973},
{"f_4976:optimizer_scm",(void*)f_4976},
{"f_4988:optimizer_scm",(void*)f_4988},
{"f_4999:optimizer_scm",(void*)f_4999},
{"f_5038:optimizer_scm",(void*)f_5038},
{"f_5030:optimizer_scm",(void*)f_5030},
{"f_5018:optimizer_scm",(void*)f_5018},
{"f_5016:optimizer_scm",(void*)f_5016},
{"f_4993:optimizer_scm",(void*)f_4993},
{"f_4809:optimizer_scm",(void*)f_4809},
{"f_4854:optimizer_scm",(void*)f_4854},
{"f_4860:optimizer_scm",(void*)f_4860},
{"f_4866:optimizer_scm",(void*)f_4866},
{"f_4910:optimizer_scm",(void*)f_4910},
{"f_4886:optimizer_scm",(void*)f_4886},
{"f_4890:optimizer_scm",(void*)f_4890},
{"f_4848:optimizer_scm",(void*)f_4848},
{"f_4836:optimizer_scm",(void*)f_4836},
{"f_4834:optimizer_scm",(void*)f_4834},
{"f_4743:optimizer_scm",(void*)f_4743},
{"f_4777:optimizer_scm",(void*)f_4777},
{"f_4746:optimizer_scm",(void*)f_4746},
{"f_4749:optimizer_scm",(void*)f_4749},
{"f_4752:optimizer_scm",(void*)f_4752},
{"f_4762:optimizer_scm",(void*)f_4762},
{"f_4480:optimizer_scm",(void*)f_4480},
{"f_4688:optimizer_scm",(void*)f_4688},
{"f_4502:optimizer_scm",(void*)f_4502},
{"f_4662:optimizer_scm",(void*)f_4662},
{"f_4517:optimizer_scm",(void*)f_4517},
{"f_4538:optimizer_scm",(void*)f_4538},
{"f_4626:optimizer_scm",(void*)f_4626},
{"f_4618:optimizer_scm",(void*)f_4618},
{"f_4541:optimizer_scm",(void*)f_4541},
{"f_4597:optimizer_scm",(void*)f_4597},
{"f_4595:optimizer_scm",(void*)f_4595},
{"f_4578:optimizer_scm",(void*)f_4578},
{"f_4553:optimizer_scm",(void*)f_4553},
{"f_4487:optimizer_scm",(void*)f_4487},
{"f_4433:optimizer_scm",(void*)f_4433},
{"f_4436:optimizer_scm",(void*)f_4436},
{"f_4464:optimizer_scm",(void*)f_4464},
{"f_4442:optimizer_scm",(void*)f_4442},
{"f_4449:optimizer_scm",(void*)f_4449},
{"f_4215:optimizer_scm",(void*)f_4215},
{"f_4314:optimizer_scm",(void*)f_4314},
{"f_4319:optimizer_scm",(void*)f_4319},
{"f_4326:optimizer_scm",(void*)f_4326},
{"f_4366:optimizer_scm",(void*)f_4366},
{"f_4346:optimizer_scm",(void*)f_4346},
{"f_4220:optimizer_scm",(void*)f_4220},
{"f_4238:optimizer_scm",(void*)f_4238},
{"f_4245:optimizer_scm",(void*)f_4245},
{"f_4292:optimizer_scm",(void*)f_4292},
{"f_4295:optimizer_scm",(void*)f_4295},
{"f_4285:optimizer_scm",(void*)f_4285},
{"f_4265:optimizer_scm",(void*)f_4265},
{"f_4226:optimizer_scm",(void*)f_4226},
{"f_4232:optimizer_scm",(void*)f_4232},
{"f_4149:optimizer_scm",(void*)f_4149},
{"f_4190:optimizer_scm",(void*)f_4190},
{"f_4197:optimizer_scm",(void*)f_4197},
{"f_4152:optimizer_scm",(void*)f_4152},
{"f_4180:optimizer_scm",(void*)f_4180},
{"f_4178:optimizer_scm",(void*)f_4178},
{"f_4068:optimizer_scm",(void*)f_4068},
{"f_4072:optimizer_scm",(void*)f_4072},
{"f_4084:optimizer_scm",(void*)f_4084},
{"f_4090:optimizer_scm",(void*)f_4090},
{"f_4110:optimizer_scm",(void*)f_4110},
{"f_3747:optimizer_scm",(void*)f_3747},
{"f_3761:optimizer_scm",(void*)f_3761},
{"f_3987:optimizer_scm",(void*)f_3987},
{"f_3993:optimizer_scm",(void*)f_3993},
{"f_3841:optimizer_scm",(void*)f_3841},
{"f_3933:optimizer_scm",(void*)f_3933},
{"f_3927:optimizer_scm",(void*)f_3927},
{"f_3852:optimizer_scm",(void*)f_3852},
{"f_3875:optimizer_scm",(void*)f_3875},
{"f_3913:optimizer_scm",(void*)f_3913},
{"f_3919:optimizer_scm",(void*)f_3919},
{"f_3881:optimizer_scm",(void*)f_3881},
{"f_3885:optimizer_scm",(void*)f_3885},
{"f_3888:optimizer_scm",(void*)f_3888},
{"f_3911:optimizer_scm",(void*)f_3911},
{"f_3858:optimizer_scm",(void*)f_3858},
{"f_3864:optimizer_scm",(void*)f_3864},
{"f_3868:optimizer_scm",(void*)f_3868},
{"f_3872:optimizer_scm",(void*)f_3872},
{"f_3847:optimizer_scm",(void*)f_3847},
{"f_3780:optimizer_scm",(void*)f_3780},
{"f_3616:optimizer_scm",(void*)f_3616},
{"f_3620:optimizer_scm",(void*)f_3620},
{"f_3631:optimizer_scm",(void*)f_3631},
{"f_3641:optimizer_scm",(void*)f_3641},
{"f_3690:optimizer_scm",(void*)f_3690},
{"f_3717:optimizer_scm",(void*)f_3717},
{"f_3688:optimizer_scm",(void*)f_3688},
{"f_3647:optimizer_scm",(void*)f_3647},
{"f_3653:optimizer_scm",(void*)f_3653},
{"f_3680:optimizer_scm",(void*)f_3680},
{"f_3623:optimizer_scm",(void*)f_3623},
{"f_3612:optimizer_scm",(void*)f_3612},
{"f_3582:optimizer_scm",(void*)f_3582},
{"f_3576:optimizer_scm",(void*)f_3576},
{"f_3223:optimizer_scm",(void*)f_3223},
{"f_3514:optimizer_scm",(void*)f_3514},
{"f_3517:optimizer_scm",(void*)f_3517},
{"f_3566:optimizer_scm",(void*)f_3566},
{"f_3520:optimizer_scm",(void*)f_3520},
{"f_3525:optimizer_scm",(void*)f_3525},
{"f_3531:optimizer_scm",(void*)f_3531},
{"f_3295:optimizer_scm",(void*)f_3295},
{"f_3376:optimizer_scm",(void*)f_3376},
{"f_3426:optimizer_scm",(void*)f_3426},
{"f_3450:optimizer_scm",(void*)f_3450},
{"f_3453:optimizer_scm",(void*)f_3453},
{"f_3471:optimizer_scm",(void*)f_3471},
{"f_3456:optimizer_scm",(void*)f_3456},
{"f_3459:optimizer_scm",(void*)f_3459},
{"f_3402:optimizer_scm",(void*)f_3402},
{"f_3413:optimizer_scm",(void*)f_3413},
{"f_3379:optimizer_scm",(void*)f_3379},
{"f_3349:optimizer_scm",(void*)f_3349},
{"f_3332:optimizer_scm",(void*)f_3332},
{"f_3338:optimizer_scm",(void*)f_3338},
{"f_3336:optimizer_scm",(void*)f_3336},
{"f_3261:optimizer_scm",(void*)f_3261},
{"f_3267:optimizer_scm",(void*)f_3267},
{"f_3282:optimizer_scm",(void*)f_3282},
{"f_3275:optimizer_scm",(void*)f_3275},
{"f_3256:optimizer_scm",(void*)f_3256},
{"f_3249:optimizer_scm",(void*)f_3249},
{"f_3254:optimizer_scm",(void*)f_3254},
{"f_3226:optimizer_scm",(void*)f_3226},
{"f_3233:optimizer_scm",(void*)f_3233},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
