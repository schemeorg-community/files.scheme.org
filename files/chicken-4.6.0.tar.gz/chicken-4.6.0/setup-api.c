/* Generated from setup-api.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: setup-api.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -feature chicken-compile-shared -dynamic -emit-import-library setup-api -output-file setup-api.c
   used units: library eval srfi_1 regex utils posix srfi_13 extras ports data_structures files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[353];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,115,104,101,108,108,112,97,116,104,32,115,116,114,52,49,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,101,120,116,114,97,45,102,101,97,116,117,114,101,115,32,46,32,116,109,112,52,56,52,57,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,39),40,115,101,116,117,112,45,97,112,105,35,101,120,116,114,97,45,110,111,110,102,101,97,116,117,114,101,115,32,46,32,116,109,112,54,52,54,53,41,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,117,115,101,114,45,105,110,115,116,97,108,108,45,115,101,116,117,112,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,115,117,100,111,45,105,110,115,116,97,108,108,32,46,32,97,114,103,115,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,7),40,97,49,56,53,48,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,49,56,52,48,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,41),40,115,101,116,117,112,45,97,112,105,35,112,97,116,99,104,32,119,104,105,99,104,49,50,52,32,114,120,49,50,53,32,115,117,98,115,116,49,50,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,48),40,115,101,116,117,112,45,97,112,105,35,114,101,103,105,115,116,101,114,45,112,114,111,103,114,97,109,32,110,97,109,101,49,53,54,32,46,32,116,109,112,49,53,53,49,53,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,112,114,111,103,114,97,109,32,110,97,109,101,49,54,49,41};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,22),40,114,101,103,32,110,97,109,101,49,54,53,32,114,110,97,109,101,49,54,54,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,102,105,120,109,97,107,101,116,97,114,103,101,116,32,102,105,108,101,50,51,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,51,54,32,103,50,52,48,50,54,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,48,57,32,103,50,49,57,50,50,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,56,53,32,103,49,57,53,49,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,52,54,32,103,50,53,54,50,54,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,50,56,51,32,103,50,57,51,50,57,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,30),40,115,101,116,117,112,45,97,112,105,35,101,120,101,99,117,116,101,32,101,120,112,108,105,115,116,50,51,51,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,102,111,114,109,45,101,114,114,111,114,32,115,51,55,48,32,112,51,55,49,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,108,105,110,101,45,101,114,114,111,114,32,115,51,56,48,32,112,51,56,49,32,110,51,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,7),40,97,50,55,53,50,41,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,97,50,55,52,54,32,101,120,110,53,49,57,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,50,55,57,51,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,50,56,48,56,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,20),40,97,50,56,48,50,32,46,32,97,114,103,115,53,49,53,53,51,48,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,7),40,97,50,55,56,55,41,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,15),40,97,50,55,52,48,32,107,53,49,52,53,49,56,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,14),40,97,50,56,56,50,32,100,101,112,52,55,57,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,12),40,97,50,57,50,54,32,100,52,55,52,41,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,13),40,109,97,116,99,104,63,32,115,51,54,49,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,108,105,110,101,115,51,54,51,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,23),40,102,95,50,54,56,54,32,115,52,52,55,32,105,110,100,101,110,116,52,52,56,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,54,49,32,103,53,54,53,53,54,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,11),40,103,53,53,52,32,102,53,53,54,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,53,52,55,32,103,53,53,49,53,53,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,14),40,97,50,53,55,57,32,100,101,112,52,50,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,15),40,97,50,53,49,48,32,108,105,110,101,52,48,50,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,58,109,97,107,101,47,112,114,111,99,47,104,101,108,112,101,114,32,115,112,101,99,52,52,49,32,97,114,103,118,52,52,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,47,112,114,111,99,32,103,53,56,54,53,56,55,53,57,50,32,46,32,114,118,97,114,53,56,56,53,57,51,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,97,116,105,111,110,45,112,114,101,102,105,120,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,13),40,118,101,114,98,32,100,105,114,54,53,55,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,15),40,102,95,53,57,48,57,32,100,105,114,54,54,52,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,15),40,102,95,53,57,49,55,32,100,105,114,54,54,54,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,51,50,56,48,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,51,50,56,57,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,119,114,105,116,101,45,105,110,102,111,32,105,100,54,55,52,32,102,105,108,101,115,54,55,53,32,105,110,102,111,54,55,54,41,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,19),40,98,111,100,121,55,50,55,32,112,114,101,102,105,120,55,51,54,41,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,112,114,101,102,105,120,55,51,48,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,101,114,114,55,50,57,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,47),40,115,101,116,117,112,45,97,112,105,35,99,111,112,121,45,102,105,108,101,32,102,114,111,109,55,50,50,32,116,111,55,50,51,32,46,32,116,109,112,55,50,49,55,50,52,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,109,111,118,101,45,102,105,108,101,32,102,114,111,109,55,53,54,32,116,111,55,53,55,41,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,31),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,102,105,108,101,42,32,100,105,114,55,54,54,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,109,97,107,101,45,100,101,115,116,45,112,97,116,104,110,97,109,101,32,112,97,116,104,55,55,50,32,102,105,108,101,55,55,51,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,55,55,55,32,103,55,56,55,55,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,35),40,115,101,116,117,112,45,97,112,105,35,99,104,101,99,107,45,102,105,108,101,108,105,115,116,32,102,108,105,115,116,55,55,52,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,45),40,115,101,116,117,112,45,97,112,105,35,115,117,112,112,108,121,45,118,101,114,115,105,111,110,32,105,110,102,111,56,50,57,32,118,101,114,115,105,111,110,56,51,48,41,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,7),40,97,51,57,57,51,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,51,57,57,54,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,61),40,115,101,116,117,112,45,97,112,105,35,115,116,97,110,100,97,114,100,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,56,52,48,32,118,101,114,115,105,111,110,56,52,49,32,46,32,116,109,112,56,51,57,56,52,50,41,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,11),40,103,57,49,54,32,102,57,49,56,41,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,48,48,32,103,57,49,48,57,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,56),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,101,120,116,101,110,115,105,111,110,32,105,100,56,56,56,32,102,105,108,101,115,56,56,57,32,46,32,116,109,112,56,56,55,56,57,48,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,12),40,101,120,105,102,121,32,102,57,54,48,41,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,13),40,103,49,48,48,56,32,102,49,48,49,48,41,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,19),40,108,111,111,112,57,57,50,32,103,49,48,48,50,49,48,48,54,41,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,11),40,103,57,56,51,32,102,57,56,53,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,57,54,55,32,103,57,55,55,57,56,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,54),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,112,114,111,103,114,97,109,32,105,100,57,53,51,32,102,105,108,101,115,57,53,52,32,46,32,116,109,112,57,53,50,57,53,53,41,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,13),40,103,49,48,53,56,32,102,49,48,54,48,41,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,48,52,50,32,103,49,48,53,50,49,48,53,54,41,0,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,97,112,105,35,105,110,115,116,97,108,108,45,115,99,114,105,112,116,32,105,100,49,48,51,48,32,102,105,108,101,115,49,48,51,49,32,46,32,116,109,112,49,48,50,57,49,48,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,33),40,115,101,116,117,112,45,97,112,105,35,114,101,112,111,45,112,97,116,104,32,116,109,112,49,48,56,52,49,48,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,37),40,115,101,116,117,112,45,97,112,105,35,101,110,115,117,114,101,45,100,105,114,101,99,116,111,114,121,32,112,97,116,104,49,48,57,57,41,0,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,48,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,97,52,55,57,52,32,101,120,49,49,51,51,49,49,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,57,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,7),40,97,52,56,52,49,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,22),40,97,52,56,51,53,32,46,32,97,114,103,115,49,49,51,53,49,49,52,56,41,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,97,52,56,48,51,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,17),40,97,52,55,56,56,32,107,49,49,51,52,49,49,51,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,7),40,97,52,56,56,54,41,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,52,56,57,50,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,7),40,97,52,56,57,53,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,7),40,97,52,57,48,49,41,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,7),40,97,52,57,48,52,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,7),40,97,52,57,48,55,41,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,97,112,105,35,116,114,121,45,99,111,109,112,105,108,101,32,99,111,100,101,49,49,49,52,32,46,32,116,109,112,49,49,49,51,49,49,49,53,41,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,99,104,105,99,107,101,110,45,118,101,114,115,105,111,110,32,118,49,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,55),40,115,101,116,117,112,45,97,112,105,35,117,112,103,114,97,100,101,45,109,101,115,115,97,103,101,32,101,120,116,49,49,54,54,32,109,115,103,49,49,54,55,32,116,109,112,49,49,54,53,49,49,54,56,41,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,15),40,108,111,111,112,32,97,114,103,115,49,49,57,50,41,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,49),40,115,101,116,117,112,45,97,112,105,35,114,101,113,117,105,114,101,100,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,97,114,103,115,49,49,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,42),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,108,105,98,114,97,114,121,32,110,97,109,101,49,50,49,54,32,112,114,111,99,49,50,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,102,105,110,100,45,104,101,97,100,101,114,32,110,97,109,101,49,50,51,55,41};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,50,53,50,32,103,49,50,54,50,49,50,54,54,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,21),40,118,101,114,115,105,111,110,45,62,108,105,115,116,32,118,49,50,52,57,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,32,112,49,49,50,55,56,32,112,50,49,50,55,57,41,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,36),40,115,101,116,117,112,45,97,112,105,35,118,101,114,115,105,111,110,62,61,63,32,118,49,49,50,52,54,32,118,50,49,50,52,55,41,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,26),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,110,97,109,101,41,0,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,32,46,32,116,109,112,49,51,50,49,49,51,50,50,41,0,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,43),40,115,101,116,117,112,45,97,112,105,35,114,101,97,100,45,105,110,102,111,32,101,103,103,49,51,51,52,32,46,32,116,109,112,49,51,51,51,49,51,51,53,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,7),40,97,53,53,53,55,41,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,18),40,97,53,53,53,49,32,101,120,49,51,53,52,49,51,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,7),40,97,53,53,54,54,41,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,7),40,97,53,53,57,53,41,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,22),40,97,53,53,56,57,32,46,32,97,114,103,115,49,51,53,54,49,51,54,56,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,7),40,97,53,53,54,48,41,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,17),40,97,53,53,52,53,32,107,49,51,53,53,49,51,53,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,13),40,103,49,51,56,49,32,102,49,51,56,51,41,0,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,51,55,52,32,103,49,51,55,56,49,51,56,48,41,0,0,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,14),40,119,97,108,107,32,100,105,114,49,51,55,48,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,49,51,52,53,32,46,32,116,109,112,49,51,52,52,49,51,52,54,41,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,20),40,108,111,111,112,49,52,48,54,32,103,49,52,49,48,49,52,49,50,41,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,50),40,115,101,116,117,112,45,97,112,105,35,114,101,109,111,118,101,45,101,120,116,101,110,115,105,111,110,32,101,103,103,49,51,57,56,32,46,32,116,109,112,49,51,57,55,49,51,57,57,41,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,27),40,115,101,116,117,112,45,97,112,105,35,36,115,121,115,116,101,109,32,115,116,114,49,52,49,56,41,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,13),40,97,53,56,50,50,32,99,49,52,51,50,41,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,32),40,115,101,116,117,112,45,97,112,105,35,115,101,116,117,112,45,101,114,114,111,114,45,104,97,110,100,108,105,110,103,41};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,21),40,101,110,115,117,114,101,45,115,116,114,105,110,103,32,120,49,51,49,49,41,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,13),40,97,53,56,51,56,32,120,49,51,48,48,41,0,0,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,7),40,97,53,57,55,51,41,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1545)
static void C_ccall f_1545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_ccall f_1572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1596)
static void C_ccall f_1596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5997)
static void C_ccall f_5997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1610)
static void C_ccall f_1610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1620)
static void C_ccall f_1620(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1624)
static void C_ccall f_1624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1627)
static void C_ccall f_1627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1650)
static void C_ccall f_1650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1654)
static void C_ccall f_1654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5974)
static void C_ccall f_5974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5972)
static void C_ccall f_5972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5964)
static void C_ccall f_5964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2017)
static void C_ccall f_2017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2023)
static void C_ccall f_2023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_ccall f_5952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5948)
static void C_ccall f_5948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5839)
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5855)
static void C_fcall f_5855(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5892)
static void C_ccall f_5892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5885)
static void C_ccall f_5885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5889)
static void C_ccall f_5889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_fcall f_5862(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5428)
static void C_ccall f_5428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5837)
static void C_ccall f_5837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5827)
static void C_ccall f_5827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_fcall f_5767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5812)
static void C_ccall f_5812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5771)
static void C_ccall f_5771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_ccall f_5784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5787)
static void C_ccall f_5787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5790)
static void C_ccall f_5790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5793)
static void C_ccall f_5793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5796)
static void C_ccall f_5796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5799)
static void C_ccall f_5799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5802)
static void C_ccall f_5802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5805)
static void C_ccall f_5805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5808)
static void C_ccall f_5808(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_fcall f_5718(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5728)
static void C_ccall f_5728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5523)
static void C_ccall f_5523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5671)
static void C_ccall f_5671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5605)
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5609)
static void C_ccall f_5609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5617)
static void C_fcall f_5617(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5656)
static void C_ccall f_5656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_fcall f_5625(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5638)
static void C_ccall f_5638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5644)
static void C_ccall f_5644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5612)
static void C_ccall f_5612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5546)
static void C_ccall f_5546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5561)
static void C_ccall f_5561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5567)
static void C_ccall f_5567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_ccall f_5578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5588)
static void C_ccall f_5588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5552)
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5484)
static void C_ccall f_5484r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5488)
static void C_ccall f_5488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5444)
static void C_ccall f_5444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5463)
static void C_ccall f_5463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5453)
static void C_ccall f_5453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5438)
static void C_ccall f_5438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5229)
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5294)
static void C_ccall f_5294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5300)
static void C_fcall f_5300(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5380)
static void C_ccall f_5380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5232)
static void C_fcall f_5232(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_ccall f_5287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5252)
static void C_fcall f_5252(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5207)
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5215)
static void C_ccall f_5215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5221)
static void C_ccall f_5221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5224)
static void C_ccall f_5224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5227)
static void C_ccall f_5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5156)
static void C_ccall f_5156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5162)
static void C_ccall f_5162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5165)
static void C_ccall f_5165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5168)
static void C_ccall f_5168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5171)
static void C_ccall f_5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5174)
static void C_ccall f_5174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5177)
static void C_ccall f_5177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5183)
static void C_ccall f_5183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5189)
static void C_ccall f_5189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5195)
static void C_ccall f_5195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5198)
static void C_ccall f_5198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5201)
static void C_ccall f_5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5027)
static void C_ccall f_5027r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5033)
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5046)
static void C_fcall f_5046(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_fcall f_5064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5104)
static void C_ccall f_5104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5115)
static void C_ccall f_5115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_fcall f_5079(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5086)
static void C_ccall f_5086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5092)
static void C_ccall f_5092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5095)
static void C_ccall f_5095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5098)
static void C_ccall f_5098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4946)
static void C_fcall f_4946(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_ccall f_4957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_ccall f_4963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4969)
static void C_ccall f_4969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4972)
static void C_ccall f_4972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4975)
static void C_ccall f_4975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4984)
static void C_ccall f_4984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5003)
static void C_ccall f_5003(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4987)
static void C_ccall f_4987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4990)
static void C_ccall f_4990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4993)
static void C_ccall f_4993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4996)
static void C_ccall f_4996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4914)
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4921)
static void C_ccall f_4921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4928)
static void C_ccall f_4928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4931)
static void C_ccall f_4931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4937)
static void C_ccall f_4937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4940)
static void C_ccall f_4940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4744)
static void C_ccall f_4744r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4751)
static void C_ccall f_4751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4905)
static void C_ccall f_4905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4754)
static void C_ccall f_4754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_ccall f_4902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4757)
static void C_ccall f_4757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4763)
static void C_ccall f_4763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4766)
static void C_ccall f_4766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4887)
static void C_ccall f_4887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4772)
static void C_ccall f_4772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4860)
static void C_ccall f_4860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4863)
static void C_ccall f_4863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_ccall f_4775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4778)
static void C_ccall f_4778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4789)
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4804)
static void C_ccall f_4804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4842)
static void C_ccall f_4842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4818)
static void C_ccall f_4818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4821)
static void C_ccall f_4821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4824)
static void C_ccall f_4824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_ccall f_4834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4827)
static void C_ccall f_4827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4830)
static void C_ccall f_4830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4795)
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4801)
static void C_ccall f_4801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_fcall f_4691(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4695)
static void C_ccall f_4695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4704)
static void C_ccall f_4704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4742)
static void C_ccall f_4742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4710)
static void C_ccall f_4710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4619)
static void C_fcall f_4619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4623)
static void C_ccall f_4623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4635)
static void C_ccall f_4635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4641)
static void C_ccall f_4641(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4651)
static void C_ccall f_4651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4660)
static void C_ccall f_4660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4626)
static void C_ccall f_4626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4629)
static void C_ccall f_4629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4455)
static void C_ccall f_4455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_ccall f_4461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4464)
static void C_ccall f_4464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4467)
static void C_ccall f_4467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4588)
static void C_ccall f_4588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4580)
static void C_ccall f_4580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_fcall f_4535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4542)
static void C_ccall f_4542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_ccall f_4545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4571)
static void C_ccall f_4571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4548)
static void C_ccall f_4548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4473)
static void C_ccall f_4473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4506)
static void C_ccall f_4506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4476)
static void C_ccall f_4476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4228)
static void C_ccall f_4228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4251)
static void C_ccall f_4251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4254)
static void C_ccall f_4254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4420)
static void C_ccall f_4420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4257)
static void C_ccall f_4257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4353)
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4380)
static void C_fcall f_4380(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4394)
static void C_ccall f_4394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4260)
static void C_ccall f_4260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_fcall f_4272(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4344)
static void C_ccall f_4344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4306)
static void C_ccall f_4306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4309)
static void C_ccall f_4309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4335)
static void C_ccall f_4335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4263)
static void C_ccall f_4263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4270)
static void C_ccall f_4270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_fcall f_4234(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3669)
static void C_ccall f_3669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4000)
static void C_ccall f_4000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4058)
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4065)
static void C_ccall f_4065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4155)
static void C_fcall f_4155(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_ccall f_4174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4068)
static void C_ccall f_4068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4074)
static void C_ccall f_4074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_fcall f_4086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4080)
static void C_ccall f_4080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4022)
static void C_ccall f_4022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_ccall f_4029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3777)
static void C_ccall f_3777r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3997)
static void C_ccall f_3997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3781)
static void C_ccall f_3781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3994)
static void C_ccall f_3994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3796)
static void C_ccall f_3796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3802)
static void C_ccall f_3802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3866)
static void C_ccall f_3866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3859)
static void C_ccall f_3859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3824)
static void C_ccall f_3824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_fcall f_3753(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3725)
static void C_ccall f_3725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3581)
static void C_fcall f_3581(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3587)
static void C_fcall f_3587(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3627)
static void C_ccall f_3627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3630)
static void C_fcall f_3630(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3597)
static void C_fcall f_3597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3556)
static void C_fcall f_3556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3534)
static void C_ccall f_3534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3479)
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3508)
static void C_ccall f_3508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3417)
static void C_fcall f_3417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_fcall f_3408(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3342)
static void C_ccall f_3342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3477)
static void C_ccall f_3477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3345)
static void C_ccall f_3345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3367)
static void C_ccall f_3367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3351)
static void C_ccall f_3351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3204)
static void C_fcall f_3204(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3211)
static void C_ccall f_3211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3249)
static void C_ccall f_3249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3279)
static void C_ccall f_3279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5917)
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5921)
static void C_ccall f_5921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5944)
static void C_ccall f_5944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5909)
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_fcall f_3180(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3187)
static void C_ccall f_3187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3190)
static void C_ccall f_3190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3171)
static void C_ccall f_3171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2665)
static void C_fcall f_2665(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2669)
static void C_fcall f_2669(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2497)
static void C_ccall f_2497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2511)
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2533)
static void C_ccall f_2533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2572)
static void C_ccall f_2572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2542)
static void C_ccall f_2542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2657)
static void C_ccall f_2657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2675)
static void C_ccall f_2675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3051)
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_fcall f_3059(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2980)
static void C_ccall f_2980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2986)
static void C_ccall f_2986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2993)
static void C_ccall f_2993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2995)
static void C_fcall f_2995(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3007)
static void C_ccall f_3007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3010)
static void C_ccall f_3010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3016)
static void C_ccall f_3016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2392)
static void C_fcall f_2392(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2405)
static void C_fcall f_2405(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2411)
static void C_ccall f_2411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2693)
static void C_ccall f_2693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2974)
static void C_ccall f_2974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2962)
static void C_ccall f_2962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2968)
static void C_ccall f_2968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2699)
static void C_ccall f_2699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2944)
static void C_ccall f_2944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2929)
static void C_ccall f_2929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2708)
static void C_ccall f_2708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2883)
static void C_ccall f_2883(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2887)
static void C_ccall f_2887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2910)
static void C_ccall f_2910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2916)
static void C_ccall f_2916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_ccall f_2919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2922)
static void C_ccall f_2922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2925)
static void C_ccall f_2925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_ccall f_2890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2900)
static void C_ccall f_2900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_ccall f_2816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2819)
static void C_ccall f_2819(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2822)
static void C_ccall f_2822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2825)
static void C_ccall f_2825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2828)
static void C_ccall f_2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2733)
static void C_ccall f_2733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2741)
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2788)
static void C_ccall f_2788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2753)
static void C_ccall f_2753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_ccall f_2760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2763)
static void C_ccall f_2763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2779)
static void C_ccall f_2779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2776)
static void C_ccall f_2776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2736)
static void C_ccall f_2736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2459)
static void C_fcall f_2459(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2473)
static void C_ccall f_2473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2482)
static void C_ccall f_2482(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2485)
static void C_ccall f_2485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2437)
static void C_fcall f_2437(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2445)
static void C_ccall f_2445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2346)
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2258)
static void C_fcall f_2258(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2049)
static void C_ccall f_2049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2188)
static void C_ccall f_2188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2195)
static void C_ccall f_2195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2129)
static void C_ccall f_2129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_fcall f_2131(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2169)
static void C_ccall f_2169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2083)
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2118)
static void C_ccall f_2118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2375)
static void C_ccall f_2375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2300)
static void C_fcall f_2300(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_ccall f_2321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2204)
static void C_fcall f_2204(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2211)
static void C_fcall f_2211(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_fcall f_2000(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2008)
static void C_ccall f_2008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1985)
static void C_ccall f_1985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1963)
static void C_ccall f_1963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1945)
static void C_ccall f_1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1953)
static void C_ccall f_1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1923)
static void C_ccall f_1923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1926)
static void C_ccall f_1926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1929)
static void C_ccall f_1929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1932)
static void C_ccall f_1932(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1826)
static void C_ccall f_1826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1912)
static void C_ccall f_1912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1841)
static void C_ccall f_1841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_fcall f_1857(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1797)
static void C_ccall f_1797r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1771)
static void C_fcall f_1771(C_word t0) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1710)
static void C_ccall f_1710(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1678)
static void C_ccall f_1678(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1629)
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5855)
static void C_fcall trf_5855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5855(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5855(t0,t1);}

C_noret_decl(trf_5862)
static void C_fcall trf_5862(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5862(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5862(t0,t1);}

C_noret_decl(trf_5767)
static void C_fcall trf_5767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5767(t0,t1);}

C_noret_decl(trf_5718)
static void C_fcall trf_5718(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5718(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5718(t0,t1,t2);}

C_noret_decl(trf_5605)
static void C_fcall trf_5605(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5605(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5605(t0,t1,t2);}

C_noret_decl(trf_5617)
static void C_fcall trf_5617(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5617(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5617(t0,t1,t2);}

C_noret_decl(trf_5625)
static void C_fcall trf_5625(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5625(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5625(t0,t1,t2);}

C_noret_decl(trf_5300)
static void C_fcall trf_5300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5300(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5300(t0,t1,t2,t3);}

C_noret_decl(trf_5232)
static void C_fcall trf_5232(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5232(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5232(t0,t1);}

C_noret_decl(trf_5242)
static void C_fcall trf_5242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5242(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5242(t0,t1,t2);}

C_noret_decl(trf_5252)
static void C_fcall trf_5252(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5252(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5252(t0,t1);}

C_noret_decl(trf_5033)
static void C_fcall trf_5033(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5033(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5033(t0,t1,t2);}

C_noret_decl(trf_5046)
static void C_fcall trf_5046(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5046(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5046(t0,t1);}

C_noret_decl(trf_5064)
static void C_fcall trf_5064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5064(t0,t1);}

C_noret_decl(trf_5079)
static void C_fcall trf_5079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5079(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5079(t0,t1);}

C_noret_decl(trf_4946)
static void C_fcall trf_4946(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4946(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4946(t0,t1,t2,t3);}

C_noret_decl(trf_4691)
static void C_fcall trf_4691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4691(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4691(t0,t1);}

C_noret_decl(trf_4619)
static void C_fcall trf_4619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4619(t0,t1);}

C_noret_decl(trf_4508)
static void C_fcall trf_4508(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4508(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4508(t0,t1,t2);}

C_noret_decl(trf_4535)
static void C_fcall trf_4535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4535(t0,t1,t2);}

C_noret_decl(trf_4353)
static void C_fcall trf_4353(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4353(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4353(t0,t1,t2);}

C_noret_decl(trf_4380)
static void C_fcall trf_4380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4380(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4380(t0,t1,t2);}

C_noret_decl(trf_4272)
static void C_fcall trf_4272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4272(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4272(t0,t1,t2);}

C_noret_decl(trf_4299)
static void C_fcall trf_4299(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4299(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4299(t0,t1,t2);}

C_noret_decl(trf_4234)
static void C_fcall trf_4234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4234(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4234(t0,t1);}

C_noret_decl(trf_4031)
static void C_fcall trf_4031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4031(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4031(t0,t1,t2);}

C_noret_decl(trf_4058)
static void C_fcall trf_4058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4058(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4058(t0,t1,t2);}

C_noret_decl(trf_4155)
static void C_fcall trf_4155(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4155(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4155(t0,t1);}

C_noret_decl(trf_4086)
static void C_fcall trf_4086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4086(t0,t1);}

C_noret_decl(trf_3753)
static void C_fcall trf_3753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3753(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3753(t0,t1,t2);}

C_noret_decl(trf_3581)
static void C_fcall trf_3581(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3581(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3581(t0,t1);}

C_noret_decl(trf_3587)
static void C_fcall trf_3587(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3587(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3587(t0,t1,t2);}

C_noret_decl(trf_3630)
static void C_fcall trf_3630(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3630(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3630(t0,t1);}

C_noret_decl(trf_3597)
static void C_fcall trf_3597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3597(t0,t1);}

C_noret_decl(trf_3556)
static void C_fcall trf_3556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3556(t0,t1,t2);}

C_noret_decl(trf_3417)
static void C_fcall trf_3417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3417(t0,t1);}

C_noret_decl(trf_3408)
static void C_fcall trf_3408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3408(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3408(t0,t1);}

C_noret_decl(trf_3335)
static void C_fcall trf_3335(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3335(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3335(t0,t1,t2);}

C_noret_decl(trf_3204)
static void C_fcall trf_3204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3204(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3204(t0,t1,t2,t3);}

C_noret_decl(trf_3180)
static void C_fcall trf_3180(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3180(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3180(t0,t1);}

C_noret_decl(trf_2665)
static void C_fcall trf_2665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2665(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2665(t0,t1,t2);}

C_noret_decl(trf_2669)
static void C_fcall trf_2669(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2669(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2669(t0,t1);}

C_noret_decl(trf_3051)
static void C_fcall trf_3051(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3051(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3051(t0,t1,t2);}

C_noret_decl(trf_3059)
static void C_fcall trf_3059(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3059(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3059(t0,t1,t2);}

C_noret_decl(trf_2995)
static void C_fcall trf_2995(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2995(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2995(t0,t1,t2);}

C_noret_decl(trf_2392)
static void C_fcall trf_2392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2392(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2392(t0,t1,t2);}

C_noret_decl(trf_2405)
static void C_fcall trf_2405(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2405(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2405(t0,t1);}

C_noret_decl(trf_2459)
static void C_fcall trf_2459(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2459(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2459(t0,t1,t2,t3);}

C_noret_decl(trf_2437)
static void C_fcall trf_2437(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2437(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2437(t0,t1,t2);}

C_noret_decl(trf_2346)
static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2346(t0,t1,t2);}

C_noret_decl(trf_2258)
static void C_fcall trf_2258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2258(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2258(t0,t1,t2);}

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2053(t0,t1);}

C_noret_decl(trf_2131)
static void C_fcall trf_2131(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2131(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2131(t0,t1,t2);}

C_noret_decl(trf_2083)
static void C_fcall trf_2083(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2083(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2083(t0,t1,t2);}

C_noret_decl(trf_2300)
static void C_fcall trf_2300(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2300(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2300(t0,t1,t2);}

C_noret_decl(trf_2204)
static void C_fcall trf_2204(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2204(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2204(t0,t1);}

C_noret_decl(trf_2211)
static void C_fcall trf_2211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2211(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2211(t0,t1);}

C_noret_decl(trf_2000)
static void C_fcall trf_2000(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2000(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2000(t0,t1,t2);}

C_noret_decl(trf_1857)
static void C_fcall trf_1857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1857(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1857(t0,t1);}

C_noret_decl(trf_1771)
static void C_fcall trf_1771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1771(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_1771(t0);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1542)){
C_save(t1);
C_rereclaim2(1542*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,353);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[13]=C_h_intern(&lf[13],24,"setup-api#host-extension");
lf[15]=C_h_intern(&lf[15],24,"setup-api#chicken-prefix");
lf[16]=C_h_intern(&lf[16],19,"setup-api#shellpath");
lf[17]=C_h_intern(&lf[17],2,"qs");
lf[18]=C_h_intern(&lf[18],18,"normalize-pathname");
lf[20]=C_h_intern(&lf[20],30,"setup-api#setup-root-directory");
lf[21]=C_h_intern(&lf[21],28,"setup-api#setup-verbose-mode");
lf[22]=C_h_intern(&lf[22],28,"setup-api#setup-install-mode");
lf[23]=C_h_intern(&lf[23],25,"setup-api#deployment-mode");
lf[24]=C_h_intern(&lf[24],22,"setup-api#program-path");
lf[25]=C_h_intern(&lf[25],28,"setup-api#keep-intermediates");
lf[26]=C_h_intern(&lf[26],24,"setup-api#extra-features");
lf[27]=C_h_intern(&lf[27],17,"register-feature!");
lf[28]=C_h_intern(&lf[28],9,"\003syserror");
lf[29]=C_h_intern(&lf[29],27,"setup-api#extra-nonfeatures");
lf[30]=C_h_intern(&lf[30],19,"unregister-feature!");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\011del /Q /S");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\006rm -fr");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\005chmod");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\006ranlib");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\005mkdir");
lf[49]=C_h_intern(&lf[49],22,"setup-api#sudo-install");
lf[50]=C_h_intern(&lf[50],5,"print");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: cannot install as superuser with Windows");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo cp -r");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo rm -fr");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\007sudo mv");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo chmod");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\013sudo ranlib");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\012sudo mkdir");
lf[58]=C_h_intern(&lf[58],21,"setup-api#abort-setup");
lf[59]=C_h_intern(&lf[59],15,"setup-api#patch");
lf[60]=C_h_intern(&lf[60],10,"write-line");
lf[61]=C_h_intern(&lf[61],17,"string-substitute");
lf[62]=C_h_intern(&lf[62],9,"read-line");
lf[63]=C_h_intern(&lf[63],20,"with-input-from-file");
lf[64]=C_h_intern(&lf[64],19,"with-output-to-file");
lf[66]=C_h_intern(&lf[66],17,"get-output-string");
lf[67]=C_h_intern(&lf[67],7,"display");
lf[68]=C_h_intern(&lf[68],19,"\003syswrite-char/port");
lf[69]=C_h_intern(&lf[69],18,"open-output-string");
lf[70]=C_h_intern(&lf[70],21,"create-temporary-file");
lf[71]=C_h_intern(&lf[71],19,"\003sysstandard-output");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\011patching ");
lf[74]=C_h_intern(&lf[74],21,"setup-api#run-verbose");
lf[75]=C_h_intern(&lf[75],26,"setup-api#register-program");
lf[76]=C_h_intern(&lf[76],10,"alist-cons");
lf[77]=C_h_intern(&lf[77],8,"->string");
lf[78]=C_h_intern(&lf[78],13,"make-pathname");
lf[79]=C_h_intern(&lf[79],22,"setup-api#find-program");
lf[81]=C_h_intern(&lf[81],26,"pathname-replace-extension");
lf[82]=C_h_intern(&lf[82],26,"\003sysload-dynamic-extension");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[85]=C_h_intern(&lf[85],18,"pathname-extension");
lf[86]=C_h_intern(&lf[86],17,"setup-api#execute");
lf[87]=C_h_intern(&lf[87],16,"\003sysflush-output");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[89]=C_h_intern(&lf[89],18,"string-intersperse");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\011-deployed");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[99]=C_h_intern(&lf[99],5,"cons*");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\023compiling-extension");
lf[102]=C_h_intern(&lf[102],6,"append");
lf[103]=C_h_intern(&lf[103],13,"string-append");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-feature ");
lf[105]=C_h_intern(&lf[105],14,"symbol->string");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\011-feature ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[109]=C_h_intern(&lf[109],8,"feature\077");
lf[110]=C_h_intern(&lf[110],14,"\000cross-chicken");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[113]=C_h_intern(&lf[113],5,"error");
lf[114]=C_h_intern(&lf[114],5,"write");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\013 for line: ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[120]=C_h_intern(&lf[120],6,"signal");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\025make: Failed to make ");
lf[123]=C_h_intern(&lf[123],22,"with-exception-handler");
lf[124]=C_h_intern(&lf[124],30,"call-with-current-continuation");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\010 changed");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\007 date: ");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\027 just because (reason: ");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\011 because ");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\017 does not exist");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\007making ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[133]=C_h_intern(&lf[133],22,"file-modification-time");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\015 was not made");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\022(make) dependency ");
lf[136]=C_h_intern(&lf[136],12,"file-exists\077");
lf[137]=C_h_intern(&lf[137],3,"any");
lf[138]=C_h_intern(&lf[138],12,"\003sysfor-each");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\036(make) don\047t know how to make ");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\011checking ");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\006make: ");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\013make: made ");
lf[144]=C_h_intern(&lf[144],7,"reverse");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[147]=C_h_intern(&lf[147],4,"caar");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[149]=C_h_intern(&lf[149],27,"condition-property-accessor");
lf[150]=C_h_intern(&lf[150],3,"exn");
lf[151]=C_h_intern(&lf[151],7,"message");
lf[152]=C_h_intern(&lf[152],19,"condition-predicate");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\0006argument-list to `make\047 is not a string or string list");
lf[154]=C_h_intern(&lf[154],5,"every");
lf[155]=C_h_intern(&lf[155],7,"string\077");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000#command part of line is not a thunk");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\037dependency item is not a string");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000!second part of line is not a list");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\0004line does not start with a string or list of strings");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000$list is not a list with 2 or 3 parts");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\036specification is an empty list");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\033specification is not a list");
lf[163]=C_h_intern(&lf[163],12,"vector->list");
lf[164]=C_h_intern(&lf[164],19,"setup-api#make/proc");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\0000no matching clause in call to \047case-lambda\047 form");
lf[166]=C_h_intern(&lf[166],28,"setup-api#destination-prefix");
lf[167]=C_h_intern(&lf[167],29,"setup-api#installation-prefix");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\010  mkdir ");
lf[169]=C_h_intern(&lf[169],16,"create-directory");
lf[170]=C_h_intern(&lf[170],2,"-p");
lf[171]=C_h_intern(&lf[171],34,"setup-api#create-directory/parents");
lf[173]=C_h_intern(&lf[173],5,"files");
lf[174]=C_h_intern(&lf[174],3,"a+r");
lf[175]=C_h_intern(&lf[175],2,"pp");
lf[176]=C_h_intern(&lf[176],15,"repository-path");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\015writing info ");
lf[181]=C_h_intern(&lf[181],10,"\003sysappend");
lf[182]=C_h_intern(&lf[182],19,"setup-api#copy-file");
lf[184]=C_h_intern(&lf[184],18,"absolute-pathname\077");
lf[185]=C_h_intern(&lf[185],14,"string-prefix\077");
lf[186]=C_h_intern(&lf[186],19,"setup-api#move-file");
lf[187]=C_h_intern(&lf[187],22,"setup-api#remove-file*");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid file-specification");
lf[192]=C_h_intern(&lf[192],7,"version");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\007unknown");
lf[195]=C_h_intern(&lf[195],36,"setup-api#extension-name-and-version");
lf[196]=C_h_intern(&lf[196],28,"setup-api#standard-extension");
lf[197]=C_h_intern(&lf[197],27,"setup-api#install-extension");
lf[198]=C_h_intern(&lf[198],6,"static");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[202]=C_h_intern(&lf[202],12,"-debug-level");
lf[203]=C_h_intern(&lf[203],15,"-optimize-level");
lf[204]=C_h_intern(&lf[204],8,"-dynamic");
lf[205]=C_h_intern(&lf[205],3,"csc");
lf[206]=C_h_intern(&lf[206],5,"-unit");
lf[207]=C_h_intern(&lf[207],20,"-emit-import-library");
lf[208]=C_h_intern(&lf[208],2,"-c");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\006inline");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\012import.scm");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\003scm");
lf[212]=C_h_intern(&lf[212],15,"\003sysget-keyword");
lf[213]=C_h_intern(&lf[213],5,"\000info");
lf[214]=C_h_intern(&lf[214],7,"\000static");
lf[215]=C_h_intern(&lf[215],6,"macosx");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[217]=C_h_intern(&lf[217],16,"software-version");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[219]=C_h_intern(&lf[219],25,"setup-api#install-program");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[226]=C_h_intern(&lf[226],24,"setup-api#install-script");
lf[227]=C_h_intern(&lf[227],4,"a+rx");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\014lib/chicken/");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\000Acannot create directory: a file with the same name already exists");
lf[232]=C_h_intern(&lf[232],10,"directory\077");
lf[233]=C_h_intern(&lf[233],3,"a+x");
lf[234]=C_h_intern(&lf[234],18,"pathname-directory");
lf[235]=C_h_intern(&lf[235],21,"setup-api#try-compile");
lf[236]=C_h_intern(&lf[236],4,"\000c++");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\012succeeded.");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\007failed.");
lf[239]=C_h_intern(&lf[239],6,"system");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\007 >nul: ");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\014 >/dev/null ");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\0042>&1");
lf[247]=C_h_intern(&lf[247],4,"conc");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\002-L");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[259]=C_h_intern(&lf[259],13,"\000compile-only");
lf[260]=C_h_intern(&lf[260],5,"\000verb");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[262]=C_h_intern(&lf[262],8,"\000ldflags");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[264]=C_h_intern(&lf[264],7,"\000cflags");
lf[265]=C_h_intern(&lf[265],3,"\000cc");
lf[266]=C_h_intern(&lf[266],34,"setup-api#required-chicken-version");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\026 or higher is required");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\020CHICKEN version ");
lf[269]=C_h_intern(&lf[269],20,"setup-api#version>=\077");
lf[270]=C_h_intern(&lf[270],15,"chicken-version");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000.and repeat the current installation operation.");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\022  chicken-install ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\015 - please run");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\002\047 ");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000#the currently installed extension `");
lf[279]=C_h_intern(&lf[279],36,"setup-api#required-extension-version");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000;, which is the minimum version that this extension requires");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\016is older than ");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000%has no associated version information");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\020is not installed");
lf[284]=C_h_intern(&lf[284],21,"extension-information");
lf[285]=C_h_intern(&lf[285],30,"required-extension-information");
lf[286]=C_decode_literal(C_heaptop,"\376B\000\000\023bad argument format");
lf[287]=C_h_intern(&lf[287],22,"setup-api#test-compile");
lf[288]=C_h_intern(&lf[288],22,"setup-api#find-library");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\017(); return 0; }");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\015int main() { ");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\003();");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\005char ");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\012extern \042C\042");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\022#ifdef __cplusplus");
lf[297]=C_h_intern(&lf[297],21,"setup-api#find-header");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\033>\012int main() { return 0; }\012");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\012#include <");
lf[300]=C_h_intern(&lf[300],19,"string-split-fields");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006[-\134._]");
lf[302]=C_h_intern(&lf[302],6,"\000infix");
lf[303]=C_h_intern(&lf[303],8,"string>\077");
lf[304]=C_h_intern(&lf[304],24,"setup-api#extension-name");
lf[305]=C_h_intern(&lf[305],27,"setup-api#extension-version");
lf[306]=C_h_intern(&lf[306],12,"string-null\077");
lf[307]=C_h_intern(&lf[307],19,"setup-api#read-info");
lf[308]=C_h_intern(&lf[308],4,"read");
lf[309]=C_h_intern(&lf[309],26,"setup-api#remove-directory");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\014sudo rm -fr ");
lf[311]=C_h_intern(&lf[311],16,"delete-directory");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[314]=C_h_intern(&lf[314],11,"delete-file");
lf[315]=C_h_intern(&lf[315],9,"directory");
lf[316]=C_h_intern(&lf[316],16,"remove-directory");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000#cannot remove - directory not found");
lf[318]=C_h_intern(&lf[318],26,"setup-api#remove-extension");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000.shell command failed with nonzero exit status ");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[323]=C_h_intern(&lf[323],30,"setup-api#setup-error-handling");
lf[324]=C_h_intern(&lf[324],5,"reset");
lf[325]=C_h_intern(&lf[325],19,"print-error-message");
lf[326]=C_h_intern(&lf[326],18,"current-error-port");
lf[327]=C_h_intern(&lf[327],25,"current-exception-handler");
lf[328]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[330]=C_h_intern(&lf[330],7,"warning");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\042invalid extension-name-and-version");
lf[332]=C_h_intern(&lf[332],14,"make-parameter");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\000\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[334]=C_h_intern(&lf[334],24,"get-environment-variable");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\026CHICKEN_INSTALL_PREFIX");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\013chicken-bug");
lf[337]=C_h_intern(&lf[337],17,"\003syspeek-c-string");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000\016chicken-status");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\021chicken-uninstall");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\017chicken-install");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\003csi");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[344]=C_h_intern(&lf[344],4,"exit");
lf[345]=C_h_intern(&lf[345],17,"current-directory");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[347]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[349]=C_h_intern(&lf[349],13,"chicken-setup");
lf[350]=C_h_intern(&lf[350],7,"windows");
lf[351]=C_h_intern(&lf[351],14,"build-platform");
lf[352]=C_h_intern(&lf[352],13,"software-type");
C_register_lf2(lf,353,create_ptable());
t2=C_mutate(&lf[0] /* (set! c53 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1545,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1543 */
static void C_ccall f_1545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1546 in k1543 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1549 in k1546 in k1543 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1566,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1572,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1575,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1575,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! setup-api#constant24 ...) */,lf[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! setup-api#*cc* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}

/* k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1584,2,t0,t1);}
t2=C_mutate(&lf[5] /* (set! setup-api#*cxx* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}

/* k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=C_mutate(&lf[6] /* (set! setup-api#*target-cflags* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}

/* k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=C_mutate(&lf[7] /* (set! setup-api#*target-libs* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1596,2,t0,t1);}
t2=C_mutate(&lf[8] /* (set! setup-api#*target-lib-home* ...) */,t1);
t3=lf[9] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[10] /* (set! setup-api#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t5=lf[11] /* setup-api#*registered-programs* */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5997,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
C_trace("software-type");
((C_proc2)C_retrieve_symbol_proc(lf[352]))(2,*((C_word*)lf[352]+1),t7);}

/* k5995 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(t1,lf[350]);
if(C_truep(t2)){
C_trace("build-platform");
((C_proc2)C_retrieve_symbol_proc(lf[351]))(2,*((C_word*)lf[351]+1),((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
f_1603(2,t3,C_SCHEME_FALSE);}}

/* k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=C_mutate(&lf[12] /* (set! setup-api#*windows* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("register-feature!");
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t3,lf[349]);}

/* k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1606,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1610,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t2,C_SCHEME_FALSE);}

/* k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1610,2,t0,t1);}
t2=C_mutate((C_word*)lf[13]+1 /* (set! setup-api#host-extension ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[334]))(3,*((C_word*)lf[334]+1),t3,lf[348]);}

/* k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t2,t1,lf[347]);}
else{
t3=t2;
f_1617(2,t3,C_SCHEME_FALSE);}}

/* k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1617,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1620,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1620(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1620(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1620,2,t0,t1);}
t2=C_mutate(&lf[14] /* (set! setup-api#*chicken-bin-path* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1624,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[334]))(3,*((C_word*)lf[334]+1),t3,lf[346]);}

/* k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1624,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1627,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1627(2,t3,t1);}
else{
C_trace("##sys#peek-c-string");
t3=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1627,2,t0,t1);}
t2=C_mutate((C_word*)lf[15]+1 /* (set! setup-api#chicken-prefix ...) */,t1);
t3=C_mutate((C_word*)lf[16]+1 /* (set! setup-api#shellpath ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1629,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("current-directory");
((C_proc2)C_retrieve_symbol_proc(lf[345]))(2,*((C_word*)lf[345]+1),t4);}

/* k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1642,2,t0,t1);}
t2=C_mutate(&lf[19] /* (set! setup-api#*base-directory* ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_retrieve2(lf[19],"setup-api#*base-directory*"));}

/* k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=C_mutate((C_word*)lf[20]+1 /* (set! setup-api#setup-root-directory ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1650,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_SCHEME_FALSE);}

/* k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1650,2,t0,t1);}
t2=C_mutate((C_word*)lf[21]+1 /* (set! setup-api#setup-verbose-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1654,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_SCHEME_TRUE);}

/* k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1654,2,t0,t1);}
t2=C_mutate((C_word*)lf[22]+1 /* (set! setup-api#setup-install-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1658,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_SCHEME_FALSE);}

/* k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1658,2,t0,t1);}
t2=C_mutate((C_word*)lf[23]+1 /* (set! setup-api#deployment-mode ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1662,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_retrieve2(lf[14],"setup-api#*chicken-bin-path*"));}

/* k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1662,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! setup-api#program-path ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t3,C_SCHEME_FALSE);}

/* k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=C_mutate((C_word*)lf[25]+1 /* (set! setup-api#keep-intermediates ...) */,t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_mutate((C_word*)lf[26]+1 /* (set! setup-api#extra-features ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1668,a[2]=t4,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[29]+1 /* (set! setup-api#extra-nonfeatures ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1700,a[2]=t7,a[3]=((C_word)li2),tmp=(C_word)a,a+=4,tmp));
t9=lf[31] /* setup-api#*copy-command* */ =C_SCHEME_UNDEFINED;;
t10=lf[32] /* setup-api#*remove-command* */ =C_SCHEME_UNDEFINED;;
t11=lf[33] /* setup-api#*move-command* */ =C_SCHEME_UNDEFINED;;
t12=lf[34] /* setup-api#*chmod-command* */ =C_SCHEME_UNDEFINED;;
t13=lf[35] /* setup-api#*ranlib-command* */ =C_SCHEME_UNDEFINED;;
t14=lf[36] /* setup-api#*mkdir-command* */ =C_SCHEME_UNDEFINED;;
t15=C_mutate(&lf[37] /* (set! setup-api#user-install-setup ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1771,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[49]+1 /* (set! setup-api#sudo-install ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1797,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5974,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t17,t18);}

/* a5973 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5974,2,t0,t1);}
t2=C_retrieve(lf[344]);
C_trace("g9697");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,C_fix(1));}

/* k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
t2=C_mutate((C_word*)lf[58]+1 /* (set! setup-api#abort-setup ...) */,t1);
t3=C_mutate((C_word*)lf[59]+1 /* (set! setup-api#patch ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1822,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t4,C_SCHEME_TRUE);}

/* k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1939,2,t0,t1);}
t2=C_mutate((C_word*)lf[74]+1 /* (set! setup-api#run-verbose ...) */,t1);
t3=C_mutate((C_word*)lf[75]+1 /* (set! setup-api#register-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[79]+1 /* (set! setup-api#find-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2011,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5972,a[2]=t6,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t8=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k5970 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[343],t1);}

/* k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5968,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k5966 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[342],t1);}

/* k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5964,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k5962 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[341],t1);}

/* k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5960,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_INSTALL_PROGRAM),C_fix(0));}

/* k5958 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[340],t1);}

/* k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2020,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2023,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5956,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_UNINSTALL_PROGRAM),C_fix(0));}

/* k5954 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[339],t1);}

/* k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5952,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_STATUS_PROGRAM),C_fix(0));}

/* k5950 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[338],t1);}

/* k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2026,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5948,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#peek-c-string");
t4=*((C_word*)lf[337]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CHICKEN_BUG_PROGRAM),C_fix(0));}

/* k5946 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reg164");
f_2000(((C_word*)t0)[2],lf[336],t1);}

/* k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2029,2,t0,t1);}
t2=C_mutate(&lf[80] /* (set! setup-api#fixmaketarget ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2204,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[86]+1 /* (set! setup-api#execute ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[112] /* (set! setup-api#make:form-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2437,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate(&lf[116] /* (set! setup-api#make:line-error ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2459,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate(&lf[119] /* (set! setup-api#make:make/proc/helper ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2665,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[164]+1 /* (set! setup-api#make/proc ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3086,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[332]))(3,*((C_word*)lf[332]+1),t8,C_SCHEME_FALSE);}

/* k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=C_mutate((C_word*)lf[166]+1 /* (set! setup-api#destination-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("get-environment-variable");
((C_proc3)C_retrieve_symbol_proc(lf[334]))(3,*((C_word*)lf[334]+1),t3,lf[335]);}

/* k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word ab[77],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=C_mutate((C_word*)lf[167]+1 /* (set! setup-api#installation-prefix ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3167,a[2]=t1,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[12],"setup-api#*windows*"))?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5909,a[2]=t3,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5917,a[2]=t3,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[171]+1 /* (set! setup-api#create-directory/parents ...) */,t4);
t6=C_mutate(&lf[172] /* (set! setup-api#write-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3204,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[182]+1 /* (set! setup-api#copy-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[186]+1 /* (set! setup-api#move-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3479,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[187]+1 /* (set! setup-api#remove-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3534,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate(&lf[188] /* (set! setup-api#make-dest-pathname ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3556,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate(&lf[189] /* (set! setup-api#check-filelist ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3581,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate(&lf[191] /* (set! setup-api#supply-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3753,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[196]+1 /* (set! setup-api#standard-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3777,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[197]+1 /* (set! setup-api#install-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4000,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[219]+1 /* (set! setup-api#install-program ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4228,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[226]+1 /* (set! setup-api#install-script ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4451,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate(&lf[177] /* (set! setup-api#repo-path ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4619,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate(&lf[183] /* (set! setup-api#ensure-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4691,a[2]=((C_word)li73),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[235]+1 /* (set! setup-api#try-compile ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4744,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[266]+1 /* (set! setup-api#required-chicken-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4914,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate(&lf[271] /* (set! setup-api#upgrade-message ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4946,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[279]+1 /* (set! setup-api#required-extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5027,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[287]+1 /* (set! setup-api#test-compile ...) */,C_retrieve(lf[235]));
t24=C_mutate((C_word*)lf[288]+1 /* (set! setup-api#find-library ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5148,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[297]+1 /* (set! setup-api#find-header ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5207,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[269]+1 /* (set! setup-api#version>=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5229,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5839,a[2]=((C_word)li118),tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc4)C_retrieve_symbol_proc(lf[332]))(4,*((C_word*)lf[332]+1),t27,lf[333],t28);}

/* a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5839(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5839,3,t0,t1,t2);}
t3=C_i_not(t2);
t4=(C_truep(t3)?t3:C_i_nullp(t2));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[328]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5855,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t6=C_i_length(t2);
t7=t5;
f_5855(t7,C_i_nequalp(C_fix(2),t6));}
else{
t6=t5;
f_5855(t6,C_SCHEME_FALSE);}}}

/* k5853 in a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5855(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5855,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5862,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5885,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("ensure-string1310");
f_5862(t5,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5892,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("warning");
((C_proc4)C_retrieve_symbol_proc(lf[330]))(4,*((C_word*)lf[330]+1),t2,lf[331],((C_word*)t0)[3]);}}

/* k5890 in k5853 in a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),((C_word*)t0)[2]);}

/* k5883 in k5853 in a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5889,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("ensure-string1310");
f_5862(t2,((C_word*)t0)[2]);}

/* k5887 in k5883 in k5853 in a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5889,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* ensure-string in k5853 in a5838 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5862(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5862,NULL,2,t1,t2);}
t3=C_i_not(t2);
if(C_truep(t3)){
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[329]);}
else{
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t1,t2);}}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[329]);}
else{
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t1,t2);}}}

/* k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5428,2,t0,t1);}
t2=C_mutate((C_word*)lf[195]+1 /* (set! setup-api#extension-name-and-version ...) */,t1);
t3=C_mutate((C_word*)lf[304]+1 /* (set! setup-api#extension-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5430,a[2]=((C_word)li98),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[305]+1 /* (set! setup-api#extension-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5440,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[307]+1 /* (set! setup-api#read-info ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5484,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[309]+1 /* (set! setup-api#remove-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5519,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[318]+1 /* (set! setup-api#remove-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate(&lf[65] /* (set! setup-api#$system ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5767,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[323]+1 /* (set! setup-api#setup-error-handling ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5817,a[2]=((C_word)li116),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#user-install-setup");
f_1771(t10);}

/* k5835 in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* setup-api#setup-error-handling in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5823,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp);
C_trace("current-exception-handler");
((C_proc3)C_retrieve_symbol_proc(lf[327]))(3,*((C_word*)lf[327]+1),t1,t2);}

/* a5822 in setup-api#setup-error-handling in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5823,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5827,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5834,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[326]))(2,*((C_word*)lf[326]+1),t4);}

/* k5832 in a5822 in setup-api#setup-error-handling in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("print-error-message");
((C_proc4)C_retrieve_symbol_proc(lf[325]))(4,*((C_word*)lf[325]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5825 in a5822 in setup-api#setup-error-handling in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reset");
((C_proc2)C_retrieve_symbol_proc(lf[324]))(2,*((C_word*)lf[324]+1),((C_word*)t0)[2]);}

/* setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5767(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5767,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5771,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5812,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[103]+1)))(5,*((C_word*)lf[103]+1),t4,lf[321],t2,lf[322]);}
else{
t5=t2;
C_trace("system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),t3,t5);}}

/* k5810 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[2],t1);}

/* k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5771,2,t0,t1);}
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5784,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}}

/* k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[320],t1);}

/* k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5790,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[3]);}

/* k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5794 in k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5799,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5797 in k5794 in k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[319],((C_word*)t0)[3]);}

/* k5800 in k5797 in k5794 in k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5805,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5803 in k5800 in k5797 in k5794 in k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5808,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k5806 in k5803 in k5800 in k5797 in k5794 in k5791 in k5788 in k5785 in k5782 in k5769 in setup-api#$system in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5808(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5692r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5692r(t0,t1,t2,t3);}}

static void C_ccall f_5692r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5696,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5696(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5743,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#read-info");
((C_proc4)C_retrieve_symbol_proc(lf[307]))(4,*((C_word*)lf[307]+1),t2,((C_word*)t0)[2],t1);}

/* k5741 in k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=C_i_assq(lf[173],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_cdr(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5718,a[2]=t6,a[3]=((C_word)li112),tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_5718(t8,t3,t4);}
else{
t4=t3;
f_5702(2,t4,C_SCHEME_FALSE);}}

/* loop1406 in k5741 in k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5718(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5718,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[187]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5728,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g14131414");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5726 in loop1406 in k5741 in k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5718(t3,((C_word*)t0)[2],t2);}

/* k5700 in k5741 in k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5709,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[2]);}

/* k5707 in k5700 in k5741 in k5694 in setup-api#remove-extension in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#remove-file*");
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),((C_word*)t0)[2],t1);}

/* setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5519r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5519r(t0,t1,t2,t3);}}

static void C_ccall f_5519r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5523,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_5523(2,t5,C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5523(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5671,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t2,((C_word*)t0)[2]);}

/* k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5671,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_retrieve2(lf[9],"setup-api#*sudo*"))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5541,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5546,a[2]=((C_word*)t0)[3],a[3]=((C_word)li107),tmp=(C_word)a,a+=4,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5605,a[2]=t3,a[3]=((C_word)li110),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5605(t5,((C_word*)t0)[4],((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)t0)[2])){
C_trace("error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[4],lf[316],lf[317],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5605(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5605,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5609,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("directory");
((C_proc4)C_retrieve_symbol_proc(lf[315]))(4,*((C_word*)lf[315]+1),t3,t2,C_SCHEME_TRUE);}

/* k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5609,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5612,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5617,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word)li109),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_5617(t6,t2,t1);}

/* loop1374 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5617(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5617,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li108),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5656,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g13811382");
t6=t3;
f_5625(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5654 in loop1374 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5617(t3,((C_word*)t0)[2],t2);}

/* g1381 in loop1374 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5625(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5625,NULL,3,t0,t1,t2);}
t3=C_i_string_equal_p(lf[312],t2);
t4=(C_truep(t3)?t3:C_i_string_equal_p(lf[313],t2));
if(C_truep(t4)){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5638,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t5,((C_word*)t0)[2],t2);}}

/* k5636 in g1381 in loop1374 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5638,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5644,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("directory?");
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t2,t1);}

/* k5642 in k5636 in g1381 in loop1374 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("walk1369");
t2=((C_word*)((C_word*)t0)[4])[1];
f_5605(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("delete-file");
((C_proc3)C_retrieve_symbol_proc(lf[314]))(3,*((C_word*)lf[314]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k5610 in k5607 in walk in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("delete-directory");
((C_proc3)C_retrieve_symbol_proc(lf[311]))(3,*((C_word*)lf[311]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5552,a[2]=t2,a[3]=((C_word)li102),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5561,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li106),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t1,t3,t4);}

/* a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5567,a[2]=((C_word*)t0)[3],a[3]=((C_word)li103),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[2],a[3]=((C_word)li105),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a5589 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_5590r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5590r(t0,t1,t2);}}

static void C_ccall f_5590r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5596,a[2]=t2,a[3]=((C_word)li104),tmp=(C_word)a,a+=4,tmp);
C_trace("k13551359");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5595 in a5589 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5567,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}

/* k5573 in a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[310],t1);}

/* k5576 in k5573 in a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5578,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5588,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}

/* k5586 in k5576 in k5573 in a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5579 in k5576 in k5573 in a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k5582 in k5579 in k5576 in k5573 in a5566 in a5560 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#$system");
f_5767(((C_word*)t0)[2],t1);}

/* a5551 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5552,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5558,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp);
C_trace("k13551359");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5557 in a5551 in a5545 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k5539 in k5669 in k5521 in setup-api#remove-directory in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("g13571358");
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#read-info in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5484(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5484r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5484r(t0,t1,t2,t3);}}

static void C_ccall f_5484r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5488,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5488(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k5486 in setup-api#read-info in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t2,t1,((C_word*)t0)[2],lf[2]);}

/* k5493 in k5486 in setup-api#read-info in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),((C_word*)t0)[2],t1,*((C_word*)lf[308]+1));}

/* setup-api#extension-version in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5440r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5440r(t0,t1,t2);}}

static void C_ccall f_5440r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5444,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_5444(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_5444(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k5442 in setup-api#extension-version in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5463,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k5461 in k5442 in setup-api#extension-version in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5463,2,t0,t1);}
t2=C_i_cadr(t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5453,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[306]))(3,*((C_word*)lf[306]+1),t3,t2);}

/* k5451 in k5461 in k5442 in setup-api#extension-version in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
if(C_truep(((C_word*)t0)[4])){
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* setup-api#extension-name in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k5436 in setup-api#extension-name in k5426 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(t1));}

/* setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5229(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5229,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5232,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5294,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("version->list1248");
f_5232(t5,t2);}

/* k5292 in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5298,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("version->list1248");
f_5232(t2,((C_word*)t0)[2]);}

/* k5296 in k5292 in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5298,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5300,a[2]=t3,a[3]=((C_word)li96),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_5300(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k5296 in k5292 in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5300(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5300,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t3));}
else{
t4=C_i_nullp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_car(t2);
if(C_truep(C_i_numberp(t5))){
t6=C_i_car(t3);
if(C_truep(C_i_numberp(t6))){
t7=C_i_car(t2);
t8=C_i_car(t3);
t9=C_i_greaterp(t7,t8);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t10=C_i_car(t2);
t11=C_i_car(t3);
if(C_truep(C_i_nequalp(t10,t11))){
t12=C_i_cdr(t2);
t13=C_i_cdr(t3);
C_trace("loop1277");
t20=t1;
t21=t12;
t22=t13;
t1=t20;
t2=t21;
t3=t22;
goto loop;}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_FALSE);}}}
else{
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}}
else{
t6=C_i_car(t3);
t7=C_i_numberp(t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5380,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t2);
t10=C_i_car(t3);
C_trace("string>?");
((C_proc4)C_retrieve_proc(*((C_word*)lf[303]+1)))(4,*((C_word*)lf[303]+1),t8,t9,t10);}}}}}

/* k5378 in loop in k5296 in k5292 in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_i_car(((C_word*)t0)[4]);
t3=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_string_equal_p(t2,t3))){
t4=C_i_cdr(((C_word*)t0)[4]);
t5=C_i_cdr(((C_word*)t0)[3]);
C_trace("loop1277");
t6=((C_word*)((C_word*)t0)[2])[1];
f_5300(t6,((C_word*)t0)[5],t4,t5);}
else{
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5232(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5232,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5240,a[2]=t1,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5287,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t8,t2);}

/* k5285 in version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-split-fields");
((C_proc5)C_retrieve_symbol_proc(lf[300]))(5,*((C_word*)lf[300]+1),((C_word*)t0)[2],lf[301],t1,lf[302]);}

/* k5238 in version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5242(t5,((C_word*)t0)[2],t1);}

/* loop1252 in k5238 in version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5242(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5242,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5252,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5273,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("string->number");
C_string_to_number(3,0,t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5271 in loop1252 in k5238 in version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5252(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
t2=((C_word*)t0)[3];
f_5252(t2,C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST));}}

/* k5250 in loop1252 in k5238 in version->list in setup-api#version>=? in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5252(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12521265");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5242(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop12521265");
t5=((C_word*)((C_word*)t0)[4])[1];
f_5242(t5,((C_word*)t0)[3],t4);}}

/* setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5207(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5207,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5215,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t3);}

/* k5213 in setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[299],t1);}

/* k5216 in k5213 in setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5219 in k5216 in k5213 in setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5221,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5224,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[298],((C_word*)t0)[2]);}

/* k5222 in k5219 in k5216 in k5213 in setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5227,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k5225 in k5222 in k5219 in k5216 in k5213 in setup-api#find-header in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[287]))(5,*((C_word*)lf[287]+1),((C_word*)t0)[2],t1,lf[259],C_SCHEME_TRUE);}

/* setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5148,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5156,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t4);}

/* k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5159,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[296],t1);}

/* k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5162,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5162,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5165,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[295],((C_word*)t0)[3]);}

/* k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5168,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5168,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5171,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[294],((C_word*)t0)[3]);}

/* k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[293],((C_word*)t0)[3]);}

/* k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5183,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[292],((C_word*)t0)[3]);}

/* k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[3]);}

/* k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[291],((C_word*)t0)[3]);}

/* k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5195,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[290],((C_word*)t0)[2]);}

/* k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5198,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k5196 in k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5198,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5201,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k5199 in k5196 in k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5201,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5205,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("conc");
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t2,lf[289],((C_word*)t0)[2]);}

/* k5203 in k5199 in k5196 in k5193 in k5190 in k5187 in k5184 in k5181 in k5178 in k5175 in k5172 in k5169 in k5166 in k5163 in k5160 in k5157 in k5154 in setup-api#find-library in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#test-compile");
((C_proc5)C_retrieve_symbol_proc(lf[287]))(5,*((C_word*)lf[287]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[262],t1);}

/* setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5027(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_5027r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5027r(t0,t1,t2);}}

static void C_ccall f_5027r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5033,a[2]=t4,a[3]=((C_word)li90),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5033(t6,t1,t2);}

/* loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5033(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5033,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5046,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
t5=t3;
f_5046(t5,C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_5046(t4,C_SCHEME_FALSE);}}}

/* k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5046(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5046,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_i_cadr(((C_word*)t0)[4]);
t4=C_i_cddr(((C_word*)t0)[4]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5058,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("extension-information");
((C_proc3)C_retrieve_symbol_proc(lf[284]))(3,*((C_word*)lf[284]+1),t5,t2);}
else{
C_trace("error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[113]+1)))(5,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[285],lf[286],((C_word*)t0)[4]);}}

/* k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_assq(lf[192],t1))){
t3=C_i_assq(lf[192],t1);
t4=t2;
f_5064(t4,C_i_cadr(t3));}
else{
t3=t2;
f_5064(t3,C_SCHEME_FALSE);}}
else{
C_trace("setup-api#upgrade-message");
f_4946(((C_word*)t0)[6],((C_word*)t0)[5],lf[283],C_SCHEME_END_OF_LIST);}}

/* k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5064,NULL,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5104,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[269]))(4,*((C_word*)lf[269]+1),t4,((C_word*)t0)[4],t1);}
else{
C_trace("setup-api#upgrade-message");
f_4946(((C_word*)t0)[6],((C_word*)t0)[5],lf[282],C_SCHEME_END_OF_LIST);}}

/* k5102 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5104,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5115,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
f_5079(t2,C_SCHEME_FALSE);}}

/* k5113 in k5102 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5115,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,((C_word*)t0)[2]);}

/* k5117 in k5113 in k5102 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_equal_p(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
f_5079(t3,C_i_not(t2));}

/* k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_5079(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5079,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}
else{
C_trace("loop1191");
t2=((C_word*)((C_word*)t0)[3])[1];
f_5033(t2,((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k5084 in k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5089,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[281],t1);}

/* k5087 in k5084 in k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5090 in k5087 in k5084 in k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[280],((C_word*)t0)[2]);}

/* k5093 in k5090 in k5087 in k5084 in k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k5096 in k5093 in k5090 in k5087 in k5084 in k5077 in k5062 in k5056 in k5044 in loop in setup-api#required-extension-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5098,2,t0,t1);}
C_trace("setup-api#upgrade-message");
f_4946(((C_word*)t0)[4],((C_word*)t0)[3],t1,C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4946(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4946,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4950,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4950(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4950(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}

/* k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[278],t1);}

/* k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[3],((C_word*)t0)[5]);}

/* k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4963,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[277],((C_word*)t0)[5]);}

/* k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4966,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4969,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[276],((C_word*)t0)[4]);}

/* k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4978,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[275],((C_word*)t0)[4]);}

/* k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4981,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4984,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4984,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4987,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5003,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("conc");
((C_proc4)C_retrieve_symbol_proc(lf[247]))(4,*((C_word*)lf[247]+1),t3,lf[273],((C_word*)t0)[2]);}
else{
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[274],((C_word*)t0)[3]);}}

/* k5001 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5003(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4990,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4990,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[272],((C_word*)t0)[2]);}

/* k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k4997 in k4994 in k4991 in k4988 in k4985 in k4982 in k4979 in k4976 in k4973 in k4970 in k4967 in k4964 in k4961 in k4958 in k4955 in k4948 in setup-api#upgrade-message in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4914(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4914,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4921,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4944,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[270]))(2,*((C_word*)lf[270]+1),t4);}

/* k4942 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#version>=?");
((C_proc4)C_retrieve_symbol_proc(lf[269]))(4,*((C_word*)lf[269]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4921,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4928,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4926 in k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4931,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[268],t1);}

/* k4929 in k4926 in k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4931,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4934,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4932 in k4929 in k4926 in k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4934,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4937,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[267],((C_word*)t0)[2]);}

/* k4935 in k4932 in k4929 in k4926 in k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4940,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k4938 in k4935 in k4932 in k4929 in k4926 in k4919 in setup-api#required-chicken-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4744(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_4744r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4744r(t0,t1,t2,t3);}}

static void C_ccall f_4744r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=C_i_get_keyword(lf[236],t3,C_SCHEME_FALSE);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4751,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4908,a[2]=t4,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t5,lf[265],t3,t6);}

/* a4907 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4908,2,t0,t1);}
if(C_truep(((C_word*)t0)[2])){
t2=C_retrieve2(lf[5],"setup-api#*cxx*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[5],"setup-api#*cxx*"));}
else{
t2=C_retrieve2(lf[4],"setup-api#*cc*");
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve2(lf[4],"setup-api#*cc*"));}}

/* k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4905,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t2,lf[264],((C_word*)t0)[2],t3);}

/* a4904 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4905,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[263]);}

/* k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4902,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t2,lf[262],((C_word*)t0)[2],t3);}

/* a4901 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4902,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[261]);}

/* k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4896,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t2,lf[260],((C_word*)t0)[2],t3);}

/* a4895 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t1);}

/* k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t2,lf[259],((C_word*)t0)[2],t3);}

/* a4892 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4893,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("create-temporary-file");
((C_proc3)C_retrieve_symbol_proc(lf[70]))(3,*((C_word*)lf[70]+1),t2,lf[258]);}

/* k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,t1,lf[257]);}

/* k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4887,a[2]=((C_word*)t0)[2],a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp);
C_trace("with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,((C_word*)t0)[8],t3);}

/* a4886 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4887,2,t0,t1);}
t2=*((C_word*)lf[67]+1);
C_trace("g11271128");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4775,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4860,a[2]=((C_word*)t0)[6],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(((C_word*)t0)[5])?lf[241]:lf[242]);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
t6=t5;
f_4874(2,t6,lf[253]);}
else{
C_trace("conc");
((C_proc8)C_retrieve_symbol_proc(lf[247]))(8,*((C_word*)lf[247]+1),t5,lf[254],C_retrieve2(lf[8],"setup-api#*target-lib-home*"),lf[255],((C_word*)t0)[2],lf[256],C_retrieve2(lf[7],"setup-api#*target-libs*"));}}

/* k4872 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=(C_truep(C_retrieve2(lf[12],"setup-api#*windows*"))?lf[243]:lf[244]);
t3=(C_truep(((C_word*)t0)[7])?lf[245]:lf[246]);
C_trace("conc");
((C_proc15)C_retrieve_symbol_proc(lf[247]))(15,*((C_word*)lf[247]+1),((C_word*)t0)[6],((C_word*)t0)[5],lf[248],((C_word*)t0)[4],lf[249],((C_word*)t0)[3],lf[250],C_retrieve2(lf[6],"setup-api#*target-cflags*"),lf[251],((C_word*)t0)[2],lf[252],t1,t2,t3);}

/* k4858 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4863,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("print");
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t2,t1,lf[240]);}
else{
t3=t1;
C_trace("system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[3],t3);}}

/* k4861 in k4858 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("system");
((C_proc3)C_retrieve_symbol_proc(lf[239]))(3,*((C_word*)lf[239]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4775,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4778,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_zerop(t1))){
C_trace("print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[50]+1)))(3,*((C_word*)lf[50]+1),t2,lf[237]);}
else{
C_trace("print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[50]+1)))(3,*((C_word*)lf[50]+1),t2,lf[238]);}}
else{
t3=t2;
f_4778(2,t3,C_SCHEME_UNDEFINED);}}

/* k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4778,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4789,a[2]=((C_word*)t0)[2],a[3]=((C_word)li80),tmp=(C_word)a,a+=4,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,t3);}

/* a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4789(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4789,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4795,a[2]=t2,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4804,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t1,t3,t4);}

/* a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4810,a[2]=((C_word*)t0)[3],a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4836,a[2]=((C_word*)t0)[2],a[3]=((C_word)li78),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a4835 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_4836r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4836r(t0,t1,t2);}}

static void C_ccall f_4836r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4842,a[2]=t2,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp);
C_trace("k11341138");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4841 in a4835 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4842,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4818,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}

/* k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4821,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t1);}

/* k4819 in k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4824,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k4822 in k4819 in k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4824,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4827,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}

/* k4832 in k4822 in k4819 in k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4825 in k4822 in k4819 in k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4827,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4830,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k4828 in k4825 in k4822 in k4819 in k4816 in a4809 in a4803 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#$system");
f_5767(((C_word*)t0)[2],t1);}

/* a4794 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4795(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4795,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4801,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
C_trace("k11341138");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a4800 in a4794 in a4788 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4801,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4784,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("g11361137");
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4782 in k4779 in k4776 in k4773 in k4770 in k4767 in k4764 in k4761 in k4758 in k4755 in k4752 in k4749 in setup-api#try-compile in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_zerop(((C_word*)t0)[2]));}

/* setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4691(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4691,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4695,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("pathname-directory");
((C_proc3)C_retrieve_symbol_proc(lf[234]))(3,*((C_word*)lf[234]+1),t3,t2);}

/* k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4698,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4704,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,t1);}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}}

/* k4702 in k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4704,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4710,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("directory?");
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t2,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4716,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#create-directory/parents");
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),t2,((C_word*)t0)[2]);}}

/* k4714 in k4702 in k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4716,2,t0,t1);}
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4742,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}}

/* k4740 in k4714 in k4702 in k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4742,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[233],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k4708 in k4702 in k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],lf[231]);}}

/* k4696 in k4693 in setup-api#ensure-directory in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4619(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4619,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4623,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_4623(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_4623(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4623,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4626,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4635,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t3);}
else{
C_trace("repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t2);}}

/* k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4635,2,t0,t1);}
if(C_truep(t1)){
C_trace("setup-api#installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4641,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#destination-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[166]))(2,*((C_word*)lf[166]+1),t2);}}

/* k4639 in k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4641(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4641,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4651,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}
else{
C_trace("repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),((C_word*)t0)[2]);}}

/* k4649 in k4639 in k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4651,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4654,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[230],t1);}

/* k4652 in k4649 in k4639 in k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_fudge(C_fix(42));
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,t3,((C_word*)t0)[2]);}

/* k4655 in k4652 in k4649 in k4639 in k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4660,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k4658 in k4655 in k4652 in k4649 in k4639 in k4633 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4624 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4629,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#ensure-directory");
f_4691(t2,t1);}

/* k4627 in k4624 in k4621 in setup-api#repo-path in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4451r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4451r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4451r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4455,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4455(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4455(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4461,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t2);}

/* k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4461,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4464,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4464,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4467,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t2);}

/* k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4588,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t3,t1,lf[229]);}

/* k4586 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#ensure-directory");
f_4691(((C_word*)t0)[2],t1);}

/* k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4508,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4508(t10,t6,((C_word*)t0)[2]);}

/* loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4508(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4508,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=((C_word*)t0)[5],a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4580,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g10581059");
t6=t3;
f_4535(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4578 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4580,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10421055");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4508(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop10421055");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4508(t6,((C_word*)t0)[3],t5);}}

/* g1058 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4535,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4542,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#make-dest-pathname");
f_3556(t5,((C_word*)t0)[2],t2);}

/* k4540 in g1058 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4545,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2],t1);}

/* k4543 in k4540 in g1058 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}}

/* k4569 in k4543 in k4540 in g1058 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4571,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[174],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k4546 in k4543 in k4540 in g1058 in loop1042 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4471 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4476,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t3=t2;
f_4476(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4506,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),t3,t1,lf[228]);}}

/* k4504 in k4471 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4506,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[227],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#supply-version");
f_3753(t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4481 in k4474 in k4471 in k4468 in k4465 in k4462 in k4459 in k4453 in setup-api#install-script in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#write-info");
f_3204(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4228r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4228r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4228r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4232(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4232(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4248,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api#setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t3);}

/* k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4248,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4251,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4254,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api#installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t2);}

/* k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t3,t1,lf[225]);}

/* k4418 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#ensure-directory");
f_4691(((C_word*)t0)[2],t1);}

/* k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4260,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[12],"setup-api#*windows*"))){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4353,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4353(t10,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4260(2,t3,((C_word*)t0)[2]);}}

/* loop967 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4353(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4353,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4380,a[2]=((C_word*)t0)[5],a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g983984");
t6=t3;
f_4380(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4410 in loop967 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop967980");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4353(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop967980");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4353(t6,((C_word*)t0)[3],t5);}}

/* g983 in loop967 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4380(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4380,NULL,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
C_trace("exify959");
f_4234(t3,t4);}
else{
C_trace("exify959");
f_4234(t1,t2);}}

/* k4392 in g983 in loop967 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4398,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
C_trace("exify959");
f_4234(t2,t3);}

/* k4396 in k4392 in g983 in loop967 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4260,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4272,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li65),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_4272(t10,t6,t1);}

/* loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4272(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4272,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[5],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4344,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g10081009");
t6=t3;
f_4299(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4342 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4344,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop9921005");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4272(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop9921005");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4272(t6,((C_word*)t0)[3],t5);}}

/* g1008 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4299(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4299,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4306,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#make-dest-pathname");
f_3556(t5,((C_word*)t0)[2],t2);}

/* k4304 in g1008 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4309,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2],t1);}

/* k4307 in k4304 in g1008 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4335,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}}

/* k4333 in k4307 in k4304 in g1008 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4335,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[174],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k4310 in k4307 in k4304 in g1008 in loop992 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4261 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4270,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#supply-version");
f_3753(t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4268 in k4261 in k4258 in k4255 in k4252 in k4249 in k4246 in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#write-info");
f_3204(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* exify in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4234(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4234,NULL,2,t1,t2);}
t3=(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))?lf[220]:C_SCHEME_FALSE);
t4=C_a_i_list(&a,1,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3669,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_3669(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_3669(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k3667 in exify in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3676,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t2,((C_word*)t0)[2]);}

/* k3674 in k3667 in exify in k4230 in setup-api#install-program in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_equalp(lf[221],t1))){
t3=C_retrieve(lf[82]);
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}
else{
if(C_truep(C_i_equalp(lf[222],t1))){
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[223]);}
else{
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[4],((C_word*)t0)[3],lf[224]);}}
else{
t3=t1;
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}}
else{
t3=((C_word*)t0)[2];
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3);}}

/* setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_4000r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4000r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4000r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4004,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_4004(2,t6,C_SCHEME_END_OF_LIST);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_4004(2,t7,C_i_car(t4));}
else{
C_trace("##sys#error");
t7=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#setup-install-mode");
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t2);}

/* k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[2]))){
t3=((C_word*)t0)[2];
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}
else{
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
C_trace("setup-api#check-filelist");
f_3581(t2,t3);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4016,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#repo-path");
f_4619(t2,C_SCHEME_END_OF_LIST);}

/* k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#repo-path");
f_4619(t2,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4019,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4022,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4031,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=((C_word)li61),tmp=(C_word)a,a+=8,tmp));
t10=((C_word*)t8)[1];
f_4031(t10,t6,((C_word*)t0)[2]);}

/* loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4031(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4031,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g916917");
t6=t3;
f_4058(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4191 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop900913");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4031(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop900913");
t6=((C_word*)((C_word*)t0)[4])[1];
f_4031(t6,((C_word*)t0)[3],t5);}}

/* g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4058(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4058,NULL,3,t0,t1,t2);}
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4065,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#make-dest-pathname");
f_3556(t5,((C_word*)t0)[2],t2);}

/* k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4068,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4155,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[12],"setup-api#*windows*");
if(C_truep(C_retrieve2(lf[12],"setup-api#*windows*"))){
t5=t3;
f_4155(t5,C_SCHEME_FALSE);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t5,t1);}}

/* k4182 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4155(t2,C_i_equalp(lf[218],t1));}

/* k4153 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4155(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4155,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_4068(2,t2,C_SCHEME_UNDEFINED);}}

/* k4172 in k4153 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4174,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t4);}

/* k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#copy-file");
((C_proc4)C_retrieve_symbol_proc(lf[182]))(4,*((C_word*)lf[182]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4074,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t3=t2;
f_4074(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[3]);}}

/* k4150 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4152,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[174],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4074,2,t0,t1);}
t2=C_i_assq(lf[198],((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4080,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("software-version");
((C_proc2)C_retrieve_symbol_proc(lf[217]))(2,*((C_word*)lf[217]+1),t5);}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[3]);}}

/* k4127 in k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4129,2,t0,t1);}
t2=C_eqp(t1,lf[215]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[5]);
if(C_truep(C_i_equalp(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[3];
f_4086(t4,C_SCHEME_FALSE);}}
else{
t3=((C_word*)t0)[3];
f_4086(t3,C_SCHEME_FALSE);}}

/* k4119 in k4127 in k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4086(t2,C_i_equalp(t1,lf[216]));}

/* k4084 in k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_4086(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4086,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}

/* k4103 in k4084 in k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[35],"setup-api#*ranlib-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t4);}

/* k4078 in k4072 in k4069 in k4066 in k4063 in g916 in loop900 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k4020 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#supply-version");
f_3753(t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k4027 in k4020 in k4017 in k4014 in k4011 in k4008 in k4002 in setup-api#install-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_4029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#write-info");
f_3204(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3777(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr4r,(void*)f_3777r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3777r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3777r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3781,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3997,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t5,lf[214],t4,t6);}

/* a3996 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3997,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3781,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3784,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3994,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[212]+1)))(5,*((C_word*)lf[212]+1),t2,lf[213],((C_word*)t0)[2],t3);}

/* a3993 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3994,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,((C_word*)t0)[4]);}

/* k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3790,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t2,C_SCHEME_FALSE,t1,lf[211]);}

/* k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[210]);}

/* k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3796,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t2,C_SCHEME_FALSE,((C_word*)t0)[2],lf[209]);}

/* k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[40],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3799,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[207],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[5],t4);
t6=C_a_i_cons(&a,2,C_fix(1),t5);
t7=C_a_i_cons(&a,2,lf[202],t6);
t8=C_a_i_cons(&a,2,C_fix(3),t7);
t9=C_a_i_cons(&a,2,lf[203],t8);
t10=C_a_i_cons(&a,2,lf[204],t9);
t11=C_a_i_cons(&a,2,lf[205],t10);
t12=C_a_i_list(&a,1,t11);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t12);}

/* k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[46],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[206],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[8],t4);
t6=C_a_i_cons(&a,2,lf[207],t5);
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],t6);
t8=C_a_i_cons(&a,2,C_fix(1),t7);
t9=C_a_i_cons(&a,2,lf[202],t8);
t10=C_a_i_cons(&a,2,C_fix(3),t9);
t11=C_a_i_cons(&a,2,lf[203],t10);
t12=C_a_i_cons(&a,2,lf[208],t11);
t13=C_a_i_cons(&a,2,lf[205],t12);
t14=C_a_i_list(&a,1,t13);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t14);}
else{
t3=t2;
f_3802(2,t3,C_SCHEME_UNDEFINED);}}

/* k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3805,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,C_fix(0),t3);
t5=C_a_i_cons(&a,2,lf[202],t4);
t6=C_a_i_cons(&a,2,C_fix(3),t5);
t7=C_a_i_cons(&a,2,lf[203],t6);
t8=C_a_i_cons(&a,2,lf[204],t7);
t9=C_a_i_cons(&a,2,lf[205],t8);
t10=C_a_i_list(&a,1,t9);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),t2,t10);}

/* k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,((C_word*)t0)[6],lf[201]);}

/* k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,((C_word*)t0)[2],lf[200]);}

/* k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3859,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3866,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,((C_word*)t0)[2]);}

/* k3864 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3866,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_list(&a,1,((C_word*)t0)[3]);
C_trace("##sys#append");
t3=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_SCHEME_END_OF_LIST);}
else{
C_trace("##sys#append");
t2=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k3857 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3859,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[9],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3816,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3820,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#supply-version");
f_3753(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3818 in k3857 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3824,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3843,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),t3,C_SCHEME_FALSE,((C_word*)t0)[2],lf[199]);}
else{
C_trace("##sys#append");
t3=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* k3841 in k3818 in k3857 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3843,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[198],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
C_trace("##sys#append");
t5=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k3822 in k3818 in k3857 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#append");
t2=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3814 in k3857 in k3853 in k3845 in k3803 in k3800 in k3797 in k3794 in k3791 in k3788 in k3785 in k3782 in k3779 in setup-api#standard-extension in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#install-extension");
((C_proc5)C_retrieve_symbol_proc(lf[197]))(5,*((C_word*)lf[197]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#supply-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3753(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3753,NULL,3,t1,t2,t3);}
if(C_truep(C_i_assq(lf[192],t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(t3)){
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[192],t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,t5,t2));}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3725,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#extension-name-and-version");
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t4);}}}

/* k3723 in setup-api#supply-version in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3725,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_pairp(t1))){
t2=C_i_cadr(t1);
if(C_truep(C_i_equalp(lf[193],t2))){
t3=C_a_i_cons(&a,2,lf[194],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[192],t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,t4,((C_word*)t0)[2]));}
else{
t3=C_i_cadr(t1);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[192],t4);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,t5,((C_word*)t0)[2]));}}
else{
t2=C_a_i_cons(&a,2,lf[194],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[192],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}}
else{
t2=C_a_i_cons(&a,2,lf[194],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[192],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t3,((C_word*)t0)[2]));}}

/* setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3581(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3581,NULL,2,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3587,a[2]=t4,a[3]=t8,a[4]=t6,a[5]=((C_word)li54),tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3587(t10,t1,t2);}

/* loop777 in setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3587(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3587,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3597,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3659,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
if(C_truep(C_i_stringp(t5))){
t6=t3;
f_3597(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3627,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t5))){
C_trace("every");
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t6,*((C_word*)lf[155]+1),t5);}
else{
t7=t6;
f_3627(2,t7,C_SCHEME_FALSE);}}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3625 in loop777 in setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3627,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3597(t2,C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3630,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_i_car(((C_word*)t0)[3]);
t4=C_i_cdr(((C_word*)t0)[3]);
t5=t2;
f_3630(t5,C_a_i_list(&a,2,t3,t4));}
else{
t3=t2;
f_3630(t3,C_SCHEME_FALSE);}}}

/* k3628 in k3625 in loop777 in setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3630(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3630,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[4];
f_3597(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[190],((C_word*)t0)[2]);}}

/* k3657 in loop777 in setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
t2=((C_word*)t0)[2];
f_3597(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k3595 in loop777 in setup-api#check-filelist in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop777790");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3587(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop777790");
t5=((C_word*)((C_word*)t0)[4])[1];
f_3587(t5,((C_word*)t0)[3],t4);}}

/* setup-api#make-dest-pathname in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3556(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3556,NULL,3,t1,t2,t3);}
if(C_truep(C_i_listp(t3))){
t4=C_i_cadr(t3);
C_trace("setup-api#make-dest-pathname");
t7=t1;
t8=t2;
t9=t4;
t1=t7;
t2=t8;
t3=t9;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3576,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[184]))(3,*((C_word*)lf[184]+1),t4,t3);}}

/* k3574 in setup-api#make-dest-pathname in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}
else{
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[4],((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* setup-api#remove-file* in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3534,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3554,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,t2);}

/* k3552 in setup-api#remove-file* in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[32],"setup-api#*remove-command*"),t2);
t4=C_a_i_list(&a,1,t3);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t4);}

/* setup-api#move-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3479(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3479,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_car(t2):t2);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t2))){
t7=C_i_cadr(t2);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t6,t3,t7);}
else{
t7=t6;
f_3486(2,t7,t3);}}

/* k3484 in setup-api#move-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#ensure-directory");
f_4691(t2,t1);}

/* k3487 in k3484 in setup-api#move-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3508,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3506 in k3487 in k3484 in setup-api#move-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3516,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3514 in k3506 in k3487 in k3484 in setup-api#move-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3516,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_3333r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3333r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3333r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3335,a[2]=t3,a[3]=t2,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3408,a[2]=t5,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3417,a[2]=t6,a[3]=((C_word)li49),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-err729749");
t8=t7;
f_3417(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
C_trace("def-prefix730747");
t10=t6;
f_3408(t10,t1);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
C_trace("body727734");
t12=t5;
f_3335(t12,t1,t10);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-err729 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3417,NULL,2,t0,t1);}
C_trace("def-prefix730747");
t2=((C_word*)t0)[2];
f_3408(t2,t1);}

/* def-prefix730 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3408(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3408,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3416,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#installation-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[167]))(2,*((C_word*)lf[167]+1),t2);}

/* k3414 in def-prefix730 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("body727734");
t2=((C_word*)t0)[3];
f_3335(t2,((C_word*)t0)[2],t1);}

/* body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3335(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3335,NULL,3,t0,t1,t2);}
t3=C_i_pairp(((C_word*)t0)[3]);
t4=(C_truep(t3)?C_i_car(((C_word*)t0)[3]):((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3342,a[2]=t2,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t6=C_i_cadr(((C_word*)t0)[3]);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t5,((C_word*)t0)[2],t6);}
else{
t6=t5;
f_3342(2,t6,((C_word*)t0)[2]);}}

/* k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3342,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3345,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=((C_word*)t0)[2];
t5=t1;
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t6,t4);}

/* k3471 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3477,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k3475 in k3471 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-prefix?");
((C_proc4)C_retrieve_symbol_proc(lf[185]))(4,*((C_word*)lf[185]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3389 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_3345(2,t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3384,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("absolute-pathname?");
((C_proc3)C_retrieve_symbol_proc(lf[184]))(3,*((C_word*)lf[184]+1),t2,((C_word*)t0)[3]);}}

/* k3382 in k3389 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
f_3345(2,t3,t2);}
else{
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* k3343 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3345,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3348,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#ensure-directory");
f_4691(t2,t1);}

/* k3346 in k3343 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3348,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3351,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3367,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}

/* k3365 in k3346 in k3343 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3373 in k3365 in k3346 in k3343 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3375,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[31],"setup-api#*copy-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k3349 in k3346 in k3343 in k3340 in body727 in setup-api#copy-file in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3204(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3204,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3331,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t6=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t3,C_SCHEME_END_OF_LIST);}

/* k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3331,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[173],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#append");
t4=*((C_word*)lf[181]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3211,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t4);}

/* k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[180],t2);}
else{
t2=((C_word*)t0)[4];
f_3211(2,t2,C_SCHEME_UNDEFINED);}}

/* k3302 in k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3305 in k3302 in k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[179],((C_word*)t0)[3]);}

/* k3308 in k3305 in k3302 in k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3311 in k3308 in k3305 in k3302 in k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[178],((C_word*)t0)[2]);}

/* k3314 in k3311 in k3308 in k3305 in k3302 in k3299 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,((C_word*)t0)[2]);}

/* k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3217,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3298,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#repo-path");
f_4619(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}

/* k3296 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_a_i_list(&a,1,t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3133,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
C_trace("repository-path");
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),((C_word*)t0)[2],t6,t2,lf[2]);}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k3131 in k3296 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[78]))(5,*((C_word*)lf[78]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],lf[2]);}

/* k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3220,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[9],"setup-api#*sudo*"))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3249,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[2],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
C_trace("with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,t1,t3);}}

/* a3289 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=C_retrieve(lf[175]);
C_trace("g707708");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3247 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3252,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3281,a[2]=((C_word*)t0)[2],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
C_trace("with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),t2,t1,t3);}

/* a3280 in k3247 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=C_retrieve(lf[175]);
C_trace("g697698");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k3250 in k3247 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3269 in k3250 in k3247 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3279,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k3277 in k3269 in k3250 in k3247 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3279,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[33],"setup-api#*move-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* k3218 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3246,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}}

/* k3244 in k3218 in k3215 in k3212 in k3209 in k3325 in k3329 in setup-api#write-info in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3246,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[174],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[34],"setup-api#*chmod-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* f_5917 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5917,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5921,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("verb656");
f_3180(t3,t2);}

/* k5919 */
static void C_ccall f_5921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5944,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[2]);}

/* k5942 in k5919 */
static void C_ccall f_5944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5944,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[170],t2);
t4=C_a_i_cons(&a,2,C_retrieve2(lf[36],"setup-api#*mkdir-command*"),t3);
t5=C_a_i_list(&a,1,t4);
C_trace("setup-api#execute");
((C_proc3)C_retrieve_symbol_proc(lf[86]))(3,*((C_word*)lf[86]+1),((C_word*)t0)[2],t5);}

/* f_5909 in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_5909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5909,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5913,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("verb656");
f_3180(t3,t2);}

/* k5911 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("create-directory");
((C_proc4)C_retrieve_symbol_proc(lf[169]))(4,*((C_word*)lf[169]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_TRUE);}

/* verb in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3180(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3180,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3187,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t3);}

/* k3185 in verb in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3187,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3190,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[168],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3188 in k3185 in verb in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3193,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3191 in k3188 in k3185 in verb in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k3194 in k3191 in k3188 in k3185 in verb in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-api#installation-prefix in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3171,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#destination-prefix");
((C_proc2)C_retrieve_symbol_proc(lf[166]))(2,*((C_word*)lf[166]+1),t2);}

/* k3169 in setup-api#installation-prefix in k3164 in k3160 in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(((C_word*)t0)[2])?((C_word*)t0)[2]:C_retrieve(lf[15])));}}

/* setup-api#make/proc in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3086r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3086r(t0,t1,t2,t3);}}

static void C_ccall f_3086r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(4);
t4=C_i_length(t3);
switch(t4){
case C_fix(0):
t5=t2;
C_trace("setup-api#make:make/proc/helper");
f_2665(t1,t5,C_SCHEME_END_OF_LIST);
case C_fix(1):
t5=t2;
t6=C_i_car(t3);
t7=C_i_cdr(t3);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3118,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(t6))){
C_trace("vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t8,t6);}
else{
C_trace("setup-api#make:make/proc/helper");
f_2665(t1,t5,t6);}
default:
C_trace("##sys#error");
t5=*((C_word*)lf[28]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t1,lf[165]);}}

/* k3116 in setup-api#make/proc in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#make:make/proc/helper");
f_2665(((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2665(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2665,NULL,3,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2669,a[2]=t4,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_vectorp(((C_word*)t4)[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3084,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
C_trace("vector->list");
((C_proc3)C_retrieve_proc(*((C_word*)lf[163]+1)))(3,*((C_word*)lf[163]+1),t6,((C_word*)t4)[1]);}
else{
t6=t5;
f_2669(t6,C_SCHEME_UNDEFINED);}}

/* k3082 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2669(t3,t2);}

/* k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2669(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2669,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[4];
t4=C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2497,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
t6=t5;
f_2497(2,t6,t4);}
else{
C_trace("setup-api#make:form-error");
f_2437(t5,lf[162],t3);}}

/* k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2497,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_pairp(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_2506(2,t4,t2);}
else{
C_trace("setup-api#make:form-error");
f_2437(t3,lf[161],((C_word*)t0)[3]);}}
else{
t2=((C_word*)t0)[2];
f_2672(2,t2,C_SCHEME_FALSE);}}

/* k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2511,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("every");
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2672(2,t2,C_SCHEME_FALSE);}}

/* a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2511(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2511,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2518,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
C_trace("<=");
C_less_or_equal_p(5,0,t3,C_fix(2),t4,C_fix(3));}
else{
t4=t3;
f_2518(2,t4,C_SCHEME_FALSE);}}

/* k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2521(2,t3,t1);}
else{
C_trace("setup-api#make:form-error");
f_2437(t2,lf[160],((C_word*)t0)[3]);}}

/* k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_stringp(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_2530(2,t5,t3);}
else{
t5=C_i_car(((C_word*)t0)[3]);
if(C_truep(C_i_listp(t5))){
t6=C_i_car(((C_word*)t0)[3]);
C_trace("every");
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t4,*((C_word*)lf[155]+1),t6);}
else{
t6=t4;
f_2530(2,t6,C_SCHEME_FALSE);}}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2528 in k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_2533(2,t3,t1);}
else{
C_trace("setup-api#make:form-error");
f_2437(t2,lf[159],((C_word*)t0)[3]);}}

/* k2531 in k2528 in k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2533,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=C_i_listp(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2542,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2542(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2572,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(((C_word*)t0)[3]);
C_trace("setup-api#make:line-error");
f_2459(t6,lf[158],t7,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2570 in k2531 in k2528 in k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2572,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_2542(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2580,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
C_trace("every");
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),((C_word*)t0)[3],t2,t3);}}

/* a2579 in k2570 in k2531 in k2528 in k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2580,3,t0,t1,t2);}
t3=C_i_stringp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
C_trace("setup-api#make:form-error");
f_2437(t1,lf[157],t2);}}

/* k2540 in k2531 in k2528 in k2519 in k2516 in a2510 in k2504 in k2495 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_caddr(((C_word*)t0)[4]);
t5=C_i_closurep(t4);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_caddr(((C_word*)t0)[4]);
C_trace("setup-api#make:line-error");
f_2459(((C_word*)t0)[3],lf[156],t6,((C_word*)t0)[2]);}}}

/* k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2675,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_i_stringp(t3);
if(C_truep(t4)){
t5=t2;
f_2675(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2657,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("every");
((C_proc4)C_retrieve_symbol_proc(lf[154]))(4,*((C_word*)lf[154]+1),t5,*((C_word*)lf[155]+1),t3);}}

/* k2655 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2675(2,t2,t1);}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[113]+1)))(4,*((C_word*)lf[113]+1),((C_word*)t0)[3],lf[153],((C_word*)t0)[2]);}}

/* k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2675,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,C_SCHEME_END_OF_LIST);
t11=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2680,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t9,a[7]=t7,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
C_trace("condition-predicate");
((C_proc3)C_retrieve_symbol_proc(lf[152]))(3,*((C_word*)lf[152]+1),t11,lf[150]);}

/* k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2680,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2684,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("condition-property-accessor");
((C_proc4)C_retrieve_symbol_proc(lf[149]))(4,*((C_word*)lf[149]+1),t3,lf[150],lf[151]);}

/* k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2684,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[7])+1,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word)li32),tmp=(C_word)a,a+=8,tmp));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2980,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_stringp(((C_word*)((C_word*)t0)[2])[1]))){
C_trace("make-file446");
t5=((C_word*)((C_word*)t0)[7])[1];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)((C_word*)t0)[2])[1],lf[145]);}
else{
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3046,a[2]=t4,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
C_trace("caar");
((C_proc3)C_retrieve_proc(*((C_word*)lf[147]+1)))(3,*((C_word*)lf[147]+1),t5,((C_word*)t0)[4]);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3051,a[2]=t6,a[3]=((C_word*)t0)[7],a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3051(t8,t4,((C_word*)((C_word*)t0)[2])[1]);}}}

/* loop547 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3051(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3051,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3066,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g554555");
t6=t3;
f_3059(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3064 in loop547 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3051(t3,((C_word*)t0)[2],t2);}

/* g554 in loop547 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_3059(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3059,NULL,3,t0,t1,t2);}
C_trace("make-file446");
t3=((C_word*)((C_word*)t0)[2])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,lf[148]);}

/* k3044 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-file446");
t2=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,lf[146]);}

/* k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t2);}

/* k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2986,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2993,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[144]+1)))(3,*((C_word*)lf[144]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2991 in k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2993,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2995,a[2]=t3,a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2995(t5,((C_word*)t0)[2],t1);}

/* loop561 in k2991 in k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2995(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2995,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3016,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[71]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3007,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t6,lf[143],t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3005 in loop561 in k2991 in k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3008 in k3005 in loop561 in k2991 in k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k3014 in loop561 in k2991 in k2984 in k2978 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_3016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2995(t3,((C_word*)t0)[2],t2);}

/* f_2686 in k2682 in k2678 in k2673 in k2670 in k2667 in setup-api#make:make/proc/helper in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2686,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=t2;
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=t5,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2392,a[2]=t7,a[3]=t9,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2392(t11,t4,t6);}

/* loop */
static void C_fcall f_2392(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2392,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(t3);
if(C_truep(C_i_stringp(t5))){
t6=C_i_car(t3);
t7=t4;
f_2405(t7,C_a_i_list(&a,1,t6));}
else{
t6=t4;
f_2405(t6,C_i_car(t3));}}}

/* k2403 in loop */
static void C_fcall f_2405(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2405,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2411,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("any");
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t2,((C_word*)t0)[2],t1);}

/* k2409 in k2403 in loop */
static void C_ccall f_2411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
t2=C_i_cdr(((C_word*)t0)[3]);
C_trace("loop362");
t3=((C_word*)((C_word*)t0)[2])[1];
f_2392(t3,((C_word*)t0)[5],t2);}}

/* match? */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2383,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_equal_p(t2,((C_word*)t0)[2]));}

/* k2688 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
C_trace("setup-api#fixmaketarget");
f_2204(t2,((C_word*)t0)[7]);}

/* k2691 in k2688 */
static void C_ccall f_2693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2693,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2974,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,t1);}

/* k2972 in k2691 in k2688 */
static void C_ccall f_2974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_2696(2,t2,C_SCHEME_FALSE);}}

/* k2694 in k2691 in k2688 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2699,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2956,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t3);}

/* k2954 in k2694 in k2691 in k2688 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2956,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[142],t2);}
else{
t2=((C_word*)t0)[4];
f_2699(2,t2,C_SCHEME_UNDEFINED);}}

/* k2957 in k2954 in k2694 in k2691 in k2688 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2960 in k2957 in k2954 in k2694 in k2691 in k2688 */
static void C_ccall f_2962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2965,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[141],((C_word*)t0)[3]);}

/* k2963 in k2960 in k2957 in k2954 in k2694 in k2691 in k2688 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2968,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2966 in k2963 in k2960 in k2957 in k2954 in k2694 in k2691 in k2688 */
static void C_ccall f_2968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2699,2,t0,t1);}
if(C_truep(((C_word*)t0)[11])){
t2=C_i_cadr(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2708,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2929,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[103]+1)))(4,*((C_word*)lf[103]+1),t4,lf[139],((C_word*)t0)[3]);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2944,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}}}

/* k2942 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[140],t1);}

/* k2945 in k2942 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2948 in k2945 in k2942 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2953,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k2951 in k2948 in k2945 in k2942 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* k2927 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2930,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word)li29),tmp=(C_word)a,a+=5,tmp);
C_trace("for-each");
t3=*((C_word*)lf[138]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a2926 in k2927 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2930,3,t0,t1,t2);}
C_trace("make-file446");
t3=((C_word*)((C_word*)t0)[3])[1];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2708,2,t0,t1);}
t2=C_i_not(((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t2)){
t4=t3;
f_2714(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2883,a[2]=((C_word*)t0)[11],a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
C_trace("any");
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t3,t4,((C_word*)t0)[2]);}}

/* a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2883(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2883,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2887,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#fixmaketarget");
f_2204(t3,t2);}

/* k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2890,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2903,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,t1);}

/* k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2890(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2910,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}}

/* k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2910,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[135],t1);}

/* k2911 in k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2916,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2914 in k2911 in k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2916,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[134],((C_word*)t0)[2]);}

/* k2917 in k2914 in k2911 in k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2919,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2922,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2920 in k2917 in k2914 in k2911 in k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2925,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k2923 in k2920 in k2917 in k2914 in k2911 in k2908 in k2901 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* k2888 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2900,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("file-modification-time");
((C_proc3)C_retrieve_symbol_proc(lf[133]))(3,*((C_word*)lf[133]+1),t2,((C_word*)t0)[3]);}

/* k2898 in k2888 in k2885 in a2882 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_greaterp(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cddr(((C_word*)t0)[10]);
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[7])+1,t3);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2733,a[2]=t2,a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t5,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t6);}}
else{
t2=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2816,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2819,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[132],t2);}
else{
t2=((C_word*)t0)[6];
f_2733(2,t2,C_SCHEME_UNDEFINED);}}

/* k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2819(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2819,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2822,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[131],((C_word*)t0)[5]);}

/* k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2828,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2831,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2838,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[4];
if(C_truep(t4)){
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[103]+1)))(5,*((C_word*)lf[103]+1),t3,lf[125],((C_word*)t0)[3],lf[126]);}
else{
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2860,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t5);}}
else{
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[103]+1)))(5,*((C_word*)lf[103]+1),t3,lf[129],((C_word*)t0)[2],lf[130]);}}

/* k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2860,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[128],t1);}

/* k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2864 in k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[127],((C_word*)t0)[3]);}

/* k2867 in k2864 in k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2870 in k2867 in k2864 in k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k2876 in k2873 in k2870 in k2867 in k2864 in k2861 in k2858 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
((C_proc3)C_retrieve_proc(*((C_word*)lf[103]+1)))(3,*((C_word*)lf[103]+1),((C_word*)t0)[2],t1);}

/* k2836 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2829 in k2826 in k2823 in k2820 in k2817 in k2814 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2736,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2741,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li27),tmp=(C_word)a,a+=7,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t2,t3);}

/* a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2741(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2741,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2747,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2788,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t1,t3,t4);}

/* a2787 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2794,a[2]=((C_word*)t0)[3],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2803,a[2]=((C_word*)t0)[2],a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a2802 in a2787 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_2803r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2803r(t0,t1,t2);}}

static void C_ccall f_2803r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2809,a[2]=t2,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
C_trace("k514518");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2808 in a2802 in a2787 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2793 in a2787 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2794,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[2]);
C_trace("g528529");
t3=t2;
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2747,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li21),tmp=(C_word)a,a+=7,tmp);
C_trace("k514518");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2753,2,t0,t1);}
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[122],t2);}

/* k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2760,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,t3,((C_word*)t0)[5]);}

/* k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2760,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2763,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[121],((C_word*)t0)[4]);}

/* k2761 in k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2766,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2776,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2779,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
C_trace("exn?444");
t5=((C_word*)((C_word*)t0)[2])[1];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)t0)[5]);}

/* k2777 in k2761 in k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("exn-message445");
t2=((C_word*)((C_word*)t0)[6])[1];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=((C_word*)t0)[4];
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* k2774 in k2761 in k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2764 in k2761 in k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2767 in k2764 in k2761 in k2758 in k2755 in a2752 in a2746 in a2740 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("signal");
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2734 in k2731 in k2712 in k2706 in k2697 in k2694 in k2691 in k2688 */
static void C_ccall f_2736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("g516517");
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2459(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2459,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2467,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t5);}

/* k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2467,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2470,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],t1);}

/* k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2473,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[118],((C_word*)t0)[4]);}

/* k2471 in k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2474 in k2471 in k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2479,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[117],((C_word*)t0)[3]);}

/* k2477 in k2474 in k2471 in k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2479,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2482,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2480 in k2477 in k2474 in k2471 in k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2482(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2482,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2485,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k2483 in k2480 in k2477 in k2474 in k2471 in k2468 in k2465 in setup-api#make:line-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2437(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2437,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2445,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t4);}

/* k2443 in setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2448,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],t1);}

/* k2446 in k2443 in setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2451,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[115],((C_word*)t0)[3]);}

/* k2449 in k2446 in k2443 in setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("write");
((C_proc4)C_retrieve_proc(*((C_word*)lf[114]+1)))(4,*((C_word*)lf[114]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2452 in k2449 in k2446 in k2443 in setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k2455 in k2452 in k2449 in k2446 in k2443 in setup-api#make:form-error in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("error");
((C_proc3)C_retrieve_proc(*((C_word*)lf[113]+1)))(3,*((C_word*)lf[113]+1),((C_word*)t0)[2],t1);}

/* setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2230,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2298,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2346,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2346(t11,t7,t2);}

/* loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2346,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2375,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2258,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word)li16),tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_2258(t13,t9,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop246 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2258(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2258,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[77]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
C_trace("g262263");
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2285 in loop246 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2287,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop246259");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2258(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop246259");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2258(t6,((C_word*)t0)[3],t5);}}

/* k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2237,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
if(C_truep(C_i_string_equal_p(t3,lf[91]))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2045,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2049,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2199,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#find-program");
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t6,lf[111]);}
else{
C_trace("setup-api#find-program");
((C_proc3)C_retrieve_symbol_proc(lf[79]))(3,*((C_word*)lf[79]+1),t2,t3);}}

/* k2197 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1);}

/* k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2049,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2053,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2188,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("feature?");
((C_proc3)C_retrieve_symbol_proc(lf[109]))(3,*((C_word*)lf[109]+1),t3,lf[110]);}

/* k2186 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2188,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2195,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-api#host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[13]))(2,*((C_word*)lf[13]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_2053(t2,lf[107]);}}

/* k2193 in k2186 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2053(t2,(C_truep(t1)?lf[107]:lf[108]));}

/* k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2182,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#keep-intermediates");
((C_proc2)C_retrieve_symbol_proc(lf[25]))(2,*((C_word*)lf[25]+1),t2);}

/* k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2182,2,t0,t1);}
t2=(C_truep(t1)?lf[93]:lf[94]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2179,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-api#host-extension");
((C_proc2)C_retrieve_symbol_proc(lf[13]))(2,*((C_word*)lf[13]+1),t3);}

/* k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2179,2,t0,t1);}
t2=(C_truep(t1)?lf[95]:lf[96]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2176,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-api#deployment-mode");
((C_proc2)C_retrieve_symbol_proc(lf[23]))(2,*((C_word*)lf[23]+1),t3);}

/* k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(C_truep(t1)?lf[97]:lf[98]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2069,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2073,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2129,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#extra-features");
((C_proc2)C_retrieve_symbol_proc(lf[26]))(2,*((C_word*)lf[26]+1),t9);}

/* k2127 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2129,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2131(t5,((C_word*)t0)[2],t1);}

/* loop185 in k2127 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2131(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2131,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2169,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2164 in loop185 in k2127 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[103]+1)))(4,*((C_word*)lf[103]+1),((C_word*)t0)[2],lf[106],t1);}

/* k2167 in loop185 in k2127 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2169,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop185198");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2131(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop185198");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2131(t6,((C_word*)t0)[3],t5);}}

/* k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2077,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2081,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#extra-nonfeatures");
((C_proc2)C_retrieve_symbol_proc(lf[29]))(2,*((C_word*)lf[29]+1),t7);}

/* k2079 in k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2081,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2083,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2083(t5,((C_word*)t0)[2],t1);}

/* loop209 in k2079 in k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2083(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2083,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2118,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("symbol->string");
((C_proc3)C_retrieve_proc(*((C_word*)lf[105]+1)))(3,*((C_word*)lf[105]+1),t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2116 in loop209 in k2079 in k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[103]+1)))(4,*((C_word*)lf[103]+1),((C_word*)t0)[2],lf[104],t1);}

/* k2119 in loop209 in k2079 in k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2121,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop209222");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2083(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop209222");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2083(t6,((C_word*)t0)[3],t5);}}

/* k2075 in k2071 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[102]+1)))(5,*((C_word*)lf[102]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2067 in k2174 in k2177 in k2180 in k2051 in k2047 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("cons*");
((C_proc10)C_retrieve_symbol_proc(lf[99]))(10,*((C_word*)lf[99]+1),((C_word*)t0)[7],((C_word*)t0)[6],lf[100],lf[101],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2043 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[2],t1,lf[92]);}

/* k2246 in k2235 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2248,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t1,t2);
C_trace("string-intersperse");
((C_proc4)C_retrieve_symbol_proc(lf[89]))(4,*((C_word*)lf[89]+1),((C_word*)t0)[2],t3,lf[90]);}

/* k2373 in loop283 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2375,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop283296");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2346(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop283296");
t6=((C_word*)((C_word*)t0)[4])[1];
f_2346(t6,((C_word*)t0)[3],t5);}}

/* k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2300,a[2]=t3,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2300(t5,((C_word*)t0)[2],t1);}

/* loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2300(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2300,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2333,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2312,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2318,a[2]=t3,a[3]=t4,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("setup-api#run-verbose");
((C_proc2)C_retrieve_symbol_proc(lf[74]))(2,*((C_word*)lf[74]+1),t6);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2316 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[88],t2);}
else{
C_trace("setup-api#$system");
f_5767(((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k2319 in k2316 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2322 in k2319 in k2316 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2324,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k2325 in k2322 in k2319 in k2316 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("##sys#flush-output");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2310 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#$system");
f_5767(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2331 in loop236 in k2296 in setup-api#execute in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2300(t3,((C_word*)t0)[2],t2);}

/* setup-api#fixmaketarget in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2204(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2204,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2211,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("pathname-extension");
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),t4,t2);}

/* k2226 in setup-api#fixmaketarget in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_equalp(lf[83],t1))){
t2=C_i_string_equal_p(lf[84],C_retrieve(lf[82]));
t3=((C_word*)t0)[2];
f_2211(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[2];
f_2211(t2,C_SCHEME_FALSE);}}

/* k2209 in setup-api#fixmaketarget in k2027 in k2024 in k2021 in k2018 in k2015 in k2012 in k2009 in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2211(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
C_trace("pathname-replace-extension");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_retrieve(lf[82]));}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* reg in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_2000(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2000,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2008,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),t4,C_retrieve2(lf[14],"setup-api#*chicken-bin-path*"),t3);}

/* k2006 in reg in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_2008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#register-program");
((C_proc4)C_retrieve_symbol_proc(lf[75]))(4,*((C_word*)lf[75]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-api#find-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1981(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1981,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1985,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t3,t2);}

/* k1983 in setup-api#find-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_assoc(t1,C_retrieve2(lf[11],"setup-api#*registered-programs*"));
if(C_truep(t2)){
t3=C_i_cdr(t2);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),((C_word*)t0)[2],t3);}
else{
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* setup-api#register-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1941r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1941r(t0,t1,t2,t3);}}

static void C_ccall f_1941r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1945,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t5,t2);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1945(2,t6,C_i_car(t3));}
else{
C_trace("##sys#error");
t6=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1961 in setup-api#register-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[78]))(4,*((C_word*)lf[78]+1),((C_word*)t0)[2],C_retrieve2(lf[14],"setup-api#*chicken-bin-path*"),t1);}

/* k1943 in setup-api#register-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1953,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t3,((C_word*)t0)[2]);}

/* k1951 in k1943 in setup-api#register-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("alist-cons");
((C_proc5)C_retrieve_symbol_proc(lf[76]))(5,*((C_word*)lf[76]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2],C_retrieve2(lf[11],"setup-api#*registered-programs*"));}

/* k1947 in k1943 in setup-api#register-program in k1937 in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[11] /* (set! setup-api#*registered-programs* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1822,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1826,a[2]=t1,a[3]=t4,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1923,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#setup-verbose-mode");
((C_proc2)C_retrieve_symbol_proc(lf[21]))(2,*((C_word*)lf[21]+1),t6);}

/* k1921 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1923,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[71]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1926,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t3,lf[73],t2);}
else{
t2=((C_word*)t0)[3];
f_1826(2,t2,C_SCHEME_UNDEFINED);}}

/* k1924 in k1921 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1929,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1927 in k1924 in k1921 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1929,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1932,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,lf[72],((C_word*)t0)[2]);}

/* k1930 in k1927 in k1924 in k1921 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1932(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-char/port");
t2=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1826,2,t0,t1);}
if(C_truep(C_i_listp(((C_word*)t0)[5]))){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1841,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li7),tmp=(C_word)a,a+=6,tmp);
C_trace("with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[64]))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
C_trace("create-temporary-file");
((C_proc2)C_retrieve_symbol_proc(lf[70]))(2,*((C_word*)lf[70]+1),t2);}}

/* k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1883,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,2,t1,t1);
C_trace("setup-api#patch");
((C_proc5)C_retrieve_symbol_proc(lf[59]))(5,*((C_word*)lf[59]+1),t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1883,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[69]))(2,*((C_word*)lf[69]+1),t2);}

/* k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),t2,C_retrieve2(lf[33],"setup-api#*move-command*"),t1);}

/* k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1916,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}

/* k1914 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1897 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[68]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k1900 in k1897 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1912,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-api#shellpath");
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,((C_word*)t0)[2]);}

/* k1910 in k1900 in k1897 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in k1881 in k1878 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-api#$system");
f_5767(((C_word*)t0)[2],t1);}

/* a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1841,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
C_trace("with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[63]))(4,*((C_word*)lf[63]+1),t1,t2,t3);}

/* a1850 in a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li5),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1857(t5,t1);}

/* loop in a1850 in a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_1857(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1857,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("read-line");
((C_proc2)C_retrieve_symbol_proc(lf[62]))(2,*((C_word*)lf[62]+1),t2);}

/* k1859 in loop in a1850 in a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("string-substitute");
((C_proc6)C_retrieve_symbol_proc(lf[61]))(6,*((C_word*)lf[61]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE);}}

/* k1875 in k1859 in loop in a1850 in a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("write-line");
((C_proc3)C_retrieve_symbol_proc(lf[60]))(3,*((C_word*)lf[60]+1),((C_word*)t0)[2],t1);}

/* k1868 in k1859 in loop in a1850 in a1840 in k1824 in setup-api#patch in k1818 in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("loop133");
t2=((C_word*)((C_word*)t0)[3])[1];
f_1857(t2,((C_word*)t0)[2]);}

/* setup-api#sudo-install in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1797(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1797r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1797r(t0,t1,t2);}}

static void C_ccall f_1797r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
if(C_truep(C_i_nullp(t2))){
t3=C_retrieve2(lf[9],"setup-api#*sudo*");
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_car(t2))){
t3=t1;
t4=lf[9] /* setup-api#*sudo* */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t5=lf[9] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
C_trace("print");
((C_proc3)C_retrieve_proc(*((C_word*)lf[50]+1)))(3,*((C_word*)lf[50]+1),t3,lf[51]);}
else{
t5=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[52]);
t6=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[53]);
t7=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[54]);
t8=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[55]);
t9=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[56]);
t10=C_mutate(&lf[36] /* (set! setup-api#*mkdir-command* ...) */,lf[57]);
t11=t3;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}}
else{
C_trace("setup-api#user-install-setup");
f_1771(t1);}}}

/* setup-api#user-install-setup in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_fcall f_1771(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1771,NULL,1,t1);}
t2=lf[9] /* setup-api#*sudo* */ =C_SCHEME_FALSE;;
if(C_truep(C_retrieve2(lf[10],"setup-api#*windows-shell*"))){
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[38]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[39]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[40]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[41]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[42]);
t9=t3;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t3=t1;
t4=C_mutate(&lf[31] /* (set! setup-api#*copy-command* ...) */,lf[43]);
t5=C_mutate(&lf[32] /* (set! setup-api#*remove-command* ...) */,lf[44]);
t6=C_mutate(&lf[33] /* (set! setup-api#*move-command* ...) */,lf[45]);
t7=C_mutate(&lf[34] /* (set! setup-api#*chmod-command* ...) */,lf[46]);
t8=C_mutate(&lf[35] /* (set! setup-api#*ranlib-command* ...) */,lf[47]);
t9=C_mutate(&lf[36] /* (set! setup-api#*mkdir-command* ...) */,lf[48]);
t10=t3;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

/* setup-api#extra-nonfeatures in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1700r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1700r(t0,t1,t2);}}

static void C_ccall f_1700r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1704,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_1704(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_1704(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1702 in setup-api#extra-nonfeatures in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1710,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t2,C_retrieve(lf[30]),t1);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1708 in k1702 in setup-api#extra-nonfeatures in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#extra-features in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1668r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1668r(t0,t1,t2);}}

static void C_ccall f_1668r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1672,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_1672(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_1672(2,t5,C_i_car(t2));}
else{
C_trace("##sys#error");
t5=*((C_word*)lf[28]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1670 in setup-api#extra-features in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1678,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_apply(4,0,t2,C_retrieve(lf[27]),t1);}
else{
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1676 in k1670 in setup-api#extra-features in k1664 in k1660 in k1656 in k1652 in k1648 in k1644 in k1640 in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1678(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-api#shellpath in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1629(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1629,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("normalize-pathname");
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),t3,t2);}

/* k1635 in setup-api#shellpath in k1625 in k1622 in k1618 in k1615 in k1612 in k1608 in k1604 in k1601 in k1594 in k1590 in k1586 in k1582 in k1578 in k1573 in k1570 in k1567 in k1564 in k1561 in k1558 in k1555 in k1552 in k1549 in k1546 in k1543 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("qs");
((C_proc3)C_retrieve_symbol_proc(lf[17]))(3,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[586] = {
{"toplevel:setup_api_scm",(void*)C_toplevel},
{"f_1545:setup_api_scm",(void*)f_1545},
{"f_1548:setup_api_scm",(void*)f_1548},
{"f_1551:setup_api_scm",(void*)f_1551},
{"f_1554:setup_api_scm",(void*)f_1554},
{"f_1557:setup_api_scm",(void*)f_1557},
{"f_1560:setup_api_scm",(void*)f_1560},
{"f_1563:setup_api_scm",(void*)f_1563},
{"f_1566:setup_api_scm",(void*)f_1566},
{"f_1569:setup_api_scm",(void*)f_1569},
{"f_1572:setup_api_scm",(void*)f_1572},
{"f_1575:setup_api_scm",(void*)f_1575},
{"f_1580:setup_api_scm",(void*)f_1580},
{"f_1584:setup_api_scm",(void*)f_1584},
{"f_1588:setup_api_scm",(void*)f_1588},
{"f_1592:setup_api_scm",(void*)f_1592},
{"f_1596:setup_api_scm",(void*)f_1596},
{"f_5997:setup_api_scm",(void*)f_5997},
{"f_1603:setup_api_scm",(void*)f_1603},
{"f_1606:setup_api_scm",(void*)f_1606},
{"f_1610:setup_api_scm",(void*)f_1610},
{"f_1614:setup_api_scm",(void*)f_1614},
{"f_1617:setup_api_scm",(void*)f_1617},
{"f_1620:setup_api_scm",(void*)f_1620},
{"f_1624:setup_api_scm",(void*)f_1624},
{"f_1627:setup_api_scm",(void*)f_1627},
{"f_1642:setup_api_scm",(void*)f_1642},
{"f_1646:setup_api_scm",(void*)f_1646},
{"f_1650:setup_api_scm",(void*)f_1650},
{"f_1654:setup_api_scm",(void*)f_1654},
{"f_1658:setup_api_scm",(void*)f_1658},
{"f_1662:setup_api_scm",(void*)f_1662},
{"f_1666:setup_api_scm",(void*)f_1666},
{"f_5974:setup_api_scm",(void*)f_5974},
{"f_1820:setup_api_scm",(void*)f_1820},
{"f_1939:setup_api_scm",(void*)f_1939},
{"f_5972:setup_api_scm",(void*)f_5972},
{"f_2011:setup_api_scm",(void*)f_2011},
{"f_5968:setup_api_scm",(void*)f_5968},
{"f_2014:setup_api_scm",(void*)f_2014},
{"f_5964:setup_api_scm",(void*)f_5964},
{"f_2017:setup_api_scm",(void*)f_2017},
{"f_5960:setup_api_scm",(void*)f_5960},
{"f_2020:setup_api_scm",(void*)f_2020},
{"f_5956:setup_api_scm",(void*)f_5956},
{"f_2023:setup_api_scm",(void*)f_2023},
{"f_5952:setup_api_scm",(void*)f_5952},
{"f_2026:setup_api_scm",(void*)f_2026},
{"f_5948:setup_api_scm",(void*)f_5948},
{"f_2029:setup_api_scm",(void*)f_2029},
{"f_3162:setup_api_scm",(void*)f_3162},
{"f_3166:setup_api_scm",(void*)f_3166},
{"f_5839:setup_api_scm",(void*)f_5839},
{"f_5855:setup_api_scm",(void*)f_5855},
{"f_5892:setup_api_scm",(void*)f_5892},
{"f_5885:setup_api_scm",(void*)f_5885},
{"f_5889:setup_api_scm",(void*)f_5889},
{"f_5862:setup_api_scm",(void*)f_5862},
{"f_5428:setup_api_scm",(void*)f_5428},
{"f_5837:setup_api_scm",(void*)f_5837},
{"f_5817:setup_api_scm",(void*)f_5817},
{"f_5823:setup_api_scm",(void*)f_5823},
{"f_5834:setup_api_scm",(void*)f_5834},
{"f_5827:setup_api_scm",(void*)f_5827},
{"f_5767:setup_api_scm",(void*)f_5767},
{"f_5812:setup_api_scm",(void*)f_5812},
{"f_5771:setup_api_scm",(void*)f_5771},
{"f_5784:setup_api_scm",(void*)f_5784},
{"f_5787:setup_api_scm",(void*)f_5787},
{"f_5790:setup_api_scm",(void*)f_5790},
{"f_5793:setup_api_scm",(void*)f_5793},
{"f_5796:setup_api_scm",(void*)f_5796},
{"f_5799:setup_api_scm",(void*)f_5799},
{"f_5802:setup_api_scm",(void*)f_5802},
{"f_5805:setup_api_scm",(void*)f_5805},
{"f_5808:setup_api_scm",(void*)f_5808},
{"f_5692:setup_api_scm",(void*)f_5692},
{"f_5696:setup_api_scm",(void*)f_5696},
{"f_5743:setup_api_scm",(void*)f_5743},
{"f_5718:setup_api_scm",(void*)f_5718},
{"f_5728:setup_api_scm",(void*)f_5728},
{"f_5702:setup_api_scm",(void*)f_5702},
{"f_5709:setup_api_scm",(void*)f_5709},
{"f_5519:setup_api_scm",(void*)f_5519},
{"f_5523:setup_api_scm",(void*)f_5523},
{"f_5671:setup_api_scm",(void*)f_5671},
{"f_5605:setup_api_scm",(void*)f_5605},
{"f_5609:setup_api_scm",(void*)f_5609},
{"f_5617:setup_api_scm",(void*)f_5617},
{"f_5656:setup_api_scm",(void*)f_5656},
{"f_5625:setup_api_scm",(void*)f_5625},
{"f_5638:setup_api_scm",(void*)f_5638},
{"f_5644:setup_api_scm",(void*)f_5644},
{"f_5612:setup_api_scm",(void*)f_5612},
{"f_5546:setup_api_scm",(void*)f_5546},
{"f_5561:setup_api_scm",(void*)f_5561},
{"f_5590:setup_api_scm",(void*)f_5590},
{"f_5596:setup_api_scm",(void*)f_5596},
{"f_5567:setup_api_scm",(void*)f_5567},
{"f_5575:setup_api_scm",(void*)f_5575},
{"f_5578:setup_api_scm",(void*)f_5578},
{"f_5588:setup_api_scm",(void*)f_5588},
{"f_5581:setup_api_scm",(void*)f_5581},
{"f_5584:setup_api_scm",(void*)f_5584},
{"f_5552:setup_api_scm",(void*)f_5552},
{"f_5558:setup_api_scm",(void*)f_5558},
{"f_5541:setup_api_scm",(void*)f_5541},
{"f_5484:setup_api_scm",(void*)f_5484},
{"f_5488:setup_api_scm",(void*)f_5488},
{"f_5495:setup_api_scm",(void*)f_5495},
{"f_5440:setup_api_scm",(void*)f_5440},
{"f_5444:setup_api_scm",(void*)f_5444},
{"f_5463:setup_api_scm",(void*)f_5463},
{"f_5453:setup_api_scm",(void*)f_5453},
{"f_5430:setup_api_scm",(void*)f_5430},
{"f_5438:setup_api_scm",(void*)f_5438},
{"f_5229:setup_api_scm",(void*)f_5229},
{"f_5294:setup_api_scm",(void*)f_5294},
{"f_5298:setup_api_scm",(void*)f_5298},
{"f_5300:setup_api_scm",(void*)f_5300},
{"f_5380:setup_api_scm",(void*)f_5380},
{"f_5232:setup_api_scm",(void*)f_5232},
{"f_5287:setup_api_scm",(void*)f_5287},
{"f_5240:setup_api_scm",(void*)f_5240},
{"f_5242:setup_api_scm",(void*)f_5242},
{"f_5273:setup_api_scm",(void*)f_5273},
{"f_5252:setup_api_scm",(void*)f_5252},
{"f_5207:setup_api_scm",(void*)f_5207},
{"f_5215:setup_api_scm",(void*)f_5215},
{"f_5218:setup_api_scm",(void*)f_5218},
{"f_5221:setup_api_scm",(void*)f_5221},
{"f_5224:setup_api_scm",(void*)f_5224},
{"f_5227:setup_api_scm",(void*)f_5227},
{"f_5148:setup_api_scm",(void*)f_5148},
{"f_5156:setup_api_scm",(void*)f_5156},
{"f_5159:setup_api_scm",(void*)f_5159},
{"f_5162:setup_api_scm",(void*)f_5162},
{"f_5165:setup_api_scm",(void*)f_5165},
{"f_5168:setup_api_scm",(void*)f_5168},
{"f_5171:setup_api_scm",(void*)f_5171},
{"f_5174:setup_api_scm",(void*)f_5174},
{"f_5177:setup_api_scm",(void*)f_5177},
{"f_5180:setup_api_scm",(void*)f_5180},
{"f_5183:setup_api_scm",(void*)f_5183},
{"f_5186:setup_api_scm",(void*)f_5186},
{"f_5189:setup_api_scm",(void*)f_5189},
{"f_5192:setup_api_scm",(void*)f_5192},
{"f_5195:setup_api_scm",(void*)f_5195},
{"f_5198:setup_api_scm",(void*)f_5198},
{"f_5201:setup_api_scm",(void*)f_5201},
{"f_5205:setup_api_scm",(void*)f_5205},
{"f_5027:setup_api_scm",(void*)f_5027},
{"f_5033:setup_api_scm",(void*)f_5033},
{"f_5046:setup_api_scm",(void*)f_5046},
{"f_5058:setup_api_scm",(void*)f_5058},
{"f_5064:setup_api_scm",(void*)f_5064},
{"f_5104:setup_api_scm",(void*)f_5104},
{"f_5115:setup_api_scm",(void*)f_5115},
{"f_5119:setup_api_scm",(void*)f_5119},
{"f_5079:setup_api_scm",(void*)f_5079},
{"f_5086:setup_api_scm",(void*)f_5086},
{"f_5089:setup_api_scm",(void*)f_5089},
{"f_5092:setup_api_scm",(void*)f_5092},
{"f_5095:setup_api_scm",(void*)f_5095},
{"f_5098:setup_api_scm",(void*)f_5098},
{"f_4946:setup_api_scm",(void*)f_4946},
{"f_4950:setup_api_scm",(void*)f_4950},
{"f_4957:setup_api_scm",(void*)f_4957},
{"f_4960:setup_api_scm",(void*)f_4960},
{"f_4963:setup_api_scm",(void*)f_4963},
{"f_4966:setup_api_scm",(void*)f_4966},
{"f_4969:setup_api_scm",(void*)f_4969},
{"f_4972:setup_api_scm",(void*)f_4972},
{"f_4975:setup_api_scm",(void*)f_4975},
{"f_4978:setup_api_scm",(void*)f_4978},
{"f_4981:setup_api_scm",(void*)f_4981},
{"f_4984:setup_api_scm",(void*)f_4984},
{"f_5003:setup_api_scm",(void*)f_5003},
{"f_4987:setup_api_scm",(void*)f_4987},
{"f_4990:setup_api_scm",(void*)f_4990},
{"f_4993:setup_api_scm",(void*)f_4993},
{"f_4996:setup_api_scm",(void*)f_4996},
{"f_4999:setup_api_scm",(void*)f_4999},
{"f_4914:setup_api_scm",(void*)f_4914},
{"f_4944:setup_api_scm",(void*)f_4944},
{"f_4921:setup_api_scm",(void*)f_4921},
{"f_4928:setup_api_scm",(void*)f_4928},
{"f_4931:setup_api_scm",(void*)f_4931},
{"f_4934:setup_api_scm",(void*)f_4934},
{"f_4937:setup_api_scm",(void*)f_4937},
{"f_4940:setup_api_scm",(void*)f_4940},
{"f_4744:setup_api_scm",(void*)f_4744},
{"f_4908:setup_api_scm",(void*)f_4908},
{"f_4751:setup_api_scm",(void*)f_4751},
{"f_4905:setup_api_scm",(void*)f_4905},
{"f_4754:setup_api_scm",(void*)f_4754},
{"f_4902:setup_api_scm",(void*)f_4902},
{"f_4757:setup_api_scm",(void*)f_4757},
{"f_4896:setup_api_scm",(void*)f_4896},
{"f_4760:setup_api_scm",(void*)f_4760},
{"f_4893:setup_api_scm",(void*)f_4893},
{"f_4763:setup_api_scm",(void*)f_4763},
{"f_4766:setup_api_scm",(void*)f_4766},
{"f_4769:setup_api_scm",(void*)f_4769},
{"f_4887:setup_api_scm",(void*)f_4887},
{"f_4772:setup_api_scm",(void*)f_4772},
{"f_4874:setup_api_scm",(void*)f_4874},
{"f_4860:setup_api_scm",(void*)f_4860},
{"f_4863:setup_api_scm",(void*)f_4863},
{"f_4775:setup_api_scm",(void*)f_4775},
{"f_4778:setup_api_scm",(void*)f_4778},
{"f_4789:setup_api_scm",(void*)f_4789},
{"f_4804:setup_api_scm",(void*)f_4804},
{"f_4836:setup_api_scm",(void*)f_4836},
{"f_4842:setup_api_scm",(void*)f_4842},
{"f_4810:setup_api_scm",(void*)f_4810},
{"f_4818:setup_api_scm",(void*)f_4818},
{"f_4821:setup_api_scm",(void*)f_4821},
{"f_4824:setup_api_scm",(void*)f_4824},
{"f_4834:setup_api_scm",(void*)f_4834},
{"f_4827:setup_api_scm",(void*)f_4827},
{"f_4830:setup_api_scm",(void*)f_4830},
{"f_4795:setup_api_scm",(void*)f_4795},
{"f_4801:setup_api_scm",(void*)f_4801},
{"f_4781:setup_api_scm",(void*)f_4781},
{"f_4784:setup_api_scm",(void*)f_4784},
{"f_4691:setup_api_scm",(void*)f_4691},
{"f_4695:setup_api_scm",(void*)f_4695},
{"f_4704:setup_api_scm",(void*)f_4704},
{"f_4716:setup_api_scm",(void*)f_4716},
{"f_4742:setup_api_scm",(void*)f_4742},
{"f_4710:setup_api_scm",(void*)f_4710},
{"f_4698:setup_api_scm",(void*)f_4698},
{"f_4619:setup_api_scm",(void*)f_4619},
{"f_4623:setup_api_scm",(void*)f_4623},
{"f_4635:setup_api_scm",(void*)f_4635},
{"f_4641:setup_api_scm",(void*)f_4641},
{"f_4651:setup_api_scm",(void*)f_4651},
{"f_4654:setup_api_scm",(void*)f_4654},
{"f_4657:setup_api_scm",(void*)f_4657},
{"f_4660:setup_api_scm",(void*)f_4660},
{"f_4626:setup_api_scm",(void*)f_4626},
{"f_4629:setup_api_scm",(void*)f_4629},
{"f_4451:setup_api_scm",(void*)f_4451},
{"f_4455:setup_api_scm",(void*)f_4455},
{"f_4461:setup_api_scm",(void*)f_4461},
{"f_4464:setup_api_scm",(void*)f_4464},
{"f_4467:setup_api_scm",(void*)f_4467},
{"f_4588:setup_api_scm",(void*)f_4588},
{"f_4470:setup_api_scm",(void*)f_4470},
{"f_4508:setup_api_scm",(void*)f_4508},
{"f_4580:setup_api_scm",(void*)f_4580},
{"f_4535:setup_api_scm",(void*)f_4535},
{"f_4542:setup_api_scm",(void*)f_4542},
{"f_4545:setup_api_scm",(void*)f_4545},
{"f_4571:setup_api_scm",(void*)f_4571},
{"f_4548:setup_api_scm",(void*)f_4548},
{"f_4473:setup_api_scm",(void*)f_4473},
{"f_4506:setup_api_scm",(void*)f_4506},
{"f_4476:setup_api_scm",(void*)f_4476},
{"f_4483:setup_api_scm",(void*)f_4483},
{"f_4228:setup_api_scm",(void*)f_4228},
{"f_4232:setup_api_scm",(void*)f_4232},
{"f_4248:setup_api_scm",(void*)f_4248},
{"f_4251:setup_api_scm",(void*)f_4251},
{"f_4254:setup_api_scm",(void*)f_4254},
{"f_4420:setup_api_scm",(void*)f_4420},
{"f_4257:setup_api_scm",(void*)f_4257},
{"f_4353:setup_api_scm",(void*)f_4353},
{"f_4412:setup_api_scm",(void*)f_4412},
{"f_4380:setup_api_scm",(void*)f_4380},
{"f_4394:setup_api_scm",(void*)f_4394},
{"f_4398:setup_api_scm",(void*)f_4398},
{"f_4260:setup_api_scm",(void*)f_4260},
{"f_4272:setup_api_scm",(void*)f_4272},
{"f_4344:setup_api_scm",(void*)f_4344},
{"f_4299:setup_api_scm",(void*)f_4299},
{"f_4306:setup_api_scm",(void*)f_4306},
{"f_4309:setup_api_scm",(void*)f_4309},
{"f_4335:setup_api_scm",(void*)f_4335},
{"f_4312:setup_api_scm",(void*)f_4312},
{"f_4263:setup_api_scm",(void*)f_4263},
{"f_4270:setup_api_scm",(void*)f_4270},
{"f_4234:setup_api_scm",(void*)f_4234},
{"f_3669:setup_api_scm",(void*)f_3669},
{"f_3676:setup_api_scm",(void*)f_3676},
{"f_4000:setup_api_scm",(void*)f_4000},
{"f_4004:setup_api_scm",(void*)f_4004},
{"f_4010:setup_api_scm",(void*)f_4010},
{"f_4013:setup_api_scm",(void*)f_4013},
{"f_4016:setup_api_scm",(void*)f_4016},
{"f_4019:setup_api_scm",(void*)f_4019},
{"f_4031:setup_api_scm",(void*)f_4031},
{"f_4193:setup_api_scm",(void*)f_4193},
{"f_4058:setup_api_scm",(void*)f_4058},
{"f_4065:setup_api_scm",(void*)f_4065},
{"f_4184:setup_api_scm",(void*)f_4184},
{"f_4155:setup_api_scm",(void*)f_4155},
{"f_4174:setup_api_scm",(void*)f_4174},
{"f_4068:setup_api_scm",(void*)f_4068},
{"f_4071:setup_api_scm",(void*)f_4071},
{"f_4152:setup_api_scm",(void*)f_4152},
{"f_4074:setup_api_scm",(void*)f_4074},
{"f_4129:setup_api_scm",(void*)f_4129},
{"f_4121:setup_api_scm",(void*)f_4121},
{"f_4086:setup_api_scm",(void*)f_4086},
{"f_4105:setup_api_scm",(void*)f_4105},
{"f_4080:setup_api_scm",(void*)f_4080},
{"f_4022:setup_api_scm",(void*)f_4022},
{"f_4029:setup_api_scm",(void*)f_4029},
{"f_3777:setup_api_scm",(void*)f_3777},
{"f_3997:setup_api_scm",(void*)f_3997},
{"f_3781:setup_api_scm",(void*)f_3781},
{"f_3994:setup_api_scm",(void*)f_3994},
{"f_3784:setup_api_scm",(void*)f_3784},
{"f_3787:setup_api_scm",(void*)f_3787},
{"f_3790:setup_api_scm",(void*)f_3790},
{"f_3793:setup_api_scm",(void*)f_3793},
{"f_3796:setup_api_scm",(void*)f_3796},
{"f_3799:setup_api_scm",(void*)f_3799},
{"f_3802:setup_api_scm",(void*)f_3802},
{"f_3805:setup_api_scm",(void*)f_3805},
{"f_3847:setup_api_scm",(void*)f_3847},
{"f_3855:setup_api_scm",(void*)f_3855},
{"f_3866:setup_api_scm",(void*)f_3866},
{"f_3859:setup_api_scm",(void*)f_3859},
{"f_3820:setup_api_scm",(void*)f_3820},
{"f_3843:setup_api_scm",(void*)f_3843},
{"f_3824:setup_api_scm",(void*)f_3824},
{"f_3816:setup_api_scm",(void*)f_3816},
{"f_3753:setup_api_scm",(void*)f_3753},
{"f_3725:setup_api_scm",(void*)f_3725},
{"f_3581:setup_api_scm",(void*)f_3581},
{"f_3587:setup_api_scm",(void*)f_3587},
{"f_3627:setup_api_scm",(void*)f_3627},
{"f_3630:setup_api_scm",(void*)f_3630},
{"f_3659:setup_api_scm",(void*)f_3659},
{"f_3597:setup_api_scm",(void*)f_3597},
{"f_3556:setup_api_scm",(void*)f_3556},
{"f_3576:setup_api_scm",(void*)f_3576},
{"f_3534:setup_api_scm",(void*)f_3534},
{"f_3554:setup_api_scm",(void*)f_3554},
{"f_3479:setup_api_scm",(void*)f_3479},
{"f_3486:setup_api_scm",(void*)f_3486},
{"f_3489:setup_api_scm",(void*)f_3489},
{"f_3508:setup_api_scm",(void*)f_3508},
{"f_3516:setup_api_scm",(void*)f_3516},
{"f_3333:setup_api_scm",(void*)f_3333},
{"f_3417:setup_api_scm",(void*)f_3417},
{"f_3408:setup_api_scm",(void*)f_3408},
{"f_3416:setup_api_scm",(void*)f_3416},
{"f_3335:setup_api_scm",(void*)f_3335},
{"f_3342:setup_api_scm",(void*)f_3342},
{"f_3473:setup_api_scm",(void*)f_3473},
{"f_3477:setup_api_scm",(void*)f_3477},
{"f_3391:setup_api_scm",(void*)f_3391},
{"f_3384:setup_api_scm",(void*)f_3384},
{"f_3345:setup_api_scm",(void*)f_3345},
{"f_3348:setup_api_scm",(void*)f_3348},
{"f_3367:setup_api_scm",(void*)f_3367},
{"f_3375:setup_api_scm",(void*)f_3375},
{"f_3351:setup_api_scm",(void*)f_3351},
{"f_3204:setup_api_scm",(void*)f_3204},
{"f_3331:setup_api_scm",(void*)f_3331},
{"f_3327:setup_api_scm",(void*)f_3327},
{"f_3301:setup_api_scm",(void*)f_3301},
{"f_3304:setup_api_scm",(void*)f_3304},
{"f_3307:setup_api_scm",(void*)f_3307},
{"f_3310:setup_api_scm",(void*)f_3310},
{"f_3313:setup_api_scm",(void*)f_3313},
{"f_3316:setup_api_scm",(void*)f_3316},
{"f_3211:setup_api_scm",(void*)f_3211},
{"f_3214:setup_api_scm",(void*)f_3214},
{"f_3298:setup_api_scm",(void*)f_3298},
{"f_3133:setup_api_scm",(void*)f_3133},
{"f_3217:setup_api_scm",(void*)f_3217},
{"f_3290:setup_api_scm",(void*)f_3290},
{"f_3249:setup_api_scm",(void*)f_3249},
{"f_3281:setup_api_scm",(void*)f_3281},
{"f_3252:setup_api_scm",(void*)f_3252},
{"f_3271:setup_api_scm",(void*)f_3271},
{"f_3279:setup_api_scm",(void*)f_3279},
{"f_3220:setup_api_scm",(void*)f_3220},
{"f_3246:setup_api_scm",(void*)f_3246},
{"f_5917:setup_api_scm",(void*)f_5917},
{"f_5921:setup_api_scm",(void*)f_5921},
{"f_5944:setup_api_scm",(void*)f_5944},
{"f_5909:setup_api_scm",(void*)f_5909},
{"f_5913:setup_api_scm",(void*)f_5913},
{"f_3180:setup_api_scm",(void*)f_3180},
{"f_3187:setup_api_scm",(void*)f_3187},
{"f_3190:setup_api_scm",(void*)f_3190},
{"f_3193:setup_api_scm",(void*)f_3193},
{"f_3196:setup_api_scm",(void*)f_3196},
{"f_3167:setup_api_scm",(void*)f_3167},
{"f_3171:setup_api_scm",(void*)f_3171},
{"f_3086:setup_api_scm",(void*)f_3086},
{"f_3118:setup_api_scm",(void*)f_3118},
{"f_2665:setup_api_scm",(void*)f_2665},
{"f_3084:setup_api_scm",(void*)f_3084},
{"f_2669:setup_api_scm",(void*)f_2669},
{"f_2497:setup_api_scm",(void*)f_2497},
{"f_2506:setup_api_scm",(void*)f_2506},
{"f_2511:setup_api_scm",(void*)f_2511},
{"f_2518:setup_api_scm",(void*)f_2518},
{"f_2521:setup_api_scm",(void*)f_2521},
{"f_2530:setup_api_scm",(void*)f_2530},
{"f_2533:setup_api_scm",(void*)f_2533},
{"f_2572:setup_api_scm",(void*)f_2572},
{"f_2580:setup_api_scm",(void*)f_2580},
{"f_2542:setup_api_scm",(void*)f_2542},
{"f_2672:setup_api_scm",(void*)f_2672},
{"f_2657:setup_api_scm",(void*)f_2657},
{"f_2675:setup_api_scm",(void*)f_2675},
{"f_2680:setup_api_scm",(void*)f_2680},
{"f_2684:setup_api_scm",(void*)f_2684},
{"f_3051:setup_api_scm",(void*)f_3051},
{"f_3066:setup_api_scm",(void*)f_3066},
{"f_3059:setup_api_scm",(void*)f_3059},
{"f_3046:setup_api_scm",(void*)f_3046},
{"f_2980:setup_api_scm",(void*)f_2980},
{"f_2986:setup_api_scm",(void*)f_2986},
{"f_2993:setup_api_scm",(void*)f_2993},
{"f_2995:setup_api_scm",(void*)f_2995},
{"f_3007:setup_api_scm",(void*)f_3007},
{"f_3010:setup_api_scm",(void*)f_3010},
{"f_3016:setup_api_scm",(void*)f_3016},
{"f_2686:setup_api_scm",(void*)f_2686},
{"f_2392:setup_api_scm",(void*)f_2392},
{"f_2405:setup_api_scm",(void*)f_2405},
{"f_2411:setup_api_scm",(void*)f_2411},
{"f_2383:setup_api_scm",(void*)f_2383},
{"f_2690:setup_api_scm",(void*)f_2690},
{"f_2693:setup_api_scm",(void*)f_2693},
{"f_2974:setup_api_scm",(void*)f_2974},
{"f_2696:setup_api_scm",(void*)f_2696},
{"f_2956:setup_api_scm",(void*)f_2956},
{"f_2959:setup_api_scm",(void*)f_2959},
{"f_2962:setup_api_scm",(void*)f_2962},
{"f_2965:setup_api_scm",(void*)f_2965},
{"f_2968:setup_api_scm",(void*)f_2968},
{"f_2699:setup_api_scm",(void*)f_2699},
{"f_2944:setup_api_scm",(void*)f_2944},
{"f_2947:setup_api_scm",(void*)f_2947},
{"f_2950:setup_api_scm",(void*)f_2950},
{"f_2953:setup_api_scm",(void*)f_2953},
{"f_2929:setup_api_scm",(void*)f_2929},
{"f_2930:setup_api_scm",(void*)f_2930},
{"f_2708:setup_api_scm",(void*)f_2708},
{"f_2883:setup_api_scm",(void*)f_2883},
{"f_2887:setup_api_scm",(void*)f_2887},
{"f_2903:setup_api_scm",(void*)f_2903},
{"f_2910:setup_api_scm",(void*)f_2910},
{"f_2913:setup_api_scm",(void*)f_2913},
{"f_2916:setup_api_scm",(void*)f_2916},
{"f_2919:setup_api_scm",(void*)f_2919},
{"f_2922:setup_api_scm",(void*)f_2922},
{"f_2925:setup_api_scm",(void*)f_2925},
{"f_2890:setup_api_scm",(void*)f_2890},
{"f_2900:setup_api_scm",(void*)f_2900},
{"f_2714:setup_api_scm",(void*)f_2714},
{"f_2816:setup_api_scm",(void*)f_2816},
{"f_2819:setup_api_scm",(void*)f_2819},
{"f_2822:setup_api_scm",(void*)f_2822},
{"f_2825:setup_api_scm",(void*)f_2825},
{"f_2828:setup_api_scm",(void*)f_2828},
{"f_2860:setup_api_scm",(void*)f_2860},
{"f_2863:setup_api_scm",(void*)f_2863},
{"f_2866:setup_api_scm",(void*)f_2866},
{"f_2869:setup_api_scm",(void*)f_2869},
{"f_2872:setup_api_scm",(void*)f_2872},
{"f_2875:setup_api_scm",(void*)f_2875},
{"f_2878:setup_api_scm",(void*)f_2878},
{"f_2838:setup_api_scm",(void*)f_2838},
{"f_2831:setup_api_scm",(void*)f_2831},
{"f_2733:setup_api_scm",(void*)f_2733},
{"f_2741:setup_api_scm",(void*)f_2741},
{"f_2788:setup_api_scm",(void*)f_2788},
{"f_2803:setup_api_scm",(void*)f_2803},
{"f_2809:setup_api_scm",(void*)f_2809},
{"f_2794:setup_api_scm",(void*)f_2794},
{"f_2747:setup_api_scm",(void*)f_2747},
{"f_2753:setup_api_scm",(void*)f_2753},
{"f_2757:setup_api_scm",(void*)f_2757},
{"f_2760:setup_api_scm",(void*)f_2760},
{"f_2763:setup_api_scm",(void*)f_2763},
{"f_2779:setup_api_scm",(void*)f_2779},
{"f_2776:setup_api_scm",(void*)f_2776},
{"f_2766:setup_api_scm",(void*)f_2766},
{"f_2769:setup_api_scm",(void*)f_2769},
{"f_2736:setup_api_scm",(void*)f_2736},
{"f_2459:setup_api_scm",(void*)f_2459},
{"f_2467:setup_api_scm",(void*)f_2467},
{"f_2470:setup_api_scm",(void*)f_2470},
{"f_2473:setup_api_scm",(void*)f_2473},
{"f_2476:setup_api_scm",(void*)f_2476},
{"f_2479:setup_api_scm",(void*)f_2479},
{"f_2482:setup_api_scm",(void*)f_2482},
{"f_2485:setup_api_scm",(void*)f_2485},
{"f_2437:setup_api_scm",(void*)f_2437},
{"f_2445:setup_api_scm",(void*)f_2445},
{"f_2448:setup_api_scm",(void*)f_2448},
{"f_2451:setup_api_scm",(void*)f_2451},
{"f_2454:setup_api_scm",(void*)f_2454},
{"f_2457:setup_api_scm",(void*)f_2457},
{"f_2230:setup_api_scm",(void*)f_2230},
{"f_2346:setup_api_scm",(void*)f_2346},
{"f_2258:setup_api_scm",(void*)f_2258},
{"f_2287:setup_api_scm",(void*)f_2287},
{"f_2237:setup_api_scm",(void*)f_2237},
{"f_2199:setup_api_scm",(void*)f_2199},
{"f_2049:setup_api_scm",(void*)f_2049},
{"f_2188:setup_api_scm",(void*)f_2188},
{"f_2195:setup_api_scm",(void*)f_2195},
{"f_2053:setup_api_scm",(void*)f_2053},
{"f_2182:setup_api_scm",(void*)f_2182},
{"f_2179:setup_api_scm",(void*)f_2179},
{"f_2176:setup_api_scm",(void*)f_2176},
{"f_2129:setup_api_scm",(void*)f_2129},
{"f_2131:setup_api_scm",(void*)f_2131},
{"f_2166:setup_api_scm",(void*)f_2166},
{"f_2169:setup_api_scm",(void*)f_2169},
{"f_2073:setup_api_scm",(void*)f_2073},
{"f_2081:setup_api_scm",(void*)f_2081},
{"f_2083:setup_api_scm",(void*)f_2083},
{"f_2118:setup_api_scm",(void*)f_2118},
{"f_2121:setup_api_scm",(void*)f_2121},
{"f_2077:setup_api_scm",(void*)f_2077},
{"f_2069:setup_api_scm",(void*)f_2069},
{"f_2045:setup_api_scm",(void*)f_2045},
{"f_2248:setup_api_scm",(void*)f_2248},
{"f_2375:setup_api_scm",(void*)f_2375},
{"f_2298:setup_api_scm",(void*)f_2298},
{"f_2300:setup_api_scm",(void*)f_2300},
{"f_2318:setup_api_scm",(void*)f_2318},
{"f_2321:setup_api_scm",(void*)f_2321},
{"f_2324:setup_api_scm",(void*)f_2324},
{"f_2327:setup_api_scm",(void*)f_2327},
{"f_2312:setup_api_scm",(void*)f_2312},
{"f_2333:setup_api_scm",(void*)f_2333},
{"f_2204:setup_api_scm",(void*)f_2204},
{"f_2228:setup_api_scm",(void*)f_2228},
{"f_2211:setup_api_scm",(void*)f_2211},
{"f_2000:setup_api_scm",(void*)f_2000},
{"f_2008:setup_api_scm",(void*)f_2008},
{"f_1981:setup_api_scm",(void*)f_1981},
{"f_1985:setup_api_scm",(void*)f_1985},
{"f_1941:setup_api_scm",(void*)f_1941},
{"f_1963:setup_api_scm",(void*)f_1963},
{"f_1945:setup_api_scm",(void*)f_1945},
{"f_1953:setup_api_scm",(void*)f_1953},
{"f_1949:setup_api_scm",(void*)f_1949},
{"f_1822:setup_api_scm",(void*)f_1822},
{"f_1923:setup_api_scm",(void*)f_1923},
{"f_1926:setup_api_scm",(void*)f_1926},
{"f_1929:setup_api_scm",(void*)f_1929},
{"f_1932:setup_api_scm",(void*)f_1932},
{"f_1826:setup_api_scm",(void*)f_1826},
{"f_1880:setup_api_scm",(void*)f_1880},
{"f_1883:setup_api_scm",(void*)f_1883},
{"f_1890:setup_api_scm",(void*)f_1890},
{"f_1893:setup_api_scm",(void*)f_1893},
{"f_1896:setup_api_scm",(void*)f_1896},
{"f_1916:setup_api_scm",(void*)f_1916},
{"f_1899:setup_api_scm",(void*)f_1899},
{"f_1902:setup_api_scm",(void*)f_1902},
{"f_1912:setup_api_scm",(void*)f_1912},
{"f_1905:setup_api_scm",(void*)f_1905},
{"f_1908:setup_api_scm",(void*)f_1908},
{"f_1841:setup_api_scm",(void*)f_1841},
{"f_1851:setup_api_scm",(void*)f_1851},
{"f_1857:setup_api_scm",(void*)f_1857},
{"f_1861:setup_api_scm",(void*)f_1861},
{"f_1877:setup_api_scm",(void*)f_1877},
{"f_1870:setup_api_scm",(void*)f_1870},
{"f_1797:setup_api_scm",(void*)f_1797},
{"f_1771:setup_api_scm",(void*)f_1771},
{"f_1700:setup_api_scm",(void*)f_1700},
{"f_1704:setup_api_scm",(void*)f_1704},
{"f_1710:setup_api_scm",(void*)f_1710},
{"f_1668:setup_api_scm",(void*)f_1668},
{"f_1672:setup_api_scm",(void*)f_1672},
{"f_1678:setup_api_scm",(void*)f_1678},
{"f_1629:setup_api_scm",(void*)f_1629},
{"f_1637:setup_api_scm",(void*)f_1637},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
