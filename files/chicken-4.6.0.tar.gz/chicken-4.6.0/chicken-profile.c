/* Generated from chicken-profile.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-profile.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file chicken-profile.c
   used units: library eval srfi_1 srfi_13 srfi_69 posix utils
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[90];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_328)
static void C_ccall f_328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_331)
static void C_ccall f_331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_337)
static void C_ccall f_337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_343)
static void C_ccall f_343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_346)
static void C_ccall f_346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_fcall f_401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_603)
static void C_fcall f_603(C_word t0,C_word t1) C_noret;
C_noret_decl(f_597)
static void C_ccall f_597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_789)
static void C_ccall f_789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_793)
static void C_ccall f_793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_fcall f_754(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_556)
static void C_ccall f_556(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_539)
static void C_ccall f_539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_516)
static void C_ccall f_516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_475)
static void C_fcall f_475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_fcall f_456(C_word t0,C_word t1) C_noret;
C_noret_decl(f_418)
static void C_ccall f_418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_436)
static void C_ccall f_436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_444)
static void C_ccall f_444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_ccall f_448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_421)
static void C_ccall f_421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_411)
static void C_fcall f_411(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1061)
static void C_ccall f_1061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1481)
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1499)
static void C_fcall f_1499(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1506)
static void C_fcall f_1506(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1452)
static void C_ccall f_1452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1070)
static void C_ccall f_1070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1444)
static void C_ccall f_1444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_fcall f_1073(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1330)
static void C_fcall f_1330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_ccall f_1381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_ccall f_1389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1393)
static void C_ccall f_1393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1283)
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1232)
static void C_ccall f_1232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1234)
static void C_fcall f_1234(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_fcall f_1247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1169)
static void C_ccall f_1169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1202)
static void C_ccall f_1202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1172)
static void C_ccall f_1172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_fcall f_1177(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1187)
static void C_ccall f_1187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_fcall f_1091(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1105)
static void C_fcall f_1105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1112)
static void C_fcall f_1112(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_fcall f_1118(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1548)
static void C_ccall f_1548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1001)
static void C_fcall f_1001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1012)
static void C_ccall f_1012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_953)
static void C_fcall f_953(C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_fcall f_948(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_923)
static void C_fcall f_923(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_943)
static void C_ccall f_943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_820)
static void C_ccall f_820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_822)
static void C_fcall f_822(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_857)
static void C_fcall f_857(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_867)
static void C_fcall f_867(C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_fcall f_870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_847)
static void C_ccall f_847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_832)
static void C_ccall f_832(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_730)
static void C_ccall f_730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_734)
static void C_ccall f_734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_664)
static void C_ccall f_664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_629)
static void C_ccall f_629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_354)
static void C_fcall f_354(C_word t0) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_358)
static void C_ccall f_358(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_401)
static void C_fcall trf_401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_401(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_401(t0,t1,t2);}

C_noret_decl(trf_603)
static void C_fcall trf_603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_603(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_603(t0,t1);}

C_noret_decl(trf_754)
static void C_fcall trf_754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_754(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_754(t0,t1,t2);}

C_noret_decl(trf_475)
static void C_fcall trf_475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_475(t0,t1);}

C_noret_decl(trf_456)
static void C_fcall trf_456(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_456(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_456(t0,t1);}

C_noret_decl(trf_411)
static void C_fcall trf_411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_411(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_411(t0,t1);}

C_noret_decl(trf_1454)
static void C_fcall trf_1454(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1454(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1454(t0,t1,t2);}

C_noret_decl(trf_1481)
static void C_fcall trf_1481(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1481(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1481(t0,t1,t2);}

C_noret_decl(trf_1499)
static void C_fcall trf_1499(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1499(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1499(t0,t1);}

C_noret_decl(trf_1506)
static void C_fcall trf_1506(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1506(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1506(t0,t1);}

C_noret_decl(trf_1073)
static void C_fcall trf_1073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1073(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1073(t0,t1);}

C_noret_decl(trf_1330)
static void C_fcall trf_1330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1330(t0,t1,t2);}

C_noret_decl(trf_1283)
static void C_fcall trf_1283(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1283(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1283(t0,t1,t2);}

C_noret_decl(trf_1234)
static void C_fcall trf_1234(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1234(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1234(t0,t1,t2,t3);}

C_noret_decl(trf_1247)
static void C_fcall trf_1247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1247(t0,t1);}

C_noret_decl(trf_1177)
static void C_fcall trf_1177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1177(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1177(t0,t1,t2);}

C_noret_decl(trf_1091)
static void C_fcall trf_1091(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1091(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1091(t0,t1,t2);}

C_noret_decl(trf_1105)
static void C_fcall trf_1105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1105(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1105(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1112)
static void C_fcall trf_1112(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1112(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1112(t0,t1);}

C_noret_decl(trf_1118)
static void C_fcall trf_1118(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1118(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1118(t0,t1);}

C_noret_decl(trf_1001)
static void C_fcall trf_1001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1001(t0,t1,t2);}

C_noret_decl(trf_953)
static void C_fcall trf_953(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_953(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_953(t0,t1);}

C_noret_decl(trf_948)
static void C_fcall trf_948(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_948(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_948(t0,t1,t2);}

C_noret_decl(trf_923)
static void C_fcall trf_923(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_923(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_923(t0,t1,t2,t3);}

C_noret_decl(trf_822)
static void C_fcall trf_822(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_822(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_822(t0,t1,t2);}

C_noret_decl(trf_857)
static void C_fcall trf_857(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_857(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_857(t0,t1,t2,t3);}

C_noret_decl(trf_867)
static void C_fcall trf_867(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_867(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_867(t0,t1);}

C_noret_decl(trf_870)
static void C_fcall trf_870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_870(t0,t1);}

C_noret_decl(trf_354)
static void C_fcall trf_354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_354(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_354(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(376)){
C_save(t1);
C_rereclaim2(376*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,90);
lf[7]=C_h_intern(&lf[7],4,"exit");
lf[8]=C_h_intern(&lf[8],7,"display");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\001\242)\012 -no-unused                remove procedures that are never called\012 -top "
"N                    display only the top N entries\012 -help                     s"
"how this text and exit\012 -version                  show version and exit\012 -releas"
"e                  show release number and exit\012\012 FILENAME defaults to the `PROF"
"ILE.<number>\047, selecting the one with\012 the highest modification time, in case mu"
"ltiple profiles exist.\012");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\001\315Usage: chicken-profile [FILENAME | OPTION] ...\012\012 -sort-by-calls            "
"sort output by call frequency\012 -sort-by-time             sort output by procedur"
"e execution time\012 -sort-by-avg              sort output by average procedure exe"
"cution time\012 -sort-by-name             sort output alphabetically by procedure n"
"ame\012 -decimals DDD             set number of decimals for seconds, average and\012 "
"                          percent columns (three digits, default: ");
lf[13]=C_h_intern(&lf[13],19,"\003sysprint-to-string");
lf[18]=C_h_intern(&lf[18],8,"string<\077");
lf[19]=C_h_intern(&lf[19],14,"symbol->string");
lf[22]=C_h_intern(&lf[22],17,"hash-table->alist");
lf[23]=C_h_intern(&lf[23],4,"read");
lf[24]=C_h_intern(&lf[24],15,"hash-table-set!");
lf[25]=C_h_intern(&lf[25],22,"hash-table-ref/default");
lf[26]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\001\000\000\000\000\376\003\000\000\002\376\377\001\000\000\000\000\376\377\016");
lf[27]=C_h_intern(&lf[27],15,"make-hash-table");
lf[28]=C_h_intern(&lf[28],3,"eq\077");
lf[30]=C_h_intern(&lf[30],13,"string-append");
lf[31]=C_h_intern(&lf[31],11,"make-string");
lf[32]=C_h_intern(&lf[32],5,"fxmax");
lf[33]=C_h_intern(&lf[33],9,"\003syserror");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[38]=C_h_intern(&lf[38],9,"substring");
lf[39]=C_h_intern(&lf[39],8,"truncate");
lf[40]=C_h_intern(&lf[40],4,"expt");
lf[41]=C_h_intern(&lf[41],25,"\003sysimplicit-exit-handler");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\011procedure");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005calls");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007seconds");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\007average");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\007percent");
lf[47]=C_h_intern(&lf[47],5,"print");
lf[48]=C_h_intern(&lf[48],11,"string-join");
lf[49]=C_h_intern(&lf[49],6,"reduce");
lf[50]=C_h_intern(&lf[50],1,"+");
lf[51]=C_h_intern(&lf[51],3,"max");
lf[52]=C_h_intern(&lf[52],13,"string-length");
lf[53]=C_h_intern(&lf[53],4,"fold");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\010overflow");
lf[55]=C_h_intern(&lf[55],28,"\003syssymbol->qualified-string");
lf[56]=C_h_intern(&lf[56],6,"remove");
lf[57]=C_h_intern(&lf[57],4,"take");
lf[58]=C_h_intern(&lf[58],4,"sort");
lf[59]=C_h_intern(&lf[59],6,"append");
lf[60]=C_h_intern(&lf[60],20,"with-input-from-file");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\011reading `");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 ...\012");
lf[63]=C_h_intern(&lf[63],5,"error");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\021no PROFILEs found");
lf[65]=C_h_intern(&lf[65],22,"file-modification-time");
lf[66]=C_h_intern(&lf[66],4,"glob");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\011PROFILE.*");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\032missing argument to option");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\032invalid argument to option");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\032chicken-profile - Version ");
lf[76]=C_h_intern(&lf[76],15,"chicken-version");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\012-no-unused");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\004-top");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\016-sort-by-calls");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-time");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\014-sort-by-avg");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\015-sort-by-name");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\011-decimals");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000$invalid argument to -decimals option");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[89]=C_h_intern(&lf[89],22,"command-line-arguments");
C_register_lf2(lf,90,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_328,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k326 */
static void C_ccall f_328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k329 in k326 */
static void C_ccall f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k332 in k329 in k326 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_337,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k335 in k332 in k329 in k326 */
static void C_ccall f_337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_340,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_346,2,t0,t1);}
t2=lf[0] /* file */ =C_SCHEME_FALSE;;
t3=lf[1] /* no-unused */ =C_SCHEME_FALSE;;
t4=lf[2] /* seconds-digits */ =C_fix(3);;
t5=lf[3] /* average-digits */ =C_fix(3);;
t6=lf[4] /* percent-digits */ =C_fix(3);;
t7=lf[5] /* top */ =C_fix(0);;
t8=C_mutate(&lf[6] /* (set! print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_354,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[14] /* (set! sort-by-calls ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_629,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[15] /* (set! sort-by-time ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_664,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate(&lf[16] /* (set! sort-by-avg ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_693,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate(&lf[17] /* (set! sort-by-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_722,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate(&lf[20] /* (set! sort-by ...) */,lf[15]);
t14=C_mutate(&lf[21] /* (set! read-profile ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_806,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate(&lf[29] /* (set! format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_921,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[35] /* (set! format-real ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1001,tmp=(C_word)a,a+=2,tmp));
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1548,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1558,a[2]=t17,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:234: command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[89]))(2,*((C_word*)lf[89]+1),t18);}

/* k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_401(t5,((C_word*)t0)[2],t1);}

/* loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(24);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_401,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_411,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(lf[0])){
t4=t3;
f_411(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:73: glob */
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t4,lf[67]);}}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_456,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t11=t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_475,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_498,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep((C_truep(C_i_equalp(t3,lf[70]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[71]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[72]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
/* chicken-profile.scm:93: print-usage */
f_354(t12);}
else{
if(C_truep((C_truep(C_i_equalp(t3,lf[73]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[74]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_516,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:95: chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[76]))(2,*((C_word*)lf[76]+1),t14);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[77]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_532,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_539,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:98: chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[76]))(2,*((C_word*)lf[76]+1),t14);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[78]))){
t13=lf[1] /* no-unused */ =C_SCHEME_TRUE;;
/* chicken-profile.scm:111: loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[79]))){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_556,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:101: next-number */
t14=t9;
f_475(t14,t13);}
else{
if(C_truep(C_i_string_equal_p(t3,lf[80]))){
t13=C_mutate(&lf[20] /* (set! sort-by ...) */,lf[14]);
/* chicken-profile.scm:111: loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[81]))){
t13=C_mutate(&lf[20] /* (set! sort-by ...) */,lf[15]);
/* chicken-profile.scm:111: loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[82]))){
t13=C_mutate(&lf[20] /* (set! sort-by ...) */,lf[16]);
/* chicken-profile.scm:111: loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[83]))){
t13=C_mutate(&lf[20] /* (set! sort-by ...) */,lf[17]);
/* chicken-profile.scm:111: loop */
t30=t1;
t31=((C_word*)t6)[1];
t1=t30;
t2=t31;
goto loop;}
else{
if(C_truep(C_i_string_equal_p(t3,lf[84]))){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_597,a[2]=t12,a[3]=t6,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm:106: next-arg */
t14=((C_word*)t8)[1];
f_456(t14,t13);}
else{
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_603,a[2]=t6,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=t12,tmp=(C_word)a,a+=7,tmp);
t14=C_i_string_length(t3);
if(C_truep(C_i_greaterp(t14,C_fix(1)))){
t15=C_i_string_ref(t3,C_fix(0));
t16=t13;
f_603(t16,C_eqp(C_make_character(45),t15));}
else{
t15=t13;
f_603(t15,C_SCHEME_FALSE);}}}}}}}}}}}}}

/* k601 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_603(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* chicken-profile.scm:108: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[6],lf[88],((C_word*)t0)[5]);}
else{
if(C_truep(lf[0])){
/* chicken-profile.scm:109: print-usage */
f_354(((C_word*)t0)[6]);}
else{
t2=C_mutate(&lf[0] /* (set! file ...) */,((C_word*)t0)[5]);
/* chicken-profile.scm:111: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_401(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_597,2,t0,t1);}
t2=C_i_string_length(t1);
if(C_truep(C_i_nequalp(t2,C_fix(3)))){
t3=C_mutate(&lf[85] /* (set! arg-digit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_754,a[2]=t1,tmp=(C_word)a,a+=3,tmp));
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_789,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:148: arg-digit */
t5=C_retrieve2(lf[85],"arg-digit");
f_754(t5,t4,C_fix(0));}
else{
/* chicken-profile.scm:151: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[2],lf[87],t1);}}

/* k787 in k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_789,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! seconds-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:149: arg-digit */
t4=C_retrieve2(lf[85],"arg-digit");
f_754(t4,t3,C_fix(1));}

/* k791 in k787 in k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_793,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! average-digits ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:150: arg-digit */
t4=C_retrieve2(lf[85],"arg-digit");
f_754(t4,t3,C_fix(2));}

/* k795 in k791 in k787 in k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[4] /* (set! percent-digits ...) */,t1);
/* chicken-profile.scm:111: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_401(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* arg-digit in k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_754(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_754,NULL,3,t0,t1,t2);}
t3=C_i_string_ref(((C_word*)t0)[2],t2);
t4=C_fix(C_character_code(t3));
t5=C_a_i_minus(&a,2,t4,C_fix(48));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:145: <= */
C_less_or_equal_p(5,0,t6,C_fix(0),t5,C_fix(9));}

/* k762 in arg-digit in k595 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_nequalp(((C_word*)t0)[4],C_fix(9));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_fix(8):((C_word*)t0)[4]));}
else{
/* chicken-profile.scm:147: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],lf[86],((C_word*)t0)[2]);}}

/* k554 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_556(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[5] /* (set! top ...) */,t1);
/* chicken-profile.scm:111: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_401(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k537 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:98: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k530 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:99: exit */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),((C_word*)t0)[2]);}

/* k521 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:95: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[47]+1)))(4,*((C_word*)lf[47]+1),((C_word*)t0)[2],lf[75],t1);}

/* k514 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:96: exit */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),((C_word*)t0)[2]);}

/* k496 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:111: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_401(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* next-number in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_475,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_479,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_495,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:90: next-arg */
t4=((C_word*)((C_word*)t0)[2])[1];
f_456(t4,t3);}

/* k493 in next-number in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:90: string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* k477 in next-number in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
if(C_truep(C_i_greaterp(t1,C_fix(0)))){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* chicken-profile.scm:91: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],lf[69],((C_word*)t0)[2]);}}
else{
/* chicken-profile.scm:91: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),((C_word*)t0)[3],lf[69],((C_word*)t0)[2]);}}

/* next-arg in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_456(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_456,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* chicken-profile.scm:85: error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[63]+1)))(4,*((C_word*)lf[63]+1),t1,lf[68],((C_word*)t0)[2]);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t1))){
/* chicken-profile.scm:75: error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[63]+1)))(3,*((C_word*)lf[63]+1),t2,lf[64]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_434,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_436,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm:76: sort */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),t3,t1,t4);}}

/* a435 in k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_436,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_444,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:78: file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[65]))(3,*((C_word*)lf[65]+1),t4,t2);}

/* k442 in a435 in k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_448,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:79: file-modification-time */
((C_proc3)C_retrieve_symbol_proc(lf[65]))(3,*((C_word*)lf[65]+1),t2,((C_word*)t0)[2]);}

/* k446 in k442 in a435 in k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_greaterp(((C_word*)t0)[2],t1));}

/* k432 in k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_car(t1);
t3=C_mutate(&lf[0] /* (set! file ...) */,t2);
t4=((C_word*)t0)[2];
f_411(t4,t3);}

/* k419 in k416 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[0] /* (set! file ...) */,t1);
t3=((C_word*)t0)[2];
f_411(t3,t2);}

/* k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_411,NULL,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1061,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:184: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[47]+1)))(5,*((C_word*)lf[47]+1),t3,lf[61],lf[0],lf[62]);}

/* k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:185: with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[60]))(4,*((C_word*)lf[60]+1),t2,lf[0],lf[21]);}

/* k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1067,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1537,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm:186: fold */
((C_proc5)C_retrieve_symbol_proc(lf[53]))(5,*((C_word*)lf[53]+1),t2,t3,C_fix(0),t1);}

/* a1536 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1537,4,t0,t1,t2,t3);}
t4=C_i_caddr(t2);
/* chicken-profile.scm:187: max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t1,t4,t3);}

/* k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1070,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1452,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1454,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=t1,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1454(t11,t7,((C_word*)t0)[2]);}

/* loop124 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1454(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1454,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1481,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1531,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g140141 */
t6=t3;
f_1481(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1529 in loop124 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1531,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop124137 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1454(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop124137 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1454(t6,((C_word*)t0)[3],t5);}}

/* g140 in loop124 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1481(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1481,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
t4=C_i_caddr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1499,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=C_i_greaterp(t3,C_fix(0));
t7=t5;
f_1499(t7,(C_truep(t6)?C_a_i_divide(&a,2,t4,t3):C_SCHEME_FALSE));}
else{
t6=t5;
f_1499(t6,C_SCHEME_FALSE);}}

/* k1497 in g140 in loop124 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1499(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1499,NULL,2,t0,t1);}
t2=(C_truep(t1)?t1:C_fix(0));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1506,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t4=C_a_i_divide(&a,2,((C_word*)t0)[2],((C_word*)t0)[3]);
t5=t3;
f_1506(t5,C_a_i_times(&a,2,t4,C_fix(100)));}
else{
t4=t3;
f_1506(t4,C_SCHEME_FALSE);}}

/* k1504 in k1497 in g140 in loop124 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1506(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1506,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_a_i_list(&a,2,((C_word*)t0)[4],t2);
/* chicken-profile.scm:191: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=C_a_i_list(&a,2,((C_word*)t0)[4],C_fix(0));
/* chicken-profile.scm:191: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[59]+1)))(4,*((C_word*)lf[59]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* k1450 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:190: sort */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[2],t1,lf[20]);}

/* k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1070,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1440,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_length(((C_word*)t3)[1]);
/* chicken-profile.scm:200: < */
C_lessp(5,0,t5,C_fix(0),lf[5],t6);}

/* k1438 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1444,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:201: take */
((C_proc4)C_retrieve_symbol_proc(lf[57]))(4,*((C_word*)lf[57]+1),t2,((C_word*)((C_word*)t0)[3])[1],lf[5]);}
else{
t2=((C_word*)t0)[2];
f_1073(t2,C_SCHEME_UNDEFINED);}}

/* k1442 in k1438 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_1073(t3,t2);}

/* k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1073(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1073,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1077,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1328,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1420,tmp=(C_word)a,a+=2,tmp);
/* chicken-profile.scm:212: remove */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t7,t8,((C_word*)((C_word*)t0)[3])[1]);}

/* a1419 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1420,3,t0,t1,t2);}
if(C_truep(C_i_cadr(t2))){
t3=C_i_cadr(t2);
t4=C_i_zerop(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[1]:C_SCHEME_FALSE));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1330,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1330(t5,((C_word*)t0)[2],t1);}

/* loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1330,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_i_cadr(t3);
t5=C_i_caddr(t3);
t6=C_i_cadddr(t3);
t7=C_i_list_ref(t3,C_fix(4));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1377,a[2]=t4,a[3]=t5,a[4]=t6,a[5]=t7,a[6]=((C_word*)t0)[2],a[7]=t1,a[8]=((C_word*)t0)[3],a[9]=t2,a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t9=C_i_car(t3);
/* chicken-profile.scm:207: ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),t8,t9);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1375 in loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[2])){
/* chicken-profile.scm:208: number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_1381(2,t3,lf[54]);}}

/* k1379 in k1375 in loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1381,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1385,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=t1,a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm:209: format-real */
f_1001(t2,t3,lf[2]);}

/* k1383 in k1379 in k1375 in loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1389,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_a_i_divide(&a,2,((C_word*)t0)[2],C_fix(1000));
/* chicken-profile.scm:210: format-real */
f_1001(t2,t3,lf[3]);}

/* k1387 in k1383 in k1379 in k1375 in loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1393,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* chicken-profile.scm:211: format-real */
f_1001(t2,((C_word*)t0)[2],lf[4]);}

/* k1391 in k1387 in k1383 in k1379 in k1375 in loop159 in k1326 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1393,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t4=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1330(t7,((C_word*)t0)[3],t6);}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=C_mutate(((C_word *)((C_word*)t0)[6])+1,t3);
t6=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop159172 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_1330(t7,((C_word*)t0)[3],t6);}}

/* k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=C_a_i_list(&a,5,lf[42],lf[43],lf[44],lf[45],lf[46]);
t4=C_a_i_list(&a,5,C_SCHEME_FALSE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1086,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t4,tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm:220: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t5,C_fix(2),C_make_character(32));}

/* k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1224,tmp=(C_word)a,a+=2,tmp);
t4=C_a_i_list(&a,5,C_fix(0),C_fix(0),C_fix(0),C_fix(0),C_fix(0));
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)((C_word*)t0)[3])[1]);
/* chicken-profile.scm:221: fold */
((C_proc5)C_retrieve_symbol_proc(lf[53]))(5,*((C_word*)lf[53]+1),t2,t3,t4,t5);}

/* a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[21],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1224,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1232,a[2]=t3,a[3]=t1,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=t9,a[3]=t14,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t16=((C_word*)t14)[1];
f_1283(t16,t12,t2);}

/* loop222 in a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1283(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(3);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1283,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[52]+1);
t4=C_slot(t2,C_fix(0));
t5=C_i_string_length(t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop222235 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop222235 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1230 in a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1232,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1234,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1234(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop196 in k1230 in a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1234(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1234,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[51]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g215216 */
t10=t6;
((C_proc4)C_retrieve_proc(t10))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k1265 in loop196 in k1230 in a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_1247(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1247(t5,t4);}}

/* k1245 in k1265 in loop196 in k1230 in a1223 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop196210 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1234(t5,((C_word*)t0)[2],t3,t4);}

/* k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1169,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* chicken-profile.scm:228: print-row */
t4=t2;
f_1091(t4,t3,((C_word*)t0)[2]);}

/* k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1172,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1202,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:229: reduce */
((C_proc5)C_retrieve_symbol_proc(lf[49]))(5,*((C_word*)lf[49]+1),t4,*((C_word*)lf[50]+1),C_fix(0),((C_word*)t0)[2]);}

/* k1208 in k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[3]);
t3=C_a_i_minus(&a,2,t2,C_fix(1));
t4=C_a_i_times(&a,2,C_fix(2),t3);
t5=C_a_i_plus(&a,2,t1,t4);
/* chicken-profile.scm:229: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[2],t5,C_make_character(45));}

/* k1200 in k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:229: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k1170 in k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1172,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1177(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop276 in k1170 in k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1177(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1177,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1187,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g283284 */
t5=((C_word*)t0)[2];
f_1091(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1185 in loop276 in k1170 in k1167 in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1177(t3,((C_word*)t0)[2],t2);}

/* print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1091(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1091,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1099,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1103,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1105,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_1105(t12,t8,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop247 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1105(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1105,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_1112(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_1112(t6,C_SCHEME_FALSE);}}

/* k1110 in loop247 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1112(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1112,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[29];
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(0));
t5=C_slot(((C_word*)t0)[6],C_fix(0));
t6=C_slot(((C_word*)t0)[5],C_fix(0));
/* g269270 */
t7=lf[29];
f_921(5,t7,t3,t4,t5,t6);}
else{
t2=((C_word*)((C_word*)t0)[2])[1];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1140 in k1110 in loop247 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1142,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[8])[1])){
t4=t3;
f_1118(t4,C_i_setslot(((C_word*)((C_word*)t0)[8])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_1118(t5,t4);}}

/* k1116 in k1140 in k1110 in loop247 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1118(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[8])+1,((C_word*)t0)[7]);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
t4=C_slot(((C_word*)t0)[5],C_fix(1));
t5=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop247262 */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1105(t6,((C_word*)t0)[2],t3,t4,t5);}

/* k1101 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:227: string-join */
((C_proc4)C_retrieve_symbol_proc(lf[48]))(4,*((C_word*)lf[48]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1097 in print-row in k1087 in k1084 in k1075 in k1071 in k1068 in k1065 in k1062 in k1059 in k409 in loop in k1556 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:227: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[47]+1)))(3,*((C_word*)lf[47]+1),((C_word*)t0)[2],t1);}

/* k1546 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1554,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k1552 in k1546 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1549 in k1546 in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_1001(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1001,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1055,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-profile.scm:172: truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t4,t2);}

/* k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1012,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* chicken-profile.scm:174: number->string */
C_number_to_string(3,0,t3,t2);}

/* k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1012,2,t0,t1);}
t2=C_i_greaterp(((C_word*)t0)[5],C_fix(0));
t3=(C_truep(t2)?lf[36]:lf[37]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1020,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1024,a[2]=t4,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1036,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1044,a[2]=((C_word*)t0)[5],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:180: - */
C_minus(5,0,t7,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(-1));}

/* k1042 in k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:180: expt */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,C_fix(10),((C_word*)t0)[2]);}

/* k1046 in k1042 in k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=C_a_i_times(&a,2,((C_word*)t0)[3],t1);
/* chicken-profile.scm:179: truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),((C_word*)t0)[2],t2);}

/* k1034 in k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_inexact_to_exact(t1);
/* chicken-profile.scm:177: number->string */
C_number_to_string(3,0,((C_word*)t0)[2],t2);}

/* k1022 in k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1024,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* chicken-profile.scm:176: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[38]+1)))(5,*((C_word*)lf[38]+1),((C_word*)t0)[2],t1,C_fix(1),t2);}

/* k1018 in k1010 in k1053 in format-real in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:173: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[30]+1)))(5,*((C_word*)lf[30]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr4r,(void*)f_921r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_921r(t0,t1,t2,t3,t4);}}

static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(10);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_923,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_948,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_953,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-right96108 */
t8=t7;
f_953(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-padc97106 */
t10=t6;
f_948(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body94101 */
t12=t5;
f_923(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[33]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[34],t11);}}}}

/* def-right96 in format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_953(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_953,NULL,2,t0,t1);}
/* def-padc97106 */
t2=((C_word*)t0)[2];
f_948(t2,t1,C_SCHEME_FALSE);}

/* def-padc97 in format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_948(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_948,NULL,3,t0,t1,t2);}
/* body94101 */
t3=((C_word*)t0)[2];
f_923(t3,t1,t2,C_make_character(32));}

/* body94 in format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_923(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_923,NULL,4,t0,t1,t2,t3);}
t4=C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_930,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_943,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_fixnum_difference(((C_word*)t0)[2],t4);
/* chicken-profile.scm:166: fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t6,C_fix(0),t7);}

/* k941 in body94 in format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:166: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k928 in body94 in format-string in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* chicken-profile.scm:168: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* chicken-profile.scm:169: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_810,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-profile.scm:154: make-hash-table */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t2,*((C_word*)lf[28]+1));}

/* k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_813,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_820,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:155: read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t3);}

/* k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_820,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_822(t5,((C_word*)t0)[2],t1);}

/* doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_822(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_822,NULL,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_832,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_847,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_851,a[2]=t9,a[3]=t6,a[4]=t8,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t11=C_i_car(t2);
/* chicken-profile.scm:160: hash-table-ref/default */
((C_proc5)C_retrieve_symbol_proc(lf[25]))(5,*((C_word*)lf[25]+1),t10,((C_word*)t0)[2],t11,lf[26]);}}

/* k849 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_851,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_857,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_857(t6,((C_word*)t0)[2],t1,t2);}

/* loop52 in k849 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_857(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_857,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
if(C_truep(t7)){
if(C_truep(t8)){
t9=C_a_i_plus(&a,2,t7,t8);
t10=t6;
f_867(t10,C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST));}
else{
t9=t6;
f_867(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t9=t6;
f_867(t9,C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST));}}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k865 in loop52 in k849 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_867(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_867,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t3=t2;
f_870(t3,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t1));}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t4=t2;
f_870(t4,t3);}}

/* k868 in k865 in loop52 in k849 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop5266 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_857(t5,((C_word*)t0)[2],t3,t4);}

/* k845 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:157: hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[24]))(5,*((C_word*)lf[24]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k830 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_832(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_832,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-profile.scm:155: read */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k837 in k830 in doloop47 in k818 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_822(t2,((C_word*)t0)[2],t1);}

/* k811 in k808 in read-profile in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:162: hash-table->alist */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* sort-by-name in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_722,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_730,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* chicken-profile.scm:135: symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t4,t5);}

/* k728 in sort-by-name in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_730,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_734,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* chicken-profile.scm:135: symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,t3);}

/* k732 in k728 in sort-by-name in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:135: string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[18]+1)))(4,*((C_word*)lf[18]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* sort-by-avg in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_693,4,t0,t1,t2,t3);}
t4=C_i_cadddr(t2);
t5=C_i_cadddr(t3);
if(C_truep(C_i_eqvp(t4,t5))){
t6=C_i_caddr(t2);
t7=C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_greaterp(t4,t5));}}

/* sort-by-time in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_664(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_664,4,t0,t1,t2,t3);}
t4=C_i_caddr(t2);
t5=C_i_caddr(t3);
if(C_truep(C_i_nequalp(t4,t5))){
t6=C_i_cadr(t2);
t7=C_i_cadr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_greaterp(t4,t5));}}

/* sort-by-calls in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_629(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_629,4,t0,t1,t2,t3);}
t4=C_i_cadr(t2);
t5=C_i_cadr(t3);
if(C_truep(C_i_eqvp(t4,t5))){
t6=C_i_caddr(t2);
t7=C_i_caddr(t3);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_greaterp(t6,t7));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t4)?(C_truep(t5)?C_i_greaterp(t4,t5):C_SCHEME_TRUE):C_SCHEME_TRUE));}}

/* print-usage in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_fcall f_354(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_354,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_358,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_365,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[9],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[4],t4);
t6=C_a_i_cons(&a,2,lf[10],t5);
t7=C_a_i_cons(&a,2,lf[3],t6);
t8=C_a_i_cons(&a,2,lf[11],t7);
t9=C_a_i_cons(&a,2,lf[2],t8);
t10=C_a_i_cons(&a,2,lf[12],t9);
/* chicken-profile.scm:45: ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),t3,t10);}

/* k363 in print-usage in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:45: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[2],t1);}

/* k356 in print-usage in k344 in k341 in k338 in k335 in k332 in k329 in k326 */
static void C_ccall f_358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-profile.scm:65: exit */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[117] = {
{"toplevel:chicken_profile_scm",(void*)C_toplevel},
{"f_328:chicken_profile_scm",(void*)f_328},
{"f_331:chicken_profile_scm",(void*)f_331},
{"f_334:chicken_profile_scm",(void*)f_334},
{"f_337:chicken_profile_scm",(void*)f_337},
{"f_340:chicken_profile_scm",(void*)f_340},
{"f_343:chicken_profile_scm",(void*)f_343},
{"f_346:chicken_profile_scm",(void*)f_346},
{"f_1558:chicken_profile_scm",(void*)f_1558},
{"f_401:chicken_profile_scm",(void*)f_401},
{"f_603:chicken_profile_scm",(void*)f_603},
{"f_597:chicken_profile_scm",(void*)f_597},
{"f_789:chicken_profile_scm",(void*)f_789},
{"f_793:chicken_profile_scm",(void*)f_793},
{"f_797:chicken_profile_scm",(void*)f_797},
{"f_754:chicken_profile_scm",(void*)f_754},
{"f_764:chicken_profile_scm",(void*)f_764},
{"f_556:chicken_profile_scm",(void*)f_556},
{"f_539:chicken_profile_scm",(void*)f_539},
{"f_532:chicken_profile_scm",(void*)f_532},
{"f_523:chicken_profile_scm",(void*)f_523},
{"f_516:chicken_profile_scm",(void*)f_516},
{"f_498:chicken_profile_scm",(void*)f_498},
{"f_475:chicken_profile_scm",(void*)f_475},
{"f_495:chicken_profile_scm",(void*)f_495},
{"f_479:chicken_profile_scm",(void*)f_479},
{"f_456:chicken_profile_scm",(void*)f_456},
{"f_418:chicken_profile_scm",(void*)f_418},
{"f_436:chicken_profile_scm",(void*)f_436},
{"f_444:chicken_profile_scm",(void*)f_444},
{"f_448:chicken_profile_scm",(void*)f_448},
{"f_434:chicken_profile_scm",(void*)f_434},
{"f_421:chicken_profile_scm",(void*)f_421},
{"f_411:chicken_profile_scm",(void*)f_411},
{"f_1061:chicken_profile_scm",(void*)f_1061},
{"f_1064:chicken_profile_scm",(void*)f_1064},
{"f_1537:chicken_profile_scm",(void*)f_1537},
{"f_1067:chicken_profile_scm",(void*)f_1067},
{"f_1454:chicken_profile_scm",(void*)f_1454},
{"f_1531:chicken_profile_scm",(void*)f_1531},
{"f_1481:chicken_profile_scm",(void*)f_1481},
{"f_1499:chicken_profile_scm",(void*)f_1499},
{"f_1506:chicken_profile_scm",(void*)f_1506},
{"f_1452:chicken_profile_scm",(void*)f_1452},
{"f_1070:chicken_profile_scm",(void*)f_1070},
{"f_1440:chicken_profile_scm",(void*)f_1440},
{"f_1444:chicken_profile_scm",(void*)f_1444},
{"f_1073:chicken_profile_scm",(void*)f_1073},
{"f_1420:chicken_profile_scm",(void*)f_1420},
{"f_1328:chicken_profile_scm",(void*)f_1328},
{"f_1330:chicken_profile_scm",(void*)f_1330},
{"f_1377:chicken_profile_scm",(void*)f_1377},
{"f_1381:chicken_profile_scm",(void*)f_1381},
{"f_1385:chicken_profile_scm",(void*)f_1385},
{"f_1389:chicken_profile_scm",(void*)f_1389},
{"f_1393:chicken_profile_scm",(void*)f_1393},
{"f_1077:chicken_profile_scm",(void*)f_1077},
{"f_1086:chicken_profile_scm",(void*)f_1086},
{"f_1224:chicken_profile_scm",(void*)f_1224},
{"f_1283:chicken_profile_scm",(void*)f_1283},
{"f_1232:chicken_profile_scm",(void*)f_1232},
{"f_1234:chicken_profile_scm",(void*)f_1234},
{"f_1267:chicken_profile_scm",(void*)f_1267},
{"f_1247:chicken_profile_scm",(void*)f_1247},
{"f_1089:chicken_profile_scm",(void*)f_1089},
{"f_1169:chicken_profile_scm",(void*)f_1169},
{"f_1210:chicken_profile_scm",(void*)f_1210},
{"f_1202:chicken_profile_scm",(void*)f_1202},
{"f_1172:chicken_profile_scm",(void*)f_1172},
{"f_1177:chicken_profile_scm",(void*)f_1177},
{"f_1187:chicken_profile_scm",(void*)f_1187},
{"f_1091:chicken_profile_scm",(void*)f_1091},
{"f_1105:chicken_profile_scm",(void*)f_1105},
{"f_1112:chicken_profile_scm",(void*)f_1112},
{"f_1142:chicken_profile_scm",(void*)f_1142},
{"f_1118:chicken_profile_scm",(void*)f_1118},
{"f_1103:chicken_profile_scm",(void*)f_1103},
{"f_1099:chicken_profile_scm",(void*)f_1099},
{"f_1548:chicken_profile_scm",(void*)f_1548},
{"f_1554:chicken_profile_scm",(void*)f_1554},
{"f_1551:chicken_profile_scm",(void*)f_1551},
{"f_1001:chicken_profile_scm",(void*)f_1001},
{"f_1055:chicken_profile_scm",(void*)f_1055},
{"f_1012:chicken_profile_scm",(void*)f_1012},
{"f_1044:chicken_profile_scm",(void*)f_1044},
{"f_1048:chicken_profile_scm",(void*)f_1048},
{"f_1036:chicken_profile_scm",(void*)f_1036},
{"f_1024:chicken_profile_scm",(void*)f_1024},
{"f_1020:chicken_profile_scm",(void*)f_1020},
{"f_921:chicken_profile_scm",(void*)f_921},
{"f_953:chicken_profile_scm",(void*)f_953},
{"f_948:chicken_profile_scm",(void*)f_948},
{"f_923:chicken_profile_scm",(void*)f_923},
{"f_943:chicken_profile_scm",(void*)f_943},
{"f_930:chicken_profile_scm",(void*)f_930},
{"f_806:chicken_profile_scm",(void*)f_806},
{"f_810:chicken_profile_scm",(void*)f_810},
{"f_820:chicken_profile_scm",(void*)f_820},
{"f_822:chicken_profile_scm",(void*)f_822},
{"f_851:chicken_profile_scm",(void*)f_851},
{"f_857:chicken_profile_scm",(void*)f_857},
{"f_867:chicken_profile_scm",(void*)f_867},
{"f_870:chicken_profile_scm",(void*)f_870},
{"f_847:chicken_profile_scm",(void*)f_847},
{"f_832:chicken_profile_scm",(void*)f_832},
{"f_839:chicken_profile_scm",(void*)f_839},
{"f_813:chicken_profile_scm",(void*)f_813},
{"f_722:chicken_profile_scm",(void*)f_722},
{"f_730:chicken_profile_scm",(void*)f_730},
{"f_734:chicken_profile_scm",(void*)f_734},
{"f_693:chicken_profile_scm",(void*)f_693},
{"f_664:chicken_profile_scm",(void*)f_664},
{"f_629:chicken_profile_scm",(void*)f_629},
{"f_354:chicken_profile_scm",(void*)f_354},
{"f_365:chicken_profile_scm",(void*)f_365},
{"f_358:chicken_profile_scm",(void*)f_358},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
