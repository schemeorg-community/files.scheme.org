/* Generated from setup-download.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: setup-download.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -feature chicken-compile-shared -dynamic -emit-import-library setup-download -output-file setup-download.c
   used units: library eval extras regex posix utils srfi_1 data_structures tcp srfi_13 files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[215];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,34),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,100,32,102,115,116,114,49,53,48,32,97,114,103,115,49,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,40),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,101,116,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,57),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,101,120,105,115,116,105,110,103,45,118,101,114,115,105,111,110,32,101,103,103,49,53,57,32,118,101,114,115,105,111,110,49,54,48,32,118,115,49,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,20),40,98,111,100,121,50,50,50,32,118,101,114,115,105,111,110,50,51,48,41,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,50,50,53,32,37,118,101,114,115,105,111,110,50,50,48,50,52,50,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,50,50,52,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,59),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,108,111,99,97,108,32,101,103,103,50,49,55,32,100,105,114,50,49,56,32,46,32,116,109,112,50,49,54,50,49,57,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,7),40,97,49,49,52,52,41,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,7),40,97,49,50,48,50,41,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,97,49,49,57,54,32,101,120,50,54,56,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,7),40,97,49,50,49,55,41,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,7),40,97,49,50,50,57,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,20),40,97,49,50,50,51,32,46,32,97,114,103,115,50,54,52,50,55,48,41,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,7),40,97,49,50,49,49,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,15),40,97,49,49,57,48,32,107,50,54,51,50,54,55,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,17),40,97,49,49,54,53,32,114,101,116,117,114,110,50,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,37),40,97,49,49,53,48,32,108,111,99,50,53,50,50,53,51,50,53,54,32,118,101,114,115,105,111,110,50,53,52,50,53,53,50,53,55,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,97,49,49,51,56,32,101,103,103,50,53,49,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,46),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,103,97,116,104,101,114,45,101,103,103,45,105,110,102,111,114,109,97,116,105,111,110,32,100,105,114,50,52,57,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,66),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,109,97,107,101,45,115,118,110,45,108,115,45,99,109,100,32,117,97,114,103,50,55,55,32,112,97,114,103,50,55,56,32,112,110,97,109,50,55,57,32,116,109,112,50,55,54,50,56,48,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,49,53,54,50,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,37),40,97,49,53,57,48,32,102,105,108,101,100,105,114,52,51,49,52,51,50,52,51,54,32,118,101,114,52,51,51,52,51,52,52,51,55,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,12),40,97,49,54,53,54,32,102,52,50,57,41,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,59),40,98,111,100,121,52,49,48,32,118,101,114,115,105,111,110,52,50,48,32,100,101,115,116,105,110,97,116,105,111,110,52,50,49,32,117,115,101,114,110,97,109,101,52,50,50,32,112,97,115,115,119,111,114,100,52,50,51,41,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,67),40,100,101,102,45,112,97,115,115,119,111,114,100,52,49,53,32,37,118,101,114,115,105,111,110,52,48,54,52,52,57,32,37,100,101,115,116,105,110,97,116,105,111,110,52,48,55,52,53,48,32,37,117,115,101,114,110,97,109,101,52,48,56,52,53,49,41,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,51),40,100,101,102,45,117,115,101,114,110,97,109,101,52,49,52,32,37,118,101,114,115,105,111,110,52,48,54,52,53,51,32,37,100,101,115,116,105,110,97,116,105,111,110,52,48,55,52,53,52,41,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,49,51,32,37,118,101,114,115,105,111,110,52,48,54,52,53,54,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,49,50,41};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,115,118,110,32,101,103,103,52,48,51,32,114,101,112,111,52,48,52,32,46,32,116,109,112,52,48,50,52,48,53,41,0,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,56,51,55,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,50,49,48,54,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,7),40,97,50,50,53,55,41,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,102,105,108,101,115,32,102,105,108,101,115,54,50,49,41,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,103,101,116,45,99,104,117,110,107,115,32,100,97,116,97,54,53,54,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,7),40,97,50,48,53,48,41,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,50,48,53,51,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,50,48,53,54,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,50,48,53,57,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,32),40,97,50,49,50,48,32,105,110,53,57,50,53,57,51,54,48,50,32,111,117,116,53,57,52,53,57,53,54,48,51,41};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,49),40,97,49,56,52,51,32,104,111,115,116,53,48,56,53,48,57,53,49,52,32,112,111,114,116,53,49,48,53,49,49,53,49,53,32,108,111,99,110,53,49,50,53,49,51,53,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,72),40,98,111,100,121,52,56,56,32,118,101,114,115,105,111,110,52,57,57,32,100,101,115,116,105,110,97,116,105,111,110,53,48,48,32,116,101,115,116,115,53,48,49,32,112,114,111,120,121,45,104,111,115,116,53,48,50,32,112,114,111,120,121,45,112,111,114,116,53,48,51,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,84),40,100,101,102,45,112,114,111,120,121,45,112,111,114,116,52,57,52,32,37,118,101,114,115,105,111,110,52,56,51,53,50,56,32,37,100,101,115,116,105,110,97,116,105,111,110,52,56,52,53,50,57,32,37,116,101,115,116,115,52,56,53,53,51,48,32,37,112,114,111,120,121,45,104,111,115,116,52,56,54,53,51,49,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,66),40,100,101,102,45,112,114,111,120,121,45,104,111,115,116,52,57,51,32,37,118,101,114,115,105,111,110,52,56,51,53,51,51,32,37,100,101,115,116,105,110,97,116,105,111,110,52,56,52,53,51,52,32,37,116,101,115,116,115,52,56,53,53,51,53,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,48),40,100,101,102,45,116,101,115,116,115,52,57,50,32,37,118,101,114,115,105,111,110,52,56,51,53,51,55,32,37,100,101,115,116,105,110,97,116,105,111,110,52,56,52,53,51,56,41};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,100,101,115,116,105,110,97,116,105,111,110,52,57,49,32,37,118,101,114,115,105,111,110,52,56,51,53,52,48,41,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,118,101,114,115,105,111,110,52,57,48,41};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,58),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,111,99,97,116,101,45,101,103,103,47,104,116,116,112,32,101,103,103,52,56,48,32,117,114,108,52,56,49,32,46,32,116,109,112,52,55,57,52,56,50,41,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,7),40,97,50,52,53,53,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,50,52,54,52,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,50,53,48,51,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,50,53,49,50,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,80),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,114,101,116,114,105,101,118,101,45,101,120,116,101,110,115,105,111,110,32,110,97,109,101,54,55,50,32,116,114,97,110,115,112,111,114,116,54,55,51,32,108,111,99,97,116,105,111,110,54,55,52,32,46,32,116,109,112,54,55,49,54,55,53,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,7),40,97,50,53,51,48,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,17),40,97,57,54,52,32,103,49,56,49,49,56,50,49,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,51,49,49,32,103,51,50,49,51,50,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,50,57,54,32,117,115,101,114,110,97,109,101,51,48,52,32,112,97,115,115,119,111,114,100,51,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,50,57,57,32,37,117,115,101,114,110,97,109,101,50,57,52,51,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,50,57,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,7),40,97,50,53,51,53,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,7),40,97,50,53,53,57,41,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,69),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,115,32,116,114,97,110,115,112,111,114,116,55,50,56,32,108,111,99,97,116,105,111,110,55,50,57,32,46,32,116,109,112,55,50,55,55,51,48,41,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,7),40,97,50,53,55,57,41,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,57,57,51,32,103,50,48,54,50,48,55,50,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,51,54,56,32,103,51,55,56,51,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,53,50,32,117,115,101,114,110,97,109,101,51,54,48,32,112,97,115,115,119,111,114,100,51,54,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,112,97,115,115,119,111,114,100,51,53,53,32,37,117,115,101,114,110,97,109,101,51,53,48,51,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,17),40,100,101,102,45,117,115,101,114,110,97,109,101,51,53,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,7),40,97,50,53,56,52,41,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,7),40,97,50,54,48,56,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,85),40,115,101,116,117,112,45,100,111,119,110,108,111,97,100,35,108,105,115,116,45,101,120,116,101,110,115,105,111,110,45,118,101,114,115,105,111,110,115,32,110,97,109,101,55,53,53,32,116,114,97,110,115,112,111,114,116,55,53,54,32,108,111,99,97,116,105,111,110,55,53,55,32,46,32,116,109,112,55,53,52,55,53,56,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_ccall f_834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_ccall f_843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_ccall f_849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_852)
static void C_ccall f_852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_861)
static void C_ccall f_861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_870)
static void C_ccall f_870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_873)
static void C_ccall f_873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_ccall f_2616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_878)
static void C_ccall f_878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2565)
static void C_ccall f_2565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2585)
static void C_ccall f_2585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_fcall f_1489(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_fcall f_1484(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1395)
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1477)
static void C_ccall f_1477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1473)
static void C_ccall f_1473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_fcall f_1427(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1462)
static void C_ccall f_1462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_992)
static void C_ccall f_992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2580)
static void C_ccall f_2580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_fcall f_1345(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_fcall f_1340(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1265)
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_fcall f_1291(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_973)
static void C_ccall f_973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_965)
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_ccall f_2531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_2513)
static void C_ccall f_2513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2451)
static void C_ccall f_2451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2465)
static void C_ccall f_2465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1909)
static void C_fcall f_1909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1899)
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1894)
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1889)
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1829)
static void C_fcall f_1829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1874)
static void C_ccall f_1874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1878)
static void C_ccall f_1878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1867)
static void C_ccall f_1867(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2334)
static void C_ccall f_2334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2337)
static void C_ccall f_2337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2102)
static void C_ccall f_2102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_ccall f_2121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2060)
static void C_ccall f_2060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2024)
static void C_ccall f_2024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_ccall f_2057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2027)
static void C_ccall f_2027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2030)
static void C_ccall f_2030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2327)
static void C_ccall f_2327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2143)
static void C_ccall f_2143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2320)
static void C_fcall f_2320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2010)
static void C_ccall f_2010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2146)
static void C_ccall f_2146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2294)
static void C_fcall f_2294(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2765)
static void C_ccall f2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2761)
static void C_ccall f2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2382)
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2418)
static void C_ccall f_2418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2386)
static void C_ccall f_2386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2404)
static void C_ccall f_2404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2285)
static void C_ccall f_2285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2288)
static void C_ccall f_2288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_ccall f_2292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2152)
static void C_fcall f_2152(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2160)
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2164)
static void C_ccall f_2164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_fcall f_2170(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2214)
static void C_ccall f_2214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2239)
static void C_ccall f_2239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2245)
static void C_ccall f_2245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2196)
static void C_ccall f_2196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2374)
static void C_ccall f_2374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2107)
static void C_ccall f_2107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1857)
static void C_ccall f_1857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_ccall f_1781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1693)
static void C_fcall f_1693(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1688)
static void C_fcall f_1688(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1678)
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1539)
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1543)
static void C_ccall f_1543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1549)
static void C_ccall f_1549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1552)
static void C_ccall f_1552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1661)
static void C_ccall f_1661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1558)
static void C_ccall f_1558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1648)
static void C_ccall f_1648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_ccall f_1638(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1631)
static void C_ccall f_1631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1625)
static void C_ccall f_1625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1577)
static void C_ccall f_1577(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1574)
static void C_ccall f_1574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_fcall f_1236(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1130)
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1151)
static void C_ccall f_1151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1161)
static void C_ccall f_1161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1191)
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1230)
static void C_ccall f_1230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1197)
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1203)
static void C_ccall f_1203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static void C_ccall f_1207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1145)
static void C_ccall f_1145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1082)
static void C_fcall f_1082(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1010)
static void C_fcall f_1010(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1017)
static void C_ccall f_1017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1076)
static void C_ccall f_1076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1020)
static void C_ccall f_1020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1036)
static void C_ccall f_1036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_919)
static void C_fcall f_919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_935)
static void C_ccall f_935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_fcall f_904(C_word t0) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_914)
static void C_ccall f_914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_fcall f_882(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1489)
static void C_fcall trf_1489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1489(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1489(t0,t1);}

C_noret_decl(trf_1484)
static void C_fcall trf_1484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1484(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1484(t0,t1,t2);}

C_noret_decl(trf_1395)
static void C_fcall trf_1395(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1395(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1395(t0,t1,t2,t3);}

C_noret_decl(trf_1427)
static void C_fcall trf_1427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1427(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1427(t0,t1,t2);}

C_noret_decl(trf_1345)
static void C_fcall trf_1345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1345(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1345(t0,t1);}

C_noret_decl(trf_1340)
static void C_fcall trf_1340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1340(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1340(t0,t1,t2);}

C_noret_decl(trf_1265)
static void C_fcall trf_1265(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1265(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1265(t0,t1,t2,t3);}

C_noret_decl(trf_1291)
static void C_fcall trf_1291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1291(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1291(t0,t1,t2);}

C_noret_decl(trf_1909)
static void C_fcall trf_1909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1909(t0,t1);}

C_noret_decl(trf_1904)
static void C_fcall trf_1904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1904(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1904(t0,t1,t2);}

C_noret_decl(trf_1899)
static void C_fcall trf_1899(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1899(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1899(t0,t1,t2,t3);}

C_noret_decl(trf_1894)
static void C_fcall trf_1894(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1894(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1894(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1889)
static void C_fcall trf_1889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1889(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1889(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1829)
static void C_fcall trf_1829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1829(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1829(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2320)
static void C_fcall trf_2320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2320(t0,t1);}

C_noret_decl(trf_2294)
static void C_fcall trf_2294(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2294(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2294(t0,t1);}

C_noret_decl(trf_2382)
static void C_fcall trf_2382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2382(t0,t1,t2);}

C_noret_decl(trf_2152)
static void C_fcall trf_2152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2152(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2152(t0,t1);}

C_noret_decl(trf_2160)
static void C_fcall trf_2160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2160(t0,t1,t2);}

C_noret_decl(trf_2170)
static void C_fcall trf_2170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2170(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2170(t0,t1);}

C_noret_decl(trf_1693)
static void C_fcall trf_1693(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1693(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1693(t0,t1);}

C_noret_decl(trf_1688)
static void C_fcall trf_1688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1688(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1688(t0,t1,t2);}

C_noret_decl(trf_1683)
static void C_fcall trf_1683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1683(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1683(t0,t1,t2,t3);}

C_noret_decl(trf_1678)
static void C_fcall trf_1678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1678(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1678(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1539)
static void C_fcall trf_1539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1539(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_1539(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_1236)
static void C_fcall trf_1236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1236(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1236(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1082)
static void C_fcall trf_1082(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1082(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1082(t0,t1);}

C_noret_decl(trf_1077)
static void C_fcall trf_1077(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1077(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1077(t0,t1,t2);}

C_noret_decl(trf_1010)
static void C_fcall trf_1010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1010(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1010(t0,t1,t2);}

C_noret_decl(trf_919)
static void C_fcall trf_919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_919(t0,t1,t2,t3);}

C_noret_decl(trf_904)
static void C_fcall trf_904(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_904(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_904(t0);}

C_noret_decl(trf_882)
static void C_fcall trf_882(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_882(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_882(t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(970)){
C_save(t1);
C_rereclaim2(970*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,215);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[6]=C_h_intern(&lf[6],7,"default");
lf[8]=C_h_intern(&lf[8],12,"flush-output");
lf[9]=C_h_intern(&lf[9],7,"fprintf");
lf[10]=C_h_intern(&lf[10],18,"current-error-port");
lf[11]=C_h_intern(&lf[11],19,"current-output-port");
lf[12]=C_h_intern(&lf[12],34,"setup-download#temporary-directory");
lf[14]=C_h_intern(&lf[14],26,"create-temporary-directory");
lf[16]=C_h_intern(&lf[16],5,"error");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\021version not found");
lf[18]=C_h_intern(&lf[18],4,"sort");
lf[19]=C_h_intern(&lf[19],20,"setup-api#version>=\077");
lf[20]=C_h_intern(&lf[20],31,"setup-download#locate-egg/local");
lf[21]=C_h_intern(&lf[21],13,"make-pathname");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[24]=C_h_intern(&lf[24],10,"directory\077");
lf[25]=C_h_intern(&lf[25],12,"file-exists\077");
lf[26]=C_h_intern(&lf[26],7,"warning");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000-extension has no such version - using default");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[29]=C_h_intern(&lf[29],9,"directory");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\004tags");
lf[31]=C_h_intern(&lf[31],9,"\003syserror");
lf[32]=C_h_intern(&lf[32],37,"setup-download#gather-egg-information");
lf[33]=C_h_intern(&lf[33],7,"version");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000.extension has syntactically invalid .meta file");
lf[35]=C_h_intern(&lf[35],20,"with-input-from-file");
lf[36]=C_h_intern(&lf[36],4,"read");
lf[37]=C_h_intern(&lf[37],22,"with-exception-handler");
lf[38]=C_h_intern(&lf[38],30,"call-with-current-continuation");
lf[39]=C_h_intern(&lf[39],14,"string->symbol");
lf[40]=C_h_intern(&lf[40],7,"call/cc");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[42]=C_h_intern(&lf[42],10,"filter-map");
lf[44]=C_h_intern(&lf[44],11,"\000recursive\077");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\004 -R ");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[47]=C_h_intern(&lf[47],4,"conc");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\007svn ls ");
lf[49]=C_h_intern(&lf[49],2,"qs");
lf[50]=C_h_intern(&lf[50],29,"setup-download#locate-egg/svn");
lf[51]=C_h_intern(&lf[51],13,"string-append");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\005tags/");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\006trunk/");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\005trunk");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[59]=C_h_intern(&lf[59],6,"system");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\005 1>&2");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\013svn export ");
lf[64]=C_h_intern(&lf[64],4,"meta");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\005.meta");
lf[66]=C_h_intern(&lf[66],16,"create-directory");
lf[67]=C_h_intern(&lf[67],13,"string-search");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\016^tags/([^/]+)/");
lf[69]=C_h_intern(&lf[69],20,"with-input-from-pipe");
lf[70]=C_h_intern(&lf[70],10,"read-lines");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\047checking available versions ...~%  ~a~%");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_h_intern(&lf[78],30,"setup-download#locate-egg/http");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\020not a valid port");
lf[81]=C_h_intern(&lf[81],12,"string-match");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000#(http://)\077([^/:]+)(:([^:/]+))\077(/.+)");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[84]=C_h_intern(&lf[84],11,"tcp-connect");
lf[85]=C_h_intern(&lf[85],5,"abort");
lf[86]=C_h_intern(&lf[86],24,"make-composite-condition");
lf[87]=C_h_intern(&lf[87],23,"make-property-condition");
lf[88]=C_h_intern(&lf[88],20,"setup-download-error");
lf[89]=C_h_intern(&lf[89],3,"exn");
lf[90]=C_h_intern(&lf[90],7,"message");
lf[91]=C_h_intern(&lf[91],9,"arguments");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\011[Server] ");
lf[93]=C_h_intern(&lf[93],7,"reverse");
lf[94]=C_h_intern(&lf[94],17,"close-output-port");
lf[95]=C_h_intern(&lf[95],16,"close-input-port");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[97]=C_h_intern(&lf[97],7,"display");
lf[98]=C_h_intern(&lf[98],19,"with-output-to-file");
lf[99]=C_h_intern(&lf[99],20,"\003sysread-string/port");
lf[100]=C_h_intern(&lf[100],9,"read-line");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\006  ~a~%");
lf[102]=C_h_intern(&lf[102],14,"string-suffix\077");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\0001invalid file name - possibly corrupt transmission");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\023reading files ...~%");
lf[106]=C_h_intern(&lf[106],17,"open-input-string");
lf[107]=C_h_intern(&lf[107],26,"string-concatenate-reverse");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002~%");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\017reading chunks ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000$[Tt]ransfer-[Ee]ncoding:\134s*chunked.*");
lf[113]=C_h_intern(&lf[113],12,"string-null\077");
lf[114]=C_h_intern(&lf[114],6,"signal");
lf[115]=C_h_intern(&lf[115],10,"http-fetch");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\034invalid response from server");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\003200");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~%");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\034HTTP/[0-9.]+\134s+([0-9]+)\134s+.*");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\026reading response ...~%");
lf[121]=C_h_intern(&lf[121],5,"\000port");
lf[122]=C_h_intern(&lf[122],7,"\000accept");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\003*/*");
lf[124]=C_h_intern(&lf[124],11,"\000proxy-host");
lf[125]=C_h_intern(&lf[125],11,"\000proxy-port");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\004GET ");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\011 HTTP/1.1");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\014Connection: ");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\014User-Agent: ");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\010Accept: ");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\006Host: ");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\020Content-length: ");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\007http://");
lf[141]=C_h_intern(&lf[141],15,"\003sysget-keyword");
lf[142]=C_h_intern(&lf[142],15,"\000content-length");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\005close");
lf[145]=C_h_intern(&lf[145],11,"\000connection");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\023requesting ~s ...~%");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000&connecting to host ~s, port ~a ~a...~%");
lf[148]=C_h_intern(&lf[148],17,"get-output-string");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[150]=C_h_intern(&lf[150],19,"\003syswrite-char/port");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\005(via ");
lf[152]=C_h_intern(&lf[152],18,"open-output-string");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[154]=C_decode_literal(C_heaptop,"\376B\000\000\006\077name=");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\006&mode=");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\012&tests=yes");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[158]=C_h_intern(&lf[158],8,"->string");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\011&version=");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[161]=C_h_intern(&lf[161],33,"setup-download#retrieve-extension");
lf[162]=C_h_intern(&lf[162],8,"\000version");
lf[163]=C_h_intern(&lf[163],6,"\000quiet");
lf[164]=C_h_intern(&lf[164],12,"\000destination");
lf[165]=C_h_intern(&lf[165],9,"\000username");
lf[166]=C_h_intern(&lf[166],9,"\000password");
lf[167]=C_h_intern(&lf[167],6,"\000tests");
lf[168]=C_h_intern(&lf[168],6,"\000trunk");
lf[169]=C_h_intern(&lf[169],5,"local");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000)destination for transport `local\047 ignored");
lf[171]=C_h_intern(&lf[171],3,"svn");
lf[172]=C_h_intern(&lf[172],4,"http");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000/cannot retrieve extension unsupported transport");
lf[174]=C_h_intern(&lf[174],16,"\003sysdynamic-wind");
lf[175]=C_h_intern(&lf[175],5,"\000mode");
lf[176]=C_h_intern(&lf[176],30,"setup-download#list-extensions");
lf[177]=C_h_intern(&lf[177],18,"string-concatenate");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[179]=C_h_intern(&lf[179],7,"\003sysmap");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[181]=C_h_intern(&lf[181],12,"string-chomp");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\047listing extension directory ...~%  ~a~%");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[191]=C_h_intern(&lf[191],38,"setup-download#list-extension-versions");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[194]=C_h_intern(&lf[194],17,"directory-exists\077");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\010unknown\012");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\005/tags");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\014--password=\047");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\014--username=\047");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000.cannot list extensions - unsupported transport");
lf[207]=C_h_intern(&lf[207],14,"make-parameter");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-install ");
lf[209]=C_h_intern(&lf[209],15,"chicken-version");
lf[210]=C_h_intern(&lf[210],17,"tcp-write-timeout");
lf[211]=C_h_intern(&lf[211],16,"tcp-read-timeout");
lf[212]=C_h_intern(&lf[212],19,"tcp-connect-timeout");
lf[213]=C_h_intern(&lf[213],11,"\003sysrequire");
lf[214]=C_h_intern(&lf[214],9,"setup-api");
C_register_lf2(lf,215,create_ptable());
t2=C_mutate(&lf[0] /* (set! c248 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k829 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k832 in k829 */
static void C_ccall f_834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_837,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k835 in k832 in k829 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k838 in k835 in k832 in k829 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_840,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_843,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_843,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_852,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_855,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_861,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#require");
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t2,lf[214]);}

/* k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_867,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("tcp-connect-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[212]))(3,*((C_word*)lf[212]+1),t2,C_fix(10000));}

/* k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_867,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_870,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("tcp-read-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[211]))(3,*((C_word*)lf[211]+1),t2,C_fix(20000));}

/* k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_873,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("tcp-write-timeout");
((C_proc3)C_retrieve_symbol_proc(lf[210]))(3,*((C_word*)lf[210]+1),t2,C_fix(20000));}

/* k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_873,2,t0,t1);}
t2=lf[2] /* setup-download#*quiet* */ =C_SCHEME_FALSE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_878,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("chicken-version");
((C_proc2)C_retrieve_symbol_proc(lf[209]))(2,*((C_word*)lf[209]+1),t4);}

/* k2614 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("conc");
((C_proc4)C_retrieve_symbol_proc(lf[47]))(4,*((C_word*)lf[47]+1),((C_word*)t0)[2],lf[208],t1);}

/* k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_878,2,t0,t1);}
t2=C_mutate(&lf[3] /* (set! setup-download#*chicken-install-user-agent* ...) */,t1);
t3=lf[4] /* setup-download#*trunk* */ =C_SCHEME_FALSE;;
t4=C_mutate(&lf[5] /* (set! setup-download#*mode* ...) */,lf[6]);
t5=C_mutate(&lf[7] /* (set! setup-download#d ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_882,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_902,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("make-parameter");
((C_proc3)C_retrieve_symbol_proc(lf[207]))(3,*((C_word*)lf[207]+1),t6,C_SCHEME_FALSE);}

/* k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=C_mutate((C_word*)lf[12]+1 /* (set! setup-download#temporary-directory ...) */,t1);
t3=C_mutate(&lf[13] /* (set! setup-download#get-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_904,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[15] /* (set! setup-download#existing-version ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_919,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[20]+1 /* (set! setup-download#locate-egg/local ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1008,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[32]+1 /* (set! setup-download#gather-egg-information ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1130,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate(&lf[43] /* (set! setup-download#make-svn-ls-cmd ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1236,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[50]+1 /* (set! setup-download#locate-egg/svn ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[78]+1 /* (set! setup-download#locate-egg/http ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[161]+1 /* (set! setup-download#retrieve-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2420,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[176]+1 /* (set! setup-download#list-extensions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2516,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[191]+1 /* (set! setup-download#list-extension-versions ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2565,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t13=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_SCHEME_UNDEFINED);}

/* setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2565(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+22)){
C_save_and_reclaim((void*)tr5r,(void*)f_2565r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2565r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2565r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(22);
t6=C_i_get_keyword(lf[163],t5,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[165],t5,C_SCHEME_FALSE);
t8=C_i_get_keyword(lf[166],t5,C_SCHEME_FALSE);
t9=t6;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2580,a[2]=t10,a[3]=t12,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2585,a[2]=t8,a[3]=t7,a[4]=t4,a[5]=t2,a[6]=t3,a[7]=((C_word)li68),tmp=(C_word)a,a+=8,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2609,a[2]=t12,a[3]=t10,a[4]=((C_word)li69),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#dynamic-wind");
t16=*((C_word*)lf[174]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t1,t13,t14,t15);}

/* a2608 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2609,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[19],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2585,2,t0,t1);}
t2=((C_word*)t0)[6];
t3=C_eqp(t2,lf[169]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[5];
t6=((C_word*)t0)[4];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1006,a[2]=t6,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t8,t5,lf[195]);}
else{
t4=C_eqp(t2,lf[171]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[5];
t7=((C_word*)t0)[4];
t8=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1395,a[2]=t6,a[3]=t7,a[4]=((C_word)li65),tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=t9,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1489,a[2]=t10,a[3]=((C_word)li67),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t8))){
C_trace("def-username354392");
t12=t11;
f_1489(t12,t5);}
else{
t12=C_i_car(t8);
t13=C_i_cdr(t8);
if(C_truep(C_i_nullp(t13))){
C_trace("def-password355390");
t14=t10;
f_1484(t14,t5,t12);}
else{
t14=C_i_car(t13);
t15=C_i_cdr(t13);
if(C_truep(C_i_nullp(t15))){
C_trace("body352359");
t16=t9;
f_1395(t16,t5,t12,t14);}
else{
C_trace("##sys#error");
t16=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t5,lf[0],t15);}}}}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t1,lf[206],((C_word*)t0)[6]);}}}

/* def-username354 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1489(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1489,NULL,2,t0,t1);}
C_trace("def-password355390");
t2=((C_word*)t0)[2];
f_1484(t2,t1,C_SCHEME_FALSE);}

/* def-password355 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1484(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1484,NULL,3,t0,t1,t2);}
C_trace("body352359");
t3=((C_word*)t0)[2];
f_1395(t3,t1,t2,C_SCHEME_FALSE);}

/* body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1395(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1395,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1399,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t4,lf[203],t2,lf[204]);}
else{
t5=t4;
f_1399(2,t5,lf[205]);}}

/* k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,lf[200],((C_word*)t0)[2],lf[201]);}
else{
t3=t2;
f_1402(2,t3,lf[202]);}}

/* k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1473,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1477,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t4,((C_word*)t0)[2],lf[199]);}

/* k1475 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1471 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download#make-svn-ls-cmd");
f_1236(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1408,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t2,t1,C_retrieve(lf[70]));}

/* k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1408,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[196]);}
else{
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1425,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t7,((C_word*)t0)[2],C_retrieve(lf[70]));}}

/* k1423 in k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1425,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1427(t5,((C_word*)t0)[2],t1);}

/* loop368 in k1423 in k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1427(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1427,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1462,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("string-chomp");
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,t4,lf[198]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1460 in loop368 in k1423 in k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,lf[197]);}

/* k1463 in loop368 in k1423 in k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop368381");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1427(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop368381");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1427(t6,((C_word*)t0)[3],t5);}}

/* k1419 in k1406 in k1403 in k1400 in k1397 in body352 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1);}

/* k1004 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k977 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("directory-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[194]))(3,*((C_word*)lf[194]+1),t2,t1);}

/* k983 in k977 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_992,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=((C_word)li63),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1002,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("directory");
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[193]);}}

/* k1000 in k983 in k977 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a993 in k983 in k977 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_994,3,t0,t1,t2);}
t3=*((C_word*)lf[51]+1);
C_trace("g209210");
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[192]);}

/* k990 in k983 in k977 in a2584 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1);}

/* a2579 in setup-download#list-extension-versions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2580,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_2516r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2516r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2516r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(21);
t5=C_i_get_keyword(lf[163],t4,C_SCHEME_FALSE);
t6=C_i_get_keyword(lf[165],t4,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[166],t4,C_SCHEME_FALSE);
t8=t5;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=t9,a[3]=t11,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2536,a[2]=t7,a[3]=t6,a[4]=t3,a[5]=t2,a[6]=((C_word)li59),tmp=(C_word)a,a+=7,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2560,a[2]=t11,a[3]=t9,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp);
C_trace("##sys#dynamic-wind");
t15=*((C_word*)lf[174]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t1,t12,t13,t14);}

/* a2559 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_eqp(t2,lf[169]);
if(C_truep(t3)){
t4=t1;
t5=((C_word*)t0)[4];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_963,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_965,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_973,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("directory");
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t8,t5);}
else{
t4=C_eqp(t2,lf[171]);
if(C_truep(t4)){
t5=t1;
t6=((C_word*)t0)[4];
t7=C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t6,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1340,a[2]=t8,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1345,a[2]=t9,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t7))){
C_trace("def-username298336");
t11=t10;
f_1345(t11,t5);}
else{
t11=C_i_car(t7);
t12=C_i_cdr(t7);
if(C_truep(C_i_nullp(t12))){
C_trace("def-password299334");
t13=t9;
f_1340(t13,t5,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
C_trace("body296303");
t15=t8;
f_1265(t15,t5,t11,t13);}
else{
C_trace("##sys#error");
t15=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t5,lf[0],t14);}}}}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t1,lf[190],((C_word*)t0)[5]);}}}

/* def-username298 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1345(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1345,NULL,2,t0,t1);}
C_trace("def-password299334");
t2=((C_word*)t0)[2];
f_1340(t2,t1,C_SCHEME_FALSE);}

/* def-password299 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1340(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1340,NULL,3,t0,t1,t2);}
C_trace("body296303");
t3=((C_word*)t0)[2];
f_1265(t3,t1,t2,C_SCHEME_FALSE);}

/* body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1265(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1265,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1269,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t4,lf[187],t2,lf[188]);}
else{
t5=t4;
f_1269(2,t5,lf[189]);}}

/* k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,lf[184],((C_word*)t0)[2],lf[185]);}
else{
t3=t2;
f_1272(2,t3,lf[186]);}}

/* k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download#make-svn-ls-cmd");
f_1236(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1278,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#d");
f_882(t2,lf[183],C_a_i_list(&a,1,t1));}

/* k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1278,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1289,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
C_trace("with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t7,((C_word*)t0)[2],C_retrieve(lf[70]));}

/* k1287 in k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1289,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1291(t5,((C_word*)t0)[2],t1);}

/* loop311 in k1287 in k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1291(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1291,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1326,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("string-chomp");
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),t5,t4,lf[182]);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1324 in loop311 in k1287 in k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1,lf[180]);}

/* k1327 in loop311 in k1287 in k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1329,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop311324");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1291(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
C_trace("loop311324");
t6=((C_word*)((C_word*)t0)[4])[1];
f_1291(t6,((C_word*)t0)[3],t5);}}

/* k1283 in k1276 in k1273 in k1270 in k1267 in body296 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1);}

/* k971 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("map");
t2=*((C_word*)lf[179]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a964 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_965,3,t0,t1,t2);}
t3=*((C_word*)lf[51]+1);
C_trace("g184185");
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[178]);}

/* k961 in a2535 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-concatenate");
((C_proc3)C_retrieve_symbol_proc(lf[177]))(3,*((C_word*)lf[177]+1),((C_word*)t0)[2],t1);}

/* a2530 in setup-download#list-extensions in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2531,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_2420r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_2420r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_2420r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word *a=C_alloc(18);
t6=C_i_get_keyword(lf[162],t5,C_SCHEME_FALSE);
t7=C_i_get_keyword(lf[163],t5,C_SCHEME_FALSE);
t8=C_i_get_keyword(lf[164],t5,C_SCHEME_FALSE);
t9=C_i_get_keyword(lf[165],t5,C_SCHEME_FALSE);
t10=C_i_get_keyword(lf[166],t5,C_SCHEME_FALSE);
t11=C_i_get_keyword(lf[167],t5,C_SCHEME_FALSE);
t12=C_i_get_keyword(lf[124],t5,C_SCHEME_FALSE);
t13=C_i_get_keyword(lf[125],t5,C_SCHEME_FALSE);
t14=C_i_get_keyword(lf[168],t5,C_SCHEME_FALSE);
t15=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2451,a[2]=t1,a[3]=t13,a[4]=t12,a[5]=t11,a[6]=t10,a[7]=t9,a[8]=t8,a[9]=t6,a[10]=t4,a[11]=t2,a[12]=t3,a[13]=t14,a[14]=t7,tmp=(C_word)a,a+=15,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2513,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[141]+1)))(5,*((C_word*)lf[141]+1),t15,lf[175],t5,t16);}

/* a2512 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2513,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[6]);}

/* k2449 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2451,2,t0,t1);}
t2=((C_word*)t0)[14];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=((C_word*)t0)[13];
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=t1;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2456,a[2]=t7,a[3]=t5,a[4]=t3,a[5]=t13,a[6]=t11,a[7]=t9,a[8]=((C_word)li48),tmp=(C_word)a,a+=9,tmp);
t15=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word)li49),tmp=(C_word)a,a+=13,tmp);
t16=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2504,a[2]=t13,a[3]=t11,a[4]=t9,a[5]=t7,a[6]=t5,a[7]=t3,a[8]=((C_word)li50),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#dynamic-wind");
t17=*((C_word*)lf[174]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,((C_word*)t0)[2],t14,t15,t16);}

/* a2503 in k2449 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,C_retrieve2(lf[4],"setup-download#*trunk*"));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[5],"setup-download#*mode*"));
t5=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate(&lf[4] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(&lf[5] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* a2464 in k2449 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2465,2,t0,t1);}
t2=((C_word*)t0)[11];
t3=C_eqp(t2,lf[169]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2475,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("warning");
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,lf[170]);}
else{
C_trace("setup-download#locate-egg/local");
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7]);}}
else{
t4=C_eqp(t2,lf[171]);
if(C_truep(t4)){
C_trace("setup-download#locate-egg/svn");
((C_proc8)C_retrieve_symbol_proc(lf[50]))(8,*((C_word*)lf[50]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5]);}
else{
t5=C_eqp(t2,lf[172]);
if(C_truep(t5)){
C_trace("setup-download#locate-egg/http");
((C_proc9)C_retrieve_symbol_proc(lf[78]))(9,*((C_word*)lf[78]+1),t1,((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t1,lf[173],((C_word*)t0)[11]);}}}}

/* k2473 in a2464 in k2449 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download#locate-egg/local");
((C_proc6)C_retrieve_symbol_proc(lf[20]))(6,*((C_word*)lf[20]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2455 in k2449 in setup-download#retrieve-extension in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2456,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,C_retrieve2(lf[2],"setup-download#*quiet*"));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,C_retrieve2(lf[4],"setup-download#*trunk*"));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[5],"setup-download#*mode*"));
t5=C_mutate(&lf[2] /* (set! setup-download#*quiet* ...) */,((C_word*)((C_word*)t0)[4])[1]);
t6=C_mutate(&lf[4] /* (set! setup-download#*trunk* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(&lf[5] /* (set! setup-download#*mode* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+25)){
C_save_and_reclaim((void*)tr4r,(void*)f_1827r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1827r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1827r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a=C_alloc(25);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1829,a[2]=t2,a[3]=t3,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1889,a[2]=t5,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1894,a[2]=t6,a[3]=((C_word)li43),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1899,a[2]=t7,a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1904,a[2]=t8,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1909,a[2]=t9,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version490541");
t11=t10;
f_1909(t11,t1);}
else{
t11=C_i_car(t4);
t12=C_i_cdr(t4);
if(C_truep(C_i_nullp(t12))){
C_trace("def-destination491539");
t13=t9;
f_1904(t13,t1,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
C_trace("def-tests492536");
t15=t8;
f_1899(t15,t1,t11,t13);}
else{
t15=C_i_car(t14);
t16=C_i_cdr(t14);
if(C_truep(C_i_nullp(t16))){
C_trace("def-proxy-host493532");
t17=t7;
f_1894(t17,t1,t11,t13,t15);}
else{
t17=C_i_car(t16);
t18=C_i_cdr(t16);
if(C_truep(C_i_nullp(t18))){
C_trace("def-proxy-port494527");
t19=t6;
f_1889(t19,t1,t11,t13,t15,t17);}
else{
t19=C_i_car(t18);
t20=C_i_cdr(t18);
if(C_truep(C_i_nullp(t20))){
C_trace("body488498");
t21=t5;
f_1829(t21,t1,t11,t13,t15,t17,t19);}
else{
C_trace("##sys#error");
t21=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t21+1)))(4,t21,t1,lf[0],t20);}}}}}}}

/* def-version490 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1909,NULL,2,t0,t1);}
C_trace("def-destination491539");
t2=((C_word*)t0)[2];
f_1904(t2,t1,C_SCHEME_FALSE);}

/* def-destination491 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1904(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1904,NULL,3,t0,t1,t2);}
C_trace("def-tests492536");
t3=((C_word*)t0)[2];
f_1899(t3,t1,t2,C_SCHEME_FALSE);}

/* def-tests492 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1899(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1899,NULL,4,t0,t1,t2,t3);}
C_trace("def-proxy-host493532");
t4=((C_word*)t0)[2];
f_1894(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-proxy-host493 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1894(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1894,NULL,5,t0,t1,t2,t3,t4);}
C_trace("def-proxy-port494527");
t5=((C_word*)t0)[2];
f_1889(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* def-proxy-port494 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1889(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1889,NULL,6,t0,t1,t2,t3,t4,t5);}
C_trace("body488498");
t6=((C_word*)t0)[2];
f_1829(t6,t1,t2,t3,t4,t5,C_SCHEME_FALSE);}

/* body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1829(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1829,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1833,a[2]=t1,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t6,a[6]=t5,a[7]=t2,a[8]=((C_word*)t0)[3],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t8=t7;
f_1833(2,t8,t3);}
else{
C_trace("setup-download#get-temporary-directory");
f_904(t7);}}

/* k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[8],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1844,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li40),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1844,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1874,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t5,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t6,lf[159],((C_word*)t0)[7]);}
else{
t7=t6;
f_1874(2,t7,lf[160]);}}

/* k1872 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1878,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("->string");
((C_proc3)C_retrieve_symbol_proc(lf[158]))(3,*((C_word*)lf[158]+1),t2,C_retrieve2(lf[5],"setup-download#*mode*"));}

/* k1876 in k1872 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[6])){
C_trace("string-append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[51]+1)))(9,*((C_word*)lf[51]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[154],((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[156]);}
else{
C_trace("string-append");
((C_proc9)C_retrieve_proc(*((C_word*)lf[51]+1)))(9,*((C_word*)lf[51]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[154],((C_word*)t0)[3],((C_word*)t0)[2],lf[155],t1,lf[157]);}}

/* k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1867,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,t1);}

/* k1865 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1867(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_1854(2,t2,C_SCHEME_UNDEFINED);}
else{
C_trace("create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[28],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1857,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
t5=((C_word*)t0)[4];
t6=((C_word*)t0)[7];
t7=((C_word*)t0)[3];
t8=((C_word*)t0)[2];
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2102,a[2]=t2,a[3]=t5,a[4]=t6,a[5]=t4,a[6]=t8,a[7]=t3,a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2331,a[2]=t4,a[3]=t3,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t7)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2334,a[2]=t7,a[3]=t8,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
C_trace("open-output-string");
((C_proc2)C_retrieve_symbol_proc(lf[152]))(2,*((C_word*)lf[152]+1),t11);}
else{
C_trace("setup-download#d");
f_882(t9,lf[147],C_a_i_list(&a,3,t3,t4,lf[153]));}}

/* k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2337,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),t2,lf[151],t1);}

/* k2335 in k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2337,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k2338 in k2335 in k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("write-char/port");
t3=C_retrieve(lf[150]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[3]);}

/* k2341 in k2338 in k2335 in k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2344 in k2341 in k2338 in k2335 in k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),t2,lf[149],((C_word*)t0)[2]);}

/* k2347 in k2344 in k2341 in k2338 in k2335 in k2332 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-output-string");
((C_proc3)C_retrieve_symbol_proc(lf[148]))(3,*((C_word*)lf[148]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2329 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
C_trace("setup-download#d");
f_882(((C_word*)t0)[4],lf[147],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2107,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word)li30),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],a[8]=((C_word)li39),tmp=(C_word)a,a+=9,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2121(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2121,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t5,a[10]=t3,tmp=(C_word)a,a+=11,tmp);
C_trace("setup-download#d");
f_882(t6,lf[146],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2327,a[2]=((C_word*)t0)[10],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*");
t5=C_a_i_list(&a,8,lf[121],((C_word*)t0)[6],lf[122],lf[123],lf[124],((C_word*)t0)[5],lf[125],((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2024,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2060,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[141]+1)))(5,*((C_word*)lf[141]+1),t6,lf[121],t5,t7);}

/* a2059 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2060,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(80));}

/* k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2027,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2057,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[141]+1)))(5,*((C_word*)lf[141]+1),t2,lf[145],((C_word*)t0)[5],t3);}

/* a2056 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2057,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[144]);}

/* k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2054,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[141]+1)))(5,*((C_word*)lf[141]+1),t2,lf[122],((C_word*)t0)[6],t3);}

/* a2053 in k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[143]);}

/* k2028 in k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2051,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp);
C_trace("##sys#get-keyword");
((C_proc5)C_retrieve_proc(*((C_word*)lf[141]+1)))(5,*((C_word*)lf[141]+1),t2,lf[142],((C_word*)t0)[7],t3);}

/* a2050 in k2028 in k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}

/* k2031 in k2028 in k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
t2=C_i_get_keyword(lf[124],((C_word*)t0)[8],C_SCHEME_FALSE);
t3=C_i_get_keyword(lf[125],((C_word*)t0)[8],C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2046,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t4,lf[140],((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
t5=t4;
f_2046(2,t5,((C_word*)t0)[2]);}}

/* k2044 in k2031 in k2028 in k2025 in k2022 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("conc");
((C_proc24)C_retrieve_symbol_proc(lf[47]))(24,*((C_word*)lf[47]+1),((C_word*)t0)[7],lf[126],t1,lf[127],lf[128],lf[129],((C_word*)t0)[6],lf[130],lf[131],C_retrieve2(lf[3],"setup-download#*chicken-install-user-agent*"),lf[132],lf[133],((C_word*)t0)[5],lf[134],lf[135],((C_word*)t0)[4],C_make_character(58),((C_word*)t0)[3],lf[136],lf[137],((C_word*)t0)[2],lf[138],lf[139]);}

/* k2325 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("display");
((C_proc4)C_retrieve_proc(*((C_word*)lf[97]+1)))(4,*((C_word*)lf[97]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),t2,((C_word*)t0)[5]);}

/* k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download#d");
f_882(t2,lf[120],C_SCHEME_END_OF_LIST);}

/* k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2137,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
C_trace("read-line");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}

/* k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2140,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=t1;
if(C_truep(C_i_stringp(t3))){
C_trace("string-match");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,lf[119],t3);}
else{
t4=t2;
f_2140(2,t4,C_SCHEME_FALSE);}}

/* k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2143,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("setup-download#d");
f_882(t2,lf[118],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2143,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2146,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2320,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
if(C_truep(t4)){
t5=C_i_cadr(t4);
t6=t3;
f_2320(t6,C_i_string_equal_p(lf[117],t5));}
else{
t5=t3;
f_2320(t5,C_SCHEME_FALSE);}}

/* k2318 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2146(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=C_a_i_list(&a,1,((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2010,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[87]))(7,*((C_word*)lf[87]+1),t4,lf[89],lf[90],lf[116],lf[91],t2);}}

/* k2012 in k2318 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,lf[115]);}

/* k2016 in k2012 in k2318 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2008 in k2318 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("signal");
((C_proc3)C_retrieve_symbol_proc(lf[114]))(3,*((C_word*)lf[114]+1),((C_word*)t0)[2],t1);}

/* k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2294,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word)li34),tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_2294(t6,t2);}

/* loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2294(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2294,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("read-line");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2296 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2304,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("string-null?");
((C_proc3)C_retrieve_symbol_proc(lf[113]))(3,*((C_word*)lf[113]+1),t2,t1);}

/* k2302 in k2296 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
C_trace("string-match");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t2,lf[112],t3);}}

/* k2314 in k2302 in k2296 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2316,2,t0,t1);}
if(C_truep(t1)){
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f2761,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#d");
f_882(t3,lf[111],C_a_i_list(&a,1,((C_word*)t0)[2]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f2765,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#d");
f_882(t2,lf[111],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* f2765 in k2314 in k2302 in k2296 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("loop609");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2294(t2,((C_word*)t0)[2]);}

/* f2761 in k2314 in k2302 in k2296 in loop in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("loop609");
t2=((C_word*)((C_word*)t0)[3])[1];
f_2294(t2,((C_word*)t0)[2]);}

/* k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2149,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2152,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2282,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#d");
f_882(t3,lf[110],C_SCHEME_END_OF_LIST);}
else{
t3=t2;
f_2152(t3,C_SCHEME_UNDEFINED);}}

/* k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)((C_word*)t0)[3])[1];
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2382,a[2]=t3,a[3]=t5,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_2382(t7,t2,C_SCHEME_END_OF_LIST);}

/* get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2382,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2386,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
C_trace("read-line");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t4,((C_word*)t0)[2]);}

/* k2416 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string->number");
C_string_to_number(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k2384 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2386,2,t0,t1);}
if(C_truep(C_i_zerop(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#d");
f_882(t2,lf[108],C_SCHEME_END_OF_LIST);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[99]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}}

/* k2399 in k2384 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2404,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download#d");
f_882(t2,lf[109],C_SCHEME_END_OF_LIST);}

/* k2402 in k2399 in k2384 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("read-line");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,((C_word*)t0)[2]);}

/* k2405 in k2402 in k2399 in k2384 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2407,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("get-chunks655");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2382(t3,((C_word*)t0)[2],t2);}

/* k2393 in k2384 in get-chunks in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("string-concatenate-reverse");
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2283 in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2288,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[95]+1)))(3,*((C_word*)lf[95]+1),t2,((C_word*)((C_word*)t0)[3])[1]);}

/* k2286 in k2283 in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("open-input-string");
((C_proc3)C_retrieve_symbol_proc(lf[106]))(3,*((C_word*)lf[106]+1),t2,((C_word*)t0)[2]);}

/* k2290 in k2286 in k2283 in k2280 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2152(t3,t2);}

/* k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2152(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2152,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2155,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download#d");
f_882(t2,lf[105],C_SCHEME_END_OF_LIST);}

/* k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2155,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2160,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word)li32),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_2160(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2160,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
C_trace("read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,((C_word*)((C_word*)t0)[4])[1]);}

/* k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t1))){
t3=C_i_car(t1);
t4=t2;
f_2170(t4,C_eqp(lf[16],t3));}
else{
t3=t2;
f_2170(t3,C_SCHEME_FALSE);}}

/* k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_2170(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2170,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[8]);
t3=C_i_cddr(((C_word*)t0)[8]);
t4=((C_word*)t0)[7];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2362,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2366,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2374,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t7,lf[92],t2);}
else{
t2=C_eofp(((C_word*)t0)[8]);
t3=(C_truep(t2)?t2:C_i_not(((C_word*)t0)[8]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2193,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
C_trace("close-input-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[95]+1)))(3,*((C_word*)lf[95]+1),t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2214,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("string-suffix?");
((C_proc4)C_retrieve_symbol_proc(lf[102]))(4,*((C_word*)lf[102]+1),t4,lf[103],((C_word*)t0)[8]);}
else{
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),((C_word*)t0)[7],lf[104],((C_word*)t0)[8]);}}}}

/* k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2214,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
C_trace("read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
C_trace("setup-download#d");
f_882(t2,lf[101],C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2236,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
C_trace("read");
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2239,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
C_trace("read-line");
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2237 in k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2242,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
C_trace("read-string/port");
t3=C_retrieve(lf[99]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2240 in k2237 in k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2245,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2256,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6]);}

/* k2254 in k2240 in k2237 in k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[3],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
C_trace("with-output-to-file");
((C_proc4)C_retrieve_symbol_proc(lf[98]))(4,*((C_word*)lf[98]+1),((C_word*)t0)[2],t1,t2);}

/* a2257 in k2254 in k2240 in k2237 in k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2258,2,t0,t1);}
t2=*((C_word*)lf[97]+1);
C_trace("g640641");
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k2243 in k2240 in k2237 in k2234 in k2231 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2245,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
C_trace("get-files620");
t3=((C_word*)((C_word*)t0)[3])[1];
f_2160(t3,((C_word*)t0)[2],t2);}

/* k2215 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
C_trace("setup-download#d");
f_882(t2,lf[96],C_a_i_list(&a,1,((C_word*)t0)[2]));}

/* k2218 in k2215 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2230,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2228 in k2218 in k2215 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),((C_word*)t0)[2],t1);}

/* k2221 in k2218 in k2215 in k2212 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("get-files620");
t2=((C_word*)((C_word*)t0)[4])[1];
f_2160(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2191 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_trace("close-output-port");
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2]);}

/* k2194 in k2191 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("reverse");
((C_proc3)C_retrieve_proc(*((C_word*)lf[93]+1)))(3,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2372 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-property-condition");
((C_proc7)C_retrieve_symbol_proc(lf[87]))(7,*((C_word*)lf[87]+1),((C_word*)t0)[3],lf[89],lf[90],t1,lf[91],((C_word*)t0)[2]);}

/* k2364 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2370,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
C_trace("make-property-condition");
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),t2,lf[88]);}

/* k2368 in k2364 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-composite-condition");
((C_proc4)C_retrieve_symbol_proc(lf[86]))(4,*((C_word*)lf[86]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2360 in k2168 in k2162 in get-files in k2153 in k2150 in k2147 in k2144 in k2141 in k2138 in k2135 in k2132 in k2129 in k2126 in k2123 in a2120 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("abort");
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],t1);}

/* a2106 in k2100 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_2107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2107,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
if(C_truep(((C_word*)t0)[3])){
C_trace("tcp-connect");
((C_proc4)C_retrieve_symbol_proc(lf[84]))(4,*((C_word*)lf[84]+1),t1,t2,((C_word*)t0)[3]);}
else{
C_trace("tcp-connect");
((C_proc4)C_retrieve_symbol_proc(lf[84]))(4,*((C_word*)lf[84]+1),t1,t2,((C_word*)t0)[2]);}}

/* k1855 in k1852 in k1849 in k1846 in a1843 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[4];
if(C_truep(t2)){
C_trace("values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
C_trace("values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[83]);}}

/* a1837 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("string-match");
((C_proc4)C_retrieve_symbol_proc(lf[81]))(4,*((C_word*)lf[81]+1),t3,lf[82],t2);}

/* k1779 in a1837 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1781,2,t0,t1);}
t2=(C_truep(t1)?C_i_caddr(t1):((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1792,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(t1)?C_i_cadddr(t1):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_i_list_ref(t1,C_fix(4));
C_trace("string->number");
C_string_to_number(3,0,t5,t6);}
else{
t5=t3;
f_1792(2,t5,C_fix(80));}}

/* k1803 in k1779 in a1837 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_1792(2,t3,t2);}
else{
t2=C_i_list_ref(((C_word*)t0)[2],C_fix(4));
C_trace("error");
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),((C_word*)t0)[3],lf[80],t2);}}

/* k1790 in k1779 in a1837 in k1831 in body488 in setup-download#locate-egg/http in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=C_i_list_ref(((C_word*)t0)[4],C_fix(5));
C_trace("values");
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}
else{
C_trace("values");
C_values(5,0,((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[79]);}}

/* setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr4r,(void*)f_1537r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1537r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1537r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a=C_alloc(21);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1539,a[2]=t3,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1678,a[2]=t5,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1683,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1688,a[2]=t7,a[3]=((C_word)li26),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1693,a[2]=t8,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version412457");
t10=t9;
f_1693(t10,t1);}
else{
t10=C_i_car(t4);
t11=C_i_cdr(t4);
if(C_truep(C_i_nullp(t11))){
C_trace("def-destination413455");
t12=t8;
f_1688(t12,t1,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
C_trace("def-username414452");
t14=t7;
f_1683(t14,t1,t10,t12);}
else{
t14=C_i_car(t13);
t15=C_i_cdr(t13);
if(C_truep(C_i_nullp(t15))){
C_trace("def-password415448");
t16=t6;
f_1678(t16,t1,t10,t12,t14);}
else{
t16=C_i_car(t15);
t17=C_i_cdr(t15);
if(C_truep(C_i_nullp(t17))){
C_trace("body410419");
t18=t5;
f_1539(t18,t1,t10,t12,t14,t16);}
else{
C_trace("##sys#error");
t18=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t18+1)))(4,t18,t1,lf[0],t17);}}}}}}

/* def-version412 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1693(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1693,NULL,2,t0,t1);}
C_trace("def-destination413455");
t2=((C_word*)t0)[2];
f_1688(t2,t1,C_SCHEME_FALSE);}

/* def-destination413 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1688(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1688,NULL,3,t0,t1,t2);}
C_trace("def-username414452");
t3=((C_word*)t0)[2];
f_1683(t3,t1,t2,C_SCHEME_FALSE);}

/* def-username414 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1683(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1683,NULL,4,t0,t1,t2,t3);}
C_trace("def-password415448");
t4=((C_word*)t0)[2];
f_1678(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* def-password415 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1678(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1678,NULL,5,t0,t1,t2,t3,t4);}
C_trace("body410419");
t5=((C_word*)t0)[2];
f_1539(t5,t1,t2,t3,t4,C_SCHEME_FALSE);}

/* body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1539,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1543,a[2]=t5,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t6,lf[75],t4,lf[76]);}
else{
t7=t6;
f_1543(2,t7,lf[77]);}}

/* k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1546,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
C_trace("string-append");
((C_proc5)C_retrieve_proc(*((C_word*)lf[51]+1)))(5,*((C_word*)lf[51]+1),t2,lf[72],((C_word*)t0)[2],lf[73]);}
else{
t3=t2;
f_1546(2,t3,lf[74]);}}

/* k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1546,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1549,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1671,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[4],((C_word*)t0)[7]);}

/* k1669 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
C_trace("setup-download#make-svn-ls-cmd");
f_1236(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_a_i_list(&a,2,lf[44],C_SCHEME_TRUE));}

/* k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
C_trace("setup-download#d");
f_882(t2,lf[71],C_a_i_list(&a,1,t1));}

/* k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1552,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
C_trace("with-input-from-pipe");
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t2,((C_word*)t0)[2],C_retrieve(lf[70]));}

/* k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1555,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1558,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1655,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1657,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp);
C_trace("filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t3,t4,t1);}

/* a1656 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1657,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1661,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("string-search");
((C_proc4)C_retrieve_symbol_proc(lf[67]))(4,*((C_word*)lf[67]+1),t3,lf[68],t2);}

/* k1659 in a1656 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_i_cadr(t1):C_SCHEME_FALSE));}

/* k1653 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download#existing-version");
f_919(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1558,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t1,a[6]=((C_word)li20),tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li21),tmp=(C_word)a,a+=8,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1591,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1595,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t3,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1648,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t4,t5,((C_word*)t0)[4]);}
else{
C_trace("setup-download#get-temporary-directory");
f_904(t6);}}

/* k1646 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[7],a[3]=t1,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t5=C_eqp(C_retrieve2(lf[5],"setup-download#*mode*"),lf[64]);
if(C_truep(t5)){
t6=((C_word*)t0)[2];
t7=((C_word*)t0)[4];
C_trace("conc");
((C_proc6)C_retrieve_symbol_proc(lf[47]))(6,*((C_word*)lf[47]+1),t4,t6,C_make_character(47),t7,lf[65]);}
else{
t6=((C_word*)t0)[2];
C_trace("conc");
((C_proc7)C_retrieve_symbol_proc(lf[47]))(7,*((C_word*)lf[47]+1),t3,((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[4],C_make_character(47),t6);}}

/* k1636 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1638(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("conc");
((C_proc7)C_retrieve_symbol_proc(lf[47]))(7,*((C_word*)lf[47]+1),((C_word*)t0)[4],((C_word*)t0)[3],C_make_character(47),((C_word*)t0)[2],C_make_character(47),t1);}

/* k1619 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1621,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1625,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(C_retrieve2(lf[5],"setup-download#*mode*"),lf[64]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1631,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
C_trace("create-directory");
((C_proc3)C_retrieve_symbol_proc(lf[66]))(3,*((C_word*)lf[66]+1),t4,((C_word*)t0)[3]);}
else{
t4=t2;
f_1625(2,t4,((C_word*)t0)[3]);}}

/* k1629 in k1619 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
C_trace("conc");
((C_proc6)C_retrieve_symbol_proc(lf[47]))(6,*((C_word*)lf[47]+1),((C_word*)t0)[2],t2,C_make_character(47),t3,lf[65]);}

/* k1623 in k1619 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
t5=(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))?lf[61]:lf[62]);
C_trace("conc");
((C_proc15)C_retrieve_symbol_proc(lf[47]))(15,*((C_word*)lf[47]+1),((C_word*)t0)[2],lf[63],t2,C_make_character(32),t3,C_make_character(32),C_make_character(34),t4,C_make_character(34),C_make_character(32),C_make_character(34),t1,C_make_character(34),t5);}

/* k1596 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1601,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("setup-download#d");
f_882(t2,lf[60],C_a_i_list(&a,1,t1));}

/* k1599 in k1596 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1617,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("system");
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),t2,((C_word*)t0)[2]);}

/* k1615 in k1599 in k1596 in k1593 in a1590 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_zerop(t1))){
C_trace("values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
C_trace("values");
C_values(4,0,((C_word*)t0)[4],C_SCHEME_FALSE,lf[58]);}}

/* a1562 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1574,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("string-append");
((C_proc4)C_retrieve_proc(*((C_word*)lf[51]+1)))(4,*((C_word*)lf[51]+1),t2,lf[52],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1577,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
if(C_truep(t4)){
C_trace("warning");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,lf[27],t3,t4);}
else{
if(C_truep(C_i_member(lf[53],((C_word*)t0)[4]))){
C_trace("values");
C_values(4,0,t1,lf[54],lf[55]);}
else{
C_trace("values");
C_values(4,0,t1,lf[56],lf[57]);}}}}

/* k1575 in a1562 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1577(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_member(lf[53],((C_word*)t0)[3]))){
C_trace("values");
C_values(4,0,((C_word*)t0)[2],lf[54],lf[55]);}
else{
C_trace("values");
C_values(4,0,((C_word*)t0)[2],lf[56],lf[57]);}}

/* k1572 in a1562 in k1556 in k1553 in k1550 in k1547 in k1544 in k1541 in body410 in setup-download#locate-egg/svn in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#make-svn-ls-cmd in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1236(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1236,NULL,5,t1,t2,t3,t4,t5);}
t6=C_i_get_keyword(lf[44],t5,C_SCHEME_FALSE);
t7=(C_truep(t6)?lf[45]:lf[46]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1251,a[2]=t7,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
C_trace("qs");
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t8,t4);}

/* k1249 in setup-download#make-svn-ls-cmd in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("conc");
((C_proc8)C_retrieve_symbol_proc(lf[47]))(8,*((C_word*)lf[47]+1),((C_word*)t0)[5],lf[48],((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1130(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1130,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1134,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
C_trace("directory");
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t3,t2);}

/* k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1134,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[3],a[3]=((C_word)li17),tmp=(C_word)a,a+=4,tmp);
C_trace("filter-map");
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t2,t1);}

/* a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1139,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1145,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1151,a[2]=t2,a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t3,t4);}

/* a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1151(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1151,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1155,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
C_trace("make-pathname");
((C_proc5)C_retrieve_symbol_proc(lf[21]))(5,*((C_word*)lf[21]+1),t4,t2,((C_word*)t0)[2],lf[41]);}

/* k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1155,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1161,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t2,t1);}

/* k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1161,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li15),tmp=(C_word)a,a+=6,tmp);
C_trace("call/cc");
((C_proc3)C_retrieve_proc(*((C_word*)lf[40]+1)))(3,*((C_word*)lf[40]+1),((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1166,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1174,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
C_trace("string->symbol");
((C_proc3)C_retrieve_proc(*((C_word*)lf[39]+1)))(3,*((C_word*)lf[39]+1),t3,((C_word*)t0)[3]);}

/* k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1174,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[33],((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1186,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1191,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li14),tmp=(C_word)a,a+=6,tmp);
C_trace("call-with-current-continuation");
((C_proc3)C_retrieve_proc(*((C_word*)lf[38]+1)))(3,*((C_word*)lf[38]+1),t3,t4);}

/* a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1197,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li9),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1212,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li13),tmp=(C_word)a,a+=5,tmp);
C_trace("with-exception-handler");
((C_proc4)C_retrieve_symbol_proc(lf[37]))(4,*((C_word*)lf[37]+1),t1,t3,t4);}

/* a1211 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[3],a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1224,a[2]=((C_word*)t0)[2],a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
C_trace("##sys#call-with-values");
C_call_with_values(4,0,t1,t2,t3);}

/* a1223 in a1211 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1224r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1224r(t0,t1,t2);}}

static void C_ccall f_1224r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1230,a[2]=t2,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
C_trace("k263267");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1229 in a1223 in a1211 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1230,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1217 in a1211 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
C_trace("with-input-from-file");
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),t1,((C_word*)t0)[2],*((C_word*)lf[36]+1));}

/* a1196 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1197,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1203,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp);
C_trace("k263267");
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1202 in a1196 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1207,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
C_trace("warning");
((C_proc4)C_retrieve_symbol_proc(lf[26]))(4,*((C_word*)lf[26]+1),t2,lf[34],((C_word*)t0)[2]);}

/* k1205 in a1202 in a1196 in a1190 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("return262");
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1184 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
C_trace("g265266");
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1187 in k1184 in k1172 in a1165 in k1159 in k1153 in a1150 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1189,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* a1144 in a1138 in k1132 in setup-download#gather-egg-information in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1145,2,t0,t1);}
C_trace("setup-download#locate-egg/local");
((C_proc4)C_retrieve_symbol_proc(lf[20]))(4,*((C_word*)lf[20]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1008r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1008r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1008r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1010,a[2]=t3,a[3]=t2,a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1077,a[2]=t5,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1082,a[2]=t6,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
C_trace("def-version224243");
t8=t7;
f_1082(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
C_trace("def-destination225241");
t10=t6;
f_1077(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
C_trace("body222229");
t12=t5;
f_1010(t12,t1,t8);}
else{
C_trace("##sys#error");
t12=*((C_word*)lf[31]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-version224 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1082(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1082,NULL,2,t0,t1);}
C_trace("def-destination225241");
t2=((C_word*)t0)[2];
f_1077(t2,t1,C_SCHEME_FALSE);}

/* def-destination225 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1077(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1077,NULL,3,t0,t1,t2);}
C_trace("body222229");
t3=((C_word*)t0)[2];
f_1010(t3,t1,t2);}

/* body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_1010(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1010,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1014,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1017,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,t1,lf[30]);}

/* k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1020,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_retrieve2(lf[4],"setup-download#*trunk*");
if(C_truep(t3)){
t4=t2;
f_1020(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1063,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t4,t1);}}

/* k1061 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1063,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1069,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
C_trace("directory?");
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1020(2,t2,C_SCHEME_FALSE);}}

/* k1067 in k1061 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
C_trace("directory");
((C_proc3)C_retrieve_symbol_proc(lf[29]))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
f_1020(2,t2,C_SCHEME_FALSE);}}

/* k1074 in k1067 in k1061 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("setup-download#existing-version");
f_919(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1020,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1030,a[2]=t1,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[5],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_trace("make-pathname");
((C_proc4)C_retrieve_symbol_proc(lf[21]))(4,*((C_word*)lf[21]+1),t2,((C_word*)t0)[4],lf[28]);}}

/* k1031 in k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1036,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
if(C_truep(t4)){
C_trace("warning");
((C_proc5)C_retrieve_symbol_proc(lf[26]))(5,*((C_word*)lf[26]+1),t2,lf[27],t3,t4);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_1036(2,t6,t5);}}

/* k1034 in k1031 in k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1042,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
C_trace("file-exists?");
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),t3,((C_word*)t0)[3]);}

/* k1049 in k1034 in k1031 in k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("directory?");
((C_proc3)C_retrieve_symbol_proc(lf[24]))(3,*((C_word*)lf[24]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
C_trace("values");
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],lf[23]);}}

/* k1040 in k1034 in k1031 in k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
C_trace("values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],lf[22]);}
else{
C_trace("values");
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[2],lf[23]);}}

/* k1028 in k1018 in k1015 in k1012 in body222 in setup-download#locate-egg/local in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("values");
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* setup-download#existing-version in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_919(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_919,NULL,4,t1,t2,t3,t4);}
if(C_truep(t3)){
if(C_truep(C_i_member(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
C_trace("error");
((C_proc5)C_retrieve_proc(*((C_word*)lf[16]+1)))(5,*((C_word*)lf[16]+1),t1,lf[17],t2,t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_935,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("sort");
((C_proc4)C_retrieve_symbol_proc(lf[18]))(4,*((C_word*)lf[18]+1),t5,t4,C_retrieve(lf[19]));}}

/* k933 in setup-download#existing-version in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_pairp(t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_car(t1):C_SCHEME_FALSE));}

/* setup-download#get-temporary-directory in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_904(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_904,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_trace("setup-download#temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[12]))(2,*((C_word*)lf[12]+1),t2);}

/* k906 in setup-download#get-temporary-directory in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_908,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_914,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_trace("create-temporary-directory");
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),t2);}}

/* k912 in k906 in setup-download#get-temporary-directory in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_914,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
C_trace("setup-download#temporary-directory");
((C_proc3)C_retrieve_symbol_proc(lf[12]))(3,*((C_word*)lf[12]+1),t2,t1);}

/* k915 in k912 in k906 in setup-download#get-temporary-directory in k900 in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* setup-download#d in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_fcall f_882(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_882,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_886,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[2],"setup-download#*quiet*"))){
C_trace("current-error-port");
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t4);}
else{
C_trace("current-output-port");
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t4);}}

/* k884 in setup-download#d in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_889,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,C_retrieve(lf[9]),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k887 in k884 in setup-download#d in k876 in k871 in k868 in k865 in k862 in k859 in k856 in k853 in k850 in k847 in k844 in k841 in k838 in k835 in k832 in k829 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_trace("flush-output");
((C_proc3)C_retrieve_proc(*((C_word*)lf[8]+1)))(3,*((C_word*)lf[8]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[237] = {
{"toplevel:setup_download_scm",(void*)C_toplevel},
{"f_831:setup_download_scm",(void*)f_831},
{"f_834:setup_download_scm",(void*)f_834},
{"f_837:setup_download_scm",(void*)f_837},
{"f_840:setup_download_scm",(void*)f_840},
{"f_843:setup_download_scm",(void*)f_843},
{"f_846:setup_download_scm",(void*)f_846},
{"f_849:setup_download_scm",(void*)f_849},
{"f_852:setup_download_scm",(void*)f_852},
{"f_855:setup_download_scm",(void*)f_855},
{"f_858:setup_download_scm",(void*)f_858},
{"f_861:setup_download_scm",(void*)f_861},
{"f_864:setup_download_scm",(void*)f_864},
{"f_867:setup_download_scm",(void*)f_867},
{"f_870:setup_download_scm",(void*)f_870},
{"f_873:setup_download_scm",(void*)f_873},
{"f_2616:setup_download_scm",(void*)f_2616},
{"f_878:setup_download_scm",(void*)f_878},
{"f_902:setup_download_scm",(void*)f_902},
{"f_2565:setup_download_scm",(void*)f_2565},
{"f_2609:setup_download_scm",(void*)f_2609},
{"f_2585:setup_download_scm",(void*)f_2585},
{"f_1489:setup_download_scm",(void*)f_1489},
{"f_1484:setup_download_scm",(void*)f_1484},
{"f_1395:setup_download_scm",(void*)f_1395},
{"f_1399:setup_download_scm",(void*)f_1399},
{"f_1402:setup_download_scm",(void*)f_1402},
{"f_1477:setup_download_scm",(void*)f_1477},
{"f_1473:setup_download_scm",(void*)f_1473},
{"f_1405:setup_download_scm",(void*)f_1405},
{"f_1408:setup_download_scm",(void*)f_1408},
{"f_1425:setup_download_scm",(void*)f_1425},
{"f_1427:setup_download_scm",(void*)f_1427},
{"f_1462:setup_download_scm",(void*)f_1462},
{"f_1465:setup_download_scm",(void*)f_1465},
{"f_1421:setup_download_scm",(void*)f_1421},
{"f_1006:setup_download_scm",(void*)f_1006},
{"f_979:setup_download_scm",(void*)f_979},
{"f_985:setup_download_scm",(void*)f_985},
{"f_1002:setup_download_scm",(void*)f_1002},
{"f_994:setup_download_scm",(void*)f_994},
{"f_992:setup_download_scm",(void*)f_992},
{"f_2580:setup_download_scm",(void*)f_2580},
{"f_2516:setup_download_scm",(void*)f_2516},
{"f_2560:setup_download_scm",(void*)f_2560},
{"f_2536:setup_download_scm",(void*)f_2536},
{"f_1345:setup_download_scm",(void*)f_1345},
{"f_1340:setup_download_scm",(void*)f_1340},
{"f_1265:setup_download_scm",(void*)f_1265},
{"f_1269:setup_download_scm",(void*)f_1269},
{"f_1272:setup_download_scm",(void*)f_1272},
{"f_1275:setup_download_scm",(void*)f_1275},
{"f_1278:setup_download_scm",(void*)f_1278},
{"f_1289:setup_download_scm",(void*)f_1289},
{"f_1291:setup_download_scm",(void*)f_1291},
{"f_1326:setup_download_scm",(void*)f_1326},
{"f_1329:setup_download_scm",(void*)f_1329},
{"f_1285:setup_download_scm",(void*)f_1285},
{"f_973:setup_download_scm",(void*)f_973},
{"f_965:setup_download_scm",(void*)f_965},
{"f_963:setup_download_scm",(void*)f_963},
{"f_2531:setup_download_scm",(void*)f_2531},
{"f_2420:setup_download_scm",(void*)f_2420},
{"f_2513:setup_download_scm",(void*)f_2513},
{"f_2451:setup_download_scm",(void*)f_2451},
{"f_2504:setup_download_scm",(void*)f_2504},
{"f_2465:setup_download_scm",(void*)f_2465},
{"f_2475:setup_download_scm",(void*)f_2475},
{"f_2456:setup_download_scm",(void*)f_2456},
{"f_1827:setup_download_scm",(void*)f_1827},
{"f_1909:setup_download_scm",(void*)f_1909},
{"f_1904:setup_download_scm",(void*)f_1904},
{"f_1899:setup_download_scm",(void*)f_1899},
{"f_1894:setup_download_scm",(void*)f_1894},
{"f_1889:setup_download_scm",(void*)f_1889},
{"f_1829:setup_download_scm",(void*)f_1829},
{"f_1833:setup_download_scm",(void*)f_1833},
{"f_1844:setup_download_scm",(void*)f_1844},
{"f_1874:setup_download_scm",(void*)f_1874},
{"f_1878:setup_download_scm",(void*)f_1878},
{"f_1848:setup_download_scm",(void*)f_1848},
{"f_1851:setup_download_scm",(void*)f_1851},
{"f_1867:setup_download_scm",(void*)f_1867},
{"f_1854:setup_download_scm",(void*)f_1854},
{"f_2334:setup_download_scm",(void*)f_2334},
{"f_2337:setup_download_scm",(void*)f_2337},
{"f_2340:setup_download_scm",(void*)f_2340},
{"f_2343:setup_download_scm",(void*)f_2343},
{"f_2346:setup_download_scm",(void*)f_2346},
{"f_2349:setup_download_scm",(void*)f_2349},
{"f_2331:setup_download_scm",(void*)f_2331},
{"f_2102:setup_download_scm",(void*)f_2102},
{"f_2121:setup_download_scm",(void*)f_2121},
{"f_2125:setup_download_scm",(void*)f_2125},
{"f_2060:setup_download_scm",(void*)f_2060},
{"f_2024:setup_download_scm",(void*)f_2024},
{"f_2057:setup_download_scm",(void*)f_2057},
{"f_2027:setup_download_scm",(void*)f_2027},
{"f_2054:setup_download_scm",(void*)f_2054},
{"f_2030:setup_download_scm",(void*)f_2030},
{"f_2051:setup_download_scm",(void*)f_2051},
{"f_2033:setup_download_scm",(void*)f_2033},
{"f_2046:setup_download_scm",(void*)f_2046},
{"f_2327:setup_download_scm",(void*)f_2327},
{"f_2128:setup_download_scm",(void*)f_2128},
{"f_2131:setup_download_scm",(void*)f_2131},
{"f_2134:setup_download_scm",(void*)f_2134},
{"f_2137:setup_download_scm",(void*)f_2137},
{"f_2140:setup_download_scm",(void*)f_2140},
{"f_2143:setup_download_scm",(void*)f_2143},
{"f_2320:setup_download_scm",(void*)f_2320},
{"f_2014:setup_download_scm",(void*)f_2014},
{"f_2018:setup_download_scm",(void*)f_2018},
{"f_2010:setup_download_scm",(void*)f_2010},
{"f_2146:setup_download_scm",(void*)f_2146},
{"f_2294:setup_download_scm",(void*)f_2294},
{"f_2298:setup_download_scm",(void*)f_2298},
{"f_2304:setup_download_scm",(void*)f_2304},
{"f_2316:setup_download_scm",(void*)f_2316},
{"f2765:setup_download_scm",(void*)f2765},
{"f2761:setup_download_scm",(void*)f2761},
{"f_2149:setup_download_scm",(void*)f_2149},
{"f_2282:setup_download_scm",(void*)f_2282},
{"f_2382:setup_download_scm",(void*)f_2382},
{"f_2418:setup_download_scm",(void*)f_2418},
{"f_2386:setup_download_scm",(void*)f_2386},
{"f_2401:setup_download_scm",(void*)f_2401},
{"f_2404:setup_download_scm",(void*)f_2404},
{"f_2407:setup_download_scm",(void*)f_2407},
{"f_2395:setup_download_scm",(void*)f_2395},
{"f_2285:setup_download_scm",(void*)f_2285},
{"f_2288:setup_download_scm",(void*)f_2288},
{"f_2292:setup_download_scm",(void*)f_2292},
{"f_2152:setup_download_scm",(void*)f_2152},
{"f_2155:setup_download_scm",(void*)f_2155},
{"f_2160:setup_download_scm",(void*)f_2160},
{"f_2164:setup_download_scm",(void*)f_2164},
{"f_2170:setup_download_scm",(void*)f_2170},
{"f_2214:setup_download_scm",(void*)f_2214},
{"f_2233:setup_download_scm",(void*)f_2233},
{"f_2236:setup_download_scm",(void*)f_2236},
{"f_2239:setup_download_scm",(void*)f_2239},
{"f_2242:setup_download_scm",(void*)f_2242},
{"f_2256:setup_download_scm",(void*)f_2256},
{"f_2258:setup_download_scm",(void*)f_2258},
{"f_2245:setup_download_scm",(void*)f_2245},
{"f_2217:setup_download_scm",(void*)f_2217},
{"f_2220:setup_download_scm",(void*)f_2220},
{"f_2230:setup_download_scm",(void*)f_2230},
{"f_2223:setup_download_scm",(void*)f_2223},
{"f_2193:setup_download_scm",(void*)f_2193},
{"f_2196:setup_download_scm",(void*)f_2196},
{"f_2374:setup_download_scm",(void*)f_2374},
{"f_2366:setup_download_scm",(void*)f_2366},
{"f_2370:setup_download_scm",(void*)f_2370},
{"f_2362:setup_download_scm",(void*)f_2362},
{"f_2107:setup_download_scm",(void*)f_2107},
{"f_1857:setup_download_scm",(void*)f_1857},
{"f_1838:setup_download_scm",(void*)f_1838},
{"f_1781:setup_download_scm",(void*)f_1781},
{"f_1805:setup_download_scm",(void*)f_1805},
{"f_1792:setup_download_scm",(void*)f_1792},
{"f_1537:setup_download_scm",(void*)f_1537},
{"f_1693:setup_download_scm",(void*)f_1693},
{"f_1688:setup_download_scm",(void*)f_1688},
{"f_1683:setup_download_scm",(void*)f_1683},
{"f_1678:setup_download_scm",(void*)f_1678},
{"f_1539:setup_download_scm",(void*)f_1539},
{"f_1543:setup_download_scm",(void*)f_1543},
{"f_1546:setup_download_scm",(void*)f_1546},
{"f_1671:setup_download_scm",(void*)f_1671},
{"f_1549:setup_download_scm",(void*)f_1549},
{"f_1552:setup_download_scm",(void*)f_1552},
{"f_1555:setup_download_scm",(void*)f_1555},
{"f_1657:setup_download_scm",(void*)f_1657},
{"f_1661:setup_download_scm",(void*)f_1661},
{"f_1655:setup_download_scm",(void*)f_1655},
{"f_1558:setup_download_scm",(void*)f_1558},
{"f_1591:setup_download_scm",(void*)f_1591},
{"f_1648:setup_download_scm",(void*)f_1648},
{"f_1595:setup_download_scm",(void*)f_1595},
{"f_1638:setup_download_scm",(void*)f_1638},
{"f_1621:setup_download_scm",(void*)f_1621},
{"f_1631:setup_download_scm",(void*)f_1631},
{"f_1625:setup_download_scm",(void*)f_1625},
{"f_1598:setup_download_scm",(void*)f_1598},
{"f_1601:setup_download_scm",(void*)f_1601},
{"f_1617:setup_download_scm",(void*)f_1617},
{"f_1563:setup_download_scm",(void*)f_1563},
{"f_1577:setup_download_scm",(void*)f_1577},
{"f_1574:setup_download_scm",(void*)f_1574},
{"f_1236:setup_download_scm",(void*)f_1236},
{"f_1251:setup_download_scm",(void*)f_1251},
{"f_1130:setup_download_scm",(void*)f_1130},
{"f_1134:setup_download_scm",(void*)f_1134},
{"f_1139:setup_download_scm",(void*)f_1139},
{"f_1151:setup_download_scm",(void*)f_1151},
{"f_1155:setup_download_scm",(void*)f_1155},
{"f_1161:setup_download_scm",(void*)f_1161},
{"f_1166:setup_download_scm",(void*)f_1166},
{"f_1174:setup_download_scm",(void*)f_1174},
{"f_1191:setup_download_scm",(void*)f_1191},
{"f_1212:setup_download_scm",(void*)f_1212},
{"f_1224:setup_download_scm",(void*)f_1224},
{"f_1230:setup_download_scm",(void*)f_1230},
{"f_1218:setup_download_scm",(void*)f_1218},
{"f_1197:setup_download_scm",(void*)f_1197},
{"f_1203:setup_download_scm",(void*)f_1203},
{"f_1207:setup_download_scm",(void*)f_1207},
{"f_1186:setup_download_scm",(void*)f_1186},
{"f_1189:setup_download_scm",(void*)f_1189},
{"f_1145:setup_download_scm",(void*)f_1145},
{"f_1008:setup_download_scm",(void*)f_1008},
{"f_1082:setup_download_scm",(void*)f_1082},
{"f_1077:setup_download_scm",(void*)f_1077},
{"f_1010:setup_download_scm",(void*)f_1010},
{"f_1014:setup_download_scm",(void*)f_1014},
{"f_1017:setup_download_scm",(void*)f_1017},
{"f_1063:setup_download_scm",(void*)f_1063},
{"f_1069:setup_download_scm",(void*)f_1069},
{"f_1076:setup_download_scm",(void*)f_1076},
{"f_1020:setup_download_scm",(void*)f_1020},
{"f_1033:setup_download_scm",(void*)f_1033},
{"f_1036:setup_download_scm",(void*)f_1036},
{"f_1051:setup_download_scm",(void*)f_1051},
{"f_1042:setup_download_scm",(void*)f_1042},
{"f_1030:setup_download_scm",(void*)f_1030},
{"f_919:setup_download_scm",(void*)f_919},
{"f_935:setup_download_scm",(void*)f_935},
{"f_904:setup_download_scm",(void*)f_904},
{"f_908:setup_download_scm",(void*)f_908},
{"f_914:setup_download_scm",(void*)f_914},
{"f_917:setup_download_scm",(void*)f_917},
{"f_882:setup_download_scm",(void*)f_882},
{"f_886:setup_download_scm",(void*)f_886},
{"f_889:setup_download_scm",(void*)f_889},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
