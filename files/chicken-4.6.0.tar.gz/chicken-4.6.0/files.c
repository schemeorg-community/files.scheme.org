/* Generated from files.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: files.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file files.c
   unit: files
*/

#include "chicken.h"

#include <unistd.h>
#include <errno.h>

#ifndef _WIN32
# include <sys/stat.h>
# define C_mkdir(str)       C_fix(mkdir(C_c_string(str), S_IRWXU | S_IRWXG | S_IRWXO))
#else
# define C_mkdir(str)	    C_fix(mkdir(C_c_string(str)))
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[108];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,21),40,100,101,108,101,116,101,45,102,105,108,101,42,32,102,105,108,101,54,49,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,56,48,57,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,18),40,97,56,48,51,32,101,120,118,97,114,49,51,57,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,6),40,97,56,52,52,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,6),40,97,56,53,54,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,19),40,97,56,53,48,32,46,32,97,114,103,115,49,52,53,49,53,56,41,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,6),40,97,56,51,56,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,14),40,97,55,57,55,32,107,49,52,52,49,52,56,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,49,51,53,32,108,49,51,54,41};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,97,56,55,52,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,18),40,97,56,54,56,32,101,120,118,97,114,49,49,53,49,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,6),40,97,56,57,57,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,57,49,49,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,19),40,97,57,48,53,32,46,32,97,114,103,115,49,50,49,49,51,50,41,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,97,56,57,51,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,14),40,97,56,54,50,32,107,49,50,48,49,50,52,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,6),40,97,57,50,57,41,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,17),40,97,57,50,51,32,101,120,118,97,114,57,54,49,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,6),40,97,57,53,52,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,57,54,54,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,19),40,97,57,54,48,32,46,32,97,114,103,115,49,48,50,49,49,51,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,57,52,56,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,14),40,97,57,49,55,32,107,49,48,49,49,48,53,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,55,52,32,99,108,111,98,98,101,114,56,50,32,98,108,111,99,107,115,105,122,101,56,51,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,31),40,100,101,102,45,98,108,111,99,107,115,105,122,101,55,55,32,37,99,108,111,98,98,101,114,55,50,49,54,56,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,15),40,100,101,102,45,99,108,111,98,98,101,114,55,54,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,42),40,102,105,108,101,45,99,111,112,121,32,111,114,105,103,102,105,108,101,54,57,32,110,101,119,102,105,108,101,55,48,32,46,32,116,109,112,54,56,55,49,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,7),40,97,49,49,52,53,41,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,19),40,97,49,49,51,57,32,101,120,118,97,114,50,52,57,50,53,57,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,7),40,97,49,49,55,48,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,7),40,97,49,49,56,50,41,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,20),40,97,49,49,55,54,32,46,32,97,114,103,115,50,53,53,50,54,54,41,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,7),40,97,49,49,54,52,41,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,15),40,97,49,49,51,51,32,107,50,53,52,50,53,56,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,7),40,97,49,50,49,55,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,19),40,97,49,50,49,49,32,101,120,118,97,114,50,55,48,50,56,48,41,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,7),40,97,49,50,53,50,41,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,7),40,97,49,50,54,52,41,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,20),40,97,49,50,53,56,32,46,32,97,114,103,115,50,55,54,50,56,57,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,7),40,97,49,50,52,54,41,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,15),40,97,49,50,48,53,32,107,50,55,53,50,55,57,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,100,50,52,55,32,108,50,52,56,41};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,50,56,50,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,19),40,97,49,50,55,54,32,101,120,118,97,114,50,50,55,50,51,55,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,55,41,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,51,49,57,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,20),40,97,49,51,49,51,32,46,32,97,114,103,115,50,51,51,50,52,52,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,49,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,15),40,97,49,50,55,48,32,107,50,51,50,50,51,54,41,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,51,51,55,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,19),40,97,49,51,51,49,32,101,120,118,97,114,50,48,56,50,49,56,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,51,54,50,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,7),40,97,49,51,55,52,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,20),40,97,49,51,54,56,32,46,32,97,114,103,115,50,49,52,50,50,53,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,7),40,97,49,51,53,54,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,15),40,97,49,51,50,53,32,107,50,49,51,50,49,55,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,49,56,54,32,99,108,111,98,98,101,114,49,57,52,32,98,108,111,99,107,115,105,122,101,49,57,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,33),40,100,101,102,45,98,108,111,99,107,115,105,122,101,49,56,57,32,37,99,108,111,98,98,101,114,49,56,52,50,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,16),40,100,101,102,45,99,108,111,98,98,101,114,49,56,56,41};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,46),40,102,105,108,101,45,109,111,118,101,32,111,114,105,103,102,105,108,101,49,56,49,32,110,101,119,102,105,108,101,49,56,50,32,46,32,116,109,112,49,56,48,49,56,51,41,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,26),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,63,32,112,110,51,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,99,104,111,112,45,112,100,115,32,115,116,114,51,50,50,32,112,100,115,51,50,51,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,32,115,116,114,115,51,51,57,41,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,26),40,99,111,110,99,45,100,105,114,115,32,100,105,114,115,51,51,54,32,112,100,115,51,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,99,97,110,111,110,105,99,97,108,105,122,101,45,100,105,114,115,32,100,105,114,115,51,52,54,32,112,100,115,51,52,55,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,52),40,95,109,97,107,101,45,112,97,116,104,110,97,109,101,32,108,111,99,51,53,52,32,100,105,114,51,53,53,32,102,105,108,101,51,53,54,32,101,120,116,51,53,55,32,112,100,115,51,53,56,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,43),40,109,97,107,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,51,56,51,32,102,105,108,101,51,56,52,32,46,32,116,109,112,51,56,50,51,56,53,41,0,0,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,52),40,109,97,107,101,45,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,32,100,105,114,115,51,57,53,32,102,105,108,101,51,57,54,32,46,32,116,109,112,51,57,52,51,57,55,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,18),40,115,116,114,105,112,45,112,100,115,32,100,105,114,52,49,49,41,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,26),40,100,101,99,111,109,112,111,115,101,45,112,97,116,104,110,97,109,101,32,112,110,52,49,51,41,0,0,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,7),40,97,49,56,57,52,41,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,47),40,97,49,57,48,48,32,100,105,114,52,49,56,52,49,57,52,50,52,32,102,105,108,101,52,50,48,52,50,49,52,50,53,32,101,120,116,52,50,50,52,50,51,52,50,54,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,100,105,114,101,99,116,111,114,121,32,112,110,52,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,7),40,97,49,57,48,57,41,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,47),40,97,49,57,49,53,32,100,105,114,52,51,49,52,51,50,52,51,55,32,102,105,108,101,52,51,51,52,51,52,52,51,56,32,101,120,116,52,51,53,52,51,54,52,51,57,41,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,21),40,112,97,116,104,110,97,109,101,45,102,105,108,101,32,112,110,52,51,48,41,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,7),40,97,49,57,50,52,41,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,47),40,97,49,57,51,48,32,100,105,114,52,52,52,52,52,53,52,53,48,32,102,105,108,101,52,52,54,52,52,55,52,53,49,32,101,120,116,52,52,56,52,52,57,52,53,50,41,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,26),40,112,97,116,104,110,97,109,101,45,101,120,116,101,110,115,105,111,110,32,112,110,52,52,51,41,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,7),40,97,49,57,51,57,41,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,47),40,97,49,57,52,53,32,100,105,114,52,53,55,52,53,56,52,54,51,32,102,105,108,101,52,53,57,52,54,48,52,54,52,32,101,120,116,52,54,49,52,54,50,52,54,53,41,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,100,105,114,101,99,116,111,114,121,32,112,110,52,53,54,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,7),40,97,49,57,53,55,41,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,47),40,97,49,57,54,51,32,100,105,114,52,55,48,52,55,49,52,55,54,32,102,105,108,101,52,55,50,52,55,51,52,55,55,32,101,120,116,52,55,52,52,55,53,52,55,56,41,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,32),40,112,97,116,104,110,97,109,101,45,115,116,114,105,112,45,101,120,116,101,110,115,105,111,110,32,112,110,52,54,57,41};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,7),40,97,49,57,55,53,41,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,45),40,97,49,57,56,49,32,95,52,56,52,52,56,53,52,57,48,32,102,105,108,101,52,56,54,52,56,55,52,57,49,32,101,120,116,52,56,56,52,56,57,52,57,50,41,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,100,105,114,101,99,116,111,114,121,32,112,110,52,56,50,32,100,105,114,52,56,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,7),40,97,49,57,57,51,41,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,44),40,97,49,57,57,57,32,100,105,114,52,57,56,52,57,57,53,48,52,32,95,53,48,48,53,48,49,53,48,53,32,101,120,116,53,48,50,53,48,51,53,48,54,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,37),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,102,105,108,101,32,112,110,52,57,54,32,102,105,108,101,52,57,55,41,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,7),40,97,50,48,49,49,41,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,45),40,97,50,48,49,55,32,100,105,114,53,49,50,53,49,51,53,49,56,32,102,105,108,101,53,49,52,53,49,53,53,49,57,32,95,53,49,54,53,49,55,53,50,48,41,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,41),40,112,97,116,104,110,97,109,101,45,114,101,112,108,97,99,101,45,101,120,116,101,110,115,105,111,110,32,112,110,53,49,48,32,101,120,116,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,9),40,116,101,109,112,100,105,114,41,0,0,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,12),40,97,50,48,56,48,32,112,53,53,53,41,0,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,35),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,102,105,108,101,32,46,32,116,109,112,53,52,55,53,52,56,41,0,0,0,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,28),40,99,114,101,97,116,101,45,116,101,109,112,111,114,97,114,121,45,100,105,114,101,99,116,111,114,121,41,0,0,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,18),40,97,100,100,112,97,114,116,32,112,97,114,116,115,53,55,48,41,0,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,11),40,103,54,48,55,32,112,54,48,57,41,0,0,0,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,54,48,48,32,103,54,48,52,54,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,28),40,108,111,111,112,32,105,53,57,48,32,112,114,101,118,53,57,49,32,112,97,114,116,115,53,57,50,41,0,0,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,40),40,110,111,114,109,97,108,105,122,101,45,112,97,116,104,110,97,109,101,32,112,97,116,104,53,56,48,32,46,32,116,109,112,53,55,57,53,56,49,41};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,24),40,100,105,114,101,99,116,111,114,121,45,110,117,108,108,63,32,100,105,114,54,51,54,41};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,28),40,100,101,99,111,109,112,111,115,101,45,100,105,114,101,99,116,111,114,121,32,100,105,114,54,52,52,41,0,0,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,14),40,102,95,50,54,50,54,32,112,110,51,48,54,41,0,0};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,14),40,102,95,50,54,51,50,32,114,116,51,48,55,41,0,0};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,14),40,102,95,50,54,52,49,32,114,116,51,48,57,41,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,30),40,97,98,115,111,108,117,116,101,45,112,97,116,104,110,97,109,101,45,114,111,111,116,32,112,110,51,49,52,41,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,19),40,114,111,111,116,45,111,114,105,103,105,110,32,114,116,51,49,53,41,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,22),40,114,111,111,116,45,100,105,114,101,99,116,111,114,121,32,114,116,51,49,54,41,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_files_toplevel)
C_externexport void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_695)
static void C_ccall f_695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_698)
static void C_ccall f_698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_ccall f_701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2651)
static void C_ccall f_2651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2662)
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2641)
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2632)
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1474)
static void C_fcall f_1474(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2592)
static void C_ccall f_2592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_ccall f_2599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2496)
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2504)
static void C_ccall f_2504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2506)
static C_word C_fcall f_2506(C_word t0);
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_fcall f_2217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2417)
static void C_fcall f_2417(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2421)
static void C_ccall f_2421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_fcall f_2365(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2351)
static void C_ccall f_2351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2227)
static void C_fcall f_2227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2253)
static void C_ccall f_2253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2319)
static void C_ccall f_2319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2262)
static void C_ccall f_2262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2265)
static void C_ccall f_2265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2291)
static void C_ccall f_2291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2280)
static void C_fcall f_2280(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2287)
static void C_ccall f_2287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static C_word C_fcall f_2173(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2115)
static void C_ccall f_2115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2121)
static void C_fcall f_2121(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2159)
static void C_ccall f_2159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2167)
static void C_ccall f_2167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2163)
static void C_ccall f_2163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2125)
static void C_ccall f_2125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2131)
static void C_ccall f_2131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2138)
static void C_ccall f_2138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2155)
static void C_ccall f_2155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2055)
static void C_ccall f_2055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2063)
static void C_fcall f_2063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2086)
static void C_ccall f_2086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2090)
static void C_ccall f_2090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2067)
static void C_ccall f_2067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2073)
static void C_ccall f_2073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2081)
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2026)
static void C_fcall f_2026(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1988)
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1994)
static void C_ccall f_1994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1976)
static void C_ccall f_1976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1964)
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1934)
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1946)
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1940)
static void C_ccall f_1940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1919)
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1931)
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1904)
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1916)
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1889)
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1901)
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1895)
static void C_ccall f_1895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1813)
static void C_ccall f_1813(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1829)
static void C_ccall f_1829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1883)
static void C_ccall f_1883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_ccall f_1868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1839)
static void C_ccall f_1839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_fcall f_1799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1752)
static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1720)
static void C_ccall f_1720r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1724)
static void C_ccall f_1724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1634)
static void C_fcall f_1634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1687)
static void C_fcall f_1687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1670)
static void C_fcall f_1670(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_fcall f_1603(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1542)
static void C_fcall f_1542(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1551)
static void C_fcall f_1551(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1581)
static void C_ccall f_1581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_fcall f_1489(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1505)
static void C_fcall f_1505(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1422)
static void C_fcall f_1422(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1064)
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1083)
static void C_ccall f_1083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_ccall f_1382(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1338)
static void C_ccall f_1338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2838)
static void C_ccall f2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1349)
static void C_ccall f_1349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1092)
static void C_ccall f_1092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1283)
static void C_ccall f_1283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2834)
static void C_ccall f2834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1098)
static void C_ccall f_1098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1101)
static void C_ccall f_1101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1113)
static void C_fcall f_1113(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1206)
static void C_ccall f_1206(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1259)
static void C_ccall f_1259r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1265)
static void C_ccall f_1265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1253)
static void C_ccall f_1253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1212)
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1218)
static void C_ccall f_1218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1225)
static void C_ccall f_1225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1123)
static void C_ccall f_1123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1134)
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1165)
static void C_ccall f_1165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1177)
static void C_ccall f_1177r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1183)
static void C_ccall f_1183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1171)
static void C_ccall f_1171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1146)
static void C_ccall f_1146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2828)
static void C_ccall f2828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1157)
static void C_ccall f_1157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1129)
static void C_ccall f_1129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1014)
static void C_fcall f_1014(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_fcall f_1009(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_717)
static void C_fcall f_717(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1002)
static void C_ccall f_1002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_998)
static void C_ccall f_998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_733)
static void C_ccall f_733(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_736)
static void C_ccall f_736(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_991)
static void C_ccall f_991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_739)
static void C_ccall f_739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_974)
static void C_ccall f_974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_742)
static void C_ccall f_742(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_949)
static void C_ccall f_949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_961)
static void C_ccall f_961r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_967)
static void C_ccall f_967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_924)
static void C_ccall f_924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_930)
static void C_ccall f_930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2824)
static void C_ccall f2824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_748)
static void C_ccall f_748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_900)
static void C_ccall f_900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_869)
static void C_ccall f_869(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_875)
static void C_ccall f_875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f2820)
static void C_ccall f2820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_764)
static void C_ccall f_764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_766)
static void C_fcall f_766(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_857)
static void C_ccall f_857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_804)
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_820)
static void C_ccall f_820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_831)
static void C_ccall f_831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_827)
static void C_ccall f_827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_792)
static void C_ccall f_792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_779)
static void C_ccall f_779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_710)
static void C_ccall f_710(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1474)
static void C_fcall trf_1474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1474(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1474(t0,t1);}

C_noret_decl(trf_2217)
static void C_fcall trf_2217(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2217(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2217(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2417)
static void C_fcall trf_2417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2417(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2417(t0,t1);}

C_noret_decl(trf_2365)
static void C_fcall trf_2365(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2365(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2365(t0,t1);}

C_noret_decl(trf_2227)
static void C_fcall trf_2227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2227(t0,t1);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2307(t0,t1,t2);}

C_noret_decl(trf_2315)
static void C_fcall trf_2315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2315(t0,t1,t2);}

C_noret_decl(trf_2280)
static void C_fcall trf_2280(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2280(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2280(t0,t1);}

C_noret_decl(trf_2121)
static void C_fcall trf_2121(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2121(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2121(t0,t1);}

C_noret_decl(trf_2063)
static void C_fcall trf_2063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2063(t0,t1);}

C_noret_decl(trf_2026)
static void C_fcall trf_2026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2026(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2026(t0,t1);}

C_noret_decl(trf_1799)
static void C_fcall trf_1799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1799(t0,t1);}

C_noret_decl(trf_1634)
static void C_fcall trf_1634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1634(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1634(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1687)
static void C_fcall trf_1687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1687(t0,t1);}

C_noret_decl(trf_1670)
static void C_fcall trf_1670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1670(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1670(t0,t1);}

C_noret_decl(trf_1603)
static void C_fcall trf_1603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1603(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1603(t0,t1,t2,t3);}

C_noret_decl(trf_1542)
static void C_fcall trf_1542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1542(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1542(t0,t1,t2,t3);}

C_noret_decl(trf_1551)
static void C_fcall trf_1551(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1551(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1551(t0,t1,t2);}

C_noret_decl(trf_1489)
static void C_fcall trf_1489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1489(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1489(t0,t1,t2);}

C_noret_decl(trf_1505)
static void C_fcall trf_1505(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1505(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1505(t0,t1);}

C_noret_decl(trf_1422)
static void C_fcall trf_1422(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1422(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1422(t0,t1);}

C_noret_decl(trf_1417)
static void C_fcall trf_1417(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1417(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1417(t0,t1,t2);}

C_noret_decl(trf_1064)
static void C_fcall trf_1064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1064(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1064(t0,t1,t2,t3);}

C_noret_decl(trf_1113)
static void C_fcall trf_1113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1113(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1113(t0,t1,t2,t3);}

C_noret_decl(trf_1014)
static void C_fcall trf_1014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1014(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1014(t0,t1);}

C_noret_decl(trf_1009)
static void C_fcall trf_1009(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1009(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1009(t0,t1,t2);}

C_noret_decl(trf_717)
static void C_fcall trf_717(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_717(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_717(t0,t1,t2,t3);}

C_noret_decl(trf_766)
static void C_fcall trf_766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_766(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_766(t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_files_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_files_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("files_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(621)){
C_save(t1);
C_rereclaim2(621*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,108);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],12,"delete-file*");
lf[3]=C_h_intern(&lf[3],11,"delete-file");
lf[4]=C_h_intern(&lf[4],12,"file-exists\077");
lf[5]=C_h_intern(&lf[5],9,"file-copy");
lf[6]=C_h_intern(&lf[6],17,"close-output-port");
lf[7]=C_h_intern(&lf[7],16,"close-input-port");
lf[8]=C_h_intern(&lf[8],12,"read-string!");
lf[9]=C_h_intern(&lf[9],9,"condition");
lf[10]=C_h_intern(&lf[10],9,"\003syserror");
lf[11]=C_h_intern(&lf[11],13,"string-append");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[13]=C_h_intern(&lf[13],12,"write-string");
lf[14]=C_h_intern(&lf[14],22,"with-exception-handler");
lf[15]=C_h_intern(&lf[15],30,"call-with-current-continuation");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[18]=C_h_intern(&lf[18],16,"open-output-file");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[20]=C_h_intern(&lf[20],15,"open-input-file");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[24]=C_h_intern(&lf[24],9,"file-move");
lf[25]=C_decode_literal(C_heaptop,"\376B\000\000\034could not remove origfile - ");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\037error writing file starting at ");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000#could not open newfile for write - ");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000#could not open origfile for read - ");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000&newfile exists but clobber is false - ");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\032origfile does not exist - ");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\0002invalid blocksize given: not a positive integer - ");
lf[35]=C_h_intern(&lf[35],18,"absolute-pathname\077");
lf[37]=C_h_intern(&lf[37],13,"\003syssubstring");
lf[38]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[39]=C_h_intern(&lf[39],13,"make-pathname");
lf[40]=C_h_intern(&lf[40],22,"make-absolute-pathname");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[49]=C_h_intern(&lf[49],17,"\003sysstring-append");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[52]=C_h_intern(&lf[52],18,"decompose-pathname");
lf[53]=C_h_intern(&lf[53],12,"string-match");
lf[54]=C_h_intern(&lf[54],18,"pathname-directory");
lf[55]=C_h_intern(&lf[55],13,"pathname-file");
lf[56]=C_h_intern(&lf[56],18,"pathname-extension");
lf[57]=C_h_intern(&lf[57],24,"pathname-strip-directory");
lf[58]=C_h_intern(&lf[58],24,"pathname-strip-extension");
lf[59]=C_h_intern(&lf[59],26,"pathname-replace-directory");
lf[60]=C_h_intern(&lf[60],21,"pathname-replace-file");
lf[61]=C_h_intern(&lf[61],26,"pathname-replace-extension");
lf[62]=C_h_intern(&lf[62],21,"create-temporary-file");
lf[63]=C_h_intern(&lf[63],26,"create-temporary-directory");
lf[64]=C_h_intern(&lf[64],21,"call-with-output-file");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\004temp");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\004/tmp");
lf[67]=C_h_intern(&lf[67],24,"get-environment-variable");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003TMP");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\004TEMP");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\006TMPDIR");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\003tmp");
lf[72]=C_h_intern(&lf[72],15,"\003syssignal-hook");
lf[73]=C_h_intern(&lf[73],11,"\000file-error");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000$cannot create temporary directory - ");
lf[75]=C_h_intern(&lf[75],17,"\003syspeek-c-string");
lf[76]=C_h_intern(&lf[76],17,"\003sysmake-c-string");
lf[77]=C_h_intern(&lf[77],17,"directory-exists\077");
lf[78]=C_h_intern(&lf[78],7,"reverse");
lf[79]=C_h_intern(&lf[79],7,"display");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004msvc\376\003\000\000\002\376\001\000\000\007mingw32\376\377\016");
lf[81]=C_h_intern(&lf[81],7,"windows");
lf[82]=C_h_intern(&lf[82],4,"unix");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\002..");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002..\376\377\016");
lf[86]=C_h_intern(&lf[86],18,"normalize-pathname");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[89]=C_h_intern(&lf[89],20,"\003sysexpand-home-path");
lf[90]=C_h_intern(&lf[90],17,"get-output-string");
lf[91]=C_h_intern(&lf[91],16,"\003syswrite-char-0");
lf[92]=C_h_intern(&lf[92],18,"open-output-string");
lf[93]=C_h_intern(&lf[93],15,"directory-null\077");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[96]=C_h_intern(&lf[96],12,"string-split");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\002/\134");
lf[98]=C_h_intern(&lf[98],19,"decompose-directory");
lf[99]=C_h_intern(&lf[99],14,"build-platform");
lf[100]=C_h_intern(&lf[100],6,"regexp");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\034^(.*[\134/\134\134])\077((\134.)\077[^\134/\134\134]+)$");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000&^(.*[\134/\134\134])\077([^\134/\134\134]+)(\134.([^\134/\134\134.]+))$");
lf[103]=C_h_intern(&lf[103],20,"\003syswindows-platform");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\026([A-Za-z]:)\077([\134/\134\134]).*");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\012([\134/\134\134]).*");
lf[106]=C_h_intern(&lf[106],17,"register-feature!");
lf[107]=C_h_intern(&lf[107],5,"files");
C_register_lf2(lf,108,create_ptable());
t2=C_mutate(&lf[0] /* (set! c174 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_695,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k693 */
static void C_ccall f_695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_698,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k696 in k693 */
static void C_ccall f_698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_701,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:57: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[106]+1)))(3,*((C_word*)lf[106]+1),t2,lf[107]);}

/* k699 in k696 in k693 */
static void C_ccall f_701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_701,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! delete-file* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_703,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[5]+1 /* (set! file-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[24]+1 /* (set! file-move ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1062,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t5=lf[32] /* absolute-pathname-root */ =C_SCHEME_UNDEFINED;;
t6=lf[33] /* root-origin */ =C_SCHEME_UNDEFINED;;
t7=lf[34] /* root-directory */ =C_SCHEME_UNDEFINED;;
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[103]+1))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2624,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:173: regexp */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t9,lf[104]);}
else{
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2651,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* files.scm:177: regexp */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t9,lf[105]);}}

/* k2649 in k699 in k696 in k693 */
static void C_ccall f_2651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2651,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2653,a[2]=t1,a[3]=((C_word)li111),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[33] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2659,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[34] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2662,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_1474(t5,t4);}

/* root-directory in k2649 in k699 in k696 in k693 */
static void C_ccall f_2662(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2662,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_cadr(t2):C_SCHEME_FALSE));}

/* root-origin in k2649 in k699 in k696 in k693 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2659,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}

/* absolute-pathname-root in k2649 in k699 in k696 in k693 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2653,3,t0,t1,t2);}
/* files.scm:178: string-match */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t1,((C_word*)t0)[2],t2);}

/* k2622 in k699 in k696 in k693 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2624,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! absolute-pathname-root ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2626,a[2]=t1,a[3]=((C_word)li108),tmp=(C_word)a,a+=4,tmp));
t3=C_mutate(&lf[33] /* (set! root-origin ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2632,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate(&lf[34] /* (set! root-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2641,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
f_1474(t5,t4);}

/* f_2641 in k2622 in k699 in k696 in k693 */
static void C_ccall f_2641(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2641,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_caddr(t2):C_SCHEME_FALSE));}

/* f_2632 in k2622 in k699 in k696 in k693 */
static void C_ccall f_2632(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2632,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_cadr(t2):C_SCHEME_FALSE));}

/* f_2626 in k2622 in k699 in k696 in k693 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2626,3,t0,t1,t2);}
/* files.scm:174: string-match */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t1,((C_word*)t0)[2],t2);}

/* k1472 in k699 in k696 in k693 */
static void C_fcall f_1474(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[40],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1474,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[35]+1 /* (set! absolute-pathname? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[36] /* (set! chop-pds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1489,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t4=C_set_block_item(lf[39] /* make-pathname */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[40] /* make-absolute-pathname */,0,C_SCHEME_UNDEFINED);
t6=*((C_word*)lf[11]+1);
t7=lf[41];
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1542,a[2]=t6,a[3]=t7,a[4]=((C_word)li63),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1603,a[2]=t9,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp));
t16=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1634,a[2]=t6,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp));
t17=C_mutate((C_word*)lf[39]+1 /* (set! make-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1720,a[2]=t11,a[3]=t7,a[4]=t13,a[5]=((C_word)li66),tmp=(C_word)a,a+=6,tmp));
t18=C_mutate((C_word*)lf[40]+1 /* (set! make-absolute-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1752,a[2]=t11,a[3]=t7,a[4]=t13,a[5]=((C_word)li67),tmp=(C_word)a,a+=6,tmp));
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* files.scm:262: regexp */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t19,lf[102]);}

/* k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1795,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:263: regexp */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),t2,lf[101]);}

/* k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp);
t3=C_mutate((C_word*)lf[52]+1 /* (set! decompose-pathname ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1813,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,a[5]=((C_word)li69),tmp=(C_word)a,a+=6,tmp));
t4=C_mutate((C_word*)lf[54]+1 /* (set! pathname-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1889,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[55]+1 /* (set! pathname-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1904,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[56]+1 /* (set! pathname-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1919,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[57]+1 /* (set! pathname-strip-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[58]+1 /* (set! pathname-strip-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1952,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[59]+1 /* (set! pathname-replace-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[60]+1 /* (set! pathname-replace-file ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1988,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[61]+1 /* (set! pathname-replace-extension ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2006,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t12=C_set_block_item(lf[62] /* create-temporary-file */,0,C_SCHEME_UNDEFINED);
t13=C_set_block_item(lf[63] /* create-temporary-directory */,0,C_SCHEME_UNDEFINED);
t14=*((C_word*)lf[64]+1);
t15=C_SCHEME_FALSE;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=lf[65];
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2026,a[2]=t16,a[3]=((C_word)li94),tmp=(C_word)a,a+=4,tmp);
t19=C_mutate((C_word*)lf[62]+1 /* (set! create-temporary-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2051,a[2]=t18,a[3]=t17,a[4]=t14,a[5]=((C_word)li97),tmp=(C_word)a,a+=6,tmp));
t20=C_mutate((C_word*)lf[63]+1 /* (set! create-temporary-directory ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2115,a[2]=t18,a[3]=t17,a[4]=((C_word)li99),tmp=(C_word)a,a+=5,tmp));
t21=*((C_word*)lf[78]+1);
t22=*((C_word*)lf[79]+1);
t23=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2621,a[2]=((C_word*)t0)[2],a[3]=t21,a[4]=t22,tmp=(C_word)a,a+=5,tmp);
/* files.scm:375: build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[99]+1)))(2,*((C_word*)lf[99]+1),t23);}

/* k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2621,2,t0,t1);}
t2=C_i_memq(t1,lf[80]);
t3=(C_truep(t2)?lf[81]:lf[82]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2173,a[2]=((C_word)li100),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[86]+1 /* (set! normalize-pathname ...) */,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2199,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li104),tmp=(C_word)a,a+=7,tmp));
t6=C_mutate((C_word*)lf[93]+1 /* (set! directory-null? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2496,a[2]=((C_word)li106),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[98]+1 /* (set! decompose-directory ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2538,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_UNDEFINED);}

/* decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2538,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2586,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_string_2(t4,lf[98]);
/* files.scm:433: string-split */
((C_proc5)C_retrieve_proc(*((C_word*)lf[96]+1)))(5,*((C_word*)lf[96]+1),t3,t4,lf[97],C_SCHEME_FALSE);}

/* k2584 in decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:466: absolute-pathname-root */
t3=lf[32];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2587 in k2584 in decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2592,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:467: root-origin */
t3=lf[33];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* k2590 in k2587 in k2584 in decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* files.scm:468: root-directory */
t3=lf[34];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2597 in k2590 in k2587 in k2584 in decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2599,2,t0,t1);}
t2=C_i_nullp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=C_i_car(t3);
t6=C_block_size(t4);
if(C_truep(C_substring_compare(t4,t5,C_fix(0),C_fix(0),t6))){
t7=C_i_cdr(t3);
t8=C_block_size(t5);
t9=C_block_size(t8);
t10=C_eqp(t6,t9);
if(C_truep(t10)){
/* files.scm:468: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,t7);}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2579,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* files.scm:464: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t11,t5,t6,t8);}}
else{
/* files.scm:468: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,t3);}}
else{
/* files.scm:468: values */
C_values(5,0,((C_word*)t0)[2],((C_word*)t0)[3],t1,t3);}}

/* k2577 in k2597 in k2590 in k2587 in k2584 in decompose-directory in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2579,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[5]);
/* files.scm:468: values */
C_values(5,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* directory-null? in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2496(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2496,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2504,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_listp(t2))){
t4=t3;
f_2504(2,t4,t2);}
else{
t4=t2;
t5=C_i_check_string_2(t4,lf[93]);
/* files.scm:433: string-split */
((C_proc5)C_retrieve_proc(*((C_word*)lf[96]+1)))(5,*((C_word*)lf[96]+1),t3,t4,lf[97],C_SCHEME_TRUE);}}

/* k2502 in directory-null? in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2506,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2506(t1));}

/* loop in k2502 in directory-null? in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static C_word C_fcall f_2506(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_i_equalp(t3,lf[94]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[95]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_2199r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2199r(t0,t1,t2,t3);}}

static void C_ccall f_2199r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2203,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2203(2,t5,((C_word*)t0)[2]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2203(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=C_eqp(t1,lf[81]);
t3=(C_truep(t2)?C_make_character(92):C_make_character(47));
t4=C_i_check_string_2(((C_word*)t0)[6],lf[86]);
t5=C_block_size(((C_word*)t0)[6]);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2217,a[2]=t1,a[3]=t11,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t9,a[9]=t3,a[10]=t7,a[11]=t5,a[12]=((C_word)li103),tmp=(C_word)a,a+=13,tmp));
t13=((C_word*)t11)[1];
f_2217(t13,((C_word*)t0)[2],C_fix(0),C_fix(0),C_SCHEME_END_OF_LIST);}

/* loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2217(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2217,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[11]))){
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2227,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t5,tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_fixnum_greaterp(t2,t3))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2351,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm:389: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t7,((C_word*)t0)[4],t3,t2);}
else{
t7=t6;
f_2227(t7,C_SCHEME_UNDEFINED);}}
else{
t6=C_i_string_ref(((C_word*)t0)[4],t2);
if(C_truep((C_truep(C_eqp(t6,C_make_character(92)))?C_SCHEME_TRUE:(C_truep(C_eqp(t6,C_make_character(47)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2365,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)t5)[1]))){
t8=C_eqp(t2,t3);
if(C_truep(t8)){
t9=C_set_block_item(((C_word*)t0)[10],0,C_SCHEME_TRUE);
t10=t7;
f_2365(t10,t9);}
else{
t9=t7;
f_2365(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t7;
f_2365(t8,C_SCHEME_UNDEFINED);}}
else{
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2417,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_nullp(((C_word*)t5)[1]))){
t8=C_i_string_ref(((C_word*)t0)[4],t2);
t9=C_eqp(t8,C_make_character(58));
t10=t7;
f_2417(t10,(C_truep(t9)?C_eqp(lf[81],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t8=t7;
f_2417(t8,C_SCHEME_FALSE);}}}}

/* k2415 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2417(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2417,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2421,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* files.scm:422: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t2,((C_word*)t0)[4],C_fix(0),t3);}
else{
t2=C_fixnum_plus(((C_word*)t0)[7],C_fix(1));
/* files.scm:424: loop */
t3=((C_word*)((C_word*)t0)[6])[1];
f_2217(t3,((C_word*)t0)[5],t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2419 in k2415 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
/* files.scm:423: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2217(t5,((C_word*)t0)[2],t3,t4,C_SCHEME_END_OF_LIST);}

/* k2363 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2365(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2365,NULL,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[8],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
/* files.scm:415: loop */
t5=((C_word*)((C_word*)t0)[6])[1];
f_2217(t5,((C_word*)t0)[5],t3,t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
t3=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[8],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2401,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* files.scm:418: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t5,((C_word*)t0)[2],((C_word*)t0)[7],((C_word*)t0)[8]);}}

/* k2399 in k2363 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2401,2,t0,t1);}
t2=f_2173(C_a_i(&a,3),t1,((C_word*)((C_word*)t0)[6])[1]);
/* files.scm:416: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2217(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2349 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2351,2,t0,t1);}
t2=f_2173(C_a_i(&a,3),t1,((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_2227(t4,t3);}

/* k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2227,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[10])[1]))){
if(C_truep(((C_word*)((C_word*)t0)[9])[1])){
t2=C_a_i_string(&a,1,((C_word*)t0)[8]);
/* files.scm:392: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),((C_word*)t0)[7],t2,lf[87]);}
else{
t2=C_a_i_string(&a,1,((C_word*)t0)[8]);
/* files.scm:393: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),((C_word*)t0)[7],lf[88],t2);}}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2253,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
/* files.scm:394: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[92]+1)))(2,*((C_word*)lf[92]+1),t2);}}

/* k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2256,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* files.scm:395: reverse */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2259,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
t3=C_i_car(t1);
/* files.scm:396: display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t2,t3,((C_word*)t0)[5]);}

/* k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2259,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2262,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2307,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word)li102),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2307(t7,t2,t3);}

/* loop600 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2307(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li101),tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g607608 */
t6=t3;
f_2315(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2323 in loop600 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2307(t3,((C_word*)t0)[2],t2);}

/* g607 in loop600 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2315,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:399: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k2317 in g607 in loop600 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:400: display */
t2=((C_word*)t0)[5];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2265,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(((C_word*)t0)[3],((C_word*)t0)[2]);
if(C_truep(t3)){
/* files.scm:402: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=t2;
f_2265(2,t4,C_SCHEME_UNDEFINED);}}

/* k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* files.scm:403: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[90]+1)))(3,*((C_word*)lf[90]+1),t2,((C_word*)t0)[2]);}

/* k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* files.scm:404: ##sys#expand-home-path */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t2,t1);}

/* k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_string_equal_p(((C_word*)t0)[6],((C_word*)t3)[1]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2280,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2291,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_string(&a,1,((C_word*)t0)[2]);
/* files.scm:407: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t5,t6,((C_word*)t3)[1]);}
else{
t5=t4;
f_2280(t5,C_SCHEME_UNDEFINED);}}
else{
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t3)[1]);}}

/* k2289 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_2280(t3,t2);}

/* k2278 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2280(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2280,NULL,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2287,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:409: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t2,((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[3])[1]);}}

/* k2285 in k2278 in k2269 in k2266 in k2263 in k2260 in k2257 in k2254 in k2251 in k2225 in loop in k2201 in normalize-pathname in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[3])[1]);}

/* addpart in k2619 in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static C_word C_fcall f_2173(C_word *a,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
if(C_truep(C_i_string_equal_p(lf[83],t1))){
t3=t2;
return(t3);}
else{
if(C_truep(C_i_string_equal_p(lf[84],t1))){
t3=C_i_nullp(t2);
return((C_truep(t3)?lf[85]:C_i_cdr(t2)));}
else{
return(C_a_i_cons(&a,2,t1,t2));}}}

/* create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2115,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2121,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word)li98),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2121(t5,t1);}

/* loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2121(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2121,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2125,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2159,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* files.scm:355: tempdir */
t5=((C_word*)t0)[2];
f_2026(t5,t4);}

/* k2157 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2163,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2167,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:358: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(16));}

/* k2165 in k2157 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:356: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2161 in k2157 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:354: make-pathname */
t2=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2123 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2131,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* files.scm:359: directory-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[77]+1)))(3,*((C_word*)lf[77]+1),t2,t1);}

/* k2129 in k2123 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2131,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:360: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2121(t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:361: ##sys#make-c-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[76]+1)))(4,*((C_word*)lf[76]+1),t2,((C_word*)t0)[2],lf[63]);}}

/* k2136 in k2129 in k2123 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2138,2,t0,t1);}
t2=C_mkdir(t1);
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)t0)[2]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2155,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[75]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2153 in k2136 in k2129 in k2123 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:366: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),((C_word*)t0)[2],lf[74],t1);}

/* k2149 in k2136 in k2129 in k2123 in loop in create-temporary-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:364: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[72]+1)))(6,*((C_word*)lf[72]+1),((C_word*)t0)[3],lf[73],lf[63],t1,((C_word*)t0)[2]);}

/* create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_2051r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2051r(t0,t1,t2);}}

static void C_ccall f_2051r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2055,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_2055(2,t4,lf[71]);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_2055(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2055,2,t0,t1);}
t2=C_i_check_string_2(t1,lf[62]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t4,a[7]=((C_word)li96),tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_2063(t6,((C_word*)t0)[2]);}

/* loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2063(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2063,NULL,2,t0,t1);}
t2=C_random_fixnum(C_fix(65536));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2067,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2086,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* files.scm:343: tempdir */
t5=((C_word*)t0)[2];
f_2026(t5,t4);}

/* k2084 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2090,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* files.scm:346: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(16));}

/* k2092 in k2084 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:344: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2088 in k2084 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:342: make-pathname */
t2=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2065 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2073,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* files.scm:347: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t2,t1);}

/* k2071 in k2065 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2073,2,t0,t1);}
if(C_truep(t1)){
/* files.scm:348: loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2063(t2,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2081,a[2]=((C_word*)t0)[3],a[3]=((C_word)li95),tmp=(C_word)a,a+=4,tmp);
/* files.scm:349: call-with-output-file */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* a2080 in k2071 in k2065 in loop in k2053 in create-temporary-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2081,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}

/* tempdir in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_2026(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2026,NULL,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2033,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* files.scm:331: get-environment-variable */
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),t3,lf[70]);}}

/* k2031 in tempdir in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2033,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2040,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:332: get-environment-variable */
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),t2,lf[69]);}}

/* k2038 in k2031 in tempdir in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2040,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* files.scm:333: get-environment-variable */
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),t2,lf[68]);}}

/* k2044 in k2038 in k2031 in tempdir in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t2=lf[66];
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}}

/* pathname-replace-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2006,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=t2,a[3]=((C_word)li91),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2018,a[2]=t3,a[3]=((C_word)li92),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a2017 in pathname-replace-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2018,5,t0,t1,t2,t3,t4);}
/* files.scm:320: make-pathname */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,((C_word*)t0)[2]);}

/* a2011 in pathname-replace-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2012,2,t0,t1);}
/* files.scm:319: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1988(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1988,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1994,a[2]=t2,a[3]=((C_word)li88),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2000,a[2]=t3,a[3]=((C_word)li89),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1999 in pathname-replace-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2000,5,t0,t1,t2,t3,t4);}
/* files.scm:315: make-pathname */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,((C_word*)t0)[2],t4);}

/* a1993 in pathname-replace-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1994,2,t0,t1);}
/* files.scm:314: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-replace-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1970,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1976,a[2]=t2,a[3]=((C_word)li85),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=t3,a[3]=((C_word)li86),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1981 in pathname-replace-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1982,5,t0,t1,t2,t3,t4);}
/* files.scm:310: make-pathname */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[2],t3,t4);}

/* a1975 in pathname-replace-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1976,2,t0,t1);}
/* files.scm:309: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1952,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1958,a[2]=t2,a[3]=((C_word)li82),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1964,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1963 in pathname-strip-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1964(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1964,5,t0,t1,t2,t3,t4);}
/* files.scm:305: make-pathname */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}

/* a1957 in pathname-strip-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1958,2,t0,t1);}
/* files.scm:304: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-strip-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1934(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1934,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1940,a[2]=t2,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1946,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1945 in pathname-strip-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1946,5,t0,t1,t2,t3,t4);}
/* files.scm:300: make-pathname */
t5=*((C_word*)lf[39]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,C_SCHEME_FALSE,t3,t4);}

/* a1939 in pathname-strip-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1940,2,t0,t1);}
/* files.scm:299: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1919(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1919,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1925,a[2]=t2,a[3]=((C_word)li76),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1931,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1930 in pathname-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1931(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1931,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a1924 in pathname-extension in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
/* files.scm:294: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1904(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1904,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1910,a[2]=t2,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1916,a[2]=((C_word)li74),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1915 in pathname-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1916(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1916,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}

/* a1909 in pathname-file in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
/* files.scm:289: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* pathname-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1889(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1889,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1895,a[2]=t2,a[3]=((C_word)li70),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1901,a[2]=((C_word)li71),tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a1900 in pathname-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1901,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}

/* a1894 in pathname-directory in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1895,2,t0,t1);}
/* files.scm:284: decompose-pathname */
t2=*((C_word*)lf[52]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1813(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1813,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[52]);
t4=C_block_size(t2);
t5=C_eqp(C_fix(0),t4);
if(C_truep(t5)){
/* files.scm:273: values */
C_values(5,0,t1,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1829,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm:274: string-match */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t6,((C_word*)t0)[2],t2);}}

/* k1827 in decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1829,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1839,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(t1);
/* files.scm:276: strip-pds */
f_1799(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm:277: string-match */
((C_proc4)C_retrieve_proc(*((C_word*)lf[53]+1)))(4,*((C_word*)lf[53]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k1856 in k1827 in decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1868,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(t1);
/* files.scm:279: strip-pds */
f_1799(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1883,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* files.scm:280: strip-pds */
f_1799(t2,((C_word*)t0)[2]);}}

/* k1881 in k1856 in k1827 in decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:280: values */
C_values(5,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* k1866 in k1856 in k1827 in decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_caddr(((C_word*)t0)[3]);
/* files.scm:279: values */
C_values(5,0,((C_word*)t0)[2],t1,t2,C_SCHEME_FALSE);}

/* k1837 in k1827 in decompose-pathname in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_ccall f_1839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_caddr(((C_word*)t0)[3]);
t3=C_i_cddddr(((C_word*)t0)[3]);
t4=C_i_car(t3);
/* files.scm:276: values */
C_values(5,0,((C_word*)t0)[2],t1,t2,t4);}

/* strip-pds in k1796 in k1793 in k1472 in k699 in k696 in k693 */
static void C_fcall f_1799(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1799,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=t2;
if(C_truep((C_truep(C_i_equalp(t3,lf[50]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[51]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
/* files.scm:269: chop-pds */
f_1489(t1,t2,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* make-absolute-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1752(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_1752r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1752r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1752r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1756,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1756(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1756(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1754 in make-absolute-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* files.scm:253: canonicalize-dirs */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1603(t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1761 in k1754 in make-absolute-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1763,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1769,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* files.scm:254: absolute-pathname? */
t4=*((C_word*)lf[35]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t1);}

/* k1767 in k1761 in k1754 in make-absolute-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[8];
/* files.scm:251: _make-pathname */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1634(t3,((C_word*)t0)[6],lf[40],t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* files.scm:256: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),((C_word*)t0)[2],((C_word*)t0)[3],((C_word*)t0)[8]);}}

/* k1764 in k1761 in k1754 in make-absolute-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:251: _make-pathname */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1634(t2,((C_word*)t0)[5],lf[40],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* make-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1720(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr4r,(void*)f_1720r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1720r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1720r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1724,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1724(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1724(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1722 in make-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1724,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1731,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* files.scm:247: canonicalize-dirs */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1603(t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1729 in k1722 in make-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:247: _make-pathname */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1634(t2,((C_word*)t0)[5],lf[39],t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* _make-pathname in k1472 in k699 in k696 in k693 */
static void C_fcall f_1634(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1634,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t5)?t5:lf[44]);
t8=(C_truep(t4)?t4:lf[45]);
t9=(C_truep(t6)?C_block_size(t6):C_fix(1));
t10=C_i_check_string_2(t3,t2);
t11=C_i_check_string_2(t8,t2);
t12=C_i_check_string_2(t7,t2);
t13=(C_truep(t6)?C_i_check_string_2(t6,t2):C_SCHEME_UNDEFINED);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1663,a[2]=t7,a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1687,a[2]=t9,a[3]=t14,a[4]=t8,tmp=(C_word)a,a+=5,tmp);
t16=C_block_size(t8);
if(C_truep(C_fixnum_greater_or_equal_p(t16,t9))){
if(C_truep(t6)){
t17=C_substring_compare(t6,t8,C_fix(0),C_fix(0),t9);
t18=t15;
f_1687(t18,t17);}
else{
t17=C_subchar(t8,C_fix(0));
t18=t15;
f_1687(t18,C_i_memq(t17,lf[48]));}}
else{
t17=t15;
f_1687(t17,C_SCHEME_FALSE);}}

/* k1685 in _make-pathname in k1472 in k699 in k696 in k693 */
static void C_fcall f_1687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[4]);
/* files.scm:237: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[3];
f_1663(2,t2,((C_word*)t0)[4]);}}

/* k1661 in _make-pathname in k1472 in k699 in k696 in k693 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1670,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_block_size(((C_word*)t0)[2]);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t4=C_eqp(C_subchar(((C_word*)t0)[2],C_fix(0)),C_make_character(46));
t5=t2;
f_1670(t5,C_i_not(t4));}
else{
t4=t2;
f_1670(t4,C_SCHEME_FALSE);}}

/* k1668 in k1661 in _make-pathname in k1472 in k699 in k696 in k693 */
static void C_fcall f_1670(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:231: string-append */
t2=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[46],((C_word*)t0)[2]);}
else{
/* files.scm:231: string-append */
t2=((C_word*)t0)[6];
((C_proc6)C_retrieve_proc(t2))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[47],((C_word*)t0)[2]);}}

/* canonicalize-dirs in k1472 in k699 in k696 in k693 */
static void C_fcall f_1603(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1603,NULL,4,t0,t1,t2,t3);}
t4=C_i_not(t2);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[43]);}
else{
if(C_truep(C_i_stringp(t2))){
t6=C_a_i_list(&a,1,t2);
/* files.scm:220: conc-dirs */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1542(t7,t1,t6,t3);}
else{
/* files.scm:221: conc-dirs */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1542(t6,t1,t2,t3);}}}

/* conc-dirs in k1472 in k699 in k696 in k693 */
static void C_fcall f_1542(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1542,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_list_2(t2,lf[39]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t6,a[6]=((C_word)li62),tmp=(C_word)a,a+=7,tmp));
t8=((C_word*)t6)[1];
f_1551(t8,t1,t2);}

/* loop in conc-dirs in k1472 in k699 in k696 in k693 */
static void C_fcall f_1551(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1551,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[42]);}
else{
t3=C_i_car(t2);
t4=C_i_string_length(t3);
if(C_truep(C_i_zerop(t4))){
t5=C_i_cdr(t2);
/* files.scm:212: loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1581,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t6=C_i_car(t2);
/* files.scm:214: chop-pds */
f_1489(t5,t6,((C_word*)t0)[4]);}}}

/* k1579 in loop in conc-dirs in k1472 in k699 in k696 in k693 */
static void C_ccall f_1581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1581,2,t0,t1);}
t2=((C_word*)t0)[7];
t3=(C_truep(t2)?t2:((C_word*)t0)[6]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1589,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t5=C_i_cdr(((C_word*)t0)[3]);
/* files.scm:216: loop */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1551(t6,t4,t5);}

/* k1587 in k1579 in loop in conc-dirs in k1472 in k699 in k696 in k693 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:213: string-append */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* chop-pds in k1472 in k699 in k696 in k693 */
static void C_fcall f_1489(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1489,NULL,3,t1,t2,t3);}
if(C_truep(t2)){
t4=C_block_size(t2);
t5=(C_truep(t3)?C_block_size(t3):C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1505,a[2]=t2,a[3]=t1,a[4]=t5,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(t4,C_fix(1)))){
if(C_truep(t3)){
t7=C_fixnum_difference(t4,t5);
t8=C_substring_compare(t2,t3,t7,C_fix(0),t5);
t9=t6;
f_1505(t9,t8);}
else{
t7=C_fixnum_difference(t4,t5);
t8=C_subchar(t2,t7);
t9=t6;
f_1505(t9,C_i_memq(t8,lf[38]));}}
else{
t7=t6;
f_1505(t7,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1503 in chop-pds in k1472 in k699 in k696 in k693 */
static void C_fcall f_1505(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm:196: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* absolute-pathname? in k1472 in k699 in k696 in k693 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1476,3,t0,t1,t2);}
t3=C_i_check_string_2(t2,lf[35]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1487,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:184: absolute-pathname-root */
t5=lf[32];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k1485 in absolute-pathname? in k1472 in k699 in k696 in k693 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_pairp(t1));}

/* file-move in k699 in k696 in k693 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_1062r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1062r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1064,a[2]=t3,a[3]=t2,a[4]=((C_word)li56),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1417,a[2]=t5,a[3]=((C_word)li57),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1422,a[2]=t6,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-clobber188300 */
t8=t7;
f_1422(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-blocksize189298 */
t10=t6;
f_1417(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body186193 */
t12=t5;
f_1064(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber188 in file-move in k699 in k696 in k693 */
static void C_fcall f_1422(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1422,NULL,2,t0,t1);}
/* def-blocksize189298 */
t2=((C_word*)t0)[2];
f_1417(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize189 in file-move in k699 in k696 in k693 */
static void C_fcall f_1417(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1417,NULL,3,t0,t1,t2);}
/* body186193 */
t3=((C_word*)t0)[2];
f_1064(t3,t1,t2,C_fix(1024));}

/* body186 in file-move in k699 in k696 in k693 */
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1064,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(((C_word*)t0)[3],lf[24]);
t5=C_i_check_string_2(((C_word*)t0)[2],lf[24]);
t6=C_i_check_number_2(t3,lf[24]);
t7=C_i_integerp(t3);
t8=(C_truep(t7)?C_i_greaterp(t3,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1080,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t8)){
t10=t9;
f_1080(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1406,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* files.scm:120: number->string */
C_number_to_string(3,0,t11,t3);}}

/* k1408 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:118: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[31],t1);}

/* k1404 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:118: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1083,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm:121: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t2,((C_word*)t0)[6]);}

/* k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1083,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1086,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_1086(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1399,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm:122: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[30],((C_word*)t0)[6]);}}

/* k1397 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:122: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:123: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t3,((C_word*)t0)[3]);}

/* k1380 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1382(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1382,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_1089(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm:125: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[29],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_1089(2,t2,C_SCHEME_FALSE);}}

/* k1390 in k1380 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:125: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1089,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1092,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[5],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,t3);}

/* a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1326,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1332,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1357,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1356 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[3],a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1369,a[2]=((C_word*)t0)[2],a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1368 in a1356 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1369r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1369r(t0,t1,t2);}}

static void C_ccall f_1369r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1375,a[2]=t2,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
/* k213217 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1374 in a1368 in a1356 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1375,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1362 in a1356 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
/* files.scm:128: open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t1,((C_word*)t0)[2]);}

/* a1331 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1332,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1338,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
/* k213217 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1337 in a1331 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1338,2,t0,t1);}
if(C_truep(C_i_structurep(((C_word*)t0)[3],lf[9]))){
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1349,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:130: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[28],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:130: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,lf[28],((C_word*)t0)[2]);}}

/* f2838 in a1337 in a1331 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:130: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1347 in a1337 in a1331 in a1325 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:130: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1092,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g215216 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[2],a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,t3);}

/* a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1271,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1301 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[3],a[3]=((C_word)li44),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1313 in a1301 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1314r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1314r(t0,t1,t2);}}

static void C_ccall f_1314r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1320,a[2]=t2,a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* k232236 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1319 in a1313 in a1301 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1307 in a1301 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
/* files.scm:133: open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t1,((C_word*)t0)[2]);}

/* a1276 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1277,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1283,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* k232236 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1282 in a1276 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1283,2,t0,t1);}
if(C_truep(C_i_structurep(((C_word*)t0)[3],lf[9]))){
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:135: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[27],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2834,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:135: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,lf[27],((C_word*)t0)[2]);}}

/* f2834 in a1282 in a1276 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f2834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:135: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1292 in a1282 in a1276 in a1270 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:135: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g234235 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:138: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[3]);}

/* k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1111,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* files.scm:139: read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1111,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li41),tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_1113(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_fcall f_1113(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1113,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1123,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* files.scm:143: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1206,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li40),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t6);}}

/* a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1206(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1206,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1212,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li35),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1247,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li39),tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1246 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1253,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li36),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1259,a[2]=((C_word*)t0)[2],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1258 in a1246 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1259(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1259r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1259r(t0,t1,t2);}}

static void C_ccall f_1259r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1265,a[2]=t2,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp);
/* k275279 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1264 in a1258 in a1246 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1265,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1252 in a1246 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1253,2,t0,t1);}
/* files.scm:152: write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1212(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1212,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1218,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li34),tmp=(C_word)a,a+=7,tmp);
/* k275279 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1217 in a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1218,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:154: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t4,((C_word*)t0)[2]);}

/* k1223 in a1217 in a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1225,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:155: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2]);}

/* k1226 in k1223 in a1217 in a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1239,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm:158: number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k1237 in k1226 in k1223 in a1217 in a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:156: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[26],t1);}

/* k1233 in k1226 in k1223 in a1217 in a1211 in a1205 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:156: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1188 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g277278 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1191 in k1188 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm:159: read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1198 in k1191 in k1188 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm:159: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1113(t3,((C_word*)t0)[2],t1,t2);}

/* k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1123,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* files.scm:144: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2]);}

/* k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1129,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1134,a[2]=((C_word*)t0)[2],a[3]=((C_word)li33),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,t3);}

/* a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1134(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1134,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1140,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1165,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a1164 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1165,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1171,a[2]=((C_word*)t0)[3],a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1177,a[2]=((C_word*)t0)[2],a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1176 in a1164 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1177(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_1177r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1177r(t0,t1,t2);}}

static void C_ccall f_1177r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1183,a[2]=t2,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
/* k254258 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1182 in a1176 in a1164 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1183,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1170 in a1164 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1171,2,t0,t1);}
/* files.scm:145: delete-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t1,((C_word*)t0)[2]);}

/* a1139 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1140,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1146,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li27),tmp=(C_word)a,a+=5,tmp);
/* k254258 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1145 in a1139 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1146,2,t0,t1);}
if(C_truep(C_i_structurep(((C_word*)t0)[3],lf[9]))){
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1157,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:147: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[25],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2828,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:147: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,lf[25],((C_word*)t0)[2]);}}

/* f2828 in a1145 in a1139 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f2828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:147: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1155 in a1145 in a1139 in a1133 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:147: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1127 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1132,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g256257 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1130 in k1127 in k1124 in k1121 in loop in k1109 in k1102 in k1099 in k1096 in k1093 in k1090 in k1087 in k1084 in k1081 in k1078 in body186 in file-move in k699 in k696 in k693 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* file-copy in k699 in k696 in k693 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr4r,(void*)f_715r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_715r(t0,t1,t2,t3,t4);}}

static void C_ccall f_715r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_717,a[2]=t3,a[3]=t2,a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1009,a[2]=t5,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1014,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-clobber76169 */
t8=t7;
f_1014(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-blocksize77167 */
t10=t6;
f_1009(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body7481 */
t12=t5;
f_717(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-clobber76 in file-copy in k699 in k696 in k693 */
static void C_fcall f_1014(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1014,NULL,2,t0,t1);}
/* def-blocksize77167 */
t2=((C_word*)t0)[2];
f_1009(t2,t1,C_SCHEME_FALSE);}

/* def-blocksize77 in file-copy in k699 in k696 in k693 */
static void C_fcall f_1009(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1009,NULL,3,t0,t1,t2);}
/* body7481 */
t3=((C_word*)t0)[2];
f_717(t3,t1,t2,C_fix(1024));}

/* body74 in file-copy in k699 in k696 in k693 */
static void C_fcall f_717(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_717,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_string_2(((C_word*)t0)[3],lf[5]);
t5=C_i_check_string_2(((C_word*)t0)[2],lf[5]);
t6=C_i_check_number_2(t3,lf[5]);
t7=C_i_integerp(t3);
t8=(C_truep(t7)?C_i_greaterp(t3,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_733,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t8)){
t10=t9;
f_733(2,t10,t8);}
else{
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_998,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1002,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* files.scm:77: number->string */
C_number_to_string(3,0,t11,t3);}}

/* k1000 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_1002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:75: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[23],t1);}

/* k996 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:75: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_733(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_733,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_736,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* files.scm:78: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t2,((C_word*)t0)[3]);}

/* k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_736(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_736,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_739,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=t2;
f_739(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_991,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm:79: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[22],((C_word*)t0)[3]);}}

/* k989 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:79: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_739,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_742,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_974,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* files.scm:80: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t3,((C_word*)t0)[4]);}

/* k972 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_974,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_742(2,t3,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* files.scm:82: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[21],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[3];
f_742(2,t2,C_SCHEME_FALSE);}}

/* k982 in k972 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:82: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_742(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_742,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_745,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,t3);}

/* a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_918,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_924,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_949,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a948 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_949,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_955,a[2]=((C_word*)t0)[3],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_961,a[2]=((C_word*)t0)[2],a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a960 in a948 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_961(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_961r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_961r(t0,t1,t2);}}

static void C_ccall f_961r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_967,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* k101105 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a966 in a960 in a948 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_967,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a954 in a948 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_955,2,t0,t1);}
/* files.scm:85: open-input-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t1,((C_word*)t0)[2]);}

/* a923 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_924,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_930,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
/* k101105 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a929 in a923 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_930,2,t0,t1);}
if(C_truep(C_i_structurep(((C_word*)t0)[3],lf[9]))){
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_941,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:87: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[19],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2824,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:87: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,lf[19],((C_word*)t0)[2]);}}

/* f2824 in a929 in a923 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f2824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:87: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k939 in a929 in a923 in a917 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:87: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_745,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_748,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g103104 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_748,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_751,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[2],a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,t3);}

/* a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_863,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_869,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_894,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a893 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_900,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_906,a[2]=((C_word*)t0)[2],a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a905 in a893 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_906(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_906r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_906r(t0,t1,t2);}}

static void C_ccall f_906r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_912,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp);
/* k120124 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a911 in a905 in a893 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_912,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a899 in a893 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_900,2,t0,t1);}
/* files.scm:90: open-output-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t1,((C_word*)t0)[2]);}

/* a868 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_869(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_869,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_875,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li9),tmp=(C_word)a,a+=5,tmp);
/* k120124 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a874 in a868 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_875,2,t0,t1);}
if(C_truep(C_i_structurep(((C_word*)t0)[3],lf[9]))){
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_886,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:92: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,lf[17],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f2820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* files.scm:92: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,lf[17],((C_word*)t0)[2]);}}

/* f2820 in a874 in a868 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f2820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:92: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k884 in a874 in a868 in a862 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:92: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_751,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_754,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g122123 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_757,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* files.scm:95: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t2,((C_word*)t0)[3]);}

/* k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_757,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_764,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* files.scm:96: read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[3],t1,((C_word*)t0)[4]);}

/* k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_764,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_766,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li8),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_766(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_fcall f_766(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_766,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* files.scm:100: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t5,((C_word*)t0)[5]);}
else{
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_798,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word)li7),tmp=(C_word)a,a+=8,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t5,t6);}}

/* a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_798,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_804,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_839,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li6),tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t1,t3,t4);}

/* a838 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_839,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_845,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_851,a[2]=((C_word*)t0)[2],a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a850 in a838 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_851r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_851r(t0,t1,t2);}}

static void C_ccall f_851r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_857,a[2]=t2,a[3]=((C_word)li4),tmp=(C_word)a,a+=4,tmp);
/* k144148 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a856 in a850 in a838 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_857,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a844 in a838 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_845,2,t0,t1);}
/* files.scm:104: write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[13]+1)))(5,*((C_word*)lf[13]+1),t1,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_804(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_804,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,a[6]=((C_word)li1),tmp=(C_word)a,a+=7,tmp);
/* k144148 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a809 in a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_810,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[5],lf[9]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[5],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_817,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* files.scm:106: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[7]+1)))(3,*((C_word*)lf[7]+1),t4,((C_word*)t0)[2]);}

/* k815 in a809 in a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_820,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:107: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2]);}

/* k818 in k815 in a809 in a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_827,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_831,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* files.scm:110: number->string */
C_number_to_string(3,0,t3,((C_word*)t0)[2]);}

/* k829 in k818 in k815 in a809 in a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:108: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[12],t1);}

/* k825 in k818 in k815 in a809 in a803 in a797 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* files.scm:108: ##sys#error */
t2=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k780 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* g146147 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k783 in k780 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_792,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* files.scm:111: read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[8]+1)))(5,*((C_word*)lf[8]+1),t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k790 in k783 in k780 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* files.scm:111: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_766(t3,((C_word*)t0)[2],t1,t2);}

/* k774 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_779,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* files.scm:101: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t2,((C_word*)t0)[2]);}

/* k777 in k774 in loop in k762 in k755 in k752 in k749 in k746 in k743 in k740 in k737 in k734 in k731 in body74 in file-copy in k699 in k696 in k693 */
static void C_ccall f_779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* delete-file* in k699 in k696 in k693 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_703,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_710,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* files.scm:67: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[4]+1)))(3,*((C_word*)lf[4]+1),t3,t2);}

/* k708 in delete-file* in k699 in k696 in k693 */
static void C_ccall f_710(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* files.scm:67: delete-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[246] = {
{"toplevel:files_scm",(void*)C_files_toplevel},
{"f_695:files_scm",(void*)f_695},
{"f_698:files_scm",(void*)f_698},
{"f_701:files_scm",(void*)f_701},
{"f_2651:files_scm",(void*)f_2651},
{"f_2662:files_scm",(void*)f_2662},
{"f_2659:files_scm",(void*)f_2659},
{"f_2653:files_scm",(void*)f_2653},
{"f_2624:files_scm",(void*)f_2624},
{"f_2641:files_scm",(void*)f_2641},
{"f_2632:files_scm",(void*)f_2632},
{"f_2626:files_scm",(void*)f_2626},
{"f_1474:files_scm",(void*)f_1474},
{"f_1795:files_scm",(void*)f_1795},
{"f_1798:files_scm",(void*)f_1798},
{"f_2621:files_scm",(void*)f_2621},
{"f_2538:files_scm",(void*)f_2538},
{"f_2586:files_scm",(void*)f_2586},
{"f_2589:files_scm",(void*)f_2589},
{"f_2592:files_scm",(void*)f_2592},
{"f_2599:files_scm",(void*)f_2599},
{"f_2579:files_scm",(void*)f_2579},
{"f_2496:files_scm",(void*)f_2496},
{"f_2504:files_scm",(void*)f_2504},
{"f_2506:files_scm",(void*)f_2506},
{"f_2199:files_scm",(void*)f_2199},
{"f_2203:files_scm",(void*)f_2203},
{"f_2217:files_scm",(void*)f_2217},
{"f_2417:files_scm",(void*)f_2417},
{"f_2421:files_scm",(void*)f_2421},
{"f_2365:files_scm",(void*)f_2365},
{"f_2401:files_scm",(void*)f_2401},
{"f_2351:files_scm",(void*)f_2351},
{"f_2227:files_scm",(void*)f_2227},
{"f_2253:files_scm",(void*)f_2253},
{"f_2256:files_scm",(void*)f_2256},
{"f_2259:files_scm",(void*)f_2259},
{"f_2307:files_scm",(void*)f_2307},
{"f_2325:files_scm",(void*)f_2325},
{"f_2315:files_scm",(void*)f_2315},
{"f_2319:files_scm",(void*)f_2319},
{"f_2262:files_scm",(void*)f_2262},
{"f_2265:files_scm",(void*)f_2265},
{"f_2268:files_scm",(void*)f_2268},
{"f_2271:files_scm",(void*)f_2271},
{"f_2291:files_scm",(void*)f_2291},
{"f_2280:files_scm",(void*)f_2280},
{"f_2287:files_scm",(void*)f_2287},
{"f_2173:files_scm",(void*)f_2173},
{"f_2115:files_scm",(void*)f_2115},
{"f_2121:files_scm",(void*)f_2121},
{"f_2159:files_scm",(void*)f_2159},
{"f_2167:files_scm",(void*)f_2167},
{"f_2163:files_scm",(void*)f_2163},
{"f_2125:files_scm",(void*)f_2125},
{"f_2131:files_scm",(void*)f_2131},
{"f_2138:files_scm",(void*)f_2138},
{"f_2155:files_scm",(void*)f_2155},
{"f_2151:files_scm",(void*)f_2151},
{"f_2051:files_scm",(void*)f_2051},
{"f_2055:files_scm",(void*)f_2055},
{"f_2063:files_scm",(void*)f_2063},
{"f_2086:files_scm",(void*)f_2086},
{"f_2094:files_scm",(void*)f_2094},
{"f_2090:files_scm",(void*)f_2090},
{"f_2067:files_scm",(void*)f_2067},
{"f_2073:files_scm",(void*)f_2073},
{"f_2081:files_scm",(void*)f_2081},
{"f_2026:files_scm",(void*)f_2026},
{"f_2033:files_scm",(void*)f_2033},
{"f_2040:files_scm",(void*)f_2040},
{"f_2046:files_scm",(void*)f_2046},
{"f_2006:files_scm",(void*)f_2006},
{"f_2018:files_scm",(void*)f_2018},
{"f_2012:files_scm",(void*)f_2012},
{"f_1988:files_scm",(void*)f_1988},
{"f_2000:files_scm",(void*)f_2000},
{"f_1994:files_scm",(void*)f_1994},
{"f_1970:files_scm",(void*)f_1970},
{"f_1982:files_scm",(void*)f_1982},
{"f_1976:files_scm",(void*)f_1976},
{"f_1952:files_scm",(void*)f_1952},
{"f_1964:files_scm",(void*)f_1964},
{"f_1958:files_scm",(void*)f_1958},
{"f_1934:files_scm",(void*)f_1934},
{"f_1946:files_scm",(void*)f_1946},
{"f_1940:files_scm",(void*)f_1940},
{"f_1919:files_scm",(void*)f_1919},
{"f_1931:files_scm",(void*)f_1931},
{"f_1925:files_scm",(void*)f_1925},
{"f_1904:files_scm",(void*)f_1904},
{"f_1916:files_scm",(void*)f_1916},
{"f_1910:files_scm",(void*)f_1910},
{"f_1889:files_scm",(void*)f_1889},
{"f_1901:files_scm",(void*)f_1901},
{"f_1895:files_scm",(void*)f_1895},
{"f_1813:files_scm",(void*)f_1813},
{"f_1829:files_scm",(void*)f_1829},
{"f_1858:files_scm",(void*)f_1858},
{"f_1883:files_scm",(void*)f_1883},
{"f_1868:files_scm",(void*)f_1868},
{"f_1839:files_scm",(void*)f_1839},
{"f_1799:files_scm",(void*)f_1799},
{"f_1752:files_scm",(void*)f_1752},
{"f_1756:files_scm",(void*)f_1756},
{"f_1763:files_scm",(void*)f_1763},
{"f_1769:files_scm",(void*)f_1769},
{"f_1766:files_scm",(void*)f_1766},
{"f_1720:files_scm",(void*)f_1720},
{"f_1724:files_scm",(void*)f_1724},
{"f_1731:files_scm",(void*)f_1731},
{"f_1634:files_scm",(void*)f_1634},
{"f_1687:files_scm",(void*)f_1687},
{"f_1663:files_scm",(void*)f_1663},
{"f_1670:files_scm",(void*)f_1670},
{"f_1603:files_scm",(void*)f_1603},
{"f_1542:files_scm",(void*)f_1542},
{"f_1551:files_scm",(void*)f_1551},
{"f_1581:files_scm",(void*)f_1581},
{"f_1589:files_scm",(void*)f_1589},
{"f_1489:files_scm",(void*)f_1489},
{"f_1505:files_scm",(void*)f_1505},
{"f_1476:files_scm",(void*)f_1476},
{"f_1487:files_scm",(void*)f_1487},
{"f_1062:files_scm",(void*)f_1062},
{"f_1422:files_scm",(void*)f_1422},
{"f_1417:files_scm",(void*)f_1417},
{"f_1064:files_scm",(void*)f_1064},
{"f_1410:files_scm",(void*)f_1410},
{"f_1406:files_scm",(void*)f_1406},
{"f_1080:files_scm",(void*)f_1080},
{"f_1083:files_scm",(void*)f_1083},
{"f_1399:files_scm",(void*)f_1399},
{"f_1086:files_scm",(void*)f_1086},
{"f_1382:files_scm",(void*)f_1382},
{"f_1392:files_scm",(void*)f_1392},
{"f_1089:files_scm",(void*)f_1089},
{"f_1326:files_scm",(void*)f_1326},
{"f_1357:files_scm",(void*)f_1357},
{"f_1369:files_scm",(void*)f_1369},
{"f_1375:files_scm",(void*)f_1375},
{"f_1363:files_scm",(void*)f_1363},
{"f_1332:files_scm",(void*)f_1332},
{"f_1338:files_scm",(void*)f_1338},
{"f2838:files_scm",(void*)f2838},
{"f_1349:files_scm",(void*)f_1349},
{"f_1092:files_scm",(void*)f_1092},
{"f_1095:files_scm",(void*)f_1095},
{"f_1271:files_scm",(void*)f_1271},
{"f_1302:files_scm",(void*)f_1302},
{"f_1314:files_scm",(void*)f_1314},
{"f_1320:files_scm",(void*)f_1320},
{"f_1308:files_scm",(void*)f_1308},
{"f_1277:files_scm",(void*)f_1277},
{"f_1283:files_scm",(void*)f_1283},
{"f2834:files_scm",(void*)f2834},
{"f_1294:files_scm",(void*)f_1294},
{"f_1098:files_scm",(void*)f_1098},
{"f_1101:files_scm",(void*)f_1101},
{"f_1104:files_scm",(void*)f_1104},
{"f_1111:files_scm",(void*)f_1111},
{"f_1113:files_scm",(void*)f_1113},
{"f_1206:files_scm",(void*)f_1206},
{"f_1247:files_scm",(void*)f_1247},
{"f_1259:files_scm",(void*)f_1259},
{"f_1265:files_scm",(void*)f_1265},
{"f_1253:files_scm",(void*)f_1253},
{"f_1212:files_scm",(void*)f_1212},
{"f_1218:files_scm",(void*)f_1218},
{"f_1225:files_scm",(void*)f_1225},
{"f_1228:files_scm",(void*)f_1228},
{"f_1239:files_scm",(void*)f_1239},
{"f_1235:files_scm",(void*)f_1235},
{"f_1190:files_scm",(void*)f_1190},
{"f_1193:files_scm",(void*)f_1193},
{"f_1200:files_scm",(void*)f_1200},
{"f_1123:files_scm",(void*)f_1123},
{"f_1126:files_scm",(void*)f_1126},
{"f_1134:files_scm",(void*)f_1134},
{"f_1165:files_scm",(void*)f_1165},
{"f_1177:files_scm",(void*)f_1177},
{"f_1183:files_scm",(void*)f_1183},
{"f_1171:files_scm",(void*)f_1171},
{"f_1140:files_scm",(void*)f_1140},
{"f_1146:files_scm",(void*)f_1146},
{"f2828:files_scm",(void*)f2828},
{"f_1157:files_scm",(void*)f_1157},
{"f_1129:files_scm",(void*)f_1129},
{"f_1132:files_scm",(void*)f_1132},
{"f_715:files_scm",(void*)f_715},
{"f_1014:files_scm",(void*)f_1014},
{"f_1009:files_scm",(void*)f_1009},
{"f_717:files_scm",(void*)f_717},
{"f_1002:files_scm",(void*)f_1002},
{"f_998:files_scm",(void*)f_998},
{"f_733:files_scm",(void*)f_733},
{"f_736:files_scm",(void*)f_736},
{"f_991:files_scm",(void*)f_991},
{"f_739:files_scm",(void*)f_739},
{"f_974:files_scm",(void*)f_974},
{"f_984:files_scm",(void*)f_984},
{"f_742:files_scm",(void*)f_742},
{"f_918:files_scm",(void*)f_918},
{"f_949:files_scm",(void*)f_949},
{"f_961:files_scm",(void*)f_961},
{"f_967:files_scm",(void*)f_967},
{"f_955:files_scm",(void*)f_955},
{"f_924:files_scm",(void*)f_924},
{"f_930:files_scm",(void*)f_930},
{"f2824:files_scm",(void*)f2824},
{"f_941:files_scm",(void*)f_941},
{"f_745:files_scm",(void*)f_745},
{"f_748:files_scm",(void*)f_748},
{"f_863:files_scm",(void*)f_863},
{"f_894:files_scm",(void*)f_894},
{"f_906:files_scm",(void*)f_906},
{"f_912:files_scm",(void*)f_912},
{"f_900:files_scm",(void*)f_900},
{"f_869:files_scm",(void*)f_869},
{"f_875:files_scm",(void*)f_875},
{"f2820:files_scm",(void*)f2820},
{"f_886:files_scm",(void*)f_886},
{"f_751:files_scm",(void*)f_751},
{"f_754:files_scm",(void*)f_754},
{"f_757:files_scm",(void*)f_757},
{"f_764:files_scm",(void*)f_764},
{"f_766:files_scm",(void*)f_766},
{"f_798:files_scm",(void*)f_798},
{"f_839:files_scm",(void*)f_839},
{"f_851:files_scm",(void*)f_851},
{"f_857:files_scm",(void*)f_857},
{"f_845:files_scm",(void*)f_845},
{"f_804:files_scm",(void*)f_804},
{"f_810:files_scm",(void*)f_810},
{"f_817:files_scm",(void*)f_817},
{"f_820:files_scm",(void*)f_820},
{"f_831:files_scm",(void*)f_831},
{"f_827:files_scm",(void*)f_827},
{"f_782:files_scm",(void*)f_782},
{"f_785:files_scm",(void*)f_785},
{"f_792:files_scm",(void*)f_792},
{"f_776:files_scm",(void*)f_776},
{"f_779:files_scm",(void*)f_779},
{"f_703:files_scm",(void*)f_703},
{"f_710:files_scm",(void*)f_710},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
