/* Generated from csc.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: csc.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file csc.c
   used units: library eval data_structures ports srfi_1 srfi_13 utils files extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[430];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_ccall f_788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_791)
static void C_ccall f_791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_797)
static void C_ccall f_797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_803)
static void C_ccall f_803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_809)
static void C_ccall f_809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4474)
static void C_ccall f_4474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4470)
static void C_ccall f_4470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4466)
static void C_ccall f_4466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4462)
static void C_ccall f_4462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4458)
static void C_ccall f_4458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_854)
static void C_ccall f_854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_858)
static void C_ccall f_858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5673)
static void C_ccall f5673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4444)
static void C_ccall f_4444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5326)
static void C_ccall f5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4440)
static void C_ccall f_4440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5669)
static void C_ccall f5669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4428)
static void C_ccall f_4428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5321)
static void C_ccall f5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5316)
static void C_ccall f5316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4408)
static void C_ccall f_4408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5311)
static void C_ccall f5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5306)
static void C_ccall f5306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5301)
static void C_ccall f5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5296)
static void C_ccall f5296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5291)
static void C_ccall f5291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4372)
static void C_ccall f_4372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5286)
static void C_ccall f5286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_944)
static void C_fcall f_944(C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4355)
static void C_ccall f_4355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4341)
static void C_ccall f_4341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4316)
static void C_ccall f_4316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5665)
static void C_ccall f5665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5281)
static void C_ccall f5281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4296)
static void C_ccall f_4296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_fcall f_1007(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_ccall f_1014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_fcall f_1022(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4252)
static void C_ccall f_4252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1224)
static void C_fcall f_1224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_fcall f_1836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_fcall f_2053(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2289)
static void C_fcall f_2289(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2292)
static void C_fcall f_2292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2727)
static void C_ccall f_2727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2348)
static void C_fcall f_2348(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_fcall f_2357(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2690)
static void C_ccall f_2690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_ccall f_2696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2680)
static void C_ccall f_2680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2631)
static void C_fcall f_2631(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2604)
static void C_ccall f_2604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2435)
static void C_fcall f_2435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2521)
static void C_ccall f_2521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2517)
static void C_ccall f_2517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2468)
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2506)
static void C_ccall f_2506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2466)
static void C_ccall f_2466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2425)
static void C_ccall f_2425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2412)
static void C_ccall f_2412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2395)
static void C_ccall f_2395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2381)
static void C_ccall f_2381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2367)
static void C_ccall f_2367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2299)
static C_word C_fcall f_2299(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2286)
static void C_ccall f_2286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2230)
static void C_ccall f_2230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2266)
static void C_ccall f_2266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2256)
static void C_ccall f_2256(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2244)
static void C_ccall f_2244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2205)
static void C_ccall f_2205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2217)
static void C_ccall f_2217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2166)
static void C_ccall f_2166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2178)
static void C_ccall f_2178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2128)
static void C_ccall f_2128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2077)
static void C_ccall f_2077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2026)
static void C_ccall f_2026(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static void C_ccall f_1992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1962)
static void C_ccall f_1962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1952)
static void C_ccall f_1952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1942)
static void C_ccall f_1942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1921)
static void C_ccall f_1921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1865)
static void C_ccall f_1865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1788)
static void C_ccall f_1788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1795)
static void C_ccall f_1795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1756)
static void C_ccall f_1756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1760)
static void C_ccall f_1760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1763)
static void C_ccall f_1763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1638)
static void C_fcall f_1638(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1615)
static void C_ccall f_1615(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1553)
static void C_ccall f_1553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1488)
static void C_ccall f_1488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_ccall f_1095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1102)
static void C_ccall f_1102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1044)
static void C_ccall f_1044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1052)
static void C_ccall f_1052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1048)
static void C_ccall f_1048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1448)
static void C_ccall f_1448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1415)
static void C_ccall f_1415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1441)
static void C_ccall f_1441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1418)
static void C_ccall f_1418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5272)
static void C_ccall f5272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1434)
static void C_ccall f_1434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1242)
static void C_ccall f_1242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_fcall f_1378(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1381)
static void C_fcall f_1381(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2823)
static void C_fcall f_2823(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5266)
static void C_ccall f5266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5261)
static void C_ccall f5261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_ccall f_2935(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_fcall f_2874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2884)
static void C_fcall f_2884(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2913)
static void C_ccall f_2913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2862)
static void C_ccall f_2862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2842)
static void C_ccall f_2842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2800)
static void C_fcall f_2800(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2810)
static void C_ccall f_2810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_ccall f_1245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_fcall f_1248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3127)
static void C_fcall f_3127(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3181)
static void C_ccall f_3181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3139)
static void C_ccall f_3139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5244)
static void C_ccall f5244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5239)
static void C_ccall f5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3178)
static void C_ccall f_3178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2973)
static void C_ccall f_2973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3125)
static void C_ccall f_3125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3100)
static void C_fcall f_3100(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3103)
static void C_ccall f_3103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4208)
static void C_ccall f_4208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3106)
static void C_ccall f_3106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2976)
static void C_fcall f_2976(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3044)
static void C_fcall f_3044(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3086)
static void C_ccall f_3086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3052)
static void C_fcall f_3052(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3056)
static void C_ccall f_3056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5232)
static void C_ccall f5232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3079)
static void C_ccall f_3079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5227)
static void C_ccall f5227(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3083)
static void C_ccall f_3083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3071)
static void C_ccall f_3071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2979)
static void C_ccall f_2979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3042)
static void C_ccall f_3042(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_fcall f_3017(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_fcall f_2994(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3004)
static void C_ccall f_3004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1272)
static void C_ccall f_1272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1275)
static void C_ccall f_1275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1278)
static void C_ccall f_1278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1281)
static void C_ccall f_1281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5218)
static void C_ccall f5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5213)
static void C_ccall f5213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1260)
static void C_ccall f_1260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3569)
static void C_ccall f_3569r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3561)
static void C_ccall f_3561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3524)
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5206)
static void C_ccall f5206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3553)
static void C_ccall f_3553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3254)
static void C_ccall f_3254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5201)
static void C_ccall f5201(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3257)
static void C_ccall f_3257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3501)
static void C_ccall f_3501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3504)
static void C_ccall f_3504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_ccall f_3518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5196)
static void C_ccall f5196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3514)
static void C_ccall f_3514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3507)
static void C_ccall f_3507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3510)
static void C_ccall f_3510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3473)
static void C_ccall f_3473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3483)
static void C_ccall f_3483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5191)
static void C_ccall f5191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3486)
static void C_ccall f_3486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3423)
static void C_ccall f_3423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5186)
static void C_ccall f5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3437)
static void C_ccall f_3437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3260)
static void C_ccall f_3260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5181)
static void C_ccall f5181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3388)
static void C_ccall f_3388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3263)
static void C_ccall f_3263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3337)
static void C_fcall f_3337(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3374)
static void C_ccall f_3374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5176)
static void C_ccall f5176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3360)
static void C_ccall f_3360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3356)
static void C_ccall f_3356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3340)
static void C_ccall f_3340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4105)
static void C_ccall f_4105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5171)
static void C_ccall f5171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_ccall f_4129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_ccall f_4108(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4111)
static void C_ccall f_4111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5166)
static void C_ccall f5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4121)
static void C_ccall f_4121(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4114)
static void C_ccall f_4114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4117)
static void C_ccall f_4117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_fcall f_3301(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3636)
static void C_ccall f_3636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3317)
static void C_ccall f_3317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4135)
static void C_ccall f_4135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4138)
static void C_ccall f_4138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4141)
static void C_ccall f_4141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4144)
static void C_ccall f_4144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4197)
static void C_ccall f_4197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4147)
static void C_ccall f_4147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4150)
static void C_ccall f_4150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4156)
static void C_ccall f_4156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4159)
static void C_ccall f_4159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3269)
static void C_fcall f_3269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1207)
static C_word C_fcall f_1207(C_word *a);
C_noret_decl(f_1181)
static void C_fcall f_1181(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1190)
static void C_ccall f_1190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_fcall f_1142(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1160)
static void C_ccall f_1160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1135)
static void C_fcall f_1135(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1140)
static void C_ccall f_1140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4237)
static void C_ccall f_4237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4083)
static void C_ccall f_4083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_fcall f_4063(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4021)
static void C_ccall f_4021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4024)
static void C_ccall f_4024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4040)
static void C_ccall f_4040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4043)
static void C_ccall f_4043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4046)
static void C_ccall f_4046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4027)
static void C_ccall f_4027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3977)
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3984)
static void C_ccall f_3984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3995)
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3990)
static void C_ccall f_3990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3930)
static void C_fcall f_3930(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3960)
static void C_fcall f_3960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3967)
static void C_ccall f_3967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3953)
static void C_ccall f_3953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3924)
static void C_ccall f_3924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3910)
static void C_ccall f_3910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3920)
static void C_ccall f_3920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_fcall f_3834(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3838)
static void C_ccall f_3838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3880)
static void C_ccall f_3880r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3874)
static void C_ccall f_3874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_fcall f_3853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3845)
static void C_ccall f_3845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3782)
static void C_fcall f_3782(C_word t0) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3820)
static void C_ccall f_3820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3816)
static void C_ccall f_3816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3797)
static void C_fcall f_3797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_fcall f_3685(C_word t0) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3741)
static void C_fcall f_3741(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3645)
static void C_fcall f_3645(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3659)
static void C_ccall f_3659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5143)
static void C_ccall f5143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3679)
static void C_ccall f_3679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_ccall f_3662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3665)
static void C_ccall f_3665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5138)
static void C_ccall f5138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3675)
static void C_ccall f_3675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3671)
static void C_ccall f_3671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3575)
static void C_fcall f_3575(C_word t0) C_noret;
C_noret_decl(f_3583)
static void C_ccall f_3583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3194)
static void C_fcall f_3194(C_word t0) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3208)
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_ccall f_3202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_881)
static void C_ccall f_881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_889)
static void C_ccall f_889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_835)
static void C_fcall f_835(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_846)
static void C_ccall f_846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_850)
static void C_ccall f_850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_944)
static void C_fcall trf_944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_944(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_944(t0,t1);}

C_noret_decl(trf_1007)
static void C_fcall trf_1007(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1007(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1007(t0,t1);}

C_noret_decl(trf_1022)
static void C_fcall trf_1022(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1022(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1022(t0,t1);}

C_noret_decl(trf_1224)
static void C_fcall trf_1224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1224(t0,t1,t2);}

C_noret_decl(trf_1836)
static void C_fcall trf_1836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1836(t0,t1);}

C_noret_decl(trf_2053)
static void C_fcall trf_2053(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2053(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2053(t0,t1);}

C_noret_decl(trf_2289)
static void C_fcall trf_2289(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2289(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2289(t0,t1);}

C_noret_decl(trf_2292)
static void C_fcall trf_2292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2292(t0,t1);}

C_noret_decl(trf_2348)
static void C_fcall trf_2348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2348(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2348(t0,t1);}

C_noret_decl(trf_2357)
static void C_fcall trf_2357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2357(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2357(t0,t1);}

C_noret_decl(trf_2631)
static void C_fcall trf_2631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2631(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2631(t0,t1);}

C_noret_decl(trf_2435)
static void C_fcall trf_2435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2435(t0,t1);}

C_noret_decl(trf_2468)
static void C_fcall trf_2468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2468(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2468(t0,t1,t2);}

C_noret_decl(trf_1638)
static void C_fcall trf_1638(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1638(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1638(t0,t1);}

C_noret_decl(trf_1378)
static void C_fcall trf_1378(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1378(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1378(t0,t1);}

C_noret_decl(trf_1381)
static void C_fcall trf_1381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1381(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1381(t0,t1);}

C_noret_decl(trf_2823)
static void C_fcall trf_2823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2823(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2823(t0,t1,t2);}

C_noret_decl(trf_2874)
static void C_fcall trf_2874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2874(t0,t1);}

C_noret_decl(trf_2884)
static void C_fcall trf_2884(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2884(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2884(t0,t1,t2);}

C_noret_decl(trf_2800)
static void C_fcall trf_2800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2800(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2800(t0,t1,t2);}

C_noret_decl(trf_1248)
static void C_fcall trf_1248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1248(t0,t1);}

C_noret_decl(trf_3127)
static void C_fcall trf_3127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3127(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3127(t0,t1,t2);}

C_noret_decl(trf_3135)
static void C_fcall trf_3135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3135(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3135(t0,t1,t2);}

C_noret_decl(trf_3100)
static void C_fcall trf_3100(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3100(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3100(t0,t1);}

C_noret_decl(trf_2976)
static void C_fcall trf_2976(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2976(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2976(t0,t1);}

C_noret_decl(trf_3044)
static void C_fcall trf_3044(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3044(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3044(t0,t1,t2);}

C_noret_decl(trf_3052)
static void C_fcall trf_3052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3052(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3052(t0,t1,t2);}

C_noret_decl(trf_3017)
static void C_fcall trf_3017(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3017(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3017(t0,t1,t2);}

C_noret_decl(trf_2994)
static void C_fcall trf_2994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2994(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2994(t0,t1,t2);}

C_noret_decl(trf_3524)
static void C_fcall trf_3524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3524(t0,t1,t2);}

C_noret_decl(trf_3337)
static void C_fcall trf_3337(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3337(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3337(t0,t1);}

C_noret_decl(trf_3301)
static void C_fcall trf_3301(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3301(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3301(t0,t1);}

C_noret_decl(trf_3269)
static void C_fcall trf_3269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3269(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3277(t0,t1,t2);}

C_noret_decl(trf_1181)
static void C_fcall trf_1181(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1181(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1181(t0,t1);}

C_noret_decl(trf_1142)
static void C_fcall trf_1142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1142(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1142(t0,t1,t2,t3);}

C_noret_decl(trf_1135)
static void C_fcall trf_1135(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1135(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1135(t0,t1);}

C_noret_decl(trf_4063)
static void C_fcall trf_4063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4063(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4063(t0,t1);}

C_noret_decl(trf_3930)
static void C_fcall trf_3930(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3930(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3930(t0,t1,t2);}

C_noret_decl(trf_3960)
static void C_fcall trf_3960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3960(t0,t1);}

C_noret_decl(trf_3834)
static void C_fcall trf_3834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3834(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3834(t0,t1);}

C_noret_decl(trf_3853)
static void C_fcall trf_3853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3853(t0,t1);}

C_noret_decl(trf_3782)
static void C_fcall trf_3782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3782(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3782(t0);}

C_noret_decl(trf_3797)
static void C_fcall trf_3797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3797(t0,t1);}

C_noret_decl(trf_3685)
static void C_fcall trf_3685(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3685(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3685(t0);}

C_noret_decl(trf_3700)
static void C_fcall trf_3700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3700(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3700(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3741)
static void C_fcall trf_3741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3741(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3741(t0,t1);}

C_noret_decl(trf_3645)
static void C_fcall trf_3645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3645(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3645(t0,t1,t2);}

C_noret_decl(trf_3575)
static void C_fcall trf_3575(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3575(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3575(t0);}

C_noret_decl(trf_3194)
static void C_fcall trf_3194(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3194(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3194(t0);}

C_noret_decl(trf_3208)
static void C_fcall trf_3208(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3208(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3208(t0,t1,t2);}

C_noret_decl(trf_835)
static void C_fcall trf_835(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_835(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_835(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2859)){
C_save(t1);
C_rereclaim2(2859*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,430);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"mingw32");
lf[4]=C_h_intern(&lf[4],4,"msvc");
lf[6]=C_h_intern(&lf[6],6,"macosx");
lf[9]=C_h_intern(&lf[9],6,"netbsd");
lf[11]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\005linux\376\003\000\000\002\376\001\000\000\006netbsd\376\003\000\000\002\376\001\000\000\007freebsd\376\003\000\000\002\376\001\000\000\007solaris\376\003\000\000\002\376\001\000\000\007openb"
"sd\376\377\016");
lf[14]=C_h_intern(&lf[14],4,"exit");
lf[15]=C_h_intern(&lf[15],7,"fprintf");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\010~a: ~\077~%");
lf[17]=C_h_intern(&lf[17],17,"\003syspeek-c-string");
lf[18]=C_h_intern(&lf[18],18,"current-error-port");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[25]=C_h_intern(&lf[25],2,"qs");
lf[26]=C_h_intern(&lf[26],18,"normalize-pathname");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\003obj");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001o");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\005-out:");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\003exe");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\003-Fo");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\003-o ");
lf[50]=C_h_intern(&lf[50],26,"\003sysload-dynamic-extension");
lf[86]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014/usr/include\376\003\000\000\002\376B\000\000\000\376\377\016");
lf[107]=C_h_intern(&lf[107],18,"string-intersperse");
lf[109]=C_h_intern(&lf[109],6,"append");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[112]=C_h_intern(&lf[112],13,"make-pathname");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[116]=C_h_intern(&lf[116],17,"get-output-string");
lf[117]=C_h_intern(&lf[117],7,"display");
lf[118]=C_h_intern(&lf[118],19,"\003syswrite-char/port");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\007copy /Y");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\002cp");
lf[121]=C_h_intern(&lf[121],18,"open-output-string");
lf[123]=C_h_intern(&lf[123],7,"reverse");
lf[124]=C_h_intern(&lf[124],6,"static");
lf[125]=C_h_intern(&lf[125],14,"static-options");
lf[126]=C_h_intern(&lf[126],21,"extension-information");
lf[127]=C_h_intern(&lf[127],15,"repository-path");
lf[129]=C_h_intern(&lf[129],13,"string-append");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\010 -static");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[133]=C_h_intern(&lf[133],9,"\003syserror");
lf[135]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000#\376\377\016");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[138]=C_h_intern(&lf[138],17,"string-translate*");
lf[139]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\001\042\376B\000\000\002\134\042\376\377\016");
lf[140]=C_h_intern(&lf[140],16,"\003syslist->string");
lf[141]=C_h_intern(&lf[141],5,"cons*");
lf[142]=C_h_intern(&lf[142],16,"\003sysstring->list");
lf[143]=C_h_intern(&lf[143],10,"string-any");
lf[144]=C_h_intern(&lf[144],6,"char=\077");
lf[146]=C_h_intern(&lf[146],19,"\003sysstandard-output");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[148]=C_h_intern(&lf[148],5,"write");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000;\012Error: shell command terminated with non-zero exit status ");
lf[150]=C_h_intern(&lf[150],6,"system");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[153]=C_h_intern(&lf[153],5,"print");
lf[155]=C_h_intern(&lf[155],11,"delete-file");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\003rm ");
lf[157]=C_h_intern(&lf[157],25,"\003sysimplicit-exit-handler");
lf[158]=C_decode_literal(C_heaptop,"\376B\000\000#not enough arguments to option `~A\047");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\013-dynamiclib");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000\007-bundle");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\004-dll");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\007-shared");
lf[163]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-DC_SHARED\376\377\016");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-shared");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\026-DC_PRIVATE_REPOSITORY");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\031-framework CoreFoundation");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\032</string>\012</dict>\012</plist>");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\001\262<\077xml version=\0421.0\042 encoding=\042UTF-8\042\077>\012<!DOCTYPE plist SYSTEM \042file://local"
"host/System/Library/DTDs/PropertyList.dtd\042>\012<plist version=\0420.9\042>\012<dict>\012\011<key>C"
"FBundlePackageType</key>\012\011<string>APPL</string>\012\011<key>CFBundleIconFile</key>\012\011<s"
"tring>CHICKEN.icns</string>\012        <key>CFBundleGetInfoString</key>\012\011<string>Cr"
"eated by CHICKEN</string>\012\011<key>CFBundleSignature</key>\012\011<string>\077\077\077\077</string>\012\011"
"<key>CFBundleExecutable</key>\012\011<string>");
lf[170]=C_h_intern(&lf[170],19,"\003sysprint-to-string");
lf[171]=C_h_intern(&lf[171],19,"with-output-to-file");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[173]=C_h_intern(&lf[173],12,"file-exists\077");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\012Info.plist");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\024chicken/CHICKEN.icns");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\014CHICKEN.icns");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\010Contents");
lf[180]=C_h_intern(&lf[180],13,"pathname-file");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\012libchicken");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\005dylib");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\003dll");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\005mac.r");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000 /Developer/Tools/Rez -t APPL -o ");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000+install_name_tool -change libchicken.dylib ");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\020libchicken.dylib");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\020@executable_path");
lf[193]=C_h_intern(&lf[193],16,"create-directory");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\006mkdir ");
lf[195]=C_h_intern(&lf[195],17,"directory-exists\077");
lf[196]=C_decode_literal(C_heaptop,"\376B\000\000\017Contents/MacOS/");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\022Contents/Resources");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\016Contents/MacOS");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\011mkdir -p ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\003app");
lf[202]=C_h_intern(&lf[202],24,"pathname-strip-extension");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\004.old");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004move");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\002mv");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\005.old\047");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 - renaming source to `");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\0001Warning: output file will overwrite source file `");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\001\232\042\042 type=\042\042win32\042\042/>\134r\134n\042\012  \042  <ms_asmv2:trustInfo xmlns:ms_asmv2=\042\042urn:sche"
"mas-microsoft-com:asm.v2\042\042>\134r\134n\042\012  \042    <ms_asmv2:security>\134r\134n\042\012  \042      <ms_as"
"mv2:requestedPrivileges>\134r\134n\042\012  \042        <ms_asmv2:requestedExecutionLevel level"
"=\042\042asInvoker\042\042 uiAccess=\042\042false\042\042/>\134r\134n\042\012  \042      </ms_asmv2:requestedPrivileges"
">\134r\134n\042\012  \042    </ms_asmv2:security>\134r\134n\042\012  \042  </ms_asmv2:trustInfo>\134r\134n\042\012  \042</ass"
"embly>\134r\134n\042\012END");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\001\0031 24 MOVEABLE PURE\012BEGIN\012  \042<\077xml version=\042\0421.0\042\042 encoding=\042\042UTF-8\042\042 standa"
"lone=\042\042yes\042\042\077>\134r\134n\042\012  \042<assembly xmlns=\042\042urn:schemas-microsoft-com:asm.v1\042\042 mani"
"festVersion=\042\0421.0\042\042>\134r\134n\042\012  \042  <assemblyIdentity version=\042\0421.0.0.0\042\042 processorAr"
"chitecture=\042\042*\042\042 name=\042\042");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\013generating ");
lf[213]=C_h_intern(&lf[213],26,"pathname-replace-extension");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[215]=C_h_intern(&lf[215],7,"windows");
lf[216]=C_h_intern(&lf[216],13,"software-type");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002-c");
lf[218]=C_h_intern(&lf[218],4,"last");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\031no source files specified");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[221]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\025chicken-scheme-to-c++\376\377\016");
lf[222]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\026chicken-scheme-to-objc\376\377\016");
lf[223]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\012-to-stdout\376\377\016");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\014-output-file");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\010-dynamic");
lf[229]=C_h_intern(&lf[229],7,"newline");
lf[230]=C_h_intern(&lf[230],6,"print*");
lf[231]=C_h_intern(&lf[231],4,"conc");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\010 -Wl,-R\042");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\010\134$ORIGIN");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\003-L\042");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[241]=C_h_intern(&lf[241],5,"-help");
lf[242]=C_h_intern(&lf[242],6,"--help");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\003\047.\012");
lf[244]=C_decode_literal(C_heaptop,"\376B\000(\217\047 is a driver program for the CHICKEN compiler. Files given on the\012  comman"
"d line are translated, compiled or linked as needed.\012\012  FILENAME is a Scheme sou"
"rce file name with optional extension or a\012  C/C++/Objective-C source, object or"
" library file name with extension. OPTION\012  may be one of the following:\012\012  Gene"
"ral options:\012\012    -h  -help                      display this text and exit\012    "
"-v                             show intermediate compilation stages\012    -vv  -ve"
"rbose                  display information about translation\012                   "
"                 progress\012    -vvv                           display information"
" about all compilation\012                                    stages\012    -V  -versi"
"on                   display Scheme compiler version and exit\012    -release      "
"                 display release number and exit\012\012  File and pathname options:\012\012"
"    -o -output-file FILENAME       specifies target executable name\012    -I -incl"
"ude-path PATHNAME      specifies alternative path for included\012                 "
"                   files\012    -to-stdout                     write compiler to st"
"dout (implies -t)\012    -s -shared -dynamic            generate dynamically loadab"
"le shared object\012                                    file\012\012  Language options:\012\012"
"    -D  -DSYMBOL  -feature SYMBOL  register feature identifier\012    -no-feature S"
"YMBOL             disable builtin feature identifier\012    -c++                   "
"        compile via a C++ source file (.cpp) \012    -objc                         "
" compile via Objective-C source file (.m)\012\012  Syntax related options:\012\012    -i -ca"
"se-insensitive           don\047t preserve case of read symbols    \012    -K  -keywor"
"d-style STYLE       enable alternative keyword-syntax\012                          "
"          (prefix, suffix or none)\012        -no-parentheses-synonyms   disables l"
"ist delimiter synonyms\012        -no-symbol-escape          disables support for e"
"scaped symbols\012        -r5rs-syntax               disables the Chicken extension"
"s to\012                                    R5RS syntax\012    -compile-syntax        "
"        macros are made available at run-time\012    -j -emit-import-library MODULE"
" write compile-time module information into\012                                    "
"separate file\012    -J -emit-all-import-libraries  emit import-libraries for all d"
"efined modules\012    -no-module-registration        do not generate module registr"
"ation code\012    -no-compiler-syntax            disable expansion of compiler-macr"
"os\012\012  Translation options:\012\012    -x  -explicit-use              do not use units "
"`library\047 and `eval\047 by\012                                    default\012    -P  -che"
"ck-syntax              stop compilation after macro-expansion\012    -A  -analyze-o"
"nly              stop compilation after first analysis pass\012\012  Debugging options"
":\012\012    -w  -no-warnings               disable warnings\012    -d0 -d1 -d2 -debug-le"
"vel NUMBER\012                                   set level of available debugging i"
"nformation\012    -no-trace                      disable rudimentary debugging info"
"rmation\012    -profile                       executable emits profiling informatio"
"n \012    -accumulate-profile            executable emits profiling information in\012"
"                                    append mode\012    -profile-name FILENAME      "
"   name of the generated profile information\012                                   "
" file\012    -S  -scrutinize                perform local flow analysis\012    -types "
"FILENAME                load additional type database\012\012  Optimization options:\012\012"
"    -O -O0 -O1 -O2 -O3 -O4 -O5 -optimize-level NUMBER\012                          "
"         enable certain sets of optimization options\012    -optimize-leaf-routines"
"        enable leaf routine optimization\012    -no-usual-integrations         stan"
"dard procedures may be redefined\012    -u  -unsafe                    disable safe"
"ty checks\012    -local                         assume globals are only modified in"
" current\012                                    file\012    -b  -block                "
"     enable block-compilation\012    -disable-interrupts            disable interru"
"pts in compiled code\012    -f  -fixnum-arithmetic         assume all numbers are f"
"ixnums\012    -lambda-lift                   perform lambda-lifting\012    -disable-st"
"ack-overflow-checks disables detection of stack-overflows\012    -inline           "
"             enable inlining\012    -inline-limit                  set inlining thr"
"eshold\012    -inline-global                 enable cross-module inlining\012    -unbo"
"xing                      use unboxed temporaries if possible\012    -n -emit-inlin"
"e-file FILENAME  generate file with globally inlinable\012                         "
"           procedures (implies -inline -local)\012    -consult-inline-file FILENAME"
"  explicitly load inline file\012    -no-argc-checks                disable argumen"
"t count checks\012    -no-bound-checks               disable bound variable checks\012"
"    -no-procedure-checks           disable procedure call checks\012    -no-procedu"
"re-checks-for-usual-bindings\012                                   disable procedur"
"e call checks only for usual\012                                    bindings\012    -n"
"o-procedure-checks-for-toplevel-bindings\012                                   disa"
"ble procedure call checks for toplevel\012                                    bindi"
"ngs\012\012  Configuration options:\012\012    -unit NAME                     compile file a"
"s a library unit\012    -uses NAME                     declare library unit as used"
".\012    -heap-size NUMBER              specifies heap-size of compiled executable\012"
"    -heap-initial-size NUMBER      specifies heap-size at startup time\012    -heap"
"-growth PERCENTAGE        specifies growth-rate of expanding heap\012    -heap-shri"
"nkage PERCENTAGE     specifies shrink-rate of contracting heap\012    -nursery NUMB"
"ER  -stack-size NUMBER\012                                   specifies nursery size"
" of compiled\012                                   executable\012    -X -extend FILENA"
"ME            load file before compilation commences\012    -prelude EXPRESSION    "
"        add expression to beginning of source file\012    -postlude EXPRESSION     "
"      add expression to end of source file\012    -prologue FILENAME             in"
"clude file before main source file\012    -epilogue FILENAME             include fi"
"le after main source file\012\012    -e  -embedded                  compile as embedde"
"d\012                                    (don\047t generate `main()\047)\012    -gui        "
"                   compile as GUI application\012    -R  -require-extension NAME   "
" require extension and import in compiled\012                                    co"
"de\012    -dll -library                  compile multiple units into a dynamic\012    "
"                                library\012    -deploy                        deplo"
"y self-contained application bundle\012\012  Options to other passes:\012\012    -C OPTION  "
"                    pass option to C compiler\012    -L OPTION                     "
" pass option to linker\012    -I<DIR>                        pass \134\042-I<DIR>\134\042 to C "
"compiler\012                                    (add include path)\012    -L<DIR>     "
"                   pass \134\042-L<DIR>\134\042 to linker\012                                  "
"  (add library path)\012    -k                             keep intermediate files\012"
"    -c                             stop after compilation to object files\012    -t"
"                             stop after translation to C\012    -cc COMPILER       "
"            select other C compiler than the default\012    -cxx COMPILER          "
"        select other C++ compiler than the default\012    -ld COMPILER             "
"      select other linker than the default \012    -lLIBNAME                      l"
"ink with given library\012                                    (`libLIBNAME\047 on UNIX"
",\012                                     `LIBNAME.lib\047 on Windows)\012    -static-lib"
"s                   link with static CHICKEN libraries\012    -static              "
"          generate completely statically linked\012                                "
"    executable\012    -static-extension NAME         link extension NAME statically"
"\012                                    (if available)\012    -F<DIR>                 "
"       pass \134\042-F<DIR>\134\042 to C compiler\012                                    (add f"
"ramework header path on Mac OS X)\012    -framework NAME                passed to l"
"inker on Mac OS X\012    -rpath PATHNAME                add directory to runtime li"
"brary search path\012    -Wl,...                        pass linker options\012    -st"
"rip                         strip resulting binary\012\012  Inquiry options:\012\012    -hom"
"e                          show home-directory (where support files go)\012    -cfl"
"ags                        show required C-compiler flags and exit\012    -ldflags "
"                      show required linker flags and exit\012    -libs             "
"             show required libraries and exit\012    -cc-name                      "
" show name of default C compiler used\012    -cxx-name                      show na"
"me of default C++ compiler used\012    -ld-name                       show name of "
"default linker used\012    -dry-run                       just show commands execut"
"ed, don\047t run them\012                                    (implies `-v\047)\012\012  Obscure"
" options:\012\012    -debug MODES                   display debugging output for the g"
"iven modes\012    -compiler PATHNAME             use other compiler than default `c"
"hicken\047\012    -raw                           do not generate implicit init- and ex"
"it code\012    -emit-external-prototypes-first\012                                   e"
"mit prototypes for callbacks before foreign\012                                    "
"declarations\012    -ignore-repository             do not refer to repository for e"
"xtensions\012    -keep-shadowed-macros          do not remove shadowed macro\012    -h"
"ost                          compile for host when configured for\012              "
"                      cross-compiling\012    -private-repository            load ex"
"tensions from executable path\012    -deployed                      compile support"
" file to be used from a deployed \012                                    executable"
"\012    -no-elevation                  embed manifest on Windows to supress elevati"
"on\012                                    warnings for programs named `install\047 or "
"`setup\047\012\012  Options can be collapsed if unambiguous, so\012\012    -vkfO\012\012  is the same"
" as\012\012    -v -k -fixnum-arithmetic -optimize\012\012  The contents of the environment v"
"ariable CSC_OPTIONS are implicitly passed to\012  every invocation of `");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\033 FILENAME | OPTION ...\012\012  `");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\007Usage: ");
lf[247]=C_h_intern(&lf[247],8,"-release");
lf[248]=C_h_intern(&lf[248],15,"chicken-version");
lf[249]=C_h_intern(&lf[249],8,"-version");
lf[250]=C_h_intern(&lf[250],7,"sprintf");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\011 -version");
lf[252]=C_h_intern(&lf[252],4,"-c++");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[254]=C_h_intern(&lf[254],5,"-objc");
lf[255]=C_h_intern(&lf[255],7,"-static");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[258]=C_h_intern(&lf[258],12,"-static-libs");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\026chicken-compile-static");
lf[261]=C_h_intern(&lf[261],7,"-cflags");
lf[262]=C_h_intern(&lf[262],8,"-ldflags");
lf[263]=C_h_intern(&lf[263],8,"-cc-name");
lf[264]=C_h_intern(&lf[264],9,"-cxx-name");
lf[265]=C_h_intern(&lf[265],8,"-ld-name");
lf[266]=C_h_intern(&lf[266],5,"-home");
lf[267]=C_h_intern(&lf[267],5,"-libs");
lf[268]=C_h_intern(&lf[268],2,"-v");
lf[269]=C_h_intern(&lf[269],8,"-verbose");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\010-verbose");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\010-VERBOSE");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\002-Q");
lf[275]=C_h_intern(&lf[275],2,"-w");
lf[276]=C_h_intern(&lf[276],12,"-no-warnings");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\002-w");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\014-no-warnings");
lf[279]=C_h_intern(&lf[279],2,"-A");
lf[280]=C_h_intern(&lf[280],13,"-analyze-only");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000\015-analyze-only");
lf[282]=C_h_intern(&lf[282],2,"-P");
lf[283]=C_h_intern(&lf[283],13,"-check-syntax");
lf[284]=C_decode_literal(C_heaptop,"\376B\000\000\015-check-syntax");
lf[285]=C_h_intern(&lf[285],2,"-k");
lf[286]=C_h_intern(&lf[286],2,"-c");
lf[287]=C_h_intern(&lf[287],2,"-t");
lf[288]=C_h_intern(&lf[288],2,"-e");
lf[289]=C_h_intern(&lf[289],9,"-embedded");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\014-DC_EMBEDDED");
lf[291]=C_h_intern(&lf[291],18,"-require-extension");
lf[292]=C_h_intern(&lf[292],2,"-R");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[294]=C_h_intern(&lf[294],17,"-static-extension");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\021-static-extension");
lf[296]=C_h_intern(&lf[296],19,"-private-repository");
lf[297]=C_h_intern(&lf[297],13,"-no-elevation");
lf[298]=C_h_intern(&lf[298],4,"-gui");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\007-DC_GUI");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\012-lkernel32");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\010-luser32");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\007-lgdi32");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\011-mwindows");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\014kernel32.lib");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\012user32.lib");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\011gdi32.lib");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\012chicken.rc");
lf[308]=C_h_intern(&lf[308],7,"-deploy");
lf[309]=C_h_intern(&lf[309],9,"-deployed");
lf[310]=C_h_intern(&lf[310],10,"-framework");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\012-framework");
lf[312]=C_h_intern(&lf[312],2,"-o");
lf[313]=C_h_intern(&lf[313],2,"-O");
lf[314]=C_h_intern(&lf[314],3,"-O1");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[317]=C_h_intern(&lf[317],3,"-O0");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[320]=C_h_intern(&lf[320],3,"-O2");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[323]=C_h_intern(&lf[323],3,"-O3");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\0013");
lf[326]=C_h_intern(&lf[326],3,"-O4");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\0014");
lf[329]=C_h_intern(&lf[329],3,"-O5");
lf[330]=C_h_intern(&lf[330],6,"cygwin");
lf[331]=C_h_intern(&lf[331],3,"gnu");
lf[332]=C_h_intern(&lf[332],5,"clang");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\003-O3");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\024-fomit-frame-pointer");
lf[335]=C_h_intern(&lf[335],14,"build-platform");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\017-optimize-level");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\0015");
lf[338]=C_h_intern(&lf[338],3,"-d0");
lf[339]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[341]=C_h_intern(&lf[341],3,"-d1");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\0011");
lf[344]=C_h_intern(&lf[344],3,"-d2");
lf[345]=C_decode_literal(C_heaptop,"\376B\000\000\014-debug-level");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000\0012");
lf[347]=C_h_intern(&lf[347],8,"-dry-run");
lf[348]=C_h_intern(&lf[348],2,"-s");
lf[349]=C_h_intern(&lf[349],4,"-dll");
lf[350]=C_h_intern(&lf[350],8,"-library");
lf[351]=C_h_intern(&lf[351],9,"-compiler");
lf[352]=C_h_intern(&lf[352],3,"-cc");
lf[353]=C_h_intern(&lf[353],4,"-cxx");
lf[354]=C_h_intern(&lf[354],3,"-ld");
lf[355]=C_h_intern(&lf[355],2,"-I");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[357]=C_h_intern(&lf[357],2,"-C");
lf[358]=C_h_intern(&lf[358],12,"string-split");
lf[359]=C_h_intern(&lf[359],6,"-strip");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[361]=C_h_intern(&lf[361],2,"-L");
lf[362]=C_h_intern(&lf[362],6,"-rpath");
lf[363]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\003gnu\376\003\000\000\002\376\001\000\000\005clang\376\377\016");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\006-Wl,-R");
lf[365]=C_h_intern(&lf[365],5,"-host");
lf[366]=C_h_intern(&lf[366],1,"-");
lf[367]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\001-\376\377\016");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[369]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-s\376\003\000\000\002\376B\000\000\007-shared\376\377\016\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\002-S\376\003\000\000\002\376B\000\000\013-scrutinize\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-P\376\003\000\000\002\376B\000\000\015-check-syntax\376\377\016\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\002-V\376\003\000\000\002\376B\000\000\010-version\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-f\376\003\000\000\002\376B\000\000\022-fixnum-arithmetic\376"
"\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-D\376\003\000\000\002\376B\000\000\010-feature\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensi"
"tive\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-X\376\003\000\000\002\376B\000\000\007-e"
"xtend\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-N\376\003\000\000\002\376B\000\000\026-no-usual-integrations\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-J\376\003\000"
"\000\002\376B\000\000\032-emit-all-import-libraries\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-x\376\003\000\000\002\376B\000\000\015-explicit-use\376\377\016\376"
"\003\000\000\002\376\003\000\000\002\376\001\000\000\002-u\376\003\000\000\002\376B\000\000\007-unsafe\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-j\376\003\000\000\002\376B\000\000\024-emit-import-libr"
"ary\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-n\376\003\000\000\002\376B\000\000\021-emit-inline-file\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\002-b\376\003\000\000\002\376B\000\000\006"
"-block\376\377\016\376\377\016");
lf[370]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\015-explicit-use\376\003\000\000\002\376\001\000\000\011-no-trace\376\003\000\000\002\376\001\000\000\014-no-warnings\376\003\000\000\002\376\001\000\000\026-no-us"
"ual-integrations\376\003\000\000\002\376\001\000\000\027-optimize-leaf-routines\376\003\000\000\002\376\001\000\000\007-unsafe\376\003\000\000\002\376\001\000\000\006-blo"
"ck\376\003\000\000\002\376\001\000\000\023-disable-interrupts\376\003\000\000\002\376\001\000\000\022-fixnum-arithmetic\376\003\000\000\002\376\001\000\000\012-to-stdout\376"
"\003\000\000\002\376\001\000\000\010-profile\376\003\000\000\002\376\001\000\000\004-raw\376\003\000\000\002\376\001\000\000\023-accumulate-profile\376\003\000\000\002\376\001\000\000\015-check-syn"
"tax\376\003\000\000\002\376\001\000\000\021-case-insensitive\376\003\000\000\002\376\001\000\000\007-shared\376\003\000\000\002\376\001\000\000\017-compile-syntax\376\003\000\000\002\376\001\000"
"\000\017-no-lambda-info\376\003\000\000\002\376\001\000\000\014-lambda-lift\376\003\000\000\002\376\001\000\000\010-dynamic\376\003\000\000\002\376\001\000\000\036-disable-stac"
"k-overflow-checks\376\003\000\000\002\376\001\000\000\006-local\376\003\000\000\002\376\001\000\000\037-emit-external-prototypes-first\376\003\000\000\002\376"
"\001\000\000\007-inline\376\003\000\000\002\376\001\000\000\010-release\376\003\000\000\002\376\001\000\000\013-scrutinize\376\003\000\000\002\376\001\000\000\015-analyze-only\376\003\000\000\002\376\001"
"\000\000\025-keep-shadowed-macros\376\003\000\000\002\376\001\000\000\016-inline-global\376\003\000\000\002\376\001\000\000\022-ignore-repository\376\003\000\000"
"\002\376\001\000\000\021-no-symbol-escape\376\003\000\000\002\376\001\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376\001\000\000\014-r5rs-syntax\376"
"\003\000\000\002\376\001\000\000\017-no-argc-checks\376\003\000\000\002\376\001\000\000\020-no-bound-checks\376\003\000\000\002\376\001\000\000\024-no-procedure-checks"
"\376\003\000\000\002\376\001\000\000\023-no-compiler-syntax\376\003\000\000\002\376\001\000\000\032-emit-all-import-libraries\376\003\000\000\002\376\001\000\000\013-setu"
"p-mode\376\003\000\000\002\376\001\000\000\011-unboxing\376\003\000\000\002\376\001\000\000\015-no-elevation\376\003\000\000\002\376\001\000\000\027-no-module-registratio"
"n\376\003\000\000\002\376\001\000\000\047-no-procedure-checks-for-usual-bindings\376\003\000\000\002\376\001\000\000*-no-procedure-checks"
"-for-toplevel-bindings\376\377\016");
lf[371]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006-debug\376\003\000\000\002\376\001\000\000\014-output-file\376\003\000\000\002\376\001\000\000\012-heap-size\376\003\000\000\002\376\001\000\000\010-nursery\376\003\000\000"
"\002\376\001\000\000\013-stack-size\376\003\000\000\002\376\001\000\000\011-compiler\376\003\000\000\002\376\001\000\000\005-unit\376\003\000\000\002\376\001\000\000\005-uses\376\003\000\000\002\376\001\000\000\016-key"
"word-style\376\003\000\000\002\376\001\000\000\017-optimize-level\376\003\000\000\002\376\001\000\000\015-include-path\376\003\000\000\002\376\001\000\000\016-database-si"
"ze\376\003\000\000\002\376\001\000\000\007-extend\376\003\000\000\002\376\001\000\000\010-prelude\376\003\000\000\002\376\001\000\000\011-postlude\376\003\000\000\002\376\001\000\000\011-prologue\376\003\000\000\002"
"\376\001\000\000\011-epilogue\376\003\000\000\002\376\001\000\000\015-inline-limit\376\003\000\000\002\376\001\000\000\015-profile-name\376\003\000\000\002\376\001\000\000\020-disable-w"
"arning\376\003\000\000\002\376\001\000\000\021-emit-inline-file\376\003\000\000\002\376\001\000\000\006-types\376\003\000\000\002\376\001\000\000\010-feature\376\003\000\000\002\376\001\000\000\014-de"
"bug-level\376\003\000\000\002\376\001\000\000\014-heap-growth\376\003\000\000\002\376\001\000\000\017-heap-shrinkage\376\003\000\000\002\376\001\000\000\022-heap-initial-"
"size\376\003\000\000\002\376\001\000\000\024-consult-inline-file\376\003\000\000\002\376\001\000\000\024-emit-import-library\376\003\000\000\002\376\001\000\000\021-stati"
"c-extension\376\003\000\000\002\376\001\000\000\013-no-feature\376\377\016");
lf[372]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[373]=C_h_intern(&lf[373],9,"substring");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[376]=C_h_intern(&lf[376],15,"lset-difference");
lf[377]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000P\376\003\000\000\002\376\377\012\000\000H\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000f\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000E\376\003\000"
"\000\002\376\377\012\000\000N\376\003\000\000\002\376\377\012\000\000x\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000b\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000w\376\003\000\000\002\376\377\012\000\000A\376\003\000\000\002\376"
"\377\012\000\000O\376\003\000\000\002\376\377\012\000\000e\376\003\000\000\002\376\377\012\000\000W\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000c\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000g\376\003\000\000\002\376\377\012\000"
"\000S\376\003\000\000\002\376\377\012\000\000J\376\377\016");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid option `~A\047");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\004-Wl,");
lf[380]=C_h_intern(&lf[380],18,"decompose-pathname");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\001h");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\002rc");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\003cpp");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001C");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\002cc");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\003cxx");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000\003hpp");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\017-no-cpp-precomp");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\001m");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\001M");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\002mm");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\030file `~A\047 does not exist");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\004.scm");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\002-:");
lf[396]=C_h_intern(&lf[396],15,"-optimize-level");
lf[397]=C_h_intern(&lf[397],15,"-benchmark-mode");
lf[398]=C_h_intern(&lf[398],10,"-to-stdout");
lf[399]=C_h_intern(&lf[399],7,"-shared");
lf[400]=C_h_intern(&lf[400],8,"-dynamic");
lf[401]=C_h_intern(&lf[401],8,"-windows");
lf[402]=C_h_intern(&lf[402],2,"-W");
lf[403]=C_h_intern(&lf[403],14,"string->symbol");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[405]=C_h_intern(&lf[405],24,"get-environment-variable");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\013CSC_OPTIONS");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\003-I\042");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\007include");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[414]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\011-lchicken\376\377\016");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\003lib");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\022libchicken-static.");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\013libchicken.");
lf[419]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[420]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005-fPIC\376\003\000\000\002\376B\000\000\005-DPIC\376\377\016");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\004link");
lf[423]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\005share");
lf[426]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[427]=C_h_intern(&lf[427],22,"command-line-arguments");
lf[428]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[429]=C_h_intern(&lf[429],16,"software-version");
C_register_lf2(lf,430,create_ptable());
t2=C_mutate(&lf[0] /* (set! c37 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_785,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k783 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_788,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k786 in k783 */
static void C_ccall f_788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_791,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k789 in k786 in k783 */
static void C_ccall f_791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_791,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k792 in k789 in k786 in k783 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_794,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_797,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_803,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_806,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:66: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[335]))(2,*((C_word*)lf[335]+1),t2);}

/* k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4474,2,t0,t1);}
t2=C_eqp(t1,lf[2]);
t3=C_mutate(&lf[3] /* (set! mingw ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4470,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:67: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[335]))(2,*((C_word*)lf[335]+1),t4);}

/* k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4470,2,t0,t1);}
t2=C_eqp(t1,lf[4]);
t3=C_mutate(&lf[5] /* (set! msvc ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4466,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:68: software-version */
((C_proc2)C_retrieve_symbol_proc(lf[429]))(2,*((C_word*)lf[429]+1),t4);}

/* k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4466,2,t0,t1);}
t2=C_eqp(t1,lf[6]);
t3=C_mutate(&lf[7] /* (set! osx ...) */,t2);
t4=C_retrieve2(lf[3],"mingw");
t5=(C_truep(C_retrieve2(lf[3],"mingw"))?C_retrieve2(lf[3],"mingw"):C_retrieve2(lf[5],"msvc"));
t6=C_mutate(&lf[8] /* (set! win ...) */,t5);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4462,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:70: software-version */
((C_proc2)C_retrieve_symbol_proc(lf[429]))(2,*((C_word*)lf[429]+1),t7);}

/* k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4462,2,t0,t1);}
t2=C_eqp(t1,lf[9]);
t3=C_mutate(&lf[10] /* (set! netbsd ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4458,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:73: software-version */
((C_proc2)C_retrieve_symbol_proc(lf[429]))(2,*((C_word*)lf[429]+1),t4);}

/* k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4458,2,t0,t1);}
t2=C_i_memq(t1,lf[11]);
t3=C_mutate(&lf[12] /* (set! elf ...) */,t2);
t4=C_mutate(&lf[13] /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_835,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:79: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[405]))(3,*((C_word*)lf[405]+1),t5,lf[428]);}

/* k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_854,2,t0,t1);}
t2=C_mutate(&lf[19] /* (set! chicken-prefix ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:80: command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[427]))(2,*((C_word*)lf[427]+1),t3);}

/* k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_858,2,t0,t1);}
t2=C_mutate(&lf[20] /* (set! arguments ...) */,t1);
t3=C_i_member(lf[21],C_retrieve2(lf[20],"arguments"));
t4=C_mutate(&lf[22] /* (set! host-mode ...) */,t3);
t5=C_fudge(C_fix(39));
t6=C_mutate(&lf[23] /* (set! cross-chicken ...) */,t5);
t7=C_mutate(&lf[24] /* (set! quotewrap ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_881,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4444,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4448,a[2]=t8,a[3]=t9,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t11=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)C_TARGET_SHARE_HOME),C_fix(0));}}

/* k4446 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[425]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t2,lf[426]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5673,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}}

/* f5673 in k4446 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4442 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5326 in k4442 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! home ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4428,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4436,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k4434 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4440,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CHICKEN_PROGRAM),C_fix(0));}

/* k4438 in k4434 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:99: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4430 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4432,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[423]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t2,lf[424]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5669,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}}

/* f5669 in k4430 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4426 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5321 in k4426 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=C_mutate(&lf[28] /* (set! translator ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4418,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}

/* k4416 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5316,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5316 in k4416 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=C_mutate(&lf[29] /* (set! compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_905,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4408,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}

/* k4406 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5311,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5311 in k4406 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_905,2,t0,t1);}
t2=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4398,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_RC_COMPILER),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_RC_COMPILER),C_fix(0));}}

/* k4396 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5306 in k4396 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_909,2,t0,t1);}
t2=C_mutate(&lf[31] /* (set! rc-compiler ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4385,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5301,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,lf[422]);}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CC),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}}}

/* f5301 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4383 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4385,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5296,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5296 in k4383 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_913,2,t0,t1);}
t2=C_mutate(&lf[32] /* (set! linker ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4372,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5291,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,lf[421]);}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CXX),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CXX),C_fix(0));}}}

/* f5291 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4370 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5286,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5286 in k4370 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_917,2,t0,t1);}
t2=C_mutate(&lf[33] /* (set! c++-linker ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[34]:lf[35]);
t4=C_mutate(&lf[36] /* (set! object-extension ...) */,t3);
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[37]:lf[38]);
t6=C_mutate(&lf[39] /* (set! library-extension ...) */,t5);
t7=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[40]:lf[41]);
t8=C_mutate(&lf[42] /* (set! link-output-flag ...) */,t7);
t9=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[43]:lf[44]);
t10=C_mutate(&lf[45] /* (set! executable-extension ...) */,t9);
t11=(C_truep(C_retrieve2(lf[5],"msvc"))?lf[46]:lf[47]);
t12=C_mutate(&lf[48] /* (set! compile-output-flag ...) */,t11);
t13=C_mutate(&lf[49] /* (set! shared-library-extension ...) */,C_retrieve(lf[50]));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_944,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=C_retrieve2(lf[3],"mingw");
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t16=C_retrieve2(lf[3],"mingw");
t17=t14;
f_944(t17,(C_truep(C_retrieve2(lf[3],"mingw"))?lf[419]:lf[420]));}
else{
t16=C_retrieve2(lf[5],"msvc");
t17=t14;
f_944(t17,(C_truep(C_retrieve2(lf[5],"msvc"))?lf[419]:lf[420]));}}

/* k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_944(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_944,NULL,2,t0,t1);}
t2=C_mutate(&lf[51] /* (set! pic-options ...) */,t1);
t3=C_mutate(&lf[52] /* (set! windows-shell ...) */,C_mk_bool(C_WINDOWS_SHELL));
t4=lf[53] /* generate-manifest */ =C_SCHEME_FALSE;;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
/* csc.scm:121: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t5,lf[417],C_retrieve2(lf[39],"library-extension"));}
else{
/* csc.scm:121: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t5,lf[418],C_retrieve2(lf[39],"library-extension"));}}

/* k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=C_mutate(&lf[54] /* (set! default-library ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4355,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_CFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CFLAGS),C_fix(0));}}

/* k4353 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:125: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),((C_word*)t0)[2],t1);}

/* k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=C_mutate(&lf[55] /* (set! default-compilation-optimization-options ...) */,t1);
t3=C_mutate(&lf[56] /* (set! best-compilation-optimization-options ...) */,C_retrieve2(lf[55],"default-compilation-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_959,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4345,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LDFLAGS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_LDFLAGS),C_fix(0));}}

/* k4343 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:127: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),((C_word*)t0)[2],t1);}

/* k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate(&lf[57] /* (set! default-linking-optimization-options ...) */,t1);
t3=C_mutate(&lf[58] /* (set! best-linking-optimization-options ...) */,C_retrieve2(lf[57],"default-linking-optimization-options"));
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
t5=t4;
f_964(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4341,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_FEATURES),C_fix(0));}}

/* k4339 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:129: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),((C_word*)t0)[2],t1);}

/* k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
t2=C_mutate(&lf[59] /* (set! extra-features ...) */,t1);
t3=lf[60] /* scheme-files */ =C_SCHEME_END_OF_LIST;;
t4=lf[61] /* c-files */ =C_SCHEME_END_OF_LIST;;
t5=lf[62] /* rc-files */ =C_SCHEME_END_OF_LIST;;
t6=lf[63] /* generated-c-files */ =C_SCHEME_END_OF_LIST;;
t7=lf[64] /* generated-rc-files */ =C_SCHEME_END_OF_LIST;;
t8=lf[65] /* object-files */ =C_SCHEME_END_OF_LIST;;
t9=lf[66] /* generated-object-files */ =C_SCHEME_END_OF_LIST;;
t10=lf[67] /* cpp-mode */ =C_SCHEME_FALSE;;
t11=lf[68] /* objc-mode */ =C_SCHEME_FALSE;;
t12=lf[69] /* embedded */ =C_SCHEME_FALSE;;
t13=lf[70] /* inquiry-only */ =C_SCHEME_FALSE;;
t14=lf[71] /* show-cflags */ =C_SCHEME_FALSE;;
t15=lf[72] /* show-ldflags */ =C_SCHEME_FALSE;;
t16=lf[73] /* show-libs */ =C_SCHEME_FALSE;;
t17=lf[74] /* dry-run */ =C_SCHEME_FALSE;;
t18=lf[75] /* gui */ =C_SCHEME_FALSE;;
t19=lf[76] /* deploy */ =C_SCHEME_FALSE;;
t20=lf[77] /* deployed */ =C_SCHEME_FALSE;;
t21=lf[78] /* rpath */ =C_SCHEME_FALSE;;
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t23=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_INSTALL_MORE_STATIC_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t23=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t23+1)))(4,t23,t22,C_mpointer(&a,(void*)C_TARGET_MORE_STATIC_LIBS),C_fix(0));}}

/* k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=C_mutate(&lf[79] /* (set! extra-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_999,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_MORE_LIBS),C_fix(0));}
else{
/* ##sys#peek-c-string */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_MORE_LIBS),C_fix(0));}}

/* k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
t2=C_mutate(&lf[80] /* (set! extra-shared-libraries ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4304,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4308,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4312,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4310 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4316,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:215: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t2,lf[416],C_retrieve2(lf[54],"default-library"));}

/* k4314 in k4310 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:213: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4306 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=C_retrieve2(lf[54],"default-library");
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[415]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t3,C_retrieve2(lf[54],"default-library"));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5665,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t3,t1);}}

/* f5665 in k4306 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4302 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5281,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5281 in k4302 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4300,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=C_mutate(&lf[81] /* (set! default-library-files ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4296,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:219: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t5,lf[413],C_retrieve2(lf[39],"library-extension"));}
else{
t5=t4;
f_1007(t5,lf[414]);}}

/* k4294 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4296,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1007(t2,C_a_i_list(&a,1,t1));}

/* k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1007(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1007,NULL,2,t0,t1);}
t2=C_mutate(&lf[82] /* (set! default-shared-library-files ...) */,t1);
t3=C_mutate(&lf[83] /* (set! library-files ...) */,C_retrieve2(lf[81],"default-library-files"));
t4=C_mutate(&lf[84] /* (set! shared-library-files ...) */,C_retrieve2(lf[82],"default-shared-library-files"));
t5=lf[85] /* translate-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4283,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_INCLUDE_HOME),C_fix(0));}}

/* k4281 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4283,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[411]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[2],t2,lf[412]);}
else{
t2=((C_word*)t0)[2];
f_1014(2,t2,t1);}}

/* k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1014,2,t0,t1);}
t2=C_i_member(t1,lf[86]);
t3=(C_truep(t2)?C_SCHEME_FALSE:t1);
t4=C_mutate(&lf[87] /* (set! include-dir ...) */,t3);
t5=lf[88] /* compile-options */ =C_SCHEME_END_OF_LIST;;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[87],"include-dir"))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4272,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:236: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),t7,lf[409],C_retrieve2(lf[87],"include-dir"),lf[410]);}
else{
t7=t6;
f_1022(t7,C_SCHEME_END_OF_LIST);}}

/* k4270 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1022(t2,C_a_i_list(&a,1,t1));}

/* k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1022(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1022,NULL,2,t0,t1);}
t2=C_mutate(&lf[89] /* (set! builtin-compile-options ...) */,t1);
t3=lf[90] /* translation-optimization-options */ =C_SCHEME_END_OF_LIST;;
t4=C_mutate(&lf[91] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[55],"default-compilation-optimization-options"));
t5=C_mutate(&lf[92] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[57],"default-linking-optimization-options"));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4259,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t8=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}}

/* k4257 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[407]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[2],t2,lf[408]);}
else{
t2=((C_word*)t0)[2];
f_1030(2,t2,t1);}}

/* k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=C_mutate(&lf[93] /* (set! library-dir ...) */,t1);
t3=lf[94] /* link-options */ =C_SCHEME_END_OF_LIST;;
t4=lf[95] /* target-filename */ =C_SCHEME_FALSE;;
t5=lf[96] /* verbose */ =C_SCHEME_FALSE;;
t6=lf[97] /* keep-files */ =C_SCHEME_FALSE;;
t7=lf[98] /* translate-only */ =C_SCHEME_FALSE;;
t8=lf[99] /* compile-only */ =C_SCHEME_FALSE;;
t9=lf[100] /* to-stdout */ =C_SCHEME_FALSE;;
t10=lf[101] /* shared */ =C_SCHEME_FALSE;;
t11=lf[102] /* static */ =C_SCHEME_FALSE;;
t12=lf[103] /* static-libs */ =C_SCHEME_FALSE;;
t13=lf[104] /* static-extensions */ =C_SCHEME_END_OF_LIST;;
t14=lf[105] /* required-extensions */ =C_SCHEME_END_OF_LIST;;
t15=C_mutate(&lf[106] /* (set! compiler-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3194,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate(&lf[110] /* (set! lib-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3575,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate(&lf[114] /* (set! copy-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3645,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate(&lf[122] /* (set! static-extension-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3685,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate(&lf[128] /* (set! linker-options ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3782,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate(&lf[132] /* (set! linker-libraries ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3834,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate(&lf[134] /* (set! constant582 ...) */,lf[135]);
t22=C_mutate(&lf[108] /* (set! quote-option ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3977,tmp=(C_word)a,a+=2,tmp));
t23=lf[145] /* last-exit-code */ =C_SCHEME_FALSE;;
t24=C_mutate(&lf[115] /* (set! command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4063,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate(&lf[154] /* (set! $delete-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4079,tmp=(C_word)a,a+=2,tmp));
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=t26,tmp=(C_word)a,a+=3,tmp);
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=t27,tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4252,a[2]=t28,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1124: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[405]))(3,*((C_word*)lf[405]+1),t29,lf[406]);}

/* k4250 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csc.scm:1124: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),((C_word*)t0)[2],t2);}
else{
/* csc.scm:1124: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),((C_word*)t0)[2],lf[404]);}}

/* k4246 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1123: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[20],"arguments"));}

/* k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1135,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1142,tmp=(C_word)a,a+=2,tmp));
t12=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1181,tmp=(C_word)a,a+=2,tmp));
t13=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1207,tmp=(C_word)a,a+=2,tmp));
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1224,a[2]=t7,a[3]=t5,a[4]=t3,a[5]=t15,a[6]=t9,tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1224(t17,((C_word*)t0)[2],t1);}

/* loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1224,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[6],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:517: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t3,C_retrieve2(lf[88],"compile-options"),C_retrieve2(lf[89],"builtin-compile-options"));}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1461,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t6,a[8]=t1,a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* csc.scm:563: string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[403]+1)))(3,*((C_word*)lf[403]+1),t7,t3);}}

/* k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1464,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(t1,lf[241]);
t4=(C_truep(t3)?t3:C_eqp(t1,lf[242]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1095,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}
else{
t5=C_eqp(t1,lf[247]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1495,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:569: chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[248]))(2,*((C_word*)lf[248]+1),t7);}
else{
t6=C_eqp(t1,lf[249]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1504,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1511,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:572: sprintf */
((C_proc4)C_retrieve_proc(*((C_word*)lf[250]+1)))(4,*((C_word*)lf[250]+1),t8,C_retrieve2(lf[28],"translator"),lf[251]);}
else{
t7=C_eqp(t1,lf[252]);
if(C_truep(t7)){
t8=lf[67] /* cpp-mode */ =C_SCHEME_TRUE;;
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=C_a_i_cons(&a,2,lf[253],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88] /* (set! compile-options ...) */,t9);
/* csc.scm:793: loop */
t11=((C_word*)((C_word*)t0)[9])[1];
f_1224(t11,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
/* csc.scm:793: loop */
t9=((C_word*)((C_word*)t0)[9])[1];
f_1224(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}}
else{
t8=C_eqp(t1,lf[254]);
if(C_truep(t8)){
t9=lf[68] /* objc-mode */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t10=((C_word*)((C_word*)t0)[9])[1];
f_1224(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t9=C_eqp(t1,lf[255]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1542,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:581: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t10,lf[256],lf[257],C_retrieve2(lf[85],"translate-options"));}
else{
t10=C_eqp(t1,lf[258]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1553,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:585: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t11,lf[259],lf[260],C_retrieve2(lf[85],"translate-options"));}
else{
t11=C_eqp(t1,lf[261]);
if(C_truep(t11)){
t12=lf[70] /* inquiry-only */ =C_SCHEME_TRUE;;
t13=lf[71] /* show-cflags */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t14=((C_word*)((C_word*)t0)[9])[1];
f_1224(t14,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t12=C_eqp(t1,lf[262]);
if(C_truep(t12)){
t13=lf[70] /* inquiry-only */ =C_SCHEME_TRUE;;
t14=lf[72] /* show-ldflags */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t15=((C_word*)((C_word*)t0)[9])[1];
f_1224(t15,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t13=C_eqp(t1,lf[263]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:593: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t14,C_retrieve2(lf[29],"compiler"));}
else{
t14=C_eqp(t1,lf[264]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1591,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:594: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t15,C_retrieve2(lf[30],"c++-compiler"));}
else{
t15=C_eqp(t1,lf[265]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1603,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:595: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t16,C_retrieve2(lf[32],"linker"));}
else{
t16=C_eqp(t1,lf[266]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1615,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:596: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t17,C_retrieve2(lf[27],"home"));}
else{
t17=C_eqp(t1,lf[267]);
if(C_truep(t17)){
t18=lf[70] /* inquiry-only */ =C_SCHEME_TRUE;;
t19=lf[73] /* show-libs */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t20=((C_word*)((C_word*)t0)[9])[1];
f_1224(t20,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t18=C_eqp(t1,lf[268]);
t19=(C_truep(t18)?t18:C_eqp(t1,lf[269]));
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1638,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t21=C_i_numberp(C_retrieve2(lf[96],"verbose"));
t22=(C_truep(t21)?C_i_not(C_retrieve2(lf[5],"msvc")):C_SCHEME_FALSE);
if(C_truep(t22)){
t23=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1653,a[2]=t20,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:602: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t23,lf[273],lf[274],C_retrieve2(lf[88],"compile-options"));}
else{
t23=t20;
f_1638(t23,C_SCHEME_UNDEFINED);}}
else{
t20=C_eqp(t1,lf[275]);
t21=(C_truep(t20)?t20:C_eqp(t1,lf[276]));
if(C_truep(t21)){
t22=C_a_i_cons(&a,2,lf[277],C_retrieve2(lf[88],"compile-options"));
t23=C_mutate(&lf[88] /* (set! compile-options ...) */,t22);
/* csc.scm:610: t-options */
f_1135(t2,C_a_i_list(&a,1,lf[278]));}
else{
t22=C_eqp(t1,lf[279]);
t23=(C_truep(t22)?t22:C_eqp(t1,lf[280]));
if(C_truep(t23)){
t24=lf[98] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:613: t-options */
f_1135(t2,C_a_i_list(&a,1,lf[281]));}
else{
t24=C_eqp(t1,lf[282]);
t25=(C_truep(t24)?t24:C_eqp(t1,lf[283]));
if(C_truep(t25)){
t26=lf[98] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:616: t-options */
f_1135(t2,C_a_i_list(&a,1,lf[284]));}
else{
t26=C_eqp(t1,lf[285]);
if(C_truep(t26)){
t27=lf[97] /* keep-files */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t28=((C_word*)((C_word*)t0)[9])[1];
f_1224(t28,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t27=C_eqp(t1,lf[286]);
if(C_truep(t27)){
t28=lf[99] /* compile-only */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t29=((C_word*)((C_word*)t0)[9])[1];
f_1224(t29,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t28=C_eqp(t1,lf[287]);
if(C_truep(t28)){
t29=lf[98] /* translate-only */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t30=((C_word*)((C_word*)t0)[9])[1];
f_1224(t30,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t29=C_eqp(t1,lf[288]);
t30=(C_truep(t29)?t29:C_eqp(t1,lf[289]));
if(C_truep(t30)){
t31=lf[69] /* embedded */ =C_SCHEME_TRUE;;
t32=C_a_i_cons(&a,2,lf[290],C_retrieve2(lf[88],"compile-options"));
t33=C_mutate(&lf[88] /* (set! compile-options ...) */,t32);
/* csc.scm:793: loop */
t34=((C_word*)((C_word*)t0)[9])[1];
f_1224(t34,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t31=C_eqp(t1,lf[291]);
t32=(C_truep(t31)?t31:C_eqp(t1,lf[292]));
if(C_truep(t32)){
t33=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1756,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:624: check */
f_1142(t33,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t33=C_eqp(t1,lf[294]);
if(C_truep(t33)){
t34=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1788,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:629: check */
f_1142(t34,t1,((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t34=C_eqp(t1,lf[296]);
if(C_truep(t34)){
t35=f_1207(C_a_i(&a,6));
/* csc.scm:793: loop */
t36=((C_word*)((C_word*)t0)[9])[1];
f_1224(t36,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t35=C_eqp(t1,lf[297]);
if(C_truep(t35)){
t36=lf[53] /* generate-manifest */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t37=((C_word*)((C_word*)t0)[9])[1];
f_1224(t37,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1]);}
else{
t36=C_eqp(t1,lf[298]);
t37=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t36)){
t38=t37;
f_1836(t38,t36);}
else{
t38=C_eqp(t1,lf[401]);
t39=t37;
f_1836(t39,(C_truep(t38)?t38:C_eqp(t1,lf[402])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=lf[75] /* gui */ =C_SCHEME_TRUE;;
t3=C_a_i_cons(&a,2,lf[299],C_retrieve2(lf[88],"compile-options"));
t4=C_mutate(&lf[88] /* (set! compile-options ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,C_mpointer(&a,(void*)C_INSTALL_SHARE_HOME),C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[7],lf[308]);
if(C_truep(t2)){
t3=lf[76] /* deploy */ =C_SCHEME_TRUE;;
t4=lf[77] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1224(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t3=C_eqp(((C_word*)t0)[7],lf[309]);
if(C_truep(t3)){
t4=lf[77] /* deployed */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[10])[1];
f_1224(t5,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=C_eqp(((C_word*)t0)[7],lf[310]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:661: check */
f_1142(t5,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[7],lf[312]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1921,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:666: check */
f_1142(t6,((C_word*)t0)[7],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[7],lf[313]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[7],lf[314]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1942,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:670: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t8,lf[315],lf[316],((C_word*)((C_word*)t0)[8])[1]);}
else{
t8=C_eqp(((C_word*)t0)[7],lf[317]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1952,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:671: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t9,lf[318],lf[319],((C_word*)((C_word*)t0)[8])[1]);}
else{
t9=C_eqp(((C_word*)t0)[7],lf[320]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1962,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:672: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t10,lf[321],lf[322],((C_word*)((C_word*)t0)[8])[1]);}
else{
t10=C_eqp(((C_word*)t0)[7],lf[323]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:673: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t11,lf[324],lf[325],((C_word*)((C_word*)t0)[8])[1]);}
else{
t11=C_eqp(((C_word*)t0)[7],lf[326]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1982,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:674: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t12,lf[327],lf[328],((C_word*)((C_word*)t0)[8])[1]);}
else{
t12=C_eqp(((C_word*)t0)[7],lf[329]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:676: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t13,lf[336],lf[337],((C_word*)((C_word*)t0)[8])[1]);}
else{
t13=C_eqp(((C_word*)t0)[7],lf[338]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:680: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t14,lf[339],lf[340],((C_word*)((C_word*)t0)[8])[1]);}
else{
t14=C_eqp(((C_word*)t0)[7],lf[341]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2026,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:681: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t15,lf[342],lf[343],((C_word*)((C_word*)t0)[8])[1]);}
else{
t15=C_eqp(((C_word*)t0)[7],lf[344]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:682: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t16,lf[345],lf[346],((C_word*)((C_word*)t0)[8])[1]);}
else{
t16=C_eqp(((C_word*)t0)[7],lf[347]);
if(C_truep(t16)){
t17=lf[96] /* verbose */ =C_SCHEME_TRUE;;
t18=lf[74] /* dry-run */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t19=((C_word*)((C_word*)t0)[10])[1];
f_1224(t19,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1]);}
else{
t17=C_eqp(((C_word*)t0)[7],lf[348]);
t18=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2053,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[4],a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t17)){
t19=t18;
f_2053(t19,t17);}
else{
t19=C_eqp(((C_word*)t0)[7],lf[399]);
t20=t18;
f_2053(t20,(C_truep(t19)?t19:C_eqp(((C_word*)t0)[7],lf[400])));}}}}}}}}}}}}}}}}}

/* k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2053(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2053,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:687: shared-build */
f_1181(((C_word*)t0)[9],C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[8],lf[349]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[8],lf[350]));
if(C_truep(t3)){
/* csc.scm:689: shared-build */
f_1181(((C_word*)t0)[9],C_SCHEME_TRUE);}
else{
t4=C_eqp(((C_word*)t0)[8],lf[351]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2077,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:691: check */
f_1142(t5,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t5=C_eqp(((C_word*)t0)[8],lf[352]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:695: check */
f_1142(t6,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t6=C_eqp(((C_word*)t0)[8],lf[353]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:699: check */
f_1142(t7,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t7=C_eqp(((C_word*)t0)[8],lf[354]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2128,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:703: check */
f_1142(t8,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t8=C_eqp(((C_word*)t0)[8],lf[355]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2145,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:707: check */
f_1142(t9,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t9=C_eqp(((C_word*)t0)[8],lf[357]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2166,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:710: check */
f_1142(t10,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t10=C_eqp(((C_word*)t0)[8],lf[359]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_a_i_list(&a,1,lf[360]);
/* csc.scm:714: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t11,C_retrieve2(lf[94],"link-options"),t12);}
else{
t11=C_eqp(((C_word*)t0)[8],lf[361]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2205,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:716: check */
f_1142(t12,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[8],lf[362]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2230,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:720: check */
f_1142(t13,((C_word*)t0)[8],((C_word*)((C_word*)t0)[7])[1],C_SCHEME_END_OF_LIST);}
else{
t13=C_eqp(((C_word*)t0)[8],lf[365]);
if(C_truep(t13)){
/* csc.scm:793: loop */
t14=((C_word*)((C_word*)t0)[6])[1];
f_1224(t14,((C_word*)t0)[5],((C_word*)((C_word*)t0)[7])[1]);}
else{
t14=C_eqp(((C_word*)t0)[8],lf[366]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2282,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:728: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t15,C_SCHEME_FALSE,lf[368],C_retrieve2(lf[45],"executable-extension"));}
else{
t15=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2289,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
t16=C_eqp(((C_word*)t0)[8],lf[398]);
if(C_truep(t16)){
t17=lf[100] /* to-stdout */ =C_SCHEME_TRUE;;
t18=lf[98] /* translate-only */ =C_SCHEME_TRUE;;
t19=t15;
f_2289(t19,t18);}
else{
t17=t15;
f_2289(t17,C_SCHEME_UNDEFINED);}}}}}}}}}}}}}}}

/* k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2289(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2289,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[9];
if(C_truep((C_truep(C_eqp(t3,lf[396]))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,lf[397]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=C_mutate(&lf[91] /* (set! compilation-optimization-options ...) */,C_retrieve2(lf[56],"best-compilation-optimization-options"));
t5=C_mutate(&lf[92] /* (set! linking-optimization-options ...) */,C_retrieve2(lf[58],"best-linking-optimization-options"));
t6=t2;
f_2292(t6,t5);}
else{
t4=t2;
f_2292(t4,C_SCHEME_UNDEFINED);}}

/* k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2292,NULL,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[9],lf[369]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2299,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t4=f_2299(C_a_i(&a,3),t3,t2);
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_1224(t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[8])[1]);}
else{
if(C_truep(C_i_memq(((C_word*)t0)[9],lf[370]))){
/* csc.scm:738: t-options */
f_1135(((C_word*)t0)[4],C_a_i_list(&a,1,((C_word*)t0)[3]));}
else{
if(C_truep(C_i_memq(((C_word*)t0)[9],lf[371]))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:740: check */
f_1142(t3,((C_word*)t0)[9],((C_word*)((C_word*)t0)[8])[1],C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2348,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
t4=C_i_string_length(((C_word*)t0)[3]);
if(C_truep(C_i_greaterp(t4,C_fix(2)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2727,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:745: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[373]+1)))(5,*((C_word*)lf[373]+1),t5,((C_word*)t0)[3],C_fix(0),C_fix(2));}
else{
t5=t3;
f_2348(t5,C_SCHEME_FALSE);}}}}}

/* k2725 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2348(t2,C_i_string_equal_p(lf[395],t1));}

/* k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2348(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2348,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csc.scm:746: t-options */
f_1135(((C_word*)t0)[7],C_a_i_list(&a,1,((C_word*)t0)[6]));}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2357,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t3=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_greaterp(t3,C_fix(1)))){
t4=C_i_string_ref(((C_word*)t0)[6],C_fix(0));
t5=t2;
f_2357(t5,C_eqp(C_make_character(45),t4));}
else{
t4=t2;
f_2357(t4,C_SCHEME_FALSE);}}}

/* k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2357(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2357,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t3=C_eqp(C_make_character(108),t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2367,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm:750: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t4,C_retrieve2(lf[94],"link-options"),t5);}
else{
t4=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t5=C_eqp(C_make_character(76),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2381,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t7=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm:752: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t6,C_retrieve2(lf[94],"link-options"),t7);}
else{
t6=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t7=C_eqp(C_make_character(73),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2395,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t9=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm:754: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t8,C_retrieve2(lf[88],"compile-options"),t9);}
else{
t8=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t9=C_eqp(C_make_character(68),t8);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2412,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:756: substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[373]+1)))(4,*((C_word*)lf[373]+1),t10,((C_word*)t0)[8],C_fix(2));}
else{
t10=C_i_string_ref(((C_word*)t0)[8],C_fix(1));
t11=C_eqp(C_make_character(70),t10);
if(C_truep(t11)){
if(C_truep(C_retrieve2(lf[7],"osx"))){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2425,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t13=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* csc.scm:759: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t12,C_retrieve2(lf[88],"compile-options"),t13);}
else{
/* csc.scm:793: loop */
t12=((C_word*)((C_word*)t0)[7])[1];
f_1224(t12,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);}}
else{
t12=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2435,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t13=C_i_string_length(((C_word*)t0)[8]);
if(C_truep(C_i_greaterp(t13,C_fix(3)))){
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2538,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:760: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[373]+1)))(5,*((C_word*)lf[373]+1),t14,((C_word*)t0)[8],C_fix(0),C_fix(4));}
else{
t14=t12;
f_2435(t14,C_SCHEME_FALSE);}}}}}}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:769: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,((C_word*)t0)[8]);}}

/* k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2568,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2690,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:789: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t2,((C_word*)t0)[6],lf[394]);}}

/* k2688 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csc.scm:790: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t2,t1);}

/* k2694 in k2688 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2696,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_1224(t4,((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1]);}
else{
/* csc.scm:792: quit */
f_835(((C_word*)t0)[3],lf[393],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2579,5,t0,t1,t2,t3,t4);}
t5=t4;
if(C_truep(t5)){
t6=t4;
if(C_truep((C_truep(C_i_equalp(t6,lf[381]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t6,lf[382]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2604,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:774: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t7,C_retrieve2(lf[61],"c-files"),t8);}
else{
if(C_truep(C_i_string_ci_equal_p(t4,lf[383]))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2618,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:776: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t7,C_retrieve2(lf[62],"rc-files"),t8);}
else{
t7=t4;
if(C_truep((C_truep(C_i_equalp(t7,lf[384]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[385]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[386]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[387]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t7,lf[388]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2631,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t9=C_a_i_cons(&a,2,lf[389],C_retrieve2(lf[88],"compile-options"));
t10=C_mutate(&lf[88] /* (set! compile-options ...) */,t9);
t11=t8;
f_2631(t11,t10);}
else{
t9=t8;
f_2631(t9,C_SCHEME_UNDEFINED);}}
else{
t8=t4;
if(C_truep((C_truep(C_i_equalp(t8,lf[390]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[391]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t8,lf[392]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t9=lf[68] /* objc-mode */ =C_SCHEME_TRUE;;
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2655,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t11=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:783: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t10,C_retrieve2(lf[61],"c-files"),t11);}
else{
t9=C_i_string_equal_p(t4,C_retrieve2(lf[36],"object-extension"));
t10=(C_truep(t9)?t9:C_i_string_equal_p(t4,C_retrieve2(lf[39],"library-extension")));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2672,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:786: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t11,C_retrieve2(lf[65],"object-files"),t12);}
else{
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2680,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:787: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t11,C_retrieve2(lf[60],"scheme-files"),t12);}}}}}}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2590,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:772: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t6,C_retrieve2(lf[60],"scheme-files"),t7);}}

/* k2588 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2678 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! scheme-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2670 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[65] /* (set! object-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2653 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2629 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2631(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2631,NULL,2,t0,t1);}
t2=lf[67] /* cpp-mode */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:780: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t3,C_retrieve2(lf[61],"c-files"),t4);}

/* k2634 in k2629 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2616 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[62] /* (set! rc-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2602 in a2578 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[61] /* (set! c-files ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a2572 in k2566 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
/* csc.scm:770: decompose-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[380]))(3,*((C_word*)lf[380]+1),t1,((C_word*)t0)[2]);}

/* k2536 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2435(t2,C_i_string_equal_p(lf[379],t1));}

/* k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2435,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_a_i_list(&a,1,((C_word*)t0)[4]);
/* csc.scm:761: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t2,C_retrieve2(lf[94],"link-options"),t3);}
else{
t2=C_i_string_length(((C_word*)t0)[4]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2521,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* string->list */
t4=C_retrieve(lf[142]);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
/* csc.scm:768: quit */
f_835(((C_word*)t0)[3],lf[378],C_a_i_list(&a,1,((C_word*)t0)[2]));}}}

/* k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2521,2,t0,t1);}
t2=C_i_cdr(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2517,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:764: lset-difference */
((C_proc5)C_retrieve_symbol_proc(lf[376]))(5,*((C_word*)lf[376]+1),t3,*((C_word*)lf[144]+1),t2,lf[377]);}

/* k2515 in k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2517,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2466,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2468,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_2468(t11,t7,((C_word*)t0)[4]);}
else{
/* csc.scm:767: quit */
f_835(((C_word*)t0)[3],lf[375],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop227 in k2515 in k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2468(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2468,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2506,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_string(&a,1,t4);
/* csc.scm:766: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t3,lf[374],t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2504 in loop227 in k2515 in k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2506,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop227240 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2468(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop227240 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2468(t6,((C_word*)t0)[3],t5);}}

/* k2464 in k2515 in k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:766: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k2460 in k2515 in k2519 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2437 in k2433 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2423 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2410 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2412,2,t0,t1);}
/* csc.scm:756: t-options */
f_1135(((C_word*)t0)[2],C_a_i_list(&a,2,lf[372],t1));}

/* k2393 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2379 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2365 in k2355 in k2346 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2327 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2329,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[6])[1]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2335,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csc.scm:742: string->number */
C_string_to_number(3,0,t3,t2);}

/* k2333 in k2327 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2338,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:743: t-options */
f_1135(t2,C_a_i_list(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k2336 in k2333 in k2327 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1224(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* g211 in k2290 in k2287 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static C_word C_fcall f_2299(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t2=C_i_cadr(t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
return(t4);}

/* k2280 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2282,2,t0,t1);}
t2=C_mutate(&lf[95] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:729: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t3,C_retrieve2(lf[60],"scheme-files"),lf[367]);}

/* k2284 in k2280 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[60] /* (set! scheme-files ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2228 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2230,2,t0,t1);}
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[78] /* (set! rpath ...) */,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:722: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[335]))(2,*((C_word*)lf[335]+1),t4);}

/* k2264 in k2228 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2266,2,t0,t1);}
t2=C_i_memq(t1,lf[363]);
t3=(C_truep(t2)?C_i_not(C_retrieve2(lf[3],"mingw")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2256,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:724: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t5,lf[364],C_retrieve2(lf[78],"rpath"));}
else{
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1224(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k2254 in k2264 in k2228 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2256(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2256,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* csc.scm:724: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[94],"link-options"),t2);}

/* k2242 in k2264 in k2228 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1224(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2203 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2217,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm:717: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,t4);}

/* k2215 in k2203 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:717: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[94],"link-options"),t1);}

/* k2207 in k2203 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1224(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2190 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2164 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm:711: string-split */
((C_proc3)C_retrieve_symbol_proc(lf[358]))(3,*((C_word*)lf[358]+1),t3,t4);}

/* k2176 in k2164 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:711: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[88],"compile-options"),t1);}

/* k2168 in k2164 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1224(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2143 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm:708: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t2,lf[356],t3,t4);}

/* k2147 in k2143 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2126 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[32] /* (set! linker ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1224(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2109 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[30] /* (set! c++-compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1224(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2092 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[29] /* (set! compiler ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1224(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2075 in k2051 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(&lf[28] /* (set! translator ...) */,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1224(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2034 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2024 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2026(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k2014 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1990 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1992,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2006,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:677: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[335]))(2,*((C_word*)lf[335]+1),t3);}

/* k2004 in k1990 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2006,2,t0,t1);}
if(C_truep((C_truep(C_eqp(t1,lf[2]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[330]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[331]))?C_SCHEME_TRUE:(C_truep(C_eqp(t1,lf[332]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2002,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:679: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t2,lf[333],lf[334],C_retrieve2(lf[88],"compile-options"));}
else{
/* csc.scm:793: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1224(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2000 in k2004 in k1990 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1980 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1970 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1960 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1950 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1940 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1224(t3,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1919 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
t5=C_mutate(&lf[95] /* (set! target-filename ...) */,t2);
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[3])[1];
f_1224(t6,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1895 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1897,2,t0,t1);}
if(C_truep(C_retrieve2(lf[7],"osx"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[4])[1]);
/* csc.scm:663: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t2,lf[311],t3,C_retrieve2(lf[94],"link-options"));}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1224(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}}

/* k1906 in k1895 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
t3=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[4])+1,t3);
/* csc.scm:793: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1224(t5,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1871 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:642: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1,lf[307],C_retrieve2(lf[36],"object-extension"));}

/* k1867 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[65],"object-files"));
t3=C_mutate(&lf[65] /* (set! object-files ...) */,t2);
t4=C_retrieve2(lf[5],"msvc");
t5=(C_truep(C_retrieve2(lf[5],"msvc"))?C_retrieve2(lf[5],"msvc"):C_retrieve2(lf[3],"mingw"));
if(C_truep(t5)){
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:650: cons* */
((C_proc7)C_retrieve_symbol_proc(lf[141]))(7,*((C_word*)lf[141]+1),t6,lf[300],lf[301],lf[302],lf[303],C_retrieve2(lf[94],"link-options"));}
else{
if(C_truep(C_retrieve2(lf[5],"msvc"))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1865,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:654: cons* */
((C_proc6)C_retrieve_symbol_proc(lf[141]))(6,*((C_word*)lf[141]+1),t6,lf[304],lf[305],lf[306],C_retrieve2(lf[94],"link-options"));}
else{
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1224(t6,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}
else{
/* csc.scm:793: loop */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1224(t6,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}

/* k1863 in k1867 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1856 in k1867 in k1834 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1786 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1788,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=C_a_i_list(&a,1,t3);
/* csc.scm:630: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t2,C_retrieve2(lf[104],"static-extensions"),t4);}

/* k1790 in k1786 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1792,2,t0,t1);}
t2=C_mutate(&lf[104] /* (set! static-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm:631: t-options */
f_1135(t3,C_a_i_list(&a,2,lf[295],t4));}

/* k1793 in k1790 in k1786 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1224(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1754 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1760,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t4=C_a_i_list(&a,1,t3);
/* csc.scm:625: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t2,C_retrieve2(lf[105],"required-extensions"),t4);}

/* k1758 in k1754 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1760,2,t0,t1);}
t2=C_mutate(&lf[105] /* (set! required-extensions ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1763,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
/* csc.scm:626: t-options */
f_1135(t3,C_a_i_list(&a,2,lf[293],t4));}

/* k1761 in k1758 in k1754 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1224(t4,((C_word*)t0)[2],((C_word*)((C_word*)t0)[4])[1]);}

/* k1651 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[5],"msvc"))?C_a_i_cons(&a,2,lf[271],C_retrieve2(lf[94],"link-options")):C_a_i_cons(&a,2,lf[272],C_retrieve2(lf[94],"link-options")));
t4=C_mutate(&lf[94] /* (set! link-options ...) */,t3);
t5=((C_word*)t0)[2];
f_1638(t5,t4);}

/* k1636 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1638(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1638,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[96],"verbose"))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1644,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:605: t-options */
f_1135(t2,C_a_i_list(&a,1,lf[270]));}
else{
t2=lf[96] /* verbose */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1224(t3,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k1642 in k1636 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[96] /* verbose */ =C_fix(2);;
/* csc.scm:793: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1224(t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1613 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1615(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:596: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1601 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:595: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1589 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:594: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1577 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:593: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(0));}

/* k1551 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[85] /* (set! translate-options ...) */,t1);
t3=lf[103] /* static-libs */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1224(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1540 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[85] /* (set! translate-options ...) */,t1);
t3=lf[102] /* static */ =C_SCHEME_TRUE;;
/* csc.scm:793: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1224(t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1509 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:572: system */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),((C_word*)t0)[2],t1);}

/* k1502 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:573: exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1493 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:569: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),((C_word*)t0)[2],t1);}

/* k1486 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:570: exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1093 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1102,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[243],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,lf[244],t4);
t6=C_a_i_cons(&a,2,t1,t5);
t7=C_a_i_cons(&a,2,lf[245],t6);
t8=C_a_i_cons(&a,2,t1,t7);
t9=C_a_i_cons(&a,2,lf[246],t8);
/* csc.scm:283: ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t2,t9);}

/* k1100 in k1093 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:283: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),((C_word*)t0)[2],t1);}

/* k1474 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:567: exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1462 in k1459 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:793: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1224(t2,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[12],"elf"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1044,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:254: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),t4,lf[237],C_retrieve2(lf[93],"library-dir"),lf[238]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1078,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:264: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),t4,lf[239],C_retrieve2(lf[93],"library-dir"),lf[240]);}}

/* k1076 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* csc.scm:518: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[94],"link-options"),t2);}

/* k1042 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1048,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1052,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[77],"deployed"))?C_i_not(C_retrieve2(lf[10],"netbsd")):C_SCHEME_FALSE);
if(C_truep(t4)){
/* csc.scm:255: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),t2,lf[232],lf[234],lf[233]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1062,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t6=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k1060 in k1042 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1062,2,t0,t1);}
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t2=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[235]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t2,lf[236]);}
else{
/* csc.scm:255: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),((C_word*)t0)[2],lf[232],t1,lf[233]);}}

/* k1050 in k1042 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:255: conc */
((C_proc5)C_retrieve_symbol_proc(lf[231]))(5,*((C_word*)lf[231]+1),((C_word*)t0)[2],lf[232],t1,lf[233]);}

/* k1046 in k1042 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1048,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
/* csc.scm:518: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[94],"link-options"),t2);}

/* k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=C_mutate(&lf[94] /* (set! link-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[70],"inquiry-only"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1415,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[71],"show-cflags"))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1448,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:521: compiler-options */
f_3194(t5);}
else{
t5=t4;
f_1415(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1242(2,t4,C_SCHEME_UNDEFINED);}}

/* k1446 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:521: print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[230]+1)))(4,*((C_word*)lf[230]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1415,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1418,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[72],"show-ldflags"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1441,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:522: linker-options */
f_3782(t3);}
else{
t3=t2;
f_1418(2,t3,C_SCHEME_UNDEFINED);}}

/* k1439 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:522: print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[230]+1)))(4,*((C_word*)lf[230]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1416 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[73],"show-libs"))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1434,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:523: linker-libraries */
f_3834(t3,C_a_i_list(&a,1,C_SCHEME_TRUE));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5272,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:524: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[229]+1)))(2,*((C_word*)lf[229]+1),t3);}}

/* f5272 in k1416 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:525: exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1432 in k1416 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:523: print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[230]+1)))(4,*((C_word*)lf[230]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k1419 in k1416 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:524: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[229]+1)))(2,*((C_word*)lf[229]+1),t2);}

/* k1422 in k1419 in k1416 in k1413 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:525: exit */
((C_proc2)C_retrieve_symbol_proc(lf[14]))(2,*((C_word*)lf[14]+1),((C_word*)t0)[2]);}

/* k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1242,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[60],"scheme-files")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1340,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[61],"c-files")))){
if(C_truep(C_i_nullp(C_retrieve2(lf[65],"object-files")))){
/* csc.scm:529: quit */
f_835(t3,lf[219],C_SCHEME_END_OF_LIST);}
else{
t4=t3;
f_1340(2,t4,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1340(2,t4,C_SCHEME_UNDEFINED);}}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[101],"shared"))?C_i_not(C_retrieve2(lf[69],"embedded")):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[228],C_retrieve2(lf[85],"translate-options"));
t6=C_mutate(&lf[85] /* (set! translate-options ...) */,t5);
t7=t3;
f_1378(t7,t6);}
else{
t5=t3;
f_1378(t5,C_SCHEME_UNDEFINED);}}}

/* k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1378(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1378,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1381,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[95],"target-filename"))){
t3=t2;
f_1381(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1388,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[101],"shared"))){
t4=C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm:542: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t3,t4,C_retrieve2(lf[49],"shared-library-extension"));}
else{
t4=C_i_car(C_retrieve2(lf[60],"scheme-files"));
/* csc.scm:543: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t3,t4,C_retrieve2(lf[45],"executable-extension"));}}}

/* k1386 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[95] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1381(t3,t2);}

/* k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1381(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1381,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2823,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2823(t6,t2,C_retrieve2(lf[60],"scheme-files"));}

/* loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2823(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2823,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2835,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_length(C_retrieve2(lf[60],"scheme-files"));
t6=C_i_nequalp(C_fix(1),t5);
t7=(C_truep(t6)?C_retrieve2(lf[95],"target-filename"):t3);
if(C_truep(C_retrieve2(lf[67],"cpp-mode"))){
/* csc.scm:801: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t4,t7,lf[225]);}
else{
if(C_truep(C_retrieve2(lf[68],"objc-mode"))){
/* csc.scm:801: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t4,t7,lf[226]);}
else{
/* csc.scm:801: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t4,t7,lf[227]);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2835,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2838,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2858,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2862,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2866,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5266,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,((C_word*)t0)[2]);}

/* f5266 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2870,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2874,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[100],"to-stdout"))){
t4=t3;
f_2874(t4,lf[223]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2935,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5261,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}}

/* f5261 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k2933 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2935(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2935,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
f_2874(t3,C_a_i_cons(&a,2,lf[224],t2));}

/* k2872 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2874,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2878,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2882,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[67],"cpp-mode"))){
/* csc.scm:816: append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[109]+1)))(6,*((C_word*)lf[109]+1),t7,C_retrieve2(lf[59],"extra-features"),C_retrieve2(lf[85],"translate-options"),lf[221],C_retrieve2(lf[90],"translation-optimization-options"));}
else{
if(C_truep(C_retrieve2(lf[68],"objc-mode"))){
/* csc.scm:816: append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[109]+1)))(6,*((C_word*)lf[109]+1),t7,C_retrieve2(lf[59],"extra-features"),C_retrieve2(lf[85],"translate-options"),lf[222],C_retrieve2(lf[90],"translation-optimization-options"));}
else{
/* csc.scm:816: append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[109]+1)))(6,*((C_word*)lf[109]+1),t7,C_retrieve2(lf[59],"extra-features"),C_retrieve2(lf[85],"translate-options"),C_SCHEME_END_OF_LIST,C_retrieve2(lf[90],"translation-optimization-options"));}}}

/* k2880 in k2872 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2882,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2884,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2884(t5,((C_word*)t0)[2],t1);}

/* loop300 in k2880 in k2872 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2884(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2884,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[108],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2913,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g316317 */
t6=C_retrieve2(lf[108],"quote-option");
f_3977(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2911 in loop300 in k2880 in k2872 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2913,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop300313 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2884(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop300313 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2884(t6,((C_word*)t0)[3],t5);}}

/* k2876 in k2872 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:811: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2868 in k2864 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:810: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[3],C_retrieve2(lf[28],"translator"),((C_word*)t0)[2],t1);}

/* k2860 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:809: string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[107]))(4,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1,lf[220]);}

/* k2856 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:808: command */
f_4063(((C_word*)t0)[2],t1);}

/* k2836 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2842,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:824: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t2,t3,C_retrieve2(lf[61],"c-files"));}

/* k2840 in k2836 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2842,2,t0,t1);}
t2=C_mutate(&lf[61] /* (set! c-files ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* csc.scm:825: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t3,t4,C_retrieve2(lf[63],"generated-c-files"));}

/* k2844 in k2840 in k2836 in k2833 in loop281 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[63] /* (set! generated-c-files ...) */,t1);
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2823(t4,((C_word*)t0)[2],t3);}

/* k2790 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1245(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2800,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2800(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* loop330 in k2790 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2800(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2800,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[154],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2810,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g337338 */
t6=C_retrieve2(lf[154],"$delete-file");
f_4079(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2808 in loop330 in k2790 in k1379 in k1376 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2800(t3,((C_word*)t0)[2],t2);}

/* k1338 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1340,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(C_retrieve2(lf[61],"c-files")))){
t3=C_retrieve2(lf[65],"object-files");
/* csc.scm:530: last */
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),t2,t3);}
else{
t3=C_retrieve2(lf[61],"c-files");
/* csc.scm:530: last */
((C_proc3)C_retrieve_symbol_proc(lf[218]))(3,*((C_word*)lf[218]+1),t2,t3);}}

/* k1341 in k1338 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
if(C_truep(C_retrieve2(lf[95],"target-filename"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_1245(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[101],"shared"))){
/* csc.scm:534: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t2,t1,C_retrieve2(lf[49],"shared-library-extension"));}
else{
/* csc.scm:535: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t2,t1,C_retrieve2(lf[45],"executable-extension"));}}}

/* k1348 in k1341 in k1338 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[95] /* (set! target-filename ...) */,t1);
t3=((C_word*)t0)[2];
f_1245(2,t3,t2);}

/* k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[76],"deploy"))){
t3=C_retrieve2(lf[101],"shared");
t4=t2;
f_1248(t4,(C_truep(t3)?C_SCHEME_UNDEFINED:f_1207(C_a_i(&a,6))));}
else{
t3=t2;
f_1248(t3,C_SCHEME_UNDEFINED);}}

/* k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1248,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[98],"translate-only"))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2973,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3127,a[2]=t7,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3127(t9,t5,C_retrieve2(lf[61],"c-files"));}}

/* loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3127(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3127,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3181,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g352353 */
t6=t3;
f_3135(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3179 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3127(t3,((C_word*)t0)[2],t2);}

/* g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3135(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3135,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3139,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:836: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t3,t2,C_retrieve2(lf[36],"object-extension"));}

/* k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(C_truep(C_retrieve2(lf[67],"cpp-mode"))?C_retrieve2(lf[30],"c++-compiler"):C_retrieve2(lf[29],"compiler"));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3166,a[2]=t1,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t6=((C_word*)t0)[2];
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5244,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t7,t6);}

/* f5244 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3164 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3170,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5239,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5239 in k3164 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3176 in k3164 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:842: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve2(lf[48],"compile-output-flag"),t1);}

/* k3168 in k3164 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3174,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:844: compiler-options */
f_3194(t2);}

/* k3172 in k3168 in k3164 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
t2=C_a_i_list(&a,5,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[217],t1);
/* csc.scm:838: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t2);}

/* k3152 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:837: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3140 in k3137 in g352 in loop345 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[66],"generated-object-files"));
t3=C_mutate(&lf[66] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3100,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[53],"generate-manifest"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:848: software-type */
((C_proc2)C_retrieve_symbol_proc(lf[216]))(2,*((C_word*)lf[216]+1),t4);}
else{
t4=t3;
f_3100(t4,C_SCHEME_FALSE);}}

/* k3123 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3100(t2,C_eqp(lf[215],t1));}

/* k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3100(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3100,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:849: pathname-replace-extension */
((C_proc4)C_retrieve_symbol_proc(lf[213]))(4,*((C_word*)lf[213]+1),t2,C_retrieve2(lf[95],"target-filename"),lf[214]);}
else{
t2=((C_word*)t0)[2];
f_2976(t2,C_SCHEME_UNDEFINED);}}

/* k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3106,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3118,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:850: pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[180]))(3,*((C_word*)lf[180]+1),t3,C_retrieve2(lf[95],"target-filename"));}

/* k3116 in k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[96],"verbose"))){
/* csc.scm:1098: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[153]+1)))(4,*((C_word*)lf[153]+1),t3,lf[212],t2);}
else{
t4=t3;
f_4203(2,t4,C_SCHEME_UNDEFINED);}}

/* k4201 in k3116 in k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4208,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1099: with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4207 in k4201 in k3116 in k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_cons(&a,2,lf[210],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,((C_word*)t0)[2],t3);
t5=C_a_i_cons(&a,2,lf[211],t4);
/* csc.scm:1099: ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t2,t5);}

/* k4214 in a4207 in k4201 in k3116 in k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1101: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),((C_word*)t0)[2],t1);}

/* k3104 in k3101 in k3098 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3106,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve2(lf[62],"rc-files"));
t3=C_mutate(&lf[62] /* (set! rc-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],C_retrieve2(lf[64],"generated-rc-files"));
t5=C_mutate(&lf[64] /* (set! generated-rc-files ...) */,t4);
t6=((C_word*)t0)[2];
f_2976(t6,t5);}

/* k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2976(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2976,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2979,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3044,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3044(t6,t2,C_retrieve2(lf[62],"rc-files"));}

/* loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3044(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3044,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3052,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3086,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g376377 */
t6=t3;
f_3052(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3084 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3044(t3,((C_word*)t0)[2],t2);}

/* g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3052(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3052,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3056,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:855: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[129]+1)))(5,*((C_word*)lf[129]+1),t3,t2,lf[209],C_retrieve2(lf[36],"object-extension"));}

/* k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3056,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3071,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3079,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5232,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}

/* f5232 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3077 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3083,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5227,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* f5227 in k3077 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5227(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3081 in k3077 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3083,2,t0,t1);}
t2=C_a_i_list(&a,3,C_retrieve2(lf[31],"rc-compiler"),((C_word*)t0)[3],t1);
/* csc.scm:857: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t2);}

/* k3069 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:856: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3057 in k3054 in g376 in loop369 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_retrieve2(lf[66],"generated-object-files"));
t3=C_mutate(&lf[66] /* (set! generated-object-files ...) */,t2);
t4=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[3])+1,t4);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2979,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2983,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3042,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:862: reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3040 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3042(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:862: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[65],"object-files"));}

/* k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2983,2,t0,t1);}
t2=C_mutate(&lf[65] /* (set! object-files ...) */,t1);
if(C_truep(C_retrieve2(lf[97],"keep-files"))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_1254(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2989,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3017,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_3017(t7,t3,C_retrieve2(lf[63],"generated-c-files"));}}

/* loop386 in k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3017(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3017,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[154],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3027,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g393394 */
t6=C_retrieve2(lf[154],"$delete-file");
f_4079(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3025 in loop386 in k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3017(t3,((C_word*)t0)[2],t2);}

/* k2987 in k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2989,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2994,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2994(t5,((C_word*)t0)[2],C_retrieve2(lf[64],"generated-rc-files"));}

/* loop399 in k2987 in k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_2994(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2994,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[154],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3004,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g406407 */
t6=C_retrieve2(lf[154],"$delete-file");
f_4079(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3002 in loop399 in k2987 in k2981 in k2977 in k2974 in k2971 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2994(t3,((C_word*)t0)[2],t2);}

/* k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
if(C_truep(C_retrieve2(lf[99],"compile-only"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1260,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_member(C_retrieve2(lf[95],"target-filename"),C_retrieve2(lf[60],"scheme-files")))){
t3=*((C_word*)lf[146]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1269,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t4,lf[208],t3);}
else{
t3=t2;
f_1260(2,t3,C_SCHEME_UNDEFINED);}}}

/* k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,C_retrieve2(lf[95],"target-filename"),((C_word*)t0)[2]);}

/* k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1275,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[207],((C_word*)t0)[2]);}

/* k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,C_retrieve2(lf[95],"target-filename"),((C_word*)t0)[2]);}

/* k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1278,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1281,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[206],((C_word*)t0)[2]);}

/* k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t2);}

/* k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1294,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[204],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[205],t1);}}

/* k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_retrieve2(lf[95],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5218,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5218 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1319 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1317,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:558: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),t4,C_retrieve2(lf[95],"target-filename"),lf[203]);}

/* k1315 in k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5213,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5213 in k1315 in k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k1311 in k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2]);}

/* k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1282 in k1279 in k1276 in k1273 in k1270 in k1267 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:553: command */
f_4063(((C_word*)t0)[2],t1);}

/* k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1260,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3254,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3522,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3561,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3563,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3569,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t9,t10,t11);}

/* a3568 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3569(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3569r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3569r(t0,t1,t2);}}

static void C_ccall f_3569r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(0)));}

/* a3562 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
/* csc.scm:881: static-extension-info */
f_3685(t1);}

/* k3559 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:880: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[65],"object-files"),t1);}

/* k3520 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3524,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3524(t5,((C_word*)t0)[2],t1);}

/* loop444 in k3520 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3524,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[24],"quotewrap");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3553,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5206,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t6,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* f5206 in loop444 in k3520 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3551 in loop444 in k3520 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3553,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop444457 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3524(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop444457 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3524(t6,((C_word*)t0)[3],t5);}}

/* k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3257,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[95],"target-filename");
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5201,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,t3);}

/* f5201 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5201(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3257,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3260,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[76],"deploy"))){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3420,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:885: pathname-strip-extension */
((C_proc3)C_retrieve_symbol_proc(lf[202]))(3,*((C_word*)lf[202]+1),t7,C_retrieve2(lf[95],"target-filename"));}
else{
t7=t6;
f_3260(2,t7,C_SCHEME_UNDEFINED);}}

/* k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3420,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3423,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[75],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3470,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:887: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),t5,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[4])[1],lf[201]);}
else{
t5=t3;
f_3423(2,t5,C_SCHEME_UNDEFINED);}}

/* k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3470,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3473,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3501,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}

/* k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3504,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[200],t1);}

/* k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3507,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3514,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3518,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:888: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[199]);}

/* k3516 in k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5196,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5196 in k3516 in k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3512 in k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3505 in k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3510,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2]);}

/* k3508 in k3505 in k3502 in k3499 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:888: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3473,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t2);}

/* k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3483,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[198],t1);}

/* k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3497,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:889: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t4,((C_word*)((C_word*)t0)[2])[1],lf[197]);}

/* k3495 in k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5191,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5191 in k3495 in k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3491 in k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3484 in k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3489,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2]);}

/* k3487 in k3484 in k3481 in k3478 in k3471 in k3468 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:889: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[75],"gui"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3460,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:894: pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[180]))(3,*((C_word*)lf[180]+1),t5,C_retrieve2(lf[95],"target-filename"));}
else{
/* csc.scm:895: pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[180]))(3,*((C_word*)lf[180]+1),t3,C_retrieve2(lf[95],"target-filename"));}}

/* k3458 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:894: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[2],lf[196],t1);}

/* k3448 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:891: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k3425 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=C_mutate(&lf[95] /* (set! target-filename ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_retrieve2(lf[95],"target-filename");
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5186,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5186 in k3425 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3429 in k3425 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:897: directory-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k3435 in k3429 in k3425 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3437,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_3260(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[96],"verbose"))){
/* csc.scm:899: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[153]+1)))(4,*((C_word*)lf[153]+1),t2,lf[194],((C_word*)((C_word*)t0)[2])[1]);}
else{
/* csc.scm:900: create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}}}

/* k3438 in k3435 in k3429 in k3425 in k3421 in k3418 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:900: create-directory */
((C_proc3)C_retrieve_symbol_proc(lf[193]))(3,*((C_word*)lf[193]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[25],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3263,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3384,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3388,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(C_truep(C_retrieve2(lf[67],"cpp-mode"))?C_retrieve2(lf[33],"c++-linker"):C_retrieve2(lf[32],"linker"));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3396,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t9=C_retrieve2(lf[95],"target-filename");
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5181,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t10,t9);}

/* f5181 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3414 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:907: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[2],C_retrieve2(lf[42],"link-output-flag"),t1);}

/* k3402 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:908: linker-options */
f_3782(t2);}

/* k3406 in k3402 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:909: linker-libraries */
f_3834(t2,C_a_i_list(&a,1,C_SCHEME_FALSE));}

/* k3410 in k3406 in k3402 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],t1);
/* csc.scm:905: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k3394 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:903: cons* */
((C_proc4)C_retrieve_symbol_proc(lf[141]))(4,*((C_word*)lf[141]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3386 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:902: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* k3382 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:901: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3337,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=C_i_not(C_retrieve2(lf[23],"cross-chicken"));
if(C_truep(t4)){
t5=t3;
f_3337(t5,t4);}
else{
t5=C_retrieve2(lf[22],"host-mode");
t6=t3;
f_3337(t6,C_retrieve2(lf[22],"host-mode"));}}
else{
t4=t3;
f_3337(t4,C_SCHEME_FALSE);}}

/* k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3337(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3337,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3356,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3360,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=lf[191];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[77],"deployed"))){
/* csc.scm:917: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t6,lf[192],t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3374,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:919: lib-path */
f_3575(t7);}}
else{
t2=((C_word*)t0)[2];
f_3266(2,t2,C_SCHEME_UNDEFINED);}}

/* k3372 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:918: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3362 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5176,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5176 in k3362 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3358 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:912: string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[129]+1)))(6,*((C_word*)lf[129]+1),((C_word*)t0)[3],lf[189],t1,lf[190],((C_word*)((C_word*)t0)[2])[1]);}

/* k3354 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:911: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3340,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[75],"gui"))?C_i_not(C_retrieve2(lf[76],"deploy")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=((C_word*)((C_word*)t0)[3])[1];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4102,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3266(2,t4,t3);}}

/* k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4105,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[188],t1);}

/* k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4105,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4108,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4129,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5171,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t4,((C_word*)t0)[2]);}

/* f5171 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4127 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4108(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4108,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4111,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4111,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4114,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4121,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4125,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1061: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t4,C_retrieve2(lf[27],"home"),lf[187]);}

/* k4123 in k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5166,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t2,t1);}

/* f5166 in k4123 in k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k4119 in k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4121(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4112 in k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4117,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2]);}

/* k4115 in k4112 in k4109 in k4106 in k4103 in k4100 in k3338 in k3335 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1058: command */
f_4063(((C_word*)t0)[2],t1);}

/* k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3269,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3301,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[76],"deploy"))){
t4=C_retrieve2(lf[102],"static");
if(C_truep(t4)){
t5=t3;
f_3301(t5,C_i_not(t4));}
else{
t5=C_retrieve2(lf[103],"static-libs");
t6=t3;
f_3301(t6,C_i_not(t5));}}
else{
t4=t3;
f_3301(t4,C_SCHEME_FALSE);}}

/* k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3301(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3301,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t4=C_retrieve2(lf[75],"gui");
if(C_truep(t4)){
/* csc.scm:928: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t3,((C_word*)((C_word*)t0)[3])[1],lf[186]);}
else{
t5=t3;
f_3321(2,t5,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t4=t3;
f_3321(2,t4,((C_word*)((C_word*)t0)[3])[1]);}}
else{
t2=((C_word*)t0)[2];
f_3269(t2,C_SCHEME_UNDEFINED);}}

/* k3319 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3629,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3636,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}

/* k3599 in k3319 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_i_string_equal_p(t1,lf[185]))){
/* csc.scm:951: lib-path */
f_3575(((C_word*)t0)[2]);}
else{
if(C_truep(C_retrieve2(lf[23],"cross-chicken"))){
t2=C_retrieve2(lf[22],"host-mode");
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* csc.scm:951: lib-path */
f_3575(((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[2];
f_3636(2,t4,t3);}}
else{
/* csc.scm:951: lib-path */
f_3575(((C_word*)t0)[2]);}}}

/* k3634 in k3319 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[7],"osx"))){
/* csc.scm:954: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1,lf[181],lf[182]);}
else{
if(C_truep(C_retrieve2(lf[8],"win"))){
/* csc.scm:954: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1,lf[181],lf[183]);}
else{
/* csc.scm:954: make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[112]))(5,*((C_word*)lf[112]+1),((C_word*)t0)[2],t1,lf[181],lf[184]);}}}

/* k3627 in k3319 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:960: copy-files */
f_3645(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[7],"osx"))?C_retrieve2(lf[75],"gui"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:932: pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[180]))(3,*((C_word*)lf[180]+1),t3,C_retrieve2(lf[95],"target-filename"));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
f_3269(t4,t3);}}

/* k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3317,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[3])[1];
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4135,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1064: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t3,t2,lf[179]);}

/* k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4138,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1065: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],lf[178]);}

/* k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4138,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4141,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csc.scm:1066: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],lf[177]);}

/* k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4141,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4144,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1067: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,t1,lf[176]);}

/* k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4144,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4147,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4190,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1068: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t3,t1);}

/* k4188 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4190,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_4147(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4197,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:1070: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,C_retrieve2(lf[27],"home"),lf[175]);}}

/* k4195 in k4188 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1069: copy-files */
f_3645(((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4150,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csc.scm:1072: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,((C_word*)t0)[2],lf[174]);}

/* k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4156,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csc.scm:1073: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[173]))(3,*((C_word*)lf[173]+1),t3,t1);}

/* k4154 in k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4156,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
f_3269(t2,((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4159,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[96],"verbose"))){
/* csc.scm:1074: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[153]+1)))(4,*((C_word*)lf[153]+1),t2,lf[172],((C_word*)t0)[2]);}
else{
t3=t2;
f_4159(2,t3,C_SCHEME_UNDEFINED);}}}

/* k4157 in k4154 in k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1075: with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[171]))(4,*((C_word*)lf[171]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* a4163 in k4157 in k4154 in k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=*((C_word*)lf[153]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4172,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_cons(&a,2,lf[168],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,((C_word*)t0)[2],t4);
t6=C_a_i_cons(&a,2,lf[169],t5);
/* csc.scm:1075: ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[170]))(3,*((C_word*)lf[170]+1),t3,t6);}

/* k4170 in a4163 in k4157 in k4154 in k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g644645 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k4151 in k4148 in k4145 in k4142 in k4139 in k4136 in k4133 in k3315 in k3302 in k3299 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_3269(t2,((C_word*)t0)[2]);}

/* k3267 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3269,NULL,2,t0,t1);}
if(C_truep(C_retrieve2(lf[97],"keep-files"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3277,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3277(t5,((C_word*)t0)[2],C_retrieve2(lf[66],"generated-object-files"));}}

/* loop511 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3277(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[154],"$delete-file");
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g518519 */
t6=C_retrieve2(lf[154],"$delete-file");
f_4079(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3285 in loop511 in k3267 in k3264 in k3261 in k3258 in k3255 in k3252 in k1258 in k1252 in k1246 in k1243 in k1240 in k1237 in k1233 in loop in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3277(t3,((C_word*)t0)[2],t2);}

/* use-private-repository in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static C_word C_fcall f_1207(C_word *a){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_stack_check;
t1=C_a_i_cons(&a,2,lf[166],C_retrieve2(lf[88],"compile-options"));
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
if(C_truep(C_retrieve2(lf[7],"osx"))){
t3=C_a_i_cons(&a,2,lf[167],C_retrieve2(lf[94],"link-options"));
t4=C_mutate(&lf[94] /* (set! link-options ...) */,t3);
return(t4);}
else{
t3=C_SCHEME_UNDEFINED;
return(t3);}}

/* shared-build in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1181(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1181,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1186,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:500: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),t3,lf[164],lf[165],C_retrieve2(lf[85],"translate-options"));}

/* k1184 in shared-build in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1186,2,t0,t1);}
t2=C_mutate(&lf[85] /* (set! translate-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1190,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:501: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),t3,C_retrieve2(lf[51],"pic-options"),lf[163],C_retrieve2(lf[88],"compile-options"));}

/* k1188 in k1184 in shared-build in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1190,2,t0,t1);}
t2=C_mutate(&lf[88] /* (set! compile-options ...) */,t1);
t3=(C_truep(C_retrieve2(lf[7],"osx"))?(C_truep(((C_word*)t0)[3])?C_a_i_cons(&a,2,lf[159],C_retrieve2(lf[94],"link-options")):C_a_i_cons(&a,2,lf[160],C_retrieve2(lf[94],"link-options"))):(C_truep(C_retrieve2(lf[5],"msvc"))?C_a_i_cons(&a,2,lf[161],C_retrieve2(lf[94],"link-options")):C_a_i_cons(&a,2,lf[162],C_retrieve2(lf[94],"link-options"))));
t4=C_mutate(&lf[94] /* (set! link-options ...) */,t3);
t5=lf[101] /* shared */ =C_SCHEME_TRUE;;
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* check in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1142(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1142,NULL,4,t1,t2,t3,t4);}
t5=C_i_length(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1160,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
if(C_truep(C_i_greater_or_equalp(t5,C_fix(1)))){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* csc.scm:497: quit */
f_835(t1,lf[158],C_a_i_list(&a,1,t2));}}
else{
t7=C_i_cdr(t4);
if(C_truep(C_i_nullp(t7))){
t8=t6;
f_1160(2,t8,C_i_car(t4));}
else{
/* ##sys#error */
t8=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t4);}}}

/* k1158 in check in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1160,2,t0,t1);}
if(C_truep(C_i_greater_or_equalp(((C_word*)t0)[4],t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm:497: quit */
f_835(((C_word*)t0)[3],lf[158],C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* t-options in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_1135(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1135,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1140,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:493: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[109]+1)))(4,*((C_word*)lf[109]+1),t3,C_retrieve2(lf[85],"translate-options"),t2);}

/* k1138 in t-options in k4242 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_1140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[85] /* (set! translate-options ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4232 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[157]))(2,*((C_word*)lf[157]+1),t3);}

/* k4238 in k4232 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k4235 in k4232 in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* $delete-file in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4079,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4083,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[96],"verbose"))){
/* csc.scm:1053: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[153]+1)))(4,*((C_word*)lf[153]+1),t3,lf[156],t2);}
else{
if(C_truep(C_retrieve2(lf[74],"dry-run"))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm:1054: delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),t1,t2);}}}

/* k4081 in $delete-file in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[74],"dry-run"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csc.scm:1054: delete-file */
((C_proc3)C_retrieve_symbol_proc(lf[155]))(3,*((C_word*)lf[155]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_4063(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4063,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4018,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[96],"verbose"))){
/* csc.scm:1036: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[153]+1)))(3,*((C_word*)lf[153]+1),t3,t2);}
else{
t4=t3;
f_4018(2,t4,C_SCHEME_UNDEFINED);}}

/* k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4021,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* csc.scm:1038: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[129]+1)))(5,*((C_word*)lf[129]+1),t2,lf[151],((C_word*)t0)[2],lf[152]);}
else{
t3=t2;
f_4021(2,t3,((C_word*)t0)[2]);}}

/* k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4024,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[74],"dry-run"))){
t3=t2;
f_4024(2,t3,C_fix(0));}
else{
/* csc.scm:1040: system */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),t2,t1);}}

/* k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4027,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_zerop(t1))){
t3=t2;
f_4027(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[146]+1);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4040,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t4,lf[149],t3);}}

/* k4038 in k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4043,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4041 in k4038 in k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4043,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4046,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[147],((C_word*)t0)[3]);}

/* k4044 in k4041 in k4038 in k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4049,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4047 in k4044 in k4041 in k4038 in k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k4025 in k4022 in k4019 in k4016 in command in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(C_i_zerop(((C_word*)t0)[3]))){
t2=lf[145] /* last-exit-code */ =C_fix(0);;
t3=C_retrieve2(lf[145],"last-exit-code");
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm:1049: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_retrieve2(lf[145],"last-exit-code"));}}
else{
t2=lf[145] /* last-exit-code */ =C_fix(1);;
t3=C_retrieve2(lf[145],"last-exit-code");
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* csc.scm:1049: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_retrieve2(lf[145],"last-exit-code"));}}}

/* quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3977(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3977,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3984,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4007,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1026: string-any */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t3,t4,t2);}

/* a4006 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4007,3,t0,t1,t2);}
t3=*((C_word*)lf[144]+1);
/* g603604 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(34),t2);}

/* k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3984,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3990,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3995,tmp=(C_word)a,a+=2,tmp);
/* csc.scm:1027: string-any */
((C_proc4)C_retrieve_symbol_proc(lf[143]))(4,*((C_word*)lf[143]+1),t2,t3,((C_word*)t0)[3]);}}

/* a3994 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3995,3,t0,t1,t2);}
t3=C_u_i_char_whitespacep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_i_memq(t2,lf[134])));}

/* k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3990,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3910,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3924,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* string->list */
t9=C_retrieve(lf[142]);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}}

/* k3926 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3930,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3930(t5,((C_word*)t0)[2],t1);}

/* fold in k3926 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3930(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3930,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_memq(t3,lf[134]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3953,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(t2);
/* csc.scm:1017: fold */
t9=t4;
t10=t5;
t1=t9;
t2=t10;
goto loop;}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3960,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_u_i_char_whitespacep(t3))){
t5=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t6=t4;
f_3960(t6,t5);}
else{
t5=t4;
f_3960(t5,C_SCHEME_UNDEFINED);}}}}

/* k3958 in fold in k3926 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3960,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3967,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* csc.scm:1020: fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3930(t4,t2,t3);}

/* k3965 in k3958 in fold in k3926 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3967,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3951 in fold in k3926 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1017: cons* */
((C_proc5)C_retrieve_symbol_proc(lf[141]))(5,*((C_word*)lf[141]+1),((C_word*)t0)[3],C_make_character(92),((C_word*)t0)[2],t1);}

/* k3922 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* list->string */
t2=C_retrieve(lf[140]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3908 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3910,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3920,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csc.scm:1022: string-translate* */
((C_proc4)C_retrieve_symbol_proc(lf[138]))(4,*((C_word*)lf[138]+1),t2,t1,lf[139]);}
else{
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3918 in k3908 in k3988 in k3982 in quote-option in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:1022: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[129]+1)))(5,*((C_word*)lf[129]+1),((C_word*)t0)[2],lf[136],t1,lf[137]);}

/* linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3834(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3834,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3838,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_3838(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_3838(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3838,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3845,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3849,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3874,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3880,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t4,t5);}
else{
t4=t3;
f_3849(2,t4,C_SCHEME_END_OF_LIST);}}

/* a3879 in k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3880(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3880r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3880r(t0,t1,t2);}}

static void C_ccall f_3880r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(0)));}

/* a3873 in k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3874,2,t0,t1);}
/* csc.scm:997: static-extension-info */
f_3685(t1);}

/* k3847 in k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3853,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_retrieve2(lf[102],"static");
if(C_truep(t3)){
t4=t2;
f_3853(t4,(C_truep(t3)?C_retrieve2(lf[83],"library-files"):C_retrieve2(lf[84],"shared-library-files")));}
else{
t4=C_retrieve2(lf[103],"static-libs");
t5=t2;
f_3853(t5,(C_truep(t4)?C_retrieve2(lf[83],"library-files"):C_retrieve2(lf[84],"shared-library-files")));}}

/* k3851 in k3847 in k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3853,NULL,2,t0,t1);}
t2=C_retrieve2(lf[102],"static");
if(C_truep(t2)){
t3=(C_truep(t2)?C_a_i_list(&a,1,C_retrieve2(lf[79],"extra-libraries")):C_a_i_list(&a,1,C_retrieve2(lf[80],"extra-shared-libraries")));
/* csc.scm:996: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t3=C_retrieve2(lf[103],"static-libs");
t4=(C_truep(t3)?C_a_i_list(&a,1,C_retrieve2(lf[79],"extra-libraries")):C_a_i_list(&a,1,C_retrieve2(lf[80],"extra-shared-libraries")));
/* csc.scm:996: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,t4);}}

/* k3843 in k3836 in linker-libraries in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:995: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3782(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3782,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3790,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3816,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3820,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3822,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3828,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}

/* a3827 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_3828r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3828r(t0,t1,t2);}}

static void C_ccall f_3828r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(1)));}

/* a3821 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3822,2,t0,t1);}
/* csc.scm:991: static-extension-info */
f_3685(t1);}

/* k3818 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:990: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[92],"linking-optimization-options"),C_retrieve2(lf[94],"link-options"),t1);}

/* k3814 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:989: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* k3788 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3797,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_retrieve2(lf[102],"static"))){
t3=C_retrieve2(lf[3],"mingw");
if(C_truep(C_retrieve2(lf[3],"mingw"))){
t4=t2;
f_3797(t4,C_SCHEME_FALSE);}
else{
t4=C_retrieve2(lf[5],"msvc");
t5=t2;
f_3797(t5,(C_truep(C_retrieve2(lf[5],"msvc"))?C_SCHEME_FALSE:C_i_not(C_retrieve2(lf[7],"osx"))));}}
else{
t3=t2;
f_3797(t3,C_SCHEME_FALSE);}}

/* k3795 in k3788 in linker-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csc.scm:988: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[130]);}
else{
/* csc.scm:988: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[129]+1)))(4,*((C_word*)lf[129]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[131]);}}

/* static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3685(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3685,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3689,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:972: repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[127]))(2,*((C_word*)lf[127]+1),t2);}

/* k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(C_truep(t1)?C_i_pairp(C_retrieve2(lf[104],"static-extensions")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_3700(t6,((C_word*)t0)[2],C_retrieve2(lf[104],"static-extensions"),C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
/* csc.scm:985: values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}}

/* loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3700,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3714,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csc.scm:976: reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t5,t3);}
else{
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t6=C_i_car(t2);
/* csc.scm:977: extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[126]))(3,*((C_word*)lf[126]+1),t5,t6);}}

/* k3719 in loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3721,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[124],t1);
t3=C_i_assq(lf[125],t1);
t4=C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3741,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cadr(t2);
/* csc.scm:982: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t6,((C_word*)t0)[2],t7);}
else{
t6=t5;
f_3741(t6,((C_word*)t0)[3]);}}
else{
t2=C_i_cdr(((C_word*)t0)[7]);
/* csc.scm:984: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3700(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3],((C_word*)t0)[6]);}}

/* k3757 in k3719 in loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=((C_word*)t0)[3];
f_3741(t2,C_a_i_cons(&a,2,t1,((C_word*)t0)[2]));}

/* k3739 in k3719 in loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3741(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3741,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=C_i_cadr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,t2,((C_word*)t0)[5]);
/* csc.scm:981: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3700(t4,((C_word*)t0)[3],((C_word*)t0)[2],t1,t3);}
else{
t2=((C_word*)t0)[5];
/* csc.scm:981: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3700(t3,((C_word*)t0)[3],((C_word*)t0)[2],t1,t2);}}

/* k3712 in loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3718,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csc.scm:976: reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t2,((C_word*)t0)[2]);}

/* k3716 in k3712 in loop in k3687 in static-extension-info in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:976: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3645(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3645,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3653,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[121]))(2,*((C_word*)lf[121]+1),t4);}

/* k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[52],"windows-shell"))){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[119],t1);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),t2,lf[120],t1);}}

/* k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3659,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3659,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3662,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3679,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5143,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5143 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3677 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3662,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3665,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[118]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k3663 in k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3665,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3668,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3675,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=((C_word*)t0)[2];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5138,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t5,t4);}

/* f5138 in k3663 in k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f5138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k3673 in k3663 in k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[117]+1)))(4,*((C_word*)lf[117]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3668,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3671,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[116]))(3,*((C_word*)lf[116]+1),t2,((C_word*)t0)[2]);}

/* k3669 in k3666 in k3663 in k3660 in k3657 in k3654 in k3651 in copy-files in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:963: command */
f_4063(((C_word*)t0)[2],t1);}

/* lib-path in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3575(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3575,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3583,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[8],"win"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}
else{
if(C_truep(C_retrieve2(lf[22],"host-mode"))){
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_LIB_HOME),C_fix(0));}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_TARGET_RUN_LIB_HOME),C_fix(0));}}}

/* k3581 in lib-path in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3583,2,t0,t1);}
t2=((C_word*)t0)[2];
if(C_truep(C_retrieve2(lf[19],"chicken-prefix"))){
t3=C_a_i_list(&a,2,C_retrieve2(lf[19],"chicken-prefix"),lf[111]);
/* csc.scm:86: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[112]))(4,*((C_word*)lf[112]+1),t2,t3,lf[113]);}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* compiler-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3194(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3194,NULL,1,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3202,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3206,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=C_retrieve2(lf[102],"static");
t9=(C_truep(t8)?t8:C_retrieve2(lf[103],"static-libs"));
if(C_truep(t9)){
/* csc.scm:870: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[91],"compilation-optimization-options"),C_retrieve2(lf[88],"compile-options"));}
else{
/* csc.scm:870: append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[109]+1)))(5,*((C_word*)lf[109]+1),t7,C_SCHEME_END_OF_LIST,C_retrieve2(lf[91],"compilation-optimization-options"),C_retrieve2(lf[88],"compile-options"));}}

/* k3204 in compiler-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3208,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3208(t5,((C_word*)t0)[2],t1);}

/* loop417 in k3204 in compiler-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_3208(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3208,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve2(lf[108],"quote-option");
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3237,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g433434 */
t6=C_retrieve2(lf[108],"quote-option");
f_3977(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3235 in loop417 in k3204 in compiler-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3237,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop417430 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3208(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop417430 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3208(t6,((C_word*)t0)[3],t5);}}

/* k3200 in compiler-options in k1028 in k1020 in k1012 in k1005 in k4298 in k997 in k993 in k962 in k957 in k952 in k948 in k942 in k915 in k911 in k907 in k903 in k899 in k895 in k891 in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_3202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:868: string-intersperse */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* quotewrap in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_881,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_889,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csc.scm:90: normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[26]))(3,*((C_word*)lf[26]+1),t3,t2);}

/* k887 in quotewrap in k856 in k852 in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:90: qs */
((C_proc3)C_retrieve_symbol_proc(lf[25]))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* quit in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_fcall f_835(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_835,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_846,a[2]=t3,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* csc.scm:76: current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t5);}

/* k844 in quit in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* ##sys#peek-c-string */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k848 in k844 in quit in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:76: fprintf */
((C_proc7)C_retrieve_symbol_proc(lf[15]))(7,*((C_word*)lf[15]+1),((C_word*)t0)[5],((C_word*)t0)[4],lf[16],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k837 in quit in k4456 in k4460 in k4464 in k4468 in k4472 in k807 in k804 in k801 in k798 in k795 in k792 in k789 in k786 in k783 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csc.scm:77: exit */
((C_proc3)C_retrieve_symbol_proc(lf[14]))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],C_fix(64));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[448] = {
{"toplevel:csc_scm",(void*)C_toplevel},
{"f_785:csc_scm",(void*)f_785},
{"f_788:csc_scm",(void*)f_788},
{"f_791:csc_scm",(void*)f_791},
{"f_794:csc_scm",(void*)f_794},
{"f_797:csc_scm",(void*)f_797},
{"f_800:csc_scm",(void*)f_800},
{"f_803:csc_scm",(void*)f_803},
{"f_806:csc_scm",(void*)f_806},
{"f_809:csc_scm",(void*)f_809},
{"f_4474:csc_scm",(void*)f_4474},
{"f_4470:csc_scm",(void*)f_4470},
{"f_4466:csc_scm",(void*)f_4466},
{"f_4462:csc_scm",(void*)f_4462},
{"f_4458:csc_scm",(void*)f_4458},
{"f_854:csc_scm",(void*)f_854},
{"f_858:csc_scm",(void*)f_858},
{"f_4448:csc_scm",(void*)f_4448},
{"f5673:csc_scm",(void*)f5673},
{"f_4444:csc_scm",(void*)f_4444},
{"f5326:csc_scm",(void*)f5326},
{"f_893:csc_scm",(void*)f_893},
{"f_4436:csc_scm",(void*)f_4436},
{"f_4440:csc_scm",(void*)f_4440},
{"f_4432:csc_scm",(void*)f_4432},
{"f5669:csc_scm",(void*)f5669},
{"f_4428:csc_scm",(void*)f_4428},
{"f5321:csc_scm",(void*)f5321},
{"f_897:csc_scm",(void*)f_897},
{"f_4418:csc_scm",(void*)f_4418},
{"f5316:csc_scm",(void*)f5316},
{"f_901:csc_scm",(void*)f_901},
{"f_4408:csc_scm",(void*)f_4408},
{"f5311:csc_scm",(void*)f5311},
{"f_905:csc_scm",(void*)f_905},
{"f_4398:csc_scm",(void*)f_4398},
{"f5306:csc_scm",(void*)f5306},
{"f_909:csc_scm",(void*)f_909},
{"f5301:csc_scm",(void*)f5301},
{"f_4385:csc_scm",(void*)f_4385},
{"f5296:csc_scm",(void*)f5296},
{"f_913:csc_scm",(void*)f_913},
{"f5291:csc_scm",(void*)f5291},
{"f_4372:csc_scm",(void*)f_4372},
{"f5286:csc_scm",(void*)f5286},
{"f_917:csc_scm",(void*)f_917},
{"f_944:csc_scm",(void*)f_944},
{"f_950:csc_scm",(void*)f_950},
{"f_4355:csc_scm",(void*)f_4355},
{"f_954:csc_scm",(void*)f_954},
{"f_4345:csc_scm",(void*)f_4345},
{"f_959:csc_scm",(void*)f_959},
{"f_4341:csc_scm",(void*)f_4341},
{"f_964:csc_scm",(void*)f_964},
{"f_995:csc_scm",(void*)f_995},
{"f_999:csc_scm",(void*)f_999},
{"f_4312:csc_scm",(void*)f_4312},
{"f_4316:csc_scm",(void*)f_4316},
{"f_4308:csc_scm",(void*)f_4308},
{"f5665:csc_scm",(void*)f5665},
{"f_4304:csc_scm",(void*)f_4304},
{"f5281:csc_scm",(void*)f5281},
{"f_4300:csc_scm",(void*)f_4300},
{"f_4296:csc_scm",(void*)f_4296},
{"f_1007:csc_scm",(void*)f_1007},
{"f_4283:csc_scm",(void*)f_4283},
{"f_1014:csc_scm",(void*)f_1014},
{"f_4272:csc_scm",(void*)f_4272},
{"f_1022:csc_scm",(void*)f_1022},
{"f_4259:csc_scm",(void*)f_4259},
{"f_1030:csc_scm",(void*)f_1030},
{"f_4252:csc_scm",(void*)f_4252},
{"f_4248:csc_scm",(void*)f_4248},
{"f_4244:csc_scm",(void*)f_4244},
{"f_1224:csc_scm",(void*)f_1224},
{"f_1461:csc_scm",(void*)f_1461},
{"f_1836:csc_scm",(void*)f_1836},
{"f_2053:csc_scm",(void*)f_2053},
{"f_2289:csc_scm",(void*)f_2289},
{"f_2292:csc_scm",(void*)f_2292},
{"f_2727:csc_scm",(void*)f_2727},
{"f_2348:csc_scm",(void*)f_2348},
{"f_2357:csc_scm",(void*)f_2357},
{"f_2568:csc_scm",(void*)f_2568},
{"f_2690:csc_scm",(void*)f_2690},
{"f_2696:csc_scm",(void*)f_2696},
{"f_2579:csc_scm",(void*)f_2579},
{"f_2590:csc_scm",(void*)f_2590},
{"f_2680:csc_scm",(void*)f_2680},
{"f_2672:csc_scm",(void*)f_2672},
{"f_2655:csc_scm",(void*)f_2655},
{"f_2631:csc_scm",(void*)f_2631},
{"f_2636:csc_scm",(void*)f_2636},
{"f_2618:csc_scm",(void*)f_2618},
{"f_2604:csc_scm",(void*)f_2604},
{"f_2573:csc_scm",(void*)f_2573},
{"f_2538:csc_scm",(void*)f_2538},
{"f_2435:csc_scm",(void*)f_2435},
{"f_2521:csc_scm",(void*)f_2521},
{"f_2517:csc_scm",(void*)f_2517},
{"f_2468:csc_scm",(void*)f_2468},
{"f_2506:csc_scm",(void*)f_2506},
{"f_2466:csc_scm",(void*)f_2466},
{"f_2462:csc_scm",(void*)f_2462},
{"f_2439:csc_scm",(void*)f_2439},
{"f_2425:csc_scm",(void*)f_2425},
{"f_2412:csc_scm",(void*)f_2412},
{"f_2395:csc_scm",(void*)f_2395},
{"f_2381:csc_scm",(void*)f_2381},
{"f_2367:csc_scm",(void*)f_2367},
{"f_2329:csc_scm",(void*)f_2329},
{"f_2335:csc_scm",(void*)f_2335},
{"f_2338:csc_scm",(void*)f_2338},
{"f_2299:csc_scm",(void*)f_2299},
{"f_2282:csc_scm",(void*)f_2282},
{"f_2286:csc_scm",(void*)f_2286},
{"f_2230:csc_scm",(void*)f_2230},
{"f_2266:csc_scm",(void*)f_2266},
{"f_2256:csc_scm",(void*)f_2256},
{"f_2244:csc_scm",(void*)f_2244},
{"f_2205:csc_scm",(void*)f_2205},
{"f_2217:csc_scm",(void*)f_2217},
{"f_2209:csc_scm",(void*)f_2209},
{"f_2192:csc_scm",(void*)f_2192},
{"f_2166:csc_scm",(void*)f_2166},
{"f_2178:csc_scm",(void*)f_2178},
{"f_2170:csc_scm",(void*)f_2170},
{"f_2145:csc_scm",(void*)f_2145},
{"f_2149:csc_scm",(void*)f_2149},
{"f_2128:csc_scm",(void*)f_2128},
{"f_2111:csc_scm",(void*)f_2111},
{"f_2094:csc_scm",(void*)f_2094},
{"f_2077:csc_scm",(void*)f_2077},
{"f_2036:csc_scm",(void*)f_2036},
{"f_2026:csc_scm",(void*)f_2026},
{"f_2016:csc_scm",(void*)f_2016},
{"f_1992:csc_scm",(void*)f_1992},
{"f_2006:csc_scm",(void*)f_2006},
{"f_2002:csc_scm",(void*)f_2002},
{"f_1982:csc_scm",(void*)f_1982},
{"f_1972:csc_scm",(void*)f_1972},
{"f_1962:csc_scm",(void*)f_1962},
{"f_1952:csc_scm",(void*)f_1952},
{"f_1942:csc_scm",(void*)f_1942},
{"f_1921:csc_scm",(void*)f_1921},
{"f_1897:csc_scm",(void*)f_1897},
{"f_1908:csc_scm",(void*)f_1908},
{"f_1873:csc_scm",(void*)f_1873},
{"f_1869:csc_scm",(void*)f_1869},
{"f_1865:csc_scm",(void*)f_1865},
{"f_1858:csc_scm",(void*)f_1858},
{"f_1788:csc_scm",(void*)f_1788},
{"f_1792:csc_scm",(void*)f_1792},
{"f_1795:csc_scm",(void*)f_1795},
{"f_1756:csc_scm",(void*)f_1756},
{"f_1760:csc_scm",(void*)f_1760},
{"f_1763:csc_scm",(void*)f_1763},
{"f_1653:csc_scm",(void*)f_1653},
{"f_1638:csc_scm",(void*)f_1638},
{"f_1644:csc_scm",(void*)f_1644},
{"f_1615:csc_scm",(void*)f_1615},
{"f_1603:csc_scm",(void*)f_1603},
{"f_1591:csc_scm",(void*)f_1591},
{"f_1579:csc_scm",(void*)f_1579},
{"f_1553:csc_scm",(void*)f_1553},
{"f_1542:csc_scm",(void*)f_1542},
{"f_1511:csc_scm",(void*)f_1511},
{"f_1504:csc_scm",(void*)f_1504},
{"f_1495:csc_scm",(void*)f_1495},
{"f_1488:csc_scm",(void*)f_1488},
{"f_1095:csc_scm",(void*)f_1095},
{"f_1102:csc_scm",(void*)f_1102},
{"f_1476:csc_scm",(void*)f_1476},
{"f_1464:csc_scm",(void*)f_1464},
{"f_1235:csc_scm",(void*)f_1235},
{"f_1078:csc_scm",(void*)f_1078},
{"f_1044:csc_scm",(void*)f_1044},
{"f_1062:csc_scm",(void*)f_1062},
{"f_1052:csc_scm",(void*)f_1052},
{"f_1048:csc_scm",(void*)f_1048},
{"f_1239:csc_scm",(void*)f_1239},
{"f_1448:csc_scm",(void*)f_1448},
{"f_1415:csc_scm",(void*)f_1415},
{"f_1441:csc_scm",(void*)f_1441},
{"f_1418:csc_scm",(void*)f_1418},
{"f5272:csc_scm",(void*)f5272},
{"f_1434:csc_scm",(void*)f_1434},
{"f_1421:csc_scm",(void*)f_1421},
{"f_1424:csc_scm",(void*)f_1424},
{"f_1242:csc_scm",(void*)f_1242},
{"f_1378:csc_scm",(void*)f_1378},
{"f_1388:csc_scm",(void*)f_1388},
{"f_1381:csc_scm",(void*)f_1381},
{"f_2823:csc_scm",(void*)f_2823},
{"f_2835:csc_scm",(void*)f_2835},
{"f5266:csc_scm",(void*)f5266},
{"f_2866:csc_scm",(void*)f_2866},
{"f5261:csc_scm",(void*)f5261},
{"f_2935:csc_scm",(void*)f_2935},
{"f_2874:csc_scm",(void*)f_2874},
{"f_2882:csc_scm",(void*)f_2882},
{"f_2884:csc_scm",(void*)f_2884},
{"f_2913:csc_scm",(void*)f_2913},
{"f_2878:csc_scm",(void*)f_2878},
{"f_2870:csc_scm",(void*)f_2870},
{"f_2862:csc_scm",(void*)f_2862},
{"f_2858:csc_scm",(void*)f_2858},
{"f_2838:csc_scm",(void*)f_2838},
{"f_2842:csc_scm",(void*)f_2842},
{"f_2846:csc_scm",(void*)f_2846},
{"f_2792:csc_scm",(void*)f_2792},
{"f_2800:csc_scm",(void*)f_2800},
{"f_2810:csc_scm",(void*)f_2810},
{"f_1340:csc_scm",(void*)f_1340},
{"f_1343:csc_scm",(void*)f_1343},
{"f_1350:csc_scm",(void*)f_1350},
{"f_1245:csc_scm",(void*)f_1245},
{"f_1248:csc_scm",(void*)f_1248},
{"f_3127:csc_scm",(void*)f_3127},
{"f_3181:csc_scm",(void*)f_3181},
{"f_3135:csc_scm",(void*)f_3135},
{"f_3139:csc_scm",(void*)f_3139},
{"f5244:csc_scm",(void*)f5244},
{"f_3166:csc_scm",(void*)f_3166},
{"f5239:csc_scm",(void*)f5239},
{"f_3178:csc_scm",(void*)f_3178},
{"f_3170:csc_scm",(void*)f_3170},
{"f_3174:csc_scm",(void*)f_3174},
{"f_3154:csc_scm",(void*)f_3154},
{"f_3142:csc_scm",(void*)f_3142},
{"f_2973:csc_scm",(void*)f_2973},
{"f_3125:csc_scm",(void*)f_3125},
{"f_3100:csc_scm",(void*)f_3100},
{"f_3103:csc_scm",(void*)f_3103},
{"f_3118:csc_scm",(void*)f_3118},
{"f_4203:csc_scm",(void*)f_4203},
{"f_4208:csc_scm",(void*)f_4208},
{"f_4216:csc_scm",(void*)f_4216},
{"f_3106:csc_scm",(void*)f_3106},
{"f_2976:csc_scm",(void*)f_2976},
{"f_3044:csc_scm",(void*)f_3044},
{"f_3086:csc_scm",(void*)f_3086},
{"f_3052:csc_scm",(void*)f_3052},
{"f_3056:csc_scm",(void*)f_3056},
{"f5232:csc_scm",(void*)f5232},
{"f_3079:csc_scm",(void*)f_3079},
{"f5227:csc_scm",(void*)f5227},
{"f_3083:csc_scm",(void*)f_3083},
{"f_3071:csc_scm",(void*)f_3071},
{"f_3059:csc_scm",(void*)f_3059},
{"f_2979:csc_scm",(void*)f_2979},
{"f_3042:csc_scm",(void*)f_3042},
{"f_2983:csc_scm",(void*)f_2983},
{"f_3017:csc_scm",(void*)f_3017},
{"f_3027:csc_scm",(void*)f_3027},
{"f_2989:csc_scm",(void*)f_2989},
{"f_2994:csc_scm",(void*)f_2994},
{"f_3004:csc_scm",(void*)f_3004},
{"f_1254:csc_scm",(void*)f_1254},
{"f_1269:csc_scm",(void*)f_1269},
{"f_1272:csc_scm",(void*)f_1272},
{"f_1275:csc_scm",(void*)f_1275},
{"f_1278:csc_scm",(void*)f_1278},
{"f_1281:csc_scm",(void*)f_1281},
{"f_1284:csc_scm",(void*)f_1284},
{"f_1291:csc_scm",(void*)f_1291},
{"f_1294:csc_scm",(void*)f_1294},
{"f_1297:csc_scm",(void*)f_1297},
{"f5218:csc_scm",(void*)f5218},
{"f_1321:csc_scm",(void*)f_1321},
{"f_1300:csc_scm",(void*)f_1300},
{"f_1303:csc_scm",(void*)f_1303},
{"f_1317:csc_scm",(void*)f_1317},
{"f5213:csc_scm",(void*)f5213},
{"f_1313:csc_scm",(void*)f_1313},
{"f_1306:csc_scm",(void*)f_1306},
{"f_1309:csc_scm",(void*)f_1309},
{"f_1260:csc_scm",(void*)f_1260},
{"f_3569:csc_scm",(void*)f_3569},
{"f_3563:csc_scm",(void*)f_3563},
{"f_3561:csc_scm",(void*)f_3561},
{"f_3522:csc_scm",(void*)f_3522},
{"f_3524:csc_scm",(void*)f_3524},
{"f5206:csc_scm",(void*)f5206},
{"f_3553:csc_scm",(void*)f_3553},
{"f_3254:csc_scm",(void*)f_3254},
{"f5201:csc_scm",(void*)f5201},
{"f_3257:csc_scm",(void*)f_3257},
{"f_3420:csc_scm",(void*)f_3420},
{"f_3470:csc_scm",(void*)f_3470},
{"f_3501:csc_scm",(void*)f_3501},
{"f_3504:csc_scm",(void*)f_3504},
{"f_3518:csc_scm",(void*)f_3518},
{"f5196:csc_scm",(void*)f5196},
{"f_3514:csc_scm",(void*)f_3514},
{"f_3507:csc_scm",(void*)f_3507},
{"f_3510:csc_scm",(void*)f_3510},
{"f_3473:csc_scm",(void*)f_3473},
{"f_3480:csc_scm",(void*)f_3480},
{"f_3483:csc_scm",(void*)f_3483},
{"f_3497:csc_scm",(void*)f_3497},
{"f5191:csc_scm",(void*)f5191},
{"f_3493:csc_scm",(void*)f_3493},
{"f_3486:csc_scm",(void*)f_3486},
{"f_3489:csc_scm",(void*)f_3489},
{"f_3423:csc_scm",(void*)f_3423},
{"f_3460:csc_scm",(void*)f_3460},
{"f_3450:csc_scm",(void*)f_3450},
{"f_3427:csc_scm",(void*)f_3427},
{"f5186:csc_scm",(void*)f5186},
{"f_3431:csc_scm",(void*)f_3431},
{"f_3437:csc_scm",(void*)f_3437},
{"f_3440:csc_scm",(void*)f_3440},
{"f_3260:csc_scm",(void*)f_3260},
{"f5181:csc_scm",(void*)f5181},
{"f_3416:csc_scm",(void*)f_3416},
{"f_3404:csc_scm",(void*)f_3404},
{"f_3408:csc_scm",(void*)f_3408},
{"f_3412:csc_scm",(void*)f_3412},
{"f_3396:csc_scm",(void*)f_3396},
{"f_3388:csc_scm",(void*)f_3388},
{"f_3384:csc_scm",(void*)f_3384},
{"f_3263:csc_scm",(void*)f_3263},
{"f_3337:csc_scm",(void*)f_3337},
{"f_3374:csc_scm",(void*)f_3374},
{"f_3364:csc_scm",(void*)f_3364},
{"f5176:csc_scm",(void*)f5176},
{"f_3360:csc_scm",(void*)f_3360},
{"f_3356:csc_scm",(void*)f_3356},
{"f_3340:csc_scm",(void*)f_3340},
{"f_4102:csc_scm",(void*)f_4102},
{"f_4105:csc_scm",(void*)f_4105},
{"f5171:csc_scm",(void*)f5171},
{"f_4129:csc_scm",(void*)f_4129},
{"f_4108:csc_scm",(void*)f_4108},
{"f_4111:csc_scm",(void*)f_4111},
{"f_4125:csc_scm",(void*)f_4125},
{"f5166:csc_scm",(void*)f5166},
{"f_4121:csc_scm",(void*)f_4121},
{"f_4114:csc_scm",(void*)f_4114},
{"f_4117:csc_scm",(void*)f_4117},
{"f_3266:csc_scm",(void*)f_3266},
{"f_3301:csc_scm",(void*)f_3301},
{"f_3321:csc_scm",(void*)f_3321},
{"f_3601:csc_scm",(void*)f_3601},
{"f_3636:csc_scm",(void*)f_3636},
{"f_3629:csc_scm",(void*)f_3629},
{"f_3304:csc_scm",(void*)f_3304},
{"f_3317:csc_scm",(void*)f_3317},
{"f_4135:csc_scm",(void*)f_4135},
{"f_4138:csc_scm",(void*)f_4138},
{"f_4141:csc_scm",(void*)f_4141},
{"f_4144:csc_scm",(void*)f_4144},
{"f_4190:csc_scm",(void*)f_4190},
{"f_4197:csc_scm",(void*)f_4197},
{"f_4147:csc_scm",(void*)f_4147},
{"f_4150:csc_scm",(void*)f_4150},
{"f_4156:csc_scm",(void*)f_4156},
{"f_4159:csc_scm",(void*)f_4159},
{"f_4164:csc_scm",(void*)f_4164},
{"f_4172:csc_scm",(void*)f_4172},
{"f_4153:csc_scm",(void*)f_4153},
{"f_3269:csc_scm",(void*)f_3269},
{"f_3277:csc_scm",(void*)f_3277},
{"f_3287:csc_scm",(void*)f_3287},
{"f_1207:csc_scm",(void*)f_1207},
{"f_1181:csc_scm",(void*)f_1181},
{"f_1186:csc_scm",(void*)f_1186},
{"f_1190:csc_scm",(void*)f_1190},
{"f_1142:csc_scm",(void*)f_1142},
{"f_1160:csc_scm",(void*)f_1160},
{"f_1135:csc_scm",(void*)f_1135},
{"f_1140:csc_scm",(void*)f_1140},
{"f_4234:csc_scm",(void*)f_4234},
{"f_4240:csc_scm",(void*)f_4240},
{"f_4237:csc_scm",(void*)f_4237},
{"f_4079:csc_scm",(void*)f_4079},
{"f_4083:csc_scm",(void*)f_4083},
{"f_4063:csc_scm",(void*)f_4063},
{"f_4018:csc_scm",(void*)f_4018},
{"f_4021:csc_scm",(void*)f_4021},
{"f_4024:csc_scm",(void*)f_4024},
{"f_4040:csc_scm",(void*)f_4040},
{"f_4043:csc_scm",(void*)f_4043},
{"f_4046:csc_scm",(void*)f_4046},
{"f_4049:csc_scm",(void*)f_4049},
{"f_4027:csc_scm",(void*)f_4027},
{"f_3977:csc_scm",(void*)f_3977},
{"f_4007:csc_scm",(void*)f_4007},
{"f_3984:csc_scm",(void*)f_3984},
{"f_3995:csc_scm",(void*)f_3995},
{"f_3990:csc_scm",(void*)f_3990},
{"f_3928:csc_scm",(void*)f_3928},
{"f_3930:csc_scm",(void*)f_3930},
{"f_3960:csc_scm",(void*)f_3960},
{"f_3967:csc_scm",(void*)f_3967},
{"f_3953:csc_scm",(void*)f_3953},
{"f_3924:csc_scm",(void*)f_3924},
{"f_3910:csc_scm",(void*)f_3910},
{"f_3920:csc_scm",(void*)f_3920},
{"f_3834:csc_scm",(void*)f_3834},
{"f_3838:csc_scm",(void*)f_3838},
{"f_3880:csc_scm",(void*)f_3880},
{"f_3874:csc_scm",(void*)f_3874},
{"f_3849:csc_scm",(void*)f_3849},
{"f_3853:csc_scm",(void*)f_3853},
{"f_3845:csc_scm",(void*)f_3845},
{"f_3782:csc_scm",(void*)f_3782},
{"f_3828:csc_scm",(void*)f_3828},
{"f_3822:csc_scm",(void*)f_3822},
{"f_3820:csc_scm",(void*)f_3820},
{"f_3816:csc_scm",(void*)f_3816},
{"f_3790:csc_scm",(void*)f_3790},
{"f_3797:csc_scm",(void*)f_3797},
{"f_3685:csc_scm",(void*)f_3685},
{"f_3689:csc_scm",(void*)f_3689},
{"f_3700:csc_scm",(void*)f_3700},
{"f_3721:csc_scm",(void*)f_3721},
{"f_3759:csc_scm",(void*)f_3759},
{"f_3741:csc_scm",(void*)f_3741},
{"f_3714:csc_scm",(void*)f_3714},
{"f_3718:csc_scm",(void*)f_3718},
{"f_3645:csc_scm",(void*)f_3645},
{"f_3653:csc_scm",(void*)f_3653},
{"f_3656:csc_scm",(void*)f_3656},
{"f_3659:csc_scm",(void*)f_3659},
{"f5143:csc_scm",(void*)f5143},
{"f_3679:csc_scm",(void*)f_3679},
{"f_3662:csc_scm",(void*)f_3662},
{"f_3665:csc_scm",(void*)f_3665},
{"f5138:csc_scm",(void*)f5138},
{"f_3675:csc_scm",(void*)f_3675},
{"f_3668:csc_scm",(void*)f_3668},
{"f_3671:csc_scm",(void*)f_3671},
{"f_3575:csc_scm",(void*)f_3575},
{"f_3583:csc_scm",(void*)f_3583},
{"f_3194:csc_scm",(void*)f_3194},
{"f_3206:csc_scm",(void*)f_3206},
{"f_3208:csc_scm",(void*)f_3208},
{"f_3237:csc_scm",(void*)f_3237},
{"f_3202:csc_scm",(void*)f_3202},
{"f_881:csc_scm",(void*)f_881},
{"f_889:csc_scm",(void*)f_889},
{"f_835:csc_scm",(void*)f_835},
{"f_846:csc_scm",(void*)f_846},
{"f_850:csc_scm",(void*)f_850},
{"f_839:csc_scm",(void*)f_839},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
