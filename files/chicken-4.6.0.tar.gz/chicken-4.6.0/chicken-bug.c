/* Generated from chicken-bug.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-bug.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file chicken-bug.c
   used units: library eval srfi_13 posix tcp data_structures utils extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_tcp_toplevel)
C_externimport void C_ccall C_tcp_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[149];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_282)
static void C_ccall f_282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_285)
static void C_ccall f_285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_288)
static void C_ccall f_288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_291)
static void C_ccall f_291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_294)
static void C_ccall f_294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_297)
static void C_ccall f_297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_300)
static void C_ccall f_300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_303)
static void C_ccall f_303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1363)
static void C_ccall f_1363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_ccall f_1369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1366)
static void C_ccall f_1366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1255)
static void C_ccall f_1255(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1261)
static void C_fcall f_1261(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1271)
static void C_ccall f_1271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_ccall f_1292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1298)
static void C_ccall f_1298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1360)
static void C_ccall f_1360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1356)
static void C_ccall f_1356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1305)
static void C_ccall f_1305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1352)
static void C_ccall f_1352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1308)
static void C_ccall f_1308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1348)
static void C_ccall f_1348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1314)
static void C_ccall f_1314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1340)
static void C_ccall f_1340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_ccall f_1320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1323)
static void C_ccall f_1323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1326)
static void C_ccall f_1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1329)
static void C_ccall f_1329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1286)
static void C_ccall f_1286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_ccall f_1274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1277)
static void C_ccall f_1277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1241)
static void C_ccall f_1241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1159)
static void C_ccall f_1159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1174)
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1204)
static void C_ccall f_1204(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1180)
static void C_ccall f_1180(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1186)
static void C_ccall f_1186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1193)
static void C_ccall f_1193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1163)
static void C_ccall f_1163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1073)
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1105)
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1135)
static void C_ccall f_1135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1147)
static void C_ccall f_1147r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1153)
static void C_ccall f_1153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_ccall f_1141(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1124)
static void C_ccall f_1124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1127)
static void C_ccall f_1127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1077)
static void C_ccall f_1077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_ccall f_1096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1071)
static void C_ccall f_1071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1067)
static void C_ccall f_1067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1063)
static void C_ccall f_1063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_867)
static void C_ccall f_867(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_878)
static void C_fcall f_878(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_882)
static void C_ccall f_882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_889)
static void C_fcall f_889(C_word t0,C_word t1) C_noret;
C_noret_decl(f_893)
static void C_ccall f_893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_ccall f_897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_917)
static void C_ccall f_917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_901)
static void C_ccall f_901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_909)
static void C_ccall f_909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_905)
static void C_ccall f_905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_851)
static void C_ccall f_851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_844)
static void C_ccall f_844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_836)
static void C_ccall f_836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_839)
static void C_ccall f_839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_680)
static void C_ccall f_680(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_761)
static void C_fcall f_761(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_769)
static void C_fcall f_769(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_810)
static void C_ccall f_810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_806)
static void C_ccall f_806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1465)
static void C_ccall f1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_781)
static void C_ccall f_781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_684)
static void C_ccall f_684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_755)
static void C_ccall f_755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_687)
static void C_fcall f_687(C_word t0,C_word t1) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_747)
static void C_ccall f_747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_718)
static void C_ccall f_718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_708)
static void C_ccall f_708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static void C_ccall f_661(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_614)
static void C_ccall f_614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_659)
static void C_ccall f_659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_652)
static void C_ccall f_652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_618)
static void C_ccall f_618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_623)
static void C_fcall f_623(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_627)
static void C_ccall f_627(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_605)
static void C_ccall f_605(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_609)
static void C_ccall f_609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_319)
static void C_ccall f_319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_323)
static void C_ccall f_323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_326)
static void C_ccall f_326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_603)
static void C_ccall f_603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_329)
static void C_ccall f_329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_332)
static void C_ccall f_332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1458)
static void C_ccall f1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_335)
static void C_ccall f_335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_341)
static void C_ccall f_341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_344)
static void C_ccall f_344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_591)
static void C_ccall f_591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_347)
static void C_ccall f_347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_587)
static void C_ccall f_587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_583)
static void C_ccall f_583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_353)
static void C_ccall f_353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_356)
static void C_ccall f_356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_575)
static void C_ccall f_575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_359)
static void C_ccall f_359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_571)
static void C_ccall f_571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_362)
static void C_ccall f_362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_365)
static void C_ccall f_365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_371)
static void C_ccall f_371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_ccall f_374(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_534)
static void C_fcall f_534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_532)
static void C_ccall f_532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_528)
static void C_ccall f_528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_446)
static void C_ccall f_446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_448)
static void C_fcall f_448(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_460)
static void C_ccall f_460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_465)
static void C_fcall f_465(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_477)
static void C_ccall f_477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_484)
static void C_ccall f_484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_499)
static void C_ccall f_499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_380)
static void C_ccall f_380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_383)
static void C_ccall f_383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_442)
static void C_ccall f_442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_428)
static void C_ccall f_428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_430)
static void C_ccall f_430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_386)
static void C_ccall f_386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_389)
static void C_ccall f_389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_ccall f_401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_414)
static void C_ccall f_414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_392)
static void C_ccall f_392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_309)
static void C_ccall f_309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_317)
static void C_ccall f_317(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1261)
static void C_fcall trf_1261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1261(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1261(t0,t1,t2);}

C_noret_decl(trf_878)
static void C_fcall trf_878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_878(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_878(t0,t1);}

C_noret_decl(trf_889)
static void C_fcall trf_889(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_889(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_889(t0,t1);}

C_noret_decl(trf_761)
static void C_fcall trf_761(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_761(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_761(t0,t1,t2);}

C_noret_decl(trf_769)
static void C_fcall trf_769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_769(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_769(t0,t1,t2);}

C_noret_decl(trf_687)
static void C_fcall trf_687(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_687(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_687(t0,t1);}

C_noret_decl(trf_623)
static void C_fcall trf_623(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_623(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_623(t0,t1,t2);}

C_noret_decl(trf_534)
static void C_fcall trf_534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_534(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_534(t0,t1,t2);}

C_noret_decl(trf_448)
static void C_fcall trf_448(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_448(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_448(t0,t1,t2);}

C_noret_decl(trf_465)
static void C_fcall trf_465(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_465(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_465(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(670)){
C_save(t1);
C_rereclaim2(670*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,149);
lf[0]=C_h_intern(&lf[0],7,"user-id");
lf[1]=C_h_intern(&lf[1],16,"user-information");
lf[2]=C_h_intern(&lf[2],15,"current-user-id");
lf[3]=C_h_intern(&lf[3],12,"collect-info");
lf[4]=C_h_intern(&lf[4],19,"\003sysstandard-output");
lf[5]=C_h_intern(&lf[5],7,"newline");
lf[6]=C_h_intern(&lf[6],7,"display");
lf[7]=C_h_intern(&lf[7],8,"read-all");
lf[8]=C_h_intern(&lf[8],20,"with-input-from-pipe");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\013gcc -v 2>&1");
lf[10]=C_h_intern(&lf[10],5,"print");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\0000CC seems to be gcc, trying to obtain version...\012");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\003gcc");
lf[13]=C_h_intern(&lf[13],8,"feature\077");
lf[14]=C_h_intern(&lf[14],4,"unix");
lf[15]=C_h_intern(&lf[15],17,"\003syspeek-c-string");
lf[16]=C_h_intern(&lf[16],20,"with-input-from-file");
lf[17]=C_h_intern(&lf[17],13,"make-pathname");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\020chicken-config.h");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024\012\012chicken-config.h:\012");
lf[20]=C_h_intern(&lf[20],11,"make-string");
lf[21]=C_h_intern(&lf[21],5,"fxmax");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[23]=C_h_intern(&lf[23],4,"chop");
lf[24]=C_h_intern(&lf[24],4,"sort");
lf[25]=C_h_intern(&lf[25],8,"string<\077");
lf[26]=C_h_intern(&lf[26],15,"keyword->string");
lf[27]=C_h_intern(&lf[27],12,"\003sysfeatures");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\011Features:");
lf[29]=C_h_intern(&lf[29],19,"\003syswrite-char/port");
lf[30]=C_h_intern(&lf[30],5,"write");
lf[31]=C_h_intern(&lf[31],21,"\003sysinclude-pathnames");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\016Include path:\011");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\020Home directory:\011");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[35]=C_h_intern(&lf[35],12,"chicken-home");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN version is:\012");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[38]=C_h_intern(&lf[38],15,"chicken-version");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\021\011build platform:\011");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[41]=C_h_intern(&lf[41],14,"build-platform");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\023\011software version:\011");
lf[43]=C_h_intern(&lf[43],16,"software-version");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\020\011software type:\011");
lf[45]=C_h_intern(&lf[45],13,"software-type");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\017\011machine type:\011");
lf[47]=C_h_intern(&lf[47],12,"machine-type");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\022Host information:\012");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\022User information:\011");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\006Date:\011");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[52]=C_h_intern(&lf[52],15,"seconds->string");
lf[53]=C_h_intern(&lf[53],15,"current-seconds");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\0002This is a bug report generated by chicken-bug(1).\012");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\0004\012--------------------------------------------------\012");
lf[56]=C_h_intern(&lf[56],5,"usage");
lf[57]=C_h_intern(&lf[57],4,"exit");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\0017usage: chicken-bug [FILENAME ...]\012\012  -help  -h            show this message"
"\012  -to-stdout           write bug report to standard output\012  -                 "
"   read description from standard input\012\012Generates a bug report file from user i"
"nput or alternatively\012from the contents of files given on the command line.\012");
lf[59]=C_h_intern(&lf[59],10,"user-input");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[61]=C_h_intern(&lf[61],26,"string-concatenate-reverse");
lf[62]=C_h_intern(&lf[62],9,"read-line");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\001jThis is the CHICKEN bug report generator. Please enter a detailed\012descripti"
"on of the problem you have encountered and enter CTRL-D (EOF)\012or a line consisti"
"ng only of \042.\042 to finish. Press CTRL-C to abort the program. You can\012also pass t"
"he description from a file (just abort now and re-invoke\012\042chicken-bug\042 with one "
"or more input files given on the command-line)\012");
lf[64]=C_h_intern(&lf[64],13,"\003systty-port\077");
lf[65]=C_h_intern(&lf[65],18,"current-input-port");
lf[66]=C_h_intern(&lf[66],7,"justify");
lf[67]=C_h_intern(&lf[67],13,"string-append");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[69]=C_h_intern(&lf[69],4,"main");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[71]=C_h_intern(&lf[71],8,"try-mail");
lf[72]=C_h_intern(&lf[72],21,"with-output-to-string");
lf[73]=C_h_intern(&lf[73],12,"mail-headers");
lf[74]=C_h_intern(&lf[74],7,"sprintf");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\033chicken-bug-report.~a-~a-~a");
lf[76]=C_h_intern(&lf[76],19,"seconds->local-time");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\017\012\012User input:\012\012");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\012-to-stdout");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\016\012\012File added: ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\002\012\012");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000!one of the following addresses:\012\012");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000Ochicken-janitors@nongnu.org\012chicken-hackers@nongnu.org\012chicken-users@nongnu"
".org");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000#\012A bug report has been written to `");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\025\047.  Please send it to");
lf[90]=C_h_intern(&lf[90],19,"with-output-to-file");
lf[91]=C_h_intern(&lf[91],9,"send-mail");
lf[92]=C_h_intern(&lf[92],13,"mail-date-str");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\006 +0000");
lf[97]=C_h_intern(&lf[97],10,"string-pad");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jan ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\005 Feb ");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\005 Mar ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\005 Apr ");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005 May ");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jun ");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\005 Jul ");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\005 Aug ");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\005 Sep ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\005 Oct ");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\005 Nov ");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\005 Dec ");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\005Sun, ");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005Mon, ");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\005Tue, ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\005Wed, ");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\005Thu, ");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\005Fri, ");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\005Sat, ");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\006Date: ");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\002\015\012");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000;From: \042chicken-bug user\042 <chicken-bug-command@callcc.org>\015\012");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\0006To: \042Chicken Janitors\042 <chicken-janitors@nongnu.org>\015\012");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000)Subject: Automated chicken-bug output -- ");
lf[122]=C_h_intern(&lf[122],17,"seconds->utc-time");
lf[123]=C_h_intern(&lf[123],9,"mail-read");
lf[124]=C_h_intern(&lf[124],9,"substring");
lf[125]=C_h_intern(&lf[125],9,"condition");
lf[126]=C_h_intern(&lf[126],17,"close-output-port");
lf[127]=C_h_intern(&lf[127],16,"close-input-port");
lf[128]=C_h_intern(&lf[128],22,"with-exception-handler");
lf[129]=C_h_intern(&lf[129],30,"call-with-current-continuation");
lf[130]=C_h_intern(&lf[130],10,"mail-write");
lf[131]=C_h_intern(&lf[131],10,"mail-check");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\010 failed.");
lf[133]=C_h_intern(&lf[133],11,"tcp-connect");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000Vok.\012\012Bug report successfully mailed to the Chicken maintainers.\012Thank you v"
"ery much!\012\012");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\004QUIT");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\004\015\012\015\012");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\005\015\012.\015\012");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\006DATA\015\012");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\047RCPT TO:<chicken-janitors@nongnu.org>\015\012");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000,MAIL FROM:<chicken-bug-command@callcc.org>\015\012");
lf[141]=C_decode_literal(C_heaptop,"\376B\000\000\021HELO callcc.org\015\012");
lf[142]=C_h_intern(&lf[142],6,"print*");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\016connecting to ");
lf[144]=C_decode_literal(C_heaptop,"\376B\000\000\007, try #");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[146]=C_h_intern(&lf[146],7,"call/cc");
lf[147]=C_h_intern(&lf[147],25,"\003sysimplicit-exit-handler");
lf[148]=C_h_intern(&lf[148],22,"command-line-arguments");
C_register_lf2(lf,149,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_282,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k280 */
static void C_ccall f_282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k283 in k280 */
static void C_ccall f_285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k286 in k283 in k280 */
static void C_ccall f_288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k289 in k286 in k283 in k280 */
static void C_ccall f_291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_303,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! user-id ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_309,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[3]+1 /* (set! collect-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_319,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[56]+1 /* (set! usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_605,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[59]+1 /* (set! user-input ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_614,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[66]+1 /* (set! justify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_661,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[69]+1 /* (set! main ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_680,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[71]+1 /* (set! try-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_826,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[92]+1 /* (set! mail-date-str ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_867,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[73]+1 /* (set! mail-headers ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1055,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[123]+1 /* (set! mail-read ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1073,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[130]+1 /* (set! mail-write ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1159,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[131]+1 /* (set! mail-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1228,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[91]+1 /* (set! send-mail ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1249,tmp=(C_word)a,a+=2,tmp));
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1363,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1373,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:271: command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[148]))(2,*((C_word*)lf[148]+1),t16);}

/* k1371 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:271: main */
((C_proc3)C_retrieve_proc(*((C_word*)lf[69]+1)))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t1);}

/* k1361 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1366,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1369,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[147]))(2,*((C_word*)lf[147]+1),t3);}

/* k1367 in k1361 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1364 in k1361 in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1249,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1255,a[2]=t3,a[3]=t5,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:249: call/cc */
((C_proc3)C_retrieve_proc(*((C_word*)lf[146]+1)))(3,*((C_word*)lf[146]+1),t1,t6);}

/* a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1255(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1255,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_1261(t6,t1,C_fix(1));}

/* doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_1261(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1261,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greaterp(t2,C_fix(3)))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* chicken-bug.scm:253: print* */
((C_proc7)C_retrieve_proc(*((C_word*)lf[142]+1)))(7,*((C_word*)lf[142]+1),t3,lf[143],((C_word*)t0)[6],lf[144],t2,lf[145]);}}

/* k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1286,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}

/* a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1292(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1292,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* chicken-bug.scm:256: call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t1,t4);}

/* a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1298,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1360,a[2]=t2,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:258: mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),t4,((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k1358 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:258: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(220),((C_word*)t0)[2]);}

/* k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1305,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1356,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:259: mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[141]);}

/* k1354 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:259: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1308,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1352,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:260: mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[140]);}

/* k1350 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:260: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1348,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:261: mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[139]);}

/* k1346 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:261: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1314,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:262: mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),t3,((C_word*)t0)[6],((C_word*)t0)[7],lf[138]);}

/* k1342 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:262: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(354),((C_word*)t0)[2]);}

/* k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1336,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1340,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:263: string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),t4,((C_word*)t0)[4],((C_word*)t0)[3],lf[136],((C_word*)t0)[2],lf[137]);}

/* k1338 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:263: mail-write */
((C_proc5)C_retrieve_proc(*((C_word*)lf[130]+1)))(5,*((C_word*)lf[130]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1334 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:263: mail-check */
((C_proc7)C_retrieve_proc(*((C_word*)lf[131]+1)))(7,*((C_word*)lf[131]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,C_fix(250),((C_word*)t0)[2]);}

/* k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* chicken-bug.scm:264: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,lf[135],((C_word*)t0)[3]);}

/* k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1323,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:265: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t2,((C_word*)t0)[2]);}

/* k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1326,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:266: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:267: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[134]);}

/* k1327 in k1324 in k1321 in k1318 in k1315 in k1312 in k1309 in k1306 in k1303 in k1300 in a1297 in a1291 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:268: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1285 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1286,2,t0,t1);}
/* chicken-bug.scm:255: tcp-connect */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),t1,((C_word*)t0)[2],C_fix(25));}

/* k1272 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:269: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[132]);}

/* k1275 in k1272 in k1269 in doloop230 in a1254 in send-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1277,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1261(t3,((C_word*)t0)[2],t2);}

/* mail-check in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=7) C_bad_argc_2(c,7,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_1228,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(C_truep(t4)?C_i_nequalp(t4,t5):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_TRUE);}
else{
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1238,a[2]=t3,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:244: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t8,t2);}}

/* k1236 in mail-check in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:245: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1239 in k1236 in mail-check in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:246: k */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1159(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1159,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1163,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1174,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t5,t6);}

/* a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1174(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1174,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1180,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1204,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1203 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1204(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1204,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1215 in a1203 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1216r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1216r(t0,t1,t2);}}

static void C_ccall f_1216r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k202206 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1221 in a1215 in a1203 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1222,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1209 in a1203 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1210,2,t0,t1);}
/* chicken-bug.scm:234: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a1179 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1180(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1180,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1186,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k202206 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1185 in a1179 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1186,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1193,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:235: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1191 in a1185 in a1179 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:235: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1194 in k1191 in a1185 in a1179 in a1173 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1161 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g204205 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1164 in k1161 in mail-write in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm:237: mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1073(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1073,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1077,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1105,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[129]+1)))(3,*((C_word*)lf[129]+1),t4,t5);}

/* a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1105(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1105,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1111,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1135,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[128]))(4,*((C_word*)lf[128]+1),t1,t3,t4);}

/* a1134 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1141,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1147,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a1146 in a1134 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1147(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1147r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1147r(t0,t1,t2);}}

static void C_ccall f_1147r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k178182 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1152 in a1146 in a1134 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1153,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a1140 in a1134 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1141(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1141,2,t0,t1);}
/* chicken-bug.scm:225: read-line */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,((C_word*)t0)[2]);}

/* a1110 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1111,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* k178182 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1116 in a1110 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1117,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[4],lf[125]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1124,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:226: close-input-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[127]+1)))(3,*((C_word*)lf[127]+1),t4,((C_word*)t0)[2]);}

/* k1122 in a1116 in a1110 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1124,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1127,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:226: close-output-port */
((C_proc3)C_retrieve_proc(*((C_word*)lf[126]+1)))(3,*((C_word*)lf[126]+1),t2,((C_word*)t0)[2]);}

/* k1125 in k1122 in a1116 in a1110 in a1104 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k1075 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1077,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g180181 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1078 in k1075 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1080,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_ref(t1,C_fix(0));
if(C_truep(C_u_i_char_numericp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:229: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[124]+1)))(5,*((C_word*)lf[124]+1),t3,t1,C_fix(0),C_fix(3));}
else{
/* chicken-bug.scm:230: mail-read */
((C_proc4)C_retrieve_proc(*((C_word*)lf[123]+1)))(4,*((C_word*)lf[123]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1094 in k1078 in k1075 in mail-read in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:229: string->number */
C_string_to_number(3,0,((C_word*)t0)[2],t1);}

/* mail-headers in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1063,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1067,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1071,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:219: current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k1069 in mail-headers in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:219: seconds->utc-time */
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[2],t1);}

/* k1065 in mail-headers in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:219: mail-date-str */
((C_proc3)C_retrieve_proc(*((C_word*)lf[92]+1)))(3,*((C_word*)lf[92]+1),((C_word*)t0)[2],t1);}

/* k1061 in mail-headers in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:218: string-append */
((C_proc8)C_retrieve_proc(*((C_word*)lf[67]+1)))(8,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[117],t1,lf[118],lf[119],lf[120],lf[121]);}

/* mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_867(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_867,3,t0,t1,t2);}
t3=C_i_vector_ref(t2,C_fix(6));
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_878,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
switch(t3){
case C_fix(0):
t5=t4;
f_878(t5,lf[110]);
case C_fix(1):
t5=t4;
f_878(t5,lf[111]);
case C_fix(2):
t5=t4;
f_878(t5,lf[112]);
case C_fix(3):
t5=t4;
f_878(t5,lf[113]);
case C_fix(4):
t5=t4;
f_878(t5,lf[114]);
case C_fix(5):
t5=t4;
f_878(t5,lf[115]);
default:
t5=C_eqp(t3,C_fix(6));
t6=t4;
f_878(t6,(C_truep(t5)?lf[116]:C_SCHEME_UNDEFINED));}}

/* k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_878(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_878,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_882,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1010,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[3],C_fix(3));
/* chicken-bug.scm:194: number->string */
C_number_to_string(3,0,t3,t4);}

/* k1008 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:194: string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_882,2,t0,t1);}
t2=C_i_vector_ref(((C_word*)t0)[4],C_fix(4));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_889,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
switch(t2){
case C_fix(0):
t4=t3;
f_889(t4,lf[98]);
case C_fix(1):
t4=t3;
f_889(t4,lf[99]);
case C_fix(2):
t4=t3;
f_889(t4,lf[100]);
case C_fix(3):
t4=t3;
f_889(t4,lf[101]);
case C_fix(4):
t4=t3;
f_889(t4,lf[102]);
case C_fix(5):
t4=t3;
f_889(t4,lf[103]);
case C_fix(6):
t4=t3;
f_889(t4,lf[104]);
case C_fix(7):
t4=t3;
f_889(t4,lf[105]);
case C_fix(8):
t4=t3;
f_889(t4,lf[106]);
case C_fix(9):
t4=t3;
f_889(t4,lf[107]);
case C_fix(10):
t4=t3;
f_889(t4,lf[108]);
case C_fix(11):
t4=t3;
f_889(t4,lf[109]);
default:
t4=C_SCHEME_UNDEFINED;
t5=t3;
f_889(t5,t4);}}

/* k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_889(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_889,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_893,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=C_i_vector_ref(((C_word*)t0)[2],C_fix(5));
t4=C_a_i_plus(&a,2,C_fix(1900),t3);
/* chicken-bug.scm:208: number->string */
C_number_to_string(3,0,t2,t4);}

/* k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(2));
/* chicken-bug.scm:210: number->string */
C_number_to_string(3,0,t3,t4);}

/* k923 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:210: string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k895 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_901,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_917,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(1));
/* chicken-bug.scm:212: number->string */
C_number_to_string(3,0,t3,t4);}

/* k915 in k895 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:212: string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k899 in k895 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_905,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_909,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_vector_ref(((C_word*)t0)[2],C_fix(0));
/* chicken-bug.scm:214: number->string */
C_number_to_string(3,0,t3,t4);}

/* k907 in k899 in k895 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:214: string-pad */
((C_proc5)C_retrieve_symbol_proc(lf[97]))(5,*((C_word*)lf[97]+1),((C_word*)t0)[2],t1,C_fix(2),C_make_character(48));}

/* k903 in k899 in k895 in k891 in k887 in k880 in k876 in mail-date-str in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:185: string-append */
((C_proc13)C_retrieve_proc(*((C_word*)lf[67]+1)))(13,*((C_word*)lf[67]+1),((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],lf[93],((C_word*)t0)[3],lf[94],((C_word*)t0)[2],lf[95],t1,lf[96]);}

/* try-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_826,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_836,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_844,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:175: with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[90]))(4,*((C_word*)lf[90]+1),t6,t3,t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_851,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t7=C_i_car(t2);
/* chicken-bug.scm:181: send-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[91]+1)))(6,*((C_word*)lf[91]+1),t6,t7,t5,t4,t3);}}

/* k849 in try-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_i_cdr(((C_word*)t0)[5]);
/* chicken-bug.scm:182: try-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[71]+1)))(6,*((C_word*)lf[71]+1),((C_word*)t0)[6],t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* a843 in try-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_844,2,t0,t1);}
/* chicken-bug.scm:176: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t1,((C_word*)t0)[2]);}

/* k834 in try-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_836,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_839,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:179: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,lf[88],((C_word*)t0)[2],lf[89]);}

/* k837 in k834 in try-mail in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:180: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[86],lf[87]);}

/* main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_680(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[20],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_680,3,t0,t1,t2);}
t3=lf[70];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_684,a[2]=t6,a[3]=t4,a[4]=t1,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_761,a[2]=t11,a[3]=t8,a[4]=t4,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_761(t13,t9,t2);}

/* loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_761(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_761,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_813,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g130131 */
t6=t3;
f_769(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k811 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_761(t3,((C_word*)t0)[2],t2);}

/* g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_769(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_769,NULL,3,t0,t1,t2);}
if(C_truep(C_i_string_equal_p(lf[78],t2))){
t3=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_781,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:129: user-input */
((C_proc2)C_retrieve_proc(*((C_word*)lf[59]+1)))(2,*((C_word*)lf[59]+1),t5);}
else{
t3=t2;
if(C_truep((C_truep(C_i_equalp(t3,lf[80]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[81]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[82]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))){
t4=t1;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1465,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:84: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t5,lf[58]);}
else{
if(C_truep(C_i_string_equal_p(lf[83],t2))){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_set_block_item(((C_word*)t0)[4],0,C_SCHEME_TRUE);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_806,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_810,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:140: read-all */
((C_proc3)C_retrieve_symbol_proc(lf[7]))(3,*((C_word*)lf[7]+1),t6,t2);}}}}

/* k808 in g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:137: string-append */
((C_proc7)C_retrieve_proc(*((C_word*)lf[67]+1)))(7,*((C_word*)lf[67]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],lf[84],((C_word*)t0)[2],lf[85],t1);}

/* k804 in g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* f1465 in g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:96: exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[2],C_fix(0));}

/* k783 in g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:129: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[79],t1);}

/* k779 in g130 in loop123 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_684,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_687,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=t2;
f_687(t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_755,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_759,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:143: user-input */
((C_proc2)C_retrieve_proc(*((C_word*)lf[59]+1)))(2,*((C_word*)lf[59]+1),t4);}}

/* k757 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:143: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[67]+1)))(5,*((C_word*)lf[67]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],lf[77],t1);}

/* k753 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_687(t3,t2);}

/* k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_687(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_687,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_690,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:144: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_690,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_693,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:145: current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t3);}

/* k749 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:145: seconds->local-time */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
t2=C_i_vector_ref(t1,C_fix(3));
t3=C_i_vector_ref(t1,C_fix(4));
t4=C_i_vector_ref(t1,C_fix(5));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_708,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:151: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t5,((C_word*)((C_word*)t0)[2])[1]);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_718,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_plus(&a,2,C_fix(1900),t4);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_743,a[2]=t2,a[3]=t6,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:155: justify */
((C_proc3)C_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t7,t3);}}

/* k741 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_747,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:155: justify */
((C_proc3)C_retrieve_proc(*((C_word*)lf[66]+1)))(3,*((C_word*)lf[66]+1),t2,((C_word*)t0)[2]);}

/* k745 in k741 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:155: sprintf */
((C_proc6)C_retrieve_proc(*((C_word*)lf[74]+1)))(6,*((C_word*)lf[74]+1),((C_word*)t0)[4],lf[75],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k716 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:156: mail-headers */
((C_proc2)C_retrieve_proc(*((C_word*)lf[73]+1)))(2,*((C_word*)lf[73]+1),t2);}

/* k720 in k716 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_726,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:157: with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[72]))(3,*((C_word*)lf[72]+1),t2,t3);}

/* a727 in k720 in k716 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_728,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_732,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:159: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,((C_word*)((C_word*)t0)[2])[1]);}

/* k730 in a727 in k720 in k716 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:160: collect-info */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* k724 in k720 in k716 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:153: try-mail */
((C_proc6)C_retrieve_proc(*((C_word*)lf[71]+1)))(6,*((C_word*)lf[71]+1),((C_word*)t0)[4],C_SCHEME_END_OF_LIST,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k706 in k691 in k688 in k685 in k682 in main in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:152: collect-info */
((C_proc2)C_retrieve_proc(*((C_word*)lf[3]+1)))(2,*((C_word*)lf[3]+1),((C_word*)t0)[2]);}

/* justify in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_661(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_661,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_665,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:116: number->string */
C_number_to_string(3,0,t3,t2);}

/* k663 in justify in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_string_length(t1);
if(C_truep(C_i_greaterp(t2,C_fix(1)))){
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* chicken-bug.scm:119: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[67]+1)))(4,*((C_word*)lf[67]+1),((C_word*)t0)[2],lf[68],t1);}}

/* user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_614,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_618,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_652,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_659,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:99: current-input-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[65]+1)))(2,*((C_word*)lf[65]+1),t4);}

/* k657 in user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:99: ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[64]))(3,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1);}

/* k650 in user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* chicken-bug.scm:100: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[63]);}
else{
t2=((C_word*)t0)[2];
f_618(2,t2,C_SCHEME_UNDEFINED);}}

/* k616 in user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_618,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_623(t5,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k616 in user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_623(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_623,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_627,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* chicken-bug.scm:110: read-line */
((C_proc2)C_retrieve_symbol_proc(lf[62]))(2,*((C_word*)lf[62]+1),t3);}

/* k625 in loop in k616 in user-input in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_627(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_627,2,t0,t1);}
t2=C_eofp(t1);
t3=(C_truep(t2)?t2:C_i_string_equal_p(lf[60],t1));
if(C_truep(t3)){
/* chicken-bug.scm:112: string-concatenate-reverse */
((C_proc3)C_retrieve_symbol_proc(lf[61]))(3,*((C_word*)lf[61]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t4=C_a_i_cons(&a,2,t1,((C_word*)t0)[3]);
/* chicken-bug.scm:113: loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_623(t5,((C_word*)t0)[4],t4);}}

/* usage in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_605(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_605,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_609,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:84: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t3,lf[58]);}

/* k607 in usage in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:96: exit */
((C_proc3)C_retrieve_symbol_proc(lf[57]))(3,*((C_word*)lf[57]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_319,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_323,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:50: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[55]);}

/* k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_326,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:51: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[54]);}

/* k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_329,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_603,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:52: current-seconds */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t4);}

/* k601 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:52: seconds->string */
((C_proc3)C_retrieve_symbol_proc(lf[52]))(3,*((C_word*)lf[52]+1),((C_word*)t0)[2],t1);}

/* k597 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:52: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[50],t1,lf[51]);}

/* k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_329,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_332,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[49],t2);}

/* k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_335,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1458,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:47: current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t4);}

/* f1458 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:47: user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

/* k593 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_335,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_341,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_344,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:54: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[48]);}

/* k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_347,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_591,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:55: machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[47]))(2,*((C_word*)lf[47]+1),t3);}

/* k589 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:55: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[46],t1);}

/* k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_587,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:56: software-type */
((C_proc2)C_retrieve_symbol_proc(lf[45]))(2,*((C_word*)lf[45]+1),t3);}

/* k585 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:56: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[44],t1);}

/* k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_583,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:57: software-version */
((C_proc2)C_retrieve_symbol_proc(lf[43]))(2,*((C_word*)lf[43]+1),t3);}

/* k581 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:57: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[42],t1);}

/* k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_353,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_356,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:58: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[41]))(2,*((C_word*)lf[41]+1),t3);}

/* k577 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:58: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[39],t1,lf[40]);}

/* k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_356,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_575,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:59: chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[38]))(3,*((C_word*)lf[38]+1),t3,C_SCHEME_TRUE);}

/* k573 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:59: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[36],t1,lf[37]);}

/* k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_359,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_362,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_571,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:60: chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[35]))(2,*((C_word*)lf[35]+1),t3);}

/* k569 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:60: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),((C_word*)t0)[2],lf[33],t1,lf[34]);}

/* k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_362,2,t0,t1);}
t2=*((C_word*)lf[4]+1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_365,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t3,lf[32],t2);}

/* k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_368,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[30]+1)))(4,*((C_word*)lf[30]+1),t2,C_retrieve(lf[31]),((C_word*)t0)[2]);}

/* k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_371,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_371,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_374,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* write-char/port */
t3=C_retrieve(lf[29]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_374(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_374,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_377,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:62: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[28]);}

/* k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_380,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_446,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_528,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_532,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_534,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_534(t13,t9,C_retrieve(lf[27]));}

/* loop61 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_534,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[26]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_563,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g7778 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k561 in loop61 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_563,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6174 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_534(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop6174 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_534(t6,((C_word*)t0)[3],t5);}}

/* k530 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:70: sort */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,*((C_word*)lf[25]+1));}

/* k526 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:70: chop */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[2],t1,C_fix(5));}

/* k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_446,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_448,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_448(t5,((C_word*)t0)[2],t1);}

/* loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_448(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_448,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_513,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_460,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* chicken-bug.scm:65: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t5,lf[22]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_460,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_465,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_465(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop40 in k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_fcall f_465(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_465,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_499,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[4]+1);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_477,a[2]=t4,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k475 in loop40 in k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_488,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_string_length(((C_word*)t0)[2]);
t5=C_fixnum_difference(C_fix(16),t4);
/* chicken-bug.scm:68: fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[21]+1)))(4,*((C_word*)lf[21]+1),t3,C_fix(1),t5);}

/* k486 in k475 in loop40 in k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:68: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[20]+1)))(4,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k482 in k475 in loop40 in k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k497 in loop40 in k458 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_465(t3,((C_word*)t0)[2],t2);}

/* k511 in loop28 in k444 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_448(t3,((C_word*)t0)[2],t2);}

/* k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_383,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:71: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[19]);}

/* k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_386,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_428,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_442,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_INSTALL_INCLUDE_HOME),C_fix(0));}

/* k440 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:72: make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[17]))(4,*((C_word*)lf[17]+1),((C_word*)t0)[2],t1,lf[18]);}

/* k426 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_428,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_430,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm:72: with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[16]))(4,*((C_word*)lf[16]+1),((C_word*)t0)[2],t1,t2);}

/* a429 in k426 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:74: read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k436 in a429 in k426 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:74: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_386,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_389,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:75: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),t2);}

/* k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_398,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)C_TARGET_CC),C_fix(0));}

/* k422 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_string_equal_p(t1,lf[12]))){
/* chicken-bug.scm:76: feature? */
((C_proc3)C_retrieve_symbol_proc(lf[13]))(3,*((C_word*)lf[13]+1),((C_word*)t0)[2],lf[14]);}
else{
t2=((C_word*)t0)[2];
f_398(2,t2,C_SCHEME_FALSE);}}

/* k396 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:77: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[10]+1)))(3,*((C_word*)lf[10]+1),t2,lf[11]);}
else{
/* chicken-bug.scm:81: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}}

/* k399 in k396 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_406,tmp=(C_word)a,a+=2,tmp);
/* chicken-bug.scm:78: with-input-from-pipe */
((C_proc4)C_retrieve_symbol_proc(lf[8]))(4,*((C_word*)lf[8]+1),((C_word*)t0)[2],lf[9],t2);}

/* a405 in k399 in k396 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_414,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:80: read-all */
((C_proc2)C_retrieve_symbol_proc(lf[7]))(2,*((C_word*)lf[7]+1),t2);}

/* k412 in a405 in k399 in k396 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:80: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),((C_word*)t0)[2],t1);}

/* k390 in k387 in k384 in k381 in k378 in k375 in k372 in k369 in k366 in k363 in k360 in k357 in k354 in k351 in k348 in k345 in k342 in k339 in k336 in k333 in k330 in k327 in k324 in k321 in collect-info in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:81: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[5]+1)))(2,*((C_word*)lf[5]+1),((C_word*)t0)[2]);}

/* user-id in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_317,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* chicken-bug.scm:47: current-user-id */
((C_proc2)C_retrieve_symbol_proc(lf[2]))(2,*((C_word*)lf[2]+1),t2);}

/* k315 in user-id in k301 in k298 in k295 in k292 in k289 in k286 in k283 in k280 */
static void C_ccall f_317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* chicken-bug.scm:47: user-information */
((C_proc3)C_retrieve_symbol_proc(lf[1]))(3,*((C_word*)lf[1]+1),((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[182] = {
{"toplevel:chicken_bug_scm",(void*)C_toplevel},
{"f_282:chicken_bug_scm",(void*)f_282},
{"f_285:chicken_bug_scm",(void*)f_285},
{"f_288:chicken_bug_scm",(void*)f_288},
{"f_291:chicken_bug_scm",(void*)f_291},
{"f_294:chicken_bug_scm",(void*)f_294},
{"f_297:chicken_bug_scm",(void*)f_297},
{"f_300:chicken_bug_scm",(void*)f_300},
{"f_303:chicken_bug_scm",(void*)f_303},
{"f_1373:chicken_bug_scm",(void*)f_1373},
{"f_1363:chicken_bug_scm",(void*)f_1363},
{"f_1369:chicken_bug_scm",(void*)f_1369},
{"f_1366:chicken_bug_scm",(void*)f_1366},
{"f_1249:chicken_bug_scm",(void*)f_1249},
{"f_1255:chicken_bug_scm",(void*)f_1255},
{"f_1261:chicken_bug_scm",(void*)f_1261},
{"f_1271:chicken_bug_scm",(void*)f_1271},
{"f_1292:chicken_bug_scm",(void*)f_1292},
{"f_1298:chicken_bug_scm",(void*)f_1298},
{"f_1360:chicken_bug_scm",(void*)f_1360},
{"f_1302:chicken_bug_scm",(void*)f_1302},
{"f_1356:chicken_bug_scm",(void*)f_1356},
{"f_1305:chicken_bug_scm",(void*)f_1305},
{"f_1352:chicken_bug_scm",(void*)f_1352},
{"f_1308:chicken_bug_scm",(void*)f_1308},
{"f_1348:chicken_bug_scm",(void*)f_1348},
{"f_1311:chicken_bug_scm",(void*)f_1311},
{"f_1344:chicken_bug_scm",(void*)f_1344},
{"f_1314:chicken_bug_scm",(void*)f_1314},
{"f_1340:chicken_bug_scm",(void*)f_1340},
{"f_1336:chicken_bug_scm",(void*)f_1336},
{"f_1317:chicken_bug_scm",(void*)f_1317},
{"f_1320:chicken_bug_scm",(void*)f_1320},
{"f_1323:chicken_bug_scm",(void*)f_1323},
{"f_1326:chicken_bug_scm",(void*)f_1326},
{"f_1329:chicken_bug_scm",(void*)f_1329},
{"f_1286:chicken_bug_scm",(void*)f_1286},
{"f_1274:chicken_bug_scm",(void*)f_1274},
{"f_1277:chicken_bug_scm",(void*)f_1277},
{"f_1228:chicken_bug_scm",(void*)f_1228},
{"f_1238:chicken_bug_scm",(void*)f_1238},
{"f_1241:chicken_bug_scm",(void*)f_1241},
{"f_1159:chicken_bug_scm",(void*)f_1159},
{"f_1174:chicken_bug_scm",(void*)f_1174},
{"f_1204:chicken_bug_scm",(void*)f_1204},
{"f_1216:chicken_bug_scm",(void*)f_1216},
{"f_1222:chicken_bug_scm",(void*)f_1222},
{"f_1210:chicken_bug_scm",(void*)f_1210},
{"f_1180:chicken_bug_scm",(void*)f_1180},
{"f_1186:chicken_bug_scm",(void*)f_1186},
{"f_1193:chicken_bug_scm",(void*)f_1193},
{"f_1196:chicken_bug_scm",(void*)f_1196},
{"f_1163:chicken_bug_scm",(void*)f_1163},
{"f_1166:chicken_bug_scm",(void*)f_1166},
{"f_1073:chicken_bug_scm",(void*)f_1073},
{"f_1105:chicken_bug_scm",(void*)f_1105},
{"f_1135:chicken_bug_scm",(void*)f_1135},
{"f_1147:chicken_bug_scm",(void*)f_1147},
{"f_1153:chicken_bug_scm",(void*)f_1153},
{"f_1141:chicken_bug_scm",(void*)f_1141},
{"f_1111:chicken_bug_scm",(void*)f_1111},
{"f_1117:chicken_bug_scm",(void*)f_1117},
{"f_1124:chicken_bug_scm",(void*)f_1124},
{"f_1127:chicken_bug_scm",(void*)f_1127},
{"f_1077:chicken_bug_scm",(void*)f_1077},
{"f_1080:chicken_bug_scm",(void*)f_1080},
{"f_1096:chicken_bug_scm",(void*)f_1096},
{"f_1055:chicken_bug_scm",(void*)f_1055},
{"f_1071:chicken_bug_scm",(void*)f_1071},
{"f_1067:chicken_bug_scm",(void*)f_1067},
{"f_1063:chicken_bug_scm",(void*)f_1063},
{"f_867:chicken_bug_scm",(void*)f_867},
{"f_878:chicken_bug_scm",(void*)f_878},
{"f_1010:chicken_bug_scm",(void*)f_1010},
{"f_882:chicken_bug_scm",(void*)f_882},
{"f_889:chicken_bug_scm",(void*)f_889},
{"f_893:chicken_bug_scm",(void*)f_893},
{"f_925:chicken_bug_scm",(void*)f_925},
{"f_897:chicken_bug_scm",(void*)f_897},
{"f_917:chicken_bug_scm",(void*)f_917},
{"f_901:chicken_bug_scm",(void*)f_901},
{"f_909:chicken_bug_scm",(void*)f_909},
{"f_905:chicken_bug_scm",(void*)f_905},
{"f_826:chicken_bug_scm",(void*)f_826},
{"f_851:chicken_bug_scm",(void*)f_851},
{"f_844:chicken_bug_scm",(void*)f_844},
{"f_836:chicken_bug_scm",(void*)f_836},
{"f_839:chicken_bug_scm",(void*)f_839},
{"f_680:chicken_bug_scm",(void*)f_680},
{"f_761:chicken_bug_scm",(void*)f_761},
{"f_813:chicken_bug_scm",(void*)f_813},
{"f_769:chicken_bug_scm",(void*)f_769},
{"f_810:chicken_bug_scm",(void*)f_810},
{"f_806:chicken_bug_scm",(void*)f_806},
{"f1465:chicken_bug_scm",(void*)f1465},
{"f_785:chicken_bug_scm",(void*)f_785},
{"f_781:chicken_bug_scm",(void*)f_781},
{"f_684:chicken_bug_scm",(void*)f_684},
{"f_759:chicken_bug_scm",(void*)f_759},
{"f_755:chicken_bug_scm",(void*)f_755},
{"f_687:chicken_bug_scm",(void*)f_687},
{"f_690:chicken_bug_scm",(void*)f_690},
{"f_751:chicken_bug_scm",(void*)f_751},
{"f_693:chicken_bug_scm",(void*)f_693},
{"f_743:chicken_bug_scm",(void*)f_743},
{"f_747:chicken_bug_scm",(void*)f_747},
{"f_718:chicken_bug_scm",(void*)f_718},
{"f_722:chicken_bug_scm",(void*)f_722},
{"f_728:chicken_bug_scm",(void*)f_728},
{"f_732:chicken_bug_scm",(void*)f_732},
{"f_726:chicken_bug_scm",(void*)f_726},
{"f_708:chicken_bug_scm",(void*)f_708},
{"f_661:chicken_bug_scm",(void*)f_661},
{"f_665:chicken_bug_scm",(void*)f_665},
{"f_614:chicken_bug_scm",(void*)f_614},
{"f_659:chicken_bug_scm",(void*)f_659},
{"f_652:chicken_bug_scm",(void*)f_652},
{"f_618:chicken_bug_scm",(void*)f_618},
{"f_623:chicken_bug_scm",(void*)f_623},
{"f_627:chicken_bug_scm",(void*)f_627},
{"f_605:chicken_bug_scm",(void*)f_605},
{"f_609:chicken_bug_scm",(void*)f_609},
{"f_319:chicken_bug_scm",(void*)f_319},
{"f_323:chicken_bug_scm",(void*)f_323},
{"f_326:chicken_bug_scm",(void*)f_326},
{"f_603:chicken_bug_scm",(void*)f_603},
{"f_599:chicken_bug_scm",(void*)f_599},
{"f_329:chicken_bug_scm",(void*)f_329},
{"f_332:chicken_bug_scm",(void*)f_332},
{"f1458:chicken_bug_scm",(void*)f1458},
{"f_595:chicken_bug_scm",(void*)f_595},
{"f_335:chicken_bug_scm",(void*)f_335},
{"f_338:chicken_bug_scm",(void*)f_338},
{"f_341:chicken_bug_scm",(void*)f_341},
{"f_344:chicken_bug_scm",(void*)f_344},
{"f_591:chicken_bug_scm",(void*)f_591},
{"f_347:chicken_bug_scm",(void*)f_347},
{"f_587:chicken_bug_scm",(void*)f_587},
{"f_350:chicken_bug_scm",(void*)f_350},
{"f_583:chicken_bug_scm",(void*)f_583},
{"f_353:chicken_bug_scm",(void*)f_353},
{"f_579:chicken_bug_scm",(void*)f_579},
{"f_356:chicken_bug_scm",(void*)f_356},
{"f_575:chicken_bug_scm",(void*)f_575},
{"f_359:chicken_bug_scm",(void*)f_359},
{"f_571:chicken_bug_scm",(void*)f_571},
{"f_362:chicken_bug_scm",(void*)f_362},
{"f_365:chicken_bug_scm",(void*)f_365},
{"f_368:chicken_bug_scm",(void*)f_368},
{"f_371:chicken_bug_scm",(void*)f_371},
{"f_374:chicken_bug_scm",(void*)f_374},
{"f_377:chicken_bug_scm",(void*)f_377},
{"f_534:chicken_bug_scm",(void*)f_534},
{"f_563:chicken_bug_scm",(void*)f_563},
{"f_532:chicken_bug_scm",(void*)f_532},
{"f_528:chicken_bug_scm",(void*)f_528},
{"f_446:chicken_bug_scm",(void*)f_446},
{"f_448:chicken_bug_scm",(void*)f_448},
{"f_460:chicken_bug_scm",(void*)f_460},
{"f_465:chicken_bug_scm",(void*)f_465},
{"f_477:chicken_bug_scm",(void*)f_477},
{"f_488:chicken_bug_scm",(void*)f_488},
{"f_484:chicken_bug_scm",(void*)f_484},
{"f_499:chicken_bug_scm",(void*)f_499},
{"f_513:chicken_bug_scm",(void*)f_513},
{"f_380:chicken_bug_scm",(void*)f_380},
{"f_383:chicken_bug_scm",(void*)f_383},
{"f_442:chicken_bug_scm",(void*)f_442},
{"f_428:chicken_bug_scm",(void*)f_428},
{"f_430:chicken_bug_scm",(void*)f_430},
{"f_438:chicken_bug_scm",(void*)f_438},
{"f_386:chicken_bug_scm",(void*)f_386},
{"f_389:chicken_bug_scm",(void*)f_389},
{"f_424:chicken_bug_scm",(void*)f_424},
{"f_398:chicken_bug_scm",(void*)f_398},
{"f_401:chicken_bug_scm",(void*)f_401},
{"f_406:chicken_bug_scm",(void*)f_406},
{"f_414:chicken_bug_scm",(void*)f_414},
{"f_392:chicken_bug_scm",(void*)f_392},
{"f_309:chicken_bug_scm",(void*)f_309},
{"f_317:chicken_bug_scm",(void*)f_317},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
