/* Generated from srfi-4.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: srfi-4.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file srfi-4.c
   unit: srfi_4
*/

#include "chicken.h"

#define C_copy_subvector(to, from, start_to, start_from, bytes)   \
  (C_memcpy((C_char *)C_data_pointer(to) + C_unfix(start_to), (C_char *)C_data_pointer(from) + C_unfix(start_from), C_unfix(bytes)), \
    C_SCHEME_UNDEFINED)

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[170];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,99,104,101,99,107,45,101,120,97,99,116,45,105,110,116,101,114,118,97,108,32,110,54,49,32,102,114,111,109,54,50,32,116,111,54,51,32,108,111,99,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,54,57,41,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,49,41,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,51,41,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,53,41,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,55,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,55,57,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,108,101,110,103,116,104,32,120,56,51,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,27),40,117,56,118,101,99,116,111,114,45,115,101,116,33,32,120,56,53,32,105,56,54,32,121,56,55,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,30),40,115,56,118,101,99,116,111,114,45,115,101,116,33,32,120,49,48,50,32,105,49,48,51,32,121,49,48,52,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,31),40,117,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,49,56,32,105,49,49,57,32,121,49,50,48,41,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,31),40,115,49,54,118,101,99,116,111,114,45,115,101,116,33,32,120,49,51,53,32,105,49,51,54,32,121,49,51,55,41,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,31),40,117,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,53,49,32,105,49,53,50,32,121,49,53,51,41,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,31),40,115,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,55,49,32,105,49,55,50,32,121,49,55,51,41,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,31),40,102,51,50,118,101,99,116,111,114,45,115,101,116,33,32,120,49,56,56,32,105,49,56,57,32,121,49,57,48,41,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,31),40,102,54,52,118,101,99,116,111,114,45,115,101,116,33,32,120,50,48,52,32,105,50,48,53,32,121,50,48,54,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,18),40,101,120,116,45,102,114,101,101,32,97,51,51,56,51,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,29),40,97,108,108,111,99,32,108,111,99,51,52,51,32,108,101,110,51,52,52,32,101,120,116,63,51,52,53,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,28),40,114,101,108,101,97,115,101,45,110,117,109,98,101,114,45,118,101,99,116,111,114,32,118,51,53,50,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,51,55,57,41,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,33),40,98,111,100,121,51,54,53,32,105,110,105,116,51,55,52,32,101,120,116,63,51,55,53,32,102,105,110,63,51,55,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,37),40,100,101,102,45,102,105,110,63,51,54,57,32,37,105,110,105,116,51,54,50,51,56,56,32,37,101,120,116,63,51,54,51,51,56,57,41,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,51,54,56,32,37,105,110,105,116,51,54,50,51,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,51,54,55,41,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,117,56,118,101,99,116,111,114,32,108,101,110,51,54,48,32,46,32,116,109,112,51,53,57,51,54,49,41,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,50,53,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,49,49,32,105,110,105,116,52,50,48,32,101,120,116,63,52,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,49,53,32,37,105,110,105,116,52,48,56,52,51,52,32,37,101,120,116,63,52,48,57,52,51,53,41,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,49,52,32,37,105,110,105,116,52,48,56,52,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,49,51,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,34),40,109,97,107,101,45,115,56,118,101,99,116,111,114,32,108,101,110,52,48,54,32,46,32,116,109,112,52,48,53,52,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,52,55,48,41,0,0,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,52,53,54,32,105,110,105,116,52,54,53,32,101,120,116,63,52,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,52,54,48,32,37,105,110,105,116,52,53,51,52,55,57,32,37,101,120,116,63,52,53,52,52,56,48,41,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,52,53,57,32,37,105,110,105,116,52,53,51,52,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,52,53,56,41,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,49,54,118,101,99,116,111,114,32,108,101,110,52,53,49,32,46,32,116,109,112,52,53,48,52,53,50,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,49,53,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,48,49,32,105,110,105,116,53,49,48,32,101,120,116,63,53,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,48,53,32,37,105,110,105,116,52,57,56,53,50,52,32,37,101,120,116,63,52,57,57,53,50,53,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,48,52,32,37,105,110,105,116,52,57,56,53,50,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,48,51,41,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,49,54,118,101,99,116,111,114,32,108,101,110,52,57,54,32,46,32,116,109,112,52,57,53,52,57,55,41,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,54,48,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,52,54,32,105,110,105,116,53,53,53,32,101,120,116,63,53,53,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,53,48,32,37,105,110,105,116,53,52,51,53,54,57,32,37,101,120,116,63,53,52,52,53,55,48,41,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,52,57,32,37,105,110,105,116,53,52,51,53,55,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,52,56,41,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,117,51,50,118,101,99,116,111,114,32,108,101,110,53,52,49,32,46,32,116,109,112,53,52,48,53,52,50,41,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,48,53,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,53,57,49,32,105,110,105,116,54,48,48,32,101,120,116,63,54,48,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,53,57,53,32,37,105,110,105,116,53,56,56,54,49,52,32,37,101,120,116,63,53,56,57,54,49,53,41,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,53,57,52,32,37,105,110,105,116,53,56,56,54,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,53,57,51,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,115,51,50,118,101,99,116,111,114,32,108,101,110,53,56,54,32,46,32,116,109,112,53,56,53,53,56,55,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,53,48,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,51,54,32,105,110,105,116,54,52,53,32,101,120,116,63,54,52,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,54,52,48,32,37,105,110,105,116,54,51,51,54,54,48,32,37,101,120,116,63,54,51,52,54,54,49,41,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,54,51,57,32,37,105,110,105,116,54,51,51,54,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,54,51,56,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,51,50,118,101,99,116,111,114,32,108,101,110,54,51,49,32,46,32,116,109,112,54,51,48,54,51,50,41,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,54,57,54,41,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,25),40,98,111,100,121,54,56,50,32,105,110,105,116,54,57,49,32,101,120,116,63,54,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,36),40,100,101,102,45,102,105,110,54,56,54,32,37,105,110,105,116,54,55,57,55,48,54,32,37,101,120,116,63,54,56,48,55,48,55,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,101,120,116,63,54,56,53,32,37,105,110,105,116,54,55,57,55,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,105,110,105,116,54,56,52,41,0,0,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,102,54,52,118,101,99,116,111,114,32,108,101,110,54,55,55,32,46,32,116,109,112,54,55,54,54,55,56,41,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,52,48,32,112,55,52,50,32,105,55,52,51,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,117,56,118,101,99,116,111,114,32,108,115,116,55,51,55,41,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,53,50,32,112,55,53,52,32,105,55,53,53,41,0,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,23),40,108,105,115,116,45,62,115,56,118,101,99,116,111,114,32,108,115,116,55,52,57,41,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,54,52,32,112,55,54,54,32,105,55,54,55,41,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,49,54,118,101,99,116,111,114,32,108,115,116,55,54,49,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,55,54,32,112,55,55,56,32,105,55,55,57,41,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,49,54,118,101,99,116,111,114,32,108,115,116,55,55,51,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,55,56,56,32,112,55,57,48,32,105,55,57,49,41,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,117,51,50,118,101,99,116,111,114,32,108,115,116,55,56,53,41};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,56,48,48,32,112,56,48,50,32,105,56,48,51,41,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,115,51,50,118,101,99,116,111,114,32,108,115,116,55,57,55,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,56,49,50,32,112,56,49,52,32,105,56,49,53,41,0,0,0};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,51,50,118,101,99,116,111,114,32,108,115,116,56,48,57,41};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,21),40,100,111,108,111,111,112,56,50,52,32,112,56,50,54,32,105,56,50,55,41,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,24),40,108,105,115,116,45,62,102,54,52,118,101,99,116,111,114,32,108,115,116,56,50,49,41};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,18),40,117,56,118,101,99,116,111,114,32,46,32,120,115,56,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,18),40,115,56,118,101,99,116,111,114,32,46,32,120,115,56,51,51,41,0,0,0,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,19),40,117,49,54,118,101,99,116,111,114,32,46,32,120,115,56,51,52,41,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,19),40,115,49,54,118,101,99,116,111,114,32,46,32,120,115,56,51,53,41,0,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,19),40,117,51,50,118,101,99,116,111,114,32,46,32,120,115,56,51,54,41,0,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,19),40,115,51,50,118,101,99,116,111,114,32,46,32,120,115,56,51,55,41,0,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,19),40,102,51,50,118,101,99,116,111,114,32,46,32,120,115,56,51,56,41,0,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,19),40,102,54,52,118,101,99,116,111,114,32,46,32,120,115,56,51,57,41,0,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,53,56,41,0,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,21),40,117,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,53,53,41,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,54,52,41,0,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,21),40,115,56,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,54,49,41,0,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,55,48,41,0,0,0,0,0};
static C_char C_TLS li97[] C_aligned={C_lihdr(0,0,22),40,117,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,54,55,41,0,0};
static C_char C_TLS li98[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,55,54,41,0,0,0,0,0};
static C_char C_TLS li99[] C_aligned={C_lihdr(0,0,22),40,115,49,54,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,55,51,41,0,0};
static C_char C_TLS li100[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,56,50,41,0,0,0,0,0};
static C_char C_TLS li101[] C_aligned={C_lihdr(0,0,22),40,117,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,55,57,41,0,0};
static C_char C_TLS li102[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,56,56,41,0,0,0,0,0};
static C_char C_TLS li103[] C_aligned={C_lihdr(0,0,22),40,115,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,56,53,41,0,0};
static C_char C_TLS li104[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,56,57,52,41,0,0,0,0,0};
static C_char C_TLS li105[] C_aligned={C_lihdr(0,0,22),40,102,51,50,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,57,49,41,0,0};
static C_char C_TLS li106[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,57,48,48,41,0,0,0,0,0};
static C_char C_TLS li107[] C_aligned={C_lihdr(0,0,22),40,102,54,52,118,101,99,116,111,114,45,62,108,105,115,116,32,118,56,57,55,41,0,0};
static C_char C_TLS li108[] C_aligned={C_lihdr(0,0,16),40,117,56,118,101,99,116,111,114,63,32,120,57,48,51,41};
static C_char C_TLS li109[] C_aligned={C_lihdr(0,0,16),40,115,56,118,101,99,116,111,114,63,32,120,57,48,52,41};
static C_char C_TLS li110[] C_aligned={C_lihdr(0,0,17),40,117,49,54,118,101,99,116,111,114,63,32,120,57,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li111[] C_aligned={C_lihdr(0,0,17),40,115,49,54,118,101,99,116,111,114,63,32,120,57,48,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li112[] C_aligned={C_lihdr(0,0,17),40,117,51,50,118,101,99,116,111,114,63,32,120,57,48,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li113[] C_aligned={C_lihdr(0,0,17),40,115,51,50,118,101,99,116,111,114,63,32,120,57,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li114[] C_aligned={C_lihdr(0,0,17),40,102,51,50,118,101,99,116,111,114,63,32,120,57,48,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li115[] C_aligned={C_lihdr(0,0,17),40,102,54,52,118,101,99,116,111,114,63,32,120,57,49,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li116[] C_aligned={C_lihdr(0,0,13),40,102,95,51,50,56,49,32,118,57,49,55,41,0,0,0};
static C_char C_TLS li117[] C_aligned={C_lihdr(0,0,25),40,112,97,99,107,45,99,111,112,121,32,116,97,103,57,49,53,32,108,111,99,57,49,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li118[] C_aligned={C_lihdr(0,0,15),40,102,95,51,50,57,57,32,115,116,114,57,50,52,41,0};
static C_char C_TLS li119[] C_aligned={C_lihdr(0,0,28),40,117,110,112,97,99,107,32,116,97,103,57,50,49,32,115,122,57,50,50,32,108,111,99,57,50,51,41,0,0,0,0};
static C_char C_TLS li120[] C_aligned={C_lihdr(0,0,15),40,102,95,51,51,50,56,32,115,116,114,57,51,51,41,0};
static C_char C_TLS li121[] C_aligned={C_lihdr(0,0,33),40,117,110,112,97,99,107,45,99,111,112,121,32,116,97,103,57,51,48,32,115,122,57,51,49,32,108,111,99,57,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li122[] C_aligned={C_lihdr(0,0,16),40,102,53,49,55,49,32,118,57,49,51,53,49,55,48,41};
static C_char C_TLS li123[] C_aligned={C_lihdr(0,0,16),40,102,53,49,54,52,32,118,57,49,51,53,49,54,51,41};
static C_char C_TLS li124[] C_aligned={C_lihdr(0,0,16),40,102,53,49,53,55,32,118,57,49,51,53,49,53,54,41};
static C_char C_TLS li125[] C_aligned={C_lihdr(0,0,16),40,102,53,49,53,48,32,118,57,49,51,53,49,52,57,41};
static C_char C_TLS li126[] C_aligned={C_lihdr(0,0,16),40,102,53,49,52,51,32,118,57,49,51,53,49,52,50,41};
static C_char C_TLS li127[] C_aligned={C_lihdr(0,0,16),40,102,53,49,51,54,32,118,57,49,51,53,49,51,53,41};
static C_char C_TLS li128[] C_aligned={C_lihdr(0,0,16),40,102,53,49,50,57,32,118,57,49,51,53,49,50,56,41};
static C_char C_TLS li129[] C_aligned={C_lihdr(0,0,16),40,102,53,49,50,50,32,118,57,49,51,53,49,50,49,41};
static C_char C_TLS li130[] C_aligned={C_lihdr(0,0,11),40,103,57,53,54,32,99,57,53,56,41,0,0,0,0,0};
static C_char C_TLS li131[] C_aligned={C_lihdr(0,0,38),40,35,35,115,121,115,35,117,115,101,114,45,114,101,97,100,45,104,111,111,107,32,99,104,97,114,57,52,51,32,112,111,114,116,57,52,52,41,0,0};
static C_char C_TLS li132[] C_aligned={C_lihdr(0,0,48),40,35,35,115,121,115,35,117,115,101,114,45,112,114,105,110,116,45,104,111,111,107,32,120,57,54,50,32,114,101,97,100,97,98,108,101,57,54,51,32,112,111,114,116,57,54,52,41};
static C_char C_TLS li133[] C_aligned={C_lihdr(0,0,48),40,115,117,98,118,101,99,116,111,114,32,118,57,55,54,32,116,57,55,55,32,101,115,57,55,56,32,102,114,111,109,57,55,57,32,116,111,57,56,48,32,108,111,99,57,56,49,41};
static C_char C_TLS li134[] C_aligned={C_lihdr(0,0,35),40,115,117,98,117,56,118,101,99,116,111,114,32,118,49,48,49,49,32,102,114,111,109,49,48,49,50,32,116,111,49,48,49,51,41,0,0,0,0,0};
static C_char C_TLS li135[] C_aligned={C_lihdr(0,0,36),40,115,117,98,117,49,54,118,101,99,116,111,114,32,118,49,48,49,52,32,102,114,111,109,49,48,49,53,32,116,111,49,48,49,54,41,0,0,0,0};
static C_char C_TLS li136[] C_aligned={C_lihdr(0,0,36),40,115,117,98,117,51,50,118,101,99,116,111,114,32,118,49,48,49,55,32,102,114,111,109,49,48,49,56,32,116,111,49,48,49,57,41,0,0,0,0};
static C_char C_TLS li137[] C_aligned={C_lihdr(0,0,35),40,115,117,98,115,56,118,101,99,116,111,114,32,118,49,48,50,48,32,102,114,111,109,49,48,50,49,32,116,111,49,48,50,50,41,0,0,0,0,0};
static C_char C_TLS li138[] C_aligned={C_lihdr(0,0,36),40,115,117,98,115,49,54,118,101,99,116,111,114,32,118,49,48,50,51,32,102,114,111,109,49,48,50,52,32,116,111,49,48,50,53,41,0,0,0,0};
static C_char C_TLS li139[] C_aligned={C_lihdr(0,0,36),40,115,117,98,115,51,50,118,101,99,116,111,114,32,118,49,48,50,54,32,102,114,111,109,49,48,50,55,32,116,111,49,48,50,56,41,0,0,0,0};
static C_char C_TLS li140[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,51,50,118,101,99,116,111,114,32,118,49,48,50,57,32,102,114,111,109,49,48,51,48,32,116,111,49,48,51,49,41,0,0,0,0};
static C_char C_TLS li141[] C_aligned={C_lihdr(0,0,36),40,115,117,98,102,54,52,118,101,99,116,111,114,32,118,49,48,51,50,32,102,114,111,109,49,48,51,51,32,116,111,49,48,51,52,41,0,0,0,0};
static C_char C_TLS li142[] C_aligned={C_lihdr(0,0,18),40,100,111,108,111,111,112,49,48,53,56,32,105,49,48,54,48,41,0,0,0,0,0,0};
static C_char C_TLS li143[] C_aligned={C_lihdr(0,0,35),40,98,111,100,121,49,48,52,54,32,112,111,114,116,49,48,53,53,32,102,114,111,109,49,48,53,54,32,116,111,49,48,53,55,41,0,0,0,0,0};
static C_char C_TLS li144[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,49,48,53,48,32,37,112,111,114,116,49,48,52,51,49,48,54,54,32,37,102,114,111,109,49,48,52,52,49,48,54,55,41};
static C_char C_TLS li145[] C_aligned={C_lihdr(0,0,28),40,100,101,102,45,102,114,111,109,49,48,52,57,32,37,112,111,114,116,49,48,52,51,49,48,54,57,41,0,0,0,0};
static C_char C_TLS li146[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,112,111,114,116,49,48,52,56,41,0,0};
static C_char C_TLS li147[] C_aligned={C_lihdr(0,0,36),40,119,114,105,116,101,45,117,56,118,101,99,116,111,114,32,118,49,48,52,49,32,46,32,116,109,112,49,48,52,48,49,48,52,50,41,0,0,0,0};
static C_char C_TLS li148[] C_aligned={C_lihdr(0,0,29),40,98,111,100,121,49,48,56,56,32,112,111,114,116,49,48,57,54,32,115,116,97,114,116,49,48,57,55,41,0,0,0};
static C_char C_TLS li149[] C_aligned={C_lihdr(0,0,29),40,100,101,102,45,115,116,97,114,116,49,48,57,49,32,37,112,111,114,116,49,48,56,54,49,49,48,53,41,0,0,0};
static C_char C_TLS li150[] C_aligned={C_lihdr(0,0,14),40,100,101,102,45,112,111,114,116,49,48,57,48,41,0,0};
static C_char C_TLS li151[] C_aligned={C_lihdr(0,0,45),40,114,101,97,100,45,117,56,118,101,99,116,111,114,33,32,110,49,48,56,51,32,100,101,115,116,49,48,56,52,32,46,32,116,109,112,49,48,56,50,49,48,56,53,41,0,0,0};
static C_char C_TLS li152[] C_aligned={C_lihdr(0,0,20),40,119,114,97,112,32,115,116,114,49,49,49,50,32,110,49,49,49,51,41,0,0,0,0};
static C_char C_TLS li153[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li154[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,49,49,50,54,32,110,49,49,51,52,32,112,49,49,51,53,41,0,0};
static C_char C_TLS li155[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,49,49,50,57,32,37,110,49,49,50,52,49,49,53,50,41,0,0};
static C_char C_TLS li156[] C_aligned={C_lihdr(0,0,11),40,100,101,102,45,110,49,49,50,56,41,0,0,0,0,0};
static C_char C_TLS li157[] C_aligned={C_lihdr(0,0,29),40,114,101,97,100,45,117,56,118,101,99,116,111,114,32,46,32,116,109,112,49,49,50,50,49,49,50,51,41,0,0,0};
static C_char C_TLS li158[] C_aligned={C_lihdr(0,0,17),40,97,52,49,56,51,32,120,51,49,56,32,105,51,49,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li159[] C_aligned={C_lihdr(0,0,17),40,97,52,50,49,50,32,120,51,48,52,32,105,51,48,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li160[] C_aligned={C_lihdr(0,0,17),40,97,52,50,52,49,32,120,50,57,48,32,105,50,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li161[] C_aligned={C_lihdr(0,0,17),40,97,52,50,55,48,32,120,50,55,54,32,105,50,55,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li162[] C_aligned={C_lihdr(0,0,17),40,97,52,50,57,57,32,120,50,54,50,32,105,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li163[] C_aligned={C_lihdr(0,0,17),40,97,52,51,50,56,32,120,50,52,56,32,105,50,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li164[] C_aligned={C_lihdr(0,0,17),40,97,52,51,53,55,32,120,50,51,52,32,105,50,51,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li165[] C_aligned={C_lihdr(0,0,17),40,97,52,51,56,54,32,120,50,50,48,32,105,50,50,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li166[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub339(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub339(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word bv=(C_word )(C_a0);
C_free((void *)C_block_item(bv, 1));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub334(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub334(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int bytes=(int )C_unfix(C_a0);
C_word *buf = (C_word *)C_malloc(bytes + sizeof(C_header));if(buf == NULL) C_return(C_SCHEME_FALSE);C_block_header(buf) = C_make_header(C_BYTEVECTOR_TYPE, bytes);C_return(buf);
C_ret:
#undef return

return C_r;}

C_noret_decl(C_srfi_4_toplevel)
C_externexport void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4387)
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4414)
static void C_ccall f_4414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1652)
static void C_ccall f_1652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4358)
static void C_ccall f_4358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4385)
static void C_ccall f_4385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4356)
static void C_ccall f_4356(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1660)
static void C_ccall f_1660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4300)
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1664)
static void C_ccall f_1664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4271)
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1668)
static void C_ccall f_1668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4242)
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4269)
static void C_ccall f_4269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1676)
static void C_ccall f_1676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4184)
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4211)
static void C_ccall f_4211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1680)
static void C_ccall f_1680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3392)
static void C_ccall f_3392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3396)
static void C_ccall f_3396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3400)
static void C_ccall f_3400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3404)
static void C_ccall f_3404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3408)
static void C_ccall f_3408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3412)
static void C_ccall f_3412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3416)
static void C_ccall f_3416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3420)
static void C_ccall f_3420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3424)
static void C_ccall f_3424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3428)
static void C_ccall f_3428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3432)
static void C_ccall f_3432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3444)
static void C_ccall f_3444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3448)
static void C_ccall f_3448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3452)
static void C_ccall f_3452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3468)
static void C_ccall f_3468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4064)
static void C_ccall f_4064r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4133)
static void C_fcall f_4133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_fcall f_4128(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4066)
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4097)
static void C_ccall f_4097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4102)
static void C_fcall f_4102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4106)
static void C_ccall f_4106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4079)
static void C_ccall f_4079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_fcall f_4055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4006)
static void C_fcall f_4006(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3960)
static void C_ccall f_3960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3891)
static void C_fcall f_3891(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3886)
static void C_fcall f_3886(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3877)
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3843)
static void C_fcall f_3843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3850)
static void C_ccall f_3850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_fcall f_3855(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3835)
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3829)
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3823)
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3817)
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3805)
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3799)
static void C_ccall f_3799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3710)
static void C_fcall f_3710(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_3743)
static void C_ccall f_3743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_ccall f_3766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3772)
static void C_ccall f_3772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3563)
static void C_ccall f_3563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3489)
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3518)
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3529)
static void C_ccall f_3529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5122)
static void C_ccall f5122(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5129)
static void C_ccall f5129(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5136)
static void C_ccall f5136(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5143)
static void C_ccall f5143(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5150)
static void C_ccall f5150(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5157)
static void C_ccall f5157(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5164)
static void C_ccall f5164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f5171)
static void C_ccall f5171(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3326)
static void C_fcall f_3326(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3328)
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3338)
static void C_ccall f_3338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_fcall f_3297(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3299)
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3279)
static void C_fcall f_3279(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3291)
static void C_ccall f_3291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3256)
static void C_ccall f_3256(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3250)
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3238)
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3232)
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3226)
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3191)
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3200)
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3214)
static void C_ccall f_3214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3171)
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3185)
static void C_ccall f_3185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3142)
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_ccall f_3104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3113)
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3127)
static void C_ccall f_3127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3075)
static void C_ccall f_3075(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3084)
static void C_fcall f_3084(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3098)
static void C_ccall f_3098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3046)
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3055)
static void C_fcall f_3055(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3069)
static void C_ccall f_3069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3026)
static void C_fcall f_3026(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3040)
static void C_ccall f_3040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2997)
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2982)
static void C_ccall f_2982r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2976)
static void C_ccall f_2976r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2970)
static void C_ccall f_2970r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2964)
static void C_ccall f_2964r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2958)
static void C_ccall f_2958r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2952)
static void C_ccall f_2952r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2946)
static void C_ccall f_2946r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2907)
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2914)
static void C_ccall f_2914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2919)
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2926)
static void C_ccall f_2926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2874)
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_fcall f_2886(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2893)
static void C_ccall f_2893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2841)
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2848)
static void C_ccall f_2848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_fcall f_2853(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2860)
static void C_ccall f_2860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2820)
static void C_fcall f_2820(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2827)
static void C_ccall f_2827(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2775)
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_fcall f_2787(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2794)
static void C_ccall f_2794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2742)
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2749)
static void C_ccall f_2749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2754)
static void C_fcall f_2754(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2709)
static void C_ccall f_2709(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2721)
static void C_fcall f_2721(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2728)
static void C_ccall f_2728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2676)
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2683)
static void C_ccall f_2683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2688)
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2613)
static void C_fcall f_2613(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2557)
static void C_fcall f_2557(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2567)
static void C_ccall f_2567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_fcall f_2579(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static C_word C_fcall f_2584(C_word t0,C_word t1);
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2492)
static void C_fcall f_2492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2487)
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2482)
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2436)
static void C_fcall f_2436(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2481)
static void C_ccall f_2481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2458)
static void C_fcall f_2458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static C_word C_fcall f_2463(C_word t0,C_word t1);
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2371)
static void C_fcall f_2371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2361)
static void C_fcall f_2361(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2319)
static void C_fcall f_2319(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2360)
static void C_ccall f_2360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2329)
static void C_ccall f_2329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static C_word C_fcall f_2343(C_word t0,C_word t1);
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2254)
static void C_fcall f_2254(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2249)
static void C_fcall f_2249(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2244)
static void C_fcall f_2244(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static C_word C_fcall f_2226(C_word t0,C_word t1);
C_noret_decl(f_2083)
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2083)
static void C_ccall f_2083r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2137)
static void C_fcall f_2137(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2132)
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2127)
static void C_fcall f_2127(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2085)
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2109)
static C_word C_fcall f_2109(C_word t0,C_word t1);
C_noret_decl(f_1966)
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1966)
static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2020)
static void C_fcall f_2020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2015)
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2010)
static void C_fcall f_2010(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1968)
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2009)
static void C_ccall f_2009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1978)
static void C_ccall f_1978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1992)
static C_word C_fcall f_1992(C_word t0,C_word t1);
C_noret_decl(f_1849)
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1849)
static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1903)
static void C_fcall f_1903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_fcall f_1898(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1893)
static void C_fcall f_1893(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1851)
static void C_fcall f_1851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1892)
static void C_ccall f_1892(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_ccall f_1861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1870)
static void C_ccall f_1870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1875)
static C_word C_fcall f_1875(C_word t0,C_word t1);
C_noret_decl(f_1732)
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1732)
static void C_ccall f_1732r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1786)
static void C_fcall f_1786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1781)
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1776)
static void C_fcall f_1776(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1734)
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1744)
static void C_ccall f_1744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static C_word C_fcall f_1758(C_word t0,C_word t1);
C_noret_decl(f_1707)
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1714)
static void C_fcall f_1714(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_fcall f_1689(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1705)
static void C_ccall f_1705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1687)
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1644)
static void C_ccall f_1644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1608)
static void C_ccall f_1608(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1537)
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1544)
static void C_ccall f_1544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1547)
static void C_ccall f_1547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1483)
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1490)
static void C_ccall f_1490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1493)
static void C_ccall f_1493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1451)
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1481)
static void C_ccall f_1481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1410)
static void C_ccall f_1410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1443)
static void C_ccall f_1443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1337)
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1347)
static void C_ccall f_1347(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1370)
static void C_ccall f_1370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1313)
static void C_ccall f_1313(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1307)
static void C_ccall f_1307(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1295)
static void C_ccall f_1295(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1289)
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;

C_noret_decl(trf_4133)
static void C_fcall trf_4133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4133(t0,t1);}

C_noret_decl(trf_4128)
static void C_fcall trf_4128(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4128(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4128(t0,t1,t2);}

C_noret_decl(trf_4066)
static void C_fcall trf_4066(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4066(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4066(t0,t1,t2,t3);}

C_noret_decl(trf_4102)
static void C_fcall trf_4102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4102(t0,t1);}

C_noret_decl(trf_4055)
static void C_fcall trf_4055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4055(t0,t1,t2);}

C_noret_decl(trf_4006)
static void C_fcall trf_4006(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4006(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4006(t0,t1);}

C_noret_decl(trf_4001)
static void C_fcall trf_4001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4001(t0,t1,t2);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3956(t0,t1,t2,t3);}

C_noret_decl(trf_3891)
static void C_fcall trf_3891(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3891(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3891(t0,t1);}

C_noret_decl(trf_3886)
static void C_fcall trf_3886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3886(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3886(t0,t1,t2);}

C_noret_decl(trf_3877)
static void C_fcall trf_3877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3877(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3877(t0,t1,t2,t3);}

C_noret_decl(trf_3843)
static void C_fcall trf_3843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3843(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3843(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3855)
static void C_fcall trf_3855(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3855(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3855(t0,t1,t2);}

C_noret_decl(trf_3710)
static void C_fcall trf_3710(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3710(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_3710(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_3518)
static void C_fcall trf_3518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3518(t0,t1,t2);}

C_noret_decl(trf_3326)
static void C_fcall trf_3326(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3326(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3326(t0,t1,t2,t3);}

C_noret_decl(trf_3297)
static void C_fcall trf_3297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3297(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3297(t0,t1,t2,t3);}

C_noret_decl(trf_3279)
static void C_fcall trf_3279(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3279(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3279(t0,t1,t2);}

C_noret_decl(trf_3200)
static void C_fcall trf_3200(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3200(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3200(t0,t1,t2);}

C_noret_decl(trf_3171)
static void C_fcall trf_3171(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3171(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3171(t0,t1,t2);}

C_noret_decl(trf_3142)
static void C_fcall trf_3142(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3142(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3142(t0,t1,t2);}

C_noret_decl(trf_3113)
static void C_fcall trf_3113(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3113(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3113(t0,t1,t2);}

C_noret_decl(trf_3084)
static void C_fcall trf_3084(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3084(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3084(t0,t1,t2);}

C_noret_decl(trf_3055)
static void C_fcall trf_3055(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3055(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3055(t0,t1,t2);}

C_noret_decl(trf_3026)
static void C_fcall trf_3026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3026(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3026(t0,t1,t2);}

C_noret_decl(trf_2997)
static void C_fcall trf_2997(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2997(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2997(t0,t1,t2);}

C_noret_decl(trf_2919)
static void C_fcall trf_2919(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2919(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2919(t0,t1,t2,t3);}

C_noret_decl(trf_2886)
static void C_fcall trf_2886(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2886(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2886(t0,t1,t2,t3);}

C_noret_decl(trf_2853)
static void C_fcall trf_2853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2853(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2853(t0,t1,t2,t3);}

C_noret_decl(trf_2820)
static void C_fcall trf_2820(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2820(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2820(t0,t1,t2,t3);}

C_noret_decl(trf_2787)
static void C_fcall trf_2787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2787(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2787(t0,t1,t2,t3);}

C_noret_decl(trf_2754)
static void C_fcall trf_2754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2754(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2754(t0,t1,t2,t3);}

C_noret_decl(trf_2721)
static void C_fcall trf_2721(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2721(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2721(t0,t1,t2,t3);}

C_noret_decl(trf_2688)
static void C_fcall trf_2688(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2688(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2688(t0,t1,t2,t3);}

C_noret_decl(trf_2613)
static void C_fcall trf_2613(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2613(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2613(t0,t1);}

C_noret_decl(trf_2608)
static void C_fcall trf_2608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2608(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2608(t0,t1,t2);}

C_noret_decl(trf_2603)
static void C_fcall trf_2603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2603(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2603(t0,t1,t2,t3);}

C_noret_decl(trf_2557)
static void C_fcall trf_2557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2557(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2557(t0,t1,t2,t3);}

C_noret_decl(trf_2579)
static void C_fcall trf_2579(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2579(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2579(t0,t1);}

C_noret_decl(trf_2492)
static void C_fcall trf_2492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2492(t0,t1);}

C_noret_decl(trf_2487)
static void C_fcall trf_2487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2487(t0,t1,t2);}

C_noret_decl(trf_2482)
static void C_fcall trf_2482(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2482(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2482(t0,t1,t2,t3);}

C_noret_decl(trf_2436)
static void C_fcall trf_2436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2436(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2436(t0,t1,t2,t3);}

C_noret_decl(trf_2458)
static void C_fcall trf_2458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2458(t0,t1);}

C_noret_decl(trf_2371)
static void C_fcall trf_2371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2371(t0,t1);}

C_noret_decl(trf_2366)
static void C_fcall trf_2366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2366(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2366(t0,t1,t2);}

C_noret_decl(trf_2361)
static void C_fcall trf_2361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2361(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2361(t0,t1,t2,t3);}

C_noret_decl(trf_2319)
static void C_fcall trf_2319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2319(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2319(t0,t1,t2,t3);}

C_noret_decl(trf_2254)
static void C_fcall trf_2254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2254(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2254(t0,t1);}

C_noret_decl(trf_2249)
static void C_fcall trf_2249(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2249(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2249(t0,t1,t2);}

C_noret_decl(trf_2244)
static void C_fcall trf_2244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2244(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2244(t0,t1,t2,t3);}

C_noret_decl(trf_2202)
static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2202(t0,t1,t2,t3);}

C_noret_decl(trf_2137)
static void C_fcall trf_2137(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2137(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2137(t0,t1);}

C_noret_decl(trf_2132)
static void C_fcall trf_2132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2132(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2132(t0,t1,t2);}

C_noret_decl(trf_2127)
static void C_fcall trf_2127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2127(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2127(t0,t1,t2,t3);}

C_noret_decl(trf_2085)
static void C_fcall trf_2085(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2085(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2085(t0,t1,t2,t3);}

C_noret_decl(trf_2020)
static void C_fcall trf_2020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2020(t0,t1);}

C_noret_decl(trf_2015)
static void C_fcall trf_2015(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2015(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2015(t0,t1,t2);}

C_noret_decl(trf_2010)
static void C_fcall trf_2010(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2010(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2010(t0,t1,t2,t3);}

C_noret_decl(trf_1968)
static void C_fcall trf_1968(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1968(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1968(t0,t1,t2,t3);}

C_noret_decl(trf_1903)
static void C_fcall trf_1903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1903(t0,t1);}

C_noret_decl(trf_1898)
static void C_fcall trf_1898(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1898(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1898(t0,t1,t2);}

C_noret_decl(trf_1893)
static void C_fcall trf_1893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1893(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1893(t0,t1,t2,t3);}

C_noret_decl(trf_1851)
static void C_fcall trf_1851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1851(t0,t1,t2,t3);}

C_noret_decl(trf_1786)
static void C_fcall trf_1786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1786(t0,t1);}

C_noret_decl(trf_1781)
static void C_fcall trf_1781(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1781(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1781(t0,t1,t2);}

C_noret_decl(trf_1776)
static void C_fcall trf_1776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1776(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1776(t0,t1,t2,t3);}

C_noret_decl(trf_1734)
static void C_fcall trf_1734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1734(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1734(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1714)
static void C_fcall trf_1714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1714(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1714(t0,t1);}

C_noret_decl(trf_1689)
static void C_fcall trf_1689(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1689(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1689(t0,t1,t2,t3);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1274(t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_4_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_4_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_4_toplevel"));
C_check_nursery_minimum(57);
if(!C_demand(57)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1534)){
C_save(t1);
C_rereclaim2(1534*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(57);
C_initialize_lf(lf,170);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\000&numeric value is not in expected range");
lf[5]=C_h_intern(&lf[5],15,"u8vector-length");
lf[6]=C_h_intern(&lf[6],8,"u8vector");
lf[7]=C_h_intern(&lf[7],15,"s8vector-length");
lf[8]=C_h_intern(&lf[8],8,"s8vector");
lf[9]=C_h_intern(&lf[9],16,"u16vector-length");
lf[10]=C_h_intern(&lf[10],9,"u16vector");
lf[11]=C_h_intern(&lf[11],16,"s16vector-length");
lf[12]=C_h_intern(&lf[12],9,"s16vector");
lf[13]=C_h_intern(&lf[13],16,"u32vector-length");
lf[14]=C_h_intern(&lf[14],9,"u32vector");
lf[15]=C_h_intern(&lf[15],16,"s32vector-length");
lf[16]=C_h_intern(&lf[16],9,"s32vector");
lf[17]=C_h_intern(&lf[17],16,"f32vector-length");
lf[18]=C_h_intern(&lf[18],9,"f32vector");
lf[19]=C_h_intern(&lf[19],16,"f64vector-length");
lf[20]=C_h_intern(&lf[20],9,"f64vector");
lf[21]=C_h_intern(&lf[21],13,"u8vector-set!");
lf[22]=C_h_intern(&lf[22],14,"\003syserror-hook");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[24]=C_h_intern(&lf[24],13,"s8vector-set!");
lf[25]=C_h_intern(&lf[25],14,"u16vector-set!");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[27]=C_h_intern(&lf[27],14,"s16vector-set!");
lf[28]=C_h_intern(&lf[28],14,"u32vector-set!");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\034argument may not be negative");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[31]=C_h_intern(&lf[31],17,"\003syscheck-integer");
lf[32]=C_h_intern(&lf[32],14,"s32vector-set!");
lf[33]=C_decode_literal(C_heaptop,"\376B\000\000\036argument exceeds integer range");
lf[34]=C_h_intern(&lf[34],14,"f32vector-set!");
lf[35]=C_h_intern(&lf[35],14,"f64vector-set!");
lf[36]=C_h_intern(&lf[36],12,"u8vector-ref");
lf[37]=C_h_intern(&lf[37],12,"s8vector-ref");
lf[38]=C_h_intern(&lf[38],13,"u16vector-ref");
lf[39]=C_h_intern(&lf[39],13,"s16vector-ref");
lf[40]=C_h_intern(&lf[40],13,"u32vector-ref");
lf[41]=C_h_intern(&lf[41],13,"s32vector-ref");
lf[42]=C_h_intern(&lf[42],13,"f32vector-ref");
lf[43]=C_h_intern(&lf[43],13,"f64vector-ref");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000:not enough memory - cannot allocate external number vector");
lf[45]=C_h_intern(&lf[45],19,"\003sysallocate-vector");
lf[46]=C_h_intern(&lf[46],21,"release-number-vector");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\047bad argument type - not a number vector");
lf[48]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376"
"\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64vector\376\377\016");
lf[49]=C_h_intern(&lf[49],13,"make-u8vector");
lf[50]=C_h_intern(&lf[50],14,"set-finalizer!");
lf[51]=C_h_intern(&lf[51],13,"make-s8vector");
lf[52]=C_h_intern(&lf[52],4,"fin\077");
lf[53]=C_h_intern(&lf[53],14,"make-u16vector");
lf[54]=C_h_intern(&lf[54],14,"make-s16vector");
lf[55]=C_h_intern(&lf[55],14,"make-u32vector");
lf[56]=C_h_intern(&lf[56],14,"make-s32vector");
lf[57]=C_h_intern(&lf[57],14,"make-f32vector");
lf[58]=C_h_intern(&lf[58],14,"make-f64vector");
lf[59]=C_h_intern(&lf[59],14,"list->u8vector");
lf[60]=C_h_intern(&lf[60],27,"\003syserror-not-a-proper-list");
lf[61]=C_h_intern(&lf[61],14,"list->s8vector");
lf[62]=C_h_intern(&lf[62],15,"list->u16vector");
lf[63]=C_h_intern(&lf[63],15,"list->s16vector");
lf[64]=C_h_intern(&lf[64],15,"list->u32vector");
lf[65]=C_h_intern(&lf[65],15,"list->s32vector");
lf[66]=C_h_intern(&lf[66],15,"list->f32vector");
lf[67]=C_h_intern(&lf[67],15,"list->f64vector");
lf[68]=C_h_intern(&lf[68],14,"u8vector->list");
lf[69]=C_h_intern(&lf[69],14,"s8vector->list");
lf[70]=C_h_intern(&lf[70],15,"u16vector->list");
lf[71]=C_h_intern(&lf[71],15,"s16vector->list");
lf[72]=C_h_intern(&lf[72],15,"u32vector->list");
lf[73]=C_h_intern(&lf[73],15,"s32vector->list");
lf[74]=C_h_intern(&lf[74],15,"f32vector->list");
lf[75]=C_h_intern(&lf[75],15,"f64vector->list");
lf[76]=C_h_intern(&lf[76],9,"u8vector\077");
lf[77]=C_h_intern(&lf[77],9,"s8vector\077");
lf[78]=C_h_intern(&lf[78],10,"u16vector\077");
lf[79]=C_h_intern(&lf[79],10,"s16vector\077");
lf[80]=C_h_intern(&lf[80],10,"u32vector\077");
lf[81]=C_h_intern(&lf[81],10,"s32vector\077");
lf[82]=C_h_intern(&lf[82],10,"f32vector\077");
lf[83]=C_h_intern(&lf[83],10,"f64vector\077");
lf[85]=C_h_intern(&lf[85],13,"\003sysmake-blob");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000+blob does not have correct size for packing");
lf[90]=C_h_intern(&lf[90],21,"u8vector->blob/shared");
lf[91]=C_h_intern(&lf[91],21,"s8vector->blob/shared");
lf[92]=C_h_intern(&lf[92],22,"u16vector->blob/shared");
lf[93]=C_h_intern(&lf[93],22,"s16vector->blob/shared");
lf[94]=C_h_intern(&lf[94],22,"u32vector->blob/shared");
lf[95]=C_h_intern(&lf[95],22,"s32vector->blob/shared");
lf[96]=C_h_intern(&lf[96],22,"f32vector->blob/shared");
lf[97]=C_h_intern(&lf[97],22,"f64vector->blob/shared");
lf[98]=C_h_intern(&lf[98],14,"u8vector->blob");
lf[99]=C_h_intern(&lf[99],14,"s8vector->blob");
lf[100]=C_h_intern(&lf[100],15,"u16vector->blob");
lf[101]=C_h_intern(&lf[101],15,"s16vector->blob");
lf[102]=C_h_intern(&lf[102],15,"u32vector->blob");
lf[103]=C_h_intern(&lf[103],15,"s32vector->blob");
lf[104]=C_h_intern(&lf[104],15,"f32vector->blob");
lf[105]=C_h_intern(&lf[105],15,"f64vector->blob");
lf[106]=C_h_intern(&lf[106],21,"blob->u8vector/shared");
lf[107]=C_h_intern(&lf[107],21,"blob->s8vector/shared");
lf[108]=C_h_intern(&lf[108],22,"blob->u16vector/shared");
lf[109]=C_h_intern(&lf[109],22,"blob->s16vector/shared");
lf[110]=C_h_intern(&lf[110],22,"blob->u32vector/shared");
lf[111]=C_h_intern(&lf[111],22,"blob->s32vector/shared");
lf[112]=C_h_intern(&lf[112],22,"blob->f32vector/shared");
lf[113]=C_h_intern(&lf[113],22,"blob->f64vector/shared");
lf[114]=C_h_intern(&lf[114],14,"blob->u8vector");
lf[115]=C_h_intern(&lf[115],14,"blob->s8vector");
lf[116]=C_h_intern(&lf[116],15,"blob->u16vector");
lf[117]=C_h_intern(&lf[117],15,"blob->s16vector");
lf[118]=C_h_intern(&lf[118],15,"blob->u32vector");
lf[119]=C_h_intern(&lf[119],15,"blob->s32vector");
lf[120]=C_h_intern(&lf[120],15,"blob->f32vector");
lf[121]=C_h_intern(&lf[121],15,"blob->f64vector");
lf[122]=C_h_intern(&lf[122],18,"\003sysuser-read-hook");
lf[123]=C_h_intern(&lf[123],4,"read");
lf[124]=C_h_intern(&lf[124],2,"u8");
lf[125]=C_h_intern(&lf[125],2,"s8");
lf[126]=C_h_intern(&lf[126],3,"u16");
lf[127]=C_h_intern(&lf[127],3,"s16");
lf[128]=C_h_intern(&lf[128],3,"u32");
lf[129]=C_h_intern(&lf[129],3,"s32");
lf[130]=C_h_intern(&lf[130],3,"f32");
lf[131]=C_h_intern(&lf[131],3,"f64");
lf[132]=C_h_intern(&lf[132],1,"f");
lf[133]=C_h_intern(&lf[133],1,"F");
lf[134]=C_h_intern(&lf[134],14,"\003sysread-error");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal bytevector syntax");
lf[136]=C_h_intern(&lf[136],19,"\003sysuser-print-hook");
lf[137]=C_h_intern(&lf[137],9,"\003sysprint");
lf[139]=C_h_intern(&lf[139],11,"subu8vector");
lf[140]=C_h_intern(&lf[140],12,"subu16vector");
lf[141]=C_h_intern(&lf[141],12,"subu32vector");
lf[142]=C_h_intern(&lf[142],11,"subs8vector");
lf[143]=C_h_intern(&lf[143],12,"subs16vector");
lf[144]=C_h_intern(&lf[144],12,"subs32vector");
lf[145]=C_h_intern(&lf[145],12,"subf32vector");
lf[146]=C_h_intern(&lf[146],12,"subf64vector");
lf[147]=C_h_intern(&lf[147],14,"write-u8vector");
lf[148]=C_h_intern(&lf[148],16,"\003syswrite-char-0");
lf[149]=C_h_intern(&lf[149],14,"\003syscheck-port");
lf[150]=C_h_intern(&lf[150],19,"\003sysstandard-output");
lf[151]=C_h_intern(&lf[151],14,"read-u8vector!");
lf[152]=C_h_intern(&lf[152],16,"\003sysread-string!");
lf[153]=C_h_intern(&lf[153],18,"\003sysstandard-input");
lf[154]=C_h_intern(&lf[154],13,"read-u8vector");
lf[155]=C_h_intern(&lf[155],17,"get-output-string");
lf[156]=C_h_intern(&lf[156],19,"\003syswrite-char/port");
lf[157]=C_h_intern(&lf[157],15,"\003sysread-char-0");
lf[158]=C_h_intern(&lf[158],18,"open-output-string");
lf[159]=C_h_intern(&lf[159],17,"register-feature!");
lf[160]=C_h_intern(&lf[160],6,"srfi-4");
lf[161]=C_h_intern(&lf[161],18,"getter-with-setter");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\023(f64vector-ref v i)");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\023(f32vector-ref v i)");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\023(s32vector-ref v i)");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\023(u32vector-ref v i)");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\023(s16vector-ref v i)");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\023(u16vector-ref v i)");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\022(s8vector-ref v i)");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\022(u8vector-ref v i)");
C_register_lf2(lf,170,create_ptable());
t2=C_mutate(&lf[0] /* (set! c399 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* (set! ##sys#check-exact-interval ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1274,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[5]+1 /* (set! u8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1289,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[7]+1 /* (set! s8vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1295,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[9]+1 /* (set! u16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! s16vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1307,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[13]+1 /* (set! u32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1313,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[15]+1 /* (set! s32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1319,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[17]+1 /* (set! f32vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[19]+1 /* (set! f64vector-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[21]+1 /* (set! u8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1337,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[24]+1 /* (set! s8vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1378,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[25]+1 /* (set! u16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1410,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[27]+1 /* (set! s16vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1451,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[28]+1 /* (set! u32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1483,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[32]+1 /* (set! s32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1537,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[34]+1 /* (set! f32vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[35]+1 /* (set! f64vector-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1652,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4387,a[2]=((C_word)li165),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:175: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t20,t21,*((C_word*)lf[21]+1),lf[169]);}

/* a4386 */
static void C_ccall f_4387(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4387,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[6],lf[36]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4414,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[36]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_u8vector_ref(t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[36],t7,C_fix(0),t5);}}

/* k4412 in a4386 */
static void C_ccall f_4414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u8vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1650 */
static void C_ccall f_1652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1652,2,t0,t1);}
t2=C_mutate((C_word*)lf[36]+1 /* (set! u8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4358,a[2]=((C_word)li164),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:185: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[21]+1),lf[168]);}

/* a4357 in k1650 */
static void C_ccall f_4358(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4358,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[8],lf[37]);
t5=C_u_i_s8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4385,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[37]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_s8vector_ref(t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[37],t7,C_fix(0),t5);}}

/* k4383 in a4357 in k1650 */
static void C_ccall f_4385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s8vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1654 in k1650 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=C_mutate((C_word*)lf[37]+1 /* (set! s8vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1660,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=((C_word)li163),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:195: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[25]+1),lf[167]);}

/* a4328 in k1654 in k1650 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4329,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[10],lf[38]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4356,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[38]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_u16vector_ref(t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[38],t7,C_fix(0),t5);}}

/* k4354 in a4328 in k1654 in k1650 */
static void C_ccall f_4356(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u16vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1658 in k1654 in k1650 */
static void C_ccall f_1660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1660,2,t0,t1);}
t2=C_mutate((C_word*)lf[38]+1 /* (set! u16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1664,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4300,a[2]=((C_word)li162),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:205: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[27]+1),lf[166]);}

/* a4299 in k1658 in k1654 in k1650 */
static void C_ccall f_4300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4300,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[12],lf[39]);
t5=C_u_i_s16vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4327,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[39]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_u_i_s16vector_ref(t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[39],t7,C_fix(0),t5);}}

/* k4325 in a4299 in k1658 in k1654 in k1650 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s16vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1664,2,t0,t1);}
t2=C_mutate((C_word*)lf[39]+1 /* (set! s16vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1668,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4271,a[2]=((C_word)li161),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:215: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[28]+1),lf[165]);}

/* a4270 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4271(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4271,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[14],lf[40]);
t5=C_u_i_u32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4298,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[40]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_u32vector_ref(&a,2,t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[40],t7,C_fix(0),t5);}}

/* k4296 in a4270 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1668,2,t0,t1);}
t2=C_mutate((C_word*)lf[40]+1 /* (set! u32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4242,a[2]=((C_word)li160),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:225: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[32]+1),lf[164]);}

/* a4241 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4242,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[16],lf[41]);
t5=C_u_i_s32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4269,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[41]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_s32vector_ref(&a,2,t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[41],t7,C_fix(0),t5);}}

/* k4267 in a4241 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4269,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=C_mutate((C_word*)lf[41]+1 /* (set! s32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4213,a[2]=((C_word)li159),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:235: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[34]+1),lf[163]);}

/* a4212 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4213(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4213,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[18],lf[42]);
t5=C_u_i_f32vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4240,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[42]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_f32vector_ref(&a,2,t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[42],t7,C_fix(0),t5);}}

/* k4238 in a4212 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1676,2,t0,t1);}
t2=C_mutate((C_word*)lf[42]+1 /* (set! f32vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1680,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4184,a[2]=((C_word)li158),tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:245: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[161]+1)))(5,*((C_word*)lf[161]+1),t3,t4,*((C_word*)lf[35]+1),lf[162]);}

/* a4183 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4184(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4184,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[20],lf[43]);
t5=C_u_i_8vector_length(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4211,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t7=t3;
t8=C_i_check_exact_2(t7,lf[43]);
t9=C_fixnum_less_or_equal_p(C_fix(0),t7);
t10=(C_truep(t9)?C_fixnum_lessp(t7,t5):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_f64vector_ref(&a,2,t2,t3));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t6,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[43],t7,C_fix(0),t5);}}

/* k4209 in a4183 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4211,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]));}

/* k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word ab[189],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1680,2,t0,t1);}
t2=C_mutate((C_word*)lf[43]+1 /* (set! f64vector-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1687,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1689,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp);
t5=C_mutate((C_word*)lf[46]+1 /* (set! release-number-vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1707,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[49]+1 /* (set! make-u8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1732,a[2]=t4,a[3]=t3,a[4]=((C_word)li25),tmp=(C_word)a,a+=5,tmp));
t7=C_mutate((C_word*)lf[51]+1 /* (set! make-s8vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1849,a[2]=t4,a[3]=t3,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t8=C_mutate((C_word*)lf[53]+1 /* (set! make-u16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1966,a[2]=t4,a[3]=t3,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[54]+1 /* (set! make-s16vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2083,a[2]=t4,a[3]=t3,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp));
t10=C_mutate((C_word*)lf[55]+1 /* (set! make-u32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2200,a[2]=t4,a[3]=t3,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp));
t11=C_mutate((C_word*)lf[56]+1 /* (set! make-s32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2317,a[2]=t4,a[3]=t3,a[4]=((C_word)li55),tmp=(C_word)a,a+=5,tmp));
t12=C_mutate((C_word*)lf[57]+1 /* (set! make-f32vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2434,a[2]=t4,a[3]=t3,a[4]=((C_word)li61),tmp=(C_word)a,a+=5,tmp));
t13=C_mutate((C_word*)lf[58]+1 /* (set! make-f64vector ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2555,a[2]=t4,a[3]=t3,a[4]=((C_word)li67),tmp=(C_word)a,a+=5,tmp));
t14=*((C_word*)lf[49]+1);
t15=C_mutate((C_word*)lf[59]+1 /* (set! list->u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2676,a[2]=t14,a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp));
t16=*((C_word*)lf[51]+1);
t17=C_mutate((C_word*)lf[61]+1 /* (set! list->s8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2709,a[2]=t16,a[3]=((C_word)li71),tmp=(C_word)a,a+=4,tmp));
t18=*((C_word*)lf[53]+1);
t19=C_mutate((C_word*)lf[62]+1 /* (set! list->u16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2742,a[2]=t18,a[3]=((C_word)li73),tmp=(C_word)a,a+=4,tmp));
t20=*((C_word*)lf[54]+1);
t21=C_mutate((C_word*)lf[63]+1 /* (set! list->s16vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2775,a[2]=t20,a[3]=((C_word)li75),tmp=(C_word)a,a+=4,tmp));
t22=*((C_word*)lf[55]+1);
t23=C_mutate((C_word*)lf[64]+1 /* (set! list->u32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2808,a[2]=t22,a[3]=((C_word)li77),tmp=(C_word)a,a+=4,tmp));
t24=*((C_word*)lf[56]+1);
t25=C_mutate((C_word*)lf[65]+1 /* (set! list->s32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2841,a[2]=t24,a[3]=((C_word)li79),tmp=(C_word)a,a+=4,tmp));
t26=*((C_word*)lf[57]+1);
t27=C_mutate((C_word*)lf[66]+1 /* (set! list->f32vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2874,a[2]=t26,a[3]=((C_word)li81),tmp=(C_word)a,a+=4,tmp));
t28=*((C_word*)lf[58]+1);
t29=C_mutate((C_word*)lf[67]+1 /* (set! list->f64vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2907,a[2]=t28,a[3]=((C_word)li83),tmp=(C_word)a,a+=4,tmp));
t30=C_mutate((C_word*)lf[6]+1 /* (set! u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2940,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[8]+1 /* (set! s8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2946,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[10]+1 /* (set! u16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2952,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[12]+1 /* (set! s16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2958,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[14]+1 /* (set! u32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2964,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp));
t35=C_mutate((C_word*)lf[16]+1 /* (set! s32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2970,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp));
t36=C_mutate((C_word*)lf[18]+1 /* (set! f32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2976,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp));
t37=C_mutate((C_word*)lf[20]+1 /* (set! f64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2982,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp));
t38=C_mutate((C_word*)lf[68]+1 /* (set! u8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2988,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp));
t39=C_mutate((C_word*)lf[69]+1 /* (set! s8vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3017,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp));
t40=C_mutate((C_word*)lf[70]+1 /* (set! u16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3046,a[2]=((C_word)li97),tmp=(C_word)a,a+=3,tmp));
t41=C_mutate((C_word*)lf[71]+1 /* (set! s16vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3075,a[2]=((C_word)li99),tmp=(C_word)a,a+=3,tmp));
t42=C_mutate((C_word*)lf[72]+1 /* (set! u32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3104,a[2]=((C_word)li101),tmp=(C_word)a,a+=3,tmp));
t43=C_mutate((C_word*)lf[73]+1 /* (set! s32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=((C_word)li103),tmp=(C_word)a,a+=3,tmp));
t44=C_mutate((C_word*)lf[74]+1 /* (set! f32vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word)li105),tmp=(C_word)a,a+=3,tmp));
t45=C_mutate((C_word*)lf[75]+1 /* (set! f64vector->list ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3191,a[2]=((C_word)li107),tmp=(C_word)a,a+=3,tmp));
t46=C_mutate((C_word*)lf[76]+1 /* (set! u8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3220,a[2]=((C_word)li108),tmp=(C_word)a,a+=3,tmp));
t47=C_mutate((C_word*)lf[77]+1 /* (set! s8vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3226,a[2]=((C_word)li109),tmp=(C_word)a,a+=3,tmp));
t48=C_mutate((C_word*)lf[78]+1 /* (set! u16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3232,a[2]=((C_word)li110),tmp=(C_word)a,a+=3,tmp));
t49=C_mutate((C_word*)lf[79]+1 /* (set! s16vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3238,a[2]=((C_word)li111),tmp=(C_word)a,a+=3,tmp));
t50=C_mutate((C_word*)lf[80]+1 /* (set! u32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=((C_word)li112),tmp=(C_word)a,a+=3,tmp));
t51=C_mutate((C_word*)lf[81]+1 /* (set! s32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3250,a[2]=((C_word)li113),tmp=(C_word)a,a+=3,tmp));
t52=C_mutate((C_word*)lf[82]+1 /* (set! f32vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3256,a[2]=((C_word)li114),tmp=(C_word)a,a+=3,tmp));
t53=C_mutate((C_word*)lf[83]+1 /* (set! f64vector? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3262,a[2]=((C_word)li115),tmp=(C_word)a,a+=3,tmp));
t54=C_mutate(&lf[84] /* (set! pack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3279,a[2]=((C_word)li117),tmp=(C_word)a,a+=3,tmp));
t55=C_mutate(&lf[86] /* (set! unpack ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3297,a[2]=((C_word)li119),tmp=(C_word)a,a+=3,tmp));
t56=C_mutate(&lf[88] /* (set! unpack-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3326,a[2]=((C_word)li121),tmp=(C_word)a,a+=3,tmp));
t57=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5171,a[2]=((C_word)li122),tmp=(C_word)a,a+=3,tmp);
t58=C_mutate((C_word*)lf[90]+1 /* (set! u8vector->blob/shared ...) */,t57);
t59=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5164,a[2]=((C_word)li123),tmp=(C_word)a,a+=3,tmp);
t60=C_mutate((C_word*)lf[91]+1 /* (set! s8vector->blob/shared ...) */,t59);
t61=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5157,a[2]=((C_word)li124),tmp=(C_word)a,a+=3,tmp);
t62=C_mutate((C_word*)lf[92]+1 /* (set! u16vector->blob/shared ...) */,t61);
t63=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5150,a[2]=((C_word)li125),tmp=(C_word)a,a+=3,tmp);
t64=C_mutate((C_word*)lf[93]+1 /* (set! s16vector->blob/shared ...) */,t63);
t65=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5143,a[2]=((C_word)li126),tmp=(C_word)a,a+=3,tmp);
t66=C_mutate((C_word*)lf[94]+1 /* (set! u32vector->blob/shared ...) */,t65);
t67=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5136,a[2]=((C_word)li127),tmp=(C_word)a,a+=3,tmp);
t68=C_mutate((C_word*)lf[95]+1 /* (set! s32vector->blob/shared ...) */,t67);
t69=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5129,a[2]=((C_word)li128),tmp=(C_word)a,a+=3,tmp);
t70=C_mutate((C_word*)lf[96]+1 /* (set! f32vector->blob/shared ...) */,t69);
t71=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5122,a[2]=((C_word)li129),tmp=(C_word)a,a+=3,tmp);
t72=C_mutate((C_word*)lf[97]+1 /* (set! f64vector->blob/shared ...) */,t71);
t73=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3392,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:539: pack-copy */
f_3279(t73,lf[6],lf[98]);}

/* k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3392,2,t0,t1);}
t2=C_mutate((C_word*)lf[98]+1 /* (set! u8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:540: pack-copy */
f_3279(t3,lf[8],lf[99]);}

/* k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3396,2,t0,t1);}
t2=C_mutate((C_word*)lf[99]+1 /* (set! s8vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3400,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:541: pack-copy */
f_3279(t3,lf[10],lf[100]);}

/* k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3400,2,t0,t1);}
t2=C_mutate((C_word*)lf[100]+1 /* (set! u16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3404,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:542: pack-copy */
f_3279(t3,lf[12],lf[101]);}

/* k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3404,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1 /* (set! s16vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3408,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:543: pack-copy */
f_3279(t3,lf[14],lf[102]);}

/* k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3408,2,t0,t1);}
t2=C_mutate((C_word*)lf[102]+1 /* (set! u32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3412,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:544: pack-copy */
f_3279(t3,lf[16],lf[103]);}

/* k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3412,2,t0,t1);}
t2=C_mutate((C_word*)lf[103]+1 /* (set! s32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3416,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:545: pack-copy */
f_3279(t3,lf[18],lf[104]);}

/* k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3416,2,t0,t1);}
t2=C_mutate((C_word*)lf[104]+1 /* (set! f32vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3420,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:546: pack-copy */
f_3279(t3,lf[20],lf[105]);}

/* k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3420,2,t0,t1);}
t2=C_mutate((C_word*)lf[105]+1 /* (set! f64vector->blob ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3424,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:548: unpack */
f_3297(t3,lf[6],C_SCHEME_TRUE,lf[106]);}

/* k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3424,2,t0,t1);}
t2=C_mutate((C_word*)lf[106]+1 /* (set! blob->u8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3428,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:549: unpack */
f_3297(t3,lf[8],C_SCHEME_TRUE,lf[107]);}

/* k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3428,2,t0,t1);}
t2=C_mutate((C_word*)lf[107]+1 /* (set! blob->s8vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3432,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:550: unpack */
f_3297(t3,lf[10],C_fix(2),lf[108]);}

/* k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3432,2,t0,t1);}
t2=C_mutate((C_word*)lf[108]+1 /* (set! blob->u16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:551: unpack */
f_3297(t3,lf[12],C_fix(2),lf[109]);}

/* k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3436,2,t0,t1);}
t2=C_mutate((C_word*)lf[109]+1 /* (set! blob->s16vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:552: unpack */
f_3297(t3,lf[14],C_fix(4),lf[110]);}

/* k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! blob->u32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:553: unpack */
f_3297(t3,lf[16],C_fix(4),lf[111]);}

/* k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3444,2,t0,t1);}
t2=C_mutate((C_word*)lf[111]+1 /* (set! blob->s32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3448,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:554: unpack */
f_3297(t3,lf[18],C_fix(4),lf[112]);}

/* k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3448,2,t0,t1);}
t2=C_mutate((C_word*)lf[112]+1 /* (set! blob->f32vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3452,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:555: unpack */
f_3297(t3,lf[20],C_fix(8),lf[113]);}

/* k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3452,2,t0,t1);}
t2=C_mutate((C_word*)lf[113]+1 /* (set! blob->f64vector/shared ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:557: unpack-copy */
f_3326(t3,lf[6],C_SCHEME_TRUE,lf[114]);}

/* k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=C_mutate((C_word*)lf[114]+1 /* (set! blob->u8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:558: unpack-copy */
f_3326(t3,lf[8],C_SCHEME_TRUE,lf[115]);}

/* k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! blob->s8vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:559: unpack-copy */
f_3326(t3,lf[10],C_fix(2),lf[116]);}

/* k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3464,2,t0,t1);}
t2=C_mutate((C_word*)lf[116]+1 /* (set! blob->u16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3468,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:560: unpack-copy */
f_3326(t3,lf[12],C_fix(2),lf[117]);}

/* k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3468,2,t0,t1);}
t2=C_mutate((C_word*)lf[117]+1 /* (set! blob->s16vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:561: unpack-copy */
f_3326(t3,lf[14],C_fix(4),lf[118]);}

/* k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3472,2,t0,t1);}
t2=C_mutate((C_word*)lf[118]+1 /* (set! blob->u32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:562: unpack-copy */
f_3326(t3,lf[16],C_fix(4),lf[119]);}

/* k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3476,2,t0,t1);}
t2=C_mutate((C_word*)lf[119]+1 /* (set! blob->s32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3480,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:563: unpack-copy */
f_3326(t3,lf[18],C_fix(4),lf[120]);}

/* k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=C_mutate((C_word*)lf[120]+1 /* (set! blob->f32vector ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3484,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:564: unpack-copy */
f_3326(t3,lf[20],C_fix(8),lf[121]);}

/* k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[101],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3484,2,t0,t1);}
t2=C_mutate((C_word*)lf[121]+1 /* (set! blob->f64vector ...) */,t1);
t3=*((C_word*)lf[122]+1);
t4=*((C_word*)lf[123]+1);
t5=C_a_i_list(&a,16,lf[124],*((C_word*)lf[59]+1),lf[125],*((C_word*)lf[61]+1),lf[126],*((C_word*)lf[62]+1),lf[127],*((C_word*)lf[63]+1),lf[128],*((C_word*)lf[64]+1),lf[129],*((C_word*)lf[65]+1),lf[130],*((C_word*)lf[66]+1),lf[131],*((C_word*)lf[67]+1));
t6=C_mutate((C_word*)lf[122]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3489,a[2]=t3,a[3]=t4,a[4]=t5,a[5]=((C_word)li131),tmp=(C_word)a,a+=6,tmp));
t7=*((C_word*)lf[136]+1);
t8=C_mutate((C_word*)lf[136]+1 /* (set! ##sys#user-print-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3550,a[2]=t7,a[3]=((C_word)li132),tmp=(C_word)a,a+=4,tmp));
t9=C_mutate(&lf[138] /* (set! subvector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3710,a[2]=((C_word)li133),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[139]+1 /* (set! subu8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3793,a[2]=((C_word)li134),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[140]+1 /* (set! subu16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3799,a[2]=((C_word)li135),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[141]+1 /* (set! subu32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3805,a[2]=((C_word)li136),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[142]+1 /* (set! subs8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3811,a[2]=((C_word)li137),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[143]+1 /* (set! subs16vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3817,a[2]=((C_word)li138),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[144]+1 /* (set! subs32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3823,a[2]=((C_word)li139),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[145]+1 /* (set! subf32vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3829,a[2]=((C_word)li140),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[146]+1 /* (set! subf64vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3835,a[2]=((C_word)li141),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[147]+1 /* (set! write-u8vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3841,a[2]=((C_word)li147),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[151]+1 /* (set! read-u8vector! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3954,a[2]=((C_word)li151),tmp=(C_word)a,a+=3,tmp));
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4055,a[2]=((C_word)li152),tmp=(C_word)a,a+=3,tmp);
t21=C_mutate((C_word*)lf[154]+1 /* (set! read-u8vector ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4064,a[2]=t20,a[3]=((C_word)li157),tmp=(C_word)a,a+=4,tmp));
t22=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:689: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[159]+1)))(3,*((C_word*)lf[159]+1),t22,lf[160]);}

/* k4180 in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4064(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr2r,(void*)f_4064r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4064r(t0,t1,t2);}}

static void C_ccall f_4064r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a=C_alloc(12);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[2],a[3]=((C_word)li154),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4128,a[2]=t3,a[3]=((C_word)li155),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4133,a[2]=t4,a[3]=((C_word)li156),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* def-n11281153 */
t6=t5;
f_4133(t6,t1);}
else{
t6=C_i_car(t2);
t7=C_i_cdr(t2);
if(C_truep(C_i_nullp(t7))){
/* def-p11291151 */
t8=t4;
f_4128(t8,t1,t6);}
else{
t8=C_i_car(t7);
t9=C_i_cdr(t7);
if(C_truep(C_i_nullp(t9))){
/* body11261133 */
t10=t3;
f_4066(t10,t1,t6,t8);}
else{
/* ##sys#error */
t10=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[0],t9);}}}}

/* def-n1128 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4133,NULL,2,t0,t1);}
/* def-p11291151 */
t2=((C_word*)t0)[2];
f_4128(t2,t1,C_SCHEME_FALSE);}

/* def-p1129 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4128(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4128,NULL,3,t0,t1,t2);}
/* body11261133 */
t3=((C_word*)t0)[2];
f_4066(t3,t1,t2,*((C_word*)lf[153]+1));}

/* body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4066(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4066,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4070,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:669: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[149]+1)))(4,*((C_word*)lf[149]+1),t4,t3,lf[154]);}

/* k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4070,2,t0,t1);}
if(C_truep(((C_word*)t0)[5])){
t2=C_i_check_exact_2(((C_word*)t0)[5],lf[154]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4079,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:671: ##sys#allocate-vector */
t4=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,((C_word*)t0)[5],C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4097,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:678: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[158]+1)))(2,*((C_word*)lf[158]+1),t2);}}

/* k4095 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4097,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4102,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word)li153),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_4102(t5,((C_word*)t0)[2]);}

/* loop in k4095 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4102,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4106,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:680: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[157]+1)))(3,*((C_word*)lf[157]+1),t2,((C_word*)t0)[2]);}

/* k4104 in loop in k4095 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4106,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:682: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[155]+1)))(3,*((C_word*)lf[155]+1),t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4124,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:686: ##sys#write-char/port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[156]+1)))(4,*((C_word*)lf[156]+1),t2,t1,((C_word*)t0)[3]);}}

/* k4122 in k4104 in loop in k4095 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm:687: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4102(t2,((C_word*)t0)[2]);}

/* k4113 in k4104 in loop in k4095 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(t1);
/* srfi-4.scm:684: wrap */
f_4055(((C_word*)t0)[2],t1,t2);}

/* k4077 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:672: ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[152]+1)))(6,*((C_word*)lf[152]+1),t2,((C_word*)t0)[5],t1,((C_word*)t0)[2],C_fix(0));}

/* k4080 in k4077 in k4068 in body1126 in read-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=C_string_to_bytevector(((C_word*)t0)[5]);
t3=C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,2,lf[6],((C_word*)t0)[5]));}
else{
/* srfi-4.scm:676: wrap */
f_4055(((C_word*)t0)[3],((C_word*)t0)[5],t1);}}

/* wrap in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4055(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4055,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4063,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* srfi-4.scm:664: ##sys#allocate-vector */
t5=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k4061 in wrap in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=C_string_to_bytevector(t1);
t3=C_substring_copy(((C_word*)t0)[4],t1,C_fix(0),((C_word*)t0)[3],C_fix(0));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,2,lf[6],t1));}

/* read-u8vector! in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_3954r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3954r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3954r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3956,a[2]=t5,a[3]=t3,a[4]=((C_word)li148),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4001,a[2]=t6,a[3]=((C_word)li149),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4006,a[2]=t7,a[3]=((C_word)li150),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-port10901106 */
t9=t8;
f_4006(t9,t1);}
else{
t9=C_i_car(t4);
t10=C_i_cdr(t4);
if(C_truep(C_i_nullp(t10))){
/* def-start10911104 */
t11=t7;
f_4001(t11,t1,t9);}
else{
t11=C_i_car(t10);
t12=C_i_cdr(t10);
if(C_truep(C_i_nullp(t12))){
/* body10881095 */
t13=t6;
f_3956(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port1090 in read-u8vector! in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4006(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4006,NULL,2,t0,t1);}
/* def-start10911104 */
t2=((C_word*)t0)[2];
f_4001(t2,t1,*((C_word*)lf[153]+1));}

/* def-start1091 in read-u8vector! in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_4001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4001,NULL,3,t0,t1,t2);}
/* body10881095 */
t3=((C_word*)t0)[2];
f_3956(t3,t1,t2,C_fix(0));}

/* body1088 in read-u8vector! in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3960,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:649: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[149]+1)))(4,*((C_word*)lf[149]+1),t4,t2,lf[151]);}

/* k3958 in body1088 in read-u8vector! in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
t2=C_i_check_exact_2(((C_word*)t0)[6],lf[151]);
t3=C_i_check_structure_2(((C_word*)t0)[5],lf[6],lf[151]);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=C_i_check_exact_2(((C_word*)((C_word*)t0)[4])[1],lf[151]);
t6=C_fixnum_plus(((C_word*)t0)[6],((C_word*)((C_word*)t0)[4])[1]);
t7=C_block_size(t4);
if(C_truep(C_fixnum_greaterp(t6,t7))){
t8=C_block_size(t4);
t9=C_fixnum_difference(t8,((C_word*)t0)[6]);
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t9);
/* srfi-4.scm:657: ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[152]+1)))(6,*((C_word*)lf[152]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
/* srfi-4.scm:657: ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[152]+1)))(6,*((C_word*)lf[152]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}}
else{
/* srfi-4.scm:657: ##sys#read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[152]+1)))(6,*((C_word*)lf[152]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[4])[1],t4,((C_word*)t0)[2],((C_word*)t0)[6]);}}

/* write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr3r,(void*)f_3841r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3841r(t0,t1,t2,t3);}}

static void C_ccall f_3841r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(17);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3843,a[2]=t2,a[3]=((C_word)li143),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3877,a[2]=t2,a[3]=t4,a[4]=((C_word)li144),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3886,a[2]=t5,a[3]=((C_word)li145),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3891,a[2]=t6,a[3]=((C_word)li146),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-port10481070 */
t8=t7;
f_3891(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-from10491068 */
t10=t6;
f_3886(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-to10501065 */
t12=t5;
f_3877(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body10461054 */
t14=t4;
f_3843(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-port1048 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3891(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3891,NULL,2,t0,t1);}
/* def-from10491068 */
t2=((C_word*)t0)[2];
f_3886(t2,t1,*((C_word*)lf[150]+1));}

/* def-from1049 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3886(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3886,NULL,3,t0,t1,t2);}
/* def-to10501065 */
t3=((C_word*)t0)[2];
f_3877(t3,t1,t2,C_fix(0));}

/* def-to1050 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3877(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3877,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3885,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:639: u8vector-length */
t5=*((C_word*)lf[5]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k3883 in def-to1050 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* body10461054 */
t2=((C_word*)t0)[5];
f_3843(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* body1046 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3843(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3843,NULL,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(((C_word*)t0)[2],lf[6],lf[147]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3850,a[2]=t3,a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:641: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[149]+1)))(4,*((C_word*)lf[149]+1),t6,t2,lf[147]);}

/* k3848 in body1046 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3850,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],a[6]=((C_word)li142),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_3855(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop1058 in k3848 in body1046 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3855(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3855,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3865,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_make_character(C_unfix(C_u_i_u8vector_ref(((C_word*)t0)[3],t2)));
/* srfi-4.scm:644: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),t3,t4,((C_word*)t0)[2]);}}

/* k3863 in doloop1058 in k3848 in body1046 in write-u8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3855(t3,((C_word*)t0)[2],t2);}

/* subf64vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3835(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3835,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:636: subvector */
f_3710(t1,t2,lf[20],C_fix(8),t3,t4,lf[146]);}

/* subf32vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3829(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3829,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:635: subvector */
f_3710(t1,t2,lf[18],C_fix(4),t3,t4,lf[145]);}

/* subs32vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3823,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:634: subvector */
f_3710(t1,t2,lf[16],C_fix(4),t3,t4,lf[144]);}

/* subs16vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3817(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3817,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:633: subvector */
f_3710(t1,t2,lf[12],C_fix(2),t3,t4,lf[143]);}

/* subs8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3811,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:632: subvector */
f_3710(t1,t2,lf[8],C_fix(1),t3,t4,lf[142]);}

/* subu32vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3805,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:631: subvector */
f_3710(t1,t2,lf[14],C_fix(4),t3,t4,lf[141]);}

/* subu16vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3799(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3799,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:630: subvector */
f_3710(t1,t2,lf[10],C_fix(2),t3,t4,lf[140]);}

/* subu8vector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3793,5,t0,t1,t2,t3,t4);}
/* srfi-4.scm:629: subvector */
f_3710(t1,t2,lf[6],C_fix(1),t3,t4,lf[139]);}

/* subvector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3710(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7){
C_word tmp;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3710,NULL,7,t1,t2,t3,t4,t5,t6,t7);}
t8=C_i_check_structure_2(t2,t3,t7);
t9=C_slot(t2,C_fix(1));
t10=C_block_size(t9);
t11=C_u_fixnum_divide(t10,t4);
t12=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3743,a[2]=t7,a[3]=t11,a[4]=t1,a[5]=t9,a[6]=t3,a[7]=t4,a[8]=t5,a[9]=t6,tmp=(C_word)a,a+=10,tmp);
t13=C_fixnum_plus(t11,C_fix(1));
t14=t5;
t15=t7;
t16=C_i_check_exact_2(t14,t15);
t17=C_fixnum_less_or_equal_p(C_fix(0),t14);
t18=(C_truep(t17)?C_fixnum_lessp(t14,t13):C_SCHEME_FALSE);
if(C_truep(t18)){
t19=C_SCHEME_UNDEFINED;
t20=t12;
f_3743(2,t20,t19);}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t12,C_fix((C_word)C_OUT_OF_RANGE_ERROR),t15,t14,C_fix(0),t13);}}

/* k3741 in subvector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=C_fixnum_plus(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[9];
t5=((C_word*)t0)[2];
t6=C_i_check_exact_2(t4,t5);
t7=C_fixnum_less_or_equal_p(C_fix(0),t4);
t8=(C_truep(t7)?C_fixnum_lessp(t4,t3):C_SCHEME_FALSE);
if(C_truep(t8)){
t9=C_SCHEME_UNDEFINED;
t10=t2;
f_3766(2,t10,t9);}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t2,C_fix((C_word)C_OUT_OF_RANGE_ERROR),t5,t4,C_fix(0),t3);}}

/* k3764 in k3741 in subvector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3766,2,t0,t1);}
t2=C_fixnum_difference(((C_word*)t0)[7],((C_word*)t0)[6]);
t3=C_fixnum_times(((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3772,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:623: ##sys#allocate-vector */
t5=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}

/* k3770 in k3764 in k3741 in subvector in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3772,2,t0,t1);}
t2=C_string_to_bytevector(t1);
t3=C_a_i_record(&a,2,((C_word*)t0)[7],t1);
t4=C_fixnum_times(((C_word*)t0)[6],((C_word*)t0)[5]);
t5=C_copy_subvector(t1,((C_word*)t0)[4],C_fix(0),t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}

/* ##sys#user-print-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word ab[102],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3550,5,t0,t1,t2,t3,t4);}
t5=C_a_i_cons(&a,2,*((C_word*)lf[68]+1),C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[124],t5);
t7=C_a_i_cons(&a,2,lf[6],t6);
t8=C_a_i_cons(&a,2,*((C_word*)lf[69]+1),C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[125],t8);
t10=C_a_i_cons(&a,2,lf[8],t9);
t11=C_a_i_cons(&a,2,*((C_word*)lf[70]+1),C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,lf[126],t11);
t13=C_a_i_cons(&a,2,lf[10],t12);
t14=C_a_i_cons(&a,2,*((C_word*)lf[71]+1),C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,lf[127],t14);
t16=C_a_i_cons(&a,2,lf[12],t15);
t17=C_a_i_cons(&a,2,*((C_word*)lf[72]+1),C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,lf[128],t17);
t19=C_a_i_cons(&a,2,lf[14],t18);
t20=C_a_i_cons(&a,2,*((C_word*)lf[73]+1),C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,lf[129],t20);
t22=C_a_i_cons(&a,2,lf[16],t21);
t23=C_a_i_cons(&a,2,*((C_word*)lf[74]+1),C_SCHEME_END_OF_LIST);
t24=C_a_i_cons(&a,2,lf[130],t23);
t25=C_a_i_cons(&a,2,lf[18],t24);
t26=C_a_i_cons(&a,2,*((C_word*)lf[75]+1),C_SCHEME_END_OF_LIST);
t27=C_a_i_cons(&a,2,lf[131],t26);
t28=C_a_i_cons(&a,2,lf[20],t27);
t29=C_a_i_cons(&a,2,t28,C_SCHEME_END_OF_LIST);
t30=C_a_i_cons(&a,2,t25,t29);
t31=C_a_i_cons(&a,2,t22,t30);
t32=C_a_i_cons(&a,2,t19,t31);
t33=C_a_i_cons(&a,2,t16,t32);
t34=C_a_i_cons(&a,2,t13,t33);
t35=C_a_i_cons(&a,2,t10,t34);
t36=C_a_i_cons(&a,2,t7,t35);
t37=C_i_assq(C_slot(t2,C_fix(0)),t36);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3560,a[2]=t2,a[3]=t4,a[4]=t1,a[5]=t37,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:605: ##sys#print */
t39=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t39+1)))(5,t39,t38,C_make_character(35),C_SCHEME_FALSE,t4);}
else{
/* srfi-4.scm:608: old-hook */
t38=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t38))(5,t38,t1,t2,t3,t4);}}

/* k3558 in ##sys#user-print-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* srfi-4.scm:606: ##sys#print */
t4=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,C_SCHEME_FALSE,((C_word*)t0)[3]);}

/* k3561 in k3558 in ##sys#user-print-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3563,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3573,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* g972973 */
t4=t2;
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,((C_word*)t0)[2]);}

/* k3571 in k3561 in k3558 in ##sys#user-print-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-4.scm:607: ##sys#print */
t2=*((C_word*)lf[137]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_TRUE,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3489(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3489,4,t0,t1,t2,t3);}
t4=t2;
if(C_truep((C_truep(C_eqp(t4,C_make_character(117)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(102)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(85)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(83)))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,C_make_character(70)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3499,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:582: read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t3);}
else{
/* srfi-4.scm:587: old-hook */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t1,t2,t3);}}

/* k3497 in ##sys#user-read-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3499,2,t0,t1);}
t2=C_i_symbolp(t1);
t3=(C_truep(t2)?t1:C_SCHEME_FALSE);
t4=C_eqp(t3,lf[132]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[133]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_memq(t3,((C_word*)t0)[4]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3518,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word)li130),tmp=(C_word)a,a+=5,tmp);
/* g956957 */
t8=t7;
f_3518(t8,((C_word*)t0)[5],t6);}
else{
/* srfi-4.scm:586: ##sys#read-error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[134]+1)))(5,*((C_word*)lf[134]+1),((C_word*)t0)[5],((C_word*)t0)[2],lf[135],t3);}}}

/* g956 in k3497 in ##sys#user-read-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3518,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
t4=C_slot(t3,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3529,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* srfi-4.scm:585: read */
t6=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,((C_word*)t0)[2]);}

/* k3527 in g956 in k3497 in ##sys#user-read-hook in k3482 in k3478 in k3474 in k3470 in k3466 in k3462 in k3458 in k3454 in k3450 in k3446 in k3442 in k3438 in k3434 in k3430 in k3426 in k3422 in k3418 in k3414 in k3410 in k3406 in k3402 in k3398 in k3394 in k3390 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g959960 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f5122 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5122(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5122,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[20],lf[97]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5129 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5129(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5129,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[96]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5136 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5136(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5136,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[95]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5143 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5143(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5143,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[94]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5150 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5150(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5150,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[93]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5157 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5157(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5157,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[92]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5164 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5164,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[91]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* f5171 in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f5171(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f5171,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* unpack-copy in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3326(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3326,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3328,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li120),tmp=(C_word)a,a+=6,tmp));}

/* f_3328 in unpack-copy in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3328(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3328,3,t0,t1,t2);}
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=C_block_size(t2);
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3338,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:522: ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t5,t4);}

/* k3336 */
static void C_ccall f_3338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3338,2,t0,t1);}
t2=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[7]);
t3=(C_truep(t2)?t2:C_eqp(C_fix(0),C_fixnum_modulo(((C_word*)t0)[6],((C_word*)t0)[7])));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,2,((C_word*)t0)[4],C_copy_block(((C_word*)t0)[3],t1)));}
else{
/* srfi-4.scm:528: ##sys#error */
t4=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],((C_word*)t0)[2],lf[89],((C_word*)t0)[4],((C_word*)t0)[6],((C_word*)t0)[7]);}}

/* unpack in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3297(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3297,NULL,4,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3299,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=((C_word)li118),tmp=(C_word)a,a+=6,tmp));}

/* f_3299 in unpack in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3299,3,t0,t1,t2);}
t3=C_i_check_bytevector_2(t2,((C_word*)t0)[4]);
t4=C_block_size(t2);
t5=C_eqp(C_SCHEME_TRUE,((C_word*)t0)[3]);
t6=(C_truep(t5)?t5:C_eqp(C_fix(0),C_fixnum_modulo(t4,((C_word*)t0)[3])));
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,2,((C_word*)t0)[2],t2));}
else{
/* srfi-4.scm:516: ##sys#error */
t7=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t1,((C_word*)t0)[4],lf[87],((C_word*)t0)[2],t4,((C_word*)t0)[3]);}}

/* pack-copy in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3279(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3279,NULL,3,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3281,a[2]=t3,a[3]=t2,a[4]=((C_word)li116),tmp=(C_word)a,a+=5,tmp));}

/* f_3281 in pack-copy in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3281,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,((C_word*)t0)[3],((C_word*)t0)[2]);
t4=C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3291,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_block_size(t4);
/* srfi-4.scm:506: ##sys#make-blob */
((C_proc3)C_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t5,t6);}

/* k3289 */
static void C_ccall f_3291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_copy_block(((C_word*)t0)[2],t1));}

/* f64vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3262,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[20]));}

/* f32vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3256(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3256,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[18]));}

/* s32vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3250(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3250,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[16]));}

/* u32vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3244,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[14]));}

/* s16vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3238(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3238,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[12]));}

/* u16vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3232(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3232,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[10]));}

/* s8vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3226(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3226,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[8]));}

/* u8vector? in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3220,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[6]));}

/* f64vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3191,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[20],lf[75]);
t4=C_u_i_f64vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3200,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li106),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3200(t8,t1,C_fix(0));}

/* loop in f64vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3200(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3200,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop899 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3212 in loop in f64vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3214,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_i_f64vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* f32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3162,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[74]);
t4=C_u_i_f32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3171,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li104),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3171(t8,t1,C_fix(0));}

/* loop in f32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3171(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3171,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3185,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop893 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3183 in loop in f32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3185,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_i_f32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* s32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3133,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[73]);
t4=C_u_i_s32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3142,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li102),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3142(t8,t1,C_fix(0));}

/* loop in s32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3142(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3142,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3156,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop887 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3154 in loop in s32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_i_s32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* u32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3104,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[72]);
t4=C_u_i_u32vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3113,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li100),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3113(t8,t1,C_fix(0));}

/* loop in u32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3113(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3113,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3127,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop881 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3125 in loop in u32vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3127,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_a_i_u32vector_ref(&a,2,((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* s16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3075(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3075,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[71]);
t4=C_u_i_s16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3084,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li98),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3084(t8,t1,C_fix(0));}

/* loop in s16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3084(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3084,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3098,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop875 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3096 in loop in s16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3098,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_u_i_s16vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* u16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3046,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[70]);
t4=C_u_i_u16vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3055,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li96),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3055(t8,t1,C_fix(0));}

/* loop in u16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3055(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3055,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3069,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop869 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3067 in loop in u16vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3069,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_u_i_u16vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* s8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3017,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[69]);
t4=C_u_i_s8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3026,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li94),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_3026(t8,t1,C_fix(0));}

/* loop in s8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_3026(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3026,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3040,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop863 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3038 in loop in s8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3040,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_u_i_s8vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* u8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2988,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[68]);
t4=C_u_i_u8vector_length(t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2997,a[2]=t6,a[3]=t2,a[4]=t4,a[5]=((C_word)li92),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_2997(t8,t1,C_fix(0));}

/* loop in u8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2997(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2997,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_plus(t2,C_fix(1));
/* loop857 */
t6=t3;
t7=t4;
t1=t6;
t2=t7;
goto loop;}}

/* k3009 in loop in u8vector->list in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3011,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,C_u_i_u8vector_ref(((C_word*)t0)[3],((C_word*)t0)[2]),t1));}

/* f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2982(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2982r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2982r(t0,t1,t2);}}

static void C_ccall f_2982r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:450: list->f64vector */
t3=*((C_word*)lf[67]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2976(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2976r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2976r(t0,t1,t2);}}

static void C_ccall f_2976r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:447: list->f32vector */
t3=*((C_word*)lf[66]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2970(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2970r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2970r(t0,t1,t2);}}

static void C_ccall f_2970r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:444: list->s32vector */
t3=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2964(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2964r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2964r(t0,t1,t2);}}

static void C_ccall f_2964r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:441: list->u32vector */
t3=*((C_word*)lf[64]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2958(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2958r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2958r(t0,t1,t2);}}

static void C_ccall f_2958r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:438: list->s16vector */
t3=*((C_word*)lf[63]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2952(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2952r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2952r(t0,t1,t2);}}

static void C_ccall f_2952r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:435: list->u16vector */
t3=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2946(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2946r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2946r(t0,t1,t2);}}

static void C_ccall f_2946r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:432: list->s8vector */
t3=*((C_word*)lf[61]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_2940r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2940r(t0,t1,t2);}}

static void C_ccall f_2940r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
/* srfi-4.scm:429: list->u8vector */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}

/* list->f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2907,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[20]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2914,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-f64vector820 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2912 in list->f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2914,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2919,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li82),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2919(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop824 in k2912 in list->f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2919(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2919,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2926,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* f64vector-set! */
t6=*((C_word*)lf[35]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2924 in doloop824 in k2912 in list->f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2919(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2874(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2874,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[18]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2881,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-f32vector808 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2879 in list->f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2881,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li80),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2886(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop812 in k2879 in list->f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2886(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2886,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2893,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* f32vector-set! */
t6=*((C_word*)lf[34]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2891 in doloop812 in k2879 in list->f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2886(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2841(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2841,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[16]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2848,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-s32vector796 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2846 in list->s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2848,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li78),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2853(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop800 in k2846 in list->s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2853(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2853,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2860,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* s32vector-set! */
t6=*((C_word*)lf[32]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2858 in doloop800 in k2846 in list->s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2853(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2808(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2808,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[14]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2815,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-u32vector784 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2813 in list->u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2820,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li76),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2820(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop788 in k2813 in list->u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2820(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2820,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2827,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* u32vector-set! */
t6=*((C_word*)lf[28]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2825 in doloop788 in k2813 in list->u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2827(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2820(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2775(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2775,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[12]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2782,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-s16vector772 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2780 in list->s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2787,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li74),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2787(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop776 in k2780 in list->s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2787(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2787,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2794,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* s16vector-set! */
t6=*((C_word*)lf[27]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2792 in doloop776 in k2780 in list->s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2787(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2742(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2742,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[10]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2749,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-u16vector760 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2747 in list->u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2749,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2754,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li72),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2754(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop764 in k2747 in list->u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2754(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2754,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2761,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* u16vector-set! */
t6=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2759 in doloop764 in k2747 in list->u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2754(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2709(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2709,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[8]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2716,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-s8vector748 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2714 in list->s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2721,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li70),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2721(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop752 in k2714 in list->s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2721(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2721,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2728,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* s8vector-set! */
t6=*((C_word*)lf[24]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2726 in doloop752 in k2714 in list->s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2721(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* list->u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2676(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2676,3,t0,t1,t2);}
t3=C_i_check_list_2(t2,lf[6]);
t4=C_i_length(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2683,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* make-u8vector736 */
t6=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t6))(3,t6,t5,t4);}

/* k2681 in list->u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2683,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2688,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word)li68),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2688(t5,((C_word*)t0)[2],((C_word*)t0)[3],C_fix(0));}

/* doloop740 in k2681 in list->u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2688(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2688,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eqp(t2,C_SCHEME_END_OF_LIST))){
t4=((C_word*)t0)[4];
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2695,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t5=(C_truep(C_blockp(t2))?C_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t5)){
/* u8vector-set! */
t6=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,((C_word*)t0)[4],t3,C_slot(t2,C_fix(0)));}
else{
/* ##sys#error-not-a-proper-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[60]+1)))(3,*((C_word*)lf[60]+1),t4,((C_word*)t0)[2]);}}}

/* k2693 in doloop740 in k2681 in list->u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[5])[1];
f_2688(t2,((C_word*)t0)[4],C_slot(((C_word*)t0)[3],C_fix(1)),C_fixnum_plus(((C_word*)t0)[2],C_fix(1)));}

/* make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_2555r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2555r(t0,t1,t2,t3);}}

static void C_ccall f_2555r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2603,a[2]=t4,a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t5,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2613,a[2]=t6,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init684710 */
t8=t7;
f_2613(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?685708 */
t10=t6;
f_2608(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin686705 */
t12=t5;
f_2603(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body682690 */
t14=t4;
f_2557(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init684 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2613(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2613,NULL,2,t0,t1);}
/* def-ext?685708 */
t2=((C_word*)t0)[2];
f_2608(t2,t1,C_SCHEME_FALSE);}

/* def-ext?685 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2608,NULL,3,t0,t1,t2);}
/* def-fin686705 */
t3=((C_word*)t0)[2];
f_2603(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin686 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2603(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2603,NULL,4,t0,t1,t2,t3);}
/* body682690 */
t4=((C_word*)t0)[2];
f_2557(t4,t1,t2,t3);}

/* body682 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2557(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2557,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_i_check_exact_2(((C_word*)t0)[4],lf[58]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2602,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:382: alloc */
f_1689(t6,lf[58],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(3)),t3);}

/* k2600 in body682 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2602,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[20],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2567,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:383: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2567(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2567(2,t4,C_SCHEME_UNDEFINED);}}

/* k2565 in k2600 in body682 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2567,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[58]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2579(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[5])[1]));
t6=t4;
f_2579(t6,t5);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2577 in k2565 in k2600 in body682 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2579(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2579,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li62),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2584(t2,C_fix(0)));}

/* doloop696 in k2577 in k2565 in k2600 in body682 in make-f64vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_2584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f64vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_2434r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2434r(t0,t1,t2,t3);}}

static void C_ccall f_2434r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2482,a[2]=t4,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2487,a[2]=t5,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2492,a[2]=t6,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init638664 */
t8=t7;
f_2492(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?639662 */
t10=t6;
f_2487(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin640659 */
t12=t5;
f_2482(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body636644 */
t14=t4;
f_2436(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init638 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2492,NULL,2,t0,t1);}
/* def-ext?639662 */
t2=((C_word*)t0)[2];
f_2487(t2,t1,C_SCHEME_FALSE);}

/* def-ext?639 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2487,NULL,3,t0,t1,t2);}
/* def-fin640659 */
t3=((C_word*)t0)[2];
f_2482(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin640 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2482(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2482,NULL,4,t0,t1,t2,t3);}
/* body636644 */
t4=((C_word*)t0)[2];
f_2436(t4,t1,t2,t3);}

/* body636 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2436(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2436,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=C_i_check_exact_2(((C_word*)t0)[4],lf[57]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2481,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:365: alloc */
f_1689(t6,lf[57],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(2)),t3);}

/* k2479 in body636 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2481,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[18],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2446,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:366: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2446(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2446(2,t4,C_SCHEME_UNDEFINED);}}

/* k2444 in k2479 in body636 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2446,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[5])[1];
if(C_truep(t2)){
t3=C_i_check_number_2(((C_word*)((C_word*)t0)[5])[1],lf[57]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2458,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_blockp(((C_word*)((C_word*)t0)[5])[1]))){
t5=t4;
f_2458(t5,C_SCHEME_UNDEFINED);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_a_i_fix_to_flo(&a,1,((C_word*)((C_word*)t0)[5])[1]));
t6=t4;
f_2458(t6,t5);}}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2456 in k2444 in k2479 in body636 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2458,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li56),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2463(t2,C_fix(0)));}

/* doloop650 in k2456 in k2444 in k2479 in body636 in make-f32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_2463(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_f32vector_set(((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_2317r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2317r(t0,t1,t2,t3);}}

static void C_ccall f_2317r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li51),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2361,a[2]=t4,a[3]=((C_word)li52),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=t5,a[3]=((C_word)li53),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=t6,a[3]=((C_word)li54),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init593618 */
t8=t7;
f_2371(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?594616 */
t10=t6;
f_2366(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin595613 */
t12=t5;
f_2361(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body591599 */
t14=t4;
f_2319(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init593 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2371,NULL,2,t0,t1);}
/* def-ext?594616 */
t2=((C_word*)t0)[2];
f_2366(t2,t1,C_SCHEME_FALSE);}

/* def-ext?594 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2366(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2366,NULL,3,t0,t1,t2);}
/* def-fin595613 */
t3=((C_word*)t0)[2];
f_2361(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin595 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2361(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2361,NULL,4,t0,t1,t2,t3);}
/* body591599 */
t4=((C_word*)t0)[2];
f_2319(t4,t1,t2,t3);}

/* body591 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2319(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2319,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(((C_word*)t0)[4],lf[56]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2360,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:352: alloc */
f_1689(t5,lf[56],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(2)),t3);}

/* k2358 in body591 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2360,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[16],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2329,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:353: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2329(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2329(2,t4,C_SCHEME_UNDEFINED);}}

/* k2327 in k2358 in body591 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2329,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=C_i_check_exact_2(((C_word*)t0)[5],lf[56]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2343,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li50),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2343(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop605 in k2327 in k2358 in body591 in make-s32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_2343(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_2200r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2200r(t0,t1,t2,t3);}}

static void C_ccall f_2200r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li45),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2244,a[2]=t4,a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2249,a[2]=t5,a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2254,a[2]=t6,a[3]=((C_word)li48),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init548573 */
t8=t7;
f_2254(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?549571 */
t10=t6;
f_2249(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin550568 */
t12=t5;
f_2244(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body546554 */
t14=t4;
f_2202(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init548 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2254(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2254,NULL,2,t0,t1);}
/* def-ext?549571 */
t2=((C_word*)t0)[2];
f_2249(t2,t1,C_SCHEME_FALSE);}

/* def-ext?549 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2249(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2249,NULL,3,t0,t1,t2);}
/* def-fin550568 */
t3=((C_word*)t0)[2];
f_2244(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin550 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2244(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2244,NULL,4,t0,t1,t2,t3);}
/* body546554 */
t4=((C_word*)t0)[2];
f_2202(t4,t1,t2,t3);}

/* body546 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(((C_word*)t0)[4],lf[55]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:339: alloc */
f_1689(t5,lf[55],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(2)),t3);}

/* k2241 in body546 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2243,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[14],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:340: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2212(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2212(2,t4,C_SCHEME_UNDEFINED);}}

/* k2210 in k2241 in body546 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=C_i_check_exact_2(((C_word*)t0)[5],lf[55]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word)li44),tmp=(C_word)a,a+=6,tmp);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,f_2226(t4,C_fix(0)));}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* doloop560 in k2210 in k2241 in body546 in make-u32vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_2226(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u32vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2083(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_2083r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2083r(t0,t1,t2,t3);}}

static void C_ccall f_2083r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li39),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2127,a[2]=t4,a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2132,a[2]=t5,a[3]=((C_word)li41),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2137,a[2]=t6,a[3]=((C_word)li42),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init503528 */
t8=t7;
f_2137(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?504526 */
t10=t6;
f_2132(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin505523 */
t12=t5;
f_2127(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body501509 */
t14=t4;
f_2085(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init503 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2137(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2137,NULL,2,t0,t1);}
/* def-ext?504526 */
t2=((C_word*)t0)[2];
f_2132(t2,t1,C_SCHEME_FALSE);}

/* def-ext?504 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2132(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2132,NULL,3,t0,t1,t2);}
/* def-fin505523 */
t3=((C_word*)t0)[2];
f_2127(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin505 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2127(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2127,NULL,4,t0,t1,t2,t3);}
/* body501509 */
t4=((C_word*)t0)[2];
f_2085(t4,t1,t2,t3);}

/* body501 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2085(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2085,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(((C_word*)t0)[4],lf[54]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2126,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:326: alloc */
f_1689(t5,lf[54],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(1)),t3);}

/* k2124 in body501 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2126,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[12],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2095,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:327: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_2095(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_2095(2,t4,C_SCHEME_UNDEFINED);}}

/* k2093 in k2124 in body501 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2095,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2104,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:331: ##sys#check-exact-interval */
f_1274(t3,((C_word*)t0)[5],C_fix(-32768),C_fix(32767),lf[54]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k2102 in k2093 in k2124 in body501 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2109,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li38),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2109(t2,C_fix(0)));}

/* doloop515 in k2102 in k2093 in k2124 in body501 in make-s16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_2109(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1966(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_1966r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1966r(t0,t1,t2,t3);}}

static void C_ccall f_1966r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1968,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li33),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2010,a[2]=t4,a[3]=((C_word)li34),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2015,a[2]=t5,a[3]=((C_word)li35),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=t6,a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init458483 */
t8=t7;
f_2020(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?459481 */
t10=t6;
f_2015(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin460478 */
t12=t5;
f_2010(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body456464 */
t14=t4;
f_1968(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init458 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2020,NULL,2,t0,t1);}
/* def-ext?459481 */
t2=((C_word*)t0)[2];
f_2015(t2,t1,C_SCHEME_FALSE);}

/* def-ext?459 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2015(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2015,NULL,3,t0,t1,t2);}
/* def-fin460478 */
t3=((C_word*)t0)[2];
f_2010(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin460 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_2010(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2010,NULL,4,t0,t1,t2,t3);}
/* body456464 */
t4=((C_word*)t0)[2];
f_1968(t4,t1,t2,t3);}

/* body456 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1968(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1968,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(((C_word*)t0)[4],lf[53]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2009,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:313: alloc */
f_1689(t5,lf[53],C_fixnum_shift_left(((C_word*)t0)[4],C_fix(1)),t3);}

/* k2007 in body456 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_2009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2009,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[10],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1978,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:314: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1978(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1978(2,t4,C_SCHEME_UNDEFINED);}}

/* k1976 in k2007 in body456 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1978,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1987,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:318: ##sys#check-exact-interval */
f_1274(t3,((C_word*)t0)[5],C_fix(0),C_fix(65535),lf[53]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1985 in k1976 in k2007 in body456 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1987,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li32),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1992(t2,C_fix(0)));}

/* doloop470 in k1985 in k1976 in k2007 in body456 in make-u16vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_1992(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u16vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1849(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_1849r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1849r(t0,t1,t2,t3);}}

static void C_ccall f_1849r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li27),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1893,a[2]=t4,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1898,a[2]=t5,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t6,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init413438 */
t8=t7;
f_1903(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?414436 */
t10=t6;
f_1898(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin415433 */
t12=t5;
f_1893(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body411419 */
t14=t4;
f_1851(t14,t1,t8,t10);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init413 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1903,NULL,2,t0,t1);}
/* def-ext?414436 */
t2=((C_word*)t0)[2];
f_1898(t2,t1,C_SCHEME_FALSE);}

/* def-ext?414 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1898(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1898,NULL,3,t0,t1,t2);}
/* def-fin415433 */
t3=((C_word*)t0)[2];
f_1893(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin415 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1893(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1893,NULL,4,t0,t1,t2,t3);}
/* body411419 */
t4=((C_word*)t0)[2];
f_1851(t4,t1,t2,t3);}

/* body411 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1851,NULL,4,t0,t1,t2,t3);}
t4=C_i_check_exact_2(((C_word*)t0)[4],lf[51]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1892,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:300: alloc */
f_1689(t5,lf[51],((C_word*)t0)[4],t3);}

/* k1890 in body411 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1892(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1892,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[8],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[52]+1);
if(C_truep(t4)){
/* srfi-4.scm:301: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1861(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1861(2,t4,C_SCHEME_UNDEFINED);}}

/* k1859 in k1890 in body411 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1861,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:305: ##sys#check-exact-interval */
f_1274(t3,((C_word*)t0)[5],C_fix(-128),C_fix(127),lf[51]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1868 in k1859 in k1890 in body411 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1870,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1875,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li26),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1875(t2,C_fix(0)));}

/* doloop425 in k1868 in k1859 in k1890 in body411 in make-s8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_1875(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_s8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1732(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr3r,(void*)f_1732r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1732r(t0,t1,t2,t3);}}

static void C_ccall f_1732r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a=C_alloc(18);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1734,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word)li21),tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1776,a[2]=t4,a[3]=((C_word)li22),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1781,a[2]=t5,a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1786,a[2]=t6,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-init367392 */
t8=t7;
f_1786(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-ext?368390 */
t10=t6;
f_1781(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* def-fin?369387 */
t12=t5;
f_1776(t12,t1,t8,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* body365373 */
t14=t4;
f_1734(t14,t1,t8,t10,t12);}
else{
/* ##sys#error */
t14=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,lf[0],t13);}}}}}

/* def-init367 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1786,NULL,2,t0,t1);}
/* def-ext?368390 */
t2=((C_word*)t0)[2];
f_1781(t2,t1,C_SCHEME_FALSE);}

/* def-ext?368 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1781(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1781,NULL,3,t0,t1,t2);}
/* def-fin?369387 */
t3=((C_word*)t0)[2];
f_1776(t3,t1,t2,C_SCHEME_FALSE);}

/* def-fin?369 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1776(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1776,NULL,4,t0,t1,t2,t3);}
/* body365373 */
t4=((C_word*)t0)[2];
f_1734(t4,t1,t2,t3,C_SCHEME_TRUE);}

/* body365 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1734(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1734,NULL,5,t0,t1,t2,t3,t4);}
t5=C_i_check_exact_2(((C_word*)t0)[4],lf[49]);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1775,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* srfi-4.scm:287: alloc */
f_1689(t6,lf[49],((C_word*)t0)[4],t3);}

/* k1773 in body365 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1775,2,t0,t1);}
t2=C_a_i_record(&a,2,lf[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1744,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t4=((C_word*)t0)[3];
if(C_truep(t4)){
/* srfi-4.scm:288: set-finalizer! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[50]+1)))(4,*((C_word*)lf[50]+1),t3,t2,((C_word*)t0)[2]);}
else{
t5=t3;
f_1744(2,t5,C_SCHEME_UNDEFINED);}}
else{
t4=t3;
f_1744(2,t4,C_SCHEME_UNDEFINED);}}

/* k1742 in k1773 in body365 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1744,2,t0,t1);}
t2=((C_word*)t0)[5];
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* srfi-4.scm:292: ##sys#check-exact-interval */
f_1274(t3,((C_word*)t0)[5],C_fix(0),C_fix(255),lf[49]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k1751 in k1742 in k1773 in body365 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li20),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_1758(t2,C_fix(0)));}

/* doloop379 in k1751 in k1742 in k1773 in body365 in make-u8vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static C_word C_fcall f_1758(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
return(((C_word*)t0)[3]);}
else{
t2=C_u_i_u8vector_set(((C_word*)t0)[3],t1,((C_word*)t0)[2]);
t4=C_fixnum_plus(t1,C_fix(1));
t1=t4;
goto loop;}}

/* release-number-vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1714,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_structurep(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_1714(t5,C_i_memq(t4,lf[48]));}
else{
t4=t3;
f_1714(t4,C_SCHEME_FALSE);}}

/* k1712 in release-number-vector in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1714(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub339(C_SCHEME_UNDEFINED,t3));}
else{
/* srfi-4.scm:282: ##sys#error */
t2=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[46],lf[47],((C_word*)t0)[2]);}}

/* alloc in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_fcall f_1689(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1689,NULL,4,t1,t2,t3,t4);}
if(C_truep(t4)){
t5=t3;
t6=C_i_foreign_fixnum_argumentp(t5);
t7=stub334(C_SCHEME_UNDEFINED,t6);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
/* srfi-4.scm:271: ##sys#error */
t8=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,lf[44],t3);}}
else{
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1705,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-4.scm:272: ##sys#allocate-vector */
t6=*((C_word*)lf[45]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,t3,C_SCHEME_TRUE,C_SCHEME_FALSE,C_SCHEME_TRUE);}}

/* k1703 in alloc in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_string_to_bytevector(t1);
t3=t1;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* ext-free in k1678 in k1674 in k1670 in k1666 in k1662 in k1658 in k1654 in k1650 */
static void C_ccall f_1687(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1687,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub339(C_SCHEME_UNDEFINED,t2));}

/* f64vector-set! */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1614,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[20],lf[35]);
t6=C_u_i_64vector_length(t2);
t7=C_i_check_number_2(t4,lf[35]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1644,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[35]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;
f_1644(2,t14,t13);}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t8,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[35],t9,C_fix(0),t6);}}

/* k1642 in f64vector-set! */
static void C_ccall f_1644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1644,2,t0,t1);}
if(C_truep(C_blockp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f64vector_set(((C_word*)t0)[3],((C_word*)t0)[2],t2));}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f64vector_set(((C_word*)t0)[3],((C_word*)t0)[2],t2));}}

/* f32vector-set! */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1578,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[18],lf[34]);
t6=C_u_i_32vector_length(t2);
t7=C_i_check_number_2(t4,lf[34]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1608,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[34]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=C_SCHEME_UNDEFINED;
t14=t8;
f_1608(2,t14,t13);}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t8,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[34],t9,C_fix(0),t6);}}

/* k1606 in f32vector-set! */
static void C_ccall f_1608(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1608,2,t0,t1);}
if(C_truep(C_blockp(((C_word*)t0)[5]))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f32vector_set(((C_word*)t0)[3],((C_word*)t0)[2],t2));}
else{
t2=C_a_i_fix_to_flo(&a,1,((C_word*)t0)[5]);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_f32vector_set(((C_word*)t0)[3],((C_word*)t0)[2],t2));}}

/* s32vector-set! */
static void C_ccall f_1537(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1537,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[16],lf[32]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1544,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:144: ##sys#check-integer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t7,t4,lf[32]);}

/* k1542 in s32vector-set! */
static void C_ccall f_1544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1544,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1547,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fits_in_int_p(((C_word*)t0)[3]))){
t3=t2;
f_1547(2,t3,C_SCHEME_UNDEFINED);}
else{
/* srfi-4.scm:146: ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[32],lf[33],((C_word*)t0)[3]);}}

/* k1545 in k1542 in s32vector-set! */
static void C_ccall f_1547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1547,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[32]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_s32vector_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t2,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[32],t3,C_fix(0),((C_word*)t0)[2]);}}

/* k1568 in k1545 in k1542 in s32vector-set! */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s32vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* u32vector-set! */
static void C_ccall f_1483(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1483,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[14],lf[28]);
t6=C_u_i_32vector_length(t2);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1490,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* srfi-4.scm:133: ##sys#check-integer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t7,t4,lf[28]);}

/* k1488 in u32vector-set! */
static void C_ccall f_1490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1493,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_negativep(((C_word*)t0)[3]))){
/* srfi-4.scm:135: ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[28],lf[29],((C_word*)t0)[3]);}
else{
if(C_truep(C_fits_in_unsigned_int_p(((C_word*)t0)[3]))){
t3=C_SCHEME_UNDEFINED;
t4=t2;
f_1493(2,t4,t3);}
else{
/* srfi-4.scm:137: ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[28],lf[30],((C_word*)t0)[3]);}}}

/* k1491 in k1488 in u32vector-set! */
static void C_ccall f_1493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1493,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[28]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u32vector_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t2,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[28],t3,C_fix(0),((C_word*)t0)[2]);}}

/* k1514 in k1491 in k1488 in u32vector-set! */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u32vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* s16vector-set! */
static void C_ccall f_1451(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1451,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[12],lf[27]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[27]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1481,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[27]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_u_i_s16vector_set(t2,t3,t4));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t8,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[27],t9,C_fix(0),t6);}}

/* k1479 in s16vector-set! */
static void C_ccall f_1481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s16vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* u16vector-set! */
static void C_ccall f_1410(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1410,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[10],lf[25]);
t6=C_u_i_16vector_length(t2);
t7=C_i_check_exact_2(t4,lf[25]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1420,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:119: ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[25],lf[26],t4);}
else{
t9=t8;
f_1420(2,t9,C_SCHEME_UNDEFINED);}}

/* k1418 in u16vector-set! */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1443,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[25]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u16vector_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t2,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[25],t3,C_fix(0),((C_word*)t0)[2]);}}

/* k1441 in k1418 in u16vector-set! */
static void C_ccall f_1443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u16vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* s8vector-set! */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1378,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[8],lf[24]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[24]);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1408,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=t3;
t10=C_i_check_exact_2(t9,lf[24]);
t11=C_fixnum_less_or_equal_p(C_fix(0),t9);
t12=(C_truep(t11)?C_fixnum_lessp(t9,t6):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,C_u_i_s8vector_set(t2,t3,t4));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t8,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[24],t9,C_fix(0),t6);}}

/* k1406 in s8vector-set! */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_s8vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* u8vector-set! */
static void C_ccall f_1337(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_1337,5,t0,t1,t2,t3,t4);}
t5=C_i_check_structure_2(t2,lf[6],lf[21]);
t6=C_u_i_8vector_length(t2);
t7=C_i_check_exact_2(t4,lf[21]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1347,a[2]=t6,a[3]=t4,a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t4,C_fix(0)))){
/* srfi-4.scm:103: ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t8,lf[21],lf[23],t4);}
else{
t9=t8;
f_1347(2,t9,C_SCHEME_UNDEFINED);}}

/* k1345 in u8vector-set! */
static void C_ccall f_1347(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1347,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[4];
t4=C_i_check_exact_2(t3,lf[21]);
t5=C_fixnum_less_or_equal_p(C_fix(0),t3);
t6=(C_truep(t5)?C_fixnum_lessp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_u_i_u8vector_set(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]));}
else{
/* srfi-4.scm:56: ##sys#error-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[22]+1)))(7,*((C_word*)lf[22]+1),t2,C_fix((C_word)C_OUT_OF_RANGE_ERROR),lf[21],t3,C_fix(0),((C_word*)t0)[2]);}}

/* k1368 in k1345 in u8vector-set! */
static void C_ccall f_1370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_u_i_u8vector_set(((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]));}

/* f64vector-length */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1331,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[20],lf[19]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_64vector_length(t2));}

/* f32vector-length */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1325,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[18],lf[17]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* s32vector-length */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1319,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[16],lf[15]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* u32vector-length */
static void C_ccall f_1313(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1313,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[14],lf[13]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_32vector_length(t2));}

/* s16vector-length */
static void C_ccall f_1307(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1307,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[12],lf[11]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_16vector_length(t2));}

/* u16vector-length */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1301,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[10],lf[9]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_16vector_length(t2));}

/* s8vector-length */
static void C_ccall f_1295(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1295,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[8],lf[7]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_8vector_length(t2));}

/* u8vector-length */
static void C_ccall f_1289(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1289,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[6],lf[5]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_8vector_length(t2));}

/* ##sys#check-exact-interval */
static void C_fcall f_1274(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,5,t1,t2,t3,t4,t5);}
t6=C_i_check_exact_2(t2,t5);
t7=C_fixnum_lessp(t2,t3);
t8=(C_truep(t7)?t7:C_fixnum_greaterp(t2,t4));
if(C_truep(t8)){
/* srfi-4.scm:51: ##sys#error */
t9=*((C_word*)lf[3]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t1,t5,lf[4],t2,t3,t4);}
else{
t9=C_SCHEME_UNDEFINED;
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[293] = {
{"toplevel:srfi_4_scm",(void*)C_srfi_4_toplevel},
{"f_4387:srfi_4_scm",(void*)f_4387},
{"f_4414:srfi_4_scm",(void*)f_4414},
{"f_1652:srfi_4_scm",(void*)f_1652},
{"f_4358:srfi_4_scm",(void*)f_4358},
{"f_4385:srfi_4_scm",(void*)f_4385},
{"f_1656:srfi_4_scm",(void*)f_1656},
{"f_4329:srfi_4_scm",(void*)f_4329},
{"f_4356:srfi_4_scm",(void*)f_4356},
{"f_1660:srfi_4_scm",(void*)f_1660},
{"f_4300:srfi_4_scm",(void*)f_4300},
{"f_4327:srfi_4_scm",(void*)f_4327},
{"f_1664:srfi_4_scm",(void*)f_1664},
{"f_4271:srfi_4_scm",(void*)f_4271},
{"f_4298:srfi_4_scm",(void*)f_4298},
{"f_1668:srfi_4_scm",(void*)f_1668},
{"f_4242:srfi_4_scm",(void*)f_4242},
{"f_4269:srfi_4_scm",(void*)f_4269},
{"f_1672:srfi_4_scm",(void*)f_1672},
{"f_4213:srfi_4_scm",(void*)f_4213},
{"f_4240:srfi_4_scm",(void*)f_4240},
{"f_1676:srfi_4_scm",(void*)f_1676},
{"f_4184:srfi_4_scm",(void*)f_4184},
{"f_4211:srfi_4_scm",(void*)f_4211},
{"f_1680:srfi_4_scm",(void*)f_1680},
{"f_3392:srfi_4_scm",(void*)f_3392},
{"f_3396:srfi_4_scm",(void*)f_3396},
{"f_3400:srfi_4_scm",(void*)f_3400},
{"f_3404:srfi_4_scm",(void*)f_3404},
{"f_3408:srfi_4_scm",(void*)f_3408},
{"f_3412:srfi_4_scm",(void*)f_3412},
{"f_3416:srfi_4_scm",(void*)f_3416},
{"f_3420:srfi_4_scm",(void*)f_3420},
{"f_3424:srfi_4_scm",(void*)f_3424},
{"f_3428:srfi_4_scm",(void*)f_3428},
{"f_3432:srfi_4_scm",(void*)f_3432},
{"f_3436:srfi_4_scm",(void*)f_3436},
{"f_3440:srfi_4_scm",(void*)f_3440},
{"f_3444:srfi_4_scm",(void*)f_3444},
{"f_3448:srfi_4_scm",(void*)f_3448},
{"f_3452:srfi_4_scm",(void*)f_3452},
{"f_3456:srfi_4_scm",(void*)f_3456},
{"f_3460:srfi_4_scm",(void*)f_3460},
{"f_3464:srfi_4_scm",(void*)f_3464},
{"f_3468:srfi_4_scm",(void*)f_3468},
{"f_3472:srfi_4_scm",(void*)f_3472},
{"f_3476:srfi_4_scm",(void*)f_3476},
{"f_3480:srfi_4_scm",(void*)f_3480},
{"f_3484:srfi_4_scm",(void*)f_3484},
{"f_4182:srfi_4_scm",(void*)f_4182},
{"f_4064:srfi_4_scm",(void*)f_4064},
{"f_4133:srfi_4_scm",(void*)f_4133},
{"f_4128:srfi_4_scm",(void*)f_4128},
{"f_4066:srfi_4_scm",(void*)f_4066},
{"f_4070:srfi_4_scm",(void*)f_4070},
{"f_4097:srfi_4_scm",(void*)f_4097},
{"f_4102:srfi_4_scm",(void*)f_4102},
{"f_4106:srfi_4_scm",(void*)f_4106},
{"f_4124:srfi_4_scm",(void*)f_4124},
{"f_4115:srfi_4_scm",(void*)f_4115},
{"f_4079:srfi_4_scm",(void*)f_4079},
{"f_4082:srfi_4_scm",(void*)f_4082},
{"f_4055:srfi_4_scm",(void*)f_4055},
{"f_4063:srfi_4_scm",(void*)f_4063},
{"f_3954:srfi_4_scm",(void*)f_3954},
{"f_4006:srfi_4_scm",(void*)f_4006},
{"f_4001:srfi_4_scm",(void*)f_4001},
{"f_3956:srfi_4_scm",(void*)f_3956},
{"f_3960:srfi_4_scm",(void*)f_3960},
{"f_3841:srfi_4_scm",(void*)f_3841},
{"f_3891:srfi_4_scm",(void*)f_3891},
{"f_3886:srfi_4_scm",(void*)f_3886},
{"f_3877:srfi_4_scm",(void*)f_3877},
{"f_3885:srfi_4_scm",(void*)f_3885},
{"f_3843:srfi_4_scm",(void*)f_3843},
{"f_3850:srfi_4_scm",(void*)f_3850},
{"f_3855:srfi_4_scm",(void*)f_3855},
{"f_3865:srfi_4_scm",(void*)f_3865},
{"f_3835:srfi_4_scm",(void*)f_3835},
{"f_3829:srfi_4_scm",(void*)f_3829},
{"f_3823:srfi_4_scm",(void*)f_3823},
{"f_3817:srfi_4_scm",(void*)f_3817},
{"f_3811:srfi_4_scm",(void*)f_3811},
{"f_3805:srfi_4_scm",(void*)f_3805},
{"f_3799:srfi_4_scm",(void*)f_3799},
{"f_3793:srfi_4_scm",(void*)f_3793},
{"f_3710:srfi_4_scm",(void*)f_3710},
{"f_3743:srfi_4_scm",(void*)f_3743},
{"f_3766:srfi_4_scm",(void*)f_3766},
{"f_3772:srfi_4_scm",(void*)f_3772},
{"f_3550:srfi_4_scm",(void*)f_3550},
{"f_3560:srfi_4_scm",(void*)f_3560},
{"f_3563:srfi_4_scm",(void*)f_3563},
{"f_3573:srfi_4_scm",(void*)f_3573},
{"f_3489:srfi_4_scm",(void*)f_3489},
{"f_3499:srfi_4_scm",(void*)f_3499},
{"f_3518:srfi_4_scm",(void*)f_3518},
{"f_3529:srfi_4_scm",(void*)f_3529},
{"f5122:srfi_4_scm",(void*)f5122},
{"f5129:srfi_4_scm",(void*)f5129},
{"f5136:srfi_4_scm",(void*)f5136},
{"f5143:srfi_4_scm",(void*)f5143},
{"f5150:srfi_4_scm",(void*)f5150},
{"f5157:srfi_4_scm",(void*)f5157},
{"f5164:srfi_4_scm",(void*)f5164},
{"f5171:srfi_4_scm",(void*)f5171},
{"f_3326:srfi_4_scm",(void*)f_3326},
{"f_3328:srfi_4_scm",(void*)f_3328},
{"f_3338:srfi_4_scm",(void*)f_3338},
{"f_3297:srfi_4_scm",(void*)f_3297},
{"f_3299:srfi_4_scm",(void*)f_3299},
{"f_3279:srfi_4_scm",(void*)f_3279},
{"f_3281:srfi_4_scm",(void*)f_3281},
{"f_3291:srfi_4_scm",(void*)f_3291},
{"f_3262:srfi_4_scm",(void*)f_3262},
{"f_3256:srfi_4_scm",(void*)f_3256},
{"f_3250:srfi_4_scm",(void*)f_3250},
{"f_3244:srfi_4_scm",(void*)f_3244},
{"f_3238:srfi_4_scm",(void*)f_3238},
{"f_3232:srfi_4_scm",(void*)f_3232},
{"f_3226:srfi_4_scm",(void*)f_3226},
{"f_3220:srfi_4_scm",(void*)f_3220},
{"f_3191:srfi_4_scm",(void*)f_3191},
{"f_3200:srfi_4_scm",(void*)f_3200},
{"f_3214:srfi_4_scm",(void*)f_3214},
{"f_3162:srfi_4_scm",(void*)f_3162},
{"f_3171:srfi_4_scm",(void*)f_3171},
{"f_3185:srfi_4_scm",(void*)f_3185},
{"f_3133:srfi_4_scm",(void*)f_3133},
{"f_3142:srfi_4_scm",(void*)f_3142},
{"f_3156:srfi_4_scm",(void*)f_3156},
{"f_3104:srfi_4_scm",(void*)f_3104},
{"f_3113:srfi_4_scm",(void*)f_3113},
{"f_3127:srfi_4_scm",(void*)f_3127},
{"f_3075:srfi_4_scm",(void*)f_3075},
{"f_3084:srfi_4_scm",(void*)f_3084},
{"f_3098:srfi_4_scm",(void*)f_3098},
{"f_3046:srfi_4_scm",(void*)f_3046},
{"f_3055:srfi_4_scm",(void*)f_3055},
{"f_3069:srfi_4_scm",(void*)f_3069},
{"f_3017:srfi_4_scm",(void*)f_3017},
{"f_3026:srfi_4_scm",(void*)f_3026},
{"f_3040:srfi_4_scm",(void*)f_3040},
{"f_2988:srfi_4_scm",(void*)f_2988},
{"f_2997:srfi_4_scm",(void*)f_2997},
{"f_3011:srfi_4_scm",(void*)f_3011},
{"f_2982:srfi_4_scm",(void*)f_2982},
{"f_2976:srfi_4_scm",(void*)f_2976},
{"f_2970:srfi_4_scm",(void*)f_2970},
{"f_2964:srfi_4_scm",(void*)f_2964},
{"f_2958:srfi_4_scm",(void*)f_2958},
{"f_2952:srfi_4_scm",(void*)f_2952},
{"f_2946:srfi_4_scm",(void*)f_2946},
{"f_2940:srfi_4_scm",(void*)f_2940},
{"f_2907:srfi_4_scm",(void*)f_2907},
{"f_2914:srfi_4_scm",(void*)f_2914},
{"f_2919:srfi_4_scm",(void*)f_2919},
{"f_2926:srfi_4_scm",(void*)f_2926},
{"f_2874:srfi_4_scm",(void*)f_2874},
{"f_2881:srfi_4_scm",(void*)f_2881},
{"f_2886:srfi_4_scm",(void*)f_2886},
{"f_2893:srfi_4_scm",(void*)f_2893},
{"f_2841:srfi_4_scm",(void*)f_2841},
{"f_2848:srfi_4_scm",(void*)f_2848},
{"f_2853:srfi_4_scm",(void*)f_2853},
{"f_2860:srfi_4_scm",(void*)f_2860},
{"f_2808:srfi_4_scm",(void*)f_2808},
{"f_2815:srfi_4_scm",(void*)f_2815},
{"f_2820:srfi_4_scm",(void*)f_2820},
{"f_2827:srfi_4_scm",(void*)f_2827},
{"f_2775:srfi_4_scm",(void*)f_2775},
{"f_2782:srfi_4_scm",(void*)f_2782},
{"f_2787:srfi_4_scm",(void*)f_2787},
{"f_2794:srfi_4_scm",(void*)f_2794},
{"f_2742:srfi_4_scm",(void*)f_2742},
{"f_2749:srfi_4_scm",(void*)f_2749},
{"f_2754:srfi_4_scm",(void*)f_2754},
{"f_2761:srfi_4_scm",(void*)f_2761},
{"f_2709:srfi_4_scm",(void*)f_2709},
{"f_2716:srfi_4_scm",(void*)f_2716},
{"f_2721:srfi_4_scm",(void*)f_2721},
{"f_2728:srfi_4_scm",(void*)f_2728},
{"f_2676:srfi_4_scm",(void*)f_2676},
{"f_2683:srfi_4_scm",(void*)f_2683},
{"f_2688:srfi_4_scm",(void*)f_2688},
{"f_2695:srfi_4_scm",(void*)f_2695},
{"f_2555:srfi_4_scm",(void*)f_2555},
{"f_2613:srfi_4_scm",(void*)f_2613},
{"f_2608:srfi_4_scm",(void*)f_2608},
{"f_2603:srfi_4_scm",(void*)f_2603},
{"f_2557:srfi_4_scm",(void*)f_2557},
{"f_2602:srfi_4_scm",(void*)f_2602},
{"f_2567:srfi_4_scm",(void*)f_2567},
{"f_2579:srfi_4_scm",(void*)f_2579},
{"f_2584:srfi_4_scm",(void*)f_2584},
{"f_2434:srfi_4_scm",(void*)f_2434},
{"f_2492:srfi_4_scm",(void*)f_2492},
{"f_2487:srfi_4_scm",(void*)f_2487},
{"f_2482:srfi_4_scm",(void*)f_2482},
{"f_2436:srfi_4_scm",(void*)f_2436},
{"f_2481:srfi_4_scm",(void*)f_2481},
{"f_2446:srfi_4_scm",(void*)f_2446},
{"f_2458:srfi_4_scm",(void*)f_2458},
{"f_2463:srfi_4_scm",(void*)f_2463},
{"f_2317:srfi_4_scm",(void*)f_2317},
{"f_2371:srfi_4_scm",(void*)f_2371},
{"f_2366:srfi_4_scm",(void*)f_2366},
{"f_2361:srfi_4_scm",(void*)f_2361},
{"f_2319:srfi_4_scm",(void*)f_2319},
{"f_2360:srfi_4_scm",(void*)f_2360},
{"f_2329:srfi_4_scm",(void*)f_2329},
{"f_2343:srfi_4_scm",(void*)f_2343},
{"f_2200:srfi_4_scm",(void*)f_2200},
{"f_2254:srfi_4_scm",(void*)f_2254},
{"f_2249:srfi_4_scm",(void*)f_2249},
{"f_2244:srfi_4_scm",(void*)f_2244},
{"f_2202:srfi_4_scm",(void*)f_2202},
{"f_2243:srfi_4_scm",(void*)f_2243},
{"f_2212:srfi_4_scm",(void*)f_2212},
{"f_2226:srfi_4_scm",(void*)f_2226},
{"f_2083:srfi_4_scm",(void*)f_2083},
{"f_2137:srfi_4_scm",(void*)f_2137},
{"f_2132:srfi_4_scm",(void*)f_2132},
{"f_2127:srfi_4_scm",(void*)f_2127},
{"f_2085:srfi_4_scm",(void*)f_2085},
{"f_2126:srfi_4_scm",(void*)f_2126},
{"f_2095:srfi_4_scm",(void*)f_2095},
{"f_2104:srfi_4_scm",(void*)f_2104},
{"f_2109:srfi_4_scm",(void*)f_2109},
{"f_1966:srfi_4_scm",(void*)f_1966},
{"f_2020:srfi_4_scm",(void*)f_2020},
{"f_2015:srfi_4_scm",(void*)f_2015},
{"f_2010:srfi_4_scm",(void*)f_2010},
{"f_1968:srfi_4_scm",(void*)f_1968},
{"f_2009:srfi_4_scm",(void*)f_2009},
{"f_1978:srfi_4_scm",(void*)f_1978},
{"f_1987:srfi_4_scm",(void*)f_1987},
{"f_1992:srfi_4_scm",(void*)f_1992},
{"f_1849:srfi_4_scm",(void*)f_1849},
{"f_1903:srfi_4_scm",(void*)f_1903},
{"f_1898:srfi_4_scm",(void*)f_1898},
{"f_1893:srfi_4_scm",(void*)f_1893},
{"f_1851:srfi_4_scm",(void*)f_1851},
{"f_1892:srfi_4_scm",(void*)f_1892},
{"f_1861:srfi_4_scm",(void*)f_1861},
{"f_1870:srfi_4_scm",(void*)f_1870},
{"f_1875:srfi_4_scm",(void*)f_1875},
{"f_1732:srfi_4_scm",(void*)f_1732},
{"f_1786:srfi_4_scm",(void*)f_1786},
{"f_1781:srfi_4_scm",(void*)f_1781},
{"f_1776:srfi_4_scm",(void*)f_1776},
{"f_1734:srfi_4_scm",(void*)f_1734},
{"f_1775:srfi_4_scm",(void*)f_1775},
{"f_1744:srfi_4_scm",(void*)f_1744},
{"f_1753:srfi_4_scm",(void*)f_1753},
{"f_1758:srfi_4_scm",(void*)f_1758},
{"f_1707:srfi_4_scm",(void*)f_1707},
{"f_1714:srfi_4_scm",(void*)f_1714},
{"f_1689:srfi_4_scm",(void*)f_1689},
{"f_1705:srfi_4_scm",(void*)f_1705},
{"f_1687:srfi_4_scm",(void*)f_1687},
{"f_1614:srfi_4_scm",(void*)f_1614},
{"f_1644:srfi_4_scm",(void*)f_1644},
{"f_1578:srfi_4_scm",(void*)f_1578},
{"f_1608:srfi_4_scm",(void*)f_1608},
{"f_1537:srfi_4_scm",(void*)f_1537},
{"f_1544:srfi_4_scm",(void*)f_1544},
{"f_1547:srfi_4_scm",(void*)f_1547},
{"f_1570:srfi_4_scm",(void*)f_1570},
{"f_1483:srfi_4_scm",(void*)f_1483},
{"f_1490:srfi_4_scm",(void*)f_1490},
{"f_1493:srfi_4_scm",(void*)f_1493},
{"f_1516:srfi_4_scm",(void*)f_1516},
{"f_1451:srfi_4_scm",(void*)f_1451},
{"f_1481:srfi_4_scm",(void*)f_1481},
{"f_1410:srfi_4_scm",(void*)f_1410},
{"f_1420:srfi_4_scm",(void*)f_1420},
{"f_1443:srfi_4_scm",(void*)f_1443},
{"f_1378:srfi_4_scm",(void*)f_1378},
{"f_1408:srfi_4_scm",(void*)f_1408},
{"f_1337:srfi_4_scm",(void*)f_1337},
{"f_1347:srfi_4_scm",(void*)f_1347},
{"f_1370:srfi_4_scm",(void*)f_1370},
{"f_1331:srfi_4_scm",(void*)f_1331},
{"f_1325:srfi_4_scm",(void*)f_1325},
{"f_1319:srfi_4_scm",(void*)f_1319},
{"f_1313:srfi_4_scm",(void*)f_1313},
{"f_1307:srfi_4_scm",(void*)f_1307},
{"f_1301:srfi_4_scm",(void*)f_1301},
{"f_1295:srfi_4_scm",(void*)f_1295},
{"f_1289:srfi_4_scm",(void*)f_1289},
{"f_1274:srfi_4_scm",(void*)f_1274},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
