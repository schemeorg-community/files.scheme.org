/* Generated from extras.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: extras.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file extras.c
   unit: extras
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[135];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,23),40,100,111,108,111,111,112,56,56,32,120,57,48,32,105,57,49,32,120,115,57,50,41,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,115,108,117,114,112,32,112,111,114,116,56,55,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,30),40,98,111,100,121,55,52,32,112,111,114,116,56,51,32,114,101,97,100,101,114,56,52,32,109,97,120,56,53,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,35),40,100,101,102,45,109,97,120,55,56,32,37,112,111,114,116,55,49,49,48,48,32,37,114,101,97,100,101,114,55,50,49,48,49,41,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,114,101,97,100,101,114,55,55,32,37,112,111,114,116,55,49,49,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,12),40,100,101,102,45,112,111,114,116,55,54,41,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,102,105,108,101,32,46,32,116,109,112,54,57,55,48,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,114,97,110,100,111,109,45,115,101,101,100,32,46,32,110,49,49,55,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,18),40,114,97,110,100,111,109,105,122,101,32,46,32,110,49,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,13),40,114,97,110,100,111,109,32,110,49,50,51,41,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,12),40,103,49,52,49,32,114,108,49,52,51,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,49,52,55,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,21),40,114,101,97,100,45,108,105,110,101,32,46,32,97,114,103,115,49,51,48,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,110,115,49,55,51,32,110,49,55,52,41,0,0,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,16),40,100,111,114,101,97,100,32,112,111,114,116,49,55,49,41};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,108,105,110,101,115,32,46,32,112,111,114,116,45,97,110,100,45,109,97,120,49,54,53,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,115,116,97,114,116,49,57,50,32,110,49,57,51,32,109,49,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,115,116,97,114,116,50,48,54,32,110,50,48,55,32,109,50,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,50),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,33,32,110,49,56,50,32,100,101,115,116,49,56,51,32,112,111,114,116,49,56,52,32,115,116,97,114,116,49,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,50,51,50,32,112,111,114,116,50,52,48,32,115,116,97,114,116,50,52,49,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,115,116,97,114,116,50,51,53,32,37,112,111,114,116,50,51,48,50,52,56,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,111,114,116,50,51,52,41,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,39),40,114,101,97,100,45,115,116,114,105,110,103,33,32,110,50,50,55,32,100,101,115,116,50,50,56,32,46,32,116,109,112,50,50,54,50,50,57,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,34),40,35,35,115,121,115,35,114,101,97,100,45,115,116,114,105,110,103,47,112,111,114,116,32,110,50,53,52,32,112,50,53,53,41,0,0,0,0,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,25),40,114,101,97,100,45,115,116,114,105,110,103,32,46,32,116,109,112,50,55,55,50,55,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,30),40,114,101,97,100,45,116,111,107,101,110,32,112,114,101,100,50,57,56,32,46,32,112,111,114,116,50,57,57,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,51,49,53,32,110,51,50,51,32,112,111,114,116,51,50,52,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,112,111,114,116,51,49,56,32,37,110,51,49,51,51,50,57,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,51,49,55,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,115,116,114,105,110,103,32,115,51,49,49,32,46,32,109,111,114,101,51,49,50,41,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,29),40,119,114,105,116,101,45,108,105,110,101,32,115,116,114,51,51,56,32,46,32,112,111,114,116,51,51,57,41,0,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,23),40,114,101,97,100,45,98,121,116,101,32,46,32,116,109,112,51,52,57,51,53,48,41,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,32),40,119,114,105,116,101,45,98,121,116,101,32,98,121,116,101,51,54,50,32,46,32,116,109,112,51,54,49,51,54,51,41};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,18),40,114,101,97,100,45,109,97,99,114,111,63,32,108,51,55,57,41,0,0,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,109,97,99,114,111,45,112,114,101,102,105,120,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,19),40,111,117,116,32,115,116,114,52,48,57,32,99,111,108,52,49,48,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,24),40,119,114,45,101,120,112,114,32,101,120,112,114,52,50,48,32,99,111,108,52,50,49,41};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,52,50,53,32,99,111,108,52,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,20),40,119,114,45,108,115,116,32,108,52,50,50,32,99,111,108,52,50,51,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,105,52,51,53,32,106,52,51,54,32,99,111,108,52,51,55,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,12),40,103,52,53,48,32,99,110,52,53,50,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,18),40,119,114,32,111,98,106,52,49,51,32,99,111,108,52,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,20),40,115,112,97,99,101,115,32,110,52,56,55,32,99,111,108,52,56,56,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,21),40,105,110,100,101,110,116,32,116,111,52,56,57,32,99,111,108,52,57,48,41,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,14),40,97,50,53,56,57,32,115,116,114,53,48,50,41,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,38),40,112,114,32,111,98,106,52,57,51,32,99,111,108,52,57,52,32,101,120,116,114,97,52,57,53,32,112,112,45,112,97,105,114,52,57,54,41,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,33),40,112,112,45,101,120,112,114,32,101,120,112,114,53,48,54,32,99,111,108,53,48,55,32,101,120,116,114,97,53,48,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,44),40,112,112,45,99,97,108,108,32,101,120,112,114,53,49,49,32,99,111,108,53,49,50,32,101,120,116,114,97,53,49,51,32,112,112,45,105,116,101,109,53,49,52,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,41),40,112,112,45,108,105,115,116,32,108,53,49,55,32,99,111,108,53,49,56,32,101,120,116,114,97,53,49,57,32,112,112,45,105,116,101,109,53,50,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,18),40,108,111,111,112,32,108,53,50,56,32,99,111,108,53,50,57,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,50),40,112,112,45,100,111,119,110,32,108,53,50,50,32,99,111,108,49,53,50,51,32,99,111,108,50,53,50,52,32,101,120,116,114,97,53,50,53,32,112,112,45,105,116,101,109,53,50,54,41,0,0,0,0,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,49,32,114,101,115,116,53,52,55,32,99,111,108,49,53,52,56,32,99,111,108,50,53,52,57,32,99,111,108,51,53,53,48,41,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,39),40,116,97,105,108,50,32,114,101,115,116,53,53,53,32,99,111,108,49,53,53,54,32,99,111,108,50,53,53,55,32,99,111,108,51,53,53,56,41,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,31),40,116,97,105,108,51,32,114,101,115,116,53,54,51,32,99,111,108,49,53,54,52,32,99,111,108,50,53,54,53,41,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,70),40,112,112,45,103,101,110,101,114,97,108,32,101,120,112,114,53,51,55,32,99,111,108,53,51,56,32,101,120,116,114,97,53,51,57,32,110,97,109,101,100,63,53,52,48,32,112,112,45,49,53,52,49,32,112,112,45,50,53,52,50,32,112,112,45,51,53,52,51,41,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,35),40,112,112,45,101,120,112,114,45,108,105,115,116,32,108,53,55,54,32,99,111,108,53,55,55,32,101,120,116,114,97,53,55,56,41,0,0,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,35),40,112,112,45,108,97,109,98,100,97,32,101,120,112,114,53,55,57,32,99,111,108,53,56,48,32,101,120,116,114,97,53,56,49,41,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,31),40,112,112,45,105,102,32,101,120,112,114,53,56,50,32,99,111,108,53,56,51,32,101,120,116,114,97,53,56,52,41,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,111,110,100,32,101,120,112,114,53,56,53,32,99,111,108,53,56,54,32,101,120,116,114,97,53,56,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,33),40,112,112,45,99,97,115,101,32,101,120,112,114,53,56,56,32,99,111,108,53,56,57,32,101,120,116,114,97,53,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,32),40,112,112,45,97,110,100,32,101,120,112,114,53,57,49,32,99,111,108,53,57,50,32,101,120,116,114,97,53,57,51,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,32),40,112,112,45,108,101,116,32,101,120,112,114,53,57,52,32,99,111,108,53,57,53,32,101,120,116,114,97,53,57,54,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,34),40,112,112,45,98,101,103,105,110,32,101,120,112,114,54,48,48,32,99,111,108,54,48,49,32,101,120,116,114,97,54,48,50,41,0,0,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,31),40,112,112,45,100,111,32,101,120,112,114,54,48,51,32,99,111,108,54,48,52,32,101,120,116,114,97,54,48,53,41,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,15),40,115,116,121,108,101,32,104,101,97,100,54,48,54,41,0};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,18),40,112,112,32,111,98,106,52,54,52,32,99,111,108,52,54,53,41,0,0,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,53),40,103,101,110,101,114,105,99,45,119,114,105,116,101,32,111,98,106,51,54,57,32,100,105,115,112,108,97,121,63,51,55,48,32,119,105,100,116,104,51,55,49,32,111,117,116,112,117,116,51,55,50,41,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,12),40,97,51,49,52,51,32,115,54,53,55,41,0,0,0,0};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,30),40,112,114,101,116,116,121,45,112,114,105,110,116,32,111,98,106,54,53,52,32,46,32,111,112,116,54,53,53,41,0,0};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,6),40,110,101,120,116,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,6),40,115,107,105,112,41,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,20),40,114,101,99,32,109,115,103,54,55,48,32,97,114,103,115,54,55,49,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,40),40,102,112,114,105,110,116,102,48,32,108,111,99,54,54,51,32,112,111,114,116,54,54,52,32,109,115,103,54,54,53,32,97,114,103,115,54,54,54,41};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,35),40,102,112,114,105,110,116,102,32,112,111,114,116,55,49,48,32,102,115,116,114,55,49,49,32,46,32,97,114,103,115,55,49,50,41,0,0,0,0,0};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,26),40,112,114,105,110,116,102,32,102,115,116,114,55,49,51,32,46,32,97,114,103,115,55,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,27),40,115,112,114,105,110,116,102,32,102,115,116,114,55,49,53,32,46,32,97,114,103,115,55,49,54,41,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,32),40,102,111,114,109,97,116,32,102,109,116,45,111,114,45,100,115,116,55,49,55,32,46,32,97,114,103,115,55,49,56,41};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k905 */
static C_word C_fcall stub114(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub114(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
unsigned int t0=(unsigned int )C_num_to_unsigned_int(C_a0);
srand(t0);
return C_r;}

C_noret_decl(C_extras_toplevel)
C_externexport void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_759)
static void C_ccall f_759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_762)
static void C_ccall f_762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_765)
static void C_ccall f_765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3519)
static void C_ccall f_3519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3476)
static void C_ccall f_3476r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3509)
static void C_ccall f_3509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3484)
static void C_ccall f_3484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3470)
static void C_ccall f_3470r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3458)
static void C_ccall f_3458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3160)
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3164)
static void C_ccall f_3164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3447)
static void C_ccall f_3447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3167)
static void C_ccall f_3167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3198)
static void C_fcall f_3198(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3233)
static void C_fcall f_3233(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static C_word C_fcall f_3411(C_word t0,C_word t1);
C_noret_decl(f_3366)
static void C_ccall f_3366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3369)
static void C_ccall f_3369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3348)
static void C_ccall f_3348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3344)
static void C_ccall f_3344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3310)
static void C_ccall f_3310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_ccall f_3284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3271)
static void C_ccall f_3271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3246)
static void C_ccall f_3246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3214)
static void C_fcall f_3214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3207)
static C_word C_fcall f_3207(C_word t0);
C_noret_decl(f_3170)
static void C_ccall f_3170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3192)
static void C_ccall f_3192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3131)
static void C_ccall f_3131r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3142)
static void C_ccall f_3142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3148)
static void C_ccall f_3148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1850)
static void C_fcall f_1850(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3118)
static void C_ccall f_3118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3122)
static void C_ccall f_3122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3026)
static void C_fcall f_3026(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3036)
static void C_fcall f_3036(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3017)
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3011)
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2989)
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2983)
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2977)
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2971)
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2965)
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2959)
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2953)
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2805)
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_2951)
static void C_ccall f_2951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2903)
static void C_ccall f_2903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2918)
static void C_ccall f_2918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2890)
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2849)
static void C_fcall f_2849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2808)
static void C_fcall f_2808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2835)
static void C_ccall f_2835(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2831)
static void C_ccall f_2831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2728)
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_2734)
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2803)
static void C_ccall f_2803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2791)
static void C_ccall f_2791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2787)
static void C_ccall f_2787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2765)
static void C_ccall f_2765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2719)
static void C_fcall f_2719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2723)
static void C_ccall f_2723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2691)
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2626)
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2633)
static void C_ccall f_2633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2686)
static void C_ccall f_2686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2555)
static void C_ccall f_2555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_ccall f_2584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2588)
static void C_ccall f_2588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2568)
static void C_ccall f_2568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2507)
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2530)
static void C_ccall f_2530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2474)
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2505)
static void C_ccall f_2505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2498)
static void C_ccall f_2498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1963)
static void C_fcall f_1963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2413)
static void C_ccall f_2413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2452)
static void C_ccall f_2452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_ccall f_2462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2455)
static void C_ccall f_2455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2433)
static void C_ccall f_2433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2400)
static void C_ccall f_2400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2354)
static void C_ccall f_2354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_ccall f_2333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_ccall f_2340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2317)
static void C_ccall f_2317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2324)
static void C_ccall f_2324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2297)
static void C_fcall f_2297(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2202)
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2209)
static void C_fcall f_2209(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_ccall f_2261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2257)
static void C_ccall f_2257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_ccall f_2236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2181)
static void C_ccall f_2181(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2158)
static void C_ccall f_2158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2168)
static void C_ccall f_2168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2123)
static void C_ccall f_2123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_fcall f_1993(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_ccall f_2061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2037)
static void C_ccall f_2037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1966)
static void C_fcall f_1966(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1973)
static void C_ccall f_1973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1984)
static void C_ccall f_1984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_fcall f_1944(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static C_word C_fcall f_1911(C_word t0);
C_noret_decl(f_1853)
static void C_fcall f_1853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_fcall f_1885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1816)
static void C_ccall f_1816(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1822)
static void C_ccall f_1822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1776)
static void C_ccall f_1776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1779)
static void C_ccall f_1779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1782)
static void C_ccall f_1782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1751)
static void C_ccall f_1751r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1764)
static void C_ccall f_1764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1662)
static void C_ccall f_1662r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1703)
static void C_fcall f_1703(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1698)
static void C_fcall f_1698(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1684)
static void C_fcall f_1684(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1681)
static void C_ccall f_1681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1600)
static void C_ccall f_1600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1603)
static void C_ccall f_1603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1608)
static void C_fcall f_1608(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1612)
static void C_ccall f_1612(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_ccall f_1628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1621)
static void C_ccall f_1621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1533)
static void C_ccall f_1533r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1476)
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1504)
static void C_ccall f_1504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1507)
static void C_ccall f_1507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_fcall f_1512(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1528)
static void C_ccall f_1528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1379)
static void C_ccall f_1379r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1428)
static void C_fcall f_1428(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1423)
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1381)
static void C_fcall f_1381(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1385)
static void C_ccall f_1385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1373)
static void C_ccall f_1373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_fcall f_1243(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1313)
static void C_fcall f_1313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1317)
static void C_ccall f_1317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1320)
static void C_fcall f_1320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_fcall f_1254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1210)
static void C_ccall f_1210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1165)
static void C_fcall f_1165(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1178)
static void C_ccall f_1178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1004)
static void C_fcall f_1004(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1007)
static void C_ccall f_1007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1027)
static void C_ccall f_1027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1032)
static void C_fcall f_1032(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1045)
static void C_ccall f_1045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1118)
static void C_ccall f_1118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1096)
static void C_fcall f_1096(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1078)
static void C_ccall f_1078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1087)
static void C_ccall f_1087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1014)
static void C_fcall f_1014(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_955)
static void C_ccall f_955(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_933)
static void C_ccall f_933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_908)
static void C_ccall f_908r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_915)
static void C_ccall f_915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_767)
static void C_ccall f_767r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_839)
static void C_fcall f_839(C_word t0,C_word t1) C_noret;
C_noret_decl(f_834)
static void C_fcall f_834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_829)
static void C_fcall f_829(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_769)
static void C_fcall f_769(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_822)
static void C_ccall f_822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_780)
static void C_ccall f_780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_fcall f_782(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_802)
static void C_ccall f_802(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_3160)
static void C_fcall trf_3160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3160(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3160(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3198)
static void C_fcall trf_3198(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3198(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3198(t0,t1,t2,t3);}

C_noret_decl(trf_3233)
static void C_fcall trf_3233(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3233(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3233(t0,t1);}

C_noret_decl(trf_3214)
static void C_fcall trf_3214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3214(t0,t1);}

C_noret_decl(trf_1850)
static void C_fcall trf_1850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1850(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1850(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2471)
static void C_fcall trf_2471(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2471(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2471(t0,t1,t2,t3);}

C_noret_decl(trf_3026)
static void C_fcall trf_3026(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3026(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3026(t0,t1,t2);}

C_noret_decl(trf_3036)
static void C_fcall trf_3036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3036(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3036(t0,t1);}

C_noret_decl(trf_2805)
static void C_fcall trf_2805(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2805(void *dummy){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
f_2805(t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(trf_2890)
static void C_fcall trf_2890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2890(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2890(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2849)
static void C_fcall trf_2849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2849(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2849(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2808)
static void C_fcall trf_2808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2808(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2808(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2728)
static void C_fcall trf_2728(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2728(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_2728(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_2734)
static void C_fcall trf_2734(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2734(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2734(t0,t1,t2,t3);}

C_noret_decl(trf_2719)
static void C_fcall trf_2719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2719(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2719(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2691)
static void C_fcall trf_2691(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2691(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2691(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_2539(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_2507)
static void C_fcall trf_2507(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2507(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2507(t0,t1,t2,t3);}

C_noret_decl(trf_2474)
static void C_fcall trf_2474(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2474(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2474(t0,t1,t2,t3);}

C_noret_decl(trf_1963)
static void C_fcall trf_1963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1963(t0,t1,t2,t3);}

C_noret_decl(trf_2297)
static void C_fcall trf_2297(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2297(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2297(t0,t1,t2);}

C_noret_decl(trf_2202)
static void C_fcall trf_2202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2202(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2202(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2209)
static void C_fcall trf_2209(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2209(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2209(t0,t1);}

C_noret_decl(trf_1993)
static void C_fcall trf_1993(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1993(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1993(t0,t1,t2,t3);}

C_noret_decl(trf_2013)
static void C_fcall trf_2013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2013(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2013(t0,t1,t2,t3);}

C_noret_decl(trf_1966)
static void C_fcall trf_1966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1966(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1966(t0,t1,t2,t3);}

C_noret_decl(trf_1944)
static void C_fcall trf_1944(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1944(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1944(t0,t1,t2,t3);}

C_noret_decl(trf_1853)
static void C_fcall trf_1853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1853(t0,t1);}

C_noret_decl(trf_1885)
static void C_fcall trf_1885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1885(t0,t1);}

C_noret_decl(trf_1703)
static void C_fcall trf_1703(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1703(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1703(t0,t1);}

C_noret_decl(trf_1698)
static void C_fcall trf_1698(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1698(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1698(t0,t1,t2);}

C_noret_decl(trf_1667)
static void C_fcall trf_1667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1667(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1667(t0,t1,t2,t3);}

C_noret_decl(trf_1684)
static void C_fcall trf_1684(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1684(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1684(t0,t1);}

C_noret_decl(trf_1608)
static void C_fcall trf_1608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1608(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1608(t0,t1);}

C_noret_decl(trf_1512)
static void C_fcall trf_1512(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1512(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1512(t0,t1);}

C_noret_decl(trf_1428)
static void C_fcall trf_1428(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1428(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1428(t0,t1);}

C_noret_decl(trf_1423)
static void C_fcall trf_1423(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1423(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1423(t0,t1,t2);}

C_noret_decl(trf_1381)
static void C_fcall trf_1381(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1381(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1381(t0,t1,t2,t3);}

C_noret_decl(trf_1243)
static void C_fcall trf_1243(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1243(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1243(t0,t1);}

C_noret_decl(trf_1313)
static void C_fcall trf_1313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1313(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1313(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1320)
static void C_fcall trf_1320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1320(t0,t1);}

C_noret_decl(trf_1254)
static void C_fcall trf_1254(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1254(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1254(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1165)
static void C_fcall trf_1165(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1165(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1165(t0,t1,t2,t3);}

C_noret_decl(trf_1004)
static void C_fcall trf_1004(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1004(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1004(t0,t1);}

C_noret_decl(trf_1032)
static void C_fcall trf_1032(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1032(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1032(t0,t1,t2);}

C_noret_decl(trf_1096)
static void C_fcall trf_1096(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1096(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1096(t0,t1);}

C_noret_decl(trf_1014)
static void C_fcall trf_1014(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1014(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1014(t0,t1,t2);}

C_noret_decl(trf_839)
static void C_fcall trf_839(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_839(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_839(t0,t1);}

C_noret_decl(trf_834)
static void C_fcall trf_834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_834(t0,t1,t2);}

C_noret_decl(trf_829)
static void C_fcall trf_829(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_829(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_829(t0,t1,t2,t3);}

C_noret_decl(trf_769)
static void C_fcall trf_769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_769(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_769(t0,t1,t2,t3,t4);}

C_noret_decl(trf_782)
static void C_fcall trf_782(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_782(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_782(t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_extras_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_extras_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("extras_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(854)){
C_save(t1);
C_rereclaim2(854*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,135);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],4,"read");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],20,"call-with-input-file");
lf[5]=C_h_intern(&lf[5],9,"read-file");
lf[6]=C_h_intern(&lf[6],5,"port\077");
lf[7]=C_h_intern(&lf[7],18,"\003sysstandard-input");
lf[8]=C_h_intern(&lf[8],9,"\003syserror");
lf[9]=C_h_intern(&lf[9],11,"random-seed");
lf[10]=C_h_intern(&lf[10],17,"\003syscheck-integer");
lf[11]=C_h_intern(&lf[11],15,"current-seconds");
lf[12]=C_h_intern(&lf[12],9,"randomize");
lf[13]=C_decode_literal(C_heaptop,"\376U1000.0\000");
lf[14]=C_h_intern(&lf[14],18,"\003sysinexact->exact");
lf[15]=C_h_intern(&lf[15],6,"random");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_h_intern(&lf[17],9,"read-line");
lf[18]=C_h_intern(&lf[18],13,"\003syssubstring");
lf[19]=C_h_intern(&lf[19],15,"\003sysread-char-0");
lf[20]=C_h_intern(&lf[20],9,"peek-char");
lf[21]=C_h_intern(&lf[21],17,"\003sysstring-append");
lf[22]=C_h_intern(&lf[22],15,"\003sysmake-string");
lf[23]=C_h_intern(&lf[23],14,"\003syscheck-port");
lf[24]=C_h_intern(&lf[24],10,"read-lines");
lf[25]=C_h_intern(&lf[25],16,"\003sysread-string!");
lf[26]=C_h_intern(&lf[26],12,"read-string!");
lf[27]=C_h_intern(&lf[27],20,"\003sysread-string/port");
lf[28]=C_h_intern(&lf[28],11,"read-string");
lf[29]=C_h_intern(&lf[29],17,"get-output-string");
lf[30]=C_h_intern(&lf[30],12,"write-string");
lf[31]=C_h_intern(&lf[31],18,"open-output-string");
lf[32]=C_h_intern(&lf[32],10,"read-token");
lf[33]=C_h_intern(&lf[33],16,"\003syswrite-char-0");
lf[34]=C_h_intern(&lf[34],15,"\003syspeek-char-0");
lf[35]=C_h_intern(&lf[35],7,"display");
lf[36]=C_h_intern(&lf[36],19,"\003sysstandard-output");
lf[37]=C_h_intern(&lf[37],7,"newline");
lf[38]=C_h_intern(&lf[38],10,"write-line");
lf[39]=C_h_intern(&lf[39],9,"read-byte");
lf[40]=C_h_intern(&lf[40],10,"write-byte");
lf[42]=C_h_intern(&lf[42],5,"quote");
lf[43]=C_h_intern(&lf[43],10,"quasiquote");
lf[44]=C_h_intern(&lf[44],7,"unquote");
lf[45]=C_h_intern(&lf[45],16,"unquote-splicing");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001\047");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001`");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\002,@");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\003 . ");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[55]=C_decode_literal(C_heaptop,"\376B\000\000\002()");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\005#!eof");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[58]=C_h_intern(&lf[58],12,"vector->list");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002#t");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002#f");
lf[61]=C_h_intern(&lf[61],18,"\003sysnumber->string");
lf[62]=C_h_intern(&lf[62],9,"\003sysprint");
lf[63]=C_h_intern(&lf[63],21,"\003sysprocedure->string");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\001x");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001u");
lf[70]=C_h_intern(&lf[70],9,"char-name");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002#\134");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\006#<eof>");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\016#<unspecified>");
lf[74]=C_h_intern(&lf[74],19,"\003syspointer->string");
lf[75]=C_h_intern(&lf[75],28,"\003sysarbitrary-unbound-symbol");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\020#<unbound value>");
lf[77]=C_h_intern(&lf[77],19,"\003sysuser-print-hook");
lf[78]=C_h_intern(&lf[78],13,"string-append");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\007#<port ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\001>");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\025#<static blob of size");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\017#<blob of size ");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\002#>");
lf[85]=C_h_intern(&lf[85],23,"\003syslambda-info->string");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\016#<lambda info ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025#<unprintable object>");
lf[88]=C_h_intern(&lf[88],11,"\003sysnumber\077");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\010        ");
lf[91]=C_h_intern(&lf[91],21,"reverse-string-append");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\001#");
lf[93]=C_h_intern(&lf[93],3,"max");
lf[94]=C_h_intern(&lf[94],28,"\003syssymbol->qualified-string");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[102]=C_h_intern(&lf[102],6,"lambda");
lf[103]=C_h_intern(&lf[103],2,"if");
lf[104]=C_h_intern(&lf[104],4,"set!");
lf[105]=C_h_intern(&lf[105],4,"cond");
lf[106]=C_h_intern(&lf[106],4,"case");
lf[107]=C_h_intern(&lf[107],3,"and");
lf[108]=C_h_intern(&lf[108],2,"or");
lf[109]=C_h_intern(&lf[109],3,"let");
lf[110]=C_h_intern(&lf[110],5,"begin");
lf[111]=C_h_intern(&lf[111],2,"do");
lf[112]=C_h_intern(&lf[112],4,"let*");
lf[113]=C_h_intern(&lf[113],6,"letrec");
lf[114]=C_h_intern(&lf[114],6,"define");
lf[115]=C_h_intern(&lf[115],18,"pretty-print-width");
lf[116]=C_h_intern(&lf[116],12,"pretty-print");
lf[117]=C_h_intern(&lf[117],19,"current-output-port");
lf[118]=C_h_intern(&lf[118],2,"pp");
lf[119]=C_h_intern(&lf[119],5,"write");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000/too few arguments to formatted output procedure");
lf[122]=C_h_intern(&lf[122],16,"\003sysflush-output");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\037illegal format-string character");
lf[124]=C_h_intern(&lf[124],13,"\003systty-port\077");
lf[125]=C_h_intern(&lf[125],7,"fprintf");
lf[126]=C_h_intern(&lf[126],6,"printf");
lf[127]=C_h_intern(&lf[127],7,"sprintf");
lf[128]=C_h_intern(&lf[128],6,"format");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\023illegal destination");
lf[130]=C_h_intern(&lf[130],12,"output-port\077");
lf[131]=C_h_intern(&lf[131],17,"register-feature!");
lf[132]=C_h_intern(&lf[132],7,"srfi-28");
lf[133]=C_h_intern(&lf[133],14,"make-parameter");
lf[134]=C_h_intern(&lf[134],6,"extras");
C_register_lf2(lf,135,create_ptable());
t2=C_mutate(&lf[0] /* (set! c111 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_759,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k757 */
static void C_ccall f_759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_762,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k760 in k757 */
static void C_ccall f_762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_765,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm:37: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t2,lf[134]);}

/* k763 in k760 in k757 */
static void C_ccall f_765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word ab[60],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_765,2,t0,t1);}
t2=*((C_word*)lf[2]+1);
t3=*((C_word*)lf[3]+1);
t4=*((C_word*)lf[4]+1);
t5=C_mutate((C_word*)lf[5]+1 /* (set! read-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_767,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=((C_word)li6),tmp=(C_word)a,a+=6,tmp));
t6=C_mutate((C_word*)lf[9]+1 /* (set! random-seed ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_908,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[12]+1 /* (set! randomize ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[15]+1 /* (set! random ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_955,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t9=*((C_word*)lf[16]+1);
t10=C_mutate((C_word*)lf[17]+1 /* (set! read-line ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_994,a[2]=t9,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t11=*((C_word*)lf[4]+1);
t12=*((C_word*)lf[3]+1);
t13=C_mutate((C_word*)lf[24]+1 /* (set! read-lines ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1143,a[2]=t11,a[3]=t12,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp));
t14=C_mutate((C_word*)lf[25]+1 /* (set! ##sys#read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1233,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! read-string! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1379,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[27]+1 /* (set! ##sys#read-string/port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1476,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[28]+1 /* (set! read-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1533,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[32]+1 /* (set! read-token ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1593,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[35]+1);
t20=C_mutate((C_word*)lf[30]+1 /* (set! write-string ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1662,a[2]=t19,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[35]+1);
t22=*((C_word*)lf[37]+1);
t23=C_mutate((C_word*)lf[38]+1 /* (set! write-line ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1751,a[2]=t21,a[3]=t22,a[4]=((C_word)li32),tmp=(C_word)a,a+=5,tmp));
t24=C_mutate((C_word*)lf[39]+1 /* (set! read-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1772,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[40]+1 /* (set! write-byte ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate(&lf[41] /* (set! generic-write ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t27=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm:549: make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[133]+1)))(3,*((C_word*)lf[133]+1),t27,C_fix(79));}

/* k3127 in k763 in k760 in k757 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=C_mutate((C_word*)lf[115]+1 /* (set! pretty-print-width ...) */,t1);
t3=C_mutate((C_word*)lf[116]+1 /* (set! pretty-print ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3131,a[2]=((C_word)li70),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[118]+1 /* (set! pp ...) */,*((C_word*)lf[116]+1));
t5=*((C_word*)lf[119]+1);
t6=*((C_word*)lf[37]+1);
t7=*((C_word*)lf[35]+1);
t8=C_mutate(&lf[120] /* (set! fprintf0 ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3160,a[2]=t6,a[3]=t7,a[4]=t5,a[5]=((C_word)li75),tmp=(C_word)a,a+=6,tmp));
t9=C_mutate((C_word*)lf[125]+1 /* (set! fprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3458,a[2]=((C_word)li76),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[126]+1 /* (set! printf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3464,a[2]=((C_word)li77),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[127]+1 /* (set! sprintf ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3470,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[128]+1 /* (set! format ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3476,a[2]=((C_word)li79),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3519,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* extras.scm:636: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[131]+1)))(3,*((C_word*)lf[131]+1),t13,lf[132]);}

/* k3517 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* format in k3127 in k763 in k760 in k757 */
static void C_ccall f_3476(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_3476r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3476r(t0,t1,t2,t3);}}

static void C_ccall f_3476r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(12);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3484,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=t2;
if(C_truep(t6)){
if(C_truep(C_booleanp(t2))){
t7=*((C_word*)lf[126]+1);
C_apply(4,0,t1,t7,((C_word*)t4)[1]);}
else{
if(C_truep(C_i_stringp(t2))){
t7=C_a_i_cons(&a,2,t2,((C_word*)t4)[1]);
t8=C_set_block_item(t4,0,t7);
t9=*((C_word*)lf[127]+1);
C_apply(4,0,t1,t9,((C_word*)t4)[1]);}
else{
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3509,a[2]=t5,a[3]=t1,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* extras.scm:631: output-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[130]+1)))(3,*((C_word*)lf[130]+1),t7,t2);}}}
else{
t7=*((C_word*)lf[127]+1);
C_apply(4,0,t1,t7,((C_word*)t4)[1]);}}

/* k3507 in format in k3127 in k763 in k760 in k757 */
static void C_ccall f_3509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3509,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=*((C_word*)lf[125]+1);
C_apply(4,0,((C_word*)t0)[3],t4,((C_word*)((C_word*)t0)[4])[1]);}
else{
/* extras.scm:633: ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[128],lf[129],((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1]);}}

/* k3482 in format in k3127 in k763 in k760 in k757 */
static void C_ccall f_3484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* sprintf in k3127 in k763 in k760 in k757 */
static void C_ccall f_3470(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3470r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3470r(t0,t1,t2,t3);}}

static void C_ccall f_3470r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm:624: fprintf0 */
t4=lf[120];
f_3160(t4,t1,lf[127],C_SCHEME_FALSE,t2,t3);}

/* printf in k3127 in k763 in k760 in k757 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_3464r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3464r(t0,t1,t2,t3);}}

static void C_ccall f_3464r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
/* extras.scm:621: fprintf0 */
t4=lf[120];
f_3160(t4,t1,lf[126],*((C_word*)lf[36]+1),t2,t3);}

/* fprintf in k3127 in k763 in k760 in k757 */
static void C_ccall f_3458(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr4r,(void*)f_3458r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3458r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3458r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
/* extras.scm:618: fprintf0 */
t5=lf[120];
f_3160(t5,t1,lf[125],t2,t3,t4);}

/* fprintf0 in k3127 in k763 in k760 in k757 */
static void C_fcall f_3160(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3160,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3164,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=t1,a[9]=t3,tmp=(C_word)a,a+=10,tmp);
if(C_truep(t3)){
/* extras.scm:566: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t6,t3,t2);}
else{
t7=t6;
f_3164(2,t7,C_SCHEME_UNDEFINED);}}

/* k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_3167,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3447,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[9])){
/* extras.scm:567: ##sys#tty-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[124]+1)))(3,*((C_word*)lf[124]+1),t3,((C_word*)t0)[9]);}
else{
/* extras.scm:569: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t2);}}

/* k3445 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3167(2,t2,((C_word*)t0)[2]);}
else{
/* extras.scm:569: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),((C_word*)t0)[3]);}}

/* k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3170,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3198,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word)li74),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_3198(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_fcall f_3198(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3198,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_i_check_string_2(t2,((C_word*)t0)[7]);
t6=C_fix(0);
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_block_size(t2);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3207,a[2]=t7,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3214,a[2]=((C_word*)t0)[7],a[3]=t4,a[4]=((C_word)li71),tmp=(C_word)a,a+=5,tmp));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3233,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=t12,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t16,a[10]=t10,a[11]=t8,a[12]=t7,a[13]=((C_word)li73),tmp=(C_word)a,a+=14,tmp));
t18=((C_word*)t16)[1];
f_3233(t18,t1);}

/* loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_fcall f_3233(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3233,NULL,2,t0,t1);}
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=f_3207(((C_word*)((C_word*)t0)[10])[1]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3246,a[2]=t1,a[3]=((C_word*)t0)[9],tmp=(C_word)a,a+=4,tmp);
t4=C_eqp(t2,C_make_character(126));
t5=(C_truep(t4)?C_fixnum_lessp(((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11]):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=f_3207(((C_word*)((C_word*)t0)[10])[1]);
t7=C_u_i_char_upcase(t6);
switch(t7){
case C_make_character(83):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3271,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:590: next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3214(t9,t8);
case C_make_character(65):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:591: next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3214(t9,t8);
case C_make_character(67):
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3297,a[2]=((C_word*)t0)[7],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm:592: next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3214(t9,t8);
case C_make_character(66):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3310,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3314,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm:593: next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3214(t10,t9);
case C_make_character(79):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3331,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm:594: next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3214(t10,t9);
case C_make_character(88):
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3344,a[2]=((C_word*)t0)[7],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3348,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* extras.scm:595: next */
t10=((C_word*)((C_word*)t0)[6])[1];
f_3214(t10,t9);
case C_make_character(33):
/* extras.scm:596: ##sys#flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[122]+1)))(3,*((C_word*)lf[122]+1),t3,((C_word*)t0)[7]);
case C_make_character(63):
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:598: next */
t9=((C_word*)((C_word*)t0)[6])[1];
f_3214(t9,t8);
case C_make_character(126):
/* extras.scm:602: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t3,C_make_character(126),((C_word*)t0)[7]);
default:
t8=C_eqp(t7,C_make_character(37));
t9=(C_truep(t8)?t8:C_eqp(t7,C_make_character(78)));
if(C_truep(t9)){
/* extras.scm:603: newline */
t10=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t10))(3,t10,t3,((C_word*)t0)[7]);}
else{
if(C_truep(C_u_i_char_whitespacep(t6))){
t10=f_3207(((C_word*)((C_word*)t0)[10])[1]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[10],a[4]=((C_word)li72),tmp=(C_word)a,a+=5,tmp);
t12=f_3411(t11,t10);
/* extras.scm:612: loop */
t25=t1;
t1=t25;
goto loop;}
else{
/* extras.scm:610: ##sys#error */
t10=*((C_word*)lf[8]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t3,((C_word*)t0)[4],lf[123],t6);}}}}
else{
/* extras.scm:611: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t3,t2,((C_word*)t0)[7]);}}}

/* skip in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static C_word C_fcall f_3411(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep(C_u_i_char_whitespacep(t1))){
t2=f_3207(((C_word*)((C_word*)t0)[3])[1]);
t6=t2;
t1=t6;
goto loop;}
else{
t2=C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t3);}}

/* k3364 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3366,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3369,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:599: next */
t3=((C_word*)((C_word*)t0)[2])[1];
f_3214(t3,t2);}

/* k3367 in k3364 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3369,2,t0,t1);}
t2=C_i_check_list_2(t1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:601: rec */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3198(t4,t3,((C_word*)t0)[2],t1);}

/* k3373 in k3367 in k3364 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:612: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3233(t2,((C_word*)t0)[2]);}

/* k3346 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:595: ##sys#number->string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t1,C_fix(16));}

/* k3342 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:595: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3329 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:594: ##sys#number->string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t1,C_fix(8));}

/* k3325 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:594: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3312 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:593: ##sys#number->string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],t1,C_fix(2));}

/* k3308 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:593: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3295 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:592: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3282 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:591: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3269 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:590: write */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3244 in loop in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:612: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_3233(t2,((C_word*)t0)[2]);}

/* next in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_fcall f_3214(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3214,NULL,2,t0,t1);}
if(C_truep(C_eqp(((C_word*)((C_word*)t0)[3])[1],C_SCHEME_END_OF_LIST))){
/* extras.scm:580: ##sys#error */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[2],lf[121]);}
else{
t2=C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(0));
t3=C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* fetch in rec in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static C_word C_fcall f_3207(C_word t0){
C_word tmp;
C_word t1;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
t1=C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);
t2=C_fixnum_plus(((C_word*)((C_word*)t0)[2])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
return(t1);}

/* k3168 in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3170,2,t0,t1);}
t2=((C_word*)t0)[4];
if(C_truep(t2)){
t3=C_eqp(((C_word*)t0)[3],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3192,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:615: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t4,((C_word*)t0)[3]);}}
else{
/* extras.scm:613: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k3190 in k3168 in k3165 in k3162 in fprintf0 in k3127 in k763 in k760 in k757 */
static void C_ccall f_3192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:615: ##sys#print */
t2=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,C_SCHEME_FALSE,((C_word*)t0)[2]);}

/* pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3131(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_3131r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3131r(t0,t1,t2,t3);}}

static void C_ccall f_3131r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(t3))){
t5=t4;
f_3135(2,t5,C_i_car(t3));}
else{
/* extras.scm:552: current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[117]+1)))(2,*((C_word*)lf[117]+1),t4);}}

/* k3133 in pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3142,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:553: pretty-print-width */
t4=*((C_word*)lf[115]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k3140 in k3133 in pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3144,a[2]=((C_word*)t0)[4],a[3]=((C_word)li69),tmp=(C_word)a,a+=4,tmp);
/* extras.scm:553: generic-write */
f_1850(((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE,t1,t2);}

/* a3143 in k3140 in k3133 in pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3144,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3148,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* extras.scm:553: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[35]+1)))(4,*((C_word*)lf[35]+1),t3,t2,((C_word*)t0)[2]);}

/* k3146 in a3143 in k3140 in k3133 in pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k3136 in k3133 in pretty-print in k3127 in k763 in k760 in k757 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* generic-write in k763 in k760 in k757 */
static void C_fcall f_1850(C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[43],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1850,NULL,5,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1853,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t17=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1911,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t18=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=t5,a[3]=((C_word)li37),tmp=(C_word)a,a+=4,tmp));
t19=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1963,a[2]=t3,a[3]=t7,a[4]=t11,a[5]=t9,a[6]=t13,a[7]=((C_word)li43),tmp=(C_word)a,a+=8,tmp));
t20=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2471,a[2]=t7,a[3]=t9,a[4]=t13,a[5]=t4,a[6]=t3,a[7]=t11,a[8]=((C_word)li67),tmp=(C_word)a,a+=9,tmp));
if(C_truep(t4)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3118,a[2]=t2,a[3]=t15,a[4]=t1,a[5]=t11,tmp=(C_word)a,a+=6,tmp);
/* extras.scm:543: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t21,C_fix(1),C_make_character(10));}
else{
/* extras.scm:544: wr */
t21=((C_word*)t13)[1];
f_1963(t21,t1,t2,C_fix(0));}}

/* k3116 in generic-write in k763 in k760 in k757 */
static void C_ccall f_3118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3118,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3122,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:543: pp */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2471(t3,t2,((C_word*)t0)[2],C_fix(0));}

/* k3120 in k3116 in generic-write in k763 in k760 in k757 */
static void C_ccall f_3122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:543: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2471(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word ab[152],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2471,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2474,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word)li44),tmp=(C_word)a,a+=5,tmp));
t41=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2507,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp));
t42=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t11,a[6]=t15,a[7]=((C_word*)t0)[7],a[8]=((C_word)li47),tmp=(C_word)a,a+=9,tmp));
t43=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2626,a[2]=((C_word*)t0)[2],a[3]=t15,a[4]=t39,a[5]=t13,a[6]=t19,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],a[9]=t11,a[10]=t9,a[11]=((C_word)li48),tmp=(C_word)a,a+=12,tmp));
t44=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2691,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t17,a[5]=((C_word)li49),tmp=(C_word)a,a+=6,tmp));
t45=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2719,a[2]=((C_word*)t0)[7],a[3]=t17,a[4]=((C_word)li50),tmp=(C_word)a,a+=5,tmp));
t46=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2728,a[2]=((C_word*)t0)[7],a[3]=t7,a[4]=t9,a[5]=((C_word)li52),tmp=(C_word)a,a+=6,tmp));
t47=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2805,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t17,a[5]=t7,a[6]=t9,a[7]=((C_word)li56),tmp=(C_word)a,a+=8,tmp));
t48=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2953,a[2]=t11,a[3]=t15,a[4]=((C_word)li57),tmp=(C_word)a,a+=5,tmp));
t49=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2959,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li58),tmp=(C_word)a,a+=6,tmp));
t50=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2965,a[2]=t11,a[3]=t19,a[4]=((C_word)li59),tmp=(C_word)a,a+=5,tmp));
t51=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2971,a[2]=t21,a[3]=t13,a[4]=((C_word)li60),tmp=(C_word)a,a+=5,tmp));
t52=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2977,a[2]=t21,a[3]=t11,a[4]=t19,a[5]=((C_word)li61),tmp=(C_word)a,a+=6,tmp));
t53=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2983,a[2]=t11,a[3]=t13,a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp));
t54=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2989,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li63),tmp=(C_word)a,a+=6,tmp));
t55=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3011,a[2]=t11,a[3]=t19,a[4]=((C_word)li64),tmp=(C_word)a,a+=5,tmp));
t56=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3017,a[2]=t11,a[3]=t21,a[4]=t19,a[5]=((C_word)li65),tmp=(C_word)a,a+=6,tmp));
t57=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3026,a[2]=t37,a[3]=t35,a[4]=t33,a[5]=t31,a[6]=t29,a[7]=t27,a[8]=t25,a[9]=t23,a[10]=((C_word)li66),tmp=(C_word)a,a+=11,tmp));
/* extras.scm:540: pr */
t58=((C_word*)t9)[1];
f_2539(t58,t1,t2,t3,C_fix(0),((C_word*)t11)[1]);}

/* style in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_3026(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3026,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,lf[102]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[9],a[11]=t1,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_3036(t5,t3);}
else{
t5=C_eqp(t2,lf[112]);
if(C_truep(t5)){
t6=t4;
f_3036(t6,t5);}
else{
t6=C_eqp(t2,lf[113]);
t7=t4;
f_3036(t7,(C_truep(t6)?t6:C_eqp(t2,lf[114])));}}}

/* k3034 in style in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_3036(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[10])[1]);}
else{
t2=C_eqp(((C_word*)t0)[9],lf[103]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[9],lf[104]));
if(C_truep(t3)){
t4=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,((C_word*)((C_word*)t0)[8])[1]);}
else{
t4=C_eqp(((C_word*)t0)[9],lf[105]);
if(C_truep(t4)){
t5=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)((C_word*)t0)[7])[1]);}
else{
t5=C_eqp(((C_word*)t0)[9],lf[106]);
if(C_truep(t5)){
t6=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)((C_word*)t0)[6])[1]);}
else{
t6=C_eqp(((C_word*)t0)[9],lf[107]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[9],lf[108]));
if(C_truep(t7)){
t8=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,((C_word*)((C_word*)t0)[5])[1]);}
else{
t8=C_eqp(((C_word*)t0)[9],lf[109]);
if(C_truep(t8)){
t9=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)((C_word*)t0)[4])[1]);}
else{
t9=C_eqp(((C_word*)t0)[9],lf[110]);
if(C_truep(t9)){
t10=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,((C_word*)((C_word*)t0)[3])[1]);}
else{
t10=C_eqp(((C_word*)t0)[9],lf[111]);
t11=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,(C_truep(t10)?((C_word*)((C_word*)t0)[2])[1]:C_SCHEME_FALSE));}}}}}}}}

/* pp-do in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_3017(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3017,5,t0,t1,t2,t3,t4);}
/* extras.scm:518: pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2805(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* pp-begin in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_3011(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3011,5,t0,t1,t2,t3,t4);}
/* extras.scm:515: pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2805(t5,t1,t2,t3,t4,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-let in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2989(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2989,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
if(C_truep(C_i_pairp(t5))){
t6=C_i_car(t5);
t7=C_i_symbolp(t6);
/* extras.scm:512: pp-general */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2805(t8,t1,t2,t3,t4,t7,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* extras.scm:512: pp-general */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2805(t6,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}}

/* pp-and in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2983(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2983,5,t0,t1,t2,t3,t4);}
/* extras.scm:507: pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2691(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-case in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2977(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2977,5,t0,t1,t2,t3,t4);}
/* extras.scm:504: pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2805(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-cond in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2971(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2971,5,t0,t1,t2,t3,t4);}
/* extras.scm:501: pp-call */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2691(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-if in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2965(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2965,5,t0,t1,t2,t3,t4);}
/* extras.scm:498: pp-general */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2805(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-lambda in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2959(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2959,5,t0,t1,t2,t3,t4);}
/* extras.scm:495: pp-general */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2805(t5,t1,t2,t3,t4,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1],C_SCHEME_FALSE,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-expr-list in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2953(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2953,5,t0,t1,t2,t3,t4);}
/* extras.scm:492: pp-list */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2719(t5,t1,t2,t3,t4,((C_word*)((C_word*)t0)[2])[1]);}

/* pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2805(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2805,NULL,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2808,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t12,a[5]=t4,a[6]=t6,a[7]=((C_word)li53),tmp=(C_word)a,a+=8,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2849,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t14,a[5]=t4,a[6]=t7,a[7]=((C_word)li54),tmp=(C_word)a,a+=8,tmp));
t17=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2890,a[2]=t8,a[3]=t4,a[4]=((C_word*)t0)[4],a[5]=((C_word)li55),tmp=(C_word)a,a+=6,tmp));
t18=C_i_car(t2);
t19=C_i_cdr(t2);
t20=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2903,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t10,a[6]=t3,a[7]=t19,a[8]=t5,tmp=(C_word)a,a+=9,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2951,a[2]=t18,a[3]=t20,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:483: out */
t22=((C_word*)((C_word*)t0)[2])[1];
f_1944(t22,t21,lf[101],t3);}

/* k2949 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:483: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2901 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2903,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[8])?C_i_pairp(((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[7]);
t4=C_i_cdr(((C_word*)t0)[7]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2918,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2933,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:487: out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1944(t7,t6,lf[100],t1);}
else{
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(2));
t4=C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm:489: tail1 */
t5=((C_word*)((C_word*)t0)[5])[1];
f_2808(t5,((C_word*)t0)[4],((C_word*)t0)[7],t3,t1,t4);}}

/* k2931 in k2901 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:487: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2916 in k2901 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2918,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(2));
t3=C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm:488: tail1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2808(t4,((C_word*)t0)[3],((C_word*)t0)[2],t2,t1,t3);}

/* tail3 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2890(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2890,NULL,5,t0,t1,t2,t3,t4);}
/* extras.scm:479: pp-down */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2728(t5,t1,t2,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* tail2 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2849(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2849,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=C_i_car(t2);
t8=C_i_cdr(t2);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2872,a[2]=t3,a[3]=t8,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2876,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:475: indent */
t13=((C_word*)((C_word*)t0)[2])[1];
f_2507(t13,t12,t5,t4);}
else{
/* extras.scm:476: tail3 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2890(t7,t1,t2,t3,t4);}}

/* k2874 in tail2 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:475: pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2539(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2870 in tail2 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:475: tail3 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2890(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tail1 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2808(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2808,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(((C_word*)t0)[6])?C_i_pairp(t2):C_SCHEME_FALSE);
if(C_truep(t6)){
t7=C_i_car(t2);
t8=C_i_cdr(t2);
t9=C_i_nullp(t8);
t10=(C_truep(t9)?C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1)):C_fix(0));
t11=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2831,a[2]=t5,a[3]=t3,a[4]=t8,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2835,a[2]=((C_word*)t0)[6],a[3]=t10,a[4]=t7,a[5]=t11,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:467: indent */
t13=((C_word*)((C_word*)t0)[2])[1];
f_2507(t13,t12,t5,t4);}
else{
/* extras.scm:468: tail2 */
t7=((C_word*)((C_word*)t0)[4])[1];
f_2849(t7,t1,t2,t3,t4,t5);}}

/* k2833 in tail1 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2835(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:467: pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2539(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2829 in tail1 in pp-general in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:467: tail2 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2849(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2728(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2728,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2734,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=((C_word*)t0)[4],a[7]=t8,a[8]=t5,a[9]=((C_word)li51),tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_2734(t10,t1,t2,t3);}

/* loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2734(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2734,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep(C_i_pairp(t2))){
t4=C_i_cdr(t2);
t5=C_i_nullp(t4);
t6=(C_truep(t5)?C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1)):C_fix(0));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2757,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t8=C_i_car(t2);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2765,a[2]=((C_word*)t0)[5],a[3]=t6,a[4]=t8,a[5]=t7,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:450: indent */
t10=((C_word*)((C_word*)t0)[4])[1];
f_2507(t10,t9,((C_word*)t0)[3],t3);}
else{
if(C_truep(C_i_nullp(t2))){
/* extras.scm:452: out */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1944(t4,t1,lf[97],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2787,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2791,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=t4,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2799,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2803,a[2]=t6,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:456: indent */
t8=((C_word*)((C_word*)t0)[4])[1];
f_2507(t8,t7,((C_word*)t0)[3],t3);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2801 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:456: out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1944(t2,((C_word*)t0)[2],lf[99],t1);}

/* k2797 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:456: indent */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2507(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2789 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2791,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* extras.scm:455: pr */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2539(t3,((C_word*)t0)[4],((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k2785 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:454: out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1944(t2,((C_word*)t0)[2],lf[98],t1);}

/* k2763 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:450: pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2539(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2755 in loop in pp-down in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:449: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2734(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* pp-list in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2719(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2719,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2723,a[2]=t5,a[3]=t4,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:440: out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1944(t7,t6,lf[96],t3);}

/* k2721 in pp-list in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:441: pp-down */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2728(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-call in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2691(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2691,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2695,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=t2,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t7=C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2717,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:432: out */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1944(t9,t8,lf[95],t3);}

/* k2715 in pp-call in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:432: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2693 in pp-call in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
if(C_truep(((C_word*)t0)[7])){
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_plus(&a,2,t1,C_fix(1));
/* extras.scm:434: pp-down */
t4=((C_word*)((C_word*)t0)[5])[1];
f_2728(t4,((C_word*)t0)[4],t2,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* pp-expr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2626(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2626,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2633,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t4,a[11]=t1,a[12]=((C_word*)t0)[10],a[13]=t2,tmp=(C_word)a,a+=14,tmp);
/* extras.scm:412: read-macro? */
f_1853(t5,t2);}

/* k2631 in pp-expr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2633,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[13];
t3=C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2644,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=t3,a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],tmp=(C_word)a,a+=7,tmp);
t5=f_1911(((C_word*)t0)[13]);
/* extras.scm:414: out */
t6=((C_word*)((C_word*)t0)[7])[1];
f_1944(t6,t4,t5,((C_word*)t0)[6]);}
else{
t2=C_i_car(((C_word*)t0)[13]);
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2660,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
/* extras.scm:419: style */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3026(t4,t3,t2);}
else{
/* extras.scm:426: pp-list */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2719(t3,((C_word*)t0)[11],((C_word*)t0)[13],((C_word*)t0)[6],((C_word*)t0)[10],((C_word*)((C_word*)t0)[9])[1]);}}}

/* k2658 in k2631 in pp-expr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2660,2,t0,t1);}
if(C_truep(t1)){
/* extras.scm:421: proc */
t2=t1;
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6]);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* extras.scm:422: ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[94]+1)))(3,*((C_word*)lf[94]+1),t2,((C_word*)t0)[2]);}}

/* k2684 in k2658 in k2631 in pp-expr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_string_length(t1);
if(C_truep(C_i_greaterp(t2,C_fix(5)))){
/* extras.scm:424: pp-general */
t3=((C_word*)((C_word*)t0)[8])[1];
f_2805(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE,((C_word*)((C_word*)t0)[3])[1]);}
else{
/* extras.scm:425: pp-call */
t3=((C_word*)((C_word*)t0)[2])[1];
f_2691(t3,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);}}

/* k2642 in k2631 in pp-expr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:413: pr */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2539(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* pr in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[26],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=C_i_pairp(t2);
t7=(C_truep(t6)?t6:C_i_vectorp(t2));
if(C_truep(t7)){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t4,a[6]=t5,a[7]=t2,a[8]=t9,a[9]=t3,a[10]=t1,a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
t11=C_a_i_minus(&a,2,((C_word*)t0)[3],t3);
t12=C_a_i_minus(&a,2,t11,t4);
t13=C_a_i_plus(&a,2,t12,C_fix(1));
/* extras.scm:398: max */
((C_proc4)C_retrieve_proc(*((C_word*)lf[93]+1)))(4,*((C_word*)lf[93]+1),t10,t13,C_fix(50));}
else{
/* extras.scm:409: wr */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1963(t8,t1,t2,t3);}}

/* k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2552,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2555,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t3,tmp=(C_word)a,a+=12,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2590,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word)li46),tmp=(C_word)a,a+=5,tmp);
/* extras.scm:399: generic-write */
f_1850(t4,((C_word*)t0)[7],((C_word*)t0)[2],C_SCHEME_FALSE,t5);}

/* a2589 in k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2590,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=C_i_string_length(t2);
t6=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[2])[1],t5);
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_greaterp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)));}

/* k2553 in k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2555,2,t0,t1);}
if(C_truep(C_i_greaterp(((C_word*)((C_word*)t0)[11])[1],C_fix(0)))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2568,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:405: reverse-string-append */
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t2,((C_word*)((C_word*)t0)[7])[1]);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
/* extras.scm:407: pp-pair */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[9],((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* extras.scm:408: vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[58]+1)))(3,*((C_word*)lf[58]+1),t2,((C_word*)t0)[6]);}}}

/* k2582 in k2553 in k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2588,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:408: out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1944(t3,t2,lf[92],((C_word*)t0)[2]);}

/* k2586 in k2582 in k2553 in k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:408: pp-list */
t2=((C_word*)((C_word*)t0)[6])[1];
f_2719(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2566 in k2553 in k2550 in pr in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:405: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* indent in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2507(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2507,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
if(C_truep(C_i_lessp(t2,t3))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2523,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2530,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:392: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t5,C_fix(1),C_make_character(10));}
else{
t4=C_a_i_minus(&a,2,t2,t3);
/* extras.scm:393: spaces */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2474(t5,t1,t4,t3);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k2528 in indent in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:392: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2521 in indent in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm:392: spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2474(t2,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* spaces in pp in generic-write in k763 in k760 in k757 */
static void C_fcall f_2474(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2474,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_greaterp(t2,C_fix(0)))){
if(C_truep(C_i_greaterp(t2,C_fix(7)))){
t4=C_a_i_minus(&a,2,t2,C_fix(8));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2498,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:385: out */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1944(t6,t5,lf[89],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2505,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:386: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),t4,lf[90],C_fix(0),t2);}}
else{
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k2503 in spaces in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:386: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2496 in spaces in pp in generic-write in k763 in k760 in k757 */
static void C_ccall f_2498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:385: spaces */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2474(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_1963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1963,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1966,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li38),tmp=(C_word)a,a+=8,tmp);
t8=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1993,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[6],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp));
if(C_truep(C_i_pairp(t2))){
/* extras.scm:318: wr-expr */
t9=t4;
f_1966(t9,t1,t2,t3);}
else{
if(C_truep(C_i_nullp(t2))){
/* extras.scm:319: wr-lst */
t9=((C_word*)t6)[1];
f_1993(t9,t1,t2,t3);}
else{
if(C_truep(C_eofp(t2))){
/* extras.scm:320: out */
t9=((C_word*)((C_word*)t0)[4])[1];
f_1944(t9,t1,lf[56],t3);}
else{
if(C_truep(C_i_vectorp(t2))){
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2119,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* extras.scm:321: vector->list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[58]+1)))(3,*((C_word*)lf[58]+1),t9,t2);}
else{
if(C_truep(C_booleanp(t2))){
if(C_truep(t2)){
/* extras.scm:322: out */
t9=((C_word*)((C_word*)t0)[4])[1];
f_1944(t9,t1,lf[59],t3);}
else{
/* extras.scm:322: out */
t9=((C_word*)((C_word*)t0)[4])[1];
f_1944(t9,t1,lf[60],t3);}}
else{
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:323: ##sys#number? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[88]+1)))(3,*((C_word*)lf[88]+1),t9,t2);}}}}}}

/* k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2149,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:323: ##sys#number->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[61]+1)))(3,*((C_word*)lf[61]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2158,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:325: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t2);}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2181,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:328: ##sys#procedure->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[63]+1)))(3,*((C_word*)lf[63]+1),t2,((C_word*)t0)[3]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
if(C_truep(((C_word*)t0)[2])){
/* extras.scm:330: out */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1944(t2,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2200,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:331: out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1944(t3,t2,lf[66],((C_word*)t0)[4]);}}
else{
if(C_truep(C_charp(((C_word*)t0)[3]))){
if(C_truep(((C_word*)t0)[2])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2284,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:345: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t2,C_fix(1),((C_word*)t0)[3]);}
else{
t2=C_fix(C_character_code(((C_word*)t0)[3]));
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:347: out */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1944(t4,t3,lf[71],((C_word*)t0)[4]);}}
else{
if(C_truep(C_eofp(((C_word*)t0)[3]))){
/* extras.scm:358: out */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1944(t2,((C_word*)t0)[5],lf[72],((C_word*)t0)[4]);}
else{
if(C_truep(C_undefinedp(((C_word*)t0)[3]))){
/* extras.scm:359: out */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1944(t2,((C_word*)t0)[5],lf[73],((C_word*)t0)[4]);}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:360: ##sys#pointer->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[74]+1)))(3,*((C_word*)lf[74]+1),t2,((C_word*)t0)[3]);}
else{
t2=C_slot(lf[75],C_fix(0));
t3=C_eqp(((C_word*)t0)[3],t2);
if(C_truep(t3)){
/* extras.scm:362: out */
t4=((C_word*)((C_word*)t0)[6])[1];
f_1944(t4,((C_word*)t0)[5],lf[76],((C_word*)t0)[4]);}
else{
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2397,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:364: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2413,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:367: port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t4,((C_word*)t0)[3]);}}}}}}}}}}}

/* k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2413,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(3));
/* extras.scm:367: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[78]+1)))(5,*((C_word*)lf[78]+1),t2,lf[79],t3,lf[80]);}
else{
if(C_truep(C_bytevectorp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_permanentp(((C_word*)t0)[2]))){
/* extras.scm:370: out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1944(t3,t2,lf[82],((C_word*)t0)[3]);}
else{
/* extras.scm:371: out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1944(t3,t2,lf[83],((C_word*)t0)[3]);}}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:375: out */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1944(t3,t2,lf[86],((C_word*)t0)[3]);}
else{
/* extras.scm:378: out */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1944(t2,((C_word*)t0)[4],lf[87],((C_word*)t0)[3]);}}}}

/* k2450 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2452,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2455,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2462,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:376: ##sys#lambda-info->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[85]+1)))(3,*((C_word*)lf[85]+1),t3,((C_word*)t0)[2]);}

/* k2460 in k2450 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:376: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2453 in k2450 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:377: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],lf[84],((C_word*)t0)[2]);}

/* k2428 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:372: number->string */
C_number_to_string(3,0,t3,C_block_size(((C_word*)t0)[2]));}

/* k2438 in k2428 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:372: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2431 in k2428 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:373: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],lf[81],((C_word*)t0)[2]);}

/* k2418 in k2411 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:367: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2395 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2400,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:365: ##sys#user-print-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2398 in k2395 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2407,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:366: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}

/* k2405 in k2398 in k2395 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:366: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2377 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:360: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2293,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:348: char-name */
((C_proc3)C_retrieve_proc(*((C_word*)lf[70]+1)))(3,*((C_word*)lf[70]+1),t2,((C_word*)t0)[2]);}

/* k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2293,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2297,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li42),tmp=(C_word)a,a+=5,tmp);
/* g450451 */
t3=t2;
f_2297(t3,((C_word*)t0)[4],t1);}
else{
if(C_truep(C_fixnum_lessp(((C_word*)t0)[3],C_fix(32)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:352: out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1944(t3,t2,lf[67],((C_word*)t0)[5]);}
else{
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(255)))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[3],C_fix(65535)))){
/* extras.scm:355: out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1944(t3,t2,lf[68],((C_word*)t0)[5]);}
else{
/* extras.scm:355: out */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1944(t3,t2,lf[69],((C_word*)t0)[5]);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2354,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:357: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[16]+1)))(4,*((C_word*)lf[16]+1),t2,C_fix(1),((C_word*)t0)[2]);}}}}

/* k2352 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:357: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2331 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2333,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:356: number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2338 in k2331 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:356: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2315 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2324,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:353: number->string */
C_number_to_string(4,0,t2,((C_word*)t0)[2],C_fix(16));}

/* k2322 in k2315 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:353: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* g450 in k2291 in k2288 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_2297(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2297,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(1));
/* extras.scm:350: out */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1944(t4,t1,t3,((C_word*)t0)[2]);}

/* k2282 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:345: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2202,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li41),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2202(t5,((C_word*)t0)[2],C_fix(0),C_fix(0),t1);}

/* loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_2202(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2202,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2209,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=((C_word*)t0)[3],a[7]=t3,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=C_i_string_length(((C_word*)t0)[4]);
t7=t5;
f_2209(t7,C_i_lessp(t3,t6));}
else{
t6=t5;
f_2209(t6,C_SCHEME_FALSE);}}

/* k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_2209(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2209,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_ref(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:C_eqp(t2,C_make_character(34)));
if(C_truep(t4)){
t5=C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2232,a[2]=t5,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2236,a[2]=t6,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2240,a[2]=((C_word*)t0)[3],a[3]=t7,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:339: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),t8,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}
else{
t5=C_a_i_plus(&a,2,((C_word*)t0)[7],C_fix(1));
/* extras.scm:341: loop */
t6=((C_word*)((C_word*)t0)[6])[1];
f_2202(t6,((C_word*)t0)[5],((C_word*)t0)[2],t5,((C_word*)t0)[3]);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2257,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:343: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),t3,((C_word*)t0)[8],((C_word*)t0)[2],((C_word*)t0)[7]);}}

/* k2259 in k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:343: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2255 in k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:342: out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1944(t2,((C_word*)t0)[2],lf[65],t1);}

/* k2238 in k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:339: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2234 in k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:338: out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1944(t2,((C_word*)t0)[2],lf[64],t1);}

/* k2230 in k2207 in loop in k2198 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:336: loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_2202(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2179 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2181(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:328: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2156 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2161,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:326: ##sys#print */
t3=*((C_word*)lf[62]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],C_SCHEME_TRUE,t1);}

/* k2159 in k2156 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2168,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:327: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2]);}

/* k2166 in k2159 in k2156 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:327: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2147 in k2140 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:323: out */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1944(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2117 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2123,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:321: out */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1944(t3,t2,lf[57],((C_word*)t0)[2]);}

/* k2121 in k2117 in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:321: wr-lst */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1993(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_1993(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1993,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_pairp(t2))){
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2011,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t3)){
t6=C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2076,a[2]=t6,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:310: out */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1944(t8,t7,lf[54],t3);}
else{
t6=t5;
f_2011(2,t6,C_SCHEME_FALSE);}}
else{
/* extras.scm:316: out */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1944(t4,t1,lf[55],t3);}}

/* k2074 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:310: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2013,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li39),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2013(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_2013(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2013,NULL,4,t0,t1,t2,t3);}
t4=t3;
if(C_truep(t4)){
if(C_truep(C_i_pairp(t2))){
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2037,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=C_i_car(t2);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=t7,a[3]=t6,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:313: out */
t9=((C_word*)((C_word*)t0)[2])[1];
f_1944(t9,t8,lf[50],t3);}
else{
if(C_truep(C_i_nullp(t2))){
/* extras.scm:314: out */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1944(t5,t1,lf[51],t3);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2061,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2065,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:315: out */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1944(t7,t6,lf[53],t3);}}}
else{
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* k2063 in loop in k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:315: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2059 in loop in k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:315: out */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1944(t2,((C_word*)t0)[2],lf[52],t1);}

/* k2043 in loop in k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:313: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2035 in loop in k2009 in wr-lst in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_2037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:313: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2013(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* wr-expr in wr in generic-write in k763 in k760 in k757 */
static void C_fcall f_1966(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1966,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1973,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm:303: read-macro? */
f_1853(t4,t2);}

/* k1971 in wr-expr in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_1973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1973,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=C_i_cadr(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1984,a[2]=t3,a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t5=f_1911(((C_word*)t0)[8]);
/* extras.scm:304: out */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1944(t6,t4,t5,((C_word*)t0)[3]);}
else{
/* extras.scm:305: wr-lst */
t2=((C_word*)((C_word*)t0)[2])[1];
f_1993(t2,((C_word*)t0)[6],((C_word*)t0)[8],((C_word*)t0)[3]);}}

/* k1982 in k1971 in wr-expr in wr in generic-write in k763 in k760 in k757 */
static void C_ccall f_1984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:304: wr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1963(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* out in generic-write in k763 in k760 in k757 */
static void C_fcall f_1944(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1944,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1954,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:298: output */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}

/* k1952 in out in generic-write in k763 in k760 in k757 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_plus(&a,2,((C_word*)t0)[2],t2));}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* read-macro-prefix in generic-write in k763 in k760 in k757 */
static C_word C_fcall f_1911(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
t2=C_i_car(t1);
t3=C_i_cdr(t1);
t4=C_eqp(t2,lf[42]);
if(C_truep(t4)){
return(lf[46]);}
else{
t5=C_eqp(t2,lf[43]);
if(C_truep(t5)){
return(lf[47]);}
else{
t6=C_eqp(t2,lf[44]);
if(C_truep(t6)){
return(lf[48]);}
else{
t7=C_eqp(t2,lf[45]);
return((C_truep(t7)?lf[49]:C_SCHEME_UNDEFINED));}}}}

/* read-macro? in generic-write in k763 in k760 in k757 */
static void C_fcall f_1853(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1853,NULL,2,t1,t2);}
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=C_eqp(t3,lf[42]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
t7=t6;
f_1885(t7,t5);}
else{
t7=C_eqp(t3,lf[43]);
if(C_truep(t7)){
t8=t6;
f_1885(t8,t7);}
else{
t8=C_eqp(t3,lf[44]);
t9=t6;
f_1885(t9,(C_truep(t8)?t8:C_eqp(t3,lf[45])));}}}

/* k1883 in read-macro? in generic-write in k763 in k760 in k757 */
static void C_fcall f_1885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_cdr(((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t3));}
else{
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* write-byte in k763 in k760 in k757 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1812r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1812r(t0,t1,t2,t3);}}

static void C_ccall f_1812r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1816,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1816(2,t5,*((C_word*)lf[36]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1816(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1814 in write-byte in k763 in k760 in k757 */
static void C_ccall f_1816(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1816,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[3],lf[40]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1822,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:261: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t3,t1,lf[40]);}

/* k1820 in k1814 in write-byte in k763 in k760 in k757 */
static void C_ccall f_1822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_make_character(C_unfix(((C_word*)t0)[4]));
/* extras.scm:262: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* read-byte in k763 in k760 in k757 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1772r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1772r(t0,t1,t2);}}

static void C_ccall f_1772r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1776,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_1776(2,t4,*((C_word*)lf[7]+1));}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_1776(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k1774 in read-byte in k763 in k760 in k757 */
static void C_ccall f_1776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1779,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:253: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t2,t1,lf[39]);}

/* k1777 in k1774 in read-byte in k763 in k760 in k757 */
static void C_ccall f_1779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1782,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extras.scm:254: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,((C_word*)t0)[2]);}

/* k1780 in k1777 in k1774 in read-byte in k763 in k760 in k757 */
static void C_ccall f_1782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_eofp(t1))){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(C_character_code(t1)));}}

/* write-line in k763 in k760 in k757 */
static void C_ccall f_1751(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1751r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1751r(t0,t1,t2,t3);}}

static void C_ccall f_1751r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(7);
t4=(C_truep(C_eqp(t3,C_SCHEME_END_OF_LIST))?*((C_word*)lf[36]+1):C_slot(t3,C_fix(0)));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1758,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm:244: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t5,t4,lf[38]);}

/* k1756 in write-line in k763 in k760 in k757 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1758,2,t0,t1);}
t2=C_i_check_string_2(((C_word*)t0)[6],lf[38]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1764,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:246: display */
t4=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[6],((C_word*)t0)[3]);}

/* k1762 in k1756 in write-line in k763 in k760 in k757 */
static void C_ccall f_1764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:247: newline */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* write-string in k763 in k760 in k757 */
static void C_ccall f_1662(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_1662r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1662r(t0,t1,t2,t3);}}

static void C_ccall f_1662r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(13);
t4=C_i_check_string_2(t2,lf[30]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1667,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li28),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1698,a[2]=t5,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1703,a[2]=t6,a[3]=((C_word)li30),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-n317330 */
t8=t7;
f_1703(t8,t1);}
else{
t8=C_i_car(t3);
t9=C_i_cdr(t3);
if(C_truep(C_i_nullp(t9))){
/* def-port318328 */
t10=t6;
f_1698(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body315322 */
t12=t5;
f_1667(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-n317 in write-string in k763 in k760 in k757 */
static void C_fcall f_1703(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1703,NULL,2,t0,t1);}
/* def-port318328 */
t2=((C_word*)t0)[2];
f_1698(t2,t1,C_SCHEME_FALSE);}

/* def-port318 in write-string in k763 in k760 in k757 */
static void C_fcall f_1698(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1698,NULL,3,t0,t1,t2);}
/* body315322 */
t3=((C_word*)t0)[2];
f_1667(t3,t1,t2,*((C_word*)lf[36]+1));}

/* body315 in write-string in k763 in k760 in k757 */
static void C_fcall f_1667(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1667,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1671,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* extras.scm:229: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t4,t3,lf[30]);}

/* k1669 in body315 in write-string in k763 in k760 in k757 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1671,2,t0,t1);}
t2=(C_truep(((C_word*)t0)[6])?C_i_check_exact_2(((C_word*)t0)[6],lf[30]):C_SCHEME_UNDEFINED);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1684,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[6])){
t5=C_block_size(((C_word*)t0)[2]);
t6=t4;
f_1684(t6,C_fixnum_lessp(((C_word*)t0)[6],t5));}
else{
t5=t4;
f_1684(t5,C_SCHEME_FALSE);}}

/* k1682 in k1669 in body315 in write-string in k763 in k760 in k757 */
static void C_fcall f_1684(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* extras.scm:233: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[7],((C_word*)t0)[6],C_fix(0),((C_word*)t0)[5]);}
else{
t2=((C_word*)t0)[6];
/* extras.scm:231: display */
t3=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}}

/* k1679 in k1669 in body315 in write-string in k763 in k760 in k757 */
static void C_ccall f_1681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:231: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* read-token in k763 in k760 in k757 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1593r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1593r(t0,t1,t2,t3);}}

static void C_ccall f_1593r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1597,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1597(2,t5,*((C_word*)lf[7]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1597(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1597,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1600,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:214: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t2,t1,lf[32]);}

/* k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1600,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1603,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:215: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t2);}

/* k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1603,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1608,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t3,a[6]=((C_word)li26),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1608(t5,((C_word*)t0)[2]);}

/* loop in k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_fcall f_1608(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1608,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1612,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:217: ##sys#peek-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,((C_word*)t0)[3]);}

/* k1610 in loop in k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1612(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1612,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1618,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_eofp(t1))){
t3=t2;
f_1618(2,t3,C_SCHEME_FALSE);}
else{
/* extras.scm:218: pred */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k1616 in k1610 in loop in k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1618,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1621,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* extras.scm:220: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}
else{
/* extras.scm:222: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),((C_word*)t0)[4],((C_word*)t0)[3]);}}

/* k1626 in k1616 in k1610 in loop in k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:220: ##sys#write-char-0 */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1619 in k1616 in k1610 in loop in k1601 in k1598 in k1595 in read-token in k763 in k760 in k757 */
static void C_ccall f_1621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:221: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1608(t2,((C_word*)t0)[2]);}

/* read-string in k763 in k760 in k757 */
static void C_ccall f_1533(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_1533r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1533r(t0,t1,t2);}}

static void C_ccall f_1533r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
if(C_truep(C_i_nullp(t2))){
t3=t1;
t4=*((C_word*)lf[7]+1);
/* extras.scm:209: ##sys#read-string/port */
t5=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_FALSE,t4);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t1;
t6=*((C_word*)lf[7]+1);
/* extras.scm:209: ##sys#read-string/port */
t7=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t3,t6);}
else{
t5=C_i_car(t4);
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t1;
/* extras.scm:209: ##sys#read-string/port */
t8=*((C_word*)lf[27]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,t5);}
else{
/* ##sys#error */
t7=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,lf[0],t6);}}}}

/* ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1476(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1476,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1480,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:189: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t4,t3,lf[28]);}

/* k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1480,2,t0,t1);}
if(C_truep(((C_word*)t0)[4])){
t2=C_i_check_exact_2(((C_word*)t0)[4],lf[28]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:191: ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:197: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[31]+1)))(2,*((C_word*)lf[31]+1),t2);}}

/* k1502 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:198: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t2,C_fix(2048));}

/* k1505 in k1502 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1507,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1512,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[4],a[6]=((C_word)li23),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1512(t5,((C_word*)t0)[2]);}

/* loop in k1505 in k1502 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_fcall f_1512(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1512,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* extras.scm:200: ##sys#read-string! */
t3=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_fix(2048),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* k1514 in loop in k1505 in k1502 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
/* extras.scm:203: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[29]+1)))(3,*((C_word*)lf[29]+1),((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1528,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:205: write-string */
t4=*((C_word*)lf[30]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],t1,((C_word*)t0)[4]);}}

/* k1526 in k1514 in loop in k1505 in k1502 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:206: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1512(t2,((C_word*)t0)[2]);}

/* k1487 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1492,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:192: ##sys#read-string! */
t3=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[2],C_fix(0));}

/* k1490 in k1487 in k1478 in ##sys#read-string/port in k763 in k760 in k757 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[2]);}
else{
/* extras.scm:195: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0),t1);}}

/* read-string! in k763 in k760 in k757 */
static void C_ccall f_1379(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+15)){
C_save_and_reclaim((void*)tr4r,(void*)f_1379r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1379r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1379r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(15);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1381,a[2]=t5,a[3]=t3,a[4]=((C_word)li19),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1423,a[2]=t6,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1428,a[2]=t7,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-port234249 */
t9=t8;
f_1428(t9,t1);}
else{
t9=C_i_car(t4);
t10=C_i_cdr(t4);
if(C_truep(C_i_nullp(t10))){
/* def-start235247 */
t11=t7;
f_1423(t11,t1,t9);}
else{
t11=C_i_car(t10);
t12=C_i_cdr(t10);
if(C_truep(C_i_nullp(t12))){
/* body232239 */
t13=t6;
f_1381(t13,t1,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}

/* def-port234 in read-string! in k763 in k760 in k757 */
static void C_fcall f_1428(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1428,NULL,2,t0,t1);}
/* def-start235247 */
t2=((C_word*)t0)[2];
f_1423(t2,t1,*((C_word*)lf[7]+1));}

/* def-start235 in read-string! in k763 in k760 in k757 */
static void C_fcall f_1423(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1423,NULL,3,t0,t1,t2);}
/* body232239 */
t3=((C_word*)t0)[2];
f_1381(t3,t1,t2,C_fix(0));}

/* body232 in read-string! in k763 in k760 in k757 */
static void C_fcall f_1381(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1381,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1385,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:176: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t4,t2,lf[26]);}

/* k1383 in body232 in read-string! in k763 in k760 in k757 */
static void C_ccall f_1385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=C_i_check_string_2(((C_word*)t0)[6],lf[26]);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t3=C_i_check_exact_2(((C_word*)((C_word*)t0)[5])[1],lf[26]);
t4=C_fixnum_plus(((C_word*)t0)[4],((C_word*)((C_word*)t0)[5])[1]);
t5=C_block_size(((C_word*)t0)[6]);
if(C_truep(C_fixnum_greaterp(t4,t5))){
t6=C_block_size(((C_word*)t0)[6]);
t7=C_fixnum_difference(t6,((C_word*)t0)[4]);
t8=C_mutate(((C_word *)((C_word*)t0)[5])+1,t7);
t9=C_i_check_exact_2(((C_word*)t0)[4],lf[26]);
/* extras.scm:183: ##sys#read-string! */
t10=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t10+1)))(6,t10,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}
else{
t6=C_i_check_exact_2(((C_word*)t0)[4],lf[26]);
/* extras.scm:183: ##sys#read-string! */
t7=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}}
else{
t3=C_i_check_exact_2(((C_word*)t0)[4],lf[26]);
/* extras.scm:183: ##sys#read-string! */
t4=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[6],((C_word*)t0)[2],((C_word*)t0)[4]);}}

/* ##sys#read-string! in k763 in k760 in k757 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1233,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_eqp(t2,C_fix(0));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1243,a[2]=t2,a[3]=t6,a[4]=t1,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_slot(t4,C_fix(6)))){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1373,a[2]=t8,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:151: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t9,t4);}
else{
t9=t8;
f_1243(t9,C_SCHEME_UNDEFINED);}}}

/* k1371 in ##sys#read-string! in k763 in k760 in k757 */
static void C_ccall f_1373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_setsubchar(((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],t1);
t3=C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1243(t5,t4);}

/* k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_fcall f_1243(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1243,NULL,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_slot(t2,C_fix(7));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[5],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[6],a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1254(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}
else{
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1313,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=((C_word)li17),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1313(t7,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2],C_fix(0));}}

/* loop in k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_fcall f_1313(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1313,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
/* extras.scm:164: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t5,((C_word*)t0)[2]);}

/* k1315 in loop in k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_ccall f_1317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1320,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_eofp(t1))){
t3=t2;
f_1320(t3,C_fix(0));}
else{
t3=C_setsubchar(((C_word*)t0)[2],((C_word*)t0)[4],t1);
t4=t2;
f_1320(t4,C_fix(1));}}

/* k1318 in k1315 in loop in k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_fcall f_1320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_not(((C_word*)t0)[4]);
t4=(C_truep(t3)?t3:C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t4)){
t5=C_fixnum_plus(((C_word*)t0)[3],t1);
t6=(C_truep(((C_word*)t0)[4])?C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t7=C_fixnum_plus(((C_word*)t0)[6],t1);
/* extras.scm:172: loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1313(t8,((C_word*)t0)[5],t5,t6,t7);}
else{
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fixnum_plus(t1,((C_word*)t0)[6]));}}}

/* loop in k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_fcall f_1254(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1254,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1258,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=t3,a[5]=t1,a[6]=t4,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* extras.scm:156: rdstring */
t6=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t6))(6,t6,t5,((C_word*)t0)[5],t3,((C_word*)t0)[2],t2);}

/* k1256 in loop in k1241 in ##sys#read-string! in k763 in k760 in k757 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=C_slot(((C_word*)t0)[7],C_fix(5));
t3=C_fixnum_plus(t2,t1);
t4=C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),t3);
t5=C_eqp(t1,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[6];
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_i_not(((C_word*)t0)[4]);
t7=(C_truep(t6)?t6:C_fixnum_lessp(t1,((C_word*)t0)[4]));
if(C_truep(t7)){
t8=C_fixnum_plus(((C_word*)t0)[3],t1);
t9=(C_truep(((C_word*)t0)[4])?C_fixnum_difference(((C_word*)t0)[4],t1):C_SCHEME_FALSE);
t10=C_fixnum_plus(((C_word*)t0)[6],t1);
/* extras.scm:161: loop */
t11=((C_word*)((C_word*)t0)[2])[1];
f_1254(t11,((C_word*)t0)[5],t8,t9,t10);}
else{
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fixnum_plus(t1,((C_word*)t0)[6]));}}}

/* read-lines in k763 in k760 in k757 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr2r,(void*)f_1143r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1143r(t0,t1,t2);}}

static void C_ccall f_1143r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(10);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_slot(t2,C_fix(0)):*((C_word*)lf[7]+1));
t5=C_i_pairp(t2);
t6=(C_truep(t5)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE);
t7=C_i_pairp(t6);
t8=(C_truep(t7)?C_slot(t6,C_fix(0)):C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1155,a[2]=((C_word*)t0)[3],a[3]=t8,a[4]=((C_word)li14),tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_stringp(t4))){
/* extras.scm:139: call-with-input-file */
t10=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t10))(4,t10,t1,t4,t9);}
else{
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1210,a[2]=t4,a[3]=t1,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* extras.scm:141: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t10,t4,lf[24]);}}

/* k1208 in read-lines in k763 in k760 in k757 */
static void C_ccall f_1210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:142: doread */
t2=((C_word*)t0)[4];
f_1155(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doread in read-lines in k763 in k760 in k757 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1155,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:C_fix(1000000000));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1165,a[2]=t2,a[3]=t5,a[4]=((C_word*)t0)[2],a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_1165(t7,t1,C_SCHEME_END_OF_LIST,t3);}

/* loop in doread in read-lines in k763 in k760 in k757 */
static void C_fcall f_1165(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1165,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
/* extras.scm:133: reverse */
t5=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t5))(3,t5,t1,t2);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1178,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:134: read-line */
t6=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}}

/* k1176 in loop in doread in read-lines in k763 in k760 in k757 */
static void C_ccall f_1178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1178,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* extras.scm:136: reverse */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=C_fixnum_difference(((C_word*)t0)[3],C_fix(1));
/* extras.scm:137: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1165(t4,((C_word*)t0)[5],t2,t3);}}

/* read-line in k763 in k760 in k757 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_994r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_994r(t0,t1,t2);}}

static void C_ccall f_994r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t3=C_i_pairp(t2);
t4=(C_truep(t3)?C_i_car(t2):*((C_word*)lf[7]+1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1004,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t6=C_i_cdr(t2);
t7=C_i_pairp(t6);
t8=t5;
f_1004(t8,(C_truep(t7)?C_i_cadr(t2):C_SCHEME_FALSE));}
else{
t6=t5;
f_1004(t6,C_SCHEME_FALSE);}}

/* k1002 in read-line in k763 in k760 in k757 */
static void C_fcall f_1004(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1004,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1007,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:94: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[23]+1)))(4,*((C_word*)lf[23]+1),t2,((C_word*)t0)[4],lf[17]);}

/* k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1007,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(2));
t3=C_slot(t2,C_fix(8));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1014,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li10),tmp=(C_word)a,a+=5,tmp);
/* g141142 */
t5=t4;
f_1014(t5,((C_word*)t0)[3],t3);}
else{
t4=(C_truep(((C_word*)t0)[4])?((C_word*)t0)[4]:C_fix(256));
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1027,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:98: ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[22]+1)))(3,*((C_word*)lf[22]+1),t7,((C_word*)t6)[1]);}}

/* k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1027,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word)li11),tmp=(C_word)a,a+=9,tmp));
t7=((C_word*)t5)[1];
f_1032(t7,((C_word*)t0)[2],C_fix(0));}

/* loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_fcall f_1032(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1032,NULL,3,t0,t1,t2);}
t3=(C_truep(((C_word*)t0)[7])?C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[7]):C_SCHEME_FALSE);
if(C_truep(t3)){
/* extras.scm:101: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),t1,((C_word*)((C_word*)t0)[6])[1],C_fix(0),t2);}
else{
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1045,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* extras.scm:102: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t4,((C_word*)t0)[5]);}}

/* k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1045,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_eqp(((C_word*)t0)[8],C_fix(0));
if(C_truep(t2)){
t3=t1;
t4=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* extras.scm:106: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);}}
else{
switch(t1){
case C_make_character(10):
/* extras.scm:108: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[7],((C_word*)((C_word*)t0)[6])[1],C_fix(0),((C_word*)t0)[8]);
case C_make_character(13):
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1078,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* extras.scm:110: peek-char */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t2,((C_word*)t0)[5]);
default:
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1096,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t0)[8],((C_word*)((C_word*)t0)[3])[1]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1110,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1118,a[2]=((C_word*)t0)[6],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* extras.scm:117: make-string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=t2;
f_1096(t3,C_SCHEME_UNDEFINED);}}}}

/* k1116 in k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:117: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[21]+1)))(4,*((C_word*)lf[21]+1),((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t1);}

/* k1108 in k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
t3=C_fixnum_plus(((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
f_1096(t5,t4);}

/* k1094 in k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_fcall f_1096(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_setsubchar(((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[5],((C_word*)t0)[4]);
t3=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* extras.scm:120: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1032(t4,((C_word*)t0)[2],t3);}

/* k1076 in k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1078,2,t0,t1);}
t2=C_eqp(t1,C_make_character(10));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1087,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* extras.scm:112: ##sys#read-char-0 */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,((C_word*)t0)[2]);}
else{
/* extras.scm:114: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[5],((C_word*)((C_word*)t0)[4])[1],C_fix(0),((C_word*)t0)[3]);}}

/* k1085 in k1076 in k1043 in loop in k1025 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_ccall f_1087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* extras.scm:113: ##sys#substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[18]+1)))(5,*((C_word*)lf[18]+1),((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],C_fix(0),((C_word*)t0)[2]);}

/* g141 in k1005 in k1002 in read-line in k763 in k760 in k757 */
static void C_fcall f_1014(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1014,NULL,3,t0,t1,t2);}
/* extras.scm:95: rl */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* random in k763 in k760 in k757 */
static void C_ccall f_955(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_955,3,t0,t1,t2);}
t3=C_i_check_exact_2(t2,lf[15]);
t4=C_eqp(t2,C_fix(0));
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}
else{
t5=C_random_fixnum(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}}

/* randomize in k763 in k760 in k757 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr2r,(void*)f_929r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_929r(t0,t1,t2);}}

static void C_ccall f_929r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_933,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* extras.scm:68: current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t4);}
else{
t4=C_i_car(t2);
t5=C_i_check_exact_2(t4,lf[12]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_randomize(t4));}}

/* k948 in randomize in k763 in k760 in k757 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
t2=C_a_i_flonum_quotient(&a,2,t1,lf[13]);
/* extras.scm:68: ##sys#inexact->exact */
((C_proc3)C_retrieve_proc(*((C_word*)lf[14]+1)))(3,*((C_word*)lf[14]+1),((C_word*)t0)[2],t2);}

/* k931 in randomize in k763 in k760 in k757 */
static void C_ccall f_933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_check_exact_2(t1,lf[12]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_randomize(t1));}

/* random-seed in k763 in k760 in k757 */
static void C_ccall f_908(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_908r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_908r(t0,t1,t2);}}

static void C_ccall f_908r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_912,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
/* extras.scm:62: current-seconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[11]+1)))(2,*((C_word*)lf[11]+1),t3);}
else{
t4=t3;
f_912(2,t4,C_i_car(t2));}}

/* k910 in random-seed in k763 in k760 in k757 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_912,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_915,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* extras.scm:63: ##sys#check-integer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),t2,t1,lf[9]);}

/* k913 in k910 in random-seed in k763 in k760 in k757 */
static void C_ccall f_915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=C_i_foreign_unsigned_integer_argumentp(t3);
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub114(C_SCHEME_UNDEFINED,t4));}

/* read-file in k763 in k760 in k757 */
static void C_ccall f_767(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr2r,(void*)f_767r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_767r(t0,t1,t2);}}

static void C_ccall f_767r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(18);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li2),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_829,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_834,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_839,a[2]=t5,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* def-port76104 */
t7=t6;
f_839(t7,t1);}
else{
t7=C_i_car(t2);
t8=C_i_cdr(t2);
if(C_truep(C_i_nullp(t8))){
/* def-reader77102 */
t9=t5;
f_834(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
/* def-max7899 */
t11=t4;
f_829(t11,t1,t7,t9);}
else{
t11=C_i_car(t10);
t12=C_i_cdr(t10);
if(C_truep(C_i_nullp(t12))){
/* body7482 */
t13=t3;
f_769(t13,t1,t7,t9,t11);}
else{
/* ##sys#error */
t13=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t1,lf[0],t12);}}}}}

/* def-port76 in read-file in k763 in k760 in k757 */
static void C_fcall f_839(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_839,NULL,2,t0,t1);}
/* def-reader77102 */
t2=((C_word*)t0)[2];
f_834(t2,t1,*((C_word*)lf[7]+1));}

/* def-reader77 in read-file in k763 in k760 in k757 */
static void C_fcall f_834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_834,NULL,3,t0,t1,t2);}
/* def-max7899 */
t3=((C_word*)t0)[3];
f_829(t3,t1,t2,((C_word*)t0)[2]);}

/* def-max78 in read-file in k763 in k760 in k757 */
static void C_fcall f_829(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_829,NULL,4,t0,t1,t2,t3);}
/* body7482 */
t4=((C_word*)t0)[2];
f_769(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body74 in read-file in k763 in k760 in k757 */
static void C_fcall f_769(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_769,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_772,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word)li1),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_822,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* extras.scm:52: port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[6]+1)))(3,*((C_word*)lf[6]+1),t6,t2);}

/* k820 in body74 in read-file in k763 in k760 in k757 */
static void C_ccall f_822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* extras.scm:53: slurp */
t2=((C_word*)t0)[5];
f_772(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* extras.scm:54: call-with-input-file */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[5]);}}

/* slurp in body74 in read-file in k763 in k760 in k757 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_772,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_780,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* extras.scm:48: reader */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k778 in slurp in body74 in read-file in k763 in k760 in k757 */
static void C_ccall f_780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_780,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li0),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_782(t5,((C_word*)t0)[2],t1,C_fix(0),C_SCHEME_END_OF_LIST);}

/* doloop88 in k778 in slurp in body74 in read-file in k763 in k760 in k757 */
static void C_fcall f_782(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_782,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eofp(t2);
t6=(C_truep(t5)?t5:(C_truep(((C_word*)t0)[6])?C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[6]):C_SCHEME_FALSE));
if(C_truep(t6)){
/* extras.scm:51: reverse */
t7=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t7))(3,t7,t1,t4);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_802,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t4,a[5]=t2,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* extras.scm:48: reader */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,((C_word*)t0)[2]);}}

/* k800 in doloop88 in k778 in slurp in body74 in read-file in k763 in k760 in k757 */
static void C_ccall f_802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_802,2,t0,t1);}
t2=C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_782(t4,((C_word*)t0)[2],t1,t2,t3);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[238] = {
{"toplevel:extras_scm",(void*)C_extras_toplevel},
{"f_759:extras_scm",(void*)f_759},
{"f_762:extras_scm",(void*)f_762},
{"f_765:extras_scm",(void*)f_765},
{"f_3129:extras_scm",(void*)f_3129},
{"f_3519:extras_scm",(void*)f_3519},
{"f_3476:extras_scm",(void*)f_3476},
{"f_3509:extras_scm",(void*)f_3509},
{"f_3484:extras_scm",(void*)f_3484},
{"f_3470:extras_scm",(void*)f_3470},
{"f_3464:extras_scm",(void*)f_3464},
{"f_3458:extras_scm",(void*)f_3458},
{"f_3160:extras_scm",(void*)f_3160},
{"f_3164:extras_scm",(void*)f_3164},
{"f_3447:extras_scm",(void*)f_3447},
{"f_3167:extras_scm",(void*)f_3167},
{"f_3198:extras_scm",(void*)f_3198},
{"f_3233:extras_scm",(void*)f_3233},
{"f_3411:extras_scm",(void*)f_3411},
{"f_3366:extras_scm",(void*)f_3366},
{"f_3369:extras_scm",(void*)f_3369},
{"f_3375:extras_scm",(void*)f_3375},
{"f_3348:extras_scm",(void*)f_3348},
{"f_3344:extras_scm",(void*)f_3344},
{"f_3331:extras_scm",(void*)f_3331},
{"f_3327:extras_scm",(void*)f_3327},
{"f_3314:extras_scm",(void*)f_3314},
{"f_3310:extras_scm",(void*)f_3310},
{"f_3297:extras_scm",(void*)f_3297},
{"f_3284:extras_scm",(void*)f_3284},
{"f_3271:extras_scm",(void*)f_3271},
{"f_3246:extras_scm",(void*)f_3246},
{"f_3214:extras_scm",(void*)f_3214},
{"f_3207:extras_scm",(void*)f_3207},
{"f_3170:extras_scm",(void*)f_3170},
{"f_3192:extras_scm",(void*)f_3192},
{"f_3131:extras_scm",(void*)f_3131},
{"f_3135:extras_scm",(void*)f_3135},
{"f_3142:extras_scm",(void*)f_3142},
{"f_3144:extras_scm",(void*)f_3144},
{"f_3148:extras_scm",(void*)f_3148},
{"f_3138:extras_scm",(void*)f_3138},
{"f_1850:extras_scm",(void*)f_1850},
{"f_3118:extras_scm",(void*)f_3118},
{"f_3122:extras_scm",(void*)f_3122},
{"f_2471:extras_scm",(void*)f_2471},
{"f_3026:extras_scm",(void*)f_3026},
{"f_3036:extras_scm",(void*)f_3036},
{"f_3017:extras_scm",(void*)f_3017},
{"f_3011:extras_scm",(void*)f_3011},
{"f_2989:extras_scm",(void*)f_2989},
{"f_2983:extras_scm",(void*)f_2983},
{"f_2977:extras_scm",(void*)f_2977},
{"f_2971:extras_scm",(void*)f_2971},
{"f_2965:extras_scm",(void*)f_2965},
{"f_2959:extras_scm",(void*)f_2959},
{"f_2953:extras_scm",(void*)f_2953},
{"f_2805:extras_scm",(void*)f_2805},
{"f_2951:extras_scm",(void*)f_2951},
{"f_2903:extras_scm",(void*)f_2903},
{"f_2933:extras_scm",(void*)f_2933},
{"f_2918:extras_scm",(void*)f_2918},
{"f_2890:extras_scm",(void*)f_2890},
{"f_2849:extras_scm",(void*)f_2849},
{"f_2876:extras_scm",(void*)f_2876},
{"f_2872:extras_scm",(void*)f_2872},
{"f_2808:extras_scm",(void*)f_2808},
{"f_2835:extras_scm",(void*)f_2835},
{"f_2831:extras_scm",(void*)f_2831},
{"f_2728:extras_scm",(void*)f_2728},
{"f_2734:extras_scm",(void*)f_2734},
{"f_2803:extras_scm",(void*)f_2803},
{"f_2799:extras_scm",(void*)f_2799},
{"f_2791:extras_scm",(void*)f_2791},
{"f_2787:extras_scm",(void*)f_2787},
{"f_2765:extras_scm",(void*)f_2765},
{"f_2757:extras_scm",(void*)f_2757},
{"f_2719:extras_scm",(void*)f_2719},
{"f_2723:extras_scm",(void*)f_2723},
{"f_2691:extras_scm",(void*)f_2691},
{"f_2717:extras_scm",(void*)f_2717},
{"f_2695:extras_scm",(void*)f_2695},
{"f_2626:extras_scm",(void*)f_2626},
{"f_2633:extras_scm",(void*)f_2633},
{"f_2660:extras_scm",(void*)f_2660},
{"f_2686:extras_scm",(void*)f_2686},
{"f_2644:extras_scm",(void*)f_2644},
{"f_2539:extras_scm",(void*)f_2539},
{"f_2552:extras_scm",(void*)f_2552},
{"f_2590:extras_scm",(void*)f_2590},
{"f_2555:extras_scm",(void*)f_2555},
{"f_2584:extras_scm",(void*)f_2584},
{"f_2588:extras_scm",(void*)f_2588},
{"f_2568:extras_scm",(void*)f_2568},
{"f_2507:extras_scm",(void*)f_2507},
{"f_2530:extras_scm",(void*)f_2530},
{"f_2523:extras_scm",(void*)f_2523},
{"f_2474:extras_scm",(void*)f_2474},
{"f_2505:extras_scm",(void*)f_2505},
{"f_2498:extras_scm",(void*)f_2498},
{"f_1963:extras_scm",(void*)f_1963},
{"f_2142:extras_scm",(void*)f_2142},
{"f_2413:extras_scm",(void*)f_2413},
{"f_2452:extras_scm",(void*)f_2452},
{"f_2462:extras_scm",(void*)f_2462},
{"f_2455:extras_scm",(void*)f_2455},
{"f_2430:extras_scm",(void*)f_2430},
{"f_2440:extras_scm",(void*)f_2440},
{"f_2433:extras_scm",(void*)f_2433},
{"f_2420:extras_scm",(void*)f_2420},
{"f_2397:extras_scm",(void*)f_2397},
{"f_2400:extras_scm",(void*)f_2400},
{"f_2407:extras_scm",(void*)f_2407},
{"f_2379:extras_scm",(void*)f_2379},
{"f_2290:extras_scm",(void*)f_2290},
{"f_2293:extras_scm",(void*)f_2293},
{"f_2354:extras_scm",(void*)f_2354},
{"f_2333:extras_scm",(void*)f_2333},
{"f_2340:extras_scm",(void*)f_2340},
{"f_2317:extras_scm",(void*)f_2317},
{"f_2324:extras_scm",(void*)f_2324},
{"f_2297:extras_scm",(void*)f_2297},
{"f_2284:extras_scm",(void*)f_2284},
{"f_2200:extras_scm",(void*)f_2200},
{"f_2202:extras_scm",(void*)f_2202},
{"f_2209:extras_scm",(void*)f_2209},
{"f_2261:extras_scm",(void*)f_2261},
{"f_2257:extras_scm",(void*)f_2257},
{"f_2240:extras_scm",(void*)f_2240},
{"f_2236:extras_scm",(void*)f_2236},
{"f_2232:extras_scm",(void*)f_2232},
{"f_2181:extras_scm",(void*)f_2181},
{"f_2158:extras_scm",(void*)f_2158},
{"f_2161:extras_scm",(void*)f_2161},
{"f_2168:extras_scm",(void*)f_2168},
{"f_2149:extras_scm",(void*)f_2149},
{"f_2119:extras_scm",(void*)f_2119},
{"f_2123:extras_scm",(void*)f_2123},
{"f_1993:extras_scm",(void*)f_1993},
{"f_2076:extras_scm",(void*)f_2076},
{"f_2011:extras_scm",(void*)f_2011},
{"f_2013:extras_scm",(void*)f_2013},
{"f_2065:extras_scm",(void*)f_2065},
{"f_2061:extras_scm",(void*)f_2061},
{"f_2045:extras_scm",(void*)f_2045},
{"f_2037:extras_scm",(void*)f_2037},
{"f_1966:extras_scm",(void*)f_1966},
{"f_1973:extras_scm",(void*)f_1973},
{"f_1984:extras_scm",(void*)f_1984},
{"f_1944:extras_scm",(void*)f_1944},
{"f_1954:extras_scm",(void*)f_1954},
{"f_1911:extras_scm",(void*)f_1911},
{"f_1853:extras_scm",(void*)f_1853},
{"f_1885:extras_scm",(void*)f_1885},
{"f_1812:extras_scm",(void*)f_1812},
{"f_1816:extras_scm",(void*)f_1816},
{"f_1822:extras_scm",(void*)f_1822},
{"f_1772:extras_scm",(void*)f_1772},
{"f_1776:extras_scm",(void*)f_1776},
{"f_1779:extras_scm",(void*)f_1779},
{"f_1782:extras_scm",(void*)f_1782},
{"f_1751:extras_scm",(void*)f_1751},
{"f_1758:extras_scm",(void*)f_1758},
{"f_1764:extras_scm",(void*)f_1764},
{"f_1662:extras_scm",(void*)f_1662},
{"f_1703:extras_scm",(void*)f_1703},
{"f_1698:extras_scm",(void*)f_1698},
{"f_1667:extras_scm",(void*)f_1667},
{"f_1671:extras_scm",(void*)f_1671},
{"f_1684:extras_scm",(void*)f_1684},
{"f_1681:extras_scm",(void*)f_1681},
{"f_1593:extras_scm",(void*)f_1593},
{"f_1597:extras_scm",(void*)f_1597},
{"f_1600:extras_scm",(void*)f_1600},
{"f_1603:extras_scm",(void*)f_1603},
{"f_1608:extras_scm",(void*)f_1608},
{"f_1612:extras_scm",(void*)f_1612},
{"f_1618:extras_scm",(void*)f_1618},
{"f_1628:extras_scm",(void*)f_1628},
{"f_1621:extras_scm",(void*)f_1621},
{"f_1533:extras_scm",(void*)f_1533},
{"f_1476:extras_scm",(void*)f_1476},
{"f_1480:extras_scm",(void*)f_1480},
{"f_1504:extras_scm",(void*)f_1504},
{"f_1507:extras_scm",(void*)f_1507},
{"f_1512:extras_scm",(void*)f_1512},
{"f_1516:extras_scm",(void*)f_1516},
{"f_1528:extras_scm",(void*)f_1528},
{"f_1489:extras_scm",(void*)f_1489},
{"f_1492:extras_scm",(void*)f_1492},
{"f_1379:extras_scm",(void*)f_1379},
{"f_1428:extras_scm",(void*)f_1428},
{"f_1423:extras_scm",(void*)f_1423},
{"f_1381:extras_scm",(void*)f_1381},
{"f_1385:extras_scm",(void*)f_1385},
{"f_1233:extras_scm",(void*)f_1233},
{"f_1373:extras_scm",(void*)f_1373},
{"f_1243:extras_scm",(void*)f_1243},
{"f_1313:extras_scm",(void*)f_1313},
{"f_1317:extras_scm",(void*)f_1317},
{"f_1320:extras_scm",(void*)f_1320},
{"f_1254:extras_scm",(void*)f_1254},
{"f_1258:extras_scm",(void*)f_1258},
{"f_1143:extras_scm",(void*)f_1143},
{"f_1210:extras_scm",(void*)f_1210},
{"f_1155:extras_scm",(void*)f_1155},
{"f_1165:extras_scm",(void*)f_1165},
{"f_1178:extras_scm",(void*)f_1178},
{"f_994:extras_scm",(void*)f_994},
{"f_1004:extras_scm",(void*)f_1004},
{"f_1007:extras_scm",(void*)f_1007},
{"f_1027:extras_scm",(void*)f_1027},
{"f_1032:extras_scm",(void*)f_1032},
{"f_1045:extras_scm",(void*)f_1045},
{"f_1118:extras_scm",(void*)f_1118},
{"f_1110:extras_scm",(void*)f_1110},
{"f_1096:extras_scm",(void*)f_1096},
{"f_1078:extras_scm",(void*)f_1078},
{"f_1087:extras_scm",(void*)f_1087},
{"f_1014:extras_scm",(void*)f_1014},
{"f_955:extras_scm",(void*)f_955},
{"f_929:extras_scm",(void*)f_929},
{"f_950:extras_scm",(void*)f_950},
{"f_933:extras_scm",(void*)f_933},
{"f_908:extras_scm",(void*)f_908},
{"f_912:extras_scm",(void*)f_912},
{"f_915:extras_scm",(void*)f_915},
{"f_767:extras_scm",(void*)f_767},
{"f_839:extras_scm",(void*)f_839},
{"f_834:extras_scm",(void*)f_834},
{"f_829:extras_scm",(void*)f_829},
{"f_769:extras_scm",(void*)f_769},
{"f_822:extras_scm",(void*)f_822},
{"f_772:extras_scm",(void*)f_772},
{"f_780:extras_scm",(void*)f_780},
{"f_782:extras_scm",(void*)f_782},
{"f_802:extras_scm",(void*)f_802},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
