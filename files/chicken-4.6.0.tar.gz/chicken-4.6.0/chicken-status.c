/* Generated from chicken-status.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-status.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file chicken-status.c
   used units: library eval srfi_1 posix data_structures utils ports regex files
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[79];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_432)
static void C_ccall f_432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_435)
static void C_ccall f_435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_438)
static void C_ccall f_438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_441)
static void C_ccall f_441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_444)
static void C_ccall f_444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_447)
static void C_ccall f_447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_450)
static void C_ccall f_450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_459)
static void C_ccall f_459(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_463)
static void C_ccall f_463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1226)
static void C_ccall f_1226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_851)
static void C_fcall f_851(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1030)
static void C_fcall f_1030(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_fcall f_1117(C_word t0,C_word t1) C_noret;
C_noret_decl(f1326)
static void C_ccall f1326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1166)
static void C_ccall f_1166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1126)
static void C_ccall f_1126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1158)
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1132)
static void C_ccall f_1132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1321)
static void C_ccall f1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1149)
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1143)
static void C_ccall f_1143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1139)
static void C_ccall f_1139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_ccall f_1111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1104)
static void C_ccall f_1104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1316)
static void C_ccall f1316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1015)
static void C_ccall f_1015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_982)
static void C_ccall f_982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_985)
static void C_ccall f_985(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1008)
static void C_ccall f_1008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_990)
static void C_ccall f_990(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_fcall f_859(C_word t0,C_word t1) C_noret;
C_noret_decl(f_931)
static void C_fcall f_931(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_966)
static void C_ccall f_966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_885)
static void C_ccall f_885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_887)
static void C_fcall f_887(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_863)
static void C_ccall f_863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_570)
static void C_ccall f_570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_566)
static void C_ccall f_566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_529)
static void C_fcall f_529(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_558)
static void C_ccall f_558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_519)
static void C_ccall f_519(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_517)
static void C_ccall f_517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_513)
static void C_ccall f_513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_866)
static void C_ccall f_866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1222)
static void C_ccall f_1222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1219)
static void C_ccall f_1219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_778)
static void C_ccall f_778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_815)
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_829)
static void C_ccall f_829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_813)
static void C_ccall f_813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_786)
static void C_ccall f_786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_fcall f_788(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_688)
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_656)
static void C_ccall f_656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_662)
static void C_ccall f_662(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_682)
static void C_ccall f_682r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_676)
static void C_ccall f_676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_665)
static void C_ccall f_665(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_692)
static void C_ccall f_692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_701)
static void C_fcall f_701(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_757)
static void C_ccall f_757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_709)
static void C_fcall f_709(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_754)
static void C_ccall f_754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_ccall f_750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_743)
static void C_ccall f_743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_723)
static void C_ccall f_723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_735)
static void C_ccall f_735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_731)
static void C_ccall f_731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_727)
static void C_ccall f_727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_572)
static void C_fcall f_572(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_604)
static void C_fcall f_604(C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_fcall f_599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_574)
static void C_fcall f_574(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_594)
static void C_ccall f_594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_467)
static void C_fcall f_467(C_word t0) C_noret;
C_noret_decl(f_481)
static void C_ccall f_481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_488)
static void C_ccall f_488(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_491)
static void C_ccall f_491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_851)
static void C_fcall trf_851(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_851(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_851(t0,t1,t2,t3);}

C_noret_decl(trf_1030)
static void C_fcall trf_1030(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1030(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1030(t0,t1);}

C_noret_decl(trf_1117)
static void C_fcall trf_1117(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1117(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1117(t0,t1);}

C_noret_decl(trf_859)
static void C_fcall trf_859(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_859(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_859(t0,t1);}

C_noret_decl(trf_931)
static void C_fcall trf_931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_931(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_931(t0,t1,t2);}

C_noret_decl(trf_887)
static void C_fcall trf_887(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_887(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_887(t0,t1,t2);}

C_noret_decl(trf_529)
static void C_fcall trf_529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_529(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_529(t0,t1,t2);}

C_noret_decl(trf_788)
static void C_fcall trf_788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_788(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_788(t0,t1,t2);}

C_noret_decl(trf_701)
static void C_fcall trf_701(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_701(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_701(t0,t1,t2);}

C_noret_decl(trf_709)
static void C_fcall trf_709(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_709(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_709(t0,t1,t2);}

C_noret_decl(trf_572)
static void C_fcall trf_572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_572(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_572(t0,t1,t2,t3);}

C_noret_decl(trf_604)
static void C_fcall trf_604(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_604(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_604(t0,t1);}

C_noret_decl(trf_599)
static void C_fcall trf_599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_599(t0,t1,t2);}

C_noret_decl(trf_574)
static void C_fcall trf_574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_574(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_574(t0,t1,t2,t3);}

C_noret_decl(trf_467)
static void C_fcall trf_467(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_467(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_467(t0);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(469)){
C_save(t1);
C_rereclaim2(469*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,79);
lf[4]=C_h_intern(&lf[4],13,"make-pathname");
lf[5]=C_h_intern(&lf[5],17,"get-output-string");
lf[6]=C_h_intern(&lf[6],7,"display");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\010chicken/");
lf[8]=C_h_intern(&lf[8],18,"open-output-string");
lf[9]=C_h_intern(&lf[9],17,"\003syspeek-c-string");
lf[10]=C_h_intern(&lf[10],15,"repository-path");
lf[12]=C_h_intern(&lf[12],13,"string-append");
lf[13]=C_h_intern(&lf[13],11,"make-string");
lf[14]=C_h_intern(&lf[14],5,"fxmax");
lf[15]=C_h_intern(&lf[15],9,"\003syserror");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[18]=C_h_intern(&lf[18],7,"version");
lf[19]=C_h_intern(&lf[19],5,"print");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\012 version: ");
lf[21]=C_h_intern(&lf[21],8,"->string");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[23]=C_h_intern(&lf[23],19,"setup-api#read-info");
lf[24]=C_h_intern(&lf[24],4,"sort");
lf[25]=C_h_intern(&lf[25],8,"string<\077");
lf[26]=C_h_intern(&lf[26],3,"min");
lf[27]=C_h_intern(&lf[27],13,"terminal-size");
lf[28]=C_h_intern(&lf[28],14,"terminal-port\077");
lf[29]=C_h_intern(&lf[29],19,"current-output-port");
lf[31]=C_h_intern(&lf[31],5,"files");
lf[32]=C_h_intern(&lf[32],10,"append-map");
lf[33]=C_h_intern(&lf[33],25,"\003sysimplicit-exit-handler");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\006(none)");
lf[35]=C_h_intern(&lf[35],17,"delete-duplicates");
lf[36]=C_h_intern(&lf[36],8,"string=\077");
lf[37]=C_h_intern(&lf[37],11,"concatenate");
lf[38]=C_h_intern(&lf[38],4,"grep");
lf[39]=C_h_intern(&lf[39],7,"\003sysmap");
lf[40]=C_h_intern(&lf[40],13,"pathname-file");
lf[41]=C_h_intern(&lf[41],4,"glob");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\012setup-info");
lf[44]=C_h_intern(&lf[44],6,"regexp");
lf[45]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002.*\376\377\016");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001^");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001$");
lf[48]=C_h_intern(&lf[48],13,"regexp-escape");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\013\012target at ");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\002:\012");
lf[51]=C_h_intern(&lf[51],16,"\003sysdynamic-wind");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\010host at ");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\002:\012");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[55]=C_h_intern(&lf[55],4,"exit");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\001\315usage: chicken-status [OPTION | PATTERN] ...\012\012  -h   -help                 "
"   show this message\012  -v   -version                 show version and exit\012  -f "
"  -files                   list installed files\012       -exact                   "
"treat PATTERN as exact match (not a pattern)\012       -host                    whe"
"n cross-compiling, show status of host extensions only\012       -target           "
"       when cross-compiling, show status of target extensions only");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\006-exact");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\002-f");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\006-files");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[64]=C_h_intern(&lf[64],15,"chicken-version");
lf[65]=C_h_intern(&lf[65],6,"append");
lf[66]=C_h_intern(&lf[66],6,"string");
lf[67]=C_h_intern(&lf[67],4,"memq");
lf[68]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000f\376\377\016");
lf[69]=C_h_intern(&lf[69],5,"every");
lf[70]=C_h_intern(&lf[70],16,"\003sysstring->list");
lf[71]=C_h_intern(&lf[71],9,"substring");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[74]=C_h_intern(&lf[74],22,"command-line-arguments");
lf[75]=C_h_intern(&lf[75],8,"feature\077");
lf[76]=C_h_intern(&lf[76],14,"\000cross-chicken");
lf[77]=C_h_intern(&lf[77],11,"\003sysrequire");
lf[78]=C_h_intern(&lf[78],9,"setup-api");
C_register_lf2(lf,79,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_432,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k430 */
static void C_ccall f_432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_435,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k433 in k430 */
static void C_ccall f_435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_435,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_438,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k436 in k433 in k430 */
static void C_ccall f_438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_438,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_441,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k439 in k436 in k433 in k430 */
static void C_ccall f_441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_441,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_444,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_444,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_447,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_447,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_450,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_453,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_456,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_459,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[77]))(3,*((C_word*)lf[77]+1),t2,lf[78]);}

/* k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_459(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_459,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_463,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* feature? */
((C_proc3)C_retrieve_symbol_proc(lf[75]))(3,*((C_word*)lf[75]+1),t2,lf[76]);}

/* k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_463,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,C_retrieve2(lf[0],"main#*cross-chicken*"));
t4=C_mutate(&lf[2] /* (set! main#*target-extensions* ...) */,C_retrieve2(lf[0],"main#*cross-chicken*"));
t5=C_mutate(&lf[3] /* (set! main#repo-path ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_467,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[11] /* (set! main#format-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_572,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[17] /* (set! main#list-installed-eggs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_688,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[30] /* (set! main#list-installed-files ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_778,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1216,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1226,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[74]))(2,*((C_word*)lf[74]+1),t10);}

/* k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1226,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_851,a[2]=t7,a[3]=t5,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_851(t9,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_851(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_851,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_859,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(C_truep(C_retrieve2(lf[1],"main#*host-extensions*"))?C_retrieve2(lf[2],"main#*target-extensions*"):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_982,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1015,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* main#repo-path */
f_467(t7);}
else{
/* status279 */
t6=t4;
f_859(t6,t1);}}
else{
t4=C_i_car(t2);
t5=C_i_string_equal_p(t4,lf[54]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1030,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_1030(t7,t5);}
else{
t7=C_i_string_equal_p(t4,lf[72]);
t8=t6;
f_1030(t8,(C_truep(t7)?t7:C_i_string_equal_p(t4,lf[73])));}}}

/* k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_1030(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1030,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1316,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,lf[56]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[57]))){
t2=lf[2] /* main#*target-extensions* */ =C_SCHEME_FALSE;;
t3=C_i_cdr(((C_word*)t0)[6]);
/* loop276 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_851(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[58]))){
t2=lf[1] /* main#*host-extensions* */ =C_SCHEME_FALSE;;
t3=C_i_cdr(((C_word*)t0)[6]);
/* loop276 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_851(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[59]))){
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t3=C_i_cdr(((C_word*)t0)[6]);
/* loop276 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_851(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
t2=C_i_string_equal_p(((C_word*)t0)[7],lf[60]);
t3=(C_truep(t2)?t2:C_i_string_equal_p(((C_word*)t0)[7],lf[61]));
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_TRUE);
t5=C_i_cdr(((C_word*)t0)[6]);
/* loop276 */
t6=((C_word*)((C_word*)t0)[5])[1];
f_851(t6,((C_word*)t0)[8],t5,((C_word*)t0)[4]);}
else{
t4=C_i_string_equal_p(((C_word*)t0)[7],lf[62]);
t5=(C_truep(t4)?t4:C_i_string_equal_p(((C_word*)t0)[7],lf[63]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1104,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1111,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[64]))(2,*((C_word*)lf[64]+1),t7);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1117,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t7=C_i_string_length(((C_word*)t0)[7]);
if(C_truep(C_i_positivep(t7))){
t8=C_i_string_ref(((C_word*)t0)[7],C_fix(0));
t9=t6;
f_1117(t9,C_eqp(C_make_character(45),t8));}
else{
t8=t6;
f_1117(t8,C_SCHEME_FALSE);}}}}}}}}

/* k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_1117(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1117,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[6]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1126,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1166,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t4,((C_word*)t0)[6],C_fix(1));}
else{
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1326,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t4,lf[56]);}}
else{
t2=C_i_cdr(((C_word*)t0)[2]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[3]);
/* loop276 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_851(t4,((C_word*)t0)[4],t2,t3);}}

/* f1326 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f1326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],C_fix(1));}

/* k1164 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[70]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1132,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1158,tmp=(C_word)a,a+=2,tmp);
/* every */
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t2,t3,t1);}

/* a1157 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1158(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1158,3,t0,t1,t2);}
t3=*((C_word*)lf[67]+1);
/* g379380 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[68]);}

/* k1130 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1132,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1139,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1143,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1149,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f1321,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,lf[56]);}}

/* f1321 in k1130 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],C_fix(1));}

/* a1148 in k1130 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1149(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1149,3,t0,t1,t2);}
t3=*((C_word*)lf[66]+1);
/* g398399 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k1141 in k1130 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[65]+1)))(4,*((C_word*)lf[65]+1),((C_word*)t0)[2],t1,t2);}

/* k1137 in k1130 in k1124 in k1115 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop276 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_851(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1109 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k1102 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],C_fix(0));}

/* f1316 in k1028 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f1316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[55]))(3,*((C_word*)lf[55]+1),((C_word*)t0)[2],C_fix(0));}

/* k1013 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),((C_word*)t0)[2],lf[52],t1,lf[53]);}

/* k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_982,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_985,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* status279 */
t3=((C_word*)t0)[3];
f_859(t3,t2);}

/* k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_985(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_985,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_990,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_995,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1008,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a1007 in k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1008,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[1],"main#*host-extensions*"));
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a994 in k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_999,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1006,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* main#repo-path */
f_467(t3);}

/* k1004 in a994 in k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),((C_word*)t0)[2],lf[49],t1,lf[50]);}

/* k997 in a994 in k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* status279 */
t2=((C_word*)t0)[3];
f_859(t2,((C_word*)t0)[2]);}

/* a989 in k983 in k980 in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_990(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_990,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[1],"main#*host-extensions*"));
t3=C_mutate(&lf[1] /* (set! main#*host-extensions* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_859(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_859,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_863,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_885,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
t8=t7;
f_885(2,t8,lf[45]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_931,a[2]=t9,a[3]=t13,a[4]=t11,tmp=(C_word)a,a+=5,tmp));
t15=((C_word*)t13)[1];
f_931(t15,t7,((C_word*)t0)[3]);}
else{
t8=((C_word*)t0)[3];
t9=t7;
f_885(2,t9,t8);}}}

/* loop309 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_931(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_931,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_966,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* regexp-escape */
((C_proc3)C_retrieve_symbol_proc(lf[48]))(3,*((C_word*)lf[48]+1),t5,t4);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k964 in loop309 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[12]+1)))(5,*((C_word*)lf[12]+1),((C_word*)t0)[2],lf[46],t1,lf[47]);}

/* k967 in loop309 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop309322 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_931(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop309322 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_931(t6,((C_word*)t0)[3],t5);}}

/* k883 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_885,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_887,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_887(t5,((C_word*)t0)[2],t1);}

/* loop283 in k883 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_887(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_887,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[44]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_916,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g299300 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k914 in loop283 in k883 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_916,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop283296 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_887(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop283296 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_887(t6,((C_word*)t0)[3],t5);}}

/* k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[23],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_506,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_527,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_566,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_570,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* main#repo-path */
f_467(t10);}

/* k568 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[4]))(5,*((C_word*)lf[4]+1),((C_word*)t0)[2],t1,lf[42],lf[43]);}

/* k564 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* glob */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),((C_word*)t0)[2],t1);}

/* k525 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_527,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_529,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_529(t5,((C_word*)t0)[2],t1);}

/* loop162 in k525 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_529(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_529,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[40]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_558,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g178179 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k556 in loop162 in k525 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_558,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop162175 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_529(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop162175 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_529(t6,((C_word*)t0)[3],t5);}}

/* k504 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_513,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_517,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_519,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* map */
t5=*((C_word*)lf[39]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a518 in k504 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_519(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_519,3,t0,t1,t2);}
t3=C_retrieve(lf[38]);
/* g200201 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,((C_word*)t0)[2]);}

/* k515 in k504 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[37]))(3,*((C_word*)lf[37]+1),((C_word*)t0)[2],t1);}

/* k511 in k504 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[35]))(4,*((C_word*)lf[35]+1),((C_word*)t0)[2],t1,*((C_word*)lf[36]+1));}

/* k864 in k861 in status in loop in k1224 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_i_nullp(t1))){
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),((C_word*)t0)[3],lf[34]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t2=C_retrieve2(lf[30],"main#list-installed-files");
/* g332333 */
t3=C_retrieve2(lf[30],"main#list-installed-files");
f_778(3,t3,((C_word*)t0)[3],t1);}
else{
t2=C_retrieve2(lf[17],"main#list-installed-eggs");
/* g332333 */
t3=C_retrieve2(lf[17],"main#list-installed-eggs");
f_688(3,t3,((C_word*)t0)[3],t1);}}}

/* k1214 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1219,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1222,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[33]))(2,*((C_word*)lf[33]+1),t3);}

/* k1220 in k1214 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k1217 in k1214 in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_1219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_778,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_786,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_813,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_815,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc4)C_retrieve_symbol_proc(lf[32]))(4,*((C_word*)lf[32]+1),t4,t5,t2);}

/* a814 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_815(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_815,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_829,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_833,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* main#repo-path */
f_467(t4);}

/* k831 in a814 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#read-info */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k827 in a814 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_assq(lf[31],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_cdr(t2):C_SCHEME_END_OF_LIST));}

/* k811 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* sort */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),((C_word*)t0)[2],t1,*((C_word*)lf[25]+1));}

/* k784 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_786,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_788,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_788(t5,((C_word*)t0)[2],t1);}

/* loop258 in k784 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_788(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_788,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[19]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g265266 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k796 in loop258 in k784 in main#list-installed-files in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_788(t3,((C_word*)t0)[2],t2);}

/* main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_688(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_688,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_692,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_776,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_656,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* current-output-port */
((C_proc2)C_retrieve_proc(*((C_word*)lf[29]+1)))(2,*((C_word*)lf[29]+1),t5);}

/* k654 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_662,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* terminal-port? */
((C_proc3)C_retrieve_symbol_proc(lf[28]))(3,*((C_word*)lf[28]+1),t2,t1);}

/* k660 in k654 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_662(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_662,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_665,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_676,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_682,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t2,t3,t4);}
else{
t2=((C_word*)t0)[4];
f_692(2,t2,C_fix(39));}}

/* a681 in k660 in k654 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_682(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_682r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_682r(t0,t1,t2);}}

static void C_ccall f_682r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_list_ref(t2,C_fix(1)));}

/* a675 in k660 in k654 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_676,2,t0,t1);}
/* terminal-size */
((C_proc3)C_retrieve_symbol_proc(lf[27]))(3,*((C_word*)lf[27]+1),t1,((C_word*)t0)[2]);}

/* k663 in k660 in k654 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_665(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=((C_word*)t0)[3];
f_692(2,t2,C_fix(39));}
else{
/* min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),((C_word*)t0)[2],C_fix(80),t1);}}

/* k774 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=C_a_i_minus(&a,2,t1,C_fix(2));
C_quotient(4,0,((C_word*)t0)[2],t2,C_fix(2));}

/* k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_699,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* sort */
((C_proc4)C_retrieve_symbol_proc(lf[24]))(4,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2],*((C_word*)lf[25]+1));}

/* k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_699,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_701,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_701(t5,((C_word*)t0)[2],t1);}

/* loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_701(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_701,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_709,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_757,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g249250 */
t6=t3;
f_709(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k755 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_701(t3,((C_word*)t0)[2],t2);}

/* g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_709(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_709,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_750,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_754,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* main#repo-path */
f_467(t4);}

/* k752 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#read-info */
((C_proc4)C_retrieve_symbol_proc(lf[23]))(4,*((C_word*)lf[23]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_750,2,t0,t1);}
t2=C_i_assq(lf[18],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_723,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_743,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t4,((C_word*)t0)[2],lf[22]);}
else{
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k741 in k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_743,2,t0,t1);}
/* main#format-string */
f_572(((C_word*)t0)[3],t1,((C_word*)t0)[2],C_a_i_list(&a,2,C_SCHEME_FALSE,C_make_character(46)));}

/* k721 in k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_727,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_731,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_735,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[21]))(3,*((C_word*)lf[21]+1),t4,t5);}

/* k733 in k721 in k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[2],lf[20],t1);}

/* k729 in k721 in k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_731,2,t0,t1);}
/* main#format-string */
f_572(((C_word*)t0)[3],t1,((C_word*)t0)[2],C_a_i_list(&a,2,C_SCHEME_TRUE,C_make_character(46)));}

/* k725 in k721 in k748 in g249 in loop242 in k697 in k690 in main#list-installed-eggs in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_572(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_572,NULL,4,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_574,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_604,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-right215227 */
t8=t7;
f_604(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-padc216225 */
t10=t6;
f_599(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body213220 */
t12=t5;
f_574(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[16],t11);}}}}

/* def-right215 in main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_604(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_604,NULL,2,t0,t1);}
/* def-padc216225 */
t2=((C_word*)t0)[2];
f_599(t2,t1,C_SCHEME_FALSE);}

/* def-padc216 in main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_599,NULL,3,t0,t1,t2);}
/* body213220 */
t3=((C_word*)t0)[2];
f_574(t3,t1,t2,C_make_character(32));}

/* body213 in main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_574(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_574,NULL,4,t0,t1,t2,t3);}
t4=C_i_string_length(((C_word*)t0)[3]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_581,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_594,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_fixnum_difference(((C_word*)t0)[2],t4);
/* fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[14]+1)))(4,*((C_word*)lf[14]+1),t6,C_fix(0),t7);}

/* k592 in body213 in main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[13]+1)))(4,*((C_word*)lf[13]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k579 in body213 in main#format-string in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
/* string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}}

/* main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_fcall f_467(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_467,NULL,1,t1);}
t2=(C_truep(C_retrieve2(lf[0],"main#*cross-chicken*"))?C_i_not(C_retrieve2(lf[1],"main#*host-extensions*")):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_481,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[9]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_TARGET_LIB_HOME),C_fix(0));}
else{
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[10]))(2,*((C_word*)lf[10]+1),t1);}}

/* k479 in main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_481,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_485,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t2);}

/* k483 in k479 in main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_485,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_488,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,lf[7],t1);}

/* k486 in k483 in k479 in main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_488(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_488,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[6]+1)))(4,*((C_word*)lf[6]+1),t2,C_fix((C_word)C_BINARY_VERSION),((C_word*)t0)[2]);}

/* k489 in k486 in k483 in k479 in main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[5]))(3,*((C_word*)lf[5]+1),t2,((C_word*)t0)[2]);}

/* k492 in k489 in k486 in k483 in k479 in main#repo-path in k461 in k457 in k454 in k451 in k448 in k445 in k442 in k439 in k436 in k433 in k430 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[4]))(4,*((C_word*)lf[4]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[97] = {
{"toplevel:chicken_status_scm",(void*)C_toplevel},
{"f_432:chicken_status_scm",(void*)f_432},
{"f_435:chicken_status_scm",(void*)f_435},
{"f_438:chicken_status_scm",(void*)f_438},
{"f_441:chicken_status_scm",(void*)f_441},
{"f_444:chicken_status_scm",(void*)f_444},
{"f_447:chicken_status_scm",(void*)f_447},
{"f_450:chicken_status_scm",(void*)f_450},
{"f_453:chicken_status_scm",(void*)f_453},
{"f_456:chicken_status_scm",(void*)f_456},
{"f_459:chicken_status_scm",(void*)f_459},
{"f_463:chicken_status_scm",(void*)f_463},
{"f_1226:chicken_status_scm",(void*)f_1226},
{"f_851:chicken_status_scm",(void*)f_851},
{"f_1030:chicken_status_scm",(void*)f_1030},
{"f_1117:chicken_status_scm",(void*)f_1117},
{"f1326:chicken_status_scm",(void*)f1326},
{"f_1166:chicken_status_scm",(void*)f_1166},
{"f_1126:chicken_status_scm",(void*)f_1126},
{"f_1158:chicken_status_scm",(void*)f_1158},
{"f_1132:chicken_status_scm",(void*)f_1132},
{"f1321:chicken_status_scm",(void*)f1321},
{"f_1149:chicken_status_scm",(void*)f_1149},
{"f_1143:chicken_status_scm",(void*)f_1143},
{"f_1139:chicken_status_scm",(void*)f_1139},
{"f_1111:chicken_status_scm",(void*)f_1111},
{"f_1104:chicken_status_scm",(void*)f_1104},
{"f1316:chicken_status_scm",(void*)f1316},
{"f_1015:chicken_status_scm",(void*)f_1015},
{"f_982:chicken_status_scm",(void*)f_982},
{"f_985:chicken_status_scm",(void*)f_985},
{"f_1008:chicken_status_scm",(void*)f_1008},
{"f_995:chicken_status_scm",(void*)f_995},
{"f_1006:chicken_status_scm",(void*)f_1006},
{"f_999:chicken_status_scm",(void*)f_999},
{"f_990:chicken_status_scm",(void*)f_990},
{"f_859:chicken_status_scm",(void*)f_859},
{"f_931:chicken_status_scm",(void*)f_931},
{"f_966:chicken_status_scm",(void*)f_966},
{"f_969:chicken_status_scm",(void*)f_969},
{"f_885:chicken_status_scm",(void*)f_885},
{"f_887:chicken_status_scm",(void*)f_887},
{"f_916:chicken_status_scm",(void*)f_916},
{"f_863:chicken_status_scm",(void*)f_863},
{"f_570:chicken_status_scm",(void*)f_570},
{"f_566:chicken_status_scm",(void*)f_566},
{"f_527:chicken_status_scm",(void*)f_527},
{"f_529:chicken_status_scm",(void*)f_529},
{"f_558:chicken_status_scm",(void*)f_558},
{"f_506:chicken_status_scm",(void*)f_506},
{"f_519:chicken_status_scm",(void*)f_519},
{"f_517:chicken_status_scm",(void*)f_517},
{"f_513:chicken_status_scm",(void*)f_513},
{"f_866:chicken_status_scm",(void*)f_866},
{"f_1216:chicken_status_scm",(void*)f_1216},
{"f_1222:chicken_status_scm",(void*)f_1222},
{"f_1219:chicken_status_scm",(void*)f_1219},
{"f_778:chicken_status_scm",(void*)f_778},
{"f_815:chicken_status_scm",(void*)f_815},
{"f_833:chicken_status_scm",(void*)f_833},
{"f_829:chicken_status_scm",(void*)f_829},
{"f_813:chicken_status_scm",(void*)f_813},
{"f_786:chicken_status_scm",(void*)f_786},
{"f_788:chicken_status_scm",(void*)f_788},
{"f_798:chicken_status_scm",(void*)f_798},
{"f_688:chicken_status_scm",(void*)f_688},
{"f_656:chicken_status_scm",(void*)f_656},
{"f_662:chicken_status_scm",(void*)f_662},
{"f_682:chicken_status_scm",(void*)f_682},
{"f_676:chicken_status_scm",(void*)f_676},
{"f_665:chicken_status_scm",(void*)f_665},
{"f_776:chicken_status_scm",(void*)f_776},
{"f_692:chicken_status_scm",(void*)f_692},
{"f_699:chicken_status_scm",(void*)f_699},
{"f_701:chicken_status_scm",(void*)f_701},
{"f_757:chicken_status_scm",(void*)f_757},
{"f_709:chicken_status_scm",(void*)f_709},
{"f_754:chicken_status_scm",(void*)f_754},
{"f_750:chicken_status_scm",(void*)f_750},
{"f_743:chicken_status_scm",(void*)f_743},
{"f_723:chicken_status_scm",(void*)f_723},
{"f_735:chicken_status_scm",(void*)f_735},
{"f_731:chicken_status_scm",(void*)f_731},
{"f_727:chicken_status_scm",(void*)f_727},
{"f_572:chicken_status_scm",(void*)f_572},
{"f_604:chicken_status_scm",(void*)f_604},
{"f_599:chicken_status_scm",(void*)f_599},
{"f_574:chicken_status_scm",(void*)f_574},
{"f_594:chicken_status_scm",(void*)f_594},
{"f_581:chicken_status_scm",(void*)f_581},
{"f_467:chicken_status_scm",(void*)f_467},
{"f_481:chicken_status_scm",(void*)f_481},
{"f_485:chicken_status_scm",(void*)f_485},
{"f_488:chicken_status_scm",(void*)f_488},
{"f_491:chicken_status_scm",(void*)f_491},
{"f_494:chicken_status_scm",(void*)f_494},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
