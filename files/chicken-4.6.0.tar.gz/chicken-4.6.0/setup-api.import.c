/* Generated from ./setup-api.import.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: ./setup-api.import.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -feature chicken-compile-shared -dynamic -no-trace -output-file setup-api.import.c
   used units: library eval
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[32];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,18),40,102,111,114,109,45,101,114,114,111,114,32,115,55,32,112,56,41,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,12),40,103,52,56,32,108,105,110,101,53,48,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,14),40,108,111,111,112,51,50,32,103,52,50,52,54,41,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,13),40,97,52,56,52,32,108,105,110,101,49,55,41,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,18),40,97,51,48,57,32,102,111,114,109,48,32,114,49,32,99,50,41,0,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,39),40,97,50,55,53,32,105,110,112,117,116,54,56,56,49,32,114,101,110,97,109,101,55,55,56,50,32,99,111,109,112,97,114,101,54,53,56,51,41,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,13),40,97,50,53,56,32,101,120,112,49,49,53,41,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,43),40,97,50,50,51,32,105,110,112,117,116,57,52,49,48,55,32,114,101,110,97,109,101,49,48,51,49,48,56,32,99,111,109,112,97,114,101,57,49,49,48,57,41,0,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,45),40,97,49,55,55,32,105,110,112,117,116,49,50,49,49,51,52,32,114,101,110,97,109,101,49,51,48,49,51,53,32,99,111,109,112,97,114,101,49,49,56,49,51,54,41,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_151)
static void C_ccall f_151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_154)
static void C_ccall f_154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_157)
static void C_ccall f_157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_178)
static void C_ccall f_178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_188)
static void C_ccall f_188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_195)
static void C_ccall f_195(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_203)
static void C_ccall f_203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_224)
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_234)
static void C_ccall f_234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_241)
static void C_ccall f_241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_253)
static void C_ccall f_253(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_259)
static void C_ccall f_259(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_267)
static void C_ccall f_267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_257)
static void C_ccall f_257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_276)
static void C_ccall f_276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_286)
static void C_ccall f_286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_293)
static void C_ccall f_293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_305)
static void C_ccall f_305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_ccall f_310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_314)
static void C_ccall f_314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_320)
static void C_ccall f_320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_323)
static void C_ccall f_323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_471)
static void C_ccall f_471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_480)
static void C_ccall f_480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_492)
static void C_fcall f_492(C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_331)
static void C_ccall f_331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_338)
static void C_ccall f_338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_374)
static void C_fcall f_374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_461)
static void C_ccall f_461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_401)
static void C_fcall f_401(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_450)
static void C_ccall f_450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_425)
static void C_ccall f_425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_372)
static void C_ccall f_372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_368)
static void C_ccall f_368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_350)
static void C_ccall f_350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_324)
static void C_fcall f_324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_160)
static void C_ccall f_160(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_492)
static void C_fcall trf_492(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_492(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_492(t0,t1);}

C_noret_decl(trf_374)
static void C_fcall trf_374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_374(t0,t1,t2);}

C_noret_decl(trf_401)
static void C_fcall trf_401(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_401(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_401(t0,t1,t2);}

C_noret_decl(trf_324)
static void C_fcall trf_324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_324(t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1573)){
C_save(t1);
C_rereclaim2(1573*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,32);
lf[0]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007execute\376\001\000\000\021setup-api#execute");
lf[1]=C_h_intern(&lf[1],5,"error");
lf[2]=C_h_intern(&lf[2],4,"list");
lf[3]=C_h_intern(&lf[3],10,"\003sysappend");
lf[4]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005quote\376\003\000\000\002\376\377\016\376\377\016\376\377\016");
lf[5]=C_h_intern(&lf[5],9,"make/proc");
lf[6]=C_h_intern(&lf[6],15,"make:line-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000\047second part of clause is not a sequence");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000%clause does not have at least 2 parts");
lf[9]=C_h_intern(&lf[9],5,"every");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000\023empty specification");
lf[11]=C_decode_literal(C_heaptop,"\376B\000\000&illegal specification (not a sequence)");
lf[12]=C_h_intern(&lf[12],6,"lambda");
lf[13]=C_h_intern(&lf[13],16,"\003syscheck-syntax");
lf[14]=C_h_intern(&lf[14],4,"make");
lf[15]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001_\376\003\000\000\002\376\001\000\000\001_\376\000\000\000\003\376\001\000\000\001_\376\377\001\000\000\000\000\376\377\001\000\000\000\001");
lf[16]=C_h_intern(&lf[16],3,"csc");
lf[17]=C_h_intern(&lf[17],3,"run");
lf[18]=C_h_intern(&lf[18],25,"\003syssyntax-rules-mismatch");
lf[19]=C_h_intern(&lf[19],9,"\003syslist\077");
lf[20]=C_h_intern(&lf[20],7,"compile");
lf[21]=C_h_intern(&lf[21],10,"quasiquote");
lf[22]=C_h_intern(&lf[22],9,"\003sysmap-n");
lf[23]=C_h_intern(&lf[23],7,"execute");
lf[24]=C_h_intern(&lf[24],2,"ex");
lf[25]=C_h_intern(&lf[25],17,"handle-exceptions");
lf[26]=C_h_intern(&lf[26],13,"ignore-errors");
lf[27]=C_h_intern(&lf[27],28,"\003sysregister-compiled-module");
lf[28]=C_h_intern(&lf[28],9,"setup-api");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022standard-extension\376\001\000\000\034setup-api#standard-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\011make/proc\376\001\000\000\023setup-api#make/proc\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016host-extension\376\001\000\000\030setup-api#ho"
"st-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021install-extension\376\001\000\000\033setup-api#install-extension\376\003\000\000"
"\002\376\003\000\000\002\376\001\000\000\017install-program\376\001\000\000\031setup-api#install-program\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016install-s"
"cript\376\001\000\000\030setup-api#install-script\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-verbose-mode\376\001\000\000\034setup-ap"
"i#setup-verbose-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022setup-install-mode\376\001\000\000\034setup-api#setup-instal"
"l-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000\017deployment-mode\376\001\000\000\031setup-api#deployment-mode\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\023installation-prefix\376\001\000\000\035setup-api#installation-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022destination"
"-prefix\376\001\000\000\034setup-api#destination-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016chicken-prefix\376\001\000\000\030setup-"
"api#chicken-prefix\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014find-library\376\001\000\000\026setup-api#find-library\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\013find-header\376\001\000\000\025setup-api#find-header\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014program-path\376\001\000\000\026setu"
"p-api#program-path\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014remove-file*\376\001\000\000\026setup-api#remove-file*\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\005patch\376\001\000\000\017setup-api#patch\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013abort-setup\376\001\000\000\025setup-api#abort-s"
"etup\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024setup-root-directory\376\001\000\000\036setup-api#setup-root-directory\376\003\000\000\002\376"
"\003\000\000\002\376\001\000\000\030create-directory/parents\376\001\000\000\042setup-api#create-directory/parents\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\014test-compile\376\001\000\000\026setup-api#test-compile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013try-compile\376\001\000\000\025set"
"up-api#try-compile\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013run-verbose\376\001\000\000\025setup-api#run-verbose\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\016extra-features\376\001\000\000\030setup-api#extra-features\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021extra-nonfeatures"
"\376\001\000\000\033setup-api#extra-nonfeatures\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011copy-file\376\001\000\000\023setup-api#copy-file"
"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011move-file\376\001\000\000\023setup-api#move-file\376\003\000\000\002\376\003\000\000\002\376\001\000\000\030required-chicken-"
"version\376\001\000\000\042setup-api#required-chicken-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032required-extension-"
"version\376\001\000\000$setup-api#required-extension-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014sudo-install\376\001\000\000\026"
"setup-api#sudo-install\376\003\000\000\002\376\003\000\000\002\376\001\000\000\022keep-intermediates\376\001\000\000\034setup-api#keep-inter"
"mediates\376\003\000\000\002\376\003\000\000\002\376\001\000\000\012version>=\077\376\001\000\000\024setup-api#version>=\077\376\003\000\000\002\376\003\000\000\002\376\001\000\000\032extensi"
"on-name-and-version\376\001\000\000$setup-api#extension-name-and-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\016exten"
"sion-name\376\001\000\000\030setup-api#extension-name\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021extension-version\376\001\000\000\033setup"
"-api#extension-version\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-directory\376\001\000\000\032setup-api#remove-direc"
"tory\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020remove-extension\376\001\000\000\032setup-api#remove-extension\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\011read-info\376\001\000\000\023setup-api#read-info\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020register-program\376\001\000\000\032setup-api#"
"register-program\376\003\000\000\002\376\003\000\000\002\376\001\000\000\014find-program\376\001\000\000\026setup-api#find-program\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\011shellpath\376\001\000\000\023setup-api#shellpath\376\003\000\000\002\376\003\000\000\002\376\001\000\000\024setup-error-handling\376\001\000\000\036se"
"tup-api#setup-error-handling\376\377\016");
lf[30]=C_h_intern(&lf[30],4,"eval");
lf[31]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006import\376\003\000\000\002\376\001\000\000\006scheme\376\003\000\000\002\376\001\000\000\007chicken\376\003\000\000\002\376\001\000\000\007foreign\376\003\000\000\002\376\001\000\000\005rege"
"x\376\003\000\000\002\376\001\000\000\005utils\376\003\000\000\002\376\001\000\000\005posix\376\003\000\000\002\376\001\000\000\005ports\376\003\000\000\002\376\001\000\000\006extras\376\003\000\000\002\376\001\000\000\017data-str"
"uctures\376\003\000\000\002\376\001\000\000\006srfi-1\376\003\000\000\002\376\001\000\000\007srfi-13\376\003\000\000\002\376\001\000\000\005files\376\377\016");
C_register_lf2(lf,32,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_151,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k149 */
static void C_ccall f_151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_154,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k152 in k149 */
static void C_ccall f_154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ./setup-api.import.scm:3: eval */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t2,lf[31]);}

/* k155 in k152 in k149 */
static void C_ccall f_157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[42],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_160,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,lf[0]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_310,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_cons(&a,2,lf[14],t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_276,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_cons(&a,2,lf[20],t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_224,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp);
t9=C_a_i_cons(&a,2,lf[17],t8);
t10=C_a_i_list(&a,3,t5,t7,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_178,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp);
t12=C_a_i_cons(&a,2,lf[26],t11);
t13=C_a_i_list(&a,1,t12);
/* ./setup-api.import.scm:16: ##sys#register-compiled-module */
((C_proc7)C_retrieve_symbol_proc(lf[27]))(7,*((C_word*)lf[27]+1),t2,lf[28],t3,lf[29],t10,t13);}

/* a177 in k155 in k152 in k149 */
static void C_ccall f_178(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_178,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_188,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t5);}

/* k186 in a177 in k155 in k152 in k149 */
static void C_ccall f_188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_188,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_195,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename130135 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[25]);}
else{
/* ##sys#syntax-rules-mismatch */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k193 in k186 in a177 in k155 in k152 in k149 */
static void C_ccall f_195(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_195,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_203,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* rename130135 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[24]);}

/* k201 in k193 in k186 in a177 in k155 in k152 in k149 */
static void C_ccall f_203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_203,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a223 in k155 in k152 in k149 */
static void C_ccall f_224(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_224,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_234,a[2]=t2,a[3]=t5,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t5);}

/* k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_234,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename103108 */
t3=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[23]);}
else{
/* ##sys#syntax-rules-mismatch */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[5],((C_word*)t0)[2]);}}

/* k239 in k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* rename103108 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[2]);}

/* k251 in k239 in k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_253(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_253,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_257,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_259,a[2]=((C_word*)t0)[3],a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
/* ##sys#map-n */
((C_proc4)C_retrieve_symbol_proc(lf[22]))(4,*((C_word*)lf[22]+1),t2,t3,((C_word*)t0)[2]);}

/* a258 in k251 in k239 in k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_259(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_259,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_267,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* rename103108 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[21]);}

/* k265 in a258 in k251 in k239 in k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_267,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,t1,t2));}

/* k255 in k251 in k239 in k232 in a223 in k155 in k152 in k149 */
static void C_ccall f_257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_257,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a275 in k155 in k152 in k149 */
static void C_ccall f_276(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_276,5,t0,t1,t2,t3,t4);}
t5=C_i_cdr(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_286,a[2]=t2,a[3]=t3,a[4]=t1,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* ##sys#list? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t6,t5);}

/* k284 in a275 in k155 in k152 in k149 */
static void C_ccall f_286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_286,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_293,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* rename7782 */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[17]);}
else{
/* ##sys#syntax-rules-mismatch */
((C_proc3)C_retrieve_symbol_proc(lf[18]))(3,*((C_word*)lf[18]+1),((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k291 in k284 in a275 in k155 in k152 in k149 */
static void C_ccall f_293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_305,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* rename7782 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[16]);}

/* k303 in k291 in k284 in a275 in k155 in k152 in k149 */
static void C_ccall f_305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_305,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* a309 in k155 in k152 in k149 */
static void C_ccall f_310(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_310,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_314,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ./setup-api.import.scm:63: ##sys#check-syntax */
((C_proc5)C_retrieve_symbol_proc(lf[13]))(5,*((C_word*)lf[13]+1),t5,lf[14],t2,lf[15]);}

/* k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_314,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ./setup-api.import.scm:65: r */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[2]);}

/* k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_320,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_323,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm:66: r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[12]);}

/* k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_324,a[2]=((C_word*)t0)[6],a[3]=((C_word)li0),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_i_listp(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_471,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_471(2,t6,t4);}
else{
/* ./setup-api.import.scm:69: form-error */
t6=t2;
f_324(t6,t5,lf[11],C_SCHEME_END_OF_LIST);}}

/* k469 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_471,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_pairp(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_480,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_480(2,t4,t2);}
else{
/* ./setup-api.import.scm:71: form-error */
t4=((C_word*)t0)[3];
f_324(t4,t3,lf[10],C_SCHEME_END_OF_LIST);}}
else{
t2=((C_word*)t0)[2];
f_331(2,t2,C_SCHEME_FALSE);}}

/* k478 in k469 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_480,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_485,a[2]=((C_word*)t0)[4],a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp);
/* ./setup-api.import.scm:72: every */
((C_proc4)C_retrieve_symbol_proc(lf[9]))(4,*((C_word*)lf[9]+1),((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_331(2,t2,C_SCHEME_FALSE);}}

/* a484 in k478 in k469 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_485,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_492,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
t5=t3;
f_492(t5,C_i_greater_or_equalp(t4,C_fix(2)));}
else{
t4=t3;
f_492(t4,C_SCHEME_FALSE);}}

/* k490 in a484 in k478 in k469 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_fcall f_492(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_492,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_495,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t2;
f_495(2,t3,t1);}
else{
/* ./setup-api.import.scm:74: form-error */
t3=((C_word*)t0)[2];
f_324(t3,t2,lf[8],C_a_i_list(&a,1,((C_word*)t0)[4]));}}

/* k493 in k490 in a484 in k478 in k469 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[3]);
t3=C_i_cadr(((C_word*)t0)[3]);
t4=C_i_listp(t3);
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_cadr(((C_word*)t0)[3]);
/* ./setup-api.import.scm:79: make:line-error */
((C_proc5)C_retrieve_symbol_proc(lf[6]))(5,*((C_word*)lf[6]+1),((C_word*)t0)[2],lf[7],t5,t2);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_338,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ./setup-api.import.scm:84: r */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,lf[5]);}

/* k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_368,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_372,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_374,a[2]=t4,a[3]=t9,a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word)li2),tmp=(C_word)a,a+=8,tmp));
t11=((C_word*)t9)[1];
f_374(t11,t7,((C_word*)t0)[2]);}

/* loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_fcall f_374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_374,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_401,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word)li1),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_461,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g4849 */
t6=t3;
f_401(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k459 in loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_461,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop3245 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_374(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop3245 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_374(t6,((C_word*)t0)[3],t5);}}

/* g48 in loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_fcall f_401(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_401,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=t3,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t5=C_i_cadr(t2);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,C_SCHEME_END_OF_LIST);}

/* k452 in g48 in loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_454,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_425,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
if(C_truep(C_i_nullp(t4))){
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_450,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t4,C_SCHEME_END_OF_LIST);}}

/* k448 in k452 in g48 in loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_450,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t4,C_SCHEME_END_OF_LIST);}

/* k423 in k452 in g48 in loop32 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_425,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],t2);
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,((C_word*)t0)[2],t3));}

/* k370 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k366 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_368,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[2],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_cddr(((C_word*)t0)[2]);
if(C_truep(C_i_nullp(t4))){
/* ##sys#append */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[4],C_SCHEME_END_OF_LIST);}
else{
t5=C_i_cddr(((C_word*)t0)[2]);
/* ##sys#append */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t5,C_SCHEME_END_OF_LIST);}}

/* k348 in k366 in k336 in k329 in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_ccall f_350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_350,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* form-error in k321 in k318 in k312 in a309 in k155 in k152 in k149 */
static void C_fcall f_324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_324,NULL,4,t0,t1,t2,t3);}
C_apply(6,0,t1,*((C_word*)lf[1]+1),t2,((C_word*)t0)[2],t3);}

/* k158 in k155 in k152 in k149 */
static void C_ccall f_160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[42] = {
{"toplevel:__setup_api_import_scm",(void*)C_toplevel},
{"f_151:__setup_api_import_scm",(void*)f_151},
{"f_154:__setup_api_import_scm",(void*)f_154},
{"f_157:__setup_api_import_scm",(void*)f_157},
{"f_178:__setup_api_import_scm",(void*)f_178},
{"f_188:__setup_api_import_scm",(void*)f_188},
{"f_195:__setup_api_import_scm",(void*)f_195},
{"f_203:__setup_api_import_scm",(void*)f_203},
{"f_224:__setup_api_import_scm",(void*)f_224},
{"f_234:__setup_api_import_scm",(void*)f_234},
{"f_241:__setup_api_import_scm",(void*)f_241},
{"f_253:__setup_api_import_scm",(void*)f_253},
{"f_259:__setup_api_import_scm",(void*)f_259},
{"f_267:__setup_api_import_scm",(void*)f_267},
{"f_257:__setup_api_import_scm",(void*)f_257},
{"f_276:__setup_api_import_scm",(void*)f_276},
{"f_286:__setup_api_import_scm",(void*)f_286},
{"f_293:__setup_api_import_scm",(void*)f_293},
{"f_305:__setup_api_import_scm",(void*)f_305},
{"f_310:__setup_api_import_scm",(void*)f_310},
{"f_314:__setup_api_import_scm",(void*)f_314},
{"f_320:__setup_api_import_scm",(void*)f_320},
{"f_323:__setup_api_import_scm",(void*)f_323},
{"f_471:__setup_api_import_scm",(void*)f_471},
{"f_480:__setup_api_import_scm",(void*)f_480},
{"f_485:__setup_api_import_scm",(void*)f_485},
{"f_492:__setup_api_import_scm",(void*)f_492},
{"f_495:__setup_api_import_scm",(void*)f_495},
{"f_331:__setup_api_import_scm",(void*)f_331},
{"f_338:__setup_api_import_scm",(void*)f_338},
{"f_374:__setup_api_import_scm",(void*)f_374},
{"f_461:__setup_api_import_scm",(void*)f_461},
{"f_401:__setup_api_import_scm",(void*)f_401},
{"f_454:__setup_api_import_scm",(void*)f_454},
{"f_450:__setup_api_import_scm",(void*)f_450},
{"f_425:__setup_api_import_scm",(void*)f_425},
{"f_372:__setup_api_import_scm",(void*)f_372},
{"f_368:__setup_api_import_scm",(void*)f_368},
{"f_350:__setup_api_import_scm",(void*)f_350},
{"f_324:__setup_api_import_scm",(void*)f_324},
{"f_160:__setup_api_import_scm",(void*)f_160},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
