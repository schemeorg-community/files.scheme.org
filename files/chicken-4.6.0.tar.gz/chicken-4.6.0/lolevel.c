/* Generated from lolevel.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: lolevel.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file lolevel.c
   unit: lolevel
*/

#include "chicken.h"

#if defined(__FreeBSD__) || defined(__NetBSD__) || defined(__OpenBSD__)
# include <sys/types.h>
#endif
#ifndef C_NONUNIX
# include <sys/mman.h>
#endif

#define C_w2b(x)                   C_fix(C_wordstobytes(C_unfix(x)))
#define C_memmove_o(to, from, n, toff, foff) C_memmove((char *)(to) + (toff), (char *)(from) + (foff), (n))

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_srfi_69_toplevel)
C_externimport void C_ccall C_srfi_69_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[141];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,99,104,101,99,107,45,98,108,111,99,107,32,120,54,49,32,108,111,99,54,50,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,41),40,35,35,115,121,115,35,99,104,101,99,107,45,103,101,110,101,114,105,99,45,115,116,114,117,99,116,117,114,101,32,120,56,49,32,108,111,99,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,33),40,35,35,115,121,115,35,99,104,101,99,107,45,112,111,105,110,116,101,114,32,120,57,56,32,46,32,108,111,99,57,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,10),40,110,111,115,105,122,101,114,114,41,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,16),40,115,105,122,101,114,114,32,97,114,103,115,50,48,53,41};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,29),40,99,104,101,99,107,110,49,32,110,50,48,54,32,110,109,97,120,50,48,55,32,111,102,102,50,48,56,41,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,47),40,99,104,101,99,107,110,50,32,110,50,48,57,32,110,109,97,120,50,49,48,32,110,109,97,120,50,50,49,49,32,111,102,102,49,50,49,50,32,111,102,102,50,50,49,51,41,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,20),40,109,111,118,101,32,102,114,111,109,50,49,54,32,116,111,50,49,55,41,0,0,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,36),40,98,111,100,121,49,56,57,32,110,49,57,56,32,102,111,102,102,115,101,116,49,57,57,32,116,111,102,102,115,101,116,50,48,48,41,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,40),40,100,101,102,45,116,111,102,102,115,101,116,49,57,51,32,37,110,49,56,54,50,56,54,32,37,102,111,102,102,115,101,116,49,56,55,50,56,55,41};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,25),40,100,101,102,45,102,111,102,102,115,101,116,49,57,50,32,37,110,49,56,54,50,56,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,110,49,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,40),40,109,111,118,101,45,109,101,109,111,114,121,33,32,102,114,111,109,49,56,51,32,116,111,49,56,52,32,46,32,116,109,112,49,56,50,49,56,53,41};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,51,49,48,32,105,51,49,50,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,51,48,48,41,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,99,111,112,121,32,120,50,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,18),40,97,108,108,111,99,97,116,101,32,97,51,49,55,51,50,48,41,0,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,14),40,102,114,101,101,32,97,51,50,50,51,50,54,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,15),40,112,111,105,110,116,101,114,63,32,120,51,50,56,41,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,20),40,112,111,105,110,116,101,114,45,108,105,107,101,63,32,120,51,51,50,41,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,26),40,97,100,100,114,101,115,115,45,62,112,111,105,110,116,101,114,32,97,100,100,114,51,51,55,41,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,25),40,112,111,105,110,116,101,114,45,62,97,100,100,114,101,115,115,32,112,116,114,51,51,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,22),40,110,117,108,108,45,112,111,105,110,116,101,114,63,32,112,116,114,51,52,49,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,62,112,111,105,110,116,101,114,32,120,51,52,51,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,24),40,112,111,105,110,116,101,114,45,62,111,98,106,101,99,116,32,112,116,114,51,53,50,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,23),40,112,111,105,110,116,101,114,61,63,32,112,49,51,53,52,32,112,50,51,53,53,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,26),40,112,111,105,110,116,101,114,43,32,97,51,53,57,51,54,51,32,97,51,53,56,51,54,52,41,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,20),40,97,108,105,103,110,45,116,111,45,119,111,114,100,32,120,51,55,51,41,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,27),40,116,97,103,45,112,111,105,110,116,101,114,32,112,116,114,51,56,49,32,116,97,103,51,56,50,41,0,0,0,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,34),40,116,97,103,103,101,100,45,112,111,105,110,116,101,114,63,32,120,51,57,54,32,46,32,116,109,112,51,57,53,51,57,55,41,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,18),40,112,111,105,110,116,101,114,45,116,97,103,32,120,52,48,54,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,33),40,109,97,107,101,45,108,111,99,97,116,105,118,101,32,111,98,106,52,49,51,32,46,32,105,110,100,101,120,52,49,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,38),40,109,97,107,101,45,119,101,97,107,45,108,111,99,97,116,105,118,101,32,111,98,106,52,49,55,32,46,32,105,110,100,101,120,52,49,56,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,25),40,108,111,99,97,116,105,118,101,45,115,101,116,33,32,120,52,50,49,32,121,52,50,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,23),40,108,111,99,97,116,105,118,101,45,62,111,98,106,101,99,116,32,120,52,50,51,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,16),40,108,111,99,97,116,105,118,101,63,32,120,52,50,52,41};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,117,56,45,115,101,116,33,32,112,52,50,54,32,110,52,50,55,41,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,27),40,112,111,105,110,116,101,114,45,115,56,45,115,101,116,33,32,112,52,50,56,32,110,52,50,57,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,49,54,45,115,101,116,33,32,112,52,51,48,32,110,52,51,49,41,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,49,54,45,115,101,116,33,32,112,52,51,50,32,110,52,51,51,41,0,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,117,51,50,45,115,101,116,33,32,112,52,51,52,32,110,52,51,53,41,0,0,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,115,51,50,45,115,101,116,33,32,112,52,51,54,32,110,52,51,55,41,0,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,51,50,45,115,101,116,33,32,112,52,51,56,32,110,52,51,57,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,28),40,112,111,105,110,116,101,114,45,102,54,52,45,115,101,116,33,32,112,52,52,48,32,110,52,52,49,41,0,0,0,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,12),40,97,49,56,56,48,32,120,52,53,50,41,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,17),40,97,49,56,57,54,32,120,52,53,52,32,105,52,53,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,34),40,101,120,116,101,110,100,45,112,114,111,99,101,100,117,114,101,32,112,114,111,99,52,53,48,32,100,97,116,97,52,53,49,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,12),40,97,49,57,50,51,32,120,52,54,53,41,0,0,0,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,26),40,101,120,116,101,110,100,101,100,45,112,114,111,99,101,100,117,114,101,63,32,120,52,53,56,41,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,12),40,97,49,57,53,54,32,120,52,55,52,41,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,21),40,112,114,111,99,101,100,117,114,101,45,100,97,116,97,32,120,52,54,55,41,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,34),40,115,101,116,45,112,114,111,99,101,100,117,114,101,45,100,97,116,97,33,32,112,114,111,99,52,55,55,32,120,52,55,56,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,115,108,111,116,115,32,120,52,56,48,41,0,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,22),40,110,117,109,98,101,114,45,111,102,45,98,121,116,101,115,32,120,52,56,50,41,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,40),40,109,97,107,101,45,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,32,116,121,112,101,52,56,54,32,46,32,97,114,103,115,52,56,55,41};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,35),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,63,32,120,52,57,53,32,46,32,116,109,112,52,57,52,52,57,54,41,0,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,27),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,116,121,112,101,32,120,53,48,56,41,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,29),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,108,101,110,103,116,104,32,120,53,49,48,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,42),40,114,101,99,111,114,100,45,105,110,115,116,97,110,99,101,45,115,108,111,116,45,115,101,116,33,32,120,53,49,50,32,105,53,49,51,32,121,53,49,52,41,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,11),40,100,111,108,111,111,112,53,50,52,41,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,21),40,114,101,99,111,114,100,45,62,118,101,99,116,111,114,32,120,53,50,49,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,22),40,111,98,106,101,99,116,45,101,118,105,99,116,101,100,63,32,120,53,51,48,41,0,0};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,16),40,102,95,50,50,57,51,32,97,53,51,53,53,51,56,41};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,53,53,49,32,105,53,53,51,41};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,53,52,49,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,34),40,111,98,106,101,99,116,45,101,118,105,99,116,32,120,53,51,49,32,46,32,97,108,108,111,99,97,116,111,114,53,51,50,41,0,0,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,53,56,54,32,105,53,56,56,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,53,55,53,41,0,0,0,0};
static C_char C_TLS li68[] C_aligned={C_lihdr(0,0,49),40,111,98,106,101,99,116,45,101,118,105,99,116,45,116,111,45,108,111,99,97,116,105,111,110,32,120,53,54,52,32,112,116,114,53,54,53,32,46,32,108,105,109,105,116,53,54,54,41,0,0,0,0,0,0,0};
static C_char C_TLS li69[] C_aligned={C_lihdr(0,0,16),40,102,95,50,53,52,54,32,97,54,48,53,54,48,57,41};
static C_char C_TLS li70[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,49,55,32,105,54,49,57,41};
static C_char C_TLS li71[] C_aligned={C_lihdr(0,0,14),40,114,101,108,101,97,115,101,32,120,54,49,50,41,0,0};
static C_char C_TLS li72[] C_aligned={C_lihdr(0,0,35),40,111,98,106,101,99,116,45,114,101,108,101,97,115,101,32,120,54,48,49,32,46,32,114,101,108,101,97,115,101,114,54,48,50,41,0,0,0,0,0};
static C_char C_TLS li73[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,51,52,32,105,54,51,54,41};
static C_char C_TLS li74[] C_aligned={C_lihdr(0,0,12),40,101,118,105,99,116,32,120,54,50,56,41,0,0,0,0};
static C_char C_TLS li75[] C_aligned={C_lihdr(0,0,18),40,111,98,106,101,99,116,45,115,105,122,101,32,120,54,50,53,41,0,0,0,0,0,0};
static C_char C_TLS li76[] C_aligned={C_lihdr(0,0,16),40,100,111,108,111,111,112,54,55,49,32,105,54,55,51,41};
static C_char C_TLS li77[] C_aligned={C_lihdr(0,0,11),40,99,111,112,121,32,120,54,53,56,41,0,0,0,0,0};
static C_char C_TLS li78[] C_aligned={C_lihdr(0,0,33),40,111,98,106,101,99,116,45,117,110,101,118,105,99,116,32,120,54,53,49,32,46,32,116,109,112,54,53,48,54,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li79[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,108,115,116,54,56,41,0,0,0,0};
static C_char C_TLS li80[] C_aligned={C_lihdr(0,0,24),40,111,98,106,101,99,116,45,98,101,99,111,109,101,33,32,97,108,115,116,54,55,57,41};
static C_char C_TLS li81[] C_aligned={C_lihdr(0,0,33),40,109,117,116,97,116,101,45,112,114,111,99,101,100,117,114,101,32,111,108,100,54,56,49,32,112,114,111,99,54,56,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li82[] C_aligned={C_lihdr(0,0,19),40,103,108,111,98,97,108,45,114,101,102,32,115,121,109,54,56,57,41,0,0,0,0,0};
static C_char C_TLS li83[] C_aligned={C_lihdr(0,0,25),40,103,108,111,98,97,108,45,115,101,116,33,32,115,121,109,54,57,49,32,120,54,57,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li84[] C_aligned={C_lihdr(0,0,22),40,103,108,111,98,97,108,45,98,111,117,110,100,63,32,115,121,109,54,57,52,41,0,0};
static C_char C_TLS li85[] C_aligned={C_lihdr(0,0,29),40,103,108,111,98,97,108,45,109,97,107,101,45,117,110,98,111,117,110,100,33,32,115,121,109,54,57,54,41,0,0,0};
static C_char C_TLS li86[] C_aligned={C_lihdr(0,0,17),40,97,50,56,52,53,32,120,53,49,55,32,105,53,49,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li87[] C_aligned={C_lihdr(0,0,12),40,97,50,56,54,57,32,112,52,52,57,41,0,0,0,0};
static C_char C_TLS li88[] C_aligned={C_lihdr(0,0,12),40,97,50,56,55,50,32,112,52,52,56,41,0,0,0,0};
static C_char C_TLS li89[] C_aligned={C_lihdr(0,0,12),40,97,50,56,55,53,32,112,52,52,55,41,0,0,0,0};
static C_char C_TLS li90[] C_aligned={C_lihdr(0,0,12),40,97,50,56,55,56,32,112,52,52,54,41,0,0,0,0};
static C_char C_TLS li91[] C_aligned={C_lihdr(0,0,12),40,97,50,56,56,49,32,112,52,52,53,41,0,0,0,0};
static C_char C_TLS li92[] C_aligned={C_lihdr(0,0,12),40,97,50,56,56,52,32,112,52,52,52,41,0,0,0,0};
static C_char C_TLS li93[] C_aligned={C_lihdr(0,0,12),40,97,50,56,56,55,32,112,52,52,51,41,0,0,0,0};
static C_char C_TLS li94[] C_aligned={C_lihdr(0,0,12),40,97,50,56,57,48,32,112,52,52,50,41,0,0,0,0};
static C_char C_TLS li95[] C_aligned={C_lihdr(0,0,14),67,95,108,111,99,97,116,105,118,101,95,114,101,102,0,0};
static C_char C_TLS li96[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2549 */
static C_word C_fcall stub606(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub606(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k2296 */
static C_word C_fcall stub536(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub536(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1611 */
static C_word C_fcall stub369(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub369(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_num_to_int(C_a0);
C_r=C_int_to_num(&C_a,C_align(t0));
return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub360(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub360(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * ptr=(void * )C_c_pointer_or_null(C_a0);
int off=(int )C_num_to_int(C_a1);
C_return((unsigned char *)ptr + off);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub348(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub348(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word x=(C_word )(C_a0);
C_return((void *)x);
C_ret:
#undef return

return C_r;}

/* from k1516 */
static C_word C_fcall stub323(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub323(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
C_free(t0);
return C_r;}

/* from k1509 */
static C_word C_fcall stub318(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub318(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer_or_false(&C_a,(void*)C_malloc(t0));
return C_r;}

/* from k1048 */
static C_word C_fcall stub164(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub164(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k1020 */
static C_word C_fcall stub148(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub148(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k992 */
static C_word C_fcall stub132(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub132(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

/* from k964 */
static C_word C_fcall stub116(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub116(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_c_pointer_or_null(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
int t4=(int )C_unfix(C_a4);
C_memmove_o(t0,t1,t2,t3,t4);
return C_r;}

C_noret_decl(C_lolevel_toplevel)
C_externexport void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_785)
static void C_ccall f_785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2888)
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2885)
static void C_ccall f_2885(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1846)
static void C_ccall f_1846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1850)
static void C_ccall f_1850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2879)
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1858)
static void C_ccall f_1858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2873)
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2870)
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1866)
static void C_ccall f_1866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2000)
static void C_ccall f_2000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2846)
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2853)
static void C_ccall f_2853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2139)
static void C_ccall f_2139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2833)
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2824)
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2792)
static void C_ccall f_2792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2807)
static void C_ccall f_2807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2795)
static void C_ccall f_2795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2769)
static void C_ccall f_2769(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_815)
static void C_fcall f_815(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_840)
static void C_ccall f_840(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2773)
static void C_ccall f_2773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2640)
static void C_ccall f_2640r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2644)
static void C_ccall f_2644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2647)
static void C_ccall f_2647(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2652)
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2711)
static void C_ccall f_2711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2714)
static void C_ccall f_2714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2723)
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2744)
static void C_ccall f_2744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2717)
static void C_ccall f_2717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2697)
static void C_ccall f_2697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2700)
static void C_ccall f_2700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2681)
static void C_ccall f_2681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2684)
static void C_ccall f_2684(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2556)
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2560)
static void C_ccall f_2560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2565)
static void C_fcall f_2565(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2578)
static void C_ccall f_2578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2635)
static void C_ccall f_2635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_fcall f_2584(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2587)
static void C_ccall f_2587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2597)
static void C_fcall f_2597(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2621)
static void C_ccall f_2621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_ccall f_2590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2464)
static void C_ccall f_2464r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2473)
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2518)
static void C_fcall f_2518(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f3207)
static void C_ccall f3207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2502)
static void C_ccall f_2502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2509)
static void C_ccall f_2509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_2300)
static void C_ccall f_2300r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_2304)
static void C_ccall f_2304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2307)
static void C_fcall f_2307(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2453)
static void C_ccall f_2453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2310)
static void C_ccall f_2310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_ccall f_2313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2321)
static void C_fcall f_2321(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2331)
static void C_ccall f_2331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2446)
static void C_ccall f_2446(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2340)
static void C_fcall f_2340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2438)
static void C_ccall f_2438(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2343)
static void C_ccall f_2343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_fcall f_2346(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2403)
static void C_ccall f_2403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2352)
static void C_ccall f_2352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2362)
static void C_fcall f_2362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2364)
static void C_fcall f_2364(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2385)
static void C_ccall f_2385(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2316)
static void C_ccall f_2316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2182)
static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2189)
static void C_ccall f_2189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2192)
static void C_ccall f_2192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2207)
static void C_ccall f_2207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2220)
static void C_ccall f_2220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_fcall f_2223(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2226)
static void C_ccall f_2226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2236)
static void C_fcall f_2236(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2238)
static void C_fcall f_2238(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2259)
static void C_ccall f_2259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2141)
static void C_ccall f_2141(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2145)
static void C_ccall f_2145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2156)
static C_word C_fcall f_2156(C_word t0,C_word t1);
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2117)
static void C_ccall f_2117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2104)
static void C_ccall f_2104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2095)
static void C_ccall f_2095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2042)
static void C_ccall f_2042r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2057)
static void C_fcall f_2057(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2033)
static void C_ccall f_2033r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_906)
static void C_fcall f_906(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2006)
static void C_ccall f_2006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1982)
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1974)
static void C_ccall f_1974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1907)
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1924)
static void C_ccall f_1924(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1941)
static void C_ccall f_1941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1872)
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1876)
static void C_ccall f_1876(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1897)
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1881)
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1830)
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1827)
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1796)
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1767)
static void C_ccall f_1767r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1738)
static void C_ccall f_1738r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1746)
static void C_ccall f_1746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1715)
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1727)
static void C_fcall f_1727(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1671)
static void C_ccall f_1671r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1651)
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1655)
static void C_ccall f_1655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_fcall f_1666(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1658)
static void C_ccall f_1658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1614)
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1635)
static void C_fcall f_1635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_ccall f_1646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1593)
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1584)
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1591)
static void C_ccall f_1591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1578)
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1567)
static void C_ccall f_1567(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1565)
static void C_ccall f_1565(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1555)
static void C_ccall f_1555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1542)
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1531)
static void C_ccall f_1531(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1523)
static void C_ccall f_1523(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1513)
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1506)
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1425)
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1431)
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1461)
static void C_ccall f_1461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1476)
static void C_fcall f_1476(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1497)
static void C_ccall f_1497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1464)
static void C_ccall f_1464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1062)
static void C_ccall f_1062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1362)
static void C_fcall f_1362(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1357)
static void C_fcall f_1357(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1352)
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1064)
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1122)
static void C_ccall f_1122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1125)
static void C_ccall f_1125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1136)
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1205)
static void C_fcall f_1205(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1270)
static void C_ccall f_1270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1292)
static void C_fcall f_1292(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1319)
static void C_ccall f_1319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1221)
static void C_fcall f_1221(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1237)
static void C_ccall f_1237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1247)
static void C_ccall f_1247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1228)
static void C_ccall f_1228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1095)
static void C_fcall f_1095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_1102)
static void C_fcall f_1102(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1079)
static void C_fcall f_1079(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1073)
static void C_fcall f_1073(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1067)
static void C_fcall f_1067(C_word t0,C_word t1) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_921)
static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_860)
static void C_fcall f_860(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_872)
static void C_fcall f_872(C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_fcall f_787(C_word t0,C_word t1,C_word t2) C_noret;

C_noret_decl(trf_815)
static void C_fcall trf_815(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_815(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_815(t0,t1,t2);}

C_noret_decl(trf_2652)
static void C_fcall trf_2652(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2652(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2652(t0,t1,t2);}

C_noret_decl(trf_2723)
static void C_fcall trf_2723(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2723(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2723(t0,t1,t2);}

C_noret_decl(trf_2565)
static void C_fcall trf_2565(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2565(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2565(t0,t1,t2);}

C_noret_decl(trf_2584)
static void C_fcall trf_2584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2584(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2584(t0,t1);}

C_noret_decl(trf_2597)
static void C_fcall trf_2597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2597(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2597(t0,t1);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2599(t0,t1,t2);}

C_noret_decl(trf_2473)
static void C_fcall trf_2473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2473(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2473(t0,t1,t2);}

C_noret_decl(trf_2518)
static void C_fcall trf_2518(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2518(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2518(t0,t1,t2);}

C_noret_decl(trf_2307)
static void C_fcall trf_2307(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2307(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2307(t0,t1);}

C_noret_decl(trf_2321)
static void C_fcall trf_2321(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2321(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2321(t0,t1,t2);}

C_noret_decl(trf_2340)
static void C_fcall trf_2340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2340(t0,t1);}

C_noret_decl(trf_2346)
static void C_fcall trf_2346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2346(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2346(t0,t1);}

C_noret_decl(trf_2362)
static void C_fcall trf_2362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2362(t0,t1);}

C_noret_decl(trf_2364)
static void C_fcall trf_2364(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2364(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2364(t0,t1,t2);}

C_noret_decl(trf_2197)
static void C_fcall trf_2197(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2197(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2197(t0,t1,t2);}

C_noret_decl(trf_2223)
static void C_fcall trf_2223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2223(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2223(t0,t1);}

C_noret_decl(trf_2236)
static void C_fcall trf_2236(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2236(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2236(t0,t1);}

C_noret_decl(trf_2238)
static void C_fcall trf_2238(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2238(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2238(t0,t1,t2);}

C_noret_decl(trf_2057)
static void C_fcall trf_2057(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2057(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2057(t0,t1);}

C_noret_decl(trf_906)
static void C_fcall trf_906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_906(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_906(t0,t1);}

C_noret_decl(trf_1727)
static void C_fcall trf_1727(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1727(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1727(t0,t1);}

C_noret_decl(trf_1666)
static void C_fcall trf_1666(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1666(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1666(t0,t1);}

C_noret_decl(trf_1635)
static void C_fcall trf_1635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1635(t0,t1);}

C_noret_decl(trf_1431)
static void C_fcall trf_1431(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1431(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1431(t0,t1,t2);}

C_noret_decl(trf_1476)
static void C_fcall trf_1476(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1476(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1476(t0,t1,t2);}

C_noret_decl(trf_1362)
static void C_fcall trf_1362(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1362(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1362(t0,t1);}

C_noret_decl(trf_1357)
static void C_fcall trf_1357(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1357(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1357(t0,t1,t2);}

C_noret_decl(trf_1352)
static void C_fcall trf_1352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1352(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1352(t0,t1,t2,t3);}

C_noret_decl(trf_1064)
static void C_fcall trf_1064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1064(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1064(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1136)
static void C_fcall trf_1136(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1136(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1136(t0,t1,t2,t3);}

C_noret_decl(trf_1205)
static void C_fcall trf_1205(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1205(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1205(t0,t1);}

C_noret_decl(trf_1292)
static void C_fcall trf_1292(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1292(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1292(t0,t1);}

C_noret_decl(trf_1221)
static void C_fcall trf_1221(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1221(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1221(t0,t1);}

C_noret_decl(trf_1095)
static void C_fcall trf_1095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1095(void *dummy){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
f_1095(t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(trf_1102)
static void C_fcall trf_1102(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1102(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1102(t0,t1);}

C_noret_decl(trf_1079)
static void C_fcall trf_1079(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1079(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1079(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1073)
static void C_fcall trf_1073(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1073(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1073(t0,t1,t2);}

C_noret_decl(trf_1067)
static void C_fcall trf_1067(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1067(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1067(t0,t1);}

C_noret_decl(trf_860)
static void C_fcall trf_860(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_860(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_860(t0,t1,t2);}

C_noret_decl(trf_872)
static void C_fcall trf_872(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_872(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_872(t0,t1);}

C_noret_decl(trf_787)
static void C_fcall trf_787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_787(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_787(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_lolevel_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_lolevel_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("lolevel_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1237)){
C_save(t1);
C_rereclaim2(1237*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,141);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],14,"\003syserror-hook");
lf[5]=C_h_intern(&lf[5],15,"\003syssignal-hook");
lf[6]=C_h_intern(&lf[6],11,"\000type-error");
lf[7]=C_decode_literal(C_heaptop,"\376B\000\000#bad argument type - not a structure");
lf[8]=C_h_intern(&lf[8],17,"\003syscheck-pointer");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000!bad argument type - not a pointer");
lf[10]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004mmap\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376\001\000\000\010"
"s8vector\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376\001\000\000\011f64ve"
"ctor\376\377\016");
lf[11]=C_h_intern(&lf[11],12,"move-memory!");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\034need number of bytes to move");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000!number of bytes to move too large");
lf[15]=C_h_intern(&lf[15],15,"\003sysbytevector\077");
lf[16]=C_decode_literal(C_heaptop,"\376B\000\000\033negative destination offset");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\026negative source offset");
lf[18]=C_h_intern(&lf[18],11,"object-copy");
lf[19]=C_h_intern(&lf[19],15,"\003sysmake-vector");
lf[20]=C_h_intern(&lf[20],8,"allocate");
lf[21]=C_h_intern(&lf[21],4,"free");
lf[22]=C_h_intern(&lf[22],8,"pointer\077");
lf[23]=C_h_intern(&lf[23],13,"pointer-like\077");
lf[24]=C_h_intern(&lf[24],16,"address->pointer");
lf[25]=C_h_intern(&lf[25],20,"\003sysaddress->pointer");
lf[26]=C_h_intern(&lf[26],17,"\003syscheck-integer");
lf[27]=C_h_intern(&lf[27],16,"pointer->address");
lf[28]=C_h_intern(&lf[28],20,"\003syspointer->address");
lf[29]=C_h_intern(&lf[29],17,"\003syscheck-special");
lf[30]=C_h_intern(&lf[30],12,"null-pointer");
lf[31]=C_h_intern(&lf[31],16,"\003sysnull-pointer");
lf[32]=C_h_intern(&lf[32],13,"null-pointer\077");
lf[33]=C_h_intern(&lf[33],15,"object->pointer");
lf[34]=C_h_intern(&lf[34],15,"pointer->object");
lf[35]=C_h_intern(&lf[35],9,"pointer=\077");
lf[36]=C_h_intern(&lf[36],8,"pointer+");
lf[37]=C_h_intern(&lf[37],14,"pointer-offset");
lf[38]=C_h_intern(&lf[38],13,"align-to-word");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a pointer or integer");
lf[40]=C_h_intern(&lf[40],11,"tag-pointer");
lf[41]=C_h_intern(&lf[41],23,"\003sysmake-tagged-pointer");
lf[42]=C_h_intern(&lf[42],15,"tagged-pointer\077");
lf[43]=C_h_intern(&lf[43],11,"pointer-tag");
lf[44]=C_h_intern(&lf[44],13,"make-locative");
lf[45]=C_h_intern(&lf[45],17,"\003sysmake-locative");
lf[46]=C_h_intern(&lf[46],18,"make-weak-locative");
lf[47]=C_h_intern(&lf[47],13,"locative-set!");
lf[48]=C_h_intern(&lf[48],12,"locative-ref");
lf[49]=C_h_intern(&lf[49],16,"locative->object");
lf[50]=C_h_intern(&lf[50],9,"locative\077");
lf[51]=C_h_intern(&lf[51],15,"pointer-u8-set!");
lf[52]=C_h_intern(&lf[52],15,"pointer-s8-set!");
lf[53]=C_h_intern(&lf[53],16,"pointer-u16-set!");
lf[54]=C_h_intern(&lf[54],16,"pointer-s16-set!");
lf[55]=C_h_intern(&lf[55],16,"pointer-u32-set!");
lf[56]=C_h_intern(&lf[56],16,"pointer-s32-set!");
lf[57]=C_h_intern(&lf[57],16,"pointer-f32-set!");
lf[58]=C_h_intern(&lf[58],16,"pointer-f64-set!");
lf[59]=C_h_intern(&lf[59],14,"pointer-u8-ref");
lf[60]=C_h_intern(&lf[60],14,"pointer-s8-ref");
lf[61]=C_h_intern(&lf[61],15,"pointer-u16-ref");
lf[62]=C_h_intern(&lf[62],15,"pointer-s16-ref");
lf[63]=C_h_intern(&lf[63],15,"pointer-u32-ref");
lf[64]=C_h_intern(&lf[64],15,"pointer-s32-ref");
lf[65]=C_h_intern(&lf[65],15,"pointer-f32-ref");
lf[66]=C_h_intern(&lf[66],15,"pointer-f64-ref");
lf[67]=C_h_intern(&lf[67],8,"extended");
lf[69]=C_h_intern(&lf[69],16,"extend-procedure");
lf[70]=C_h_intern(&lf[70],19,"\003sysdecorate-lambda");
lf[71]=C_h_intern(&lf[71],17,"\003syscheck-closure");
lf[72]=C_h_intern(&lf[72],19,"extended-procedure\077");
lf[73]=C_h_intern(&lf[73],21,"\003syslambda-decoration");
lf[74]=C_h_intern(&lf[74],14,"procedure-data");
lf[75]=C_h_intern(&lf[75],19,"set-procedure-data!");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000-bad argument type - not an extended procedure");
lf[77]=C_h_intern(&lf[77],10,"block-set!");
lf[78]=C_h_intern(&lf[78],14,"\003sysblock-set!");
lf[79]=C_h_intern(&lf[79],9,"block-ref");
lf[80]=C_h_intern(&lf[80],15,"number-of-slots");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000,bad argument type - not a vector-like object");
lf[82]=C_h_intern(&lf[82],15,"number-of-bytes");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\0002cannot compute number of bytes of immediate object");
lf[84]=C_h_intern(&lf[84],20,"make-record-instance");
lf[85]=C_h_intern(&lf[85],18,"\003sysmake-structure");
lf[86]=C_h_intern(&lf[86],16,"record-instance\077");
lf[87]=C_h_intern(&lf[87],20,"record-instance-type");
lf[88]=C_h_intern(&lf[88],22,"record-instance-length");
lf[89]=C_h_intern(&lf[89],25,"record-instance-slot-set!");
lf[90]=C_h_intern(&lf[90],15,"\003syscheck-range");
lf[91]=C_h_intern(&lf[91],20,"record-instance-slot");
lf[92]=C_h_intern(&lf[92],14,"record->vector");
lf[93]=C_h_intern(&lf[93],15,"object-evicted\077");
lf[94]=C_h_intern(&lf[94],12,"object-evict");
lf[95]=C_h_intern(&lf[95],15,"hash-table-set!");
lf[96]=C_h_intern(&lf[96],19,"\003sysundefined-value");
lf[97]=C_h_intern(&lf[97],22,"hash-table-ref/default");
lf[98]=C_h_intern(&lf[98],15,"make-hash-table");
lf[99]=C_h_intern(&lf[99],3,"eq\077");
lf[100]=C_h_intern(&lf[100],24,"object-evict-to-location");
lf[101]=C_h_intern(&lf[101],24,"\003sysset-pointer-address!");
lf[102]=C_h_intern(&lf[102],6,"signal");
lf[103]=C_h_intern(&lf[103],24,"make-composite-condition");
lf[104]=C_h_intern(&lf[104],23,"make-property-condition");
lf[105]=C_h_intern(&lf[105],5,"evict");
lf[106]=C_h_intern(&lf[106],5,"limit");
lf[107]=C_h_intern(&lf[107],3,"exn");
lf[108]=C_h_intern(&lf[108],8,"location");
lf[109]=C_h_intern(&lf[109],7,"message");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000$cannot evict object - limit exceeded");
lf[111]=C_h_intern(&lf[111],9,"arguments");
lf[112]=C_h_intern(&lf[112],14,"object-release");
lf[113]=C_h_intern(&lf[113],11,"object-size");
lf[114]=C_h_intern(&lf[114],14,"object-unevict");
lf[115]=C_h_intern(&lf[115],15,"\003sysmake-string");
lf[116]=C_h_intern(&lf[116],14,"object-become!");
lf[117]=C_h_intern(&lf[117],11,"\003sysbecome!");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000:bad argument type - not an a-list of non-immediate objects");
lf[119]=C_h_intern(&lf[119],16,"mutate-procedure");
lf[120]=C_h_intern(&lf[120],10,"global-ref");
lf[121]=C_h_intern(&lf[121],11,"global-set!");
lf[122]=C_h_intern(&lf[122],13,"global-bound\077");
lf[123]=C_h_intern(&lf[123],32,"\003syssymbol-has-toplevel-binding\077");
lf[124]=C_h_intern(&lf[124],20,"global-make-unbound!");
lf[125]=C_h_intern(&lf[125],28,"\003sysarbitrary-unbound-symbol");
lf[126]=C_h_intern(&lf[126],18,"getter-with-setter");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\032(record-instance-slot x i)");
lf[128]=C_h_intern(&lf[128],13,"\003sysblock-ref");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\017(block-ref x i)");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-f64-ref p)");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-f32-ref p)");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-s32-ref p)");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-u32-ref p)");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-s16-ref p)");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\023(pointer-u16-ref p)");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\022(pointer-s8-ref p)");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\022(pointer-u8-ref p)");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\022(locative-ref loc)");
lf[139]=C_h_intern(&lf[139],17,"register-feature!");
lf[140]=C_h_intern(&lf[140],7,"lolevel");
C_register_lf2(lf,141,create_ptable());
t2=C_mutate(&lf[0] /* (set! c297 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_srfi_69_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k780 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_785,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:52: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[139]+1)))(3,*((C_word*)lf[139]+1),t2,lf[140]);}

/* k783 in k780 */
static void C_ccall f_785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word ab[76],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_785,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! ##sys#check-block ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_787,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! ##sys#check-generic-structure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_860,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[8]+1 /* (set! ##sys#check-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_921,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t5=lf[10];
t6=C_mutate((C_word*)lf[11]+1 /* (set! move-memory! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1062,a[2]=t5,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));
t7=C_mutate((C_word*)lf[18]+1 /* (set! object-copy ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1425,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[20]+1 /* (set! allocate ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1506,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[21]+1 /* (set! free ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1513,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[22]+1 /* (set! pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1523,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[23]+1 /* (set! pointer-like? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1531,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[24]+1 /* (set! address->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1542,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[27]+1 /* (set! pointer->address ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1551,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[30]+1 /* (set! null-pointer ...) */,*((C_word*)lf[31]+1));
t15=C_mutate((C_word*)lf[32]+1 /* (set! null-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1561,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[33]+1 /* (set! object->pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1567,a[2]=((C_word)li23),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[34]+1 /* (set! pointer->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1578,a[2]=((C_word)li24),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[35]+1 /* (set! pointer=? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1584,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[36]+1 /* (set! pointer+ ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1593,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[37]+1 /* (set! pointer-offset ...) */,*((C_word*)lf[36]+1));
t21=C_mutate((C_word*)lf[38]+1 /* (set! align-to-word ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1614,a[2]=((C_word)li27),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[40]+1 /* (set! tag-pointer ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1651,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[42]+1 /* (set! tagged-pointer? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1671,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[43]+1 /* (set! pointer-tag ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1715,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[44]+1 /* (set! make-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1738,a[2]=((C_word)li31),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[46]+1 /* (set! make-weak-locative ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1767,a[2]=((C_word)li32),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[47]+1 /* (set! locative-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1796,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t28=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t29=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)C_locative_ref,a[2]=((C_word)li95),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:311: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t28,t29,*((C_word*)lf[47]+1),lf[138]);}

/* k1799 in k783 in k780 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[36],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1801,2,t0,t1);}
t2=C_mutate((C_word*)lf[48]+1 /* (set! locative-ref ...) */,t1);
t3=C_mutate((C_word*)lf[49]+1 /* (set! locative->object ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1803,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[50]+1 /* (set! locative? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1806,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[51]+1 /* (set! pointer-u8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1812,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[52]+1 /* (set! pointer-s8-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1815,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[53]+1 /* (set! pointer-u16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1818,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[54]+1 /* (set! pointer-s16-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1821,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[55]+1 /* (set! pointer-u32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1824,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[56]+1 /* (set! pointer-s32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1827,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[57]+1 /* (set! pointer-f32-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1830,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[58]+1 /* (set! pointer-f64-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1833,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1838,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2891,a[2]=((C_word)li94),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:332: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t13,t14,*((C_word*)lf[51]+1),lf[137]);}

/* a2890 in k1799 in k783 in k780 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2891,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_u8_ref(t2));}

/* k1836 in k1799 in k783 in k780 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=C_mutate((C_word*)lf[59]+1 /* (set! pointer-u8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1842,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2888,a[2]=((C_word)li93),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:338: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[52]+1),lf[136]);}

/* a2887 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2888(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2888,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_s8_ref(t2));}

/* k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=C_mutate((C_word*)lf[60]+1 /* (set! pointer-s8-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1846,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2885,a[2]=((C_word)li92),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:344: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[53]+1),lf[135]);}

/* a2884 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2885(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2885,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_u16_ref(t2));}

/* k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1846,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! pointer-u16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1850,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2882,a[2]=((C_word)li91),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:350: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[54]+1),lf[134]);}

/* a2881 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2882,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_pointer_s16_ref(t2));}

/* k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1850,2,t0,t1);}
t2=C_mutate((C_word*)lf[62]+1 /* (set! pointer-s16-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2879,a[2]=((C_word)li90),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:356: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[55]+1),lf[133]);}

/* a2878 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2879,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_u32_ref(&a,1,t2));}

/* k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1854,2,t0,t1);}
t2=C_mutate((C_word*)lf[63]+1 /* (set! pointer-u32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1858,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2876,a[2]=((C_word)li89),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:362: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[56]+1),lf[132]);}

/* a2875 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_s32_ref(&a,1,t2));}

/* k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1858,2,t0,t1);}
t2=C_mutate((C_word*)lf[64]+1 /* (set! pointer-s32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2873,a[2]=((C_word)li88),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:368: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[57]+1),lf[131]);}

/* a2872 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2873,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_f32_ref(&a,1,t2));}

/* k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=C_mutate((C_word*)lf[65]+1 /* (set! pointer-f32-ref ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1866,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2870,a[2]=((C_word)li87),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:374: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t3,t4,*((C_word*)lf[58]+1),lf[130]);}

/* a2869 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2870(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2870,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_u_i_pointer_f64_ref(&a,1,t2));}

/* k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1866,2,t0,t1);}
t2=C_mutate((C_word*)lf[66]+1 /* (set! pointer-f64-ref ...) */,t1);
t3=C_a_i_vector(&a,1,lf[67]);
t4=C_mutate(&lf[68] /* (set! xproc-tag ...) */,t3);
t5=C_mutate((C_word*)lf[69]+1 /* (set! extend-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1872,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[72]+1 /* (set! extended-procedure? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1907,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[74]+1 /* (set! procedure-data ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1943,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t8=*((C_word*)lf[69]+1);
t9=C_mutate((C_word*)lf[75]+1 /* (set! set-procedure-data! ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1982,a[2]=t8,a[3]=((C_word)li51),tmp=(C_word)a,a+=4,tmp));
t10=C_mutate((C_word*)lf[77]+1 /* (set! block-set! ...) */,*((C_word*)lf[78]+1));
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2000,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:421: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t11,*((C_word*)lf[128]+1),*((C_word*)lf[78]+1),lf[129]);}

/* k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[27],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2000,2,t0,t1);}
t2=C_mutate((C_word*)lf[79]+1 /* (set! block-ref ...) */,t1);
t3=C_mutate((C_word*)lf[80]+1 /* (set! number-of-slots ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2002,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[82]+1 /* (set! number-of-bytes ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[84]+1 /* (set! make-record-instance ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2033,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[86]+1 /* (set! record-instance? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2042,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[87]+1 /* (set! record-instance-type ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2091,a[2]=((C_word)li56),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[88]+1 /* (set! record-instance-length ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2100,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[89]+1 /* (set! record-instance-slot-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2113,a[2]=((C_word)li58),tmp=(C_word)a,a+=3,tmp));
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2139,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2846,a[2]=((C_word)li86),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:469: getter-with-setter */
((C_proc5)C_retrieve_proc(*((C_word*)lf[126]+1)))(5,*((C_word*)lf[126]+1),t10,t11,*((C_word*)lf[89]+1),lf[127]);}

/* a2845 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2846(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2846,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2850,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:471: ##sys#check-generic-structure */
f_860(t4,t2,C_a_i_list(&a,1,lf[91]));}

/* k2848 in a2845 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[2]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm:472: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[90]+1)))(6,*((C_word*)lf[90]+1),t2,((C_word*)t0)[4],C_fix(0),t4,lf[91]);}

/* k2851 in k2848 in a2845 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_slot(((C_word*)t0)[2],t2));}

/* k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[39],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2139,2,t0,t1);}
t2=C_mutate((C_word*)lf[91]+1 /* (set! record-instance-slot ...) */,t1);
t3=C_mutate((C_word*)lf[92]+1 /* (set! record->vector ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2141,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[93]+1 /* (set! object-evicted? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2179,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[94]+1 /* (set! object-evict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2182,a[2]=((C_word)li65),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[100]+1 /* (set! object-evict-to-location ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2300,a[2]=((C_word)li68),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[112]+1 /* (set! object-release ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2464,a[2]=((C_word)li72),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[113]+1 /* (set! object-size ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2556,a[2]=((C_word)li75),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[114]+1 /* (set! object-unevict ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2640,a[2]=((C_word)li78),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[116]+1 /* (set! object-become! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2769,a[2]=((C_word)li80),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[119]+1 /* (set! mutate-procedure ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2778,a[2]=((C_word)li81),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[120]+1 /* (set! global-ref ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2809,a[2]=((C_word)li82),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[121]+1 /* (set! global-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2815,a[2]=((C_word)li83),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[122]+1 /* (set! global-bound? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2824,a[2]=((C_word)li84),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[124]+1 /* (set! global-make-unbound! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2833,a[2]=((C_word)li85),tmp=(C_word)a,a+=3,tmp));
t16=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_SCHEME_UNDEFINED);}

/* global-make-unbound! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2833(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2833,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[124]);
t4=C_slot(lf[125],C_fix(0));
t5=C_i_setslot(t2,C_fix(0),t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* global-bound? in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2824(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2824,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[122]);
/* lolevel.scm:641: ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[123]+1)))(3,*((C_word*)lf[123]+1),t1,t2);}

/* global-set! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2815,4,t0,t1,t2,t3);}
t4=C_i_check_symbol_2(t2,lf[121]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(0),t3));}

/* global-ref in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2809,3,t0,t1,t2);}
t3=C_i_check_symbol_2(t2,lf[120]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_retrieve(t2));}

/* mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2778,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2782,a[2]=t3,a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:620: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t4,t2,lf[119]);}

/* k2780 in mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2785,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:621: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t2,((C_word*)t0)[2],lf[119]);}

/* k2783 in k2780 in mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[4]);
t3=C_words(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2792,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:624: ##sys#make-vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t4,t3);}

/* k2790 in k2783 in k2780 in mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2792,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2795,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2807,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:625: proc */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t2);}

/* k2805 in k2790 in k2783 in k2780 in mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2807,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=C_a_i_list(&a,1,t2);
/* lolevel.scm:625: ##sys#become! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[117]+1)))(3,*((C_word*)lf[117]+1),((C_word*)t0)[2],t3);}

/* k2793 in k2790 in k2783 in k2780 in mutate-procedure in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-become! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2769(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2769,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2773,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_i_check_list_2(t4,lf[116]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_815,a[2]=t4,a[3]=t7,a[4]=((C_word)li79),tmp=(C_word)a,a+=5,tmp));
t9=((C_word*)t7)[1];
f_815(t9,t3,t4);}

/* loop in object-become! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_815(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_815,NULL,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=C_i_check_pair_2(t4,lf[116]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_837,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t4);
/* lolevel.scm:93: ##sys#check-block */
f_787(t6,t7,C_a_i_list(&a,1,lf[116]));}
else{
/* lolevel.scm:97: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),t1,lf[6],lf[116],lf[118],((C_word*)t0)[2]);}}}

/* k835 in loop in object-become! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_840,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* lolevel.scm:94: ##sys#check-block */
f_787(t2,t3,C_a_i_list(&a,1,lf[116]));}

/* k838 in k835 in loop in object-become! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_840(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* lolevel.scm:95: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_815(t3,((C_word*)t0)[2],t2);}

/* k2771 in object-become! in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:617: ##sys#become! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[117]+1)))(3,*((C_word*)lf[117]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2640(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2640r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2640r(t0,t1,t2,t3);}}

static void C_ccall f_2640r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2644(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2644(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2644,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2647,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:588: make-hash-table */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t2,*((C_word*)lf[99]+1));}

/* k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2647(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2647,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2652,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li77),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2652(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2652(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2652,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:592: hash-table-ref/default */
((C_proc5)C_retrieve_proc(*((C_word*)lf[97]+1)))(5,*((C_word*)lf[97]+1),t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2668,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_byteblockp(((C_word*)t0)[5]))){
if(C_truep(((C_word*)t0)[4])){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[5]);
/* lolevel.scm:595: ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[115]+1)))(3,*((C_word*)lf[115]+1),t2,t3);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[5]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2697,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
/* lolevel.scm:600: ##sys#intern-symbol */
C_string_to_symbol(3,0,t2,t3);}
else{
t2=C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2711,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:605: ##sys#make-vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,t2);}}}}

/* k2709 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2711,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2714,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:606: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t3,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* k2712 in k2709 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2717,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(C_truep(C_specialp(((C_word*)t0)[4]))?C_fix(1):C_fix(0));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2723,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[3],a[6]=((C_word)li76),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_2723(t7,t2,t3);}

/* doloop671 in k2712 in k2709 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2723(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2723,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2744,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm:609: copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2652(t5,t3,t4);}}

/* k2742 in doloop671 in k2712 in k2709 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2723(t4,((C_word*)t0)[2],t3);}

/* k2715 in k2712 in k2709 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2695 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2700,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:601: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2698 in k2695 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2679 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2681,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[4],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2684,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:596: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t3,((C_word*)t0)[2],((C_word*)t0)[4],t2);}

/* k2682 in k2679 in k2666 in copy in k2645 in k2642 in object-unevict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2684(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2556(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2556,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2560,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:571: make-hash-table */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t3,*((C_word*)lf[99]+1));}

/* k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2560,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2565,a[2]=t1,a[3]=t3,a[4]=((C_word)li74),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2565(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2565(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2565,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:574: hash-table-ref/default */
((C_proc5)C_retrieve_proc(*((C_word*)lf[97]+1)))(5,*((C_word*)lf[97]+1),t3,((C_word*)t0)[2],t2,C_SCHEME_FALSE);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fix(0));}}

/* k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2578,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2584,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2635,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
/* lolevel.scm:578: align-to-word */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=C_bytes(t2);
t6=t3;
f_2584(t6,C_fixnum_plus(t5,C_bytes(C_fix(1))));}}}

/* k2633 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2584(t2,C_fixnum_plus(t1,C_bytes(C_fix(1))));}

/* k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2584(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2584,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2587,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:580: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t4,((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_TRUE);}

/* k2585 in k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)((C_word*)t0)[5])[1]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2597,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2597(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2597(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2595 in k2585 in k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2597(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2597,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li73),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2599(t5,((C_word*)t0)[2],t1);}

/* doloop634 in k2595 in k2585 in k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2599,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2621,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:584: evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2565(t5,t3,t4);}}

/* k2619 in doloop634 in k2595 in k2585 in k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_fixnum_plus(t1,((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2599(t5,((C_word*)t0)[2],t4);}

/* k2588 in k2585 in k2582 in k2576 in evict in k2558 in object-size in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2464(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+13)){
C_save_and_reclaim((void*)tr3r,(void*)f_2464r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2464r(t0,t1,t2,t3);}}

static void C_ccall f_2464r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(13);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_car(t3):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word)li69),tmp=(C_word)a,a+=3,tmp));
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2473,a[2]=t9,a[3]=t5,a[4]=t7,a[5]=((C_word)li71),tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2473(t11,t1,t2);}

/* release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2473(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2473,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_permanentp(t2))){
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[4])[1]))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_block_size(t2);
t4=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[4])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[4])+1,t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2502,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_byteblockp(t2))){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f3207,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:568: ##sys#address->pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t7,C_block_address(&a,1,t2));}
else{
t7=(C_truep(C_specialp(t2))?C_fix(1):C_fix(0));
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t9,a[5]=t3,a[6]=((C_word)li70),tmp=(C_word)a,a+=7,tmp));
t11=((C_word*)t9)[1];
f_2518(t11,t6,t7);}}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* doloop617 in release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2518(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2518,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2528,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:567: release */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2473(t5,t3,t4);}}

/* k2526 in doloop617 in release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2518(t3,((C_word*)t0)[2],t2);}

/* f3207 in release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f3207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:568: free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2500 in release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2502,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2509,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:568: ##sys#address->pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),t2,C_block_address(&a,1,((C_word*)t0)[2]));}

/* k2507 in k2500 in release in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:568: free */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* f_2546 in object-release in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2546,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub606(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub606(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2300(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_2300r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_2300r(t0,t1,t2,t3,t4);}}

static void C_ccall f_2300r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2304,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:515: ##sys#check-special */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t5,t3,lf[100]);}

/* k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_check_exact_2(t3,lf[100]);
t5=t2;
f_2307(t5,t3);}
else{
t3=t2;
f_2307(t3,C_SCHEME_FALSE);}}

/* k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2307(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2307,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2310,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2453,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:520: ##sys#pointer->address */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t5,((C_word*)t0)[2]);}

/* k2451 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:520: ##sys#address->pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t1);}

/* k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:521: make-hash-table */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t2,*((C_word*)lf[99]+1));}

/* k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2316,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2321,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=((C_word)li67),tmp=(C_word)a,a+=7,tmp));
t6=((C_word*)t4)[1];
f_2321(t6,t2,((C_word*)t0)[2]);}

/* evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2321(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2321,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2331,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* lolevel.scm:525: hash-table-ref/default */
((C_proc5)C_retrieve_proc(*((C_word*)lf[97]+1)))(5,*((C_word*)lf[97]+1),t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2331,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2340,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2446,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[6]))){
/* lolevel.scm:529: align-to-word */
t5=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t5=C_bytes(t2);
t6=t3;
f_2340(t6,C_fixnum_plus(t5,C_bytes(C_fix(1))));}}}

/* k2444 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2446(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2340(t2,C_fixnum_plus(t1,C_bytes(C_fix(1))));}

/* k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2340,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2343,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=C_fixnum_difference(((C_word*)((C_word*)t0)[2])[1],t1);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[2])[1],C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2430,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2434,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_a_i_list(&a,2,((C_word*)t0)[8],((C_word*)((C_word*)t0)[2])[1]);
/* lolevel.scm:536: make-property-condition */
((C_proc9)C_retrieve_proc(*((C_word*)lf[104]+1)))(9,*((C_word*)lf[104]+1),t6,lf[107],lf[108],lf[100],lf[109],lf[110],lf[111],t7);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t2;
f_2343(2,t6,t5);}}
else{
t3=t2;
f_2343(2,t3,C_SCHEME_UNDEFINED);}}

/* k2432 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2438,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:540: make-property-condition */
((C_proc5)C_retrieve_proc(*((C_word*)lf[104]+1)))(5,*((C_word*)lf[104]+1),t2,lf[105],lf[106],((C_word*)((C_word*)t0)[2])[1]);}

/* k2436 in k2432 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2438(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:535: make-composite-condition */
((C_proc4)C_retrieve_proc(*((C_word*)lf[103]+1)))(4,*((C_word*)lf[103]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2428 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:534: signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[102]+1)))(3,*((C_word*)lf[102]+1),((C_word*)t0)[2],t1);}

/* k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2343,2,t0,t1);}
t2=C_evict_block(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2346,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[8],a[8]=t2,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[8]))){
t4=*((C_word*)lf[96]+1);
t5=t3;
f_2346(t5,C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2346(t4,C_SCHEME_UNDEFINED);}}

/* k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2346(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2346,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2403,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:543: ##sys#pointer->address */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t3,((C_word*)t0)[2]);}

/* k2401 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2403,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[4]);
/* lolevel.scm:543: ##sys#set-pointer-address! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[101]+1)))(4,*((C_word*)lf[101]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:544: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2350 in k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2352,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2362,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2362(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2362(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2360 in k2350 in k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2362,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2364,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li66),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2364(t5,((C_word*)t0)[2],t1);}

/* doloop586 in k2360 in k2350 in k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2364(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2364,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2385,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:548: evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2321(t5,t3,t4);}}

/* k2383 in doloop586 in k2360 in k2350 in k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2385(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2364(t4,((C_word*)t0)[2],t3);}

/* k2353 in k2350 in k2347 in k2344 in k2341 in k2338 in k2329 in evict in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k2314 in k2311 in k2308 in k2305 in k2302 in object-evict-to-location in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:550: values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2182(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_2182r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2182r(t0,t1,t2,t3);}}

static void C_ccall f_2182r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(8);
t4=C_i_pairp(t3);
t5=(C_truep(t4)?C_i_car(t3):(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=((C_word)li62),tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2189,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:496: make-hash-table */
((C_proc3)C_retrieve_proc(*((C_word*)lf[98]+1)))(3,*((C_word*)lf[98]+1),t6,*((C_word*)lf[99]+1));}

/* k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2192,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:497: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t2,((C_word*)t0)[4],lf[94]);}

/* k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2192,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2197,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word)li64),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_2197(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2197(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2197,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2207,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:500: hash-table-ref/default */
((C_proc5)C_retrieve_proc(*((C_word*)lf[97]+1)))(5,*((C_word*)lf[97]+1),t3,((C_word*)t0)[3],t2,C_SCHEME_FALSE);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2207,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_block_size(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[5]))){
/* lolevel.scm:503: align-to-word */
t4=*((C_word*)lf[38]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t4=t3;
f_2216(2,t4,C_bytes(t2));}}}

/* k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2216,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2220,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_fixnum_plus(t1,C_bytes(C_fix(1)));
/* lolevel.scm:504: allocator */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t2,t3);}

/* k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2220,2,t0,t1);}
t2=C_evict_block(((C_word*)t0)[6],t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[6]))){
t4=*((C_word*)lf[96]+1);
t5=t3;
f_2223(t5,C_i_set_i_slot(t2,C_fix(0),t4));}
else{
t4=t3;
f_2223(t4,C_SCHEME_UNDEFINED);}}

/* k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2223(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2223,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2226,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* lolevel.scm:506: hash-table-set! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[95]+1)))(5,*((C_word*)lf[95]+1),t2,((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[6]);}

/* k2224 in k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2229,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_byteblockp(((C_word*)t0)[4]))){
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[5]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2236,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_specialp(((C_word*)t0)[4]);
if(C_truep(t4)){
t5=t3;
f_2236(t5,(C_truep(t4)?C_fix(1):C_fix(0)));}
else{
t5=C_i_symbolp(((C_word*)t0)[4]);
t6=t3;
f_2236(t6,(C_truep(t5)?C_fix(1):C_fix(0)));}}}

/* k2234 in k2224 in k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2236(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2236,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word)li63),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_2238(t5,((C_word*)t0)[2],t1);}

/* doloop551 in k2234 in k2224 in k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2238(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2238,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2259,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[3],t2);
/* lolevel.scm:511: evict */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2197(t5,t3,t4);}}

/* k2257 in doloop551 in k2234 in k2224 in k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_set_i_slot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2238(t4,((C_word*)t0)[2],t3);}

/* k2227 in k2224 in k2221 in k2218 in k2214 in k2205 in evict in k2190 in k2187 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* f_2293 in object-evict in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2293,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub536(t3,t4));}

/* object-evicted? in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2179,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_permanentp(t2));}

/* record->vector in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2141(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2141,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2145,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:478: ##sys#check-generic-structure */
f_860(t3,t2,C_a_i_list(&a,1,lf[92]));}

/* k2143 in record->vector in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2145,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:480: ##sys#make-vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t3,t2);}

/* k2149 in k2143 in record->vector in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2156,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li59),tmp=(C_word)a,a+=6,tmp);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,f_2156(t2,C_fix(0)));}

/* doloop524 in k2149 in k2143 in record->vector in k2137 in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static C_word C_fcall f_2156(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[4]))){
t2=((C_word*)t0)[3];
return(t2);}
else{
t2=C_slot(((C_word*)t0)[2],t1);
t3=C_i_setslot(((C_word*)t0)[3],t1,t2);
t4=C_fixnum_plus(t1,C_fix(1));
t7=t4;
t1=t7;
goto loop;}}

/* record-instance-slot-set! in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_2113,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2117,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:464: ##sys#check-generic-structure */
f_860(t5,t2,C_a_i_list(&a,1,lf[89]));}

/* k2115 in record-instance-slot-set! in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_block_size(((C_word*)t0)[3]);
t4=C_fixnum_difference(t3,C_fix(1));
/* lolevel.scm:465: ##sys#check-range */
((C_proc6)C_retrieve_proc(*((C_word*)lf[90]+1)))(6,*((C_word*)lf[90]+1),t2,((C_word*)t0)[5],C_fix(0),t4,lf[89]);}

/* k2118 in k2115 in record-instance-slot-set! in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(((C_word*)t0)[3],t2,((C_word*)t0)[2]));}

/* record-instance-length in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2100,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2104,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:460: ##sys#check-generic-structure */
f_860(t3,t2,C_a_i_list(&a,1,lf[88]));}

/* k2102 in record-instance-length in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_fixnum_difference(t2,C_fix(1)));}

/* record-instance-type in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2091,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2095,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:456: ##sys#check-generic-structure */
f_860(t3,t2,C_a_i_list(&a,1,lf[87]));}

/* k2093 in record-instance-type in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(((C_word*)t0)[2],C_fix(0)));}

/* record-instance? in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2042(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_2042r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2042r(t0,t1,t2,t3);}}

static void C_ccall f_2042r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2046,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2046(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2046(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2044 in record-instance? in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2046,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2057,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
if(C_truep(C_blockp(t3))){
t4=C_structurep(t3);
t5=t2;
f_2057(t5,t4);}
else{
t4=t2;
f_2057(t4,C_SCHEME_FALSE);}}

/* k2055 in k2044 in record-instance? in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_2057(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_slot(((C_word*)t0)[2],C_fix(0));
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(((C_word*)t0)[4],t3));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* make-record-instance in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2033(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_2033r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2033r(t0,t1,t2,t3);}}

static void C_ccall f_2033r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
t4=C_i_check_symbol_2(t2,lf[84]);
C_apply(5,0,t1,*((C_word*)lf[85]+1),t2,t3);}

/* number-of-bytes in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2011,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_byteblockp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_block_size(t2));}
else{
t3=C_block_size(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_w2b(t3));}}
else{
/* lolevel.scm:430: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),t1,lf[6],lf[82],lf[83],t2);}}

/* number-of-slots in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2002,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2006,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
t5=C_a_i_list(&a,1,lf[80]);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_906,a[2]=t4,a[3]=t3,a[4]=t5,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_blockp(t4))){
t7=C_specialp(t4);
if(C_truep(t7)){
t8=t6;
f_906(t8,C_i_not(t7));}
else{
t8=C_byteblockp(t4);
t9=t6;
f_906(t9,C_i_not(t8));}}
else{
t7=t6;
f_906(t7,C_SCHEME_FALSE);}}

/* k904 in number-of-slots in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_fcall f_906(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_block_size(((C_word*)t0)[5]));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=C_i_car(((C_word*)t0)[4]);
/* lolevel.scm:111: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[6],t2,lf[81],((C_word*)t0)[2]);}
else{
/* lolevel.scm:111: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[6],C_SCHEME_FALSE,lf[81],((C_word*)t0)[2]);}}}

/* k2004 in number-of-slots in k1998 in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_2006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_block_size(((C_word*)t0)[2]));}

/* set-procedure-data! in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1982(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1982,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1986,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:408: extend-procedure */
t5=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,t2,t3);}

/* k1984 in set-procedure-data! in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* lolevel.scm:411: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[2],lf[6],lf[75],lf[76],((C_word*)t0)[3]);}}

/* procedure-data in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1943,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1974,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1957,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:393: ##sys#lambda-decoration */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1956 in procedure-data in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1957,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1972 in procedure-data in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_slot(t1,C_fix(1)):C_SCHEME_FALSE));}

/* extended-procedure? in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1907(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1907,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_closurep(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1941,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1924,a[2]=((C_word)li47),tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:393: ##sys#lambda-decoration */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t3,t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* a1923 in extended-procedure? in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1924(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1924,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1939 in extended-procedure? in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?C_SCHEME_TRUE:C_SCHEME_FALSE));}

/* extend-procedure in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1872,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1876,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:386: ##sys#check-closure */
((C_proc4)C_retrieve_proc(*((C_word*)lf[71]+1)))(4,*((C_word*)lf[71]+1),t4,t2,lf[69]);}

/* k1874 in extend-procedure in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1876(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1876,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1881,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1897,a[2]=((C_word*)t0)[4],a[3]=((C_word)li45),tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:387: ##sys#decorate-lambda */
((C_proc5)C_retrieve_proc(*((C_word*)lf[70]+1)))(5,*((C_word*)lf[70]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,t3);}

/* a1896 in k1874 in extend-procedure in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1897,4,t0,t1,t2,t3);}
t4=C_a_i_cons(&a,2,lf[68],((C_word*)t0)[2]);
t5=C_i_setslot(t2,t3,t4);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}

/* a1880 in k1874 in extend-procedure in k1864 in k1860 in k1856 in k1852 in k1848 in k1844 in k1840 in k1836 in k1799 in k783 in k780 */
static void C_ccall f_1881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1881,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_eqp(lf[68],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer-f64-set! in k1799 in k783 in k780 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1833,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_f64_set(t2,t3));}

/* pointer-f32-set! in k1799 in k783 in k780 */
static void C_ccall f_1830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1830,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_f32_set(t2,t3));}

/* pointer-s32-set! in k1799 in k783 in k780 */
static void C_ccall f_1827(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1827,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s32_set(t2,t3));}

/* pointer-u32-set! in k1799 in k783 in k780 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1824,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u32_set(t2,t3));}

/* pointer-s16-set! in k1799 in k783 in k780 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1821,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s16_set(t2,t3));}

/* pointer-u16-set! in k1799 in k783 in k780 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1818,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u16_set(t2,t3));}

/* pointer-s8-set! in k1799 in k783 in k780 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1815,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_s8_set(t2,t3));}

/* pointer-u8-set! in k1799 in k783 in k780 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1812,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_u_i_pointer_u8_set(t2,t3));}

/* locative? in k1799 in k783 in k780 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1806,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=C_locativep(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* locative->object in k1799 in k783 in k780 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1803,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_locative_to_object(t2));}

/* locative-set! in k783 in k780 */
static void C_ccall f_1796(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1796,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_locative_set(t2,t3));}

/* make-weak-locative in k783 in k780 */
static void C_ccall f_1767(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1767r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1767r(t0,t1,t2,t3);}}

static void C_ccall f_1767r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1775,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm:306: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),t1,t2,C_fix(0),C_SCHEME_TRUE,lf[46]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* lolevel.scm:306: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),t1,t2,t6,C_SCHEME_TRUE,lf[46]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1773 in make-weak-locative in k783 in k780 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:306: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_TRUE,lf[46]);}

/* make-locative in k783 in k780 */
static void C_ccall f_1738(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1738r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1738r(t0,t1,t2,t3);}}

static void C_ccall f_1738r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1746,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* lolevel.scm:303: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),t1,t2,C_fix(0),C_SCHEME_FALSE,lf[44]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* lolevel.scm:303: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),t1,t2,t6,C_SCHEME_FALSE,lf[44]);}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1744 in make-locative in k783 in k780 */
static void C_ccall f_1746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:303: ##sys#make-locative */
((C_proc6)C_retrieve_proc(*((C_word*)lf[45]+1)))(6,*((C_word*)lf[45]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE,lf[44]);}

/* pointer-tag in k783 in k780 */
static void C_ccall f_1715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1715,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1727,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1727(t6,t5);}
else{
t5=t3;
f_1727(t5,C_SCHEME_FALSE);}}

/* k1725 in pointer-tag in k783 in k780 */
static void C_fcall f_1727(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(C_taggedpointerp(((C_word*)t0)[2]))?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE));}
else{
/* lolevel.scm:280: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),((C_word*)t0)[3],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[43],((C_word*)t0)[2]);}}

/* tagged-pointer? in k783 in k780 */
static void C_ccall f_1671(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1671r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1671r(t0,t1,t2,t3);}}

static void C_ccall f_1671r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1675(2,t5,C_SCHEME_FALSE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1675(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k1673 in tagged-pointer? in k783 in k780 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_blockp(((C_word*)t0)[3]))){
if(C_truep(C_taggedpointerp(((C_word*)t0)[3]))){
t2=C_i_not(t1);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_slot(((C_word*)t0)[3],C_fix(1));
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_equalp(t1,t3));}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* tag-pointer in k783 in k780 */
static void C_ccall f_1651(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1651,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1655,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:265: ##sys#make-tagged-pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[41]+1)))(3,*((C_word*)lf[41]+1),t4,t3);}

/* k1653 in tag-pointer in k783 in k780 */
static void C_ccall f_1655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1658,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1666,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=((C_word*)t0)[2];
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1666(t6,t5);}
else{
t5=t3;
f_1666(t5,C_SCHEME_FALSE);}}

/* k1664 in k1653 in tag-pointer in k783 in k780 */
static void C_fcall f_1666(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_copy_pointer(((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
/* lolevel.scm:268: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),((C_word*)t0)[2],C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),lf[40],((C_word*)t0)[5]);}}

/* k1656 in k1653 in tag-pointer in k783 in k780 */
static void C_ccall f_1658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* align-to-word in k783 in k780 */
static void C_ccall f_1614(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1614,3,t0,t1,t2);}
if(C_truep(C_i_integerp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(4));
t6=C_i_foreign_integer_argumentp(t4);
t7=t3;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub369(t5,t6));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1635,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=t2;
if(C_truep(C_blockp(t4))){
t5=C_specialp(t4);
t6=t3;
f_1635(t6,t5);}
else{
t5=t3;
f_1635(t5,C_SCHEME_FALSE);}}}

/* k1633 in align-to-word in k783 in k780 */
static void C_fcall f_1635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1635,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* lolevel.scm:255: ##sys#pointer->address */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),t2,((C_word*)t0)[2]);}
else{
/* lolevel.scm:257: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[3],lf[6],lf[38],lf[39],((C_word*)t0)[2]);}}

/* k1644 in k1633 in align-to-word in k783 in k780 */
static void C_ccall f_1646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1646,2,t0,t1);}
t2=C_a_i_bytevector(&a,1,C_fix(4));
t3=C_i_foreign_integer_argumentp(t1);
t4=stub369(t2,t3);
/* lolevel.scm:255: ##sys#address->pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[2],t4);}

/* pointer+ in k783 in k780 */
static void C_ccall f_1593(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1593,4,t0,t1,t2,t3);}
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=(C_truep(t2)?C_i_foreign_pointer_argumentp(t2):C_SCHEME_FALSE);
t6=C_i_foreign_integer_argumentp(t3);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub360(t4,t5,t6));}

/* pointer=? in k783 in k780 */
static void C_ccall f_1584(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1584,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1588,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:239: ##sys#check-special */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t4,t2,lf[35]);}

/* k1586 in pointer=? in k783 in k780 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1588,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1591,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* lolevel.scm:240: ##sys#check-special */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t2,((C_word*)t0)[2],lf[35]);}

/* k1589 in k1586 in pointer=? in k783 in k780 */
static void C_ccall f_1591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_pointer_eqp(((C_word*)t0)[3],((C_word*)t0)[2]));}

/* pointer->object in k783 in k780 */
static void C_ccall f_1578(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1578,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1582,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:235: ##sys#check-pointer */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[34]);}

/* k1580 in pointer->object in k783 in k780 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_pointer_to_object(((C_word*)t0)[2]));}

/* object->pointer in k783 in k780 */
static void C_ccall f_1567(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1567,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_bytevector(&a,1,C_fix(3));
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub348(t5,t4));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* null-pointer? in k783 in k780 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1561,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1565,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:227: ##sys#check-special */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t3,t2,lf[32]);}

/* k1563 in null-pointer? in k783 in k780 */
static void C_ccall f_1565(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_null_pointerp(((C_word*)t0)[2]));}

/* pointer->address in k783 in k780 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1551,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1555,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:221: ##sys#check-special */
((C_proc4)C_retrieve_proc(*((C_word*)lf[29]+1)))(4,*((C_word*)lf[29]+1),t3,t2,lf[27]);}

/* k1553 in pointer->address in k783 in k780 */
static void C_ccall f_1555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:222: ##sys#pointer->address */
((C_proc3)C_retrieve_proc(*((C_word*)lf[28]+1)))(3,*((C_word*)lf[28]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* address->pointer in k783 in k780 */
static void C_ccall f_1542(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1542,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1546,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* lolevel.scm:217: ##sys#check-integer */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),t3,t2,lf[24]);}

/* k1544 in address->pointer in k783 in k780 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* lolevel.scm:218: ##sys#address->pointer */
((C_proc3)C_retrieve_proc(*((C_word*)lf[25]+1)))(3,*((C_word*)lf[25]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pointer-like? in k783 in k780 */
static void C_ccall f_1531(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1531,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
t3=C_specialp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* pointer? in k783 in k780 */
static void C_ccall f_1523(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1523,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_safe_pointerp(t2));}

/* free in k783 in k780 */
static void C_ccall f_1513(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1513,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_foreign_pointer_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub323(C_SCHEME_UNDEFINED,t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub323(C_SCHEME_UNDEFINED,C_SCHEME_FALSE));}}

/* allocate in k783 in k780 */
static void C_ccall f_1506(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1506,3,t0,t1,t2);}
t3=C_a_i_bytevector(&a,1,C_fix(3));
t4=C_i_foreign_fixnum_argumentp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,stub318(t3,t4));}

/* object-copy in k783 in k780 */
static void C_ccall f_1425(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1425,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1431,a[2]=t4,a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_1431(t6,t1,t2);}

/* copy in object-copy in k783 in k780 */
static void C_fcall f_1431(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1431,NULL,3,t0,t1,t2);}
if(C_truep(C_blockp(t2))){
if(C_truep(C_i_symbolp(t2))){
t3=C_slot(t2,C_fix(1));
/* lolevel.scm:195: ##sys#intern-symbol */
C_string_to_symbol(3,0,t1,t3);}
else{
t3=C_block_size(t2);
t4=(C_truep(C_byteblockp(t2))?C_words(t3):t3);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1461,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* lolevel.scm:199: ##sys#make-vector */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t5,t4);}}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1459 in copy in object-copy in k783 in k780 */
static void C_ccall f_1461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1461,2,t0,t1);}
t2=C_copy_block(((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1464,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_byteblockp(((C_word*)t0)[5]);
t5=(C_truep(t4)?t4:C_i_symbolp(((C_word*)t0)[5]));
if(C_truep(t5)){
t6=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t2);}
else{
t6=(C_truep(C_specialp(((C_word*)t0)[5]))?C_fix(1):C_fix(0));
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1476,a[2]=((C_word*)t0)[2],a[3]=t8,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li13),tmp=(C_word)a,a+=7,tmp));
t10=((C_word*)t8)[1];
f_1476(t10,t3,t6);}}

/* doloop310 in k1459 in copy in object-copy in k783 in k780 */
static void C_fcall f_1476(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1476,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[5]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1497,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
/* lolevel.scm:203: copy */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1431(t5,t3,t4);}}

/* k1495 in doloop310 in k1459 in copy in object-copy in k783 in k780 */
static void C_ccall f_1497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[5],((C_word*)t0)[4],t1);
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_1476(t4,((C_word*)t0)[2],t3);}

/* k1462 in k1459 in copy in object-copy in k783 in k780 */
static void C_ccall f_1464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* move-memory! in k783 in k780 */
static void C_ccall f_1062(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr4r,(void*)f_1062r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1062r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1062r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a=C_alloc(18);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1064,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word)li8),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1352,a[2]=t5,a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1357,a[2]=t6,a[3]=((C_word)li10),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1362,a[2]=t7,a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-n191290 */
t9=t8;
f_1362(t9,t1);}
else{
t9=C_i_car(t4);
t10=C_i_cdr(t4);
if(C_truep(C_i_nullp(t10))){
/* def-foffset192288 */
t11=t7;
f_1357(t11,t1,t9);}
else{
t11=C_i_car(t10);
t12=C_i_cdr(t10);
if(C_truep(C_i_nullp(t12))){
/* def-toffset193285 */
t13=t6;
f_1352(t13,t1,t9,t11);}
else{
t13=C_i_car(t12);
t14=C_i_cdr(t12);
if(C_truep(C_i_nullp(t14))){
/* body189197 */
t15=t5;
f_1064(t15,t1,t9,t11,t13);}
else{
/* ##sys#error */
t15=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[0],t14);}}}}}

/* def-n191 in move-memory! in k783 in k780 */
static void C_fcall f_1362(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1362,NULL,2,t0,t1);}
/* def-foffset192288 */
t2=((C_word*)t0)[2];
f_1357(t2,t1,C_SCHEME_FALSE);}

/* def-foffset192 in move-memory! in k783 in k780 */
static void C_fcall f_1357(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1357,NULL,3,t0,t1,t2);}
/* def-toffset193285 */
t3=((C_word*)t0)[2];
f_1352(t3,t1,t2,C_fix(0));}

/* def-toffset193 in move-memory! in k783 in k780 */
static void C_fcall f_1352(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1352,NULL,4,t0,t1,t2,t3);}
/* body189197 */
t4=((C_word*)t0)[2];
f_1064(t4,t1,t2,t3,C_fix(0));}

/* body189 in move-memory! in k783 in k780 */
static void C_fcall f_1064(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[41],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1064,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1067,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li3),tmp=(C_word)a,a+=5,tmp));
t14=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1073,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp));
t15=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1079,a[2]=t8,a[3]=((C_word)li5),tmp=(C_word)a,a+=4,tmp));
t16=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1095,a[2]=t8,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp));
t17=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t12,a[6]=t10,a[7]=t6,a[8]=t3,a[9]=t4,a[10]=t2,a[11]=((C_word*)t0)[2],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm:155: ##sys#check-block */
f_787(t17,((C_word*)t0)[4],C_a_i_list(&a,1,lf[11]));}

/* k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* lolevel.scm:156: ##sys#check-block */
f_787(t2,((C_word*)t0)[2],C_a_i_list(&a,1,lf[11]));}

/* k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[8],C_fix(0)))){
/* lolevel.scm:158: ##sys#error */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[11],lf[17],((C_word*)t0)[8]);}
else{
t3=t2;
f_1128(2,t3,C_SCHEME_UNDEFINED);}}

/* k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1131,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[9],C_fix(0)))){
/* lolevel.scm:160: ##sys#error */
t3=*((C_word*)lf[12]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[11],lf[16],((C_word*)t0)[9]);}
else{
t3=t2;
f_1131(2,t3,C_SCHEME_UNDEFINED);}}

/* k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1131,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1136,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=t3,a[9]=((C_word*)t0)[11],a[10]=((C_word)li7),tmp=(C_word)a,a+=11,tmp));
t5=((C_word*)t3)[1];
f_1136(t5,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1136(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word *a;
loop:
a=C_alloc(11);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1136,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_structurep(t2))){
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[9]))){
t5=C_slot(t2,C_fix(1));
/* lolevel.scm:164: move */
t17=t1;
t18=t5;
t19=t3;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t2;
/* lolevel.scm:131: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
if(C_truep(C_structurep(t3))){
t4=C_slot(t3,C_fix(0));
if(C_truep(C_i_memq(t4,((C_word*)t0)[9]))){
t5=C_slot(t3,C_fix(1));
/* lolevel.scm:168: move */
t17=t1;
t18=t2;
t19=t5;
t1=t17;
t2=t18;
t3=t19;
goto loop;}
else{
t5=t1;
t6=t3;
/* lolevel.scm:131: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t5,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t6);}}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1205,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=t1,a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
t5=t2;
t6=C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1205(t7,t6);}
else{
t7=C_locativep(t5);
t8=t4;
f_1205(t8,t7);}}}}

/* k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1205(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1205,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1221,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=((C_word*)t0)[8];
t4=C_i_safe_pointerp(t3);
if(C_truep(t4)){
t5=t2;
f_1221(t5,t4);}
else{
t5=C_locativep(t3);
t6=t2;
f_1221(t6,t5);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1270,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:177: ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[7]);}}

/* k1268 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1270,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=C_block_size(((C_word*)t0)[9]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1292,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
t5=((C_word*)t0)[7];
t6=C_i_safe_pointerp(t5);
if(C_truep(t6)){
t7=t4;
f_1292(t7,t6);}
else{
t7=C_locativep(t5);
t8=t4;
f_1292(t8,t7);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm:131: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1290 in k1268 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1292(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1292,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=((C_word*)t0)[5];
if(C_truep(t3)){
/* lolevel.scm:180: checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1079(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6]);}
else{
/* lolevel.scm:180: checkn1 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_1079(t4,t2,((C_word*)t0)[3],((C_word*)t0)[3],((C_word*)t0)[6]);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:181: ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[9]);}}

/* k1307 in k1290 in k1268 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1319,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(C_truep(t4)?t4:((C_word*)t0)[3]);
t6=C_block_size(((C_word*)t0)[9]);
/* lolevel.scm:182: checkn2 */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1095(t7,t3,t5,((C_word*)t0)[3],t6,((C_word*)t0)[5],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm:131: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1317 in k1307 in k1290 in k1268 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub164(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1297 in k1290 in k1268 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_block_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub132(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1219 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1221(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1221,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[9];
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1228,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_1228(2,t4,t2);}
else{
/* lolevel.scm:172: nosizerr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_1067(t4,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1237,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
/* lolevel.scm:173: ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[15]+1)))(3,*((C_word*)lf[15]+1),t2,((C_word*)t0)[7]);}}

/* k1235 in k1219 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1237,2,t0,t1);}
t2=(C_truep(t1)?t1:C_i_stringp(((C_word*)t0)[9]));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1247,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[9],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=C_block_size(((C_word*)t0)[9]);
/* lolevel.scm:174: checkn1 */
t7=((C_word*)((C_word*)t0)[3])[1];
f_1079(t7,t3,t4,t6,((C_word*)t0)[6]);}
else{
/* lolevel.scm:174: nosizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1067(t6,t5);}}
else{
t3=((C_word*)t0)[8];
t4=((C_word*)t0)[9];
/* lolevel.scm:131: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t3,C_fix((C_word)C_BAD_ARGUMENT_TYPE_ERROR),lf[11],t4);}}

/* k1249 in k1235 in k1219 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_block_size(((C_word*)t0)[5]);
/* lolevel.scm:174: checkn1 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1079(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}

/* k1245 in k1235 in k1219 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub148(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* k1226 in k1219 in k1203 in move in k1129 in k1126 in k1123 in k1120 in body189 in move-memory! in k783 in k780 */
static void C_ccall f_1228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
t4=((C_word*)t0)[4];
t5=((C_word*)t0)[3];
t6=((C_word*)t0)[2];
t7=(C_truep(t3)?C_i_foreign_pointer_argumentp(t3):C_SCHEME_FALSE);
t8=(C_truep(t4)?C_i_foreign_pointer_argumentp(t4):C_SCHEME_FALSE);
t9=C_i_foreign_fixnum_argumentp(t1);
t10=C_i_foreign_fixnum_argumentp(t5);
t11=C_i_foreign_fixnum_argumentp(t6);
t12=t2;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub116(C_SCHEME_UNDEFINED,t7,t8,t9,t10,t11));}

/* checkn2 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1095(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1095,NULL,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1102,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=C_fixnum_difference(t3,t5);
if(C_truep(C_fixnum_less_or_equal_p(t2,t8))){
t9=C_fixnum_difference(t4,t6);
t10=t7;
f_1102(t10,C_fixnum_less_or_equal_p(t2,t9));}
else{
t9=t7;
f_1102(t9,C_SCHEME_FALSE);}}

/* k1100 in checkn2 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1102(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1102,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* lolevel.scm:153: sizerr */
t2=((C_word*)((C_word*)t0)[4])[1];
f_1073(t2,((C_word*)t0)[5],C_a_i_list(&a,3,((C_word*)t0)[6],((C_word*)t0)[3],((C_word*)t0)[2]));}}

/* checkn1 in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1079(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1079,NULL,5,t0,t1,t2,t3,t4);}
t5=C_fixnum_difference(t3,t4);
if(C_truep(C_fixnum_less_or_equal_p(t2,t5))){
t6=t2;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
/* lolevel.scm:148: sizerr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1073(t6,t1,C_a_i_list(&a,2,t2,t3));}}

/* sizerr in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1073(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1073,NULL,3,t0,t1,t2);}
C_apply(8,0,t1,*((C_word*)lf[12]+1),lf[11],lf[14],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* nosizerr in body189 in move-memory! in k783 in k780 */
static void C_fcall f_1067(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1067,NULL,2,t0,t1);}
/* lolevel.scm:140: ##sys#error */
t2=*((C_word*)lf[12]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,t1,lf[11],lf[13],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##sys#check-pointer in k783 in k780 */
static void C_ccall f_921(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr3r,(void*)f_921r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_921r(t0,t1,t2,t3);}}

static void C_ccall f_921r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
t4=t2;
if(C_truep(C_i_safe_pointerp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep(C_i_pairp(t3))){
t5=C_i_car(t3);
/* lolevel.scm:117: ##sys#error-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),t5,lf[9],t2);}
else{
/* lolevel.scm:117: ##sys#error-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_POINTER_ERROR),C_SCHEME_FALSE,lf[9],t2);}}}

/* ##sys#check-generic-structure in k783 in k780 */
static void C_fcall f_860(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_860,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_872,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
if(C_truep(C_blockp(t5))){
t6=C_structurep(t5);
t7=t4;
f_872(t7,t6);}
else{
t6=t4;
f_872(t6,C_SCHEME_FALSE);}}

/* k870 in ##sys#check-generic-structure in k783 in k780 */
static void C_fcall f_872(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=C_i_car(((C_word*)t0)[3]);
/* lolevel.scm:103: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[6],t2,lf[7],((C_word*)t0)[2]);}
else{
/* lolevel.scm:103: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[5]+1)))(6,*((C_word*)lf[5]+1),((C_word*)t0)[4],lf[6],C_SCHEME_FALSE,lf[7],((C_word*)t0)[2]);}}}

/* ##sys#check-block in k783 in k780 */
static void C_fcall f_787(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_787,NULL,3,t1,t2,t3);}
if(C_truep(C_blockp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_pairp(t3))){
t4=C_i_car(t3);
/* lolevel.scm:82: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),t4,t2);}
else{
/* lolevel.scm:82: ##sys#error-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[3]+1)))(5,*((C_word*)lf[3]+1),t1,C_fix((C_word)C_BAD_ARGUMENT_TYPE_NO_BLOCK_ERROR),C_SCHEME_FALSE,t2);}}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[222] = {
{"toplevel:lolevel_scm",(void*)C_lolevel_toplevel},
{"f_782:lolevel_scm",(void*)f_782},
{"f_785:lolevel_scm",(void*)f_785},
{"f_1801:lolevel_scm",(void*)f_1801},
{"f_2891:lolevel_scm",(void*)f_2891},
{"f_1838:lolevel_scm",(void*)f_1838},
{"f_2888:lolevel_scm",(void*)f_2888},
{"f_1842:lolevel_scm",(void*)f_1842},
{"f_2885:lolevel_scm",(void*)f_2885},
{"f_1846:lolevel_scm",(void*)f_1846},
{"f_2882:lolevel_scm",(void*)f_2882},
{"f_1850:lolevel_scm",(void*)f_1850},
{"f_2879:lolevel_scm",(void*)f_2879},
{"f_1854:lolevel_scm",(void*)f_1854},
{"f_2876:lolevel_scm",(void*)f_2876},
{"f_1858:lolevel_scm",(void*)f_1858},
{"f_2873:lolevel_scm",(void*)f_2873},
{"f_1862:lolevel_scm",(void*)f_1862},
{"f_2870:lolevel_scm",(void*)f_2870},
{"f_1866:lolevel_scm",(void*)f_1866},
{"f_2000:lolevel_scm",(void*)f_2000},
{"f_2846:lolevel_scm",(void*)f_2846},
{"f_2850:lolevel_scm",(void*)f_2850},
{"f_2853:lolevel_scm",(void*)f_2853},
{"f_2139:lolevel_scm",(void*)f_2139},
{"f_2833:lolevel_scm",(void*)f_2833},
{"f_2824:lolevel_scm",(void*)f_2824},
{"f_2815:lolevel_scm",(void*)f_2815},
{"f_2809:lolevel_scm",(void*)f_2809},
{"f_2778:lolevel_scm",(void*)f_2778},
{"f_2782:lolevel_scm",(void*)f_2782},
{"f_2785:lolevel_scm",(void*)f_2785},
{"f_2792:lolevel_scm",(void*)f_2792},
{"f_2807:lolevel_scm",(void*)f_2807},
{"f_2795:lolevel_scm",(void*)f_2795},
{"f_2769:lolevel_scm",(void*)f_2769},
{"f_815:lolevel_scm",(void*)f_815},
{"f_837:lolevel_scm",(void*)f_837},
{"f_840:lolevel_scm",(void*)f_840},
{"f_2773:lolevel_scm",(void*)f_2773},
{"f_2640:lolevel_scm",(void*)f_2640},
{"f_2644:lolevel_scm",(void*)f_2644},
{"f_2647:lolevel_scm",(void*)f_2647},
{"f_2652:lolevel_scm",(void*)f_2652},
{"f_2668:lolevel_scm",(void*)f_2668},
{"f_2711:lolevel_scm",(void*)f_2711},
{"f_2714:lolevel_scm",(void*)f_2714},
{"f_2723:lolevel_scm",(void*)f_2723},
{"f_2744:lolevel_scm",(void*)f_2744},
{"f_2717:lolevel_scm",(void*)f_2717},
{"f_2697:lolevel_scm",(void*)f_2697},
{"f_2700:lolevel_scm",(void*)f_2700},
{"f_2681:lolevel_scm",(void*)f_2681},
{"f_2684:lolevel_scm",(void*)f_2684},
{"f_2556:lolevel_scm",(void*)f_2556},
{"f_2560:lolevel_scm",(void*)f_2560},
{"f_2565:lolevel_scm",(void*)f_2565},
{"f_2578:lolevel_scm",(void*)f_2578},
{"f_2635:lolevel_scm",(void*)f_2635},
{"f_2584:lolevel_scm",(void*)f_2584},
{"f_2587:lolevel_scm",(void*)f_2587},
{"f_2597:lolevel_scm",(void*)f_2597},
{"f_2599:lolevel_scm",(void*)f_2599},
{"f_2621:lolevel_scm",(void*)f_2621},
{"f_2590:lolevel_scm",(void*)f_2590},
{"f_2464:lolevel_scm",(void*)f_2464},
{"f_2473:lolevel_scm",(void*)f_2473},
{"f_2518:lolevel_scm",(void*)f_2518},
{"f_2528:lolevel_scm",(void*)f_2528},
{"f3207:lolevel_scm",(void*)f3207},
{"f_2502:lolevel_scm",(void*)f_2502},
{"f_2509:lolevel_scm",(void*)f_2509},
{"f_2546:lolevel_scm",(void*)f_2546},
{"f_2300:lolevel_scm",(void*)f_2300},
{"f_2304:lolevel_scm",(void*)f_2304},
{"f_2307:lolevel_scm",(void*)f_2307},
{"f_2453:lolevel_scm",(void*)f_2453},
{"f_2310:lolevel_scm",(void*)f_2310},
{"f_2313:lolevel_scm",(void*)f_2313},
{"f_2321:lolevel_scm",(void*)f_2321},
{"f_2331:lolevel_scm",(void*)f_2331},
{"f_2446:lolevel_scm",(void*)f_2446},
{"f_2340:lolevel_scm",(void*)f_2340},
{"f_2434:lolevel_scm",(void*)f_2434},
{"f_2438:lolevel_scm",(void*)f_2438},
{"f_2430:lolevel_scm",(void*)f_2430},
{"f_2343:lolevel_scm",(void*)f_2343},
{"f_2346:lolevel_scm",(void*)f_2346},
{"f_2403:lolevel_scm",(void*)f_2403},
{"f_2349:lolevel_scm",(void*)f_2349},
{"f_2352:lolevel_scm",(void*)f_2352},
{"f_2362:lolevel_scm",(void*)f_2362},
{"f_2364:lolevel_scm",(void*)f_2364},
{"f_2385:lolevel_scm",(void*)f_2385},
{"f_2355:lolevel_scm",(void*)f_2355},
{"f_2316:lolevel_scm",(void*)f_2316},
{"f_2182:lolevel_scm",(void*)f_2182},
{"f_2189:lolevel_scm",(void*)f_2189},
{"f_2192:lolevel_scm",(void*)f_2192},
{"f_2197:lolevel_scm",(void*)f_2197},
{"f_2207:lolevel_scm",(void*)f_2207},
{"f_2216:lolevel_scm",(void*)f_2216},
{"f_2220:lolevel_scm",(void*)f_2220},
{"f_2223:lolevel_scm",(void*)f_2223},
{"f_2226:lolevel_scm",(void*)f_2226},
{"f_2236:lolevel_scm",(void*)f_2236},
{"f_2238:lolevel_scm",(void*)f_2238},
{"f_2259:lolevel_scm",(void*)f_2259},
{"f_2229:lolevel_scm",(void*)f_2229},
{"f_2293:lolevel_scm",(void*)f_2293},
{"f_2179:lolevel_scm",(void*)f_2179},
{"f_2141:lolevel_scm",(void*)f_2141},
{"f_2145:lolevel_scm",(void*)f_2145},
{"f_2151:lolevel_scm",(void*)f_2151},
{"f_2156:lolevel_scm",(void*)f_2156},
{"f_2113:lolevel_scm",(void*)f_2113},
{"f_2117:lolevel_scm",(void*)f_2117},
{"f_2120:lolevel_scm",(void*)f_2120},
{"f_2100:lolevel_scm",(void*)f_2100},
{"f_2104:lolevel_scm",(void*)f_2104},
{"f_2091:lolevel_scm",(void*)f_2091},
{"f_2095:lolevel_scm",(void*)f_2095},
{"f_2042:lolevel_scm",(void*)f_2042},
{"f_2046:lolevel_scm",(void*)f_2046},
{"f_2057:lolevel_scm",(void*)f_2057},
{"f_2033:lolevel_scm",(void*)f_2033},
{"f_2011:lolevel_scm",(void*)f_2011},
{"f_2002:lolevel_scm",(void*)f_2002},
{"f_906:lolevel_scm",(void*)f_906},
{"f_2006:lolevel_scm",(void*)f_2006},
{"f_1982:lolevel_scm",(void*)f_1982},
{"f_1986:lolevel_scm",(void*)f_1986},
{"f_1943:lolevel_scm",(void*)f_1943},
{"f_1957:lolevel_scm",(void*)f_1957},
{"f_1974:lolevel_scm",(void*)f_1974},
{"f_1907:lolevel_scm",(void*)f_1907},
{"f_1924:lolevel_scm",(void*)f_1924},
{"f_1941:lolevel_scm",(void*)f_1941},
{"f_1872:lolevel_scm",(void*)f_1872},
{"f_1876:lolevel_scm",(void*)f_1876},
{"f_1897:lolevel_scm",(void*)f_1897},
{"f_1881:lolevel_scm",(void*)f_1881},
{"f_1833:lolevel_scm",(void*)f_1833},
{"f_1830:lolevel_scm",(void*)f_1830},
{"f_1827:lolevel_scm",(void*)f_1827},
{"f_1824:lolevel_scm",(void*)f_1824},
{"f_1821:lolevel_scm",(void*)f_1821},
{"f_1818:lolevel_scm",(void*)f_1818},
{"f_1815:lolevel_scm",(void*)f_1815},
{"f_1812:lolevel_scm",(void*)f_1812},
{"f_1806:lolevel_scm",(void*)f_1806},
{"f_1803:lolevel_scm",(void*)f_1803},
{"f_1796:lolevel_scm",(void*)f_1796},
{"f_1767:lolevel_scm",(void*)f_1767},
{"f_1775:lolevel_scm",(void*)f_1775},
{"f_1738:lolevel_scm",(void*)f_1738},
{"f_1746:lolevel_scm",(void*)f_1746},
{"f_1715:lolevel_scm",(void*)f_1715},
{"f_1727:lolevel_scm",(void*)f_1727},
{"f_1671:lolevel_scm",(void*)f_1671},
{"f_1675:lolevel_scm",(void*)f_1675},
{"f_1651:lolevel_scm",(void*)f_1651},
{"f_1655:lolevel_scm",(void*)f_1655},
{"f_1666:lolevel_scm",(void*)f_1666},
{"f_1658:lolevel_scm",(void*)f_1658},
{"f_1614:lolevel_scm",(void*)f_1614},
{"f_1635:lolevel_scm",(void*)f_1635},
{"f_1646:lolevel_scm",(void*)f_1646},
{"f_1593:lolevel_scm",(void*)f_1593},
{"f_1584:lolevel_scm",(void*)f_1584},
{"f_1588:lolevel_scm",(void*)f_1588},
{"f_1591:lolevel_scm",(void*)f_1591},
{"f_1578:lolevel_scm",(void*)f_1578},
{"f_1582:lolevel_scm",(void*)f_1582},
{"f_1567:lolevel_scm",(void*)f_1567},
{"f_1561:lolevel_scm",(void*)f_1561},
{"f_1565:lolevel_scm",(void*)f_1565},
{"f_1551:lolevel_scm",(void*)f_1551},
{"f_1555:lolevel_scm",(void*)f_1555},
{"f_1542:lolevel_scm",(void*)f_1542},
{"f_1546:lolevel_scm",(void*)f_1546},
{"f_1531:lolevel_scm",(void*)f_1531},
{"f_1523:lolevel_scm",(void*)f_1523},
{"f_1513:lolevel_scm",(void*)f_1513},
{"f_1506:lolevel_scm",(void*)f_1506},
{"f_1425:lolevel_scm",(void*)f_1425},
{"f_1431:lolevel_scm",(void*)f_1431},
{"f_1461:lolevel_scm",(void*)f_1461},
{"f_1476:lolevel_scm",(void*)f_1476},
{"f_1497:lolevel_scm",(void*)f_1497},
{"f_1464:lolevel_scm",(void*)f_1464},
{"f_1062:lolevel_scm",(void*)f_1062},
{"f_1362:lolevel_scm",(void*)f_1362},
{"f_1357:lolevel_scm",(void*)f_1357},
{"f_1352:lolevel_scm",(void*)f_1352},
{"f_1064:lolevel_scm",(void*)f_1064},
{"f_1122:lolevel_scm",(void*)f_1122},
{"f_1125:lolevel_scm",(void*)f_1125},
{"f_1128:lolevel_scm",(void*)f_1128},
{"f_1131:lolevel_scm",(void*)f_1131},
{"f_1136:lolevel_scm",(void*)f_1136},
{"f_1205:lolevel_scm",(void*)f_1205},
{"f_1270:lolevel_scm",(void*)f_1270},
{"f_1292:lolevel_scm",(void*)f_1292},
{"f_1309:lolevel_scm",(void*)f_1309},
{"f_1319:lolevel_scm",(void*)f_1319},
{"f_1299:lolevel_scm",(void*)f_1299},
{"f_1221:lolevel_scm",(void*)f_1221},
{"f_1237:lolevel_scm",(void*)f_1237},
{"f_1251:lolevel_scm",(void*)f_1251},
{"f_1247:lolevel_scm",(void*)f_1247},
{"f_1228:lolevel_scm",(void*)f_1228},
{"f_1095:lolevel_scm",(void*)f_1095},
{"f_1102:lolevel_scm",(void*)f_1102},
{"f_1079:lolevel_scm",(void*)f_1079},
{"f_1073:lolevel_scm",(void*)f_1073},
{"f_1067:lolevel_scm",(void*)f_1067},
{"f_921:lolevel_scm",(void*)f_921},
{"f_860:lolevel_scm",(void*)f_860},
{"f_872:lolevel_scm",(void*)f_872},
{"f_787:lolevel_scm",(void*)f_787},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
