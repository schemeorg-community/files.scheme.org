/* Generated from ports.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: ports.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file ports.c
   unit: ports
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);

static C_TLS C_word lf[48];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,28),40,112,111,114,116,45,102,111,114,45,101,97,99,104,32,102,110,54,49,32,116,104,117,110,107,54,50,41,0,0,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,120,115,55,49,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,23),40,112,111,114,116,45,109,97,112,32,102,110,54,56,32,116,104,117,110,107,54,57,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,12),40,108,111,111,112,32,97,99,99,55,56,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,30),40,112,111,114,116,45,102,111,108,100,32,102,110,55,52,32,97,99,99,55,53,32,116,104,117,110,107,55,54,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,19),40,102,95,54,51,57,32,98,117,102,49,52,51,32,110,49,52,52,41,0,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,14),40,100,111,108,111,111,112,57,50,32,105,57,52,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,19),40,102,95,54,52,52,32,98,117,102,49,52,53,32,110,49,52,54,41,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,110,49,48,56,41,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,6),40,97,54,54,49,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,11),40,97,54,54,55,32,120,49,52,55,41,0,0,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,26),40,98,111,100,121,49,51,48,32,114,101,97,100,49,51,56,32,119,114,105,116,101,49,51,57,41,0,0,0,0,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,26),40,100,101,102,45,119,114,105,116,101,49,51,51,32,37,114,101,97,100,49,50,56,49,52,57,41,0,0,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,114,101,97,100,49,51,50,41,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,38),40,99,111,112,121,45,112,111,114,116,32,115,114,99,49,50,53,32,100,101,115,116,49,50,54,32,46,32,116,109,112,49,50,52,49,50,55,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,17),40,97,55,51,55,32,103,49,55,50,49,55,51,49,55,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,11),40,97,55,51,49,32,115,49,53,55,41,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,49,55,57,32,103,49,56,51,49,56,53,41,0,0,0,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,55,52,51,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,98,114,111,97,100,99,97,115,116,45,112,111,114,116,32,46,32,112,111,114,116,115,49,53,54,41};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,97,55,56,49,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,6),40,97,56,49,54,41,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,97,56,51,54,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,32,110,50,49,51,32,99,50,49,52,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,33),40,97,56,55,49,32,112,50,48,56,32,110,50,48,57,32,100,101,115,116,50,49,48,32,115,116,97,114,116,50,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,41),40,109,97,107,101,45,99,111,110,99,97,116,101,110,97,116,101,100,45,112,111,114,116,32,112,49,49,57,48,32,46,32,112,111,114,116,115,49,57,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,97,57,51,51,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,6),40,97,57,51,56,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,6),40,97,57,52,52,41,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,39),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,112,111,114,116,32,112,111,114,116,50,50,49,32,116,104,117,110,107,50,50,50,41,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,97,57,53,56,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,6),40,97,57,54,51,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,6),40,97,57,54,57,41,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,38),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,112,111,114,116,32,112,111,114,116,50,51,52,32,116,104,117,110,107,50,51,53,41,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,6),40,97,57,56,51,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,6),40,97,57,56,56,41,0,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,6),40,97,57,57,52,41,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,44),40,119,105,116,104,45,101,114,114,111,114,45,111,117,116,112,117,116,45,116,111,45,112,111,114,116,32,112,111,114,116,50,52,55,32,116,104,117,110,107,50,52,56,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,39),40,99,97,108,108,45,119,105,116,104,45,105,110,112,117,116,45,115,116,114,105,110,103,32,115,116,114,50,54,48,32,112,114,111,99,50,54,49,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,33),40,99,97,108,108,45,119,105,116,104,45,111,117,116,112,117,116,45,115,116,114,105,110,103,32,112,114,111,99,50,54,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,7),40,97,49,48,50,57,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,48,51,52,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,48,52,48,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,40),40,119,105,116,104,45,105,110,112,117,116,45,102,114,111,109,45,115,116,114,105,110,103,32,115,116,114,50,54,54,32,116,104,117,110,107,50,54,55,41};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,7),40,97,49,48,53,52,41,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,7),40,97,49,48,53,57,41,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,7),40,97,49,48,54,56,41,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,32),40,119,105,116,104,45,111,117,116,112,117,116,45,116,111,45,115,116,114,105,110,103,32,116,104,117,110,107,50,55,56,41};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,12),40,97,49,48,57,48,32,112,51,49,54,41,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,12),40,97,49,49,49,49,32,112,51,50,50,41,0,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,12),40,97,49,49,51,50,32,112,51,50,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,12),40,97,49,49,52,49,32,112,51,51,49,41,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,45),40,98,111,100,121,51,48,51,32,112,101,101,107,51,49,50,32,114,101,97,100,45,115,116,114,105,110,103,51,49,51,32,114,101,97,100,45,108,105,110,101,51,49,52,41,0,0,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,49),40,100,101,102,45,114,101,97,100,45,108,105,110,101,51,48,55,32,37,112,101,101,107,51,48,48,51,51,54,32,37,114,101,97,100,45,115,116,114,105,110,103,51,48,49,51,51,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,32),40,100,101,102,45,114,101,97,100,45,115,116,114,105,110,103,51,48,54,32,37,112,101,101,107,51,48,48,51,51,57,41};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,13),40,100,101,102,45,112,101,101,107,51,48,53,41,0,0,0};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,56),40,109,97,107,101,45,105,110,112,117,116,45,112,111,114,116,32,114,101,97,100,50,57,54,32,114,101,97,100,121,63,50,57,55,32,99,108,111,115,101,50,57,56,32,46,32,116,109,112,50,57,53,50,57,57,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,17),40,97,49,50,51,55,32,112,51,54,49,32,99,51,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li63[] C_aligned={C_lihdr(0,0,17),40,97,49,50,52,55,32,112,51,54,51,32,115,51,54,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li64[] C_aligned={C_lihdr(0,0,12),40,97,49,50,53,51,32,112,51,54,53,41,0,0,0,0};
static C_char C_TLS li65[] C_aligned={C_lihdr(0,0,12),40,97,49,50,54,50,32,112,51,54,55,41,0,0,0,0};
static C_char C_TLS li66[] C_aligned={C_lihdr(0,0,48),40,109,97,107,101,45,111,117,116,112,117,116,45,112,111,114,116,32,119,114,105,116,101,51,53,52,32,99,108,111,115,101,51,53,53,32,46,32,116,109,112,51,53,51,51,53,54,41};
static C_char C_TLS li67[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_ports_toplevel)
C_externexport void C_ccall C_ports_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_398)
static void C_ccall f_398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1220)
static void C_ccall f_1220r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1224)
static void C_ccall f_1224(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1236)
static void C_ccall f_1236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1263)
static void C_ccall f_1263(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1248)
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1238)
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_1157)
static void C_fcall f_1157(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1152)
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1147)
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1076)
static void C_fcall f_1076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1086)
static void C_ccall f_1086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1089)
static void C_ccall f_1089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1142)
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1133)
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1137)
static void C_ccall f_1137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1112)
static void C_ccall f_1112(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1128)
static void C_ccall f_1128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1091)
static void C_ccall f_1091(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1046)
static void C_ccall f_1046(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1050)
static void C_ccall f_1050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1064)
static void C_ccall f_1064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1055)
static void C_ccall f_1055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1021)
static void C_ccall f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1025)
static void C_ccall f_1025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1041)
static void C_ccall f_1041(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1035)
static void C_ccall f_1035(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1030)
static void C_ccall f_1030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1009)
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1016)
static void C_ccall f_1016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_995)
static void C_ccall f_995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_989)
static void C_ccall f_989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_970)
static void C_ccall f_970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_964)
static void C_ccall f_964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_959)
static void C_ccall f_959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_934)
static void C_ccall f_934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_773)
static void C_ccall f_773r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_872)
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_878)
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_894)
static void C_ccall f_894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_897)
static void C_fcall f_897(C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_ccall f_837(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_843)
static void C_fcall f_843(C_word t0,C_word t1) C_noret;
C_noret_decl(f_853)
static void C_ccall f_853(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_817)
static void C_ccall f_817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_788)
static void C_fcall f_788(C_word t0,C_word t1) C_noret;
C_noret_decl(f_798)
static void C_ccall f_798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_726)
static void C_ccall f_726r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_744)
static void C_ccall f_744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_750)
static void C_fcall f_750(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_760)
static void C_ccall f_760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_732)
static void C_ccall f_732(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_678)
static void C_fcall f_678(C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_fcall f_673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_621)
static void C_fcall f_621(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_547)
static void C_fcall f_547(C_word t0,C_word t1) C_noret;
C_noret_decl(f_551)
static void C_ccall f_551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_560)
static void C_ccall f_560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_668)
static void C_fcall f_668(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_662)
static void C_fcall f_662(C_word t0,C_word t1) C_noret;
C_noret_decl(f_569)
static void C_ccall f_569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_fcall f_574(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_fcall f_578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_485)
static void C_ccall f_485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_490)
static void C_fcall f_490(C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_503)
static void C_ccall f_503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_644)
static void C_ccall f_644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_514)
static void C_fcall f_514(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_524)
static void C_ccall f_524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_639)
static void C_ccall f_639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_456)
static void C_ccall f_456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_462)
static void C_fcall f_462(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_466)
static void C_ccall f_466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_479)
static void C_ccall f_479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_ccall f_424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_430)
static void C_fcall f_430(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_434)
static void C_ccall f_434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_454)
static void C_ccall f_454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_400)
static void C_ccall f_400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_406)
static void C_fcall f_406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_410)
static void C_ccall f_410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1157)
static void C_fcall trf_1157(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1157(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1157(t0,t1);}

C_noret_decl(trf_1152)
static void C_fcall trf_1152(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1152(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1152(t0,t1,t2);}

C_noret_decl(trf_1147)
static void C_fcall trf_1147(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1147(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1147(t0,t1,t2,t3);}

C_noret_decl(trf_1076)
static void C_fcall trf_1076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1076(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1076(t0,t1,t2,t3,t4);}

C_noret_decl(trf_878)
static void C_fcall trf_878(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_878(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_878(t0,t1,t2,t3);}

C_noret_decl(trf_897)
static void C_fcall trf_897(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_897(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_897(t0,t1);}

C_noret_decl(trf_843)
static void C_fcall trf_843(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_843(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_843(t0,t1);}

C_noret_decl(trf_788)
static void C_fcall trf_788(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_788(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_788(t0,t1);}

C_noret_decl(trf_750)
static void C_fcall trf_750(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_750(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_750(t0,t1,t2);}

C_noret_decl(trf_678)
static void C_fcall trf_678(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_678(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_678(t0,t1);}

C_noret_decl(trf_673)
static void C_fcall trf_673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_673(t0,t1,t2);}

C_noret_decl(trf_621)
static void C_fcall trf_621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_621(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_621(t0,t1,t2,t3);}

C_noret_decl(trf_547)
static void C_fcall trf_547(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_547(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_547(t0,t1);}

C_noret_decl(trf_668)
static void C_fcall trf_668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_668(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_668(t0,t1,t2);}

C_noret_decl(trf_662)
static void C_fcall trf_662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_662(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_662(t0,t1);}

C_noret_decl(trf_574)
static void C_fcall trf_574(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_574(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_574(t0,t1,t2);}

C_noret_decl(trf_578)
static void C_fcall trf_578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_578(t0,t1);}

C_noret_decl(trf_490)
static void C_fcall trf_490(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_490(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_490(t0,t1);}

C_noret_decl(trf_514)
static void C_fcall trf_514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_514(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_514(t0,t1,t2);}

C_noret_decl(trf_462)
static void C_fcall trf_462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_462(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_462(t0,t1,t2);}

C_noret_decl(trf_430)
static void C_fcall trf_430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_430(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_430(t0,t1,t2);}

C_noret_decl(trf_406)
static void C_fcall trf_406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_406(t0,t1);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_ports_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_ports_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("ports_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(440)){
C_save(t1);
C_rereclaim2(440*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,48);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],13,"port-for-each");
lf[3]=C_h_intern(&lf[3],7,"reverse");
lf[4]=C_h_intern(&lf[4],8,"port-map");
lf[5]=C_h_intern(&lf[5],9,"port-fold");
lf[6]=C_h_intern(&lf[6],9,"read-char");
lf[7]=C_h_intern(&lf[7],10,"write-char");
lf[8]=C_h_intern(&lf[8],9,"copy-port");
lf[9]=C_h_intern(&lf[9],12,"write-string");
lf[10]=C_h_intern(&lf[10],12,"read-string!");
lf[11]=C_h_intern(&lf[11],11,"make-string");
lf[12]=C_h_intern(&lf[12],9,"\003syserror");
lf[13]=C_h_intern(&lf[13],19,"make-broadcast-port");
lf[14]=C_h_intern(&lf[14],12,"\003sysfor-each");
lf[15]=C_h_intern(&lf[15],12,"flush-output");
lf[16]=C_h_intern(&lf[16],16,"make-output-port");
lf[17]=C_h_intern(&lf[17],4,"void");
lf[18]=C_h_intern(&lf[18],22,"make-concatenated-port");
lf[19]=C_h_intern(&lf[19],18,"\003sysread-char/port");
lf[20]=C_h_intern(&lf[20],11,"char-ready\077");
lf[21]=C_h_intern(&lf[21],9,"peek-char");
lf[22]=C_h_intern(&lf[22],15,"make-input-port");
lf[23]=C_h_intern(&lf[23],20,"with-input-from-port");
lf[24]=C_h_intern(&lf[24],18,"\003sysstandard-input");
lf[25]=C_h_intern(&lf[25],16,"\003sysdynamic-wind");
lf[26]=C_h_intern(&lf[26],14,"\003syscheck-port");
lf[27]=C_h_intern(&lf[27],19,"with-output-to-port");
lf[28]=C_h_intern(&lf[28],19,"\003sysstandard-output");
lf[29]=C_h_intern(&lf[29],21,"with-output-from-port");
lf[30]=C_h_intern(&lf[30],25,"with-error-output-to-port");
lf[31]=C_h_intern(&lf[31],18,"\003sysstandard-error");
lf[32]=C_h_intern(&lf[32],27,"with-error-output-from-port");
lf[33]=C_h_intern(&lf[33],22,"call-with-input-string");
lf[34]=C_h_intern(&lf[34],17,"open-input-string");
lf[35]=C_h_intern(&lf[35],23,"call-with-output-string");
lf[36]=C_h_intern(&lf[36],17,"get-output-string");
lf[37]=C_h_intern(&lf[37],18,"open-output-string");
lf[38]=C_h_intern(&lf[38],22,"with-input-from-string");
lf[39]=C_h_intern(&lf[39],21,"with-output-to-string");
lf[40]=C_h_intern(&lf[40],18,"\003sysset-port-data!");
lf[41]=C_h_intern(&lf[41],13,"\003sysmake-port");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[43]=C_h_intern(&lf[43],6,"custom");
lf[44]=C_h_intern(&lf[44],6,"string");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\010(custom)");
lf[46]=C_h_intern(&lf[46],17,"register-feature!");
lf[47]=C_h_intern(&lf[47],5,"ports");
C_register_lf2(lf,48,create_ptable());
t2=C_mutate(&lf[0] /* (set! c155 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_398,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ports.scm:42: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[47]);}

/* k396 */
static void C_ccall f_398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[49],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_398,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! port-for-each ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_400,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t3=*((C_word*)lf[3]+1);
t4=C_mutate((C_word*)lf[4]+1 /* (set! port-map ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_424,a[2]=t3,a[3]=((C_word)li3),tmp=(C_word)a,a+=4,tmp));
t5=C_mutate((C_word*)lf[5]+1 /* (set! port-fold ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_456,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t6=*((C_word*)lf[6]+1);
t7=*((C_word*)lf[7]+1);
t8=C_mutate((C_word*)lf[8]+1 /* (set! copy-port ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_619,a[2]=t7,a[3]=t6,a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp));
t9=C_mutate((C_word*)lf[13]+1 /* (set! make-broadcast-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_726,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[18]+1 /* (set! make-concatenated-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_773,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[23]+1 /* (set! with-input-from-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_925,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[27]+1 /* (set! with-output-to-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_950,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! with-error-output-to-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_975,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[33]+1 /* (set! call-with-input-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1000,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[35]+1 /* (set! call-with-output-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1009,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[38]+1 /* (set! with-input-from-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1021,a[2]=((C_word)li48),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[39]+1 /* (set! with-output-to-string ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1046,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[22]+1 /* (set! make-input-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1074,a[2]=((C_word)li61),tmp=(C_word)a,a+=3,tmp));
t19=*((C_word*)lf[44]+1);
t20=C_mutate((C_word*)lf[16]+1 /* (set! make-output-port ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1220,a[2]=t19,a[3]=((C_word)li66),tmp=(C_word)a,a+=4,tmp));
t21=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,C_SCHEME_UNDEFINED);}

/* make-output-port in k396 */
static void C_ccall f_1220(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr4r,(void*)f_1220r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1220r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1220r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1224,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1224(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1224(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1222 in make-output-port in k396 */
static void C_ccall f_1224(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[33],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1224,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1238,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li62),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1248,a[2]=((C_word*)t0)[5],a[3]=((C_word)li63),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[3],a[3]=((C_word)li64),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1263,a[2]=t1,a[3]=((C_word)li65),tmp=(C_word)a,a+=4,tmp);
t6=C_a_i_vector(&a,9,C_SCHEME_FALSE,C_SCHEME_FALSE,t2,t3,t4,t5,C_SCHEME_FALSE,C_SCHEME_FALSE,C_SCHEME_FALSE);
t7=C_a_i_vector(&a,1,C_SCHEME_FALSE);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1233,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:271: ##sys#make-port */
((C_proc6)C_retrieve_proc(*((C_word*)lf[41]+1)))(6,*((C_word*)lf[41]+1),t8,C_SCHEME_FALSE,t6,lf[45],lf[43]);}

/* k1231 in k1222 in make-output-port in k396 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1236,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:272: ##sys#set-port-data! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,t1,((C_word*)t0)[2]);}

/* k1234 in k1231 in k1222 in make-output-port in k396 */
static void C_ccall f_1236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1262 in k1222 in make-output-port in k396 */
static void C_ccall f_1263(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1263,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* ports.scm:266: flush */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a1253 in k1222 in make-output-port in k396 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1254,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1258,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:263: close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1256 in a1253 in k1222 in make-output-port in k396 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a1247 in k1222 in make-output-port in k396 */
static void C_ccall f_1248(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1248,4,t0,t1,t2,t3);}
/* ports.scm:261: write */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a1237 in k1222 in make-output-port in k396 */
static void C_ccall f_1238(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1238,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1246,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:259: string */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t3);}

/* k1244 in a1237 in k1222 in make-output-port in k396 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:259: write */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* make-input-port in k396 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(c<5) C_bad_min_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+18)){
C_save_and_reclaim((void*)tr5r,(void*)f_1074r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_1074r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_1074r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a=C_alloc(18);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1076,a[2]=t3,a[3]=t4,a[4]=t2,a[5]=((C_word)li57),tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1147,a[2]=t6,a[3]=((C_word)li58),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1152,a[2]=t7,a[3]=((C_word)li59),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1157,a[2]=t8,a[3]=((C_word)li60),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t5))){
/* def-peek305340 */
t10=t9;
f_1157(t10,t1);}
else{
t10=C_i_car(t5);
t11=C_i_cdr(t5);
if(C_truep(C_i_nullp(t11))){
/* def-read-string306338 */
t12=t8;
f_1152(t12,t1,t10);}
else{
t12=C_i_car(t11);
t13=C_i_cdr(t11);
if(C_truep(C_i_nullp(t13))){
/* def-read-line307335 */
t14=t7;
f_1147(t14,t1,t10,t12);}
else{
t14=C_i_car(t13);
t15=C_i_cdr(t13);
if(C_truep(C_i_nullp(t15))){
/* body303311 */
t16=t6;
f_1076(t16,t1,t10,t12,t14);}
else{
/* ##sys#error */
t16=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t1,lf[0],t15);}}}}}

/* def-peek305 in make-input-port in k396 */
static void C_fcall f_1157(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1157,NULL,2,t0,t1);}
/* def-read-string306338 */
t2=((C_word*)t0)[2];
f_1152(t2,t1,C_SCHEME_FALSE);}

/* def-read-string306 in make-input-port in k396 */
static void C_fcall f_1152(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1152,NULL,3,t0,t1,t2);}
/* def-read-line307335 */
t3=((C_word*)t0)[2];
f_1147(t3,t1,t2,C_SCHEME_FALSE);}

/* def-read-line307 in make-input-port in k396 */
static void C_fcall f_1147(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1147,NULL,4,t0,t1,t2,t3);}
/* body303311 */
t4=((C_word*)t0)[2];
f_1076(t4,t1,t2,t3,C_SCHEME_FALSE);}

/* body303 in make-input-port in k396 */
static void C_fcall f_1076(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1076,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1091,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li53),tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1112,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word)li54),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1133,a[2]=((C_word*)t0)[3],a[3]=((C_word)li55),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1142,a[2]=((C_word*)t0)[2],a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp);
t9=C_a_i_vector(&a,9,t5,t6,C_SCHEME_FALSE,C_SCHEME_FALSE,t7,C_SCHEME_FALSE,t8,t3,t4);
t10=C_a_i_vector(&a,1,C_SCHEME_FALSE);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1086,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:247: ##sys#make-port */
((C_proc6)C_retrieve_proc(*((C_word*)lf[41]+1)))(6,*((C_word*)lf[41]+1),t11,C_SCHEME_TRUE,t9,lf[42],lf[43]);}

/* k1084 in body303 in make-input-port in k396 */
static void C_ccall f_1086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1089,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:248: ##sys#set-port-data! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),t2,t1,((C_word*)t0)[2]);}

/* k1087 in k1084 in body303 in make-input-port in k396 */
static void C_ccall f_1089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a1141 in body303 in make-input-port in k396 */
static void C_ccall f_1142(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1142,3,t0,t1,t2);}
/* ports.scm:243: ready? */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t1);}

/* a1132 in body303 in make-input-port in k396 */
static void C_ccall f_1133(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1133,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1137,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:239: close */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k1135 in a1132 in body303 in make-input-port in k396 */
static void C_ccall f_1137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(8),C_SCHEME_TRUE));}

/* a1111 in body303 in make-input-port in k396 */
static void C_ccall f_1112(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1112,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* ports.scm:230: peek */
t4=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1128,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:233: read */
t5=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}}}

/* k1126 in a1111 in body303 in make-input-port in k396 */
static void C_ccall f_1128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(10),t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a1090 in body303 in make-input-port in k396 */
static void C_ccall f_1091(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1091,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(10));
if(C_truep(((C_word*)t0)[3])){
/* ports.scm:223: read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
if(C_truep(t3)){
t4=C_i_set_i_slot(t2,C_fix(10),C_SCHEME_FALSE);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t3);}
else{
/* ports.scm:227: read */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}}}

/* with-output-to-string in k396 */
static void C_ccall f_1046(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1046,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1050,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:206: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t3);}

/* k1048 in with-output-to-string in k396 */
static void C_ccall f_1050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1050,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1055,a[2]=t3,a[3]=t5,a[4]=((C_word)li49),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1060,a[2]=((C_word*)t0)[3],a[3]=((C_word)li50),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1069,a[2]=t5,a[3]=t3,a[4]=((C_word)li51),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a1068 in k1048 in with-output-to-string in k396 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1069,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[28]+1));
t3=C_mutate((C_word*)lf[28]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a1059 in k1048 in with-output-to-string in k396 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1064,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* ports.scm:207: thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1062 in a1059 in k1048 in with-output-to-string in k396 */
static void C_ccall f_1064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:208: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[2],*((C_word*)lf[28]+1));}

/* a1054 in k1048 in with-output-to-string in k396 */
static void C_ccall f_1055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1055,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[28]+1));
t3=C_mutate((C_word*)lf[28]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-input-from-string in k396 */
static void C_ccall f_1021(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1021,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1025,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:201: open-input-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t4,t2);}

/* k1023 in with-input-from-string in k396 */
static void C_ccall f_1025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1025,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1030,a[2]=t3,a[3]=t5,a[4]=((C_word)li45),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1035,a[2]=((C_word*)t0)[3],a[3]=((C_word)li46),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1041,a[2]=t5,a[3]=t3,a[4]=((C_word)li47),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a1040 in k1023 in with-input-from-string in k396 */
static void C_ccall f_1041(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1041,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[24]+1));
t3=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a1034 in k1023 in with-input-from-string in k396 */
static void C_ccall f_1035(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1035,2,t0,t1);}
/* ports.scm:202: thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a1029 in k1023 in with-input-from-string in k396 */
static void C_ccall f_1030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1030,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[24]+1));
t3=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* call-with-output-string in k396 */
static void C_ccall f_1009(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1009,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1013,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:195: open-output-string */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t3);}

/* k1011 in call-with-output-string in k396 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1016,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:196: proc */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1014 in k1011 in call-with-output-string in k396 */
static void C_ccall f_1016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:197: get-output-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* call-with-input-string in k396 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1000,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1004,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:190: open-input-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t4,t2);}

/* k1002 in call-with-input-string in k396 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:191: proc */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* with-error-output-to-port in k396 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_975,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_979,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:182: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),t4,t2,lf[32]);}

/* k977 in with-error-output-to-port in k396 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_984,a[2]=t3,a[3]=t5,a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_989,a[2]=((C_word*)t0)[3],a[3]=((C_word)li40),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_995,a[2]=t5,a[3]=t3,a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a994 in k977 in with-error-output-to-port in k396 */
static void C_ccall f_995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_995,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[31]+1));
t3=C_mutate((C_word*)lf[31]+1 /* (set! ##sys#standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a988 in k977 in with-error-output-to-port in k396 */
static void C_ccall f_989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_989,2,t0,t1);}
/* ports.scm:184: thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a983 in k977 in with-error-output-to-port in k396 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_984,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[31]+1));
t3=C_mutate((C_word*)lf[31]+1 /* (set! ##sys#standard-error ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-output-to-port in k396 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_950,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_954,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:177: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),t4,t2,lf[29]);}

/* k952 in with-output-to-port in k396 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_954,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_959,a[2]=t3,a[3]=t5,a[4]=((C_word)li35),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_964,a[2]=((C_word*)t0)[3],a[3]=((C_word)li36),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_970,a[2]=t5,a[3]=t3,a[4]=((C_word)li37),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a969 in k952 in with-output-to-port in k396 */
static void C_ccall f_970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_970,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[28]+1));
t3=C_mutate((C_word*)lf[28]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a963 in k952 in with-output-to-port in k396 */
static void C_ccall f_964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_964,2,t0,t1);}
/* ports.scm:179: thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a958 in k952 in with-output-to-port in k396 */
static void C_ccall f_959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_959,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[28]+1));
t3=C_mutate((C_word*)lf[28]+1 /* (set! ##sys#standard-output ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* with-input-from-port in k396 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_925,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_929,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:172: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[26]+1)))(4,*((C_word*)lf[26]+1),t4,t2,lf[23]);}

/* k927 in with-input-from-port in k396 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_929,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_934,a[2]=t3,a[3]=t5,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[3],a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_945,a[2]=t5,a[3]=t3,a[4]=((C_word)li33),tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[25]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a944 in k927 in with-input-from-port in k396 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[24]+1));
t3=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a938 in k927 in with-input-from-port in k396 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
/* ports.scm:174: thunk */
t2=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t2))(2,t2,t1);}

/* a933 in k927 in with-input-from-port in k396 */
static void C_ccall f_934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_934,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,*((C_word*)lf[24]+1));
t3=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#standard-input ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* make-concatenated-port in k396 */
static void C_ccall f_773(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+21)){
C_save_and_reclaim((void*)tr3r,(void*)f_773r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_773r(t0,t1,t2,t3);}}

static void C_ccall f_773r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(21);
t4=C_a_i_cons(&a,2,t2,t3);
t5=t4;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_782,a[2]=t6,a[3]=((C_word)li24),tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_817,a[2]=t6,a[3]=((C_word)li25),tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_837,a[2]=t6,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_872,a[2]=t6,a[3]=((C_word)li29),tmp=(C_word)a,a+=4,tmp);
/* ports.scm:135: make-input-port */
t11=*((C_word*)lf[22]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t1,t7,t8,*((C_word*)lf[17]+1),t9,t10);}

/* a871 in make-concatenated-port in k396 */
static void C_ccall f_872(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_872,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_878,a[2]=t4,a[3]=t5,a[4]=t7,a[5]=((C_word*)t0)[2],a[6]=((C_word)li28),tmp=(C_word)a,a+=7,tmp));
t9=((C_word*)t7)[1];
f_878(t9,t1,t3,C_fix(0));}

/* loop in a871 in make-concatenated-port in k396 */
static void C_fcall f_878(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_878,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[5])[1]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_fixnum_less_or_equal_p(t2,C_fix(0)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_894,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t5=C_i_car(((C_word*)((C_word*)t0)[5])[1]);
t6=C_fixnum_plus(((C_word*)t0)[3],t3);
/* ports.scm:163: read-string! */
((C_proc6)C_retrieve_proc(*((C_word*)lf[10]+1)))(6,*((C_word*)lf[10]+1),t4,t2,((C_word*)t0)[2],t5,t6);}}}

/* k892 in loop in a871 in make-concatenated-port in k396 */
static void C_ccall f_894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_897,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_fixnum_lessp(t1,((C_word*)t0)[6]))){
t3=C_i_cdr(((C_word*)((C_word*)t0)[2])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t5=t2;
f_897(t5,t4);}
else{
t3=t2;
f_897(t3,C_SCHEME_UNDEFINED);}}

/* k895 in k892 in loop in a871 in make-concatenated-port in k396 */
static void C_fcall f_897(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[6],((C_word*)t0)[5]);
t3=C_fixnum_plus(((C_word*)t0)[4],((C_word*)t0)[5]);
/* ports.scm:166: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_878(t4,((C_word*)t0)[2],t2,t3);}

/* a836 in make-concatenated-port in k396 */
static void C_ccall f_837(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_837,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_843,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li26),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_843(t5,t1);}

/* loop in a836 in make-concatenated-port in k396 */
static void C_fcall f_843(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_843,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_853,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* ports.scm:153: peek-char */
((C_proc3)C_retrieve_proc(*((C_word*)lf[21]+1)))(3,*((C_word*)lf[21]+1),t2,t3);}}

/* k851 in loop in a836 in make-concatenated-port in k396 */
static void C_ccall f_853(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_eofp(t1))){
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* ports.scm:156: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_843(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* a816 in make-concatenated-port in k396 */
static void C_ccall f_817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_817,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[2])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_car(((C_word*)((C_word*)t0)[2])[1]);
/* ports.scm:147: char-ready? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),t1,t2);}}

/* a781 in make-concatenated-port in k396 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_782,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_788,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li23),tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_788(t5,t1);}

/* loop in a781 in make-concatenated-port in k396 */
static void C_fcall f_788(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_788,NULL,2,t0,t1);}
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_798,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
/* read-char/port */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k796 in loop in a781 in make-concatenated-port in k396 */
static void C_ccall f_798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(C_eofp(t1))){
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
/* ports.scm:143: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_788(t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}}

/* make-broadcast-port in k396 */
static void C_ccall f_726(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_726r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_726r(t0,t1,t2);}}

static void C_ccall f_726r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_732,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_744,a[2]=t2,a[3]=((C_word)li21),tmp=(C_word)a,a+=4,tmp);
/* ports.scm:128: make-output-port */
t5=*((C_word*)lf[16]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t3,*((C_word*)lf[17]+1),t4);}

/* a743 in make-broadcast-port in k396 */
static void C_ccall f_744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_744,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_750,a[2]=t3,a[3]=((C_word)li20),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_750(t5,t1,((C_word*)t0)[2]);}

/* loop179 in a743 in make-broadcast-port in k396 */
static void C_fcall f_750(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_750,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[15]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_760,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g186187 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k758 in loop179 in a743 in make-broadcast-port in k396 */
static void C_ccall f_760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_750(t3,((C_word*)t0)[2],t2);}

/* a731 in make-broadcast-port in k396 */
static void C_ccall f_732(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_732,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_738,a[2]=t2,a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}

/* a737 in a731 in make-broadcast-port in k396 */
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_738,3,t0,t1,t2);}
t3=*((C_word*)lf[9]+1);
/* g175176 */
t4=t3;
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,((C_word*)t0)[2],C_SCHEME_FALSE,t2);}

/* copy-port in k396 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+17)){
C_save_and_reclaim((void*)tr4r,(void*)f_619r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_619r(t0,t1,t2,t3,t4);}}

static void C_ccall f_619r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a=C_alloc(17);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_621,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word)li14),tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_673,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word)li15),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_678,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word)li16),tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* def-read132150 */
t8=t7;
f_678(t8,t1);}
else{
t8=C_i_car(t4);
t9=C_i_cdr(t4);
if(C_truep(C_i_nullp(t9))){
/* def-write133148 */
t10=t6;
f_673(t10,t1,t8);}
else{
t10=C_i_car(t9);
t11=C_i_cdr(t9);
if(C_truep(C_i_nullp(t11))){
/* body130137 */
t12=t5;
f_621(t12,t1,t8,t10);}
else{
/* ##sys#error */
t12=*((C_word*)lf[12]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t1,lf[0],t11);}}}}

/* def-read132 in copy-port in k396 */
static void C_fcall f_678(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_678,NULL,2,t0,t1);}
/* def-write133148 */
t2=((C_word*)t0)[3];
f_673(t2,t1,((C_word*)t0)[2]);}

/* def-write133 in copy-port in k396 */
static void C_fcall f_673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_673,NULL,3,t0,t1,t2);}
/* body130137 */
t3=((C_word*)t0)[3];
f_621(t3,t1,t2,((C_word*)t0)[2]);}

/* body130 in copy-port in k396 */
static void C_fcall f_621(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_621,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,((C_word*)t0)[5]);
if(C_truep(t4)){
t5=C_eqp(t3,((C_word*)t0)[4]);
t6=(C_truep(t5)?(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_639,a[2]=((C_word*)t0)[3],a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp):(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_644,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word)li8),tmp=(C_word)a,a+=5,tmp));
t7=t1;
t8=((C_word*)t0)[2];
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_485,a[2]=t7,a[3]=t8,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:73: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[11]+1)))(3,*((C_word*)lf[11]+1),t9,C_fix(1024));}
else{
t5=C_eqp(t3,((C_word*)t0)[4]);
if(C_truep(t5)){
t6=t1;
t7=((C_word*)t0)[2];
t8=((C_word*)t0)[3];
t9=t2;
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_569,a[2]=t6,a[3]=t7,a[4]=t9,a[5]=t8,tmp=(C_word)a,a+=6,tmp);
/* ports.scm:93: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[11]+1)))(3,*((C_word*)lf[11]+1),t10,C_fix(1024));}
else{
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_662,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_668,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t8=t1;
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_547,a[2]=t6,a[3]=t7,a[4]=t10,a[5]=((C_word)li13),tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_547(t12,t8);}}}

/* loop in body130 in copy-port in k396 */
static void C_fcall f_547(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_547,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_551,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:87: reader */
t3=((C_word*)t0)[2];
f_662(t3,t2);}

/* k549 in loop in body130 in copy-port in k396 */
static void C_ccall f_551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_551,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_560,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:89: writer */
t3=((C_word*)t0)[2];
f_668(t3,t2,t1);}}

/* k558 in k549 in loop in body130 in copy-port in k396 */
static void C_ccall f_560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:90: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_547(t2,((C_word*)t0)[2]);}

/* a667 in body130 in copy-port in k396 */
static void C_fcall f_668(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_668,NULL,3,t0,t1,t2);}
/* ports.scm:122: write */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a661 in body130 in copy-port in k396 */
static void C_fcall f_662(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_662,NULL,2,t0,t1);}
/* ports.scm:121: read */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k567 in body130 in copy-port in k396 */
static void C_ccall f_569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_569,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word)li10),tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_574(t5,((C_word*)t0)[2],C_fix(0));}

/* loop in k567 in body130 in copy-port in k396 */
static void C_fcall f_574(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_574,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t3,tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)t3)[1],C_fix(1024)))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ports.scm:96: write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),t5,((C_word*)t0)[6],C_fix(1024),((C_word*)t0)[5]);}
else{
t5=t4;
f_578(t5,C_SCHEME_UNDEFINED);}}

/* k614 in loop in k567 in body130 in copy-port in k396 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_fix(0));
t3=((C_word*)t0)[2];
f_578(t3,t2);}

/* k576 in loop in k567 in body130 in copy-port in k396 */
static void C_fcall f_578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_578,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_581,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* ports.scm:98: reader */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k579 in k576 in loop in k567 in body130 in copy-port in k396 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(C_eofp(t1))){
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[6])[1],C_fix(0)))){
/* ports.scm:101: write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}
else{
t2=C_fix(C_character_code(t1));
t3=C_setbyte(((C_word*)t0)[4],((C_word*)((C_word*)t0)[6])[1],t2);
t4=C_fixnum_plus(((C_word*)((C_word*)t0)[6])[1],C_fix(1));
/* ports.scm:104: loop */
t5=((C_word*)((C_word*)t0)[2])[1];
f_574(t5,((C_word*)t0)[5],t4);}}

/* k483 in body130 in copy-port in k396 */
static void C_ccall f_485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_485,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_490,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word)li9),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_490(t5,((C_word*)t0)[2]);}

/* loop in k483 in body130 in copy-port in k396 */
static void C_fcall f_490(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_490,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_494,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* ports.scm:75: read-string! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[10]+1)))(5,*((C_word*)lf[10]+1),t2,C_fix(1024),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k492 in loop in k483 in body130 in copy-port in k396 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_494,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_503,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:77: writer */
t4=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t4))(4,t4,t3,((C_word*)t0)[2],t1);}}

/* k501 in k492 in loop in k483 in body130 in copy-port in k396 */
static void C_ccall f_503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:78: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_490(t2,((C_word*)t0)[2]);}

/* f_644 in body130 in copy-port in k396 */
static void C_ccall f_644(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_644,4,t0,t1,t2,t3);}
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_514,a[2]=t4,a[3]=t5,a[4]=t2,a[5]=t7,a[6]=t3,a[7]=((C_word)li7),tmp=(C_word)a,a+=8,tmp));
t9=((C_word*)t7)[1];
f_514(t9,t1,C_fix(0));}

/* doloop92 */
static void C_fcall f_514(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_514,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_524,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_subbyte(((C_word*)t0)[4],t2);
t5=C_make_character(C_unfix(t4));
/* ports.scm:83: writer */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t3,t5,((C_word*)t0)[2]);}}

/* k522 in doloop92 */
static void C_ccall f_524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_514(t3,((C_word*)t0)[2],t2);}

/* f_639 in body130 in copy-port in k396 */
static void C_ccall f_639(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_639,4,t0,t1,t2,t3);}
/* ports.scm:115: write-string */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),t1,t2,t3,((C_word*)t0)[2]);}

/* port-fold in k396 */
static void C_ccall f_456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_456,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_462,a[2]=t4,a[3]=t2,a[4]=t6,a[5]=((C_word)li4),tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_462(t8,t1,t3);}

/* loop in port-fold in k396 */
static void C_fcall f_462(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_462,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_466,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* ports.scm:65: thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k464 in loop in port-fold in k396 */
static void C_ccall f_466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_466,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_479,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:68: fn */
t3=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,t1,((C_word*)t0)[5]);}}

/* k477 in k464 in loop in port-fold in k396 */
static void C_ccall f_479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:68: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_462(t2,((C_word*)t0)[2],t1);}

/* port-map in k396 */
static void C_ccall f_424(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_424,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_430,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=((C_word)li2),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_430(t7,t1,C_SCHEME_END_OF_LIST);}

/* loop in port-map in k396 */
static void C_fcall f_430(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_430,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_434,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* ports.scm:58: thunk */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}

/* k432 in loop in port-map in k396 */
static void C_ccall f_434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_434,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* ports.scm:60: reverse */
t2=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_454,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ports.scm:61: fn */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k452 in k432 in loop in port-map in k396 */
static void C_ccall f_454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_454,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[4]);
/* ports.scm:61: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_430(t3,((C_word*)t0)[2],t2);}

/* port-for-each in k396 */
static void C_ccall f_400(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_400,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_406,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=((C_word)li0),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_406(t7,t1);}

/* loop in port-for-each in k396 */
static void C_fcall f_406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_406,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_410,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* ports.scm:49: thunk */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k408 in loop in port-for-each in k396 */
static void C_ccall f_410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_410,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_419,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ports.scm:51: fn */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k417 in k408 in loop in port-for-each in k396 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ports.scm:52: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_406(t2,((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[109] = {
{"toplevel:ports_scm",(void*)C_ports_toplevel},
{"f_398:ports_scm",(void*)f_398},
{"f_1220:ports_scm",(void*)f_1220},
{"f_1224:ports_scm",(void*)f_1224},
{"f_1233:ports_scm",(void*)f_1233},
{"f_1236:ports_scm",(void*)f_1236},
{"f_1263:ports_scm",(void*)f_1263},
{"f_1254:ports_scm",(void*)f_1254},
{"f_1258:ports_scm",(void*)f_1258},
{"f_1248:ports_scm",(void*)f_1248},
{"f_1238:ports_scm",(void*)f_1238},
{"f_1246:ports_scm",(void*)f_1246},
{"f_1074:ports_scm",(void*)f_1074},
{"f_1157:ports_scm",(void*)f_1157},
{"f_1152:ports_scm",(void*)f_1152},
{"f_1147:ports_scm",(void*)f_1147},
{"f_1076:ports_scm",(void*)f_1076},
{"f_1086:ports_scm",(void*)f_1086},
{"f_1089:ports_scm",(void*)f_1089},
{"f_1142:ports_scm",(void*)f_1142},
{"f_1133:ports_scm",(void*)f_1133},
{"f_1137:ports_scm",(void*)f_1137},
{"f_1112:ports_scm",(void*)f_1112},
{"f_1128:ports_scm",(void*)f_1128},
{"f_1091:ports_scm",(void*)f_1091},
{"f_1046:ports_scm",(void*)f_1046},
{"f_1050:ports_scm",(void*)f_1050},
{"f_1069:ports_scm",(void*)f_1069},
{"f_1060:ports_scm",(void*)f_1060},
{"f_1064:ports_scm",(void*)f_1064},
{"f_1055:ports_scm",(void*)f_1055},
{"f_1021:ports_scm",(void*)f_1021},
{"f_1025:ports_scm",(void*)f_1025},
{"f_1041:ports_scm",(void*)f_1041},
{"f_1035:ports_scm",(void*)f_1035},
{"f_1030:ports_scm",(void*)f_1030},
{"f_1009:ports_scm",(void*)f_1009},
{"f_1013:ports_scm",(void*)f_1013},
{"f_1016:ports_scm",(void*)f_1016},
{"f_1000:ports_scm",(void*)f_1000},
{"f_1004:ports_scm",(void*)f_1004},
{"f_975:ports_scm",(void*)f_975},
{"f_979:ports_scm",(void*)f_979},
{"f_995:ports_scm",(void*)f_995},
{"f_989:ports_scm",(void*)f_989},
{"f_984:ports_scm",(void*)f_984},
{"f_950:ports_scm",(void*)f_950},
{"f_954:ports_scm",(void*)f_954},
{"f_970:ports_scm",(void*)f_970},
{"f_964:ports_scm",(void*)f_964},
{"f_959:ports_scm",(void*)f_959},
{"f_925:ports_scm",(void*)f_925},
{"f_929:ports_scm",(void*)f_929},
{"f_945:ports_scm",(void*)f_945},
{"f_939:ports_scm",(void*)f_939},
{"f_934:ports_scm",(void*)f_934},
{"f_773:ports_scm",(void*)f_773},
{"f_872:ports_scm",(void*)f_872},
{"f_878:ports_scm",(void*)f_878},
{"f_894:ports_scm",(void*)f_894},
{"f_897:ports_scm",(void*)f_897},
{"f_837:ports_scm",(void*)f_837},
{"f_843:ports_scm",(void*)f_843},
{"f_853:ports_scm",(void*)f_853},
{"f_817:ports_scm",(void*)f_817},
{"f_782:ports_scm",(void*)f_782},
{"f_788:ports_scm",(void*)f_788},
{"f_798:ports_scm",(void*)f_798},
{"f_726:ports_scm",(void*)f_726},
{"f_744:ports_scm",(void*)f_744},
{"f_750:ports_scm",(void*)f_750},
{"f_760:ports_scm",(void*)f_760},
{"f_732:ports_scm",(void*)f_732},
{"f_738:ports_scm",(void*)f_738},
{"f_619:ports_scm",(void*)f_619},
{"f_678:ports_scm",(void*)f_678},
{"f_673:ports_scm",(void*)f_673},
{"f_621:ports_scm",(void*)f_621},
{"f_547:ports_scm",(void*)f_547},
{"f_551:ports_scm",(void*)f_551},
{"f_560:ports_scm",(void*)f_560},
{"f_668:ports_scm",(void*)f_668},
{"f_662:ports_scm",(void*)f_662},
{"f_569:ports_scm",(void*)f_569},
{"f_574:ports_scm",(void*)f_574},
{"f_616:ports_scm",(void*)f_616},
{"f_578:ports_scm",(void*)f_578},
{"f_581:ports_scm",(void*)f_581},
{"f_485:ports_scm",(void*)f_485},
{"f_490:ports_scm",(void*)f_490},
{"f_494:ports_scm",(void*)f_494},
{"f_503:ports_scm",(void*)f_503},
{"f_644:ports_scm",(void*)f_644},
{"f_514:ports_scm",(void*)f_514},
{"f_524:ports_scm",(void*)f_524},
{"f_639:ports_scm",(void*)f_639},
{"f_456:ports_scm",(void*)f_456},
{"f_462:ports_scm",(void*)f_462},
{"f_466:ports_scm",(void*)f_466},
{"f_479:ports_scm",(void*)f_479},
{"f_424:ports_scm",(void*)f_424},
{"f_430:ports_scm",(void*)f_430},
{"f_434:ports_scm",(void*)f_434},
{"f_454:ports_scm",(void*)f_454},
{"f_400:ports_scm",(void*)f_400},
{"f_406:ports_scm",(void*)f_406},
{"f_410:ports_scm",(void*)f_410},
{"f_419:ports_scm",(void*)f_419},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
