/* Generated from csi.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: csi.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file csi.c -extend ./private-namespace.scm
   used units: library eval chicken_syntax ports extras
*/

#include "chicken.h"

#if (defined(_MSC_VER) && defined(_WIN32)) || defined(HAVE_DIRECT_H)
# include <direct.h>
#else
# define _getcwd(buf, len)       NULL
#endif

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[407];
static double C_possibly_force_alignment;


/* from k1457 */
static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub62(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * t0=(void * )C_data_pointer_or_null(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_mpointer(&C_a,(void*)_getcwd(t0,t1));
return C_r;}

C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1276)
static void C_ccall f_1276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1301)
static void C_ccall f_1301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6118)
static void C_ccall f_6118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6127)
static void C_ccall f_6127(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_fcall f_1309(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1445)
static void C_ccall f_1445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6111)
static void C_ccall f_6111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1739)
static void C_ccall f_1739(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1768)
static void C_ccall f_1768(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2439)
static void C_ccall f_2439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2796)
static void C_ccall f_2796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6100)
static void C_ccall f_6100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6106)
static void C_ccall f_6106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_ccall f_6103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5048)
static void C_ccall f_5048(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6094)
static void C_ccall f_6094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2301)
static void C_ccall f_2301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2422)
static void C_ccall f_2422r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2428)
static void C_ccall f_2428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2389)
static void C_ccall f_2389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2397)
static void C_ccall f_2397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2399)
static void C_fcall f_2399(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2416)
static void C_ccall f_2416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2371)
static void C_ccall f_2371(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2377)
static void C_ccall f_2377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2308)
static void C_ccall f_2308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2313)
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2350)
static void C_ccall f_2350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_fcall f_2323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5052)
static void C_ccall f_5052(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6090)
static void C_ccall f_6090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6086)
static void C_ccall f_6086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6073)
static void C_ccall f_6073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5983)
static void C_ccall f_5983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5986)
static void C_ccall f_5986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5989)
static void C_ccall f_5989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5992)
static void C_ccall f_5992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6001)
static void C_ccall f_6001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_fcall f_5064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5977)
static void C_ccall f_5977(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5070)
static void C_fcall f_5070(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5073)
static void C_ccall f_5073(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_fcall f_5076(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5968)
static void C_ccall f_5968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5929)
static void C_ccall f_5929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5931)
static void C_fcall f_5931(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5960)
static void C_ccall f_5960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5922)
static void C_ccall f_5922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5236)
static void C_ccall f_5236(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5910)
static void C_ccall f_5910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5913)
static void C_ccall f_5913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5239)
static void C_ccall f_5239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5242)
static void C_fcall f_5242(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5903)
static void C_ccall f_5903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5896)
static void C_ccall f_5896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5245)
static void C_ccall f_5245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5883)
static void C_ccall f_5883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5248)
static void C_fcall f_5248(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5877)
static void C_ccall f_5877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5251)
static void C_ccall f_5251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5862)
static void C_ccall f_5862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6814)
static void C_ccall f6814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5865)
static void C_ccall f_5865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5868)
static void C_ccall f_5868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5836)
static void C_ccall f_5836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5838)
static void C_fcall f_5838(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5848)
static void C_ccall f_5848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5257)
static void C_ccall f_5257(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5809)
static void C_ccall f_5809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5811)
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5821)
static void C_ccall f_5821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5260)
static void C_ccall f_5260(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5782)
static void C_ccall f_5782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5784)
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5794)
static void C_ccall f_5794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5263)
static void C_ccall f_5263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5743)
static void C_ccall f_5743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5745)
static void C_fcall f_5745(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5704)
static void C_ccall f_5704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5706)
static void C_fcall f_5706(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5735)
static void C_ccall f_5735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5700)
static void C_ccall f_5700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5267)
static void C_ccall f_5267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5270)
static void C_ccall f_5270(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5623)
static void C_ccall f_5623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5626)
static void C_ccall f_5626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5273)
static void C_ccall f_5273(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5611)
static void C_ccall f_5611(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5614)
static void C_ccall f_5614(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5276)
static void C_ccall f_5276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5596)
static void C_ccall f_5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5599)
static void C_ccall f_5599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5602)
static void C_ccall f_5602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5279)
static void C_ccall f_5279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5139)
static void C_ccall f_5139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5161)
static void C_ccall f_5161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5145)
static void C_ccall f_5145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5148)
static void C_ccall f_5148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5282)
static void C_ccall f_5282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_fcall f_5285(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5290)
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5558)
static void C_ccall f_5558(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5513)
static void C_ccall f_5513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5516)
static void C_ccall f_5516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_fcall f_5527(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5543)
static void C_ccall f_5543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5519)
static void C_ccall f_5519(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5522)
static void C_ccall f_5522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5471)
static void C_ccall f_5471r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5461)
static void C_ccall f_5461(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5469)
static void C_ccall f_5469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5440)
static void C_ccall f_5440r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5414)
static void C_ccall f_5414r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5404)
static void C_ccall f_5404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5384)
static void C_ccall f_5384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5368)
static void C_ccall f_5368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5344)
static void C_ccall f_5344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5303)
static void C_ccall f_5303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_fcall f_5166(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5213)
static void C_ccall f_5213(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5173)
static void C_ccall f_5173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5180)
static void C_ccall f_5180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5182)
static void C_fcall f_5182(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5203)
static void C_ccall f_5203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5192)
static void C_ccall f_5192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5199)
static void C_ccall f_5199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5081)
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5087)
static void C_fcall f_5087(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5095)
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4903)
static void C_fcall f_4903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4909)
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4931)
static void C_fcall f_4931(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4988)
static void C_ccall f_4988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4981)
static void C_ccall f_4981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4947)
static void C_ccall f_4947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4970)
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4960)
static void C_ccall f_4960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4964)
static void C_ccall f_4964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static C_word C_fcall f_5020(C_word t0);
C_noret_decl(f_4846)
static void C_fcall f_4846(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4852)
static void C_fcall f_4852(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4864)
static void C_fcall f_4864(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_4791)
static void C_ccall f_4791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4825)
static void C_ccall f_4825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4812)
static void C_ccall f_4812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4749)
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4755)
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4771)
static void C_ccall f_4771(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4781)
static void C_ccall f_4781(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4535)
static void C_fcall f_4535(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4747)
static void C_ccall f_4747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4545)
static void C_fcall f_4545(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4576)
static void C_fcall f_4576(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4631)
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4701)
static void C_ccall f_4701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4639)
static void C_fcall f_4639(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4645)
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4675)
static void C_ccall f_4675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4658)
static void C_ccall f_4658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4604)
static void C_ccall f_4604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4556)
static void C_fcall f_4556(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4478)
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4488)
static void C_fcall f_4488(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4211)
static void C_fcall f_4211(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4237)
static void C_fcall f_4237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4246)
static void C_fcall f_4246(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4274)
static void C_ccall f_4274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4280)
static void C_ccall f_4280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4446)
static void C_fcall f_4446(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4283)
static void C_ccall f_4283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4289)
static void C_ccall f_4289(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4292)
static void C_ccall f_4292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4429)
static void C_ccall f_4429(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4432)
static void C_ccall f_4432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4295)
static void C_ccall f_4295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4298)
static void C_ccall f_4298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4331)
static void C_fcall f_4331(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4398)
static void C_ccall f_4398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4364)
static void C_ccall f_4364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4367)
static void C_ccall f_4367(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4370)
static void C_ccall f_4370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4373)
static void C_ccall f_4373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_ccall f_4376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4214)
static void C_fcall f_4214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4041)
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4054)
static void C_ccall f_4054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4126)
static void C_fcall f_4126(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4180)
static void C_ccall f_4180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4183)
static void C_ccall f_4183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4160)
static void C_fcall f_4160(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4057)
static void C_ccall f_4057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4060)
static void C_ccall f_4060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4075)
static void C_fcall f_4075(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4088)
static void C_ccall f_4088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_ccall f_4063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4066)
static void C_ccall f_4066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4012)
static void C_fcall f_4012(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4032)
static void C_ccall f_4032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3848)
static void C_ccall f_3848r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3961)
static void C_fcall f_3961(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3956)
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3850)
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3875)
static void C_ccall f_3875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_fcall f_3918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3882)
static void C_ccall f_3882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_fcall f_3853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3839)
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3843)
static void C_ccall f_3843(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2798)
static void C_ccall f_2798r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2802)
static void C_ccall f_2802(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3818)
static void C_ccall f_3818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2930)
static void C_ccall f_2930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3065)
static void C_ccall f_3065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static C_word C_fcall f_2764(C_word t0);
C_noret_decl(f_3177)
static void C_fcall f_3177(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3335)
static void C_ccall f_3335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3363)
static void C_ccall f_3363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3372)
static void C_ccall f_3372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3681)
static void C_ccall f_3681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3775)
static void C_ccall f_3775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3736)
static void C_fcall f_3736(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3601)
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3660)
static void C_ccall f_3660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3609)
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_fcall f_3622(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3657)
static void C_ccall f_3657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3649)
static void C_ccall f_3649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3632)
static void C_ccall f_3632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3497)
static void C_ccall f_3497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3500)
static void C_ccall f_3500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3511)
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3534)
static void C_fcall f_3534(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3542)
static void C_fcall f_3542(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3521)
static void C_ccall f_3521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3485)
static void C_ccall f_3485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3295)
static void C_fcall f_3295(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3305)
static void C_ccall f_3305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2725)
static C_word C_fcall f_2725(C_word t0,C_word t1);
C_noret_decl(f_3165)
static void C_ccall f_3165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3081)
static void C_ccall f_3081(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3084)
static void C_ccall f_3084(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3104)
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3072)
static void C_ccall f_3072(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2999)
static void C_ccall f_2999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3005)
static void C_ccall f_3005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2933)
static void C_ccall f_2933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2804)
static void C_ccall f_2804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_2927)
static void C_ccall f_2927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2811)
static void C_ccall f_2811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2816)
static void C_fcall f_2816(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2839)
static void C_ccall f_2839(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2848)
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2912)
static void C_ccall f_2912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2858)
static void C_ccall f_2858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2861)
static void C_ccall f_2861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2448)
static void C_ccall f_2448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2450)
static void C_ccall f_2450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2477)
static void C_ccall f_2477(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2674)
static void C_fcall f_2674(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2703)
static void C_ccall f_2703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2672)
static void C_ccall f_2672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2668)
static void C_ccall f_2668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2591)
static void C_fcall f_2591(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2653)
static void C_ccall f_2653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2599)
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2603)
static void C_ccall f_2603(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2608)
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2639)
static void C_ccall f_2639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2616)
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2628)
static void C_ccall f_2628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2624)
static void C_ccall f_2624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2480)
static void C_ccall f_2480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2508)
static void C_ccall f_2508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2516)
static void C_ccall f_2516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2520)
static void C_ccall f_2520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2524)
static void C_ccall f_2524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2528)
static void C_ccall f_2528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2536)
static void C_ccall f_2536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2462)
static void C_fcall f_2462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2470)
static void C_ccall f_2470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1827)
static void C_fcall f_1827(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2278)
static void C_ccall f_2278r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2282)
static void C_ccall f_2282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2272)
static void C_ccall f_2272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_ccall f_1833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_ccall f_2258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2234)
static void C_ccall f_2234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2242)
static void C_ccall f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2237)
static void C_ccall f_2237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2221)
static void C_ccall f_2221(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2193)
static void C_ccall f_2193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2174)
static void C_ccall f_2174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2162)
static void C_ccall f_2162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2150)
static void C_ccall f_2150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2134)
static void C_ccall f_2134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6690)
static void C_ccall f6690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f6686)
static void C_ccall f6686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2130)
static void C_ccall f_2130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2113)
static void C_ccall f_2113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2045)
static void C_ccall f_2045(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2065)
static void C_ccall f_2065r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2076)
static void C_ccall f_2076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2069)
static void C_ccall f_2069(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2019)
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2029)
static void C_ccall f_2029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2014)
static void C_ccall f_2014(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2002)
static void C_ccall f_2002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1969)
static void C_ccall f_1969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1977)
static void C_fcall f_1977(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1987)
static void C_ccall f_1987(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1972)
static void C_ccall f_1972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1930)
static void C_ccall f_1930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1933)
static void C_ccall f_1933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1936)
static void C_ccall f_1936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1939)
static void C_ccall f_1939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_ccall f_1915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_ccall f_1903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1882)
static void C_ccall f_1882(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1885)
static void C_ccall f_1885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1888)
static void C_ccall f_1888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1859)
static void C_ccall f_1859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1844)
static void C_ccall f_1844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_1770)
static void C_ccall f_1770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_1774)
static void C_ccall f_1774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1761)
static void C_ccall f_1761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1714)
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1673)
static void C_fcall f_1673(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1683)
static void C_ccall f_1683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1689)
static void C_ccall f_1689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1704)
static void C_ccall f_1704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1692)
static void C_ccall f_1692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1657)
static void C_ccall f_1657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1618)
static void C_ccall f_1618(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1642)
static void C_ccall f_1642(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1628)
static void C_fcall f_1628(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1512)
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1516)
static void C_ccall f_1516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_ccall f_1557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1563)
static void C_ccall f_1563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1572)
static void C_fcall f_1572(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1599)
static void C_ccall f_1599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1585)
static void C_ccall f_1585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1550)
static void C_ccall f_1550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static C_word C_fcall f_1491(C_word t0,C_word t1);
C_noret_decl(f_1464)
static void C_fcall f_1464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1471)
static void C_ccall f_1471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1474)
static void C_ccall f_1474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1480)
static void C_ccall f_1480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1414)
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1427)
static void C_fcall f_1427(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1388)
static void C_ccall f_1388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1400)
static void C_ccall f_1400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1355)
static void C_ccall f_1355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1376)
static void C_ccall f_1376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1339)
static void C_ccall f_1339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1343)
static void C_ccall f_1343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1346)
static void C_ccall f_1346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1353)
static void C_ccall f_1353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1311)
static void C_ccall f_1311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1309)
static void C_fcall trf_1309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1309(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1309(t0,t1);}

C_noret_decl(trf_2399)
static void C_fcall trf_2399(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2399(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2399(t0,t1,t2,t3);}

C_noret_decl(trf_2313)
static void C_fcall trf_2313(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2313(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2313(t0,t1,t2);}

C_noret_decl(trf_2323)
static void C_fcall trf_2323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2323(t0,t1);}

C_noret_decl(trf_5064)
static void C_fcall trf_5064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5064(t0,t1);}

C_noret_decl(trf_5070)
static void C_fcall trf_5070(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5070(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5070(t0,t1);}

C_noret_decl(trf_5076)
static void C_fcall trf_5076(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5076(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5076(t0,t1);}

C_noret_decl(trf_5931)
static void C_fcall trf_5931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5931(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5931(t0,t1,t2);}

C_noret_decl(trf_5242)
static void C_fcall trf_5242(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5242(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5242(t0,t1);}

C_noret_decl(trf_5248)
static void C_fcall trf_5248(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5248(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5248(t0,t1);}

C_noret_decl(trf_5838)
static void C_fcall trf_5838(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5838(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5838(t0,t1,t2);}

C_noret_decl(trf_5811)
static void C_fcall trf_5811(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5811(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5811(t0,t1,t2);}

C_noret_decl(trf_5784)
static void C_fcall trf_5784(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5784(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5784(t0,t1,t2);}

C_noret_decl(trf_5745)
static void C_fcall trf_5745(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5745(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5745(t0,t1,t2);}

C_noret_decl(trf_5706)
static void C_fcall trf_5706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5706(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5706(t0,t1,t2);}

C_noret_decl(trf_5285)
static void C_fcall trf_5285(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5285(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5285(t0,t1);}

C_noret_decl(trf_5290)
static void C_fcall trf_5290(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5290(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5290(t0,t1,t2);}

C_noret_decl(trf_5527)
static void C_fcall trf_5527(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5527(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5527(t0,t1,t2);}

C_noret_decl(trf_5166)
static void C_fcall trf_5166(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5166(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5166(t0,t1,t2);}

C_noret_decl(trf_5182)
static void C_fcall trf_5182(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5182(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5182(t0,t1,t2);}

C_noret_decl(trf_5081)
static void C_fcall trf_5081(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5081(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5081(t0,t1,t2);}

C_noret_decl(trf_5087)
static void C_fcall trf_5087(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5087(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5087(t0,t1,t2);}

C_noret_decl(trf_5095)
static void C_fcall trf_5095(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5095(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5095(t0,t1,t2);}

C_noret_decl(trf_4903)
static void C_fcall trf_4903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4903(t0,t1);}

C_noret_decl(trf_4909)
static void C_fcall trf_4909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4909(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4909(t0,t1,t2);}

C_noret_decl(trf_4931)
static void C_fcall trf_4931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4931(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4931(t0,t1);}

C_noret_decl(trf_4846)
static void C_fcall trf_4846(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4846(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4846(t0,t1,t2);}

C_noret_decl(trf_4852)
static void C_fcall trf_4852(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4852(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4852(t0,t1,t2);}

C_noret_decl(trf_4864)
static void C_fcall trf_4864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4864(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4864(t0,t1,t2);}

C_noret_decl(trf_4796)
static void C_fcall trf_4796(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4796(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4796(t0,t1,t2);}

C_noret_decl(trf_4755)
static void C_fcall trf_4755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4755(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4755(t0,t1,t2);}

C_noret_decl(trf_4535)
static void C_fcall trf_4535(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4535(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4535(t0,t1,t2);}

C_noret_decl(trf_4545)
static void C_fcall trf_4545(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4545(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4545(t0,t1);}

C_noret_decl(trf_4576)
static void C_fcall trf_4576(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4576(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4576(t0,t1,t2,t3);}

C_noret_decl(trf_4631)
static void C_fcall trf_4631(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4631(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4631(t0,t1,t2,t3);}

C_noret_decl(trf_4639)
static void C_fcall trf_4639(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4639(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4639(t0,t1,t2,t3);}

C_noret_decl(trf_4645)
static void C_fcall trf_4645(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4645(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4645(t0,t1,t2,t3);}

C_noret_decl(trf_4556)
static void C_fcall trf_4556(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4556(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4556(t0,t1,t2);}

C_noret_decl(trf_4478)
static void C_fcall trf_4478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4478(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4478(t0,t1,t2);}

C_noret_decl(trf_4488)
static void C_fcall trf_4488(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4488(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4488(t0,t1);}

C_noret_decl(trf_4211)
static void C_fcall trf_4211(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4211(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4211(t0,t1,t2);}

C_noret_decl(trf_4237)
static void C_fcall trf_4237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4237(t0,t1);}

C_noret_decl(trf_4246)
static void C_fcall trf_4246(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4246(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4246(t0,t1,t2,t3);}

C_noret_decl(trf_4446)
static void C_fcall trf_4446(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4446(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4446(t0,t1);}

C_noret_decl(trf_4331)
static void C_fcall trf_4331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4331(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4331(t0,t1,t2,t3);}

C_noret_decl(trf_4339)
static void C_fcall trf_4339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4339(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4339(t0,t1,t2,t3);}

C_noret_decl(trf_4354)
static void C_fcall trf_4354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4354(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4354(t0,t1,t2,t3);}

C_noret_decl(trf_4214)
static void C_fcall trf_4214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4214(t0,t1);}

C_noret_decl(trf_4041)
static void C_fcall trf_4041(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4041(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4041(t0,t1,t2);}

C_noret_decl(trf_4126)
static void C_fcall trf_4126(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4126(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4126(t0,t1,t2,t3);}

C_noret_decl(trf_4160)
static void C_fcall trf_4160(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4160(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4160(t0,t1,t2);}

C_noret_decl(trf_4075)
static void C_fcall trf_4075(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4075(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4075(t0,t1,t2,t3);}

C_noret_decl(trf_4012)
static void C_fcall trf_4012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4012(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4012(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3961)
static void C_fcall trf_3961(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3961(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3961(t0,t1);}

C_noret_decl(trf_3956)
static void C_fcall trf_3956(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3956(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3956(t0,t1,t2);}

C_noret_decl(trf_3850)
static void C_fcall trf_3850(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3850(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3850(t0,t1,t2,t3);}

C_noret_decl(trf_3918)
static void C_fcall trf_3918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3918(t0,t1);}

C_noret_decl(trf_3853)
static void C_fcall trf_3853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3853(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3853(t0,t1,t2);}

C_noret_decl(trf_3177)
static void C_fcall trf_3177(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3177(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3177(t0,t1);}

C_noret_decl(trf_3714)
static void C_fcall trf_3714(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3714(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3714(t0,t1,t2);}

C_noret_decl(trf_3736)
static void C_fcall trf_3736(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3736(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3736(t0,t1,t2);}

C_noret_decl(trf_3700)
static void C_fcall trf_3700(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3700(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3700(t0,t1,t2);}

C_noret_decl(trf_3601)
static void C_fcall trf_3601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3601(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3601(t0,t1,t2);}

C_noret_decl(trf_3609)
static void C_fcall trf_3609(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3609(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3609(t0,t1,t2);}

C_noret_decl(trf_3622)
static void C_fcall trf_3622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3622(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3622(t0,t1,t2);}

C_noret_decl(trf_3511)
static void C_fcall trf_3511(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3511(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3511(t0,t1,t2);}

C_noret_decl(trf_3534)
static void C_fcall trf_3534(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3534(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3534(t0,t1,t2);}

C_noret_decl(trf_3542)
static void C_fcall trf_3542(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3542(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3542(t0,t1,t2);}

C_noret_decl(trf_3295)
static void C_fcall trf_3295(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3295(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3295(t0,t1);}

C_noret_decl(trf_3189)
static void C_fcall trf_3189(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3189(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3189(t0,t1,t2,t3);}

C_noret_decl(trf_3104)
static void C_fcall trf_3104(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3104(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3104(t0,t1,t2);}

C_noret_decl(trf_2816)
static void C_fcall trf_2816(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2816(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2816(t0,t1,t2);}

C_noret_decl(trf_2848)
static void C_fcall trf_2848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2848(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2848(t0,t1,t2,t3);}

C_noret_decl(trf_2674)
static void C_fcall trf_2674(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2674(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2674(t0,t1,t2);}

C_noret_decl(trf_2591)
static void C_fcall trf_2591(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2591(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2591(t0,t1,t2);}

C_noret_decl(trf_2599)
static void C_fcall trf_2599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2599(t0,t1,t2);}

C_noret_decl(trf_2608)
static void C_fcall trf_2608(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2608(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2608(t0,t1,t2);}

C_noret_decl(trf_2616)
static void C_fcall trf_2616(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2616(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2616(t0,t1,t2);}

C_noret_decl(trf_2462)
static void C_fcall trf_2462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2462(t0,t1);}

C_noret_decl(trf_1827)
static void C_fcall trf_1827(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1827(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1827(t0,t1);}

C_noret_decl(trf_1977)
static void C_fcall trf_1977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1977(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1977(t0,t1,t2);}

C_noret_decl(trf_1673)
static void C_fcall trf_1673(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1673(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1673(t0,t1,t2);}

C_noret_decl(trf_1628)
static void C_fcall trf_1628(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1628(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1628(t0,t1);}

C_noret_decl(trf_1572)
static void C_fcall trf_1572(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1572(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1572(t0,t1,t2);}

C_noret_decl(trf_1464)
static void C_fcall trf_1464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1464(t0,t1);}

C_noret_decl(trf_1427)
static void C_fcall trf_1427(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1427(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1427(t0,t1);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2642)){
C_save(t1);
C_rereclaim2(2642*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,407);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\006.csirc");
lf[4]=C_h_intern(&lf[4],27,"\003sysrepl-print-length-limit");
lf[5]=C_h_intern(&lf[5],4,"\000csi");
lf[6]=C_h_intern(&lf[6],12,"\003sysfeatures");
lf[7]=C_h_intern(&lf[7],19,"\003sysnotices-enabled");
lf[8]=C_h_intern(&lf[8],14,"editor-command");
lf[11]=C_h_intern(&lf[11],15,"\003csiprint-usage");
lf[12]=C_h_intern(&lf[12],7,"display");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\004V    -b  -batch                    terminate after command-line processing\012 "
"   -w  -no-warnings              disable all warnings\012    -K  -keyword-style STY"
"LE      enable alternative keyword-syntax\012                                   (pr"
"efix, suffix or none)\012        -no-parentheses-synonyms  disables list delimiter "
"synonyms\012        -no-symbol-escape         disables support for escaped symbols\012"
"        -r5rs-syntax              disables the Chicken extensions to\012           "
"                        R5RS syntax\012    -s  -script PATHNAME          use interp"
"reter for shell scripts\012        -ss PATHNAME              shell script with `mai"
"n\047 procedure\012        -sx PATHNAME              same as `-s\047, but print each expr"
"ession\012                                   as it is evaluated\012        -setup-mode"
"               prefer the current directory when locating extensions\012    -R  -re"
"quire-extension NAME   require extension and import before\012                     "
"              executing code\012    -I  -include-path PATHNAME    add PATHNAME to i"
"nclude path\012    --                            ignore all following options\012");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\003 \047\012");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000D    -n  -no-init                  do not load initialization file ` ");
lf[16]=C_h_intern(&lf[16],19,"\003sysprint-to-string");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\003*usage: csi [FILENAME | OPTION ...]\012\012  `csi\047 is the CHICKEN interpreter.\012  \012"
"  FILENAME is a Scheme source file name with optional extension. OPTION may be\012 "
" one of the following:\012\012    -h  -help  --help             display this text and "
"exit\012    -v  -version                  display version and exit\012        -release"
"                  print release number and exit\012    -i  -case-insensitive       "
"  enable case-insensitive reading\012    -e  -eval EXPRESSION          evaluate giv"
"en expression\012    -p  -print EXPRESSION         evaluate and print result(s)\012   "
" -P  -pretty-print EXPRESSION  evaluate and print result(s) prettily\012    -D  -fe"
"ature SYMBOL           register feature identifier\012        -no-feature SYMBOL   "
"     disable built-in feature identifier\012    -q  -quiet                    do no"
"t print banner\012");
lf[18]=C_h_intern(&lf[18],16,"\003csiprint-banner");
lf[19]=C_h_intern(&lf[19],5,"print");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2010 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[22]=C_h_intern(&lf[22],15,"chicken-version");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\007CHICKEN");
lf[24]=C_h_intern(&lf[24],7,"newline");
lf[25]=C_h_intern(&lf[25],9,"read-char");
lf[26]=C_h_intern(&lf[26],4,"read");
lf[27]=C_h_intern(&lf[27],18,"\003sysuser-read-hook");
lf[28]=C_h_intern(&lf[28],5,"quote");
lf[29]=C_h_intern(&lf[29],17,"\003csihistory-count");
lf[30]=C_h_intern(&lf[30],15,"\003csihistory-ref");
lf[31]=C_h_intern(&lf[31],21,"\003syssharp-number-hook");
lf[33]=C_h_intern(&lf[33],9,"substring");
lf[34]=C_h_intern(&lf[34],18,"\003csichop-separator");
lf[35]=C_h_intern(&lf[35],1,"@");
lf[36]=C_h_intern(&lf[36],12,"file-exists\077");
lf[37]=C_h_intern(&lf[37],13,"string-append");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\004.bat");
lf[39]=C_h_intern(&lf[39],22,"\003csilookup-script-file");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[41]=C_h_intern(&lf[41],25,"\003syspeek-nonnull-c-string");
lf[42]=C_h_intern(&lf[42],12,"string-split");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[45]=C_h_intern(&lf[45],24,"get-environment-variable");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\004PATH");
lf[47]=C_h_intern(&lf[47],16,"\003csihistory-list");
lf[48]=C_h_intern(&lf[48],13,"vector-resize");
lf[49]=C_h_intern(&lf[49],15,"\003csihistory-add");
lf[50]=C_h_intern(&lf[50],19,"\003sysundefined-value");
lf[51]=C_h_intern(&lf[51],17,"\003csihistory-clear");
lf[52]=C_h_intern(&lf[52],12,"vector-fill!");
lf[53]=C_h_intern(&lf[53],16,"\003csihistory-show");
lf[54]=C_h_intern(&lf[54],19,"\003sysstandard-output");
lf[55]=C_h_intern(&lf[55],9,"\003sysprint");
lf[56]=C_h_intern(&lf[56],27,"\003syswith-print-length-limit");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[58]=C_h_intern(&lf[58],19,"\003syswrite-char/port");
lf[59]=C_h_intern(&lf[59],9,"\003syserror");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000 history entry index out of range");
lf[61]=C_h_intern(&lf[61],14,"\003csitty-input\077");
lf[62]=C_h_intern(&lf[62],13,"\003systty-port\077");
lf[63]=C_h_intern(&lf[63],18,"\003sysstandard-input");
lf[64]=C_h_intern(&lf[64],18,"\003sysbreak-on-error");
lf[65]=C_h_intern(&lf[65],20,"\003sysread-prompt-hook");
lf[67]=C_h_intern(&lf[67],16,"toplevel-command");
lf[68]=C_h_intern(&lf[68],19,"\003syshash-table-set!");
lf[69]=C_h_intern(&lf[69],4,"eval");
lf[70]=C_h_intern(&lf[70],12,"load-noisily");
lf[71]=C_h_intern(&lf[71],9,"read-line");
lf[72]=C_h_intern(&lf[72],6,"length");
lf[73]=C_h_intern(&lf[73],5,"write");
lf[74]=C_h_intern(&lf[74],6,"printf");
lf[75]=C_h_intern(&lf[75],6,"expand");
lf[76]=C_h_intern(&lf[76],12,"pretty-print");
lf[77]=C_h_intern(&lf[77],8,"integer\077");
lf[78]=C_h_intern(&lf[78],6,"values");
lf[79]=C_h_intern(&lf[79],18,"\003sysrepl-eval-hook");
lf[80]=C_h_intern(&lf[80],4,"exit");
lf[81]=C_h_intern(&lf[81],1,"x");
lf[82]=C_h_intern(&lf[82],16,"\003sysstrip-syntax");
lf[83]=C_h_intern(&lf[83],1,"p");
lf[84]=C_h_intern(&lf[84],1,"d");
lf[85]=C_h_intern(&lf[85],12,"\003csidescribe");
lf[86]=C_h_intern(&lf[86],2,"du");
lf[87]=C_h_intern(&lf[87],8,"\003csidump");
lf[88]=C_h_intern(&lf[88],3,"dur");
lf[89]=C_h_intern(&lf[89],1,"r");
lf[90]=C_h_intern(&lf[90],10,"\003csireport");
lf[91]=C_h_intern(&lf[91],1,"q");
lf[92]=C_h_intern(&lf[92],1,"l");
lf[93]=C_h_intern(&lf[93],4,"load");
lf[94]=C_h_intern(&lf[94],2,"ln");
lf[95]=C_h_intern(&lf[95],6,"print*");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\004==> ");
lf[97]=C_h_intern(&lf[97],8,"\000printer");
lf[98]=C_h_intern(&lf[98],12,"\003sysfor-each");
lf[99]=C_h_intern(&lf[99],1,"t");
lf[100]=C_h_intern(&lf[100],17,"\003sysdisplay-times");
lf[101]=C_h_intern(&lf[101],14,"\003sysstop-timer");
lf[102]=C_h_intern(&lf[102],15,"\003sysstart-timer");
lf[103]=C_h_intern(&lf[103],3,"exn");
lf[104]=C_h_intern(&lf[104],18,"\003syslast-exception");
lf[105]=C_h_intern(&lf[105],1,"e");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000,Editor returned with non-zero exit status ~a");
lf[107]=C_h_intern(&lf[107],6,"system");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[109]=C_h_intern(&lf[109],2,"ch");
lf[110]=C_h_intern(&lf[110],1,"h");
lf[111]=C_h_intern(&lf[111],1,"c");
lf[113]=C_h_intern(&lf[113],1,"f");
lf[115]=C_h_intern(&lf[115],1,"g");
lf[117]=C_h_intern(&lf[117],1,"s");
lf[118]=C_h_intern(&lf[118],1,"\077");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\002 ,");
lf[120]=C_h_intern(&lf[120],23,"\003syshash-table-for-each");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\003\266Toplevel commands:\012\012 ,\077                Show this text\012 ,p EXP            Pr"
"etty print evaluated expression EXP\012 ,d EXP            Describe result of evalua"
"ted expression EXP\012 ,du EXP           Dump data of expression EXP\012 ,dur EXP N   "
"     Dump range\012 ,q                Quit interpreter\012 ,l FILENAME ...   Load one "
"or more files\012 ,ln FILENAME ...  Load one or more files and print result of each"
" top-level expression\012 ,r                Show system information\012 ,h            "
"    Show history of expression results\012 ,ch               Clear history of expre"
"ssion results\012 ,e FILENAME       Run external editor\012 ,s TEXT ...       Execute "
"shell-command\012 ,exn              Describe last exception\012 ,c                Show"
" call-chain of most recent error\012 ,f N              Select frame N\012 ,g NAME     "
"      Get variable NAME from current frame\012 ,t EXP            Evaluate form and "
"print elapsed time\012 ,x EXP            Pretty print expanded expression EXP\012");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\0005Undefined toplevel command ~s - enter `,\077\047 for help~%");
lf[123]=C_h_intern(&lf[123],18,"\003syshash-table-ref");
lf[124]=C_h_intern(&lf[124],7,"unquote");
lf[125]=C_h_intern(&lf[125],4,"chop");
lf[126]=C_h_intern(&lf[126],4,"sort");
lf[127]=C_h_intern(&lf[127],19,"with-output-to-port");
lf[128]=C_h_intern(&lf[128],19,"current-output-port");
lf[129]=C_h_intern(&lf[129],4,"argv");
lf[130]=C_h_intern(&lf[130],8,"truncate");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\025symbol gc is enabled\012");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\027interrupts are enabled\012");
lf[133]=C_h_intern(&lf[133],16,"\003syswrite-char-0");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\010(64-bit)");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[136]=C_decode_literal(C_heaptop,"\376B\000\000\010 (fixed)");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\010downward");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\006upward");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\002\207~%~%~\012                   Machine type:    \011~A ~A~%~\012                   Soft"
"ware type:   \011~A~%~\012                   Software version:\011~A~%~\012                 "
"  Build platform:  \011~A~%~\012                   Installation prefix:\011~A~%~\012        "
"           Extension path:  \011~A~%~\012                   Include path:    \011~A~%~\012  "
"                 Symbol-table load:\011~S~%  ~\012                     Avg bucket leng"
"th:\011~S~%  ~\012                     Total symbol count:\011~S~%~\012                   Me"
"mory:\011heap size is ~S bytes~A with ~S bytes currently in use~%~  \012              "
"       nursery size is ~S bytes, stack grows ~A~%~\012                   Command li"
"ne:    \011~S~%");
lf[141]=C_h_intern(&lf[141],21,"\003sysinclude-pathnames");
lf[142]=C_h_intern(&lf[142],15,"repository-path");
lf[143]=C_h_intern(&lf[143],14,"build-platform");
lf[144]=C_h_intern(&lf[144],16,"software-version");
lf[145]=C_h_intern(&lf[145],13,"software-type");
lf[146]=C_h_intern(&lf[146],12,"machine-type");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\004~a~a");
lf[148]=C_h_intern(&lf[148],11,"make-string");
lf[149]=C_h_intern(&lf[149],5,"fxmax");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003\012  ");
lf[151]=C_h_intern(&lf[151],8,"string<\077");
lf[152]=C_h_intern(&lf[152],15,"keyword->string");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\012Features:\012");
lf[154]=C_h_intern(&lf[154],17,"memory-statistics");
lf[155]=C_h_intern(&lf[155],21,"\003syssymbol-table-info");
lf[156]=C_h_intern(&lf[156],2,"gc");
lf[158]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010u8vector\376\003\000\000\002\376B\000\000\030vector of unsigned bytes\376\003\000\000\002\376\001\000\000\017u8vector-leng"
"th\376\003\000\000\002\376\001\000\000\014u8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010s8vector\376\003\000\000\002\376B\000\000\026vector of signed byt"
"es\376\003\000\000\002\376\001\000\000\017s8vector-length\376\003\000\000\002\376\001\000\000\014s8vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u16vector\376\003\000\000"
"\002\376B\000\000\037vector of unsigned 16-bit words\376\003\000\000\002\376\001\000\000\020u16vector-length\376\003\000\000\002\376\001\000\000\015u16vect"
"or-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s16vector\376\003\000\000\002\376B\000\000\035vector of signed 16-bit words\376\003\000\000\002\376\001\000"
"\000\020s16vector-length\376\003\000\000\002\376\001\000\000\015s16vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011u32vector\376\003\000\000\002\376B\000\000\037ve"
"ctor of unsigned 32-bit words\376\003\000\000\002\376\001\000\000\020u32vector-length\376\003\000\000\002\376\001\000\000\015u32vector-ref\376\377"
"\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011s32vector\376\003\000\000\002\376B\000\000\035vector of signed 32-bit words\376\003\000\000\002\376\001\000\000\020s32vec"
"tor-length\376\003\000\000\002\376\001\000\000\015s32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011f32vector\376\003\000\000\002\376B\000\000\027vector of "
"32-bit floats\376\003\000\000\002\376\001\000\000\020f32vector-length\376\003\000\000\002\376\001\000\000\015f32vector-ref\376\377\016\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"f64vector\376\003\000\000\002\376B\000\000\027vector of 64-bit floats\376\003\000\000\002\376\001\000\000\020f64vector-length\376\003\000\000\002\376\001\000\000\015f6"
"4vector-ref\376\377\016\376\377\016");
lf[160]=C_h_intern(&lf[160],7,"sprintf");
lf[161]=C_h_intern(&lf[161],7,"fprintf");
lf[162]=C_h_intern(&lf[162],8,"list-ref");
lf[163]=C_h_intern(&lf[163],10,"string-ref");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000 ~% (~A elements not displayed)~%");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000.\011(followed by ~A identical instance~a)~% ...~%");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\007 ~S: ~S");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\021~A of length ~S~%");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000$character ~S, code: ~S, #x~X, #o~O~%");
lf[171]=C_decode_literal(C_heaptop,"\376B\000\000\016boolean true~%");
lf[172]=C_decode_literal(C_heaptop,"\376B\000\000\017boolean false~%");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\014empty list~%");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\024end-of-file object~%");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\024unspecified object~%");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\016, character ~S");
lf[177]=C_decode_literal(C_heaptop,"\376B\000\000\042exact integer ~S, #x~X, #o~O, #b~B");
lf[178]=C_h_intern(&lf[178],28,"\003sysarbitrary-unbound-symbol");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\017unbound value~%");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\023inexact number ~S~%");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\013number ~S~%");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\006string");
lf[183]=C_h_intern(&lf[183],8,"\003syssize");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\006vector");
lf[185]=C_h_intern(&lf[185],8,"\003sysslot");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\035keyword symbol with name ~s~%");
lf[187]=C_h_intern(&lf[187],18,"\003syssymbol->string");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\005  ~s\011");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\020  \012properties:\012\012");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\013uninterned ");
lf[192]=C_decode_literal(C_heaptop,"\376B\000\000\012qualified ");
lf[193]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\031~a~asymbol with name ~S~%");
lf[195]=C_h_intern(&lf[195],28,"\003syssymbol->qualified-string");
lf[196]=C_h_intern(&lf[196],20,"\003sysinterned-symbol\077");
lf[197]=C_h_intern(&lf[197],21,"\003sysqualified-symbol\077");
lf[198]=C_decode_literal(C_heaptop,"\376B\000\000\010unbound ");
lf[199]=C_h_intern(&lf[199],32,"\003syssymbol-has-toplevel-binding\077");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\005eol~%");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\012(circle)~%");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\006~S -> ");
lf[203]=C_decode_literal(C_heaptop,"\376B\000\000\024circular structure: ");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\004list");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\036pair with car ~S~%and cdr ~S~%");
lf[206]=C_h_intern(&lf[206],15,"describe-object");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000\036procedure with code pointer ~X");
lf[208]=C_h_intern(&lf[208],25,"\003syspeek-unsigned-integer");
lf[209]=C_h_intern(&lf[209],9,"\000tinyclos");
lf[210]=C_h_intern(&lf[210],19,"\010tinyclosentity-tag");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\005input");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\006output");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\0005~A port of type ~A with name ~S and file pointer ~X~%");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000/locative~%  pointer ~X~%  index ~A~%  type ~A~%");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\004slot");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\010u8vector");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\010s8vector");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\011u16vector");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\011s16vector");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\011u32vector");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\011s32vector");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\011f32vector");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\011f64vector");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\024machine pointer ~X~%");
lf[226]=C_h_intern(&lf[226],11,"\003csihexdump");
lf[227]=C_h_intern(&lf[227],8,"\003sysbyte");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\022blob of size ~S:~%");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\030lambda information: ~s~%");
lf[230]=C_h_intern(&lf[230],23,"\003syslambda-info->string");
lf[231]=C_h_intern(&lf[231],10,"hash-table");
lf[232]=C_decode_literal(C_heaptop,"\376B\000\000\013 ~S\011-> ~S~%");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\025  hash function: ~a~%");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000:hash-table with ~S element~a~%  comparison procedure: ~A~%");
lf[237]=C_h_intern(&lf[237],9,"condition");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\011\011~s: ~s~%");
lf[239]=C_h_intern(&lf[239],4,"cdar");
lf[240]=C_h_intern(&lf[240],4,"caar");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\005 ~s~%");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000\017condition: ~s~%");
lf[243]=C_h_intern(&lf[243],6,"unveil");
lf[244]=C_h_intern(&lf[244],6,"append");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\031structure of type `~S\047:~%");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\020unknown object~%");
lf[247]=C_h_intern(&lf[247],15,"meroon-instance");
lf[248]=C_h_intern(&lf[248],9,"provided\077");
lf[249]=C_h_intern(&lf[249],6,"meroon");
lf[250]=C_h_intern(&lf[250],15,"\003sysbytevector\077");
lf[251]=C_h_intern(&lf[251],13,"\003syslocative\077");
lf[252]=C_h_intern(&lf[252],9,"instance\077");
lf[253]=C_h_intern(&lf[253],5,"port\077");
lf[254]=C_h_intern(&lf[254],8,"keyword\077");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\034statically allocated (0x~X) ");
lf[256]=C_h_intern(&lf[256],17,"\003sysblock-address");
lf[257]=C_h_intern(&lf[257],14,"set-describer!");
lf[258]=C_h_intern(&lf[258],16,"\003syscheck-symbol");
lf[259]=C_h_intern(&lf[259],6,"symbol");
lf[260]=C_h_intern(&lf[260],3,"min");
lf[261]=C_h_intern(&lf[261],4,"dump");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot dump immediate object");
lf[263]=C_h_intern(&lf[263],13,"\003syspeek-byte");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\022cannot dump object");
lf[265]=C_h_intern(&lf[265],10,"write-char");
lf[266]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[267]=C_h_intern(&lf[267],5,"fxmod");
lf[268]=C_h_intern(&lf[268],26,"\003sysrepl-recent-call-chain");
lf[269]=C_h_intern(&lf[269],9,"frameinfo");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\004:\011  ");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\006  ---\012");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\003\011  ");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\002[]");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\016no such frame\012");
lf[278]=C_h_intern(&lf[278],7,"call/cc");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\030no environment in frame\012");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\021no such variable\012");
lf[281]=C_decode_literal(C_heaptop,"\376B\000\000$string or symbol required for `,cf\047\012");
lf[282]=C_h_intern(&lf[282],7,"\003csidel");
lf[283]=C_h_intern(&lf[283],11,"\003csideldups");
lf[284]=C_h_intern(&lf[284],6,"equal\077");
lf[287]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\007-script");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[292]=C_h_intern(&lf[292],6,"string");
lf[293]=C_h_intern(&lf[293],7,"\003sysmap");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\016invalid option");
lf[295]=C_h_intern(&lf[295],16,"\003sysstring->list");
lf[296]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\007-script\376\003\000\000\002\376B\000\000\010-version\376\003\000\000\002\376B\000\000\005-help\376\003\000\000"
"\002\376B\000\000\006--help\376\003\000\000\002\376B\000\000\010-feature\376\003\000\000\002\376B\000\000\013-no-feature\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\021-cas"
"e-insensitive\376\003\000\000\002\376B\000\000\016-keyword-style\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000"
"\021-no-symbol-escape\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\022-require-"
"extension\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\010-no-ini"
"t\376\003\000\000\002\376B\000\000\015-include-path\376\003\000\000\002\376B\000\000\010-release\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pretty-prin"
"t\376\003\000\000\002\376B\000\000\002--\376\377\016");
lf[297]=C_h_intern(&lf[297],7,"\003csirun");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\047missing argument to command-line option");
lf[299]=C_h_intern(&lf[299],8,"\003syslist");
lf[300]=C_h_intern(&lf[300],17,"open-input-string");
lf[301]=C_h_intern(&lf[301],4,"repl");
lf[302]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002--\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\003\000\000\002\376B\000\000\002-n"
"\376\003\000\000\002\376B\000\000\010-no-init\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-"
"insensitive\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\003\000\000\002\376B\000"
"\000\014-r5rs-syntax\376\003\000\000\002\376B\000\000\013-setup-mode\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B"
"\000\000\007-script\376\377\016");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\002-K");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\016-keyword-style");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-R");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\022-require-extension");
lf[312]=C_h_intern(&lf[312],22,"\004corerequire-extension");
lf[313]=C_h_intern(&lf[313],14,"string->symbol");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\002-e");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\005-eval");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\006-print");
lf[318]=C_h_intern(&lf[318],8,"for-each");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-P");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\015-pretty-print");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\003-ss");
lf[322]=C_h_intern(&lf[322],4,"main");
lf[323]=C_h_intern(&lf[323],22,"command-line-arguments");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\003-sx");
lf[325]=C_h_intern(&lf[325],18,"\003sysstandard-error");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\002; ");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\003\012; ");
lf[328]=C_h_intern(&lf[328],12,"flush-output");
lf[329]=C_h_intern(&lf[329],21,"with-output-to-string");
lf[330]=C_h_intern(&lf[330],8,"\003sysload");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000\004HOME");
lf[334]=C_h_intern(&lf[334],17,"\003sysstring-append");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\002./");
lf[336]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-n\376\003\000\000\002\376B\000\000\010-no-init\376\377\016");
lf[337]=C_h_intern(&lf[337],13,"symbol-escape");
lf[338]=C_h_intern(&lf[338],20,"parentheses-synonyms");
lf[339]=C_h_intern(&lf[339],13,"keyword-style");
lf[340]=C_h_intern(&lf[340],5,"\000none");
lf[341]=C_h_intern(&lf[341],14,"case-sensitive");
lf[342]=C_decode_literal(C_heaptop,"\376B\000\000/Disabled the Chicken extensions to R5RS syntax\012");
lf[343]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014-r5rs-syntax\376\377\016");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000%Disabled support for escaped symbols\012");
lf[345]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\021-no-symbol-escape\376\377\016");
lf[346]=C_decode_literal(C_heaptop,"\376B\000\000*Disabled support for parentheses synonyms\012");
lf[347]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\030-no-parentheses-synonyms\376\377\016");
lf[348]=C_decode_literal(C_heaptop,"\376B\000\000\006prefix");
lf[349]=C_h_intern(&lf[349],7,"\000prefix");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\004none");
lf[351]=C_decode_literal(C_heaptop,"\376B\000\000\006suffix");
lf[352]=C_h_intern(&lf[352],7,"\000suffix");
lf[353]=C_decode_literal(C_heaptop,"\376B\000\000+missing argument to `-keyword-style\047 option");
lf[354]=C_h_intern(&lf[354],8,"string=\077");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\002-I");
lf[356]=C_decode_literal(C_heaptop,"\376B\000\000\015-include-path");
lf[357]=C_h_intern(&lf[357],19,"unregister-feature!");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[359]=C_h_intern(&lf[359],17,"register-feature!");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[362]=C_h_intern(&lf[362],16,"case-insensitive");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000-Identifiers and symbols are case insensitive\012");
lf[364]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-i\376\003\000\000\002\376B\000\000\021-case-insensitive\376\377\016");
lf[365]=C_h_intern(&lf[365],12,"load-verbose");
lf[366]=C_h_intern(&lf[366],20,"\003syswarnings-enabled");
lf[367]=C_decode_literal(C_heaptop,"\376B\000\000\026Warnings are disabled\012");
lf[368]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-w\376\003\000\000\002\376B\000\000\014-no-warnings\376\377\016");
lf[369]=C_decode_literal(C_heaptop,"\376B\000\000\010-release");
lf[370]=C_decode_literal(C_heaptop,"\376B\000\000\013-setup-mode");
lf[371]=C_h_intern(&lf[371],14,"\003syssetup-mode");
lf[372]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-v\376\003\000\000\002\376B\000\000\010-version\376\377\016");
lf[373]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-h\376\003\000\000\002\376B\000\000\005-help\376\003\000\000\002\376B\000\000\006--help\376\377\016");
lf[374]=C_decode_literal(C_heaptop,"\376B\000\000\001;");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\024CHICKEN_INCLUDE_PATH");
lf[377]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-q\376\003\000\000\002\376B\000\000\006-quiet\376\377\016");
lf[378]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-b\376\003\000\000\002\376B\000\000\006-batch\376\377\016");
lf[379]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-e\376\003\000\000\002\376B\000\000\002-p\376\003\000\000\002\376B\000\000\002-P\376\003\000\000\002\376B\000\000\005-eval\376\003\000\000\002\376B\000\000\006-print\376\003\000\000\002\376B\000\000\015-pr"
"etty-print\376\377\016");
lf[380]=C_h_intern(&lf[380],20,"\003syswindows-platform");
lf[381]=C_h_intern(&lf[381],6,"script");
lf[382]=C_h_intern(&lf[382],12,"program-name");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\042missing or invalid script argument");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\002--");
lf[385]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\003-ss\376\003\000\000\002\376B\000\000\003-sx\376\003\000\000\002\376B\000\000\002-s\376\003\000\000\002\376B\000\000\007-script\376\377\016");
lf[386]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-K\376\003\000\000\002\376B\000\000\016-keyword-style\376\377\016");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[388]=C_h_intern(&lf[388],17,"get-output-string");
lf[389]=C_h_intern(&lf[389],18,"open-output-string");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\025invalid option syntax");
lf[391]=C_h_intern(&lf[391],7,"reverse");
lf[392]=C_h_intern(&lf[392],22,"with-exception-handler");
lf[393]=C_h_intern(&lf[393],30,"call-with-current-continuation");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\013CSI_OPTIONS");
lf[395]=C_h_intern(&lf[395],25,"\003sysimplicit-exit-handler");
lf[396]=C_h_intern(&lf[396],11,"make-vector");
lf[397]=C_h_intern(&lf[397],17,"\003syspeek-c-string");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\006#;~A> ");
lf[400]=C_h_intern(&lf[400],11,"repl-prompt");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\013emacsclient");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\002vi");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\005EMACS");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\006VISUAL");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\006EDITOR");
lf[406]=C_h_intern(&lf[406],14,"make-parameter");
C_register_lf2(lf,407,create_ptable());
t2=C_mutate(&lf[0] /* (set! c144 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1276,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k1274 */
static void C_ccall f_1276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1277 in k1274 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1280 in k1277 in k1274 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! constant19 ...) */,lf[3]);
t3=C_set_block_item(lf[4] /* repl-print-length-limit */,0,C_fix(2048));
t4=C_a_i_cons(&a,2,lf[5],C_retrieve(lf[6]));
t5=C_mutate((C_word*)lf[6]+1 /* (set! ##sys#features ...) */,t4);
t6=C_set_block_item(lf[7] /* notices-enabled */,0,C_SCHEME_TRUE);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:69: make-parameter */
((C_proc3)C_retrieve_symbol_proc(lf[406]))(3,*((C_word*)lf[406]+1),t7,C_SCHEME_FALSE);}

/* k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1301,2,t0,t1);}
t2=C_mutate((C_word*)lf[8]+1 /* (set! editor-command ...) */,t1);
t3=lf[9] /* selected-frame */ =C_SCHEME_FALSE;;
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:73: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t4,lf[405]);}

/* k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1309(t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6118,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:74: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,lf[404]);}}

/* k6116 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6118,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
f_1309(t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6127,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:75: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t2,lf[403]);}}

/* k6125 in k6116 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6127(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1309(t2,(C_truep(t1)?lf[401]:lf[402]));}

/* k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1309(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1309,NULL,2,t0,t1);}
t2=C_mutate(&lf[10] /* (set! default-editor ...) */,t1);
t3=C_mutate((C_word*)lf[11]+1 /* (set! ##csi#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1311,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[18]+1 /* (set! ##csi#print-banner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1339,tmp=(C_word)a,a+=2,tmp));
t5=*((C_word*)lf[25]+1);
t6=*((C_word*)lf[26]+1);
t7=C_retrieve(lf[27]);
t8=C_mutate((C_word*)lf[27]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1355,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[31]+1 /* (set! ##sys#sharp-number-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1388,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate(&lf[32] /* (set! dirseparator? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1402,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[33]+1);
t12=C_mutate((C_word*)lf[34]+1 /* (set! ##csi#chop-separator ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1414,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_set_block_item(lf[35] /* @ */,0,C_SCHEME_FALSE);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1445,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:190: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[148]+1)))(3,*((C_word*)lf[148]+1),t14,C_fix(256));}

/* k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1464,tmp=(C_word)a,a+=2,tmp);
t3=C_mutate((C_word*)lf[39]+1 /* (set! ##csi#lookup-script-file ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1512,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=C_a_i_vector(&a,32,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4,t4);
t6=C_mutate((C_word*)lf[47]+1 /* (set! ##csi#history-list ...) */,t5);
t7=C_set_block_item(lf[29] /* history-count */,0,C_fix(1));
t8=C_retrieve(lf[48]);
t9=C_mutate((C_word*)lf[49]+1 /* (set! ##csi#history-add ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1618,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[51]+1 /* (set! ##csi#history-clear ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1657,tmp=(C_word)a,a+=2,tmp));
t11=*((C_word*)lf[24]+1);
t12=C_mutate((C_word*)lf[53]+1 /* (set! ##csi#history-show ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t11,tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[30]+1 /* (set! ##csi#history-ref ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1714,tmp=(C_word)a,a+=2,tmp));
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1739,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t15=*((C_word*)lf[160]+1);
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6111,a[2]=t15,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:257: repl-prompt */
((C_proc3)C_retrieve_symbol_proc(lf[400]))(3,*((C_word*)lf[400]+1),t14,t16);}

/* a6110 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6111,2,t0,t1);}
/* csi.scm:260: sprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,t1,lf[399],C_retrieve(lf[29]));}

/* k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1739(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1739,2,t0,t1);}
t2=C_mutate((C_word*)lf[61]+1 /* (set! ##csi#tty-input? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1741,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[64] /* break-on-error */,0,C_SCHEME_FALSE);
t4=C_retrieve(lf[65]);
t5=C_mutate((C_word*)lf[65]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1754,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1768,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:272: make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[396]+1)))(4,*((C_word*)lf[396]+1),t6,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1768(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1768,2,t0,t1);}
t2=C_mutate(&lf[66] /* (set! command-table ...) */,t1);
t3=C_mutate((C_word*)lf[67]+1 /* (set! toplevel-command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1770,tmp=(C_word)a,a+=2,tmp));
t4=C_retrieve(lf[69]);
t5=C_retrieve(lf[70]);
t6=*((C_word*)lf[26]+1);
t7=C_retrieve(lf[71]);
t8=*((C_word*)lf[72]+1);
t9=*((C_word*)lf[12]+1);
t10=*((C_word*)lf[73]+1);
t11=C_retrieve(lf[42]);
t12=*((C_word*)lf[74]+1);
t13=C_retrieve(lf[75]);
t14=C_retrieve(lf[76]);
t15=*((C_word*)lf[77]+1);
t16=*((C_word*)lf[78]+1);
t17=C_mutate((C_word*)lf[79]+1 /* (set! ##sys#repl-eval-hook ...) */,(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1811,a[2]=t9,a[3]=t12,a[4]=t16,a[5]=t5,a[6]=t7,a[7]=t11,a[8]=t4,a[9]=t6,a[10]=t13,a[11]=t14,tmp=(C_word)a,a+=12,tmp));
t18=*((C_word*)lf[74]+1);
t19=C_retrieve(lf[125]);
t20=C_retrieve(lf[126]);
t21=C_retrieve(lf[127]);
t22=*((C_word*)lf[128]+1);
t23=C_retrieve(lf[129]);
t24=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2436,a[2]=((C_word*)t0)[2],a[3]=t22,a[4]=t21,a[5]=t20,a[6]=t19,a[7]=t23,a[8]=t18,tmp=(C_word)a,a+=9,tmp);
/* csi.scm:438: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t24,lf[398]);}

/* k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2439,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t1)){
t3=t2;
f_2439(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[397]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_PREFIX),C_fix(0));}}

/* k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2439,2,t0,t1);}
t2=C_mutate((C_word*)lf[90]+1 /* (set! ##csi#report ...) */,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2440,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=t1,a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t3=C_mutate(&lf[157] /* (set! ##csi#bytevector-data ...) */,lf[158]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2796,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:522: make-vector */
((C_proc4)C_retrieve_proc(*((C_word*)lf[396]+1)))(4,*((C_word*)lf[396]+1),t4,C_fix(37),C_SCHEME_END_OF_LIST);}

/* k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2796,2,t0,t1);}
t2=C_mutate(&lf[159] /* (set! describer-table ...) */,t1);
t3=*((C_word*)lf[160]+1);
t4=*((C_word*)lf[74]+1);
t5=C_retrieve(lf[161]);
t6=*((C_word*)lf[72]+1);
t7=*((C_word*)lf[162]+1);
t8=*((C_word*)lf[163]+1);
t9=C_mutate((C_word*)lf[85]+1 /* (set! ##csi#describe ...) */,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2798,a[2]=t3,a[3]=t7,a[4]=t6,a[5]=t4,a[6]=t8,a[7]=t5,tmp=(C_word)a,a+=8,tmp));
t10=C_mutate((C_word*)lf[257]+1 /* (set! set-describer! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3839,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[87]+1 /* (set! ##csi#dump ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3848,tmp=(C_word)a,a+=2,tmp));
t12=*((C_word*)lf[12]+1);
t13=*((C_word*)lf[37]+1);
t14=*((C_word*)lf[148]+1);
t15=*((C_word*)lf[265]+1);
t16=C_mutate((C_word*)lf[226]+1 /* (set! ##csi#hexdump ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4009,a[2]=t12,a[3]=t15,a[4]=t14,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t17=*((C_word*)lf[265]+1);
t18=*((C_word*)lf[24]+1);
t19=*((C_word*)lf[12]+1);
t20=C_mutate(&lf[112] /* (set! show-frameinfo ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4211,a[2]=t19,a[3]=t18,tmp=(C_word)a,a+=4,tmp));
t21=*((C_word*)lf[12]+1);
t22=C_mutate(&lf[114] /* (set! select-frame ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4478,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t23=*((C_word*)lf[12]+1);
t24=*((C_word*)lf[278]+1);
t25=C_mutate(&lf[116] /* (set! copy-from-frame ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4535,a[2]=t24,a[3]=t23,tmp=(C_word)a,a+=4,tmp));
t26=C_mutate((C_word*)lf[282]+1 /* (set! ##csi#del ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4749,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[283]+1 /* (set! ##csi#deldups ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4787,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate(&lf[285] /* (set! member* ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4846,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate(&lf[286] /* (set! canonicalize-args ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4903,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[297]+1 /* (set! ##csi#run ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5048,tmp=(C_word)a,a+=2,tmp));
t31=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1079: run */
((C_proc2)C_retrieve_symbol_proc(lf[297]))(2,*((C_word*)lf[297]+1),t31);}

/* k6098 in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6106,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[395]))(2,*((C_word*)lf[395]+1),t3);}

/* k6104 in k6098 in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k6101 in k6098 in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5048(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5048,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5052,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6094,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:929: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,lf[394]);}

/* k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6094,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[387]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2301,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:415: open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t3,t2);}

/* k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2301,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2308,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2365,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[393]+1)))(3,*((C_word*)lf[393]+1),t6,t7);}

/* a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2365,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2371,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[392]))(4,*((C_word*)lf[392]+1),t1,t3,t4);}

/* a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2389,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2421 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2422(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2422r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2422r(t0,t1,t2);}}

static void C_ccall f_2422r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2428,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k289293 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2427 in a2421 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2428,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2388 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2389,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2397,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:423: read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2]);}

/* k2395 in a2388 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2397,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2399,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2399(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* doloop295 in k2395 in a2388 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2399(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2399,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_eofp(t2))){
/* csi.scm:425: reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[391]+1)))(3,*((C_word*)lf[391]+1),t1,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2416,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:423: read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t4,((C_word*)t0)[2]);}}

/* k2414 in doloop295 in k2395 in a2388 in a2382 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2416,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_2399(t3,((C_word*)t0)[2],t1,t2);}

/* a2370 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2371(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2371,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2377,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* k289293 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2376 in a2370 in a2364 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2377,2,t0,t1);}
/* csi.scm:422: ##sys#error */
t2=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[390],((C_word*)t0)[2]);}

/* k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g291292 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2311,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2313,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2313(t5,((C_word*)t0)[2],t1);}

/* loop265 in k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2313(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2313,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2323,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
if(C_truep(C_i_stringp(t5))){
t6=t3;
f_2323(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2350,a[2]=t5,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:419: open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[389]))(2,*((C_word*)lf[389]+1),t6);}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2348 in loop265 in k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2350,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:420: write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,((C_word*)t0)[2],t1);}

/* k2351 in k2348 in loop265 in k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:421: get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[388]))(3,*((C_word*)lf[388]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2357 in loop265 in k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2359,2,t0,t1);}
t2=((C_word*)t0)[2];
f_2323(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k2321 in loop265 in k2309 in k2306 in k2299 in k6092 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop265278 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2313(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop265278 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2313(t5,((C_word*)t0)[3],t4);}}

/* k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5052(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5052,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5055,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6090,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:930: command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[323]))(2,*((C_word*)lf[323]+1),t3);}

/* k6088 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:930: canonicalize-args */
f_4903(((C_word*)t0)[2],t1);}

/* k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:932: member* */
f_4846(t4,lf[386],((C_word*)t3)[1]);}

/* k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:933: member* */
f_4846(t2,lf[385],((C_word*)((C_word*)t0)[4])[1]);}

/* k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5983,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(t1);
t5=C_i_pairp(t4);
t6=C_i_not(t5);
if(C_truep(t6)){
if(C_truep(t6)){
/* csi.scm:938: ##sys#error */
t7=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t3,lf[383]);}
else{
t7=t3;
f_5983(2,t7,C_SCHEME_UNDEFINED);}}
else{
t7=C_i_cadr(t1);
t8=C_i_string_length(t7);
t9=C_i_zerop(t8);
if(C_truep(t9)){
if(C_truep(t9)){
/* csi.scm:938: ##sys#error */
t10=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t3,lf[383]);}
else{
t10=t3;
f_5983(2,t10,C_SCHEME_UNDEFINED);}}
else{
t10=C_i_cadr(t1);
t11=C_i_string_ref(t10,C_fix(0));
t12=C_eqp(C_make_character(45),t11);
if(C_truep(t12)){
/* csi.scm:938: ##sys#error */
t13=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t3,lf[383]);}
else{
t13=t3;
f_5983(2,t13,C_SCHEME_UNDEFINED);}}}}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6073,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6086,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:947: canonicalize-args */
f_4903(t4,((C_word*)t0)[2]);}}

/* k6084 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:947: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[244]+1)))(4,*((C_word*)lf[244]+1),((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k6071 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=C_i_member(lf[384],((C_word*)((C_word*)t0)[3])[1]);
t4=((C_word*)t0)[2];
f_5064(t4,(C_truep(t3)?C_i_set_cdr(t3,C_SCHEME_END_OF_LIST):C_SCHEME_FALSE));}

/* k5981 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm:939: program-name */
((C_proc3)C_retrieve_symbol_proc(lf[382]))(3,*((C_word*)lf[382]+1),t2,t3);}

/* k5984 in k5981 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cddr(((C_word*)t0)[3]);
/* csi.scm:940: command-line-arguments */
((C_proc3)C_retrieve_symbol_proc(lf[323]))(3,*((C_word*)lf[323]+1),t2,t3);}

/* k5987 in k5984 in k5981 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5992,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:941: register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,lf[381]);}

/* k5990 in k5987 in k5984 in k5981 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5992,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[3]);
t3=C_i_set_cdr(t2,C_SCHEME_END_OF_LIST);
if(C_truep(*((C_word*)lf[380]+1))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm:944: lookup-script-file */
((C_proc3)C_retrieve_symbol_proc(lf[39]))(3,*((C_word*)lf[39]+1),t4,t5);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[2];
f_5064(t5,t4);}}

/* k5999 in k5990 in k5987 in k5984 in k5981 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_6001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
f_5064(t3,C_i_set_car(t2,t1));}
else{
t2=((C_word*)t0)[2];
f_5064(t2,C_SCHEME_FALSE);}}

/* k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5064,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:950: member* */
f_4846(t2,lf[379],((C_word*)((C_word*)t0)[5])[1]);}

/* k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5070,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_5070(t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5977,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:951: member* */
f_4846(t3,lf[378],((C_word*)((C_word*)t0)[5])[1]);}}

/* k5975 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5977(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_5070(t3,t2);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
f_5070(t3,t2);}}

/* k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5070(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5070,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5073,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:952: member* */
f_4846(t2,lf[377],((C_word*)((C_word*)t0)[6])[1]);}

/* k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5073(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5073,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5076,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_5076(t3,((C_word*)t0)[5]);}
else{
if(C_truep(t1)){
t3=t1;
t4=t2;
f_5076(t4,t3);}
else{
t3=((C_word*)t0)[2];
t4=t2;
f_5076(t4,t3);}}}

/* k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5076(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5076,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5079,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5929,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5968,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:954: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t8,lf[376]);}

/* k5966 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm:954: string-split */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],t2,lf[374]);}
else{
/* csi.scm:954: string-split */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),((C_word*)t0)[2],lf[375],lf[374]);}}

/* k5927 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5929,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5931,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5931(t5,((C_word*)t0)[2],t1);}

/* loop952 in k5927 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5931(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5931,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[34]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5960,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g968969 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5958 in loop952 in k5927 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5960,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop952965 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5931(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop952965 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5931(t6,((C_word*)t0)[3],t5);}}

/* k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5079,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5081,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp));
t7=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5166,tmp=(C_word)a,a+=2,tmp));
t8=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5236,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=t5,a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5919,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:976: member* */
f_4846(t9,lf[373],((C_word*)((C_word*)t0)[7])[1]);}

/* k5917 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5922,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:977: print-usage */
((C_proc2)C_retrieve_symbol_proc(lf[11]))(2,*((C_word*)lf[11]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5236(2,t2,C_SCHEME_UNDEFINED);}}

/* k5920 in k5917 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:978: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),((C_word*)t0)[2],C_fix(0));}

/* k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5236(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5236,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5910,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:979: member* */
f_4846(t3,lf[372],((C_word*)((C_word*)t0)[6])[1]);}

/* k5908 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5910,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5913,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:980: print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),t2);}
else{
t2=((C_word*)t0)[2];
f_5239(2,t2,C_SCHEME_UNDEFINED);}}

/* k5911 in k5908 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:981: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),((C_word*)t0)[2],C_fix(0));}

/* k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5242,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_member(lf[370],((C_word*)((C_word*)t0)[6])[1]))){
t3=C_set_block_item(lf[371] /* setup-mode */,0,C_SCHEME_TRUE);
t4=t2;
f_5242(t4,t3);}
else{
t3=t2;
f_5242(t3,C_SCHEME_UNDEFINED);}}

/* k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5242(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5242,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5245,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(C_i_member(lf[369],((C_word*)((C_word*)t0)[6])[1]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5896,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5903,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:985: chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[22]))(2,*((C_word*)lf[22]+1),t4);}
else{
t3=t2;
f_5245(2,t3,C_SCHEME_UNDEFINED);}}

/* k5901 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:985: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),((C_word*)t0)[2],t1);}

/* k5894 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:986: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),((C_word*)t0)[2],C_fix(0));}

/* k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5245,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5883,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:987: member* */
f_4846(t3,lf[368],((C_word*)((C_word*)t0)[6])[1]);}

/* k5881 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5883,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_set_block_item(lf[366] /* warnings-enabled */,0,C_SCHEME_FALSE);
t4=((C_word*)t0)[3];
f_5248(t4,t3);}
else{
/* csi.scm:988: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[367]);}}
else{
t2=((C_word*)t0)[3];
f_5248(t2,C_SCHEME_UNDEFINED);}}

/* k5884 in k5881 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(lf[366] /* warnings-enabled */,0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
f_5248(t3,t2);}

/* k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5248(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5248,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_5251(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5877,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:991: load-verbose */
((C_proc3)C_retrieve_symbol_proc(lf[365]))(3,*((C_word*)lf[365]+1),t3,C_SCHEME_TRUE);}}

/* k5875 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:992: print-banner */
((C_proc2)C_retrieve_symbol_proc(lf[18]))(2,*((C_word*)lf[18]+1),((C_word*)t0)[2]);}

/* k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5862,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:993: member* */
f_4846(t3,lf[364],((C_word*)((C_word*)t0)[6])[1]);}

/* k5860 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5862,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5865,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f6814,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:995: register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t3,lf[362]);}
else{
/* csi.scm:994: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[363]);}}
else{
t2=((C_word*)t0)[3];
f_5254(2,t2,C_SCHEME_UNDEFINED);}}

/* f6814 in k5860 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f6814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:996: case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5863 in k5860 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5868,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:995: register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[359]))(3,*((C_word*)lf[359]+1),t2,lf[362]);}

/* k5866 in k5863 in k5860 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:996: case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5254,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5257,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5836,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:997: collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5081(t4,t3,lf[361]);}

/* k5834 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5836,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5838,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5838(t5,((C_word*)t0)[2],t1);}

/* loop1024 in k5834 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5838(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5838,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[359]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5848,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10311032 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5846 in loop1024 in k5834 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5838(t3,((C_word*)t0)[2],t2);}

/* k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5257(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5257,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5260,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5809,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:998: collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5081(t4,t3,lf[360]);}

/* k5807 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5809,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5811,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5811(t5,((C_word*)t0)[2],t1);}

/* loop1037 in k5807 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5811(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5811,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[359]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5821,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10441045 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5819 in loop1037 in k5807 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5811(t3,((C_word*)t0)[2],t2);}

/* k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5260(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5260,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5263,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5782,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:999: collect-options */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5081(t4,t3,lf[358]);}

/* k5780 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5782,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5784,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5784(t5,((C_word*)t0)[2],t1);}

/* loop1050 in k5780 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5784(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5784,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[357]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5794,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g10571058 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5792 in loop1050 in k5780 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5784(t3,((C_word*)t0)[2],t2);}

/* k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5263,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5267,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5743,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1002: collect-options */
t10=((C_word*)((C_word*)t0)[2])[1];
f_5081(t10,t9,lf[356]);}

/* k5741 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5743,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5745,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5745(t5,((C_word*)t0)[2],t1);}

/* loop1063 in k5741 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5745(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5745,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[34]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g10791080 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5772 in loop1063 in k5741 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10631076 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5745(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10631076 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5745(t6,((C_word*)t0)[3],t5);}}

/* k5694 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5696,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5700,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5704,a[2]=t6,a[3]=t3,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:1003: collect-options */
t8=((C_word*)((C_word*)t0)[2])[1];
f_5081(t8,t7,lf[355]);}

/* k5702 in k5694 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5704,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5706,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5706(t5,((C_word*)t0)[2],t1);}

/* loop1086 in k5702 in k5694 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5706(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5706,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[34]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5735,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g11021103 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5733 in loop1086 in k5702 in k5694 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5735,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10861099 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5706(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10861099 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5706(t6,((C_word*)t0)[3],t5);}}

/* k5698 in k5694 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1002: append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[244]+1)))(6,*((C_word*)lf[244]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,C_retrieve(lf[141]),((C_word*)t0)[2]);}

/* k5690 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1001: deldups */
((C_proc4)C_retrieve_symbol_proc(lf[283]))(4,*((C_word*)lf[283]+1),((C_word*)t0)[2],t1,*((C_word*)lf[354]+1));}

/* k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5267,2,t0,t1);}
t2=C_mutate((C_word*)lf[141]+1 /* (set! ##sys#include-pathnames ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5270,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=C_i_cdr(((C_word*)t0)[2]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[348],t5))){
/* csi.scm:1011: keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t3,lf[349]);}
else{
t6=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[350],t6))){
/* csi.scm:1013: keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t3,lf[340]);}
else{
t7=C_i_cadr(((C_word*)t0)[2]);
if(C_truep(C_i_string_equal_p(lf[351],t7))){
/* csi.scm:1015: keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t3,lf[352]);}
else{
t8=t3;
f_5270(2,t8,C_SCHEME_UNDEFINED);}}}}
else{
/* csi.scm:1009: ##sys#error */
t5=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,lf[353]);}}
else{
t4=t3;
f_5270(2,t4,C_SCHEME_UNDEFINED);}}

/* k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5270(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5270,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5273,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5623,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1016: member* */
f_4846(t3,lf[347],((C_word*)((C_word*)t0)[3])[1]);}

/* k5621 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5623,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5626,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:1018: parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm:1017: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[346]);}}
else{
t2=((C_word*)t0)[3];
f_5273(2,t2,C_SCHEME_UNDEFINED);}}

/* k5624 in k5621 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1018: parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5273(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5273,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5611,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1019: member* */
f_4846(t3,lf[345],((C_word*)((C_word*)t0)[3])[1]);}

/* k5609 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5611(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5611,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5614,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:1021: symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
/* csi.scm:1020: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[344]);}}
else{
t2=((C_word*)t0)[3];
f_5276(2,t2,C_SCHEME_UNDEFINED);}}

/* k5612 in k5609 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5614(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1021: symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5279,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1022: member* */
f_4846(t3,lf[343],((C_word*)((C_word*)t0)[3])[1]);}

/* k5588 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_5593(2,t3,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:1023: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[342]);}}
else{
t2=((C_word*)t0)[3];
f_5279(2,t2,C_SCHEME_UNDEFINED);}}

/* k5591 in k5588 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5593,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5596,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1024: case-sensitive */
((C_proc3)C_retrieve_symbol_proc(lf[341]))(3,*((C_word*)lf[341]+1),t2,C_SCHEME_FALSE);}

/* k5594 in k5591 in k5588 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5596,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1025: keyword-style */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t2,lf[340]);}

/* k5597 in k5594 in k5591 in k5588 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5599,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5602,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1026: parentheses-synonyms */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t2,C_SCHEME_FALSE);}

/* k5600 in k5597 in k5594 in k5591 in k5588 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1027: symbol-escape */
((C_proc3)C_retrieve_symbol_proc(lf[337]))(3,*((C_word*)lf[337]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5282,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5581,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1028: member* */
f_4846(t3,lf[336],((C_word*)((C_word*)t0)[2])[1]);}

/* k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(C_truep(t1)?t1:((C_word*)t0)[3]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_5282(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:964: ##sys#string-append */
((C_proc4)C_retrieve_symbol_proc(lf[334]))(4,*((C_word*)lf[334]+1),t3,lf[335],lf[2]);}}

/* k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5139,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:965: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t2,t1);}

/* k5137 in k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5139,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:966: load */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5145,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5161,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:967: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,lf[333]);}}

/* k5159 in k5137 in k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* csi.scm:967: chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),((C_word*)t0)[2],t2);}
else{
/* csi.scm:967: chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),((C_word*)t0)[2],lf[332]);}}

/* k5143 in k5137 in k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5148,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:968: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),t2,t1,lf[331],lf[2]);}

/* k5146 in k5143 in k5137 in k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5154,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:969: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t2,t1);}

/* k5152 in k5146 in k5143 in k5137 in k5131 in k5579 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* csi.scm:970: load */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
f_5282(2,t2,C_SCHEME_UNDEFINED);}}

/* k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
t3=C_set_block_item(lf[7] /* notices-enabled */,0,C_SCHEME_FALSE);
t4=t2;
f_5285(t4,t3);}
else{
t3=t2;
f_5285(t3,C_SCHEME_UNDEFINED);}}

/* k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5285(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5285,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5290,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5290(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5290(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(17);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5290,NULL,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(((C_word*)t3)[1]))){
if(C_truep(((C_word*)t0)[5])){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5303,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1034: repl */
((C_proc2)C_retrieve_symbol_proc(lf[301]))(2,*((C_word*)lf[301]+1),t4);}}
else{
t4=C_i_car(((C_word*)t3)[1]);
t5=C_i_member(t4,lf[302]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5315,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t7;
t1=t35;
t2=t36;
goto loop;}
else{
if(C_truep((C_truep(C_i_equalp(t4,lf[303]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[304]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[305]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[306]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[307]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[308]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t4,lf[309]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))))){
t7=C_i_cdr(((C_word*)t3)[1]);
t8=C_set_block_item(t3,0,t7);
t9=C_i_cdr(((C_word*)t3)[1]);
t35=t1;
t36=t9;
t1=t35;
t2=t36;
goto loop;}
else{
t7=C_i_string_equal_p(lf[310],t4);
t8=(C_truep(t7)?t7:C_i_string_equal_p(lf[311],t4));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5344,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5368,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
t11=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1041: string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[313]+1)))(3,*((C_word*)lf[313]+1),t10,t11);}
else{
t9=C_i_string_equal_p(lf[314],t4);
t10=(C_truep(t9)?t9:C_i_string_equal_p(lf[315],t4));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5384,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t12=C_i_cadr(((C_word*)t3)[1]);
/* csi.scm:1044: evalstring */
f_5166(t11,t12,C_SCHEME_END_OF_LIST);}
else{
t11=C_i_string_equal_p(lf[316],t4);
t12=(C_truep(t11)?t11:C_i_string_equal_p(lf[317],t4));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5404,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t14=C_i_cadr(((C_word*)t3)[1]);
t15=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5414,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1047: evalstring */
f_5166(t13,t14,C_a_i_list(&a,1,t15));}
else{
t13=C_i_string_equal_p(lf[319],t4);
t14=(C_truep(t13)?t13:C_i_string_equal_p(lf[320],t4));
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5430,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
t16=C_i_cadr(((C_word*)t3)[1]);
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5440,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1050: evalstring */
f_5166(t15,t16,C_a_i_list(&a,1,t17));}
else{
t15=(C_truep(((C_word*)t0)[2])?C_i_car(((C_word*)t0)[2]):C_SCHEME_FALSE);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5450,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t6,a[6]=t15,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_equalp(lf[324],t15))){
t17=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5503,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1054: ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[330]))(5,*((C_word*)lf[330]+1),t16,t4,t17,C_SCHEME_FALSE);}
else{
/* csi.scm:1054: ##sys#load */
((C_proc5)C_retrieve_symbol_proc(lf[330]))(5,*((C_word*)lf[330]+1),t16,t4,C_SCHEME_FALSE,C_SCHEME_FALSE);}}}}}}}}}

/* f_5503 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5503,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5558,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:1058: with-output-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[329]))(3,*((C_word*)lf[329]+1),t3,t4);}

/* a5557 */
static void C_ccall f_5558(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5558,2,t0,t1);}
t2=C_retrieve(lf[76]);
/* g11661167 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,((C_word*)t0)[2]);}

/* k5505 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5513,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1060: flush-output */
((C_proc3)C_retrieve_proc(*((C_word*)lf[328]+1)))(3,*((C_word*)lf[328]+1),t3,*((C_word*)lf[54]+1));}

/* k5511 in k5505 */
static void C_ccall f_5513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5513,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:1061: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,lf[327],*((C_word*)lf[325]+1));}

/* k5514 in k5511 in k5505 */
static void C_ccall f_5516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5519,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5527,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_5527(t6,t2,C_fix(0));}

/* doloop1169 in k5514 in k5511 in k5505 */
static void C_fcall f_5527(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5527,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5540,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t5=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,*((C_word*)lf[325]+1));}}

/* k5538 in doloop1169 in k5514 in k5511 in k5505 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5540,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5543,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(C_make_character(10),((C_word*)t0)[2]);
if(C_truep(t3)){
/* csi.scm:1067: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,lf[326],*((C_word*)lf[325]+1));}
else{
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t5=((C_word*)((C_word*)t0)[4])[1];
f_5527(t5,((C_word*)t0)[3],t4);}}

/* k5541 in k5538 in doloop1169 in k5514 in k5511 in k5505 */
static void C_ccall f_5543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5527(t3,((C_word*)t0)[2],t2);}

/* k5517 in k5514 in k5511 in k5505 */
static void C_ccall f_5519(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5519,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5522,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1068: newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t2,*((C_word*)lf[325]+1));}

/* k5520 in k5517 in k5514 in k5511 in k5505 */
static void C_ccall f_5522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1069: eval */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5448 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
if(C_truep(C_i_equalp(lf[321],((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5461,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5471,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:1072: call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t2,t3);}
else{
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5290(t3,((C_word*)t0)[2],t2);}}

/* a5470 in k5448 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5471(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5471r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5471r(t0,t1,t2);}}

static void C_ccall f_5471r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
if(C_truep(C_i_pairp(t2))){
t3=C_i_car(t2);
if(C_truep(C_fixnump(t3))){
t4=C_i_car(t2);
/* csi.scm:1074: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t1,t4);}
else{
/* csi.scm:1074: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t1,C_fix(0));}}
else{
/* csi.scm:1074: exit */
((C_proc3)C_retrieve_symbol_proc(lf[80]))(3,*((C_word*)lf[80]+1),t1,C_fix(0));}}

/* a5460 in k5448 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5461(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5461,2,t0,t1);}
t2=C_retrieve(lf[322]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5469,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:1072: command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[323]))(2,*((C_word*)lf[323]+1),t3);}

/* k5467 in a5460 in k5448 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g11821183 */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* a5439 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5440(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5440r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5440r(t0,t1,t2);}}

static void C_ccall f_5440r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),C_retrieve(lf[76]),t2);}

/* k5428 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5290(t5,((C_word*)t0)[2],t4);}

/* a5413 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5414(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+0)){
C_save_and_reclaim((void*)tr2r,(void*)f_5414r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5414r(t0,t1,t2);}}

static void C_ccall f_5414r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_apply(5,0,t1,*((C_word*)lf[318]+1),*((C_word*)lf[19]+1),t2);}

/* k5402 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5290(t5,((C_word*)t0)[2],t4);}

/* k5382 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5290(t5,((C_word*)t0)[2],t4);}

/* k5366 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5368,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,C_SCHEME_TRUE,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t2,t3);
t5=C_a_i_cons(&a,2,lf[312],t4);
/* csi.scm:1041: eval */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),((C_word*)t0)[2],t5);}

/* k5342 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,t2);
t4=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t5=((C_word*)((C_word*)t0)[3])[1];
f_5290(t5,((C_word*)t0)[2],t4);}

/* k5313 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)((C_word*)t0)[4])[1]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_5290(t3,((C_word*)t0)[2],t2);}

/* k5301 in doloop1119 in k5283 in k5280 in k5277 in k5274 in k5271 in k5268 in k5265 in k5261 in k5258 in k5255 in k5252 in k5249 in k5246 in k5243 in k5240 in k5237 in k5234 in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:1035: ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[54]+1));}

/* evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5166(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5166,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5170,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_5170(2,t5,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5213,tmp=(C_word)a,a+=2,tmp));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5170(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* f_5213 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5213(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5213,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5173,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:972: open-input-string */
((C_proc3)C_retrieve_symbol_proc(lf[300]))(3,*((C_word*)lf[300]+1),t2,((C_word*)t0)[2]);}

/* k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:973: read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,t1);}

/* k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5180,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5182,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5182(t5,((C_word*)t0)[2],t1);}

/* doloop1010 in k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5182(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5182,NULL,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5192,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5203,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5205,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,*((C_word*)lf[299]+1));}}

/* a5204 in doloop1010 in k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
/* csi.scm:975: eval */
((C_proc3)C_retrieve_symbol_proc(lf[69]))(3,*((C_word*)lf[69]+1),t1,((C_word*)t0)[2]);}

/* k5201 in doloop1010 in k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:975: rec */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k5190 in doloop1010 in k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5192,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:973: read */
((C_proc3)C_retrieve_proc(*((C_word*)lf[26]+1)))(3,*((C_word*)lf[26]+1),t2,((C_word*)t0)[2]);}

/* k5197 in k5190 in doloop1010 in k5178 in k5171 in k5168 in evalstring in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
f_5182(t2,((C_word*)t0)[2],t1);}

/* collect-options in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5081(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5081,NULL,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5087,a[2]=t4,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_5087(t6,t1,((C_word*)((C_word*)t0)[2])[1]);}

/* loop in collect-options in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5087(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5087,NULL,3,t0,t1,t2);}
t3=C_i_member(((C_word*)t0)[3],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* g987988 */
t5=t4;
f_5095(t5,t1,t3);}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}}

/* g987 in loop in collect-options in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_5095(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5095,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* csi.scm:960: ##sys#error */
t4=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[298],((C_word*)t0)[3]);}
else{
t4=C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5116,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cddr(t2);
/* csi.scm:961: loop */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5087(t7,t5,t6);}}

/* k5114 in g987 in loop in collect-options in k5077 in k5074 in k5071 in k5068 in k5065 in k5062 in k5059 in k5056 in k5053 in k5050 in ##csi#run in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4903(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4903,NULL,2,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4909,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4909(t6,t1,t2);}

/* loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4909(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4909,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
if(C_truep((C_truep(C_i_equalp(t3,lf[287]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[288]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[289]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[290]))?C_SCHEME_TRUE:(C_truep(C_i_equalp(t3,lf[291]))?C_SCHEME_TRUE:C_SCHEME_FALSE))))))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4931,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t5=C_block_size(t3);
if(C_truep(C_fixnum_greaterp(t5,C_fix(2)))){
t6=C_eqp(C_make_character(45),C_subchar(t3,C_fix(0)));
if(C_truep(t6)){
t7=C_i_member(t3,lf[296]);
t8=t4;
f_4931(t8,C_i_not(t7));}
else{
t7=t4;
f_4931(t7,C_SCHEME_FALSE);}}
else{
t6=t4;
f_4931(t6,C_SCHEME_FALSE);}}}}

/* k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4931(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4931,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_eqp(C_make_character(58),C_subchar(((C_word*)t0)[5],C_fix(1)));
if(C_truep(t2)){
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm:905: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4909(t4,((C_word*)t0)[2],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4947,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4981,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:906: substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t4,((C_word*)t0)[5],C_fix(1));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4988,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm:910: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4909(t4,t2,t3);}}

/* k4986 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4988,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4979 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[295]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4945 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4947,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5020,tmp=(C_word)a,a+=2,tmp);
t4=f_5020(t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4960,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4970,tmp=(C_word)a,a+=2,tmp);
/* map */
t7=*((C_word*)lf[293]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}
else{
/* csi.scm:909: ##sys#error */
t5=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[5],lf[294],((C_word*)t0)[2]);}}

/* a4969 in k4945 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4970,3,t0,t1,t2);}
t3=*((C_word*)lf[292]+1);
/* g882883 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4958 in k4945 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4964,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* csi.scm:908: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4909(t4,t2,t3);}

/* k4962 in k4958 in k4945 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:908: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[244]+1)))(4,*((C_word*)lf[244]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k4945 in k4929 in loop in canonicalize-args in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static C_word C_fcall f_5020(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
t2=C_i_nullp(t1);
if(C_truep(t2)){
return(t2);}
else{
t3=C_i_car(t1);
if(C_truep((C_truep(C_eqp(t3,C_make_character(107)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(115)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(118)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(104)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(68)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(101)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(105)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(82)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(98)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(110)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(113)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(119)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(45)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(73)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(112)))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,C_make_character(80)))?C_SCHEME_TRUE:C_SCHEME_FALSE)))))))))))))))))){
t4=C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}
else{
return(C_SCHEME_FALSE);}}}

/* member* in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4846(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4846,NULL,3,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4852,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_4852(t7,t1,t3);}

/* loop in member* in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4852(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4852,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4864,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4864(t6,t1,((C_word*)t0)[2]);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* find in loop in member* in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4864(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4864,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm:881: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4852(t4,t1,t3);}
else{
t3=C_i_car(t2);
t4=C_i_car(((C_word*)t0)[4]);
if(C_truep(C_i_equalp(t3,t4))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[4]);}
else{
t5=C_i_cdr(t2);
/* csi.scm:883: find */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##csi#deldups in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_4787r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_4787r(t0,t1,t2,t3);}}

static void C_ccall f_4787r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4791,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_4791(2,t5,*((C_word*)lf[284]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_4791(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k4789 in ##csi#deldups in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4791,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4796,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4796(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* recur in k4789 in ##csi#deldups in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4796(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4796,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_car(t2);
t4=C_i_cdr(t2);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4812,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4825,a[2]=t5,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:874: del */
((C_proc5)C_retrieve_symbol_proc(lf[282]))(5,*((C_word*)lf[282]+1),t6,t3,t4,((C_word*)t0)[2]);}}

/* k4823 in recur in k4789 in ##csi#deldups in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:874: recur */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4796(t2,((C_word*)t0)[2],t1);}

/* k4810 in recur in k4789 in ##csi#deldups in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4812,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[5],t1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?((C_word*)t0)[3]:C_a_i_cons(&a,2,((C_word*)t0)[2],t1)));}

/* ##csi#del in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4749(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4749,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4755,a[2]=t2,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4755(t8,t1,t3);}

/* loop in ##csi#del in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4755(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4755,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:864: tst */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k4769 in loop in ##csi#del in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4771(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4771,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_cdr(((C_word*)t0)[4]));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4781,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
/* csi.scm:866: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_4755(t4,t2,t3);}}

/* k4779 in k4769 in loop in ##csi#del in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4781(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4781,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4535(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4535,NULL,3,t0,t1,t2);}
t3=C_retrieve(lf[268]);
t4=(C_truep(t3)?t3:C_SCHEME_END_OF_LIST);
t5=C_i_length(t4);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4545,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t5,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(t2))){
t7=t6;
f_4545(t7,C_slot(t2,C_fix(1)));}
else{
if(C_truep(C_i_stringp(t2))){
t7=t2;
t8=t6;
f_4545(t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4747,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:827: display */
t8=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t8))(3,t8,t7,lf[281]);}}}

/* k4745 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4545(t2,C_SCHEME_FALSE);}

/* k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4545(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4545,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:830: call/cc */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}}

/* a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4553,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4556,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4576,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t6,a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t8=((C_word*)t6)[1];
f_4576(t8,t1,((C_word*)t0)[2],t4);}

/* doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4576(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word *a;
loop:
a=C_alloc(14);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4576,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* csi.scm:837: fail */
t4=((C_word*)t0)[5];
f_4556(t4,t1,lf[279]);}
else{
t4=C_i_car(t2);
t5=C_eqp(C_retrieve2(lf[9],"selected-frame"),t4);
t6=C_slot(t4,C_fix(2));
t7=C_i_structurep(t6,lf[269]);
t8=(C_truep(t7)?C_slot(t6,C_fix(1)):t6);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4604,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t10=(C_truep(t5)?t7:C_SCHEME_FALSE);
if(C_truep(t10)){
t11=C_slot(t6,C_fix(2));
t12=C_slot(t6,C_fix(3));
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4631,a[2]=t14,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_4631(t16,t9,t11,t12);}
else{
t11=C_i_cdr(t2);
t12=C_fixnum_difference(t3,C_fix(1));
t19=t1;
t20=t11;
t21=t12;
t1=t19;
t2=t20;
t3=t21;
goto loop;}}}

/* loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4631(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4631,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4639,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4701,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g798799 */
t10=t6;
f_4639(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4699 in loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4631(t4,((C_word*)t0)[2],t2,t3);}

/* g798 in loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4639(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4639,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4645,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=t5,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4645(t7,t1,C_fix(0),t2);}

/* doloop802 in g798 in loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4645(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(15);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4645,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
/* csi.scm:848: fail */
t4=((C_word*)t0)[6];
f_4556(t4,t1,lf[280]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4658,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=C_slot(t5,C_fix(1));
if(C_truep(C_i_string_equal_p(((C_word*)t0)[4],t6))){
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4675,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
t8=C_slot(((C_word*)t0)[3],t2);
t9=C_a_i_list(&a,1,t8);
/* csi.scm:850: history-add */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t7,t9);}
else{
t7=C_fixnum_plus(t2,C_fix(1));
t8=C_i_cdr(t3);
t13=t1;
t14=t7;
t15=t8;
t1=t13;
t2=t14;
t3=t15;
goto loop;}}}

/* k4673 in doloop802 in g798 in loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm:851: return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* k4656 in doloop802 in g798 in loop788 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4645(t4,((C_word*)t0)[2],t2,t3);}

/* k4602 in doloop773 in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4576(t4,((C_word*)t0)[2],t2,t3);}

/* fail in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4556(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4556,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4560,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:833: display */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k4558 in fail in a4552 in k4543 in copy-from-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_retrieve(lf[50]);
/* csi.scm:834: return */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,((C_word*)t0)[2],t2);}

/* select-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4478(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4478,NULL,3,t0,t1,t2);}
t3=C_i_numberp(t2);
t4=C_i_not(t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4488,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_4488(t6,t4);}
else{
t6=C_i_not(C_retrieve(lf[268]));
if(C_truep(t6)){
t7=t5;
f_4488(t7,t6);}
else{
t7=C_fixnum_lessp(t2,C_fix(0));
if(C_truep(t7)){
t8=t5;
f_4488(t8,t7);}
else{
t8=C_i_length(C_retrieve(lf[268]));
t9=t5;
f_4488(t9,C_fixnum_greater_or_equal_p(t2,t8));}}}}

/* k4486 in select-frame in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4488(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
/* csi.scm:809: display */
t2=((C_word*)t0)[4];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[3],lf[277]);}
else{
t2=C_i_length(C_retrieve(lf[268]));
t3=C_fixnum_plus(((C_word*)t0)[2],C_fix(1));
t4=C_fixnum_difference(t2,t3);
t5=C_i_list_ref(C_retrieve(lf[268]),t4);
t6=C_mutate(&lf[9] /* (set! selected-frame ...) */,t5);
/* csi.scm:815: show-frameinfo */
t7=C_retrieve2(lf[112],"show-frameinfo");
f_4211(t7,((C_word*)t0)[3],C_retrieve2(lf[9],"selected-frame"));}}

/* show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4211(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4211,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4214,tmp=(C_word)a,a+=2,tmp);
t4=C_retrieve(lf[268]);
t5=(C_truep(t4)?t4:C_SCHEME_END_OF_LIST);
t6=C_i_length(t5);
t7=C_i_memq(t2,t5);
t8=(C_truep(t7)?t2:C_SCHEME_FALSE);
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4237,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t6,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t8)){
t10=t9;
f_4237(t10,t8);}
else{
if(C_truep(C_fixnum_greaterp(t6,C_fix(0)))){
t10=C_fixnum_difference(t6,C_fix(1));
t11=t9;
f_4237(t11,C_i_list_ref(t5,t10));}
else{
t10=t9;
f_4237(t10,C_SCHEME_FALSE);}}}

/* k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4237,NULL,2,t0,t1);}
t2=C_mutate(&lf[9] /* (set! selected-frame ...) */,t1);
t3=C_fixnum_difference(((C_word*)t0)[7],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4246,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_4246(t7,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4246(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4246,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_i_car(t2);
t5=C_eqp(C_retrieve2(lf[9],"selected-frame"),t4);
t6=C_slot(t4,C_fix(1));
t7=C_slot(t4,C_fix(2));
t8=C_i_structurep(t7,lf[269]);
t9=(C_truep(t8)?C_slot(t7,C_fix(1)):t7);
t10=*((C_word*)lf[54]+1);
t11=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4274,a[2]=t4,a[3]=t10,a[4]=t9,a[5]=t6,a[6]=((C_word*)t0)[2],a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=t7,a[10]=t8,a[11]=t5,a[12]=t1,a[13]=((C_word*)t0)[5],a[14]=t3,a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(t5)){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t11,C_make_character(42),t10);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t11,C_make_character(32),t10);}}}

/* k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4277,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[14],((C_word*)t0)[3]);}

/* k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4280,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* write-char/port */
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(58),((C_word*)t0)[3]);}

/* k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4283,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4446,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[10])){
t4=C_slot(((C_word*)t0)[9],C_fix(2));
t5=t3;
f_4446(t5,C_i_pairp(t4));}
else{
t4=t3;
f_4446(t4,C_SCHEME_FALSE);}}

/* k4444 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4446(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],lf[275],((C_word*)t0)[2]);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],lf[276],((C_word*)t0)[2]);}}

/* k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_4286,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
/* write-char/port */
t3=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4286,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4289,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],tmp=(C_word)a,a+=15,tmp);
t3=C_slot(((C_word*)t0)[2],C_fix(0));
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,t3,((C_word*)t0)[3]);}

/* k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4289(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4289,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4292,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,lf[274],((C_word*)t0)[2]);}

/* k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4292,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4295,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4429,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t5=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(91),t3);}
else{
t3=t2;
f_4295(2,t3,C_SCHEME_UNDEFINED);}}

/* k4427 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4429(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4429,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4432,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4430 in k4427 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],lf[273],((C_word*)t0)[2]);}

/* k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4298,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:786: prin1 */
f_4214(t2,((C_word*)t0)[2]);}
else{
t3=t2;
f_4298(2,t3,C_SCHEME_UNDEFINED);}}

/* k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4301,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:787: newline */
t3=((C_word*)t0)[4];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4304,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(C_truep(((C_word*)t0)[7])?((C_word*)t0)[6]:C_SCHEME_FALSE);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[5],C_fix(2));
t5=C_slot(((C_word*)t0)[5],C_fix(3));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4331,a[2]=t7,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4331(t9,t2,t4,t5);}
else{
t4=C_i_cdr(((C_word*)t0)[11]);
t5=C_fixnum_difference(((C_word*)t0)[10],C_fix(1));
t6=((C_word*)((C_word*)t0)[9])[1];
f_4246(t6,((C_word*)t0)[8],t4,t5);}}

/* loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4331(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4331,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4339,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4398,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g716717 */
t10=t6;
f_4339(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4396 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4331(t4,((C_word*)t0)[2],t2,t3);}

/* g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4339,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4349,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:792: display */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,lf[272]);}}

/* k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4349,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t3,tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_4354(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4354,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=*((C_word*)lf[54]+1);
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4364,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=t3,a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t5,lf[271],t4);}}

/* k4362 in doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4364,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4367,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=C_i_car(((C_word*)t0)[8]);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,t3,((C_word*)t0)[2]);}

/* k4365 in k4362 in doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4367(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4367,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4370,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,lf[270],((C_word*)t0)[2]);}

/* k4368 in k4365 in k4362 in doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4373,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_slot(((C_word*)t0)[3],((C_word*)t0)[8]);
/* csi.scm:797: prin1 */
f_4214(t2,t3);}

/* k4371 in k4368 in k4365 in k4362 in doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4373,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4376,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:798: newline */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k4374 in k4371 in k4368 in k4365 in k4362 in doloop720 in k4347 in g716 in loop706 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4354(t4,((C_word*)t0)[2],t2,t3);}

/* k4302 in k4299 in k4296 in k4293 in k4290 in k4287 in k4284 in k4281 in k4278 in k4275 in k4272 in doloop678 in k4235 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4246(t4,((C_word*)t0)[2],t2,t3);}

/* prin1 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4214(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4214,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4220,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:761: ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t1,C_fix(100),t3);}

/* a4219 in prin1 in show-frameinfo in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
/* csi.scm:764: ##sys#print */
t2=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,t1,((C_word*)t0)[2],C_SCHEME_TRUE,*((C_word*)lf[54]+1));}

/* ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4009,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4012,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4041,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t4,a[6]=t5,a[7]=((C_word*)t0)[3],a[8]=t8,a[9]=t3,tmp=(C_word)a,a+=10,tmp));
t10=((C_word*)t8)[1];
f_4041(t10,t1,C_fix(0));}

/* doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4041(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4041,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[9]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4051,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t1,a[10]=((C_word*)t0)[8],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4209,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:729: justify */
t5=((C_word*)t0)[2];
f_4012(t5,t4,t2,C_fix(4),C_fix(10),C_make_character(32));}}

/* k4207 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:729: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4051,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4054,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:730: write-char */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(58),((C_word*)t0)[7]);}

/* k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4057,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4126,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[2],a[6]=t4,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp));
t6=((C_word*)t4)[1];
f_4126(t6,t2,C_fix(0),((C_word*)t0)[11]);}

/* doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4126(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4126,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]));
if(C_truep(t5)){
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[9]))){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:735: fxmod */
((C_proc4)C_retrieve_proc(*((C_word*)lf[267]+1)))(4,*((C_word*)lf[267]+1),t6,((C_word*)t0)[9],C_fix(16));}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}}
else{
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4180,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=t3,a[10]=t2,tmp=(C_word)a,a+=11,tmp);
/* csi.scm:740: write-char */
t7=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,C_make_character(32),((C_word*)t0)[7]);}}

/* k4178 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4183,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4198,a[2]=((C_word*)t0)[5],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4202,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:741: ref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],((C_word*)t0)[9]);}

/* k4200 in k4178 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:741: justify */
t2=((C_word*)t0)[3];
f_4012(t2,((C_word*)t0)[2],t1,C_fix(2),C_fix(16),C_make_character(48));}

/* k4196 in k4178 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:741: display */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4181 in k4178 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4126(t4,((C_word*)t0)[2],t2,t3);}

/* k4143 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_fixnum_difference(C_fix(16),t1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_4160(t7,((C_word*)t0)[4],t3);}}

/* doloop635 in k4143 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4160(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4160,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,C_fix(0));
if(C_truep(t3)){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4170,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:739: display */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,lf[266],((C_word*)t0)[2]);}}

/* k4168 in doloop635 in k4143 in doloop627 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4160(t3,((C_word*)t0)[2],t2);}

/* k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4060,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* csi.scm:742: write-char */
t3=((C_word*)t0)[6];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(32),((C_word*)t0)[5]);}

/* k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t4,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_4075(t6,t2,C_fix(0),((C_word*)t0)[9]);}

/* doloop643 in k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4075(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4075,NULL,4,t0,t1,t2,t3);}
t4=C_fixnum_greater_or_equal_p(t2,C_fix(16));
t5=(C_truep(t4)?t4:C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[7]));
if(C_truep(t5)){
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:746: ref */
t7=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t7))(4,t7,t6,((C_word*)t0)[2],t3);}}

/* k4086 in doloop643 in k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4091,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_fixnum_greater_or_equal_p(t1,C_fix(32));
t4=(C_truep(t3)?C_fixnum_lessp(t1,C_fix(128)):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_make_character(C_unfix(t1));
/* csi.scm:748: write-char */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t2,t5,((C_word*)t0)[2]);}
else{
/* csi.scm:749: write-char */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,C_make_character(46),((C_word*)t0)[2]);}}

/* k4089 in k4086 in doloop643 in k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4075(t4,((C_word*)t0)[2],t2,t3);}

/* k4061 in k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4063,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4066,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:750: write-char */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k4064 in k4061 in k4058 in k4055 in k4052 in k4049 in doloop617 in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(16));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4041(t3,((C_word*)t0)[2],t2);}

/* justify in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_4012(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4012,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4016,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* csi.scm:721: number->string */
C_number_to_string(4,0,t6,t2,t4);}

/* k4014 in justify in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=C_block_size(t1);
if(C_truep(C_fixnum_lessp(t2,((C_word*)t0)[6]))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4032,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_fixnum_difference(((C_word*)t0)[6],t2);
/* csi.scm:724: make-string */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t3=t1;
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4030 in k4014 in justify in ##csi#hexdump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_4032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:724: string-append */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3848(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3848r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3848r(t0,t1,t2,t3);}}

static void C_ccall f_3848r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(9);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3850,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3956,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3961,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-len585604 */
t7=t6;
f_3961(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* def-out586602 */
t9=t5;
f_3956(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
/* body583590 */
t11=t4;
f_3850(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-len585 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3961(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3961,NULL,2,t0,t1);}
/* def-out586602 */
t2=((C_word*)t0)[2];
f_3956(t2,t1,C_SCHEME_FALSE);}

/* def-out586 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3956(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3956,NULL,3,t0,t1,t2);}
/* body583590 */
t3=((C_word*)t0)[2];
f_3850(t3,t1,t2,*((C_word*)lf[54]+1));}

/* body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3850(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3850,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3853,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_immp(((C_word*)t0)[2]))){
/* csi.scm:703: ##sys#error */
t5=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,lf[261],lf[262],((C_word*)t0)[2]);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3875,a[2]=t4,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:704: ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[250]+1)))(3,*((C_word*)lf[250]+1),t5,((C_word*)t0)[2]);}}

/* k3873 in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3875,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3882,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* csi.scm:704: bestlen */
t4=((C_word*)t0)[2];
f_3853(t4,t2,t3);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_block_size(((C_word*)t0)[4]);
/* csi.scm:705: bestlen */
t4=((C_word*)t0)[2];
f_3853(t4,t2,t3);}
else{
t2=C_immp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_SCHEME_FALSE:C_anypointerp(((C_word*)t0)[4]));
if(C_truep(t3)){
/* csi.scm:707: hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[226]))(6,*((C_word*)lf[226]+1),((C_word*)t0)[5],((C_word*)t0)[4],C_fix(32),*((C_word*)lf[263]+1),((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3918,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_structurep(((C_word*)t0)[4]))){
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=t4;
f_3918(t6,C_i_assq(t5,C_retrieve2(lf[157],"bytevector-data")));}
else{
t5=t4;
f_3918(t5,C_SCHEME_FALSE);}}}}}

/* k3916 in k3873 in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3928,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_block_size(t2);
/* csi.scm:710: bestlen */
t5=((C_word*)t0)[2];
f_3853(t5,t3,t4);}
else{
/* csi.scm:711: ##sys#error */
t2=*((C_word*)lf[59]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],lf[261],lf[264],((C_word*)t0)[5]);}}

/* k3926 in k3916 in k3873 in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:710: hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[226]))(6,*((C_word*)lf[226]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[227]+1),((C_word*)t0)[2]);}

/* k3897 in k3873 in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:705: hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[226]))(6,*((C_word*)lf[226]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[227]+1),((C_word*)t0)[2]);}

/* k3880 in k3873 in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:704: hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[226]))(6,*((C_word*)lf[226]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,*((C_word*)lf[227]+1),((C_word*)t0)[2]);}

/* bestlen in body583 in ##csi#dump in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3853,NULL,3,t0,t1,t2);}
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:702: min */
((C_proc4)C_retrieve_proc(*((C_word*)lf[260]+1)))(4,*((C_word*)lf[260]+1),t1,((C_word*)t0)[2],t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* set-describer! in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3839(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3839,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3843,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:691: ##sys#check-symbol */
((C_proc5)C_retrieve_proc(*((C_word*)lf[258]+1)))(5,*((C_word*)lf[258]+1),t4,t2,lf[259],lf[257]);}

/* k3841 in set-describer! in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3843(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:692: ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[68]))(5,*((C_word*)lf[68]+1),((C_word*)t0)[4],C_retrieve2(lf[159],"describer-table"),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2798(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+10)){
C_save_and_reclaim((void*)tr3r,(void*)f_2798r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2798r(t0,t1,t2,t3);}}

static void C_ccall f_2798r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(10);
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2802,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=t2,a[9]=((C_word*)t0)[7],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_2802(2,t5,*((C_word*)lf[54]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_2802(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2802(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2802,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2804,a[2]=((C_word*)t0)[8],a[3]=t1,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[7],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_permanentp(((C_word*)t0)[8]))){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3818,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:553: ##sys#block-address */
((C_proc3)C_retrieve_symbol_proc(lf[256]))(3,*((C_word*)lf[256]+1),t4,((C_word*)t0)[8]);}
else{
t4=t3;
f_2930(2,t4,C_SCHEME_UNDEFINED);}}

/* k3816 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:553: fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[255],t1);}

/* k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2933,a[2]=((C_word*)t0)[11],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_charp(((C_word*)t0)[10]))){
t3=C_fix(C_character_code(((C_word*)t0)[10]));
/* csi.scm:556: fprintf */
t4=((C_word*)t0)[9];
((C_proc8)C_retrieve_proc(t4))(8,t4,t2,((C_word*)t0)[8],lf[170],((C_word*)t0)[10],t3,t3,t3);}
else{
switch(((C_word*)t0)[10]){
case C_SCHEME_TRUE:
/* csi.scm:557: fprintf */
t3=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],lf[171]);
case C_SCHEME_FALSE:
/* csi.scm:558: fprintf */
t3=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],lf[172]);
default:
if(C_truep(C_i_nullp(((C_word*)t0)[10]))){
/* csi.scm:559: fprintf */
t3=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],lf[173]);}
else{
if(C_truep(C_eofp(((C_word*)t0)[10]))){
/* csi.scm:560: fprintf */
t3=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[8],lf[174]);}
else{
t3=C_retrieve(lf[50]);
t4=C_eqp(t3,((C_word*)t0)[10]);
if(C_truep(t4)){
/* csi.scm:561: fprintf */
t5=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t5))(4,t5,t2,((C_word*)t0)[8],lf[175]);}
else{
if(C_truep(C_fixnump(((C_word*)t0)[10]))){
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2999,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=t2,a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:563: fprintf */
t6=((C_word*)t0)[9];
((C_proc8)C_retrieve_proc(t6))(8,t6,t5,((C_word*)t0)[8],lf[177],((C_word*)t0)[10],((C_word*)t0)[10],((C_word*)t0)[10],((C_word*)t0)[10]);}
else{
t5=C_slot(lf[178],C_fix(0));
t6=C_eqp(((C_word*)t0)[10],t5);
if(C_truep(t6)){
/* csi.scm:568: fprintf */
t7=((C_word*)t0)[9];
((C_proc4)C_retrieve_proc(t7))(4,t7,t2,((C_word*)t0)[8],lf[179]);}
else{
if(C_truep(C_i_flonump(((C_word*)t0)[10]))){
/* csi.scm:569: fprintf */
t7=((C_word*)t0)[9];
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,((C_word*)t0)[8],lf[180],((C_word*)t0)[10]);}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[10]))){
/* csi.scm:570: fprintf */
t7=((C_word*)t0)[9];
((C_proc5)C_retrieve_proc(t7))(5,t7,t2,((C_word*)t0)[8],lf[181],((C_word*)t0)[10]);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[10]))){
/* csi.scm:571: descseq */
t7=((C_word*)t0)[7];
f_2804(6,t7,t2,lf[182],*((C_word*)lf[183]+1),((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[10]))){
/* csi.scm:572: descseq */
t7=((C_word*)t0)[7];
f_2804(6,t7,t2,lf[184],*((C_word*)lf[183]+1),*((C_word*)lf[185]+1),C_fix(0));}
else{
t7=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3065,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[11],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[8],a[10]=t2,a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:573: keyword? */
((C_proc3)C_retrieve_symbol_proc(lf[254]))(3,*((C_word*)lf[254]+1),t7,((C_word*)t0)[10]);}}}}}}}}}}}}

/* k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3065,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3072,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:575: ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t2,((C_word*)t0)[8]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[8]))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3081,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3165,a[2]=((C_word*)t0)[9],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:577: ##sys#symbol-has-toplevel-binding? */
((C_proc3)C_retrieve_symbol_proc(lf[199]))(3,*((C_word*)lf[199]+1),t3,((C_word*)t0)[8]);}
else{
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2725,tmp=(C_word)a,a+=2,tmp);
t4=f_2725(t2,t2);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3177,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[11],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t4)){
t6=t5;
f_3177(t6,t4);}
else{
t6=((C_word*)t0)[8];
t7=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2764,tmp=(C_word)a,a+=2,tmp);
t8=t5;
f_3177(t8,f_2764(t6));}}}}

/* lp in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static C_word C_fcall f_2764(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
loop:
C_stack_check;
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_eqp(t1,t2);
if(C_truep(t3)){
return(t3);}
else{
t4=C_i_cdr(t1);
t6=t4;
t1=t6;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}

/* k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3177(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3177,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:598: fprintf */
t3=((C_word*)t0)[8];
((C_proc4)C_retrieve_proc(t3))(4,t3,t2,((C_word*)t0)[7],lf[203]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[10]))){
/* csi.scm:608: descseq */
t2=((C_word*)t0)[5];
f_2804(6,t2,((C_word*)t0)[6],lf[204],((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[10]))){
t2=C_i_car(((C_word*)t0)[10]);
t3=C_i_cdr(((C_word*)t0)[10]);
/* csi.scm:609: fprintf */
t4=((C_word*)t0)[8];
((C_proc6)C_retrieve_proc(t4))(6,t4,((C_word*)t0)[6],((C_word*)t0)[7],lf[205],t2,t3);}
else{
if(C_truep(C_i_closurep(((C_word*)t0)[10]))){
t2=C_block_size(((C_word*)t0)[10]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3295,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_greaterp(t2,C_fix(3)))){
if(C_truep(C_i_memq(lf[209],C_retrieve(lf[6])))){
t4=C_fixnum_difference(t2,C_fix(1));
t5=C_slot(((C_word*)t0)[10],t4);
t6=t3;
f_3295(t6,C_eqp(C_retrieve(lf[210]),t5));}
else{
t4=t3;
f_3295(t4,C_SCHEME_FALSE);}}
else{
t4=t3;
f_3295(t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3335,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:619: port? */
((C_proc3)C_retrieve_symbol_proc(lf[253]))(3,*((C_word*)lf[253]+1),t2,((C_word*)t0)[10]);}}}}}

/* k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3335,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=(C_truep(t2)?lf[211]:lf[212]);
t4=C_slot(((C_word*)t0)[6],C_fix(7));
t5=C_slot(((C_word*)t0)[6],C_fix(3));
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3354,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:625: ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t6,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3363,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_memq(lf[209],C_retrieve(lf[6])))){
/* csi.scm:626: instance? */
((C_proc3)C_retrieve_symbol_proc(lf[252]))(3,*((C_word*)lf[252]+1),t2,((C_word*)t0)[6]);}
else{
t3=t2;
f_3363(2,t3,C_SCHEME_FALSE);}}}

/* k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3363,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:627: describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3372,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:628: ##sys#locative? */
((C_proc3)C_retrieve_symbol_proc(lf[251]))(3,*((C_word*)lf[251]+1),t2,((C_word*)t0)[5]);}}

/* k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3372,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:630: ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
if(C_truep(C_anypointerp(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:643: ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t2,((C_word*)t0)[6],C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:644: ##sys#bytevector? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[250]+1)))(3,*((C_word*)lf[250]+1),t2,((C_word*)t0)[6]);}}}

/* k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
if(C_truep(t1)){
t2=C_block_size(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3472,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:646: fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[4],lf[228],t2);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[6]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:649: ##sys#lambda-info->string */
((C_proc3)C_retrieve_symbol_proc(lf[230]))(3,*((C_word*)lf[230]+1),t2,((C_word*)t0)[6]);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[231]))){
t2=C_slot(((C_word*)t0)[6],C_fix(2));
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3497,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,C_fix(1));
t5=(C_truep(t4)?lf[234]:lf[235]);
t6=C_slot(((C_word*)t0)[6],C_fix(3));
/* csi.scm:652: fprintf */
t7=((C_word*)t0)[3];
((C_proc7)C_retrieve_proc(t7))(7,t7,t3,((C_word*)t0)[4],lf[236],t2,t5,t6);}
else{
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[237]))){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3592,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(1));
/* csi.scm:666: fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[4],lf[242],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3681,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_structurep(((C_word*)t0)[6],lf[247]))){
/* csi.scm:676: provided? */
((C_proc3)C_retrieve_symbol_proc(lf[248]))(3,*((C_word*)lf[248]+1),t2,lf[249]);}
else{
t3=t2;
f_3681(2,t3,C_SCHEME_FALSE);}}}}}}

/* k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3681,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:677: unveil */
((C_proc4)C_retrieve_symbol_proc(lf[243]))(4,*((C_word*)lf[243]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep(C_structurep(((C_word*)t0)[5]))){
t2=C_slot(((C_word*)t0)[5],C_fix(0));
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3696,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:680: ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t3,C_retrieve2(lf[159],"describer-table"),t2);}
else{
/* csi.scm:687: fprintf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[6],((C_word*)t0)[4],lf[246]);}}}

/* k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* g536537 */
t3=t2;
f_3700(t3,((C_word*)t0)[5],t1);}
else{
t2=C_i_assq(((C_word*)t0)[4],C_retrieve2(lf[157],"bytevector-data"));
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g546547 */
t4=t3;
f_3714(t4,((C_word*)t0)[5],t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3775,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(((C_word*)t0)[7],C_fix(0));
/* csi.scm:685: fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[6],lf[245],t4);}}}

/* k3773 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:686: descseq */
t2=((C_word*)t0)[3];
f_2804(6,t2,((C_word*)t0)[2],C_SCHEME_FALSE,*((C_word*)lf[183]+1),*((C_word*)lf[185]+1),C_fix(1));}

/* g546 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3714(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3714,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3722,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3726,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_i_cdr(t2);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3736,a[2]=t5,a[3]=t11,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_3736(t13,t8,t9);}

/* loop551 in g546 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3736(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3736,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[69]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g567568 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3763 in loop551 in g546 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3765,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop551564 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3736(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop551564 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_3736(t6,((C_word*)t0)[3],t5);}}

/* k3724 in g546 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=C_a_i_list(&a,1,C_fix(0));
/* csi.scm:683: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[244]+1)))(4,*((C_word*)lf[244]+1),((C_word*)t0)[2],t1,t2);}

/* k3720 in g546 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g536 in k3694 in k3679 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3700(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3700,NULL,3,t0,t1,t2);}
/* g543544 */
t3=t2;
((C_proc4)C_retrieve_proc(t3))(4,t3,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3601,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3601(t6,((C_word*)t0)[2],t2);}

/* loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3601(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3601,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3609,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3660,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g518519 */
t6=t3;
f_3609(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3658 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3601(t3,((C_word*)t0)[2],t2);}

/* g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3609(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3609,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3613,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:669: fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[241],t2);}

/* k3611 in g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(2));
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3622(t6,((C_word*)t0)[2],t2);}

/* loop in k3611 in g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3622(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3622,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3632,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3657,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=t3,a[6]=((C_word*)t0)[3],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:672: caar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[240]+1)))(3,*((C_word*)lf[240]+1),t4,t2);}}

/* k3655 in loop in k3611 in g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3657,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[8],t1);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3649,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:673: cdar */
((C_proc3)C_retrieve_proc(*((C_word*)lf[239]+1)))(3,*((C_word*)lf[239]+1),t3,((C_word*)t0)[7]);}
else{
t3=C_i_cddr(((C_word*)t0)[7]);
/* csi.scm:674: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3622(t4,((C_word*)t0)[2],t3);}}

/* k3647 in k3655 in loop in k3611 in g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
/* csi.scm:673: fprintf */
t3=((C_word*)t0)[4];
((C_proc6)C_retrieve_proc(t3))(6,t3,((C_word*)t0)[3],((C_word*)t0)[2],lf[238],t1,t2);}

/* k3630 in loop in k3611 in g518 in loop511 in k3590 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
/* csi.scm:674: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3622(t3,((C_word*)t0)[2],t2);}

/* k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3500,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[5],C_fix(4));
/* csi.scm:654: fprintf */
t4=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t4))(5,t4,t2,((C_word*)t0)[3],lf[233],t3);}

/* k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3500,2,t0,t1);}
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3511,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t5,a[6]=t3,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_3511(t7,((C_word*)t0)[2],C_fix(0));}

/* doloop488 in k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3511(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3511,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[6]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3521,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(((C_word*)t0)[4],t2);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3534,a[2]=t6,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3534(t8,t3,t4);}}

/* loop493 in doloop488 in k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3534(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3534,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3542,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3557,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g500501 */
t6=t3;
f_3542(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3555 in loop493 in doloop488 in k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3534(t3,((C_word*)t0)[2],t2);}

/* g500 in loop493 in doloop488 in k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3542(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3542,NULL,3,t0,t1,t2);}
t3=C_slot(t2,C_fix(0));
t4=C_slot(t2,C_fix(1));
/* csi.scm:662: fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t1,((C_word*)t0)[2],lf[232],t3,t4);}

/* k3519 in doloop488 in k3498 in k3495 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3511(t3,((C_word*)t0)[2],t2);}

/* k3483 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:649: fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[229],t1);}

/* k3470 in k3464 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:647: hexdump */
((C_proc6)C_retrieve_symbol_proc(lf[226]))(6,*((C_word*)lf[226]+1),((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],*((C_word*)lf[227]+1),((C_word*)t0)[2]);}

/* k3458 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:643: fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[225],t1);}

/* k3377 in k3370 in k3361 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[5],C_fix(2));
switch(t3){
case C_fix(0):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[215]);
case C_fix(1):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[216]);
case C_fix(2):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[217]);
case C_fix(3):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[218]);
case C_fix(4):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[219]);
case C_fix(5):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[220]);
case C_fix(6):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[221]);
case C_fix(7):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[222]);
case C_fix(8):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[223]);
case C_fix(9):
/* csi.scm:629: fprintf */
t4=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t4))(7,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,lf[224]);
default:
t4=C_SCHEME_UNDEFINED;
/* csi.scm:629: fprintf */
t5=((C_word*)t0)[4];
((C_proc7)C_retrieve_proc(t5))(7,t5,((C_word*)t0)[3],((C_word*)t0)[2],lf[214],t1,t2,t4);}}

/* k3352 in k3333 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:620: fprintf */
t2=((C_word*)t0)[7];
((C_proc8)C_retrieve_proc(t2))(8,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[213],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3293 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3295(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3295,NULL,2,t0,t1);}
if(C_truep(t1)){
/* csi.scm:615: describe-object */
((C_proc4)C_retrieve_symbol_proc(lf[206]))(4,*((C_word*)lf[206]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3305,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3309,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:617: ##sys#peek-unsigned-integer */
((C_proc4)C_retrieve_symbol_proc(lf[208]))(4,*((C_word*)lf[208]+1),t3,((C_word*)t0)[5],C_fix(0));}}

/* k3307 in k3293 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:617: sprintf */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],lf[207],t1);}

/* k3303 in k3293 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:616: descseq */
t2=((C_word*)t0)[3];
f_2804(6,t2,((C_word*)t0)[2],t1,*((C_word*)lf[183]+1),*((C_word*)lf[185]+1),C_fix(1));}

/* k3178 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3189,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t6=((C_word*)t4)[1];
f_3189(t6,((C_word*)t0)[2],((C_word*)t0)[6],t2);}

/* loop-print in k3178 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3189(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3189,NULL,4,t0,t1,t2,t3);}
t4=C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
/* csi.scm:602: printf */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,lf[200]);}
else{
t6=C_i_car(t2);
if(C_truep(C_i_memq(t6,t3))){
/* csi.scm:604: fprintf */
t7=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t7))(4,t7,t1,((C_word*)t0)[3],lf[201]);}
else{
t7=C_i_car(t2);
if(C_truep(C_i_memq(t7,t3))){
t8=C_SCHEME_UNDEFINED;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3220,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t2);
/* csi.scm:606: fprintf */
t10=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t10))(5,t10,t8,((C_word*)t0)[3],lf[202],t9);}}}}

/* k3218 in loop-print in k3178 in k3175 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_car(((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[4]);
/* csi.scm:607: loop-print */
t5=((C_word*)((C_word*)t0)[3])[1];
f_3189(t5,((C_word*)t0)[2],t2,t4);}

/* lp in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static C_word C_fcall f_2725(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
loop:
C_stack_check;
if(C_truep(C_i_pairp(t1))){
t3=C_i_cdr(t1);
if(C_truep(C_i_pairp(t3))){
t4=C_i_cdr(t3);
t5=C_i_cdr(t2);
t6=C_eqp(t4,t5);
if(C_truep(t6)){
return(t6);}
else{
t8=t4;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* k3163 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_3081(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:578: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),((C_word*)t0)[3],lf[198],((C_word*)t0)[2]);}}

/* k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3081(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3081,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3084,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:579: ##sys#qualified-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),t2,((C_word*)t0)[6]);}

/* k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3084(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3084,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3087,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* csi.scm:581: ##sys#interned-symbol? */
((C_proc3)C_retrieve_symbol_proc(lf[196]))(3,*((C_word*)lf[196]+1),t3,((C_word*)t0)[6]);}

/* k3160 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3162,2,t0,t1);}
t2=(C_truep(t1)?lf[190]:lf[191]);
t3=(C_truep(((C_word*)t0)[6])?lf[192]:lf[193]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3153,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[6])){
/* csi.scm:584: ##sys#symbol->qualified-string */
((C_proc3)C_retrieve_symbol_proc(lf[195]))(3,*((C_word*)lf[195]+1),t4,((C_word*)t0)[2]);}
else{
/* csi.scm:585: ##sys#symbol->string */
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t4,((C_word*)t0)[2]);}}

/* k3151 in k3160 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:580: fprintf */
t2=((C_word*)t0)[6];
((C_proc7)C_retrieve_proc(t2))(7,t2,((C_word*)t0)[5],((C_word*)t0)[4],lf[194],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3087,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(2));
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_retrieve(lf[50]));}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3099,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:588: display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t3,lf[189],((C_word*)t0)[4]);}}

/* k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3104,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3104(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* doloop449 in k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_3104(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3104,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3114,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* csi.scm:591: fprintf */
t5=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t5))(5,t5,t3,((C_word*)t0)[3],lf[188],t4);}}

/* k3112 in doloop449 in k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3117,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3129,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:592: ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,C_fix(1000),t3);}

/* a3128 in k3112 in doloop449 in k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[3]);
/* csi.scm:595: write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t1,t2,((C_word*)t0)[2]);}

/* k3115 in k3112 in doloop449 in k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:596: newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}

/* k3118 in k3115 in k3112 in doloop449 in k3097 in k3085 in k3082 in k3079 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_3104(t3,((C_word*)t0)[2],t2);}

/* k3070 in k3063 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3072(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:574: fprintf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[186],t1);}

/* k2997 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2999,2,t0,t1);}
t2=C_make_character(C_unfix(((C_word*)t0)[5]));
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3005,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_lessp(((C_word*)t0)[5],C_fix(65536)))){
/* csi.scm:565: fprintf */
t4=((C_word*)t0)[3];
((C_proc5)C_retrieve_proc(t4))(5,t4,t3,((C_word*)t0)[2],lf[176],t2);}
else{
/* csi.scm:566: ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),((C_word*)t0)[4],C_make_character(10),*((C_word*)lf[54]+1));}}

/* k3003 in k2997 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_3005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:566: ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),((C_word*)t0)[2],C_make_character(10),*((C_word*)lf[54]+1));}

/* k2931 in k2928 in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2804(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_2804,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2927,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t4,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],a[8]=t5,tmp=(C_word)a,a+=9,tmp);
/* csi.scm:533: plen */
t7=t3;
((C_proc3)C_retrieve_proc(t7))(3,t7,t6,((C_word*)t0)[2]);}

/* k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2927,2,t0,t1);}
t2=C_fixnum_difference(t1,((C_word*)t0)[8]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2811,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[2])){
/* csi.scm:534: fprintf */
t4=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t4))(6,t4,t3,((C_word*)t0)[6],lf[169],((C_word*)t0)[2],t2);}
else{
t4=t3;
f_2811(2,t4,C_SCHEME_UNDEFINED);}}

/* k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2811,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2816,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp));
t5=((C_word*)t3)[1];
f_2816(t5,((C_word*)t0)[2],C_fix(0));}

/* loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2816(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2816,NULL,3,t0,t1,t2);}
t3=C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[8]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(40)))){
t4=C_fixnum_difference(((C_word*)t0)[8],t2);
/* csi.scm:538: fprintf */
t5=((C_word*)t0)[7];
((C_proc5)C_retrieve_proc(t5))(5,t5,t1,((C_word*)t0)[6],lf[164],t4);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2839,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=((C_word*)t0)[5],tmp=(C_word)a,a+=11,tmp);
t5=C_fixnum_plus(((C_word*)t0)[5],t2);
/* csi.scm:540: pref */
t6=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t6))(4,t6,t4,((C_word*)t0)[2],t5);}}}

/* k2837 in loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2839(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2839,2,t0,t1);}
t2=C_fixnum_plus(((C_word*)t0)[10],C_fix(1));
t3=C_fixnum_plus(((C_word*)t0)[9],t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2848,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp));
t7=((C_word*)t5)[1];
f_2848(t7,((C_word*)t0)[2],C_fix(1),t3);}

/* loop2 in k2837 in loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2848(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2848,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[10]))){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:543: fprintf */
t5=((C_word*)t0)[7];
((C_proc6)C_retrieve_proc(t5))(6,t5,t4,((C_word*)t0)[6],lf[168],((C_word*)t0)[9],((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2912,a[2]=((C_word*)t0)[10],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:550: pref */
t5=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t5))(4,t5,t4,((C_word*)t0)[2],t3);}}

/* k2910 in loop2 in k2837 in loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_eqp(((C_word*)t0)[7],t1);
if(C_truep(t2)){
t3=C_fixnum_plus(((C_word*)t0)[6],C_fix(1));
t4=C_fixnum_plus(((C_word*)t0)[5],C_fix(1));
/* csi.scm:550: loop2 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2848(t5,((C_word*)t0)[3],t3,t4);}
else{
/* csi.scm:551: loop2 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2848(t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* k2856 in loop2 in k2837 in loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2861,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(((C_word*)t0)[6],C_fix(1)))){
t3=C_fixnum_difference(((C_word*)t0)[6],C_fix(1));
t4=C_eqp(((C_word*)t0)[6],C_fix(2));
if(C_truep(t4)){
/* csi.scm:545: fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[165],t3,lf[166]);}
else{
/* csi.scm:545: fprintf */
t5=((C_word*)t0)[3];
((C_proc6)C_retrieve_proc(t5))(6,t5,t2,((C_word*)t0)[2],lf[165],t3,lf[167]);}}
else{
/* csi.scm:548: newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[24]+1)))(3,*((C_word*)lf[24]+1),t2,((C_word*)t0)[2]);}}

/* k2859 in k2856 in loop2 in k2837 in loop1 in k2809 in k2925 in descseq in k2800 in ##csi#describe in k2794 in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[5],((C_word*)t0)[4]);
/* csi.scm:549: loop1 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2816(t3,((C_word*)t0)[2],t2);}

/* ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr2r,(void*)f_2440r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2440r(t0,t1,t2);}}

static void C_ccall f_2440r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(9);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2448,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t4=t3;
f_2448(2,t4,C_i_car(t2));}
else{
/* csi.scm:441: current-output-port */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2450,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* csi.scm:441: with-output-to-port */
t3=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t3))(4,t3,((C_word*)t0)[2],t1,t2);}

/* a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2450,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2454,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* csi.scm:443: gc */
((C_proc2)C_retrieve_symbol_proc(lf[156]))(2,*((C_word*)lf[156]+1),t2);}

/* k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* csi.scm:444: ##sys#symbol-table-info */
((C_proc2)C_retrieve_symbol_proc(lf[155]))(2,*((C_word*)lf[155]+1),t2);}

/* k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:445: memory-statistics */
((C_proc2)C_retrieve_symbol_proc(lf[154]))(2,*((C_word*)lf[154]+1),t2);}

/* k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2462,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2477,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm:447: printf */
t4=((C_word*)t0)[6];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,lf[153]);}

/* k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2477(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[32],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2477,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2480,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2589,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2668,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2672,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2674,a[2]=t6,a[3]=t11,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t13=((C_word*)t11)[1];
f_2674(t13,t9,C_retrieve(lf[6]));}

/* loop348 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2674(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2674,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[152]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2703,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g364365 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2701 in loop348 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2703,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop348361 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2674(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop348361 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2674(t6,((C_word*)t0)[3],t5);}}

/* k2670 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:455: sort */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,*((C_word*)lf[151]+1));}

/* k2666 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:455: chop */
t2=((C_word*)t0)[3];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[2],t1,C_fix(5));}

/* k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2589,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2591,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2591(t5,((C_word*)t0)[2],t1);}

/* loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2591(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2591,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2599,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2653,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g326327 */
t6=t3;
f_2599(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2651 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2591(t3,((C_word*)t0)[2],t2);}

/* g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2599,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2603,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:450: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t3,lf[150]);}

/* k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2603(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2603,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2608,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_2608(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop331 in k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2608(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2608,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2616,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2639,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g338339 */
t6=t3;
f_2616(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2637 in loop331 in k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2608(t3,((C_word*)t0)[2],t2);}

/* g338 in loop331 in k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2616(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2616,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2624,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2628,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_string_length(t2);
t6=C_fixnum_difference(C_fix(16),t5);
/* csi.scm:453: fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[149]+1)))(4,*((C_word*)lf[149]+1),t4,C_fix(1),t6);}

/* k2626 in g338 in loop331 in k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:453: make-string */
((C_proc4)C_retrieve_proc(*((C_word*)lf[148]+1)))(4,*((C_word*)lf[148]+1),((C_word*)t0)[2],t1,C_make_character(32));}

/* k2622 in g338 in loop331 in k2601 in g326 in loop319 in k2587 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:453: printf */
t2=((C_word*)t0)[4];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[3],lf[147],((C_word*)t0)[2],t1);}

/* k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2480,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2483,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2508,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* csi.scm:470: machine-type */
((C_proc2)C_retrieve_symbol_proc(lf[146]))(2,*((C_word*)lf[146]+1),t3);}

/* k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2508,2,t0,t1);}
t2=C_fudge(C_fix(3));
t3=(C_truep(t2)?lf[134]:lf[135]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2516,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],tmp=(C_word)a,a+=11,tmp);
/* csi.scm:472: software-type */
((C_proc2)C_retrieve_symbol_proc(lf[145]))(2,*((C_word*)lf[145]+1),t4);}

/* k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2516,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_2520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* csi.scm:473: software-version */
((C_proc2)C_retrieve_symbol_proc(lf[144]))(2,*((C_word*)lf[144]+1),t2);}

/* k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2520,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_2524,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* csi.scm:474: build-platform */
((C_proc2)C_retrieve_symbol_proc(lf[143]))(2,*((C_word*)lf[143]+1),t2);}

/* k2522 in k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_2528,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* csi.scm:476: repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[142]))(2,*((C_word*)lf[142]+1),t2);}

/* k2526 in k2522 in k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
t3=C_i_vector_ref(((C_word*)t0)[13],C_fix(0));
/* csi.scm:478: shorten */
f_2462(t2,t3);}

/* k2530 in k2526 in k2522 in k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2536,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t3=C_i_vector_ref(((C_word*)t0)[14],C_fix(1));
/* csi.scm:479: shorten */
f_2462(t2,t3);}

/* k2534 in k2530 in k2526 in k2522 in k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2536,2,t0,t1);}
t2=C_i_vector_ref(((C_word*)t0)[14],C_fix(2));
t3=C_i_vector_ref(((C_word*)t0)[13],C_fix(0));
t4=C_fudge(C_fix(17));
t5=(C_truep(t4)?lf[136]:lf[137]);
t6=C_i_vector_ref(((C_word*)t0)[13],C_fix(1));
t7=C_i_vector_ref(((C_word*)t0)[13],C_fix(2));
t8=C_fudge(C_fix(18));
t9=C_i_nequalp(C_fix(1),t8);
t10=(C_truep(t9)?lf[138]:lf[139]);
t11=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_2564,a[2]=t10,a[3]=t7,a[4]=t6,a[5]=t5,a[6]=t3,a[7]=t2,a[8]=t1,a[9]=((C_word*)t0)[3],a[10]=((C_word*)t0)[4],a[11]=((C_word*)t0)[5],a[12]=((C_word*)t0)[6],a[13]=((C_word*)t0)[7],a[14]=((C_word*)t0)[8],a[15]=((C_word*)t0)[9],a[16]=((C_word*)t0)[10],a[17]=((C_word*)t0)[11],a[18]=((C_word*)t0)[12],tmp=(C_word)a,a+=19,tmp);
/* csi.scm:486: argv */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k2562 in k2534 in k2530 in k2526 in k2522 in k2518 in k2514 in k2506 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:456: printf */
t2=((C_word*)t0)[18];
((C_proc20)C_retrieve_proc(t2))(20,t2,((C_word*)t0)[17],lf[140],((C_word*)t0)[16],((C_word*)t0)[15],((C_word*)t0)[14],((C_word*)t0)[13],((C_word*)t0)[12],((C_word*)t0)[11],((C_word*)t0)[10],C_retrieve(lf[141]),((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2481 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:487: ##sys#write-char-0 */
((C_proc4)C_retrieve_symbol_proc(lf[133]))(4,*((C_word*)lf[133]+1),t2,C_make_character(10),*((C_word*)lf[54]+1));}

/* k2484 in k2481 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(14)))){
/* csi.scm:488: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[132]);}
else{
t3=t2;
f_2489(2,t3,C_SCHEME_UNDEFINED);}}

/* k2487 in k2484 in k2481 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fudge(C_fix(15)))){
/* csi.scm:489: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[131]);}
else{
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}}

/* k2490 in k2487 in k2484 in k2481 in k2478 in k2475 in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* shorten in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_2462(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2462,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2470,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_times(&a,2,t2,C_fix(100));
/* csi.scm:446: truncate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[130]+1)))(3,*((C_word*)lf[130]+1),t3,t4);}

/* k2468 in shorten in k2458 in k2455 in k2452 in a2449 in k2446 in ##csi#report in k2437 in k2434 in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2470,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_divide(&a,2,t1,C_fix(100)));}

/* ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1811,3,t0,t1,t2);}
if(C_truep(C_eofp(t2))){
/* csi.scm:294: exit */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),t1);}
else{
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1827,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=t2,tmp=(C_word)a,a+=14,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_slot(t2,C_fix(0));
t5=t3;
f_1827(t5,C_eqp(lf[124],t4));}
else{
t4=t3;
f_1827(t4,C_SCHEME_FALSE);}}}

/* k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1827(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1827,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[13]);
t3=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=t2,a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
if(C_truep(C_i_symbolp(t2))){
/* csi.scm:298: ##sys#hash-table-ref */
((C_proc4)C_retrieve_symbol_proc(lf[123]))(4,*((C_word*)lf[123]+1),t3,C_retrieve2(lf[66],"command-table"),t2);}
else{
t4=t3;
f_1833(2,t4,C_SCHEME_FALSE);}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2272,a[2]=((C_word*)t0)[13],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2278,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[12],t2,t3);}}

/* a2277 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2278(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2278r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2278r(t0,t1,t2);}}

static void C_ccall f_2278r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2282,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:408: history-add */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t3,t2);}

/* k2280 in a2277 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2271 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2272,2,t0,t1);}
/* csi.scm:407: eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1833,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[14];
t3=t1;
t4=C_i_car(t3);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1844,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g175176 */
t6=t4;
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t2=C_eqp(((C_word*)t0)[13],lf[81]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1859,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:305: read */
t4=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t3=C_eqp(((C_word*)t0)[13],lf[83]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1882,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:309: read */
t5=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t5))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[13],lf[84]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1900,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:314: read */
t6=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t6))(2,t6,t5);}
else{
t5=C_eqp(((C_word*)t0)[13],lf[86]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1915,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:318: read */
t7=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t7))(2,t7,t6);}
else{
t6=C_eqp(((C_word*)t0)[13],lf[88]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1930,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:322: read */
t8=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t8))(2,t8,t7);}
else{
t7=C_eqp(((C_word*)t0)[13],lf[89]);
if(C_truep(t7)){
/* csi.scm:327: report */
((C_proc2)C_retrieve_symbol_proc(lf[90]))(2,*((C_word*)lf[90]+1),((C_word*)t0)[14]);}
else{
t8=C_eqp(((C_word*)t0)[13],lf[91]);
if(C_truep(t8)){
/* csi.scm:328: exit */
((C_proc2)C_retrieve_symbol_proc(lf[80]))(2,*((C_word*)lf[80]+1),((C_word*)t0)[14]);}
else{
t9=C_eqp(((C_word*)t0)[13],lf[92]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1969,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2002,a[2]=t10,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:330: read-line */
t12=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}
else{
t10=C_eqp(((C_word*)t0)[13],lf[94]);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[14],tmp=(C_word)a,a+=5,tmp);
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=t11,a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:334: read-line */
t13=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t11=C_eqp(((C_word*)t0)[13],lf[99]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2045,a[2]=((C_word*)t0)[14],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:338: read */
t13=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t13))(2,t13,t12);}
else{
t12=C_eqp(((C_word*)t0)[13],lf[103]);
if(C_truep(t12)){
if(C_truep(C_retrieve(lf[104]))){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t14=C_a_i_list(&a,1,C_retrieve(lf[104]));
/* csi.scm:344: history-add */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t13,t14);}
else{
t13=C_SCHEME_UNDEFINED;
t14=((C_word*)t0)[14];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}}
else{
t13=C_eqp(((C_word*)t0)[13],lf[105]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2113,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[14],tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2130,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2134,a[2]=((C_word*)t0)[7],a[3]=t15,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:349: editor-command */
((C_proc2)C_retrieve_symbol_proc(lf[8]))(2,*((C_word*)lf[8]+1),t16);}
else{
t14=C_eqp(((C_word*)t0)[13],lf[109]);
if(C_truep(t14)){
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2150,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t16=C_retrieve(lf[50]);
/* csi.scm:237: vector-fill! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[52]+1)))(4,*((C_word*)lf[52]+1),t15,C_retrieve(lf[47]),t16);}
else{
t15=C_eqp(((C_word*)t0)[13],lf[110]);
if(C_truep(t15)){
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2162,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:357: history-show */
((C_proc2)C_retrieve_symbol_proc(lf[53]))(2,*((C_word*)lf[53]+1),t16);}
else{
t16=C_eqp(((C_word*)t0)[13],lf[111]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2174,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:360: show-frameinfo */
t18=C_retrieve2(lf[112],"show-frameinfo");
f_4211(t18,t17,C_retrieve2(lf[9],"selected-frame"));}
else{
t17=C_eqp(((C_word*)t0)[13],lf[113]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2193,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:363: read */
t20=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t18=C_eqp(((C_word*)t0)[13],lf[115]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:366: read */
t20=((C_word*)t0)[10];
((C_proc2)C_retrieve_proc(t20))(2,t20,t19);}
else{
t19=C_eqp(((C_word*)t0)[13],lf[117]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:368: read-line */
t21=((C_word*)t0)[7];
((C_proc2)C_retrieve_proc(t21))(2,t21,t20);}
else{
t20=C_eqp(((C_word*)t0)[13],lf[118]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2234,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:373: display */
t22=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t22))(3,t22,t21,lf[121]);}
else{
t21=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[14],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:404: printf */
t22=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t22))(4,t22,t21,lf[122],((C_word*)t0)[2]);}}}}}}}}}}}}}}}}}}}}}

/* k2256 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2232 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2242,tmp=(C_word)a,a+=2,tmp);
/* csi.scm:395: ##sys#hash-table-for-each */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),t2,t3,C_retrieve2(lf[66],"command-table"));}

/* a2241 in k2232 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2242(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2242,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(t4)){
/* csi.scm:399: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),t1,C_make_character(32),t4);}
else{
/* csi.scm:400: print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[19]+1)))(4,*((C_word*)lf[19]+1),t1,lf[119],t2);}}

/* k2235 in k2232 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2213 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:369: system */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),t2,t1);}

/* k2216 in k2213 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2221,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_list(&a,1,t1);
/* csi.scm:370: history-add */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t2,t3);}

/* k2219 in k2216 in k2213 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2221(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2204 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:366: copy-from-frame */
t2=C_retrieve2(lf[116],"copy-from-frame");
f_4535(t2,((C_word*)t0)[2],t1);}

/* k2191 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:363: select-frame */
t2=C_retrieve2(lf[114],"select-frame");
f_4478(t2,((C_word*)t0)[2],t1);}

/* k2184 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2172 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2160 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2148 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2132 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2134,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f6686,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:350: read-line */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}
else{
t2=C_retrieve2(lf[10],"default-editor");
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f6690,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:350: read-line */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t3);}}

/* f6690 in k2132 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f6690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:348: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[2],C_retrieve2(lf[10],"default-editor"),lf[108],t1);}

/* f6686 in k2132 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f6686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:348: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[3],((C_word*)t0)[2],lf[108],t1);}

/* k2128 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:347: system */
((C_proc3)C_retrieve_symbol_proc(lf[107]))(3,*((C_word*)lf[107]+1),((C_word*)t0)[2],t1);}

/* k2111 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
/* csi.scm:352: printf */
t2=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],lf[106],t1);}}

/* k2095 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:345: describe */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],C_retrieve(lf[104]));}

/* k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2045(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2045,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2050,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2077 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_2078r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2078r(t0,t1,t2);}}

static void C_ccall f_2078r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(5);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2082,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* csi.scm:340: history-add */
((C_proc3)C_retrieve_symbol_proc(lf[49]))(3,*((C_word*)lf[49]+1),t3,t2);}

/* k2080 in a2077 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2054,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#start-timer */
t3=*((C_word*)lf[102]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k2052 in a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2065,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2064 in k2052 in a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2065(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr2r,(void*)f_2065r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2065r(t0,t1,t2);}}

static void C_ccall f_2065r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(7);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2069,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2076,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#stop-timer */
t5=*((C_word*)lf[101]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2074 in a2064 in k2052 in a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#display-times */
((C_proc3)C_retrieve_symbol_proc(lf[100]))(3,*((C_word*)lf[100]+1),((C_word*)t0)[2],t1);}

/* k2067 in a2064 in k2052 in a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2069(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply_values(3,0,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2058 in k2052 in a2049 in k2043 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
/* csi.scm:339: eval */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,((C_word*)t0)[2]);}

/* k2034 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:334: string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k2009 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2014,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[98]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* a2018 in k2009 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2019(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2019,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* g229230 */
t4=((C_word*)t0)[2];
((C_proc5)C_retrieve_proc(t4))(5,t4,t1,t2,lf[97],t3);}

/* a2024 in a2018 in k2009 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2025,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2029,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:335: pretty-print */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t3,t2);}

/* k2027 in a2024 in a2018 in k2009 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:335: print* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[95]+1)))(3,*((C_word*)lf[95]+1),((C_word*)t0)[2],lf[96]);}

/* k2012 in k2009 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2014(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k2000 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_2002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:330: string-split */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1967 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1972,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1977,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1977(t6,t2,t1);}

/* loop199 in k1967 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1977(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1977,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[93]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1987,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g206207 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1985 in loop199 in k1967 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1987(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1977(t3,((C_word*)t0)[2],t2);}

/* k1970 in k1967 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k1928 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1933,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:323: read */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1931 in k1928 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1933,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1936,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:324: eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1934 in k1931 in k1928 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1936,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1939,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:325: eval */
t3=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[2]);}

/* k1937 in k1934 in k1931 in k1928 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:326: dump */
((C_proc4)C_retrieve_symbol_proc(lf[87]))(4,*((C_word*)lf[87]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1913 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:319: eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1916 in k1913 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:320: dump */
((C_proc3)C_retrieve_symbol_proc(lf[87]))(3,*((C_word*)lf[87]+1),((C_word*)t0)[2],t1);}

/* k1898 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1903,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:315: eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1901 in k1898 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:316: describe */
((C_proc3)C_retrieve_symbol_proc(lf[85]))(3,*((C_word*)lf[85]+1),((C_word*)t0)[2],t1);}

/* k1880 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1882(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1882,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1885,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:310: eval */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1883 in k1880 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1888,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:311: pretty-print */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}

/* k1886 in k1883 in k1880 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k1857 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1859,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1869,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1873,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:306: expand */
t5=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t5))(3,t5,t4,t1);}

/* k1871 in k1857 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:306: ##sys#strip-syntax */
((C_proc3)C_retrieve_symbol_proc(lf[82]))(3,*((C_word*)lf[82]+1),((C_word*)t0)[2],t1);}

/* k1867 in k1857 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:306: pretty-print */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k1860 in k1857 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* k1842 in k1831 in k1825 in ##sys#repl-eval-hook in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_retrieve(lf[50]));}

/* toplevel-command in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1770(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(c<4) C_bad_min_argc_2(c,4,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_1770r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_1770r(t0,t1,t2,t3,t4);}}

static void C_ccall f_1770r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1774,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_1774(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_1774(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k1772 in toplevel-command in k1766 in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1774,2,t0,t1);}
t2=C_i_check_symbol_2(((C_word*)t0)[4],lf[67]);
t3=(C_truep(t1)?C_i_check_string_2(t1,lf[67]):C_SCHEME_UNDEFINED);
t4=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
/* csi.scm:277: ##sys#hash-table-set! */
((C_proc5)C_retrieve_symbol_proc(lf[68]))(5,*((C_word*)lf[68]+1),((C_word*)t0)[2],C_retrieve2(lf[66],"command-table"),((C_word*)t0)[4],t4);}

/* ##sys#read-prompt-hook in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1754,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1761,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_fudge(C_fix(12));
if(C_truep(t3)){
if(C_truep(t3)){
/* csi.scm:270: old */
t4=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t4))(2,t4,t1);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
/* csi.scm:263: ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t2,*((C_word*)lf[63]+1));}}

/* k1759 in ##sys#read-prompt-hook in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm:270: old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##csi#tty-input? in k1737 in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=C_fudge(C_fix(12));
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* csi.scm:263: ##sys#tty-port? */
((C_proc3)C_retrieve_symbol_proc(lf[62]))(3,*((C_word*)lf[62]+1),t1,*((C_word*)lf[63]+1));}}

/* ##csi#history-ref in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1714(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1714,3,t0,t1,t2);}
t3=C_i_inexact_to_exact(t2);
t4=C_fixnum_greaterp(t3,C_fix(0));
t5=(C_truep(t4)?C_fixnum_less_or_equal_p(t3,C_retrieve(lf[29])):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_i_vector_ref(C_retrieve(lf[47]),t3));}
else{
/* csi.scm:255: ##sys#error */
t6=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[60],t2);}}

/* ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1667,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1673,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1673(t5,t1,C_fix(1));}

/* doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1673(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1673,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,C_retrieve(lf[29])))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1683,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=C_retrieve(lf[58]);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(35),t3);}}

/* k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k1684 in k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1689,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[12]+1)))(4,*((C_word*)lf[12]+1),t2,lf[57],((C_word*)t0)[2]);}

/* k1687 in k1684 in k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1692,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1704,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:245: ##sys#with-print-length-limit */
((C_proc4)C_retrieve_symbol_proc(lf[56]))(4,*((C_word*)lf[56]+1),t2,C_fix(80),t3);}

/* a1703 in k1687 in k1684 in k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1704,2,t0,t1);}
t2=C_i_vector_ref(C_retrieve(lf[47]),((C_word*)t0)[2]);
/* csi.scm:248: ##sys#print */
t3=*((C_word*)lf[55]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,C_SCHEME_TRUE,*((C_word*)lf[54]+1));}

/* k1690 in k1687 in k1684 in k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1695,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:249: newline */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k1693 in k1690 in k1687 in k1684 in k1681 in doloop112 in ##csi#history-show in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1673(t3,((C_word*)t0)[2],t2);}

/* ##csi#history-clear in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1657,2,t0,t1);}
t2=C_retrieve(lf[50]);
/* csi.scm:237: vector-fill! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[52]+1)))(4,*((C_word*)lf[52]+1),t1,C_retrieve(lf[47]),t2);}

/* ##csi#history-add in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1618(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1618,3,t0,t1,t2);}
t3=C_i_nullp(t2);
t4=(C_truep(t3)?C_retrieve(lf[50]):C_slot(t2,C_fix(0)));
t5=C_block_size(C_retrieve(lf[47]));
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1628,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(C_retrieve(lf[29]),t5))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1642,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=C_fixnum_times(C_fix(2),t5);
/* csi.scm:231: vector-resize */
t9=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t9))(4,t9,t7,C_retrieve(lf[47]),t8);}
else{
t7=t6;
f_1628(t7,C_SCHEME_UNDEFINED);}}

/* k1640 in ##csi#history-add in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1642(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate((C_word*)lf[47]+1 /* (set! ##csi#history-list ...) */,t1);
t3=((C_word*)t0)[2];
f_1628(t3,t2);}

/* k1626 in ##csi#history-add in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1628(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_vector_set(C_retrieve(lf[47]),C_retrieve(lf[29]),((C_word*)t0)[3]);
t3=C_fixnum_plus(C_retrieve(lf[29]),C_fix(1));
t4=C_mutate((C_word*)lf[29]+1 /* (set! ##csi#history-count ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,((C_word*)t0)[3]);}

/* ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1512,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1516,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* csi.scm:204: get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[45]))(3,*((C_word*)lf[45]+1),t3,lf[46]);}

/* k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1516,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[5]);
if(C_truep(C_i_greaterp(t2,C_fix(0)))){
t3=C_i_string_ref(((C_word*)t0)[5],C_fix(0));
t4=C_eqp(t3,C_make_character(92));
t5=(C_truep(t4)?t4:C_eqp(t3,C_make_character(47)));
if(C_truep(t5)){
/* csi.scm:206: addext */
f_1464(((C_word*)t0)[3],((C_word*)t0)[5]);}
else{
t6=C_retrieve2(lf[32],"dirseparator\077");
t7=((C_word*)t0)[5];
t8=C_block_size(t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1491,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=f_1491(t9,C_fix(0));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1540,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t12=((C_word*)t0)[2];
t13=C_a_i_bytevector(&a,1,C_fix(3));
t14=(C_truep(t12)?C_i_foreign_block_argumentp(t12):C_SCHEME_FALSE);
t15=C_i_foreign_fixnum_argumentp(C_fix(256));
t16=stub62(t13,t14,t15);
/* ##sys#peek-nonnull-c-string */
t17=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t11,t16,C_fix(0));}
else{
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* csi.scm:210: addext */
f_1464(t11,((C_word*)t0)[5]);}}}
else{
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1557,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1563,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:212: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,lf[44],((C_word*)t0)[2]);}}

/* k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1570,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:213: string-split */
((C_proc4)C_retrieve_symbol_proc(lf[42]))(4,*((C_word*)lf[42]+1),t2,((C_word*)t0)[2],lf[43]);}

/* k1568 in k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1572,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_1572(t5,((C_word*)t0)[2],t1);}

/* loop in k1568 in k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1572(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1572,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1582,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1599,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(0));
/* csi.scm:215: chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),t4,t5);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* k1597 in loop in k1568 in k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:215: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1580 in loop in k1568 in k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1585,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* csi.scm:216: addext */
f_1464(t2,t1);}

/* k1583 in k1580 in loop in k1568 in k1561 in k1555 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=C_slot(((C_word*)t0)[3],C_fix(1));
/* csi.scm:217: loop */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1572(t3,((C_word*)t0)[4],t2);}}

/* k1538 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1540,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1550,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1554,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:209: chop-separator */
((C_proc3)C_retrieve_symbol_proc(lf[34]))(3,*((C_word*)lf[34]+1),t3,t1);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k1552 in k1538 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:209: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[37]+1)))(5,*((C_word*)lf[37]+1),((C_word*)t0)[3],t1,lf[40],((C_word*)t0)[2]);}

/* k1548 in k1538 in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:209: addext */
f_1464(((C_word*)t0)[2],t1);}

/* loop in k1514 in ##csi#lookup-script-file in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static C_word C_fcall f_1491(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
loop:
C_stack_check;
if(C_truep(C_fixnum_greater_or_equal_p(t1,((C_word*)t0)[3]))){
return(C_SCHEME_FALSE);}
else{
t2=C_subchar(((C_word*)t0)[2],t1);
t3=C_eqp(t2,C_make_character(92));
t4=(C_truep(t3)?t3:C_eqp(t2,C_make_character(47)));
if(C_truep(t4)){
return(t1);}
else{
t5=C_fixnum_plus(t1,C_fix(1));
t7=t5;
t1=t7;
goto loop;}}}

/* addext in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1464(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1464,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1471,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* csi.scm:193: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t3,t2);}

/* k1469 in addext in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1471,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1474,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:195: string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[37]+1)))(4,*((C_word*)lf[37]+1),t2,((C_word*)t0)[3],lf[38]);}}

/* k1472 in k1469 in addext in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1474,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1480,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* csi.scm:196: file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[36]))(3,*((C_word*)lf[36]+1),t2,t1);}

/* k1478 in k1472 in k1469 in addext in k1443 in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?((C_word*)t0)[2]:C_SCHEME_FALSE));}

/* ##csi#chop-separator in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1414(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1414,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_i_string_ref(t2,t4);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1427,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greaterp(t4,C_fix(0)))){
t7=C_eqp(t5,C_make_character(92));
t8=t6;
f_1427(t8,(C_truep(t7)?t7:C_eqp(t5,C_make_character(47))));}
else{
t7=t6;
f_1427(t7,C_SCHEME_FALSE);}}

/* k1425 in ##csi#chop-separator in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_fcall f_1427(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* csi.scm:181: substring */
t2=((C_word*)t0)[5];
((C_proc5)C_retrieve_proc(t2))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* dirseparator? in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1402,3,t0,t1,t2);}
t3=C_eqp(t2,C_make_character(92));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_eqp(t2,C_make_character(47))));}

/* ##sys#sharp-number-hook in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1388(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1388,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1400,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:167: history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t4,t3);}

/* k1398 in ##sys#sharp-number-hook in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1400,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[28],t2));}

/* ##sys#user-read-hook in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1355,4,t0,t1,t2,t3);}
t4=C_eqp(C_make_character(41),t2);
t5=(C_truep(t4)?t4:C_u_i_char_whitespacep(t2));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1376,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t7=C_fixnum_difference(C_retrieve(lf[29]),C_fix(1));
/* csi.scm:162: history-ref */
((C_proc3)C_retrieve_symbol_proc(lf[30]))(3,*((C_word*)lf[30]+1),t6,t7);}
else{
/* csi.scm:163: old-hook */
t6=((C_word*)t0)[2];
((C_proc4)C_retrieve_proc(t6))(4,t6,t1,t2,t3);}}

/* k1374 in ##sys#user-read-hook in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1376,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[28],t2));}

/* ##csi#print-banner in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1339,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1343,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:132: newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[24]+1)))(2,*((C_word*)lf[24]+1),t2);}

/* k1341 in ##csi#print-banner in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1343,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1346,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:150: print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[19]+1)))(3,*((C_word*)lf[19]+1),t2,lf[23]);}

/* k1344 in k1341 in ##csi#print-banner in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1346,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1353,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* csi.scm:151: chicken-version */
((C_proc3)C_retrieve_symbol_proc(lf[22]))(3,*((C_word*)lf[22]+1),t2,C_SCHEME_TRUE);}

/* k1351 in k1344 in k1341 in ##csi#print-banner in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:151: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[19]+1)))(5,*((C_word*)lf[19]+1),((C_word*)t0)[2],lf[20],t1,lf[21]);}

/* ##csi#print-usage in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* csi.scm:83: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),t2,lf[17]);}

/* k1313 in ##csi#print-usage in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1325,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_a_i_cons(&a,2,lf[14],C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[2],t4);
t6=C_a_i_cons(&a,2,lf[15],t5);
/* csi.scm:104: ##sys#print-to-string */
((C_proc3)C_retrieve_symbol_proc(lf[16]))(3,*((C_word*)lf[16]+1),t3,t6);}

/* k1323 in k1313 in ##csi#print-usage in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:104: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],t1);}

/* k1316 in k1313 in ##csi#print-usage in k1307 in k1304 in k1299 in k1286 in k1283 in k1280 in k1277 in k1274 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* csi.scm:109: display */
((C_proc3)C_retrieve_proc(*((C_word*)lf[12]+1)))(3,*((C_word*)lf[12]+1),((C_word*)t0)[2],lf[13]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[489] = {
{"toplevel:csi_scm",(void*)C_toplevel},
{"f_1276:csi_scm",(void*)f_1276},
{"f_1279:csi_scm",(void*)f_1279},
{"f_1282:csi_scm",(void*)f_1282},
{"f_1285:csi_scm",(void*)f_1285},
{"f_1288:csi_scm",(void*)f_1288},
{"f_1301:csi_scm",(void*)f_1301},
{"f_1306:csi_scm",(void*)f_1306},
{"f_6118:csi_scm",(void*)f_6118},
{"f_6127:csi_scm",(void*)f_6127},
{"f_1309:csi_scm",(void*)f_1309},
{"f_1445:csi_scm",(void*)f_1445},
{"f_6111:csi_scm",(void*)f_6111},
{"f_1739:csi_scm",(void*)f_1739},
{"f_1768:csi_scm",(void*)f_1768},
{"f_2436:csi_scm",(void*)f_2436},
{"f_2439:csi_scm",(void*)f_2439},
{"f_2796:csi_scm",(void*)f_2796},
{"f_6100:csi_scm",(void*)f_6100},
{"f_6106:csi_scm",(void*)f_6106},
{"f_6103:csi_scm",(void*)f_6103},
{"f_5048:csi_scm",(void*)f_5048},
{"f_6094:csi_scm",(void*)f_6094},
{"f_2301:csi_scm",(void*)f_2301},
{"f_2365:csi_scm",(void*)f_2365},
{"f_2383:csi_scm",(void*)f_2383},
{"f_2422:csi_scm",(void*)f_2422},
{"f_2428:csi_scm",(void*)f_2428},
{"f_2389:csi_scm",(void*)f_2389},
{"f_2397:csi_scm",(void*)f_2397},
{"f_2399:csi_scm",(void*)f_2399},
{"f_2416:csi_scm",(void*)f_2416},
{"f_2371:csi_scm",(void*)f_2371},
{"f_2377:csi_scm",(void*)f_2377},
{"f_2308:csi_scm",(void*)f_2308},
{"f_2311:csi_scm",(void*)f_2311},
{"f_2313:csi_scm",(void*)f_2313},
{"f_2350:csi_scm",(void*)f_2350},
{"f_2353:csi_scm",(void*)f_2353},
{"f_2359:csi_scm",(void*)f_2359},
{"f_2323:csi_scm",(void*)f_2323},
{"f_5052:csi_scm",(void*)f_5052},
{"f_6090:csi_scm",(void*)f_6090},
{"f_5055:csi_scm",(void*)f_5055},
{"f_5058:csi_scm",(void*)f_5058},
{"f_5061:csi_scm",(void*)f_5061},
{"f_6086:csi_scm",(void*)f_6086},
{"f_6073:csi_scm",(void*)f_6073},
{"f_5983:csi_scm",(void*)f_5983},
{"f_5986:csi_scm",(void*)f_5986},
{"f_5989:csi_scm",(void*)f_5989},
{"f_5992:csi_scm",(void*)f_5992},
{"f_6001:csi_scm",(void*)f_6001},
{"f_5064:csi_scm",(void*)f_5064},
{"f_5067:csi_scm",(void*)f_5067},
{"f_5977:csi_scm",(void*)f_5977},
{"f_5070:csi_scm",(void*)f_5070},
{"f_5073:csi_scm",(void*)f_5073},
{"f_5076:csi_scm",(void*)f_5076},
{"f_5968:csi_scm",(void*)f_5968},
{"f_5929:csi_scm",(void*)f_5929},
{"f_5931:csi_scm",(void*)f_5931},
{"f_5960:csi_scm",(void*)f_5960},
{"f_5079:csi_scm",(void*)f_5079},
{"f_5919:csi_scm",(void*)f_5919},
{"f_5922:csi_scm",(void*)f_5922},
{"f_5236:csi_scm",(void*)f_5236},
{"f_5910:csi_scm",(void*)f_5910},
{"f_5913:csi_scm",(void*)f_5913},
{"f_5239:csi_scm",(void*)f_5239},
{"f_5242:csi_scm",(void*)f_5242},
{"f_5903:csi_scm",(void*)f_5903},
{"f_5896:csi_scm",(void*)f_5896},
{"f_5245:csi_scm",(void*)f_5245},
{"f_5883:csi_scm",(void*)f_5883},
{"f_5886:csi_scm",(void*)f_5886},
{"f_5248:csi_scm",(void*)f_5248},
{"f_5877:csi_scm",(void*)f_5877},
{"f_5251:csi_scm",(void*)f_5251},
{"f_5862:csi_scm",(void*)f_5862},
{"f6814:csi_scm",(void*)f6814},
{"f_5865:csi_scm",(void*)f_5865},
{"f_5868:csi_scm",(void*)f_5868},
{"f_5254:csi_scm",(void*)f_5254},
{"f_5836:csi_scm",(void*)f_5836},
{"f_5838:csi_scm",(void*)f_5838},
{"f_5848:csi_scm",(void*)f_5848},
{"f_5257:csi_scm",(void*)f_5257},
{"f_5809:csi_scm",(void*)f_5809},
{"f_5811:csi_scm",(void*)f_5811},
{"f_5821:csi_scm",(void*)f_5821},
{"f_5260:csi_scm",(void*)f_5260},
{"f_5782:csi_scm",(void*)f_5782},
{"f_5784:csi_scm",(void*)f_5784},
{"f_5794:csi_scm",(void*)f_5794},
{"f_5263:csi_scm",(void*)f_5263},
{"f_5743:csi_scm",(void*)f_5743},
{"f_5745:csi_scm",(void*)f_5745},
{"f_5774:csi_scm",(void*)f_5774},
{"f_5696:csi_scm",(void*)f_5696},
{"f_5704:csi_scm",(void*)f_5704},
{"f_5706:csi_scm",(void*)f_5706},
{"f_5735:csi_scm",(void*)f_5735},
{"f_5700:csi_scm",(void*)f_5700},
{"f_5692:csi_scm",(void*)f_5692},
{"f_5267:csi_scm",(void*)f_5267},
{"f_5270:csi_scm",(void*)f_5270},
{"f_5623:csi_scm",(void*)f_5623},
{"f_5626:csi_scm",(void*)f_5626},
{"f_5273:csi_scm",(void*)f_5273},
{"f_5611:csi_scm",(void*)f_5611},
{"f_5614:csi_scm",(void*)f_5614},
{"f_5276:csi_scm",(void*)f_5276},
{"f_5590:csi_scm",(void*)f_5590},
{"f_5593:csi_scm",(void*)f_5593},
{"f_5596:csi_scm",(void*)f_5596},
{"f_5599:csi_scm",(void*)f_5599},
{"f_5602:csi_scm",(void*)f_5602},
{"f_5279:csi_scm",(void*)f_5279},
{"f_5581:csi_scm",(void*)f_5581},
{"f_5133:csi_scm",(void*)f_5133},
{"f_5139:csi_scm",(void*)f_5139},
{"f_5161:csi_scm",(void*)f_5161},
{"f_5145:csi_scm",(void*)f_5145},
{"f_5148:csi_scm",(void*)f_5148},
{"f_5154:csi_scm",(void*)f_5154},
{"f_5282:csi_scm",(void*)f_5282},
{"f_5285:csi_scm",(void*)f_5285},
{"f_5290:csi_scm",(void*)f_5290},
{"f_5503:csi_scm",(void*)f_5503},
{"f_5558:csi_scm",(void*)f_5558},
{"f_5507:csi_scm",(void*)f_5507},
{"f_5513:csi_scm",(void*)f_5513},
{"f_5516:csi_scm",(void*)f_5516},
{"f_5527:csi_scm",(void*)f_5527},
{"f_5540:csi_scm",(void*)f_5540},
{"f_5543:csi_scm",(void*)f_5543},
{"f_5519:csi_scm",(void*)f_5519},
{"f_5522:csi_scm",(void*)f_5522},
{"f_5450:csi_scm",(void*)f_5450},
{"f_5471:csi_scm",(void*)f_5471},
{"f_5461:csi_scm",(void*)f_5461},
{"f_5469:csi_scm",(void*)f_5469},
{"f_5440:csi_scm",(void*)f_5440},
{"f_5430:csi_scm",(void*)f_5430},
{"f_5414:csi_scm",(void*)f_5414},
{"f_5404:csi_scm",(void*)f_5404},
{"f_5384:csi_scm",(void*)f_5384},
{"f_5368:csi_scm",(void*)f_5368},
{"f_5344:csi_scm",(void*)f_5344},
{"f_5315:csi_scm",(void*)f_5315},
{"f_5303:csi_scm",(void*)f_5303},
{"f_5166:csi_scm",(void*)f_5166},
{"f_5213:csi_scm",(void*)f_5213},
{"f_5170:csi_scm",(void*)f_5170},
{"f_5173:csi_scm",(void*)f_5173},
{"f_5180:csi_scm",(void*)f_5180},
{"f_5182:csi_scm",(void*)f_5182},
{"f_5205:csi_scm",(void*)f_5205},
{"f_5203:csi_scm",(void*)f_5203},
{"f_5192:csi_scm",(void*)f_5192},
{"f_5199:csi_scm",(void*)f_5199},
{"f_5081:csi_scm",(void*)f_5081},
{"f_5087:csi_scm",(void*)f_5087},
{"f_5095:csi_scm",(void*)f_5095},
{"f_5116:csi_scm",(void*)f_5116},
{"f_4903:csi_scm",(void*)f_4903},
{"f_4909:csi_scm",(void*)f_4909},
{"f_4931:csi_scm",(void*)f_4931},
{"f_4988:csi_scm",(void*)f_4988},
{"f_4981:csi_scm",(void*)f_4981},
{"f_4947:csi_scm",(void*)f_4947},
{"f_4970:csi_scm",(void*)f_4970},
{"f_4960:csi_scm",(void*)f_4960},
{"f_4964:csi_scm",(void*)f_4964},
{"f_5020:csi_scm",(void*)f_5020},
{"f_4846:csi_scm",(void*)f_4846},
{"f_4852:csi_scm",(void*)f_4852},
{"f_4864:csi_scm",(void*)f_4864},
{"f_4787:csi_scm",(void*)f_4787},
{"f_4791:csi_scm",(void*)f_4791},
{"f_4796:csi_scm",(void*)f_4796},
{"f_4825:csi_scm",(void*)f_4825},
{"f_4812:csi_scm",(void*)f_4812},
{"f_4749:csi_scm",(void*)f_4749},
{"f_4755:csi_scm",(void*)f_4755},
{"f_4771:csi_scm",(void*)f_4771},
{"f_4781:csi_scm",(void*)f_4781},
{"f_4535:csi_scm",(void*)f_4535},
{"f_4747:csi_scm",(void*)f_4747},
{"f_4545:csi_scm",(void*)f_4545},
{"f_4553:csi_scm",(void*)f_4553},
{"f_4576:csi_scm",(void*)f_4576},
{"f_4631:csi_scm",(void*)f_4631},
{"f_4701:csi_scm",(void*)f_4701},
{"f_4639:csi_scm",(void*)f_4639},
{"f_4645:csi_scm",(void*)f_4645},
{"f_4675:csi_scm",(void*)f_4675},
{"f_4658:csi_scm",(void*)f_4658},
{"f_4604:csi_scm",(void*)f_4604},
{"f_4556:csi_scm",(void*)f_4556},
{"f_4560:csi_scm",(void*)f_4560},
{"f_4478:csi_scm",(void*)f_4478},
{"f_4488:csi_scm",(void*)f_4488},
{"f_4211:csi_scm",(void*)f_4211},
{"f_4237:csi_scm",(void*)f_4237},
{"f_4246:csi_scm",(void*)f_4246},
{"f_4274:csi_scm",(void*)f_4274},
{"f_4277:csi_scm",(void*)f_4277},
{"f_4280:csi_scm",(void*)f_4280},
{"f_4446:csi_scm",(void*)f_4446},
{"f_4283:csi_scm",(void*)f_4283},
{"f_4286:csi_scm",(void*)f_4286},
{"f_4289:csi_scm",(void*)f_4289},
{"f_4292:csi_scm",(void*)f_4292},
{"f_4429:csi_scm",(void*)f_4429},
{"f_4432:csi_scm",(void*)f_4432},
{"f_4295:csi_scm",(void*)f_4295},
{"f_4298:csi_scm",(void*)f_4298},
{"f_4301:csi_scm",(void*)f_4301},
{"f_4331:csi_scm",(void*)f_4331},
{"f_4398:csi_scm",(void*)f_4398},
{"f_4339:csi_scm",(void*)f_4339},
{"f_4349:csi_scm",(void*)f_4349},
{"f_4354:csi_scm",(void*)f_4354},
{"f_4364:csi_scm",(void*)f_4364},
{"f_4367:csi_scm",(void*)f_4367},
{"f_4370:csi_scm",(void*)f_4370},
{"f_4373:csi_scm",(void*)f_4373},
{"f_4376:csi_scm",(void*)f_4376},
{"f_4304:csi_scm",(void*)f_4304},
{"f_4214:csi_scm",(void*)f_4214},
{"f_4220:csi_scm",(void*)f_4220},
{"f_4009:csi_scm",(void*)f_4009},
{"f_4041:csi_scm",(void*)f_4041},
{"f_4209:csi_scm",(void*)f_4209},
{"f_4051:csi_scm",(void*)f_4051},
{"f_4054:csi_scm",(void*)f_4054},
{"f_4126:csi_scm",(void*)f_4126},
{"f_4180:csi_scm",(void*)f_4180},
{"f_4202:csi_scm",(void*)f_4202},
{"f_4198:csi_scm",(void*)f_4198},
{"f_4183:csi_scm",(void*)f_4183},
{"f_4145:csi_scm",(void*)f_4145},
{"f_4160:csi_scm",(void*)f_4160},
{"f_4170:csi_scm",(void*)f_4170},
{"f_4057:csi_scm",(void*)f_4057},
{"f_4060:csi_scm",(void*)f_4060},
{"f_4075:csi_scm",(void*)f_4075},
{"f_4088:csi_scm",(void*)f_4088},
{"f_4091:csi_scm",(void*)f_4091},
{"f_4063:csi_scm",(void*)f_4063},
{"f_4066:csi_scm",(void*)f_4066},
{"f_4012:csi_scm",(void*)f_4012},
{"f_4016:csi_scm",(void*)f_4016},
{"f_4032:csi_scm",(void*)f_4032},
{"f_3848:csi_scm",(void*)f_3848},
{"f_3961:csi_scm",(void*)f_3961},
{"f_3956:csi_scm",(void*)f_3956},
{"f_3850:csi_scm",(void*)f_3850},
{"f_3875:csi_scm",(void*)f_3875},
{"f_3918:csi_scm",(void*)f_3918},
{"f_3928:csi_scm",(void*)f_3928},
{"f_3899:csi_scm",(void*)f_3899},
{"f_3882:csi_scm",(void*)f_3882},
{"f_3853:csi_scm",(void*)f_3853},
{"f_3839:csi_scm",(void*)f_3839},
{"f_3843:csi_scm",(void*)f_3843},
{"f_2798:csi_scm",(void*)f_2798},
{"f_2802:csi_scm",(void*)f_2802},
{"f_3818:csi_scm",(void*)f_3818},
{"f_2930:csi_scm",(void*)f_2930},
{"f_3065:csi_scm",(void*)f_3065},
{"f_2764:csi_scm",(void*)f_2764},
{"f_3177:csi_scm",(void*)f_3177},
{"f_3335:csi_scm",(void*)f_3335},
{"f_3363:csi_scm",(void*)f_3363},
{"f_3372:csi_scm",(void*)f_3372},
{"f_3466:csi_scm",(void*)f_3466},
{"f_3681:csi_scm",(void*)f_3681},
{"f_3696:csi_scm",(void*)f_3696},
{"f_3775:csi_scm",(void*)f_3775},
{"f_3714:csi_scm",(void*)f_3714},
{"f_3736:csi_scm",(void*)f_3736},
{"f_3765:csi_scm",(void*)f_3765},
{"f_3726:csi_scm",(void*)f_3726},
{"f_3722:csi_scm",(void*)f_3722},
{"f_3700:csi_scm",(void*)f_3700},
{"f_3592:csi_scm",(void*)f_3592},
{"f_3601:csi_scm",(void*)f_3601},
{"f_3660:csi_scm",(void*)f_3660},
{"f_3609:csi_scm",(void*)f_3609},
{"f_3613:csi_scm",(void*)f_3613},
{"f_3622:csi_scm",(void*)f_3622},
{"f_3657:csi_scm",(void*)f_3657},
{"f_3649:csi_scm",(void*)f_3649},
{"f_3632:csi_scm",(void*)f_3632},
{"f_3497:csi_scm",(void*)f_3497},
{"f_3500:csi_scm",(void*)f_3500},
{"f_3511:csi_scm",(void*)f_3511},
{"f_3534:csi_scm",(void*)f_3534},
{"f_3557:csi_scm",(void*)f_3557},
{"f_3542:csi_scm",(void*)f_3542},
{"f_3521:csi_scm",(void*)f_3521},
{"f_3485:csi_scm",(void*)f_3485},
{"f_3472:csi_scm",(void*)f_3472},
{"f_3460:csi_scm",(void*)f_3460},
{"f_3379:csi_scm",(void*)f_3379},
{"f_3354:csi_scm",(void*)f_3354},
{"f_3295:csi_scm",(void*)f_3295},
{"f_3309:csi_scm",(void*)f_3309},
{"f_3305:csi_scm",(void*)f_3305},
{"f_3180:csi_scm",(void*)f_3180},
{"f_3189:csi_scm",(void*)f_3189},
{"f_3220:csi_scm",(void*)f_3220},
{"f_2725:csi_scm",(void*)f_2725},
{"f_3165:csi_scm",(void*)f_3165},
{"f_3081:csi_scm",(void*)f_3081},
{"f_3084:csi_scm",(void*)f_3084},
{"f_3162:csi_scm",(void*)f_3162},
{"f_3153:csi_scm",(void*)f_3153},
{"f_3087:csi_scm",(void*)f_3087},
{"f_3099:csi_scm",(void*)f_3099},
{"f_3104:csi_scm",(void*)f_3104},
{"f_3114:csi_scm",(void*)f_3114},
{"f_3129:csi_scm",(void*)f_3129},
{"f_3117:csi_scm",(void*)f_3117},
{"f_3120:csi_scm",(void*)f_3120},
{"f_3072:csi_scm",(void*)f_3072},
{"f_2999:csi_scm",(void*)f_2999},
{"f_3005:csi_scm",(void*)f_3005},
{"f_2933:csi_scm",(void*)f_2933},
{"f_2804:csi_scm",(void*)f_2804},
{"f_2927:csi_scm",(void*)f_2927},
{"f_2811:csi_scm",(void*)f_2811},
{"f_2816:csi_scm",(void*)f_2816},
{"f_2839:csi_scm",(void*)f_2839},
{"f_2848:csi_scm",(void*)f_2848},
{"f_2912:csi_scm",(void*)f_2912},
{"f_2858:csi_scm",(void*)f_2858},
{"f_2861:csi_scm",(void*)f_2861},
{"f_2440:csi_scm",(void*)f_2440},
{"f_2448:csi_scm",(void*)f_2448},
{"f_2450:csi_scm",(void*)f_2450},
{"f_2454:csi_scm",(void*)f_2454},
{"f_2457:csi_scm",(void*)f_2457},
{"f_2460:csi_scm",(void*)f_2460},
{"f_2477:csi_scm",(void*)f_2477},
{"f_2674:csi_scm",(void*)f_2674},
{"f_2703:csi_scm",(void*)f_2703},
{"f_2672:csi_scm",(void*)f_2672},
{"f_2668:csi_scm",(void*)f_2668},
{"f_2589:csi_scm",(void*)f_2589},
{"f_2591:csi_scm",(void*)f_2591},
{"f_2653:csi_scm",(void*)f_2653},
{"f_2599:csi_scm",(void*)f_2599},
{"f_2603:csi_scm",(void*)f_2603},
{"f_2608:csi_scm",(void*)f_2608},
{"f_2639:csi_scm",(void*)f_2639},
{"f_2616:csi_scm",(void*)f_2616},
{"f_2628:csi_scm",(void*)f_2628},
{"f_2624:csi_scm",(void*)f_2624},
{"f_2480:csi_scm",(void*)f_2480},
{"f_2508:csi_scm",(void*)f_2508},
{"f_2516:csi_scm",(void*)f_2516},
{"f_2520:csi_scm",(void*)f_2520},
{"f_2524:csi_scm",(void*)f_2524},
{"f_2528:csi_scm",(void*)f_2528},
{"f_2532:csi_scm",(void*)f_2532},
{"f_2536:csi_scm",(void*)f_2536},
{"f_2564:csi_scm",(void*)f_2564},
{"f_2483:csi_scm",(void*)f_2483},
{"f_2486:csi_scm",(void*)f_2486},
{"f_2489:csi_scm",(void*)f_2489},
{"f_2492:csi_scm",(void*)f_2492},
{"f_2462:csi_scm",(void*)f_2462},
{"f_2470:csi_scm",(void*)f_2470},
{"f_1811:csi_scm",(void*)f_1811},
{"f_1827:csi_scm",(void*)f_1827},
{"f_2278:csi_scm",(void*)f_2278},
{"f_2282:csi_scm",(void*)f_2282},
{"f_2272:csi_scm",(void*)f_2272},
{"f_1833:csi_scm",(void*)f_1833},
{"f_2258:csi_scm",(void*)f_2258},
{"f_2234:csi_scm",(void*)f_2234},
{"f_2242:csi_scm",(void*)f_2242},
{"f_2237:csi_scm",(void*)f_2237},
{"f_2215:csi_scm",(void*)f_2215},
{"f_2218:csi_scm",(void*)f_2218},
{"f_2221:csi_scm",(void*)f_2221},
{"f_2206:csi_scm",(void*)f_2206},
{"f_2193:csi_scm",(void*)f_2193},
{"f_2186:csi_scm",(void*)f_2186},
{"f_2174:csi_scm",(void*)f_2174},
{"f_2162:csi_scm",(void*)f_2162},
{"f_2150:csi_scm",(void*)f_2150},
{"f_2134:csi_scm",(void*)f_2134},
{"f6690:csi_scm",(void*)f6690},
{"f6686:csi_scm",(void*)f6686},
{"f_2130:csi_scm",(void*)f_2130},
{"f_2113:csi_scm",(void*)f_2113},
{"f_2097:csi_scm",(void*)f_2097},
{"f_2045:csi_scm",(void*)f_2045},
{"f_2078:csi_scm",(void*)f_2078},
{"f_2082:csi_scm",(void*)f_2082},
{"f_2050:csi_scm",(void*)f_2050},
{"f_2054:csi_scm",(void*)f_2054},
{"f_2065:csi_scm",(void*)f_2065},
{"f_2076:csi_scm",(void*)f_2076},
{"f_2069:csi_scm",(void*)f_2069},
{"f_2059:csi_scm",(void*)f_2059},
{"f_2036:csi_scm",(void*)f_2036},
{"f_2011:csi_scm",(void*)f_2011},
{"f_2019:csi_scm",(void*)f_2019},
{"f_2025:csi_scm",(void*)f_2025},
{"f_2029:csi_scm",(void*)f_2029},
{"f_2014:csi_scm",(void*)f_2014},
{"f_2002:csi_scm",(void*)f_2002},
{"f_1969:csi_scm",(void*)f_1969},
{"f_1977:csi_scm",(void*)f_1977},
{"f_1987:csi_scm",(void*)f_1987},
{"f_1972:csi_scm",(void*)f_1972},
{"f_1930:csi_scm",(void*)f_1930},
{"f_1933:csi_scm",(void*)f_1933},
{"f_1936:csi_scm",(void*)f_1936},
{"f_1939:csi_scm",(void*)f_1939},
{"f_1915:csi_scm",(void*)f_1915},
{"f_1918:csi_scm",(void*)f_1918},
{"f_1900:csi_scm",(void*)f_1900},
{"f_1903:csi_scm",(void*)f_1903},
{"f_1882:csi_scm",(void*)f_1882},
{"f_1885:csi_scm",(void*)f_1885},
{"f_1888:csi_scm",(void*)f_1888},
{"f_1859:csi_scm",(void*)f_1859},
{"f_1873:csi_scm",(void*)f_1873},
{"f_1869:csi_scm",(void*)f_1869},
{"f_1862:csi_scm",(void*)f_1862},
{"f_1844:csi_scm",(void*)f_1844},
{"f_1770:csi_scm",(void*)f_1770},
{"f_1774:csi_scm",(void*)f_1774},
{"f_1754:csi_scm",(void*)f_1754},
{"f_1761:csi_scm",(void*)f_1761},
{"f_1741:csi_scm",(void*)f_1741},
{"f_1714:csi_scm",(void*)f_1714},
{"f_1667:csi_scm",(void*)f_1667},
{"f_1673:csi_scm",(void*)f_1673},
{"f_1683:csi_scm",(void*)f_1683},
{"f_1686:csi_scm",(void*)f_1686},
{"f_1689:csi_scm",(void*)f_1689},
{"f_1704:csi_scm",(void*)f_1704},
{"f_1692:csi_scm",(void*)f_1692},
{"f_1695:csi_scm",(void*)f_1695},
{"f_1657:csi_scm",(void*)f_1657},
{"f_1618:csi_scm",(void*)f_1618},
{"f_1642:csi_scm",(void*)f_1642},
{"f_1628:csi_scm",(void*)f_1628},
{"f_1512:csi_scm",(void*)f_1512},
{"f_1516:csi_scm",(void*)f_1516},
{"f_1557:csi_scm",(void*)f_1557},
{"f_1563:csi_scm",(void*)f_1563},
{"f_1570:csi_scm",(void*)f_1570},
{"f_1572:csi_scm",(void*)f_1572},
{"f_1599:csi_scm",(void*)f_1599},
{"f_1582:csi_scm",(void*)f_1582},
{"f_1585:csi_scm",(void*)f_1585},
{"f_1540:csi_scm",(void*)f_1540},
{"f_1554:csi_scm",(void*)f_1554},
{"f_1550:csi_scm",(void*)f_1550},
{"f_1491:csi_scm",(void*)f_1491},
{"f_1464:csi_scm",(void*)f_1464},
{"f_1471:csi_scm",(void*)f_1471},
{"f_1474:csi_scm",(void*)f_1474},
{"f_1480:csi_scm",(void*)f_1480},
{"f_1414:csi_scm",(void*)f_1414},
{"f_1427:csi_scm",(void*)f_1427},
{"f_1402:csi_scm",(void*)f_1402},
{"f_1388:csi_scm",(void*)f_1388},
{"f_1400:csi_scm",(void*)f_1400},
{"f_1355:csi_scm",(void*)f_1355},
{"f_1376:csi_scm",(void*)f_1376},
{"f_1339:csi_scm",(void*)f_1339},
{"f_1343:csi_scm",(void*)f_1343},
{"f_1346:csi_scm",(void*)f_1346},
{"f_1353:csi_scm",(void*)f_1353},
{"f_1311:csi_scm",(void*)f_1311},
{"f_1315:csi_scm",(void*)f_1315},
{"f_1325:csi_scm",(void*)f_1325},
{"f_1318:csi_scm",(void*)f_1318},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
