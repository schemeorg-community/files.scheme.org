/* Generated from tcp.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: tcp.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file tcp.c
   unit: tcp
*/

#include "chicken.h"

#include <errno.h>
#ifdef _WIN32
# if _MSC_VER > 1300
# include <winsock2.h>
# include <ws2tcpip.h>
# else
# include <winsock.h>
# endif
/* Beware: winsock2.h must come BEFORE windows.h */
# define socklen_t       int
static WSADATA wsa;
# define fcntl(a, b, c)  0
# define EWOULDBLOCK     0
# define EINPROGRESS     0
# define typecorrect_getsockopt(socket, level, optname, optval, optlen)	\
    getsockopt(socket, level, optname, (char *)optval, optlen)
#else
# include <fcntl.h>
# include <sys/types.h>
# include <sys/socket.h>
# include <sys/time.h>
# include <netinet/in.h>
# include <unistd.h>
# include <netdb.h>
# include <signal.h>
# define closesocket     close
# define INVALID_SOCKET  -1
# define typecorrect_getsockopt getsockopt
#endif

#ifndef SD_RECEIVE
# define SD_RECEIVE      0
# define SD_SEND         1
#endif

#ifdef ECOS
#include <sys/sockio.h>
#endif

static char addr_buffer[ 20 ];

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[95];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,43),40,35,35,110,101,116,35,103,101,116,104,111,115,116,97,100,100,114,32,97,49,56,55,49,57,50,32,97,49,56,54,49,57,51,32,97,49,56,53,49,57,52,41,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,56,54,51,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,16),40,97,56,53,52,32,114,101,116,117,114,110,49,57,55,41};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,7),40,121,105,101,108,100,41,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,7),40,97,49,48,55,51,41,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,32),40,97,49,48,55,57,32,115,50,53,56,50,53,57,50,54,50,32,97,100,100,114,50,54,48,50,54,49,50,54,51,41};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,22),40,98,111,100,121,50,52,56,32,119,50,53,54,32,104,111,115,116,50,53,55,41,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,22),40,100,101,102,45,104,111,115,116,50,53,49,32,37,119,50,52,54,50,55,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,10),40,100,101,102,45,119,50,53,48,41,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,30),40,116,99,112,45,108,105,115,116,101,110,32,112,111,114,116,50,52,52,32,46,32,109,111,114,101,50,52,53,41,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,108,105,115,116,101,110,101,114,63,32,120,50,55,56,41,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,116,99,112,45,99,108,111,115,101,32,116,99,112,108,50,56,48,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,13),40,102,95,49,50,49,54,32,120,50,56,55,41,0,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,14),40,99,104,101,99,107,32,108,111,99,50,56,54,41,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,12),40,114,101,97,100,45,105,110,112,117,116,41,0,0,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,23),40,108,111,111,112,32,108,101,110,51,56,57,32,111,102,102,115,101,116,51,57,48,41,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,13),40,111,117,116,112,117,116,32,115,51,56,55,41,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,52,54,32,115,52,48,54,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,13),40,102,95,49,53,54,54,32,115,52,48,57,41,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,54,41,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,8),40,102,95,49,53,51,48,41};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,7),40,97,49,53,56,49,41,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,7),40,97,49,54,48,51,41,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,7),40,97,49,54,51,56,41,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,7),40,97,49,54,56,49,41,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,25),40,108,111,111,112,32,110,51,52,55,32,109,51,52,56,32,115,116,97,114,116,51,52,57,41,0,0,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,34),40,97,49,54,57,57,32,112,51,52,50,32,110,51,52,51,32,100,101,115,116,51,52,52,32,115,116,97,114,116,51,52,53,41,0,0,0,0,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,23),40,97,49,55,57,48,32,112,111,115,50,51,54,55,32,110,101,120,116,51,54,56,41,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,22),40,108,111,111,112,32,115,116,114,51,54,50,32,108,105,109,105,116,51,54,51,41,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,21),40,97,49,55,54,52,32,112,51,53,57,32,108,105,109,105,116,51,54,48,41,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,22),40,35,35,110,101,116,35,105,111,45,112,111,114,116,115,32,102,100,50,57,54,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,99,99,101,112,116,32,116,99,112,108,52,50,54,41,0,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,97,99,99,101,112,116,45,114,101,97,100,121,63,32,116,99,112,108,52,51,57,41,0,0,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,6),40,102,97,105,108,41,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,11),40,108,111,111,112,32,105,50,48,53,41,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,7),40,97,50,50,54,50,41,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,29),40,97,50,50,54,56,32,104,111,115,116,52,53,57,52,54,49,32,112,111,114,116,52,54,48,52,54,50,41,0,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,31),40,116,99,112,45,99,111,110,110,101,99,116,32,104,111,115,116,52,53,51,32,46,32,109,111,114,101,52,53,52,41,0};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,29),40,35,35,115,121,115,35,116,99,112,45,112,111,114,116,45,62,102,105,108,101,110,111,32,112,52,57,53,41,0,0,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,20),40,116,99,112,45,97,100,100,114,101,115,115,101,115,32,112,52,57,55,41,0,0,0,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,112,111,114,116,45,110,117,109,98,101,114,115,32,112,53,48,54,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,27),40,116,99,112,45,108,105,115,116,101,110,101,114,45,112,111,114,116,32,116,99,112,108,53,49,53,41,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,23),40,116,99,112,45,97,98,97,110,100,111,110,45,112,111,114,116,32,112,53,50,48,41,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,26),40,116,99,112,45,108,105,115,116,101,110,101,114,45,102,105,108,101,110,111,32,108,53,50,50,41,0,0,0,0,0,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k2036 */
static C_word C_fcall stub449(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub449(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_mpointer(&C_a,(void*)strerror(t0));
return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub445(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub445(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int err, optlen;optlen = sizeof(err);if (typecorrect_getsockopt(socket, SOL_SOCKET, SO_ERROR, &err, (socklen_t *)&optlen) == -1)C_return(-1);C_return(err);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub231(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub231(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int socket=(int )C_unfix(C_a0);
int yes = 1; 
                      C_return(setsockopt(socket, SOL_SOCKET, SO_REUSEADDR, (const char *)&yes, sizeof(int)));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub214(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub214(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a1);
struct sockaddr_in *addr = (struct sockaddr_in *)saddr;memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons(port);addr->sin_addr.s_addr = htonl(INADDR_ANY);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub188(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
void * saddr=(void * )C_data_pointer_or_null(C_a0);
char * host=(char * )C_string_or_null(C_a1);
unsigned short port=(unsigned short )(unsigned short)C_unfix(C_a2);
struct hostent *he = gethostbyname(host);struct sockaddr_in *addr = (struct sockaddr_in *)saddr;if(he == NULL) C_return(0);memset(addr, 0, sizeof(struct sockaddr_in));addr->sin_family = AF_INET;addr->sin_port = htons((short)port);addr->sin_addr = *((struct in_addr *)he->h_addr);C_return(1);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub182(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub182(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set out;
     struct timeval tm;
     int rv;
     FD_ZERO(&out);
     FD_SET(fd, &out);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, NULL, &out, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &out) ? 1 : 0; }
     C_return(rv);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub178(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub178(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
fd_set in;
     struct timeval tm;
     int rv;
     FD_ZERO(&in);
     FD_SET(fd, &in);
     tm.tv_sec = tm.tv_usec = 0;
     rv = select(fd + 1, &in, NULL, NULL, &tm);
     if(rv > 0) { rv = FD_ISSET(fd, &in) ? 1 : 0; }
     C_return(rv);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub169(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub169(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * serv=(char * )C_string_or_null(C_a0);
char * proto=(char * )C_string_or_null(C_a1);
struct servent *se;
     if((se = getservbyname(serv, proto)) == NULL) C_return(0);
     else C_return(ntohs(se->s_port));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub165(C_word C_buf) C_regparm;
C_regparm static C_word C_fcall stub165(C_word C_buf){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
#ifdef _WIN32
     C_return(WSAStartup(MAKEWORD(1, 1), &wsa) == 0);
#else
     signal(SIGPIPE, SIG_IGN);
     C_return(1);
#endif
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub161(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub161(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;unsigned int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, ((unsigned int *)&len)) != 0) C_return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);C_return(addr_buffer);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub157(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub157(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getpeername(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) C_return(-1);else C_return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub153(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub153(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)(&len)) != 0) C_return(-1);else C_return(ntohs(sa.sin_port));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mpointer(&C_a,(void*)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub148(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub148(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
struct sockaddr_in sa;unsigned char *ptr;int len = sizeof(struct sockaddr_in);if(getsockname(s, (struct sockaddr *)&sa, (socklen_t *)&len) != 0) C_return(NULL);ptr = (unsigned char *)&sa.sin_addr;sprintf(addr_buffer, "%d.%d.%d.%d", ptr[ 0 ], ptr[ 1 ], ptr[ 2 ], ptr[ 3 ]);C_return(addr_buffer);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_mk_bool((x))); goto C_ret; C_cblockend
static C_word C_fcall stub144(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub144(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int fd=(int )C_unfix(C_a0);
int val = fcntl(fd, F_GETFL, 0);if(val == -1) C_return(0);C_return(fcntl(fd, F_SETFL, val | O_NONBLOCK) != -1);
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub134(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4) C_regparm;
C_regparm static C_word C_fcall stub134(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3,C_word C_a4){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int s=(int )C_unfix(C_a0);
void * msg=(void * )C_data_pointer_or_null(C_a1);
int offset=(int )C_unfix(C_a2);
int len=(int )C_unfix(C_a3);
int flags=(int )C_unfix(C_a4);
C_return(send(s, (char *)msg+offset, len, flags));
C_ret:
#undef return

return C_r;}

/* from k703 */
static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub122(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)connect(t0,t1,t2));
return C_r;}

/* from k688 */
static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub115(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)shutdown(t0,t1));
return C_r;}

/* from k674 */
static C_word C_fcall stub105(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub105(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_unfix(C_a3);
C_r=C_fix((C_word)recv(t0,t1,t2,t3));
return C_r;}

/* from k655 */
static C_word C_fcall stub98(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub98(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)closesocket(t0));
return C_r;}

/* from k642 */
static C_word C_fcall stub88(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub88(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_c_pointer_or_null(C_a1);
void * t2=(void * )C_c_pointer_or_null(C_a2);
C_r=C_fix((C_word)accept(t0,t1,t2));
return C_r;}

/* from k627 */
static C_word C_fcall stub81(C_word C_buf,C_word C_a0,C_word C_a1) C_regparm;
C_regparm static C_word C_fcall stub81(C_word C_buf,C_word C_a0,C_word C_a1){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
C_r=C_fix((C_word)listen(t0,t1));
return C_r;}

/* from k613 */
static C_word C_fcall stub72(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub72(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
void * t1=(void * )C_data_pointer_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)bind(t0,t1,t2));
return C_r;}

/* from k598 */
static C_word C_fcall stub64(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2) C_regparm;
C_regparm static C_word C_fcall stub64(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
int t1=(int )C_unfix(C_a1);
int t2=(int )C_unfix(C_a2);
C_r=C_fix((C_word)socket(t0,t1,t2));
return C_r;}

C_noret_decl(C_tcp_toplevel)
C_externexport void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_579)
static void C_ccall f_579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_582)
static void C_ccall f_582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_585)
static void C_ccall f_585(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_783)
static void C_ccall f_783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1208)
static void C_ccall f_1208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2479)
static void C_ccall f_2479(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1231)
static void C_ccall f_1231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2475)
static void C_ccall f_2475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1235)
static void C_ccall f_1235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2471)
static void C_ccall f_2471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2467)
static void C_ccall f_2467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1243)
static void C_ccall f_1243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2456)
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2436)
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2440)
static void C_ccall f_2440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2447)
static void C_ccall f_2447(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2407)
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2434)
static void C_ccall f_2434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2430)
static void C_ccall f_2430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2359)
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2363)
static void C_ccall f_2363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2366)
static void C_ccall f_2366(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2401)
static void C_ccall f_2401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2376)
static void C_ccall f_2376(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2394)
static void C_ccall f_2394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2383)
static void C_ccall f_2383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2311)
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2357)
static void C_ccall f_2357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2353)
static void C_ccall f_2353(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2328)
static void C_ccall f_2328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2332)
static void C_ccall f_2332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2346)
static void C_ccall f_2346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2342)
static void C_ccall f_2342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2335)
static void C_ccall f_2335(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2293)
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2297)
static void C_ccall f_2297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_2040)
static void C_ccall f_2040r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_2044)
static void C_ccall f_2044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2047)
static void C_ccall f_2047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2269)
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2263)
static void C_ccall f_2263(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_879)
static void C_fcall f_879(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_902)
static void C_ccall f_902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_906)
static void C_ccall f_906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_790)
static void C_ccall f_790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_794)
static void C_ccall f_794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_929)
static void C_ccall f_929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_925)
static void C_ccall f_925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_912)
static void C_ccall f_912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2053)
static void C_ccall f_2053(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2059)
static void C_ccall f_2059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2241)
static void C_ccall f_2241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2252)
static void C_ccall f_2252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2248)
static void C_ccall f_2248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2085)
static void C_ccall f_2085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2232)
static void C_ccall f_2232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2088)
static void C_ccall f_2088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2218)
static void C_ccall f_2218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2229)
static void C_ccall f_2229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_ccall f_2225(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2091)
static void C_ccall f_2091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2154)
static void C_fcall f_2154(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_ccall f_2161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2170)
static void C_ccall f_2170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2173)
static void C_ccall f_2173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2176)
static void C_ccall f_2176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2179)
static void C_ccall f_2179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2094)
static void C_ccall f_2094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2140)
static void C_ccall f_2140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2136)
static void C_ccall f_2136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2120)
static void C_ccall f_2120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2116)
static void C_ccall f_2116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2100)
static void C_ccall f_2100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_fcall f_2064(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2082)
static void C_ccall f_2082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2078)
static void C_ccall f_2078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1986)
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2012)
static void C_ccall f_2012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1900)
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1910)
static void C_ccall f_1910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1915)
static void C_fcall f_1915(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1980)
static void C_ccall f_1980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1951)
static void C_ccall f_1951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1954)
static void C_ccall f_1954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1957)
static void C_ccall f_1957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1960)
static void C_ccall f_1960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1937)
static void C_ccall f_1937(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1948)
static void C_ccall f_1948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1944)
static void C_ccall f_1944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1245)
static void C_fcall f_1245(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1887)
static void C_ccall f_1887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1898)
static void C_ccall f_1898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1894)
static void C_ccall f_1894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1252)
static void C_ccall f_1252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1258)
static void C_ccall f_1258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1261)
static void C_fcall f_1261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1267)
static void C_ccall f_1267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1765)
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1775)
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1863)
static void C_ccall f_1863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1789)
static void C_ccall f_1789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1791)
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1798)
static void C_ccall f_1798(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1820)
static void C_ccall f_1820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1836)
static void C_ccall f_1836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1700)
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_1706)
static void C_fcall f_1706(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1754)
static void C_ccall f_1754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1639)
static void C_ccall f_1639(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1647)
static void C_fcall f_1647(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1667)
static void C_ccall f_1667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1604)
static void C_ccall f_1604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1626)
static void C_ccall f_1626(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1637)
static void C_ccall f_1637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1633)
static void C_ccall f_1633(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1617)
static void C_ccall f_1617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1582)
static void C_ccall f_1582(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1344)
static void C_ccall f_1344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_ccall f_1530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1540)
static void C_ccall f_1540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1467)
static void C_ccall f_1467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1514)
static void C_fcall f_1514(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1517)
static void C_ccall f_1517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_fcall f_1475(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1478)
static void C_fcall f_1478(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_fcall f_1484(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1487)
static void C_ccall f_1487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1494)
static void C_ccall f_1494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1546)
static void C_ccall f_1546(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1551)
static void C_ccall f_1551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1560)
static void C_ccall f_1560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1440)
static void C_ccall f_1440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1455)
static void C_ccall f_1455(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1458)
static void C_ccall f_1458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1345)
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1355)
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1420)
static void C_ccall f_1420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1416)
static void C_ccall f_1416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1406)
static void C_ccall f_1406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1377)
static void C_ccall f_1377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1380)
static void C_ccall f_1380(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1383)
static void C_ccall f_1383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1386)
static void C_ccall f_1386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1268)
static void C_fcall f_1268(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1274)
static void C_fcall f_1274(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1325)
static void C_ccall f_1325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1336)
static void C_ccall f_1336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1322)
static void C_ccall f_1322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1293)
static void C_ccall f_1293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1296)
static void C_ccall f_1296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1299)
static void C_ccall f_1299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1214)
static void C_fcall f_1214(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1216)
static void C_ccall f_1216(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1173)
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1189)
static void C_ccall f_1189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1200)
static void C_ccall f_1200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1196)
static void C_ccall f_1196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1164)
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1066)
static void C_ccall f_1066r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1116)
static void C_fcall f_1116(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1111)
static void C_fcall f_1111(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1068)
static void C_fcall f_1068(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1080)
static void C_ccall f_1080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1099)
static void C_ccall f_1099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1110)
static void C_ccall f_1110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1106)
static void C_ccall f_1106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1090)
static void C_ccall f_1090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1074)
static void C_ccall f_1074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1049)
static void C_ccall f_1049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_969)
static void C_ccall f_969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1022)
static void C_ccall f_1022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1033)
static void C_ccall f_1033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1029)
static void C_ccall f_1029(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_972)
static void C_ccall f_972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_975)
static void C_ccall f_975(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1010)
static void C_ccall f_1010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_993)
static void C_ccall f_993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1004)
static void C_ccall f_1004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1000)
static void C_ccall f_1000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_984)
static void C_ccall f_984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_849)
static void C_fcall f_849(C_word t0) C_noret;
C_noret_decl(f_855)
static void C_ccall f_855(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_864)
static void C_ccall f_864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_824)
static void C_fcall f_824(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_833)
static void C_ccall f_833(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_879)
static void C_fcall trf_879(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_879(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_879(t0,t1,t2);}

C_noret_decl(trf_2154)
static void C_fcall trf_2154(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2154(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2154(t0,t1);}

C_noret_decl(trf_2064)
static void C_fcall trf_2064(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2064(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2064(t0,t1);}

C_noret_decl(trf_1915)
static void C_fcall trf_1915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1915(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1915(t0,t1);}

C_noret_decl(trf_1245)
static void C_fcall trf_1245(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1245(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1245(t0,t1,t2);}

C_noret_decl(trf_1261)
static void C_fcall trf_1261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1261(t0,t1);}

C_noret_decl(trf_1775)
static void C_fcall trf_1775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1775(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1775(t0,t1,t2,t3);}

C_noret_decl(trf_1706)
static void C_fcall trf_1706(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1706(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1706(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1647)
static void C_fcall trf_1647(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1647(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1647(t0,t1);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1653(t0,t1);}

C_noret_decl(trf_1514)
static void C_fcall trf_1514(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1514(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1514(t0,t1);}

C_noret_decl(trf_1475)
static void C_fcall trf_1475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1475(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1475(t0,t1);}

C_noret_decl(trf_1478)
static void C_fcall trf_1478(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1478(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1478(t0,t1);}

C_noret_decl(trf_1484)
static void C_fcall trf_1484(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1484(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1484(t0,t1);}

C_noret_decl(trf_1345)
static void C_fcall trf_1345(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1345(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1345(t0,t1,t2);}

C_noret_decl(trf_1355)
static void C_fcall trf_1355(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1355(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1355(t0,t1,t2,t3);}

C_noret_decl(trf_1268)
static void C_fcall trf_1268(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1268(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1268(t0,t1);}

C_noret_decl(trf_1274)
static void C_fcall trf_1274(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1274(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1274(t0,t1);}

C_noret_decl(trf_1214)
static void C_fcall trf_1214(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1214(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1214(t0,t1);}

C_noret_decl(trf_1116)
static void C_fcall trf_1116(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1116(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1116(t0,t1);}

C_noret_decl(trf_1111)
static void C_fcall trf_1111(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1111(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1111(t0,t1,t2);}

C_noret_decl(trf_1068)
static void C_fcall trf_1068(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1068(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1068(t0,t1,t2,t3);}

C_noret_decl(trf_849)
static void C_fcall trf_849(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_849(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_849(t0);}

C_noret_decl(trf_824)
static void C_fcall trf_824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_824(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_824(t0,t1,t2,t3);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_tcp_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_tcp_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("tcp_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(480)){
C_save(t1);
C_rereclaim2(480*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,95);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[3]=C_h_intern(&lf[3],17,"\003sysmake-c-string");
lf[5]=C_h_intern(&lf[5],18,"\003syscurrent-thread");
lf[6]=C_h_intern(&lf[6],12,"\003sysschedule");
lf[7]=C_h_intern(&lf[7],9,"substring");
lf[8]=C_h_intern(&lf[8],10,"tcp-listen");
lf[9]=C_h_intern(&lf[9],15,"\003syssignal-hook");
lf[10]=C_h_intern(&lf[10],14,"\000network-error");
lf[11]=C_h_intern(&lf[11],17,"\003sysstring-append");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot bind to socket - ");
lf[13]=C_h_intern(&lf[13],17,"\003syspeek-c-string");
lf[14]=C_h_intern(&lf[14],16,"\003sysupdate-errno");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\042getting listener host IP failed - ");
lf[16]=C_h_intern(&lf[16],11,"make-string");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000 error while setting up socket - ");
lf[18]=C_h_intern(&lf[18],9,"\003syserror");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024cannot create socket");
lf[20]=C_h_intern(&lf[20],13,"\000domain-error");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\023invalid port number");
lf[22]=C_h_intern(&lf[22],12,"tcp-listener");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot listen on socket - ");
lf[24]=C_h_intern(&lf[24],13,"tcp-listener\077");
lf[25]=C_h_intern(&lf[25],9,"tcp-close");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot close TCP socket - ");
lf[27]=C_h_intern(&lf[27],15,"tcp-buffer-size");
lf[28]=C_h_intern(&lf[28],16,"tcp-read-timeout");
lf[29]=C_h_intern(&lf[29],17,"tcp-write-timeout");
lf[30]=C_h_intern(&lf[30],19,"tcp-connect-timeout");
lf[31]=C_h_intern(&lf[31],18,"tcp-accept-timeout");
lf[33]=C_h_intern(&lf[33],22,"\000network-timeout-error");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\030read operation timed out");
lf[35]=C_h_intern(&lf[35],25,"\003systhread-block-for-i/o!");
lf[36]=C_h_intern(&lf[36],29,"\003systhread-block-for-timeout!");
lf[37]=C_h_intern(&lf[37],20,"current-milliseconds");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot read from socket - ");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\031write operation timed out");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot write to socket - ");
lf[41]=C_h_intern(&lf[41],5,"fxmin");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\005(tcp)");
lf[44]=C_h_intern(&lf[44],6,"socket");
lf[45]=C_h_intern(&lf[45],18,"\003sysset-port-data!");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot close socket output port - ");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[50]=C_h_intern(&lf[50],16,"make-output-port");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000!cannot close socket input port - ");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[54]=C_h_intern(&lf[54],15,"\003sysmake-string");
lf[55]=C_h_intern(&lf[55],20,"\003sysscan-buffer-line");
lf[56]=C_h_intern(&lf[56],15,"make-input-port");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\032cannot create TCP ports - ");
lf[59]=C_h_intern(&lf[59],10,"tcp-accept");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000!could not accept from listener - ");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\032accept operation timed out");
lf[62]=C_h_intern(&lf[62],17,"tcp-accept-ready\077");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000 cannot check socket for input - ");
lf[64]=C_h_intern(&lf[64],11,"tcp-connect");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\033cannot connect to socket - ");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\026getsockopt() failed - ");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\033connect operation timed out");
lf[69]=C_h_intern(&lf[69],4,"\000all");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\021fcntl() failed - ");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\030cannot find host address");
lf[72]=C_decode_literal(C_heaptop,"\376B\000\000\027cannot create socket - ");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\021no port specified");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000#cannot compute port from service - ");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\003tcp");
lf[76]=C_h_intern(&lf[76],20,"\003systcp-port->fileno");
lf[77]=C_h_intern(&lf[77],5,"error");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000)argument does not appear to be a TCP port");
lf[79]=C_h_intern(&lf[79],13,"\003sysport-data");
lf[80]=C_h_intern(&lf[80],13,"tcp-addresses");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000 cannot compute remote address - ");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\037cannot compute local address - ");
lf[83]=C_h_intern(&lf[83],14,"\003syscheck-port");
lf[84]=C_h_intern(&lf[84],16,"tcp-port-numbers");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\035cannot compute remote port - ");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\034cannot compute local port - ");
lf[87]=C_h_intern(&lf[87],17,"tcp-listener-port");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\036cannot obtain listener port - ");
lf[89]=C_h_intern(&lf[89],16,"tcp-abandon-port");
lf[90]=C_h_intern(&lf[90],19,"tcp-listener-fileno");
lf[91]=C_h_intern(&lf[91],14,"make-parameter");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\031cannot initialize Winsock");
lf[93]=C_h_intern(&lf[93],17,"register-feature!");
lf[94]=C_h_intern(&lf[94],3,"tcp");
C_register_lf2(lf,95,create_ptable());
t2=C_mutate(&lf[0] /* (set! c277 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_579,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k577 */
static void C_ccall f_579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_579,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_582,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k580 in k577 */
static void C_ccall f_582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_585,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:80: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[93]+1)))(3,*((C_word*)lf[93]+1),t2,lf[94]);}

/* k583 in k580 in k577 */
static void C_ccall f_585(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_585,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_783,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(stub165(C_SCHEME_UNDEFINED))){
t3=t2;
f_783(2,t3,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm:166: ##sys#signal-hook */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),t2,lf[10],lf[92]);}}

/* k781 in k583 in k580 in k577 */
static void C_ccall f_783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_783,2,t0,t1);}
t2=C_mutate(&lf[2] /* (set! ##net#gethostaddr ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_824,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate(&lf[4] /* (set! yield ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_849,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t4=*((C_word*)lf[7]+1);
t5=C_mutate((C_word*)lf[8]+1 /* (set! tcp-listen ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1066,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[24]+1 /* (set! tcp-listener? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1164,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[25]+1 /* (set! tcp-close ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1173,a[2]=((C_word)li11),tmp=(C_word)a,a+=3,tmp));
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1208,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:308: make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[91]+1)))(3,*((C_word*)lf[91]+1),t8,C_SCHEME_FALSE);}

/* k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1208,2,t0,t1);}
t2=C_mutate((C_word*)lf[27]+1 /* (set! tcp-buffer-size ...) */,t1);
t3=C_set_block_item(lf[28] /* tcp-read-timeout */,0,C_SCHEME_UNDEFINED);
t4=C_set_block_item(lf[29] /* tcp-write-timeout */,0,C_SCHEME_UNDEFINED);
t5=C_set_block_item(lf[30] /* tcp-connect-timeout */,0,C_SCHEME_UNDEFINED);
t6=C_set_block_item(lf[31] /* tcp-accept-timeout */,0,C_SCHEME_UNDEFINED);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1214,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1231,a[2]=t7,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2479,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:319: check */
f_1214(t9,lf[28]);}

/* k2477 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2479(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:319: make-parameter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),((C_word*)t0)[2],C_fix(60000),t1);}

/* k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1231,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! tcp-read-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1235,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2475,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:320: check */
f_1214(t4,lf[29]);}

/* k2473 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:320: make-parameter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),((C_word*)t0)[2],C_fix(60000),t1);}

/* k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1235,2,t0,t1);}
t2=C_mutate((C_word*)lf[29]+1 /* (set! tcp-write-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2471,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:321: check */
f_1214(t4,lf[30]);}

/* k2469 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:321: make-parameter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1239,2,t0,t1);}
t2=C_mutate((C_word*)lf[30]+1 /* (set! tcp-connect-timeout ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1243,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2467,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:322: check */
f_1214(t4,lf[31]);}

/* k2465 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:322: make-parameter */
((C_proc4)C_retrieve_proc(*((C_word*)lf[91]+1)))(4,*((C_word*)lf[91]+1),((C_word*)t0)[2],C_SCHEME_FALSE,t1);}

/* k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[32],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1243,2,t0,t1);}
t2=C_mutate((C_word*)lf[31]+1 /* (set! tcp-accept-timeout ...) */,t1);
t3=*((C_word*)lf[27]+1);
t4=*((C_word*)lf[16]+1);
t5=C_mutate(&lf[32] /* (set! ##net#io-ports ...) */,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1245,a[2]=t4,a[3]=t3,a[4]=((C_word)li31),tmp=(C_word)a,a+=5,tmp));
t6=C_mutate((C_word*)lf[59]+1 /* (set! tcp-accept ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1900,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[62]+1 /* (set! tcp-accept-ready? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1986,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[64]+1 /* (set! tcp-connect ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2040,a[2]=((C_word)li40),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[76]+1 /* (set! ##sys#tcp-port->fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2293,a[2]=((C_word)li41),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[80]+1 /* (set! tcp-addresses ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2311,a[2]=((C_word)li42),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[84]+1 /* (set! tcp-port-numbers ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2359,a[2]=((C_word)li43),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[87]+1 /* (set! tcp-listener-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2407,a[2]=((C_word)li44),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[89]+1 /* (set! tcp-abandon-port ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2436,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[90]+1 /* (set! tcp-listener-fileno ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2456,a[2]=((C_word)li46),tmp=(C_word)a,a+=3,tmp));
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_UNDEFINED);}

/* tcp-listener-fileno in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2456(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2456,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[22],lf[90]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* tcp-abandon-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2436(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2436,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2440,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:658: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t3,t2,lf[89]);}

/* k2438 in tcp-abandon-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2440,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2447,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:660: ##sys#port-data */
((C_proc3)C_retrieve_proc(*((C_word*)lf[79]+1)))(3,*((C_word*)lf[79]+1),t2,((C_word*)t0)[3]);}

/* k2445 in k2438 in tcp-abandon-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2447(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[3],C_fix(1));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_i_set_i_slot(t1,C_fix(2),C_SCHEME_TRUE):C_i_set_i_slot(t1,C_fix(1),C_SCHEME_TRUE)));}

/* tcp-listener-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2407,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[22],lf[87]);
t4=C_slot(t2,C_fix(1));
t5=C_i_foreign_fixnum_argumentp(t4);
t6=stub153(C_SCHEME_UNDEFINED,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2420,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_eqp(C_fix(-1),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2430,a[2]=t4,a[3]=t2,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2434,a[2]=t9,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t11=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t6);}}

/* k2432 in tcp-listener-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:653: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[88],t1);}

/* k2428 in tcp-listener-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:652: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[87],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2418 in tcp-listener-port in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2359(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2359,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2363,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:635: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t3,t2,lf[84]);}

/* k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2363,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2366,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:636: ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2366(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2366,2,t0,t1);}
t2=t1;
t3=C_i_foreign_fixnum_argumentp(t2);
t4=stub153(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t4)){
t6=t5;
f_2376(2,t6,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2401,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2405,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2403 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:641: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[86],t1);}

/* k2399 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:639: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[84],t1,((C_word*)t0)[2]);}

/* k2374 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2376(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2376,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=C_i_foreign_fixnum_argumentp(t2);
t4=stub157(C_SCHEME_UNDEFINED,t3);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2383,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t4)){
/* tcp.scm:637: values */
C_values(4,0,((C_word*)t0)[3],t1,t4);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2394,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t8=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2392 in k2374 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:645: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[85],t1);}

/* k2388 in k2374 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:643: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[84],t1,((C_word*)t0)[2]);}

/* k2381 in k2374 in k2364 in k2361 in tcp-port-numbers in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:637: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2311(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2311,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2315,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:622: ##sys#check-port */
((C_proc4)C_retrieve_proc(*((C_word*)lf[83]+1)))(4,*((C_word*)lf[83]+1),t3,t2,lf[80]);}

/* k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:623: ##sys#tcp-port->fileno */
t3=*((C_word*)lf[76]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=t1;
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=C_i_foreign_fixnum_argumentp(t3);
t6=stub148(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2328,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_2328(2,t3,t1);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2353,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2357,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2355 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:628: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[82],t1);}

/* k2351 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2353(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:626: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[80],t1,((C_word*)t0)[2]);}

/* k2326 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2332,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=C_a_i_bytevector(&a,1,C_fix(3));
t5=C_i_foreign_fixnum_argumentp(t3);
t6=stub161(t4,t5);
/* ##sys#peek-c-string */
t7=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,C_fix(0));}

/* k2330 in k2326 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2332,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2335,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
/* tcp.scm:624: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],t3);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2342,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2346,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t5=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}}

/* k2344 in k2330 in k2326 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:632: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[81],t1);}

/* k2340 in k2330 in k2326 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:630: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[80],t1,((C_word*)t0)[2]);}

/* k2333 in k2330 in k2326 in k2323 in k2316 in k2313 in tcp-addresses in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2335(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:624: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##sys#tcp-port->fileno in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2293(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2293,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2297,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:616: ##sys#port-data */
((C_proc3)C_retrieve_proc(*((C_word*)lf[79]+1)))(3,*((C_word*)lf[79]+1),t3,t2);}

/* k2295 in ##sys#tcp-port->fileno in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_vectorp(t1))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_slot(t1,C_fix(0)));}
else{
/* tcp.scm:619: error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[77]+1)))(5,*((C_word*)lf[77]+1),((C_word*)t0)[3],lf[76],lf[78],((C_word*)t0)[2]);}}

/* tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2040(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_2040r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_2040r(t0,t1,t2,t3);}}

static void C_ccall f_2040r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2044,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t6=t5;
f_2044(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_cdr(t3);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_2044(2,t7,C_i_car(t3));}
else{
/* ##sys#error */
t7=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t3);}}}

/* k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2044,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2047,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:559: tcp-connect-timeout */
t5=*((C_word*)lf[30]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2047,2,t0,t1);}
t2=C_i_check_string(((C_word*)((C_word*)t0)[4])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2053,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t4=t3;
f_2053(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2263,a[2]=((C_word*)t0)[4],a[3]=((C_word)li38),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li39),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t4,t5,t6);}}

/* a2268 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2269,4,t0,t1,t2,t3);}
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t3);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2263(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2263,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[2])[1];
t3=C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_879,a[2]=t5,a[3]=t2,a[4]=t3,a[5]=((C_word)li37),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_879(t7,t1,C_fix(0));}

/* loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_879(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(5);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_879,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
/* tcp.scm:222: values */
C_values(4,0,t1,((C_word*)t0)[3],C_SCHEME_FALSE);}
else{
t3=C_subchar(((C_word*)t0)[3],t2);
t4=C_eqp(t3,C_make_character(58));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_902,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=C_fixnum_plus(t2,C_fix(1));
/* tcp.scm:226: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[7]+1)))(5,*((C_word*)lf[7]+1),t5,((C_word*)t0)[3],t6,((C_word*)t0)[4]);}
else{
t5=C_fixnum_plus(t2,C_fix(1));
/* tcp.scm:236: loop */
t9=t1;
t10=t5;
t1=t9;
t2=t10;
goto loop;}}}

/* k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_906,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:227: substring */
((C_proc5)C_retrieve_proc(*((C_word*)lf[7]+1)))(5,*((C_word*)lf[7]+1),t2,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_906,2,t0,t1);}
t2=t1;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_790,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t3,t4);}
else{
t4=t3;
f_790(2,t4,C_SCHEME_FALSE);}}

/* k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_794,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=C_i_foreign_string_argumentp(lf[75]);
/* ##sys#make-c-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t2,t3);}

/* k792 in k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_794,2,t0,t1);}
t2=stub169(C_SCHEME_UNDEFINED,((C_word*)t0)[5],t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_912,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(C_fix(0),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_918,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:230: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t5);}
else{
/* tcp.scm:225: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],t2);}}

/* k916 in k792 in k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_925,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_929,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k927 in k916 in k792 in k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:233: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[74],t1);}

/* k923 in k916 in k792 in k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:231: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[64],t1,((C_word*)t0)[2]);}

/* k910 in k792 in k788 in k904 in k900 in loop in a2262 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:225: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2253 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_2053(2,t3,t2);}
else{
/* tcp.scm:563: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[64],lf[73],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2053(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2053,2,t0,t1);}
t2=C_i_check_exact(((C_word*)((C_word*)t0)[5])[1]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:565: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t3,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2059,2,t0,t1);}
t2=C_fix((C_word)AF_INET);
t3=C_fix((C_word)SOCK_STREAM);
t4=C_i_foreign_fixnum_argumentp(t2);
t5=C_i_foreign_fixnum_argumentp(t3);
t6=C_i_foreign_fixnum_argumentp(C_fix(0));
t7=stub64(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t7,a[5]=((C_word)li35),tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2085,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t8,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=C_eqp(C_fix(-1),t7);
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2241,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:574: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t11);}
else{
t11=t9;
f_2085(2,t11,C_SCHEME_UNDEFINED);}}

/* k2239 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2241,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2248,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2252,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2250 in k2239 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:577: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[72],t1);}

/* k2246 in k2239 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:575: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[64],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2085,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2088,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2232,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:578: ##net#gethostaddr */
f_824(t3,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* k2230 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_2088(2,t2,C_SCHEME_UNDEFINED);}
else{
/* tcp.scm:579: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[64],lf[71],((C_word*)((C_word*)t0)[2])[1]);}}

/* k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2088,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2091,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
if(C_truep(stub144(C_SCHEME_UNDEFINED,t3))){
t4=t2;
f_2091(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:581: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t4);}}

/* k2216 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2218,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2229,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2227 in k2216 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:582: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[70],t1);}

/* k2223 in k2216 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2225(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:582: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[10],lf[64],t1);}

/* k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2091,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2094,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[4];
t4=C_fix((C_word)sizeof(struct sockaddr_in));
t5=C_i_foreign_fixnum_argumentp(((C_word*)t0)[6]);
t6=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t4);
t8=stub122(C_SCHEME_UNDEFINED,t5,t6,t7);
t9=C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=C_eqp(C_fix((C_word)errno),C_fix((C_word)EINPROGRESS));
if(C_truep(t10)){
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t12,a[5]=((C_word*)t0)[6],a[6]=((C_word)li36),tmp=(C_word)a,a+=7,tmp));
t14=((C_word*)t12)[1];
f_2154(t14,t2);}
else{
/* tcp.scm:601: fail */
t11=((C_word*)t0)[2];
f_2064(t11,t2);}}
else{
t10=t2;
f_2094(2,t10,C_SCHEME_UNDEFINED);}}

/* loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_2154(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2154,NULL,2,t0,t1);}
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=stub182(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
/* tcp.scm:587: fail */
t6=((C_word*)t0)[2];
f_2064(t6,t4);}
else{
t6=t4;
f_2161(2,t6,C_SCHEME_UNDEFINED);}}

/* k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2161,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[6],C_fix(1));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2199,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:592: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t4);}
else{
t4=t3;
f_2170(2,t4,C_SCHEME_UNDEFINED);}}}

/* k2197 in k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[3]);
/* tcp.scm:590: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),((C_word*)t0)[2],*((C_word*)lf[5]+1),t2);}

/* k2168 in k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:593: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[5]+1),((C_word*)t0)[2],lf[69]);}

/* k2171 in k2168 in k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:594: yield */
f_849(t2);}

/* k2174 in k2171 in k2168 in k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2179,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_slot(*((C_word*)lf[5]+1),C_fix(13)))){
/* tcp.scm:596: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),t2,lf[33],lf[64],lf[68],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* tcp.scm:600: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2154(t3,((C_word*)t0)[4]);}}

/* k2177 in k2174 in k2171 in k2168 in k2159 in loop in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:600: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_2154(t2,((C_word*)t0)[2]);}

/* k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2094,2,t0,t1);}
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t3=stub445(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2100,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(t3,C_fix(-1));
if(C_truep(t5)){
t6=C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=stub98(C_SCHEME_UNDEFINED,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2116,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2120,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t10=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}
else{
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
t6=C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t7=stub98(C_SCHEME_UNDEFINED,t6);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2136,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2140,a[2]=t8,tmp=(C_word)a,a+=3,tmp);
t10=C_a_i_bytevector(&a,1,C_fix(3));
t11=C_i_foreign_fixnum_argumentp(t3);
t12=stub449(t10,t11);
/* ##sys#peek-c-string */
t13=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t13+1)))(4,t13,t9,t12,C_fix(0));}
else{
/* tcp.scm:613: ##net#io-ports */
t6=lf[32];
f_1245(t6,((C_word*)t0)[2],((C_word*)t0)[3]);}}}

/* k2138 in k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:612: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[67],t1);}

/* k2134 in k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:610: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[10],lf[64],t1);}

/* k2118 in k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:607: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[66],t1);}

/* k2114 in k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:605: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[10],lf[64],t1);}

/* k2098 in k2092 in k2089 in k2086 in k2083 in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:613: ##net#io-ports */
t2=lf[32];
f_1245(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* fail in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_2064(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2064,NULL,2,t0,t1);}
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=stub98(C_SCHEME_UNDEFINED,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:569: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t4);}

/* k2069 in fail in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2071,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2078,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2082,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2080 in k2069 in fail in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:571: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[65],t1);}

/* k2076 in k2069 in fail in k2057 in k2051 in k2045 in k2042 in tcp-connect in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:570: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[64],t1,((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* tcp-accept-ready? in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1986(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1986,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[22],lf[62]);
t4=C_slot(t2,C_fix(1));
t5=C_i_foreign_fixnum_argumentp(t4);
t6=stub178(C_SCHEME_UNDEFINED,t5);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1996,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_eqp(C_fix(-1),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2005,a[2]=t2,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:541: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t9);}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(C_fix(1),t6));}}

/* k2003 in tcp-accept-ready? in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2012,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k2014 in k2003 in tcp-accept-ready? in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:543: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[63],t1);}

/* k2010 in k2003 in tcp-accept-ready? in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_2012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:542: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[62],t1,((C_word*)t0)[2]);}

/* k1994 in tcp-accept-ready? in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(C_fix(1),((C_word*)t0)[2]));}

/* tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1900,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[22]);
t4=C_slot(t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1910,a[2]=t1,a[3]=t2,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:513: tcp-accept-timeout */
t6=*((C_word*)lf[31]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}

/* k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1910,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1915,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word)li32),tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_1915(t5,((C_word*)t0)[2]);}

/* loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1915(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1915,NULL,2,t0,t1);}
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=stub178(C_SCHEME_UNDEFINED,t2);
t4=C_eqp(C_fix(1),t3);
if(C_truep(t4)){
t5=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t6=stub88(C_SCHEME_UNDEFINED,t5,C_SCHEME_FALSE,C_SCHEME_FALSE);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1928,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_eqp(C_fix(-1),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1937,a[2]=((C_word*)t0)[4],a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:518: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t9);}
else{
/* tcp.scm:522: ##net#io-ports */
t9=lf[32];
f_1245(t9,t1,t6);}}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1951,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1980,a[2]=t5,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:527: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t6);}
else{
t6=t5;
f_1951(2,t6,C_SCHEME_UNDEFINED);}}}

/* k1978 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1980,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[3]);
/* tcp.scm:525: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),((C_word*)t0)[2],*((C_word*)lf[5]+1),t2);}

/* k1949 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1954,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:528: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1952 in k1949 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:529: yield */
f_849(t2);}

/* k1955 in k1952 in k1949 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1957,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1960,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_slot(*((C_word*)lf[5]+1),C_fix(13)))){
/* tcp.scm:531: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),t2,lf[33],lf[59],lf[61],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* tcp.scm:535: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1915(t3,((C_word*)t0)[4]);}}

/* k1958 in k1955 in k1952 in k1949 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:535: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1915(t2,((C_word*)t0)[2]);}

/* k1935 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1937(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1937,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1944,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1948,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1946 in k1935 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:520: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[60],t1);}

/* k1942 in k1935 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:519: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[59],t1,((C_word*)t0)[2]);}

/* k1926 in loop in k1908 in tcp-accept in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:522: ##net#io-ports */
t2=lf[32];
f_1245(t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1245(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1245,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=t2;
t5=C_i_foreign_fixnum_argumentp(t4);
if(C_truep(stub144(C_SCHEME_UNDEFINED,t5))){
t6=t3;
f_1249(2,t6,C_SCHEME_UNDEFINED);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1887,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:329: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t6);}}

/* k1885 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1894,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1898,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1896 in k1885 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:331: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[58],t1);}

/* k1892 in k1885 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:330: ##sys#signal-hook */
((C_proc4)C_retrieve_proc(*((C_word*)lf[9]+1)))(4,*((C_word*)lf[9]+1),((C_word*)t0)[2],lf[10],t1);}

/* k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1252,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:332: make-string */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,C_fix(1024));}

/* k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[24],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1252,2,t0,t1);}
t2=C_a_i_vector(&a,5,((C_word*)t0)[4],C_SCHEME_FALSE,C_SCHEME_FALSE,t1,C_fix(0));
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1258,a[2]=t8,a[3]=t10,a[4]=((C_word*)t0)[3],a[5]=t6,a[6]=t2,a[7]=t4,a[8]=t1,a[9]=((C_word*)t0)[4],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm:338: tbs */
t12=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t12))(2,t12,t11);}

/* k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1261,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=C_fixnum_greaterp(t1,C_fix(0));
t4=t2;
f_1261(t4,(C_truep(t3)?lf[57]:C_SCHEME_FALSE));}
else{
t3=t2;
f_1261(t3,C_SCHEME_FALSE);}}

/* k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1261,NULL,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* tcp.scm:340: tcp-read-timeout */
t5=*((C_word*)lf[28]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1264,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_1267,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* tcp.scm:341: tcp-write-timeout */
t3=*((C_word*)lf[29]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[60],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1268,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word)li15),tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=t1,a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1582,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word)li22),tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1604,a[2]=((C_word*)t0)[12],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[7],a[5]=((C_word)li23),tmp=(C_word)a,a+=6,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1639,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[12],a[5]=((C_word*)t0)[2],a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1682,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word)li25),tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1700,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word)li27),tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1765,a[2]=t2,a[3]=((C_word*)t0)[11],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=((C_word)li30),tmp=(C_word)a,a+=7,tmp);
/* tcp.scm:370: make-input-port */
((C_proc8)C_retrieve_proc(*((C_word*)lf[56]+1)))(8,*((C_word*)lf[56]+1),t3,t4,t5,t6,t7,t8,t9);}

/* a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1765(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1765,4,t0,t1,t2,t3);}
t4=(C_truep(t3)?t3:C_fudge(C_fix(21)));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1775,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t6,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li29),tmp=(C_word)a,a+=9,tmp));
t8=((C_word*)t6)[1];
f_1775(t8,t1,C_SCHEME_FALSE,t4);}

/* loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1775(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1775,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1789,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=t3,a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* tcp.scm:425: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t4,((C_word*)((C_word*)t0)[6])[1],t3);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1863,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm:444: read-input */
t5=((C_word*)t0)[3];
f_1268(t5,t4);}}

/* k1861 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
/* tcp.scm:446: loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1775(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* k1787 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_1791,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word)li28),tmp=(C_word)a,a+=11,tmp);
/* tcp.scm:423: ##sys#scan-buffer-line */
((C_proc6)C_retrieve_proc(*((C_word*)lf[55]+1)))(6,*((C_word*)lf[55]+1),((C_word*)t0)[2],((C_word*)t0)[9],t1,((C_word*)((C_word*)t0)[10])[1],t2);}

/* a1790 in k1787 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1791(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1791,4,t0,t1,t2,t3);}
t4=C_fixnum_difference(t2,((C_word*)((C_word*)t0)[9])[1]);
t5=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_1798,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t4,a[6]=((C_word*)t0)[5],a[7]=t1,a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=t3,a[11]=t2,a[12]=((C_word*)t0)[9],a[13]=((C_word*)t0)[8],tmp=(C_word)a,a+=14,tmp);
/* tcp.scm:429: ##sys#make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t5,t4);}

/* k1796 in a1790 in k1787 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1798(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1798,2,t0,t1);}
t2=C_substring_copy(((C_word*)t0)[13],t1,((C_word*)((C_word*)t0)[12])[1],((C_word*)t0)[11],C_fix(0));
t3=C_mutate(((C_word *)((C_word*)t0)[12])+1,((C_word*)t0)[10]);
t4=C_eqp(((C_word*)t0)[11],((C_word*)t0)[9]);
if(C_truep(t4)){
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm:433: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t5=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t1);}}
else{
t5=C_eqp(((C_word*)t0)[11],((C_word*)t0)[10]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1820,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[12],tmp=(C_word)a,a+=10,tmp);
/* tcp.scm:435: read-input */
t7=((C_word*)t0)[3];
f_1268(t7,t6);}
else{
t6=C_slot(((C_word*)t0)[2],C_fix(4));
t7=C_fixnum_plus(t6,C_fix(1));
t8=C_i_set_i_slot(((C_word*)t0)[2],C_fix(4),t7);
if(C_truep(((C_word*)t0)[8])){
/* tcp.scm:442: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[7],((C_word*)t0)[8],t1);}
else{
t9=t1;
t10=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}}}}

/* k1818 in k1796 in a1790 in k1787 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1820,2,t0,t1);}
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[9])[1],((C_word*)((C_word*)t0)[8])[1]))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?t2:lf[53]));}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1836,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[7])){
/* tcp.scm:438: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t2,((C_word*)t0)[7],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[2];
t4=C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* tcp.scm:438: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_1775(t5,((C_word*)t0)[6],t3,t4);}}}

/* k1834 in k1818 in k1796 in a1790 in k1787 in loop in a1764 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_difference(((C_word*)t0)[5],((C_word*)t0)[4]);
/* tcp.scm:438: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1775(t3,((C_word*)t0)[2],t1,t2);}

/* a1699 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1700(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(c!=6) C_bad_argc_2(c,6,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_1700,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1706,a[2]=((C_word*)t0)[2],a[3]=t7,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word)li26),tmp=(C_word)a,a+=9,tmp));
t9=((C_word*)t7)[1];
f_1706(t9,t1,t3,C_fix(0),t5);}

/* loop in a1699 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1706(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1706,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(t2,C_fix(0));
if(C_truep(t5)){
t6=t3;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[7])[1],((C_word*)((C_word*)t0)[6])[1]))){
t6=C_fixnum_difference(((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[7])[1]);
t7=C_fixnum_lessp(t2,t6);
t8=(C_truep(t7)?t2:t6);
t9=C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t10=C_substring_copy(((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)((C_word*)t0)[7])[1],t9,t4);
t11=C_fixnum_plus(((C_word*)((C_word*)t0)[7])[1],t8);
t12=C_mutate(((C_word *)((C_word*)t0)[7])+1,t11);
t13=C_fixnum_difference(t2,t8);
t14=C_fixnum_plus(t3,t8);
t15=C_fixnum_plus(t4,t8);
/* tcp.scm:413: loop */
t19=t1;
t20=t13;
t21=t14;
t22=t15;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1754,a[2]=t4,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm:415: read-input */
t7=((C_word*)t0)[2];
f_1268(t7,t6);}}}

/* k1752 in loop in a1699 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(((C_word*)((C_word*)t0)[7])[1],C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[6];
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* tcp.scm:418: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_1706(t3,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}}

/* a1681 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1686,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm:401: read-input */
t3=((C_word*)t0)[2];
f_1268(t3,t2);}
else{
t3=t2;
f_1686(2,t3,C_SCHEME_UNDEFINED);}}

/* k1684 in a1681 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_fixnum_lessp(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=C_subchar(((C_word*)t0)[3],((C_word*)((C_word*)t0)[5])[1]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}}

/* a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1639(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1639,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_set_block_item(((C_word*)t0)[5],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1647,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(1)))){
t4=t3;
f_1647(t4,C_SCHEME_UNDEFINED);}
else{
t4=((C_word*)t0)[4];
t5=C_fix((C_word)SD_RECEIVE);
t6=C_i_foreign_fixnum_argumentp(t4);
t7=C_i_foreign_fixnum_argumentp(t5);
t8=t3;
f_1647(t8,stub115(C_SCHEME_UNDEFINED,t6,t7));}}}

/* k1645 in a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1647(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1647,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=((C_word*)t0)[3];
t4=C_i_foreign_fixnum_argumentp(t3);
t5=stub98(C_SCHEME_UNDEFINED,t4);
t6=t2;
f_1653(t6,C_eqp(C_fix(-1),t5));}
else{
t3=t2;
f_1653(t3,C_SCHEME_FALSE);}}

/* k1651 in k1645 in a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:394: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1654 in k1651 in k1645 in a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1656,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1667,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1665 in k1654 in k1651 in k1645 in a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:397: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[52],t1);}

/* k1661 in k1654 in k1651 in k1645 in a1638 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:395: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],t1,((C_word*)t0)[2]);}

/* a1603 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1604,2,t0,t1);}
t2=C_fixnum_lessp(((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t2)){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=((C_word*)t0)[2];
t4=C_i_foreign_fixnum_argumentp(t3);
t5=stub178(C_SCHEME_UNDEFINED,t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1617,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(t5,C_fix(-1));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1626,a[2]=((C_word*)t0)[2],a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:383: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_eqp(t5,C_fix(1)));}}}

/* k1624 in a1603 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1626(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1626,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1633,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1637,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1635 in k1624 in a1603 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:386: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[51],t1);}

/* k1631 in k1624 in a1603 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1633(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:384: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],t1,((C_word*)t0)[2]);}

/* k1615 in a1603 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[2],C_fix(1)));}

/* a1581 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1582(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1582,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
/* tcp.scm:373: read-input */
t3=((C_word*)t0)[2];
f_1268(t3,t2);}
else{
t3=t2;
f_1586(2,t3,C_SCHEME_UNDEFINED);}}

/* k1584 in a1581 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(C_fixnum_greater_or_equal_p(((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1]))){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_FILE);}
else{
t2=C_subchar(((C_word*)t0)[2],((C_word*)((C_word*)t0)[5])[1]);
t3=C_fixnum_plus(((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[5])+1,t3);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t2);}}

/* k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[30],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1344,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1345,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1440,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(((C_word*)((C_word*)t0)[5])[1])?(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1546,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word)li18),tmp=(C_word)a,a+=6,tmp):(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1566,a[2]=t2,a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1467,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[3],a[8]=((C_word)li20),tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)((C_word*)t0)[5])[1])){
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1530,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li21),tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:476: make-output-port */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t3,t4,t5,t6);}
else{
/* tcp.scm:476: make-output-port */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t3,t4,t5,C_SCHEME_FALSE);}}

/* f_1530 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1530,2,t0,t1);}
t2=C_block_size(((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(C_fixnum_greaterp(t2,C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1540,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:500: output */
t4=((C_word*)t0)[2];
f_1345(t4,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1538 */
static void C_ccall f_1540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[49]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1467,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_set_block_item(((C_word*)t0)[7],0,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1514,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t5=C_block_size(((C_word*)((C_word*)t0)[3])[1]);
t6=t4;
f_1514(t6,C_fixnum_greaterp(t5,C_fix(0)));}
else{
t5=t4;
f_1514(t5,C_SCHEME_FALSE);}}}

/* k1512 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1514(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1514,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:490: output */
t3=((C_word*)t0)[2];
f_1345(t3,t2,((C_word*)((C_word*)t0)[4])[1]);}
else{
t2=((C_word*)t0)[3];
f_1475(t2,C_SCHEME_UNDEFINED);}}

/* k1515 in k1512 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[48]);
t3=((C_word*)t0)[2];
f_1475(t3,t2);}

/* k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1475(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1475,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1478,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_slot(((C_word*)t0)[2],C_fix(2)))){
t3=t2;
f_1478(t3,C_SCHEME_UNDEFINED);}
else{
t3=((C_word*)t0)[4];
t4=C_fix((C_word)SD_SEND);
t5=C_i_foreign_fixnum_argumentp(t3);
t6=C_i_foreign_fixnum_argumentp(t4);
t7=t2;
f_1478(t7,stub115(C_SCHEME_UNDEFINED,t5,t6));}}

/* k1476 in k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1478(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1478,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=((C_word*)t0)[3];
t4=C_i_foreign_fixnum_argumentp(t3);
t5=stub98(C_SCHEME_UNDEFINED,t4);
t6=t2;
f_1484(t6,C_eqp(C_fix(-1),t5));}
else{
t3=t2;
f_1484(t3,C_SCHEME_FALSE);}}

/* k1482 in k1476 in k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1484(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1484,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1487,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:494: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t2);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k1485 in k1482 in k1476 in k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1487,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1498,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1496 in k1485 in k1482 in k1476 in k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:496: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[47],t1);}

/* k1492 in k1485 in k1482 in k1476 in k1473 in a1466 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:495: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],t1,((C_word*)t0)[2]);}

/* f_1566 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1566(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1566,3,t0,t1,t2);}
t3=C_block_size(t2);
if(C_truep(C_fixnum_greaterp(t3,C_fix(0)))){
/* tcp.scm:485: output */
t4=((C_word*)t0)[2];
f_1345(t4,t1,t2);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* f_1546 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1546(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1546,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1551,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:479: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),t3,((C_word*)((C_word*)t0)[4])[1],t2);}

/* k1549 */
static void C_ccall f_1551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1551,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_block_size(((C_word*)((C_word*)t0)[5])[1]);
if(C_truep(C_fixnum_greater_or_equal_p(t3,((C_word*)t0)[4]))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1560,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:481: output */
t5=((C_word*)t0)[2];
f_1345(t5,t4,((C_word*)((C_word*)t0)[5])[1]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1558 in k1549 */
static void C_ccall f_1560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,lf[46]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1438 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1440,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[4],C_fix(3),lf[42]);
t3=C_i_setslot(t1,C_fix(3),lf[43]);
t4=C_i_setslot(((C_word*)t0)[4],C_fix(7),lf[44]);
t5=C_i_setslot(t1,C_fix(7),lf[44]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1455,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:506: ##sys#set-port-data! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t6,((C_word*)t0)[4],((C_word*)t0)[2]);}

/* k1453 in k1438 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1455(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1455,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1458,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:507: ##sys#set-port-data! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1456 in k1453 in k1438 in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:508: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1345(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1345,NULL,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1355,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=((C_word)li16),tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_1355(t7,t1,t3,C_fix(0));}

/* loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1355(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1355,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* tcp.scm:452: fxmin */
((C_proc4)C_retrieve_proc(*((C_word*)lf[41]+1)))(4,*((C_word*)lf[41]+1),t4,C_fix(8192),t2);}

/* k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=((C_word*)t0)[6];
t5=C_i_foreign_fixnum_argumentp(t2);
t6=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t7=C_i_foreign_fixnum_argumentp(t4);
t8=C_i_foreign_fixnum_argumentp(t1);
t9=C_i_foreign_fixnum_argumentp(C_fix(0));
t10=stub134(C_SCHEME_UNDEFINED,t5,t6,t7,t8,t9);
t11=C_eqp(C_fix(-1),t10);
if(C_truep(t11)){
t12=C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1377,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1406,a[2]=t13,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:459: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t14);}
else{
t14=t13;
f_1377(2,t14,C_SCHEME_UNDEFINED);}}
else{
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:468: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t13);}}
else{
if(C_truep(C_fixnum_lessp(t10,((C_word*)t0)[3]))){
t12=C_fixnum_difference(((C_word*)t0)[3],t10);
t13=C_fixnum_plus(((C_word*)t0)[6],t10);
/* tcp.scm:474: loop */
t14=((C_word*)((C_word*)t0)[5])[1];
f_1355(t14,((C_word*)t0)[4],t12,t13);}
else{
t12=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_SCHEME_UNDEFINED);}}}

/* k1407 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1416,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1420,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1418 in k1407 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:471: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[40],t1);}

/* k1414 in k1407 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:469: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],t1,((C_word*)t0)[2]);}

/* k1404 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1406,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[3]);
/* tcp.scm:457: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),((C_word*)t0)[2],*((C_word*)lf[5]+1),t2);}

/* k1375 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1377,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm:460: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k1378 in k1375 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1380(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1380,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1383,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* tcp.scm:461: yield */
f_849(t2);}

/* k1381 in k1378 in k1375 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1383,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1386,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_slot(*((C_word*)lf[5]+1),C_fix(13)))){
/* tcp.scm:463: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),t2,lf[33],lf[39],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* tcp.scm:466: loop */
t3=((C_word*)((C_word*)t0)[7])[1];
f_1355(t3,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4]);}}

/* k1384 in k1381 in k1378 in k1375 in k1357 in loop in output in k1342 in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:466: loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1355(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1268(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1268,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word)li14),tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_1274(t5,t1);}

/* loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1274(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1274,NULL,2,t0,t1);}
t2=((C_word*)t0)[8];
t3=((C_word*)t0)[7];
t4=C_i_foreign_fixnum_argumentp(t2);
t5=(C_truep(t3)?C_i_foreign_block_argumentp(t3):C_SCHEME_FALSE);
t6=C_i_foreign_fixnum_argumentp(C_fix(1024));
t7=C_i_foreign_fixnum_argumentp(C_fix(0));
t8=stub105(C_SCHEME_UNDEFINED,t4,t5,t6,t7);
t9=C_eqp(C_fix(-1),t8);
if(C_truep(t9)){
t10=C_eqp(C_fix((C_word)errno),C_fix((C_word)EWOULDBLOCK));
if(C_truep(t10)){
t11=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1293,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[5])){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1322,a[2]=t11,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:351: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[37]+1)))(2,*((C_word*)lf[37]+1),t12);}
else{
t12=t11;
f_1293(2,t12,C_SCHEME_UNDEFINED);}}
else{
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1325,a[2]=((C_word*)t0)[8],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:360: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t11);}}
else{
t10=C_mutate(((C_word *)((C_word*)t0)[4])+1,t8);
t11=C_i_set_i_slot(((C_word*)t0)[3],C_fix(4),t8);
t12=C_set_block_item(((C_word*)t0)[2],0,C_fix(0));
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}}

/* k1323 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1332,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1336,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1334 in k1323 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:363: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[38],t1);}

/* k1330 in k1323 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:361: ##sys#signal-hook */
((C_proc5)C_retrieve_proc(*((C_word*)lf[9]+1)))(5,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],t1,((C_word*)t0)[2]);}

/* k1320 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1322,2,t0,t1);}
t2=C_a_i_plus(&a,2,t1,((C_word*)t0)[3]);
/* tcp.scm:349: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[36]+1)))(4,*((C_word*)lf[36]+1),((C_word*)t0)[2],*((C_word*)lf[5]+1),t2);}

/* k1291 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1296,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:352: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[35]+1)))(5,*((C_word*)lf[35]+1),t2,*((C_word*)lf[5]+1),((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1294 in k1291 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:353: yield */
f_849(t2);}

/* k1297 in k1294 in k1291 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1299,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1302,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_slot(*((C_word*)lf[5]+1),C_fix(13)))){
/* tcp.scm:355: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),t2,lf[33],lf[34],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* tcp.scm:358: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1274(t3,((C_word*)t0)[4]);}}

/* k1300 in k1297 in k1294 in k1291 in loop in read-input in k1265 in k1262 in k1259 in k1256 in k1250 in k1247 in ##net#io-ports in k1241 in k1237 in k1233 in k1229 in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:358: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1274(t2,((C_word*)t0)[2]);}

/* check in k1206 in k781 in k583 in k580 in k577 */
static void C_fcall f_1214(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1214,NULL,2,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1216,a[2]=t2,a[3]=((C_word)li12),tmp=(C_word)a,a+=4,tmp));}

/* f_1216 in check in k1206 in k781 in k583 in k580 in k577 */
static void C_ccall f_1216(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1216,3,t0,t1,t2);}
if(C_truep(t2)){
t3=C_i_check_exact_2(t2,((C_word*)t0)[2]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* tcp-close in k781 in k583 in k580 in k577 */
static void C_ccall f_1173(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1173,3,t0,t1,t2);}
t3=C_i_check_structure(t2,lf[22]);
t4=C_slot(t2,C_fix(1));
t5=C_i_foreign_fixnum_argumentp(t4);
t6=stub98(C_SCHEME_UNDEFINED,t5);
t7=C_eqp(C_fix(-1),t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1189,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:300: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t8);}
else{
t8=C_SCHEME_UNDEFINED;
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k1187 in tcp-close in k781 in k583 in k580 in k577 */
static void C_ccall f_1189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1200,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1198 in k1187 in tcp-close in k781 in k583 in k580 in k577 */
static void C_ccall f_1200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:303: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[26],t1);}

/* k1194 in k1187 in tcp-close in k781 in k583 in k580 in k577 */
static void C_ccall f_1196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:301: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[25],t1,((C_word*)t0)[2]);}

/* tcp-listener? in k781 in k583 in k580 in k577 */
static void C_ccall f_1164(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1164,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(C_blockp(t2))?C_i_structurep(t2,lf[22]):C_SCHEME_FALSE));}

/* tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1066(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+12)){
C_save_and_reclaim((void*)tr3r,(void*)f_1066r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1066r(t0,t1,t2,t3);}}

static void C_ccall f_1066r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a=C_alloc(12);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1068,a[2]=t2,a[3]=((C_word)li6),tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1111,a[2]=t4,a[3]=((C_word)li7),tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1116,a[2]=t5,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* def-w250272 */
t7=t6;
f_1116(t7,t1);}
else{
t7=C_i_car(t3);
t8=C_i_cdr(t3);
if(C_truep(C_i_nullp(t8))){
/* def-host251270 */
t9=t5;
f_1111(t9,t1,t7);}
else{
t9=C_i_car(t8);
t10=C_i_cdr(t8);
if(C_truep(C_i_nullp(t10))){
/* body248255 */
t11=t4;
f_1068(t11,t1,t7,t9);}
else{
/* ##sys#error */
t11=*((C_word*)lf[18]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t1,lf[0],t10);}}}}

/* def-w250 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_fcall f_1116(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1116,NULL,2,t0,t1);}
/* def-host251270 */
t2=((C_word*)t0)[2];
f_1111(t2,t1,C_fix(10));}

/* def-host251 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_fcall f_1111(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1111,NULL,3,t0,t1,t2);}
/* body248255 */
t3=((C_word*)t0)[2];
f_1068(t3,t1,t2,C_SCHEME_FALSE);}

/* body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_fcall f_1068(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1068,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1074,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word)li4),tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1080,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a1079 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1080(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1080,4,t0,t1,t2,t3);}
t4=C_i_check_exact(((C_word*)t0)[3]);
t5=t2;
t6=((C_word*)t0)[3];
t7=C_i_foreign_fixnum_argumentp(t5);
t8=C_i_foreign_fixnum_argumentp(t6);
t9=stub81(C_SCHEME_UNDEFINED,t7,t8);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t11=C_eqp(C_fix(-1),t9);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1099,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t10,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:286: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t12);}
else{
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,2,lf[22],t2));}}

/* k1097 in a1079 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1110,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1108 in k1097 in a1079 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:289: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[23],t1);}

/* k1104 in k1097 in a1079 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:287: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[8],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1088 in a1079 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1090,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,2,lf[22],((C_word*)t0)[2]));}

/* a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1074,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=C_fix((C_word)SOCK_STREAM);
t4=((C_word*)t0)[2];
t5=C_i_check_exact(t2);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_963,a[2]=t4,a[3]=t2,a[4]=t1,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_fixnum_lessp(t2,C_fix(0));
if(C_truep(t7)){
if(C_truep(t7)){
/* tcp.scm:249: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),t6,lf[20],lf[8],lf[21],t2);}
else{
t8=t6;
f_963(2,t8,C_SCHEME_UNDEFINED);}}
else{
if(C_truep(C_fixnum_greater_or_equal_p(t2,C_fix(65535)))){
/* tcp.scm:249: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),t6,lf[20],lf[8],lf[21],t2);}
else{
t8=t6;
f_963(2,t8,C_SCHEME_UNDEFINED);}}}

/* k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_963,2,t0,t1);}
t2=C_fix((C_word)AF_INET);
t3=C_i_foreign_fixnum_argumentp(t2);
t4=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t5=C_i_foreign_fixnum_argumentp(C_fix(0));
t6=stub64(C_SCHEME_UNDEFINED,t3,t4,t5);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_969,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
t8=C_eqp(C_fix((C_word)INVALID_SOCKET),t6);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1049,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:252: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t9);}
else{
t9=t7;
f_969(2,t9,C_SCHEME_UNDEFINED);}}

/* k1047 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:253: ##sys#error */
t2=*((C_word*)lf[18]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[19]);}

/* k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_969,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_972,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t4=stub231(C_SCHEME_UNDEFINED,t3);
t5=C_eqp(C_fix(-1),t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1022,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* tcp.scm:259: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t6);}
else{
t6=t2;
f_972(2,t6,C_SCHEME_UNDEFINED);}}

/* k1020 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1029,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1033,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1031 in k1020 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:262: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[17],t1);}

/* k1027 in k1020 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1029(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:260: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[9]+1)))(6,*((C_word*)lf[9]+1),((C_word*)t0)[3],lf[10],lf[8],t1,((C_word*)t0)[2]);}

/* k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_972,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* tcp.scm:263: make-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[16]+1)))(3,*((C_word*)lf[16]+1),t2,C_fix((C_word)sizeof(struct sockaddr_in)));}

/* k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_975(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_975,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_978,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1010,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:265: ##net#gethostaddr */
f_824(t3,t1,((C_word*)t0)[2],((C_word*)t0)[3]);}
else{
t3=t1;
if(C_truep(t3)){
t4=C_i_foreign_block_argumentp(t3);
t5=C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t6=t2;
f_978(2,t6,stub214(C_SCHEME_UNDEFINED,t4,t5));}
else{
t4=C_i_foreign_fixnum_argumentp(((C_word*)t0)[3]);
t5=t2;
f_978(2,t5,stub214(C_SCHEME_UNDEFINED,C_SCHEME_FALSE,t4));}}}

/* k1008 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[4];
f_978(2,t3,t2);}
else{
/* tcp.scm:266: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[8],lf[15],((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k976 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_978,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=C_fix((C_word)sizeof(struct sockaddr_in));
t4=C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t5=(C_truep(t2)?C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=C_i_foreign_fixnum_argumentp(t3);
t7=stub72(C_SCHEME_UNDEFINED,t4,t5,t6);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_984,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t9=C_eqp(C_fix(-1),t7);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_993,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t8,tmp=(C_word)a,a+=5,tmp);
/* tcp.scm:272: ##sys#update-errno */
((C_proc2)C_retrieve_proc(*((C_word*)lf[14]+1)))(2,*((C_word*)lf[14]+1),t10);}
else{
/* tcp.scm:276: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[4],((C_word*)t0)[5]);}}

/* k991 in k976 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_993,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1000,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1004,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[13]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)strerror(errno)),C_fix(0));}

/* k1002 in k991 in k976 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:275: ##sys#string-append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[11]+1)))(4,*((C_word*)lf[11]+1),((C_word*)t0)[2],lf[12],t1);}

/* k998 in k991 in k976 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_1000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:273: ##sys#signal-hook */
((C_proc7)C_retrieve_proc(*((C_word*)lf[9]+1)))(7,*((C_word*)lf[9]+1),((C_word*)t0)[4],lf[10],lf[8],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k982 in k976 in k973 in k970 in k967 in k961 in a1073 in body248 in tcp-listen in k781 in k583 in k580 in k577 */
static void C_ccall f_984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tcp.scm:276: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* yield in k781 in k583 in k580 in k577 */
static void C_fcall f_849(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_849,NULL,1,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_855,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp);
/* tcp.scm:210: ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t2);}

/* a854 in yield in k781 in k583 in k580 in k577 */
static void C_ccall f_855(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_855,3,t0,t1,t2);}
t3=*((C_word*)lf[5]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_864,a[2]=t2,a[3]=((C_word)li1),tmp=(C_word)a,a+=4,tmp);
t5=C_i_setslot(t3,C_fix(1),t4);
/* tcp.scm:214: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[6]+1)))(2,*((C_word*)lf[6]+1),t1);}

/* a863 in a854 in yield in k781 in k583 in k580 in k577 */
static void C_ccall f_864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_864,2,t0,t1);}
/* tcp.scm:213: return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* ##net#gethostaddr in k781 in k583 in k580 in k577 */
static void C_fcall f_824(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_824,NULL,4,t1,t2,t3,t4);}
t5=(C_truep(t2)?C_i_foreign_block_argumentp(t2):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_833,a[2]=t5,a[3]=t1,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t7=C_i_foreign_string_argumentp(t3);
/* ##sys#make-c-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[3]+1)))(3,*((C_word*)lf[3]+1),t6,t7);}
else{
t7=C_i_foreign_fixnum_argumentp(t4);
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub188(C_SCHEME_UNDEFINED,t5,C_SCHEME_FALSE,t7));}}

/* k831 in ##net#gethostaddr in k781 in k583 in k580 in k577 */
static void C_ccall f_833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[4]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,stub188(C_SCHEME_UNDEFINED,((C_word*)t0)[2],t1,t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[218] = {
{"toplevel:tcp_scm",(void*)C_tcp_toplevel},
{"f_579:tcp_scm",(void*)f_579},
{"f_582:tcp_scm",(void*)f_582},
{"f_585:tcp_scm",(void*)f_585},
{"f_783:tcp_scm",(void*)f_783},
{"f_1208:tcp_scm",(void*)f_1208},
{"f_2479:tcp_scm",(void*)f_2479},
{"f_1231:tcp_scm",(void*)f_1231},
{"f_2475:tcp_scm",(void*)f_2475},
{"f_1235:tcp_scm",(void*)f_1235},
{"f_2471:tcp_scm",(void*)f_2471},
{"f_1239:tcp_scm",(void*)f_1239},
{"f_2467:tcp_scm",(void*)f_2467},
{"f_1243:tcp_scm",(void*)f_1243},
{"f_2456:tcp_scm",(void*)f_2456},
{"f_2436:tcp_scm",(void*)f_2436},
{"f_2440:tcp_scm",(void*)f_2440},
{"f_2447:tcp_scm",(void*)f_2447},
{"f_2407:tcp_scm",(void*)f_2407},
{"f_2434:tcp_scm",(void*)f_2434},
{"f_2430:tcp_scm",(void*)f_2430},
{"f_2420:tcp_scm",(void*)f_2420},
{"f_2359:tcp_scm",(void*)f_2359},
{"f_2363:tcp_scm",(void*)f_2363},
{"f_2366:tcp_scm",(void*)f_2366},
{"f_2405:tcp_scm",(void*)f_2405},
{"f_2401:tcp_scm",(void*)f_2401},
{"f_2376:tcp_scm",(void*)f_2376},
{"f_2394:tcp_scm",(void*)f_2394},
{"f_2390:tcp_scm",(void*)f_2390},
{"f_2383:tcp_scm",(void*)f_2383},
{"f_2311:tcp_scm",(void*)f_2311},
{"f_2315:tcp_scm",(void*)f_2315},
{"f_2318:tcp_scm",(void*)f_2318},
{"f_2325:tcp_scm",(void*)f_2325},
{"f_2357:tcp_scm",(void*)f_2357},
{"f_2353:tcp_scm",(void*)f_2353},
{"f_2328:tcp_scm",(void*)f_2328},
{"f_2332:tcp_scm",(void*)f_2332},
{"f_2346:tcp_scm",(void*)f_2346},
{"f_2342:tcp_scm",(void*)f_2342},
{"f_2335:tcp_scm",(void*)f_2335},
{"f_2293:tcp_scm",(void*)f_2293},
{"f_2297:tcp_scm",(void*)f_2297},
{"f_2040:tcp_scm",(void*)f_2040},
{"f_2044:tcp_scm",(void*)f_2044},
{"f_2047:tcp_scm",(void*)f_2047},
{"f_2269:tcp_scm",(void*)f_2269},
{"f_2263:tcp_scm",(void*)f_2263},
{"f_879:tcp_scm",(void*)f_879},
{"f_902:tcp_scm",(void*)f_902},
{"f_906:tcp_scm",(void*)f_906},
{"f_790:tcp_scm",(void*)f_790},
{"f_794:tcp_scm",(void*)f_794},
{"f_918:tcp_scm",(void*)f_918},
{"f_929:tcp_scm",(void*)f_929},
{"f_925:tcp_scm",(void*)f_925},
{"f_912:tcp_scm",(void*)f_912},
{"f_2255:tcp_scm",(void*)f_2255},
{"f_2053:tcp_scm",(void*)f_2053},
{"f_2059:tcp_scm",(void*)f_2059},
{"f_2241:tcp_scm",(void*)f_2241},
{"f_2252:tcp_scm",(void*)f_2252},
{"f_2248:tcp_scm",(void*)f_2248},
{"f_2085:tcp_scm",(void*)f_2085},
{"f_2232:tcp_scm",(void*)f_2232},
{"f_2088:tcp_scm",(void*)f_2088},
{"f_2218:tcp_scm",(void*)f_2218},
{"f_2229:tcp_scm",(void*)f_2229},
{"f_2225:tcp_scm",(void*)f_2225},
{"f_2091:tcp_scm",(void*)f_2091},
{"f_2154:tcp_scm",(void*)f_2154},
{"f_2161:tcp_scm",(void*)f_2161},
{"f_2199:tcp_scm",(void*)f_2199},
{"f_2170:tcp_scm",(void*)f_2170},
{"f_2173:tcp_scm",(void*)f_2173},
{"f_2176:tcp_scm",(void*)f_2176},
{"f_2179:tcp_scm",(void*)f_2179},
{"f_2094:tcp_scm",(void*)f_2094},
{"f_2140:tcp_scm",(void*)f_2140},
{"f_2136:tcp_scm",(void*)f_2136},
{"f_2120:tcp_scm",(void*)f_2120},
{"f_2116:tcp_scm",(void*)f_2116},
{"f_2100:tcp_scm",(void*)f_2100},
{"f_2064:tcp_scm",(void*)f_2064},
{"f_2071:tcp_scm",(void*)f_2071},
{"f_2082:tcp_scm",(void*)f_2082},
{"f_2078:tcp_scm",(void*)f_2078},
{"f_1986:tcp_scm",(void*)f_1986},
{"f_2005:tcp_scm",(void*)f_2005},
{"f_2016:tcp_scm",(void*)f_2016},
{"f_2012:tcp_scm",(void*)f_2012},
{"f_1996:tcp_scm",(void*)f_1996},
{"f_1900:tcp_scm",(void*)f_1900},
{"f_1910:tcp_scm",(void*)f_1910},
{"f_1915:tcp_scm",(void*)f_1915},
{"f_1980:tcp_scm",(void*)f_1980},
{"f_1951:tcp_scm",(void*)f_1951},
{"f_1954:tcp_scm",(void*)f_1954},
{"f_1957:tcp_scm",(void*)f_1957},
{"f_1960:tcp_scm",(void*)f_1960},
{"f_1937:tcp_scm",(void*)f_1937},
{"f_1948:tcp_scm",(void*)f_1948},
{"f_1944:tcp_scm",(void*)f_1944},
{"f_1928:tcp_scm",(void*)f_1928},
{"f_1245:tcp_scm",(void*)f_1245},
{"f_1887:tcp_scm",(void*)f_1887},
{"f_1898:tcp_scm",(void*)f_1898},
{"f_1894:tcp_scm",(void*)f_1894},
{"f_1249:tcp_scm",(void*)f_1249},
{"f_1252:tcp_scm",(void*)f_1252},
{"f_1258:tcp_scm",(void*)f_1258},
{"f_1261:tcp_scm",(void*)f_1261},
{"f_1264:tcp_scm",(void*)f_1264},
{"f_1267:tcp_scm",(void*)f_1267},
{"f_1765:tcp_scm",(void*)f_1765},
{"f_1775:tcp_scm",(void*)f_1775},
{"f_1863:tcp_scm",(void*)f_1863},
{"f_1789:tcp_scm",(void*)f_1789},
{"f_1791:tcp_scm",(void*)f_1791},
{"f_1798:tcp_scm",(void*)f_1798},
{"f_1820:tcp_scm",(void*)f_1820},
{"f_1836:tcp_scm",(void*)f_1836},
{"f_1700:tcp_scm",(void*)f_1700},
{"f_1706:tcp_scm",(void*)f_1706},
{"f_1754:tcp_scm",(void*)f_1754},
{"f_1682:tcp_scm",(void*)f_1682},
{"f_1686:tcp_scm",(void*)f_1686},
{"f_1639:tcp_scm",(void*)f_1639},
{"f_1647:tcp_scm",(void*)f_1647},
{"f_1653:tcp_scm",(void*)f_1653},
{"f_1656:tcp_scm",(void*)f_1656},
{"f_1667:tcp_scm",(void*)f_1667},
{"f_1663:tcp_scm",(void*)f_1663},
{"f_1604:tcp_scm",(void*)f_1604},
{"f_1626:tcp_scm",(void*)f_1626},
{"f_1637:tcp_scm",(void*)f_1637},
{"f_1633:tcp_scm",(void*)f_1633},
{"f_1617:tcp_scm",(void*)f_1617},
{"f_1582:tcp_scm",(void*)f_1582},
{"f_1586:tcp_scm",(void*)f_1586},
{"f_1344:tcp_scm",(void*)f_1344},
{"f_1530:tcp_scm",(void*)f_1530},
{"f_1540:tcp_scm",(void*)f_1540},
{"f_1467:tcp_scm",(void*)f_1467},
{"f_1514:tcp_scm",(void*)f_1514},
{"f_1517:tcp_scm",(void*)f_1517},
{"f_1475:tcp_scm",(void*)f_1475},
{"f_1478:tcp_scm",(void*)f_1478},
{"f_1484:tcp_scm",(void*)f_1484},
{"f_1487:tcp_scm",(void*)f_1487},
{"f_1498:tcp_scm",(void*)f_1498},
{"f_1494:tcp_scm",(void*)f_1494},
{"f_1566:tcp_scm",(void*)f_1566},
{"f_1546:tcp_scm",(void*)f_1546},
{"f_1551:tcp_scm",(void*)f_1551},
{"f_1560:tcp_scm",(void*)f_1560},
{"f_1440:tcp_scm",(void*)f_1440},
{"f_1455:tcp_scm",(void*)f_1455},
{"f_1458:tcp_scm",(void*)f_1458},
{"f_1345:tcp_scm",(void*)f_1345},
{"f_1355:tcp_scm",(void*)f_1355},
{"f_1359:tcp_scm",(void*)f_1359},
{"f_1409:tcp_scm",(void*)f_1409},
{"f_1420:tcp_scm",(void*)f_1420},
{"f_1416:tcp_scm",(void*)f_1416},
{"f_1406:tcp_scm",(void*)f_1406},
{"f_1377:tcp_scm",(void*)f_1377},
{"f_1380:tcp_scm",(void*)f_1380},
{"f_1383:tcp_scm",(void*)f_1383},
{"f_1386:tcp_scm",(void*)f_1386},
{"f_1268:tcp_scm",(void*)f_1268},
{"f_1274:tcp_scm",(void*)f_1274},
{"f_1325:tcp_scm",(void*)f_1325},
{"f_1336:tcp_scm",(void*)f_1336},
{"f_1332:tcp_scm",(void*)f_1332},
{"f_1322:tcp_scm",(void*)f_1322},
{"f_1293:tcp_scm",(void*)f_1293},
{"f_1296:tcp_scm",(void*)f_1296},
{"f_1299:tcp_scm",(void*)f_1299},
{"f_1302:tcp_scm",(void*)f_1302},
{"f_1214:tcp_scm",(void*)f_1214},
{"f_1216:tcp_scm",(void*)f_1216},
{"f_1173:tcp_scm",(void*)f_1173},
{"f_1189:tcp_scm",(void*)f_1189},
{"f_1200:tcp_scm",(void*)f_1200},
{"f_1196:tcp_scm",(void*)f_1196},
{"f_1164:tcp_scm",(void*)f_1164},
{"f_1066:tcp_scm",(void*)f_1066},
{"f_1116:tcp_scm",(void*)f_1116},
{"f_1111:tcp_scm",(void*)f_1111},
{"f_1068:tcp_scm",(void*)f_1068},
{"f_1080:tcp_scm",(void*)f_1080},
{"f_1099:tcp_scm",(void*)f_1099},
{"f_1110:tcp_scm",(void*)f_1110},
{"f_1106:tcp_scm",(void*)f_1106},
{"f_1090:tcp_scm",(void*)f_1090},
{"f_1074:tcp_scm",(void*)f_1074},
{"f_963:tcp_scm",(void*)f_963},
{"f_1049:tcp_scm",(void*)f_1049},
{"f_969:tcp_scm",(void*)f_969},
{"f_1022:tcp_scm",(void*)f_1022},
{"f_1033:tcp_scm",(void*)f_1033},
{"f_1029:tcp_scm",(void*)f_1029},
{"f_972:tcp_scm",(void*)f_972},
{"f_975:tcp_scm",(void*)f_975},
{"f_1010:tcp_scm",(void*)f_1010},
{"f_978:tcp_scm",(void*)f_978},
{"f_993:tcp_scm",(void*)f_993},
{"f_1004:tcp_scm",(void*)f_1004},
{"f_1000:tcp_scm",(void*)f_1000},
{"f_984:tcp_scm",(void*)f_984},
{"f_849:tcp_scm",(void*)f_849},
{"f_855:tcp_scm",(void*)f_855},
{"f_864:tcp_scm",(void*)f_864},
{"f_824:tcp_scm",(void*)f_824},
{"f_833:tcp_scm",(void*)f_833},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
