/* Generated from c-backend.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: c-backend.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file c-backend.c
   unit: backend
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[866];
static double C_possibly_force_alignment;


#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1880(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1880(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);
return(C_header_size(lit));
C_ret:
#undef return

return C_r;}

#define return(x) C_cblock C_r = (C_fix((C_word)(x))); goto C_ret; C_cblockend
static C_word C_fcall stub1876(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub1876(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
C_word lit=(C_word )(C_a0);

#ifdef C_SIXTY_FOUR
return((C_header_bits(lit) >> (24 + 32)) & 0xff);
#else
return((C_header_bits(lit) >> 24) & 0xff);
#endif

C_ret:
#undef return

return C_r;}

C_noret_decl(C_backend_toplevel)
C_externexport void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1922)
static void C_ccall f_1922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1925)
static void C_ccall f_1925(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9737)
static void C_ccall f_9737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9740)
static void C_ccall f_9740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9767)
static void C_ccall f_9767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9763)
static void C_ccall f_9763(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9743)
static void C_ccall f_9743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9746)
static void C_ccall f_9746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9759)
static void C_ccall f_9759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9749)
static void C_ccall f_9749(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9752)
static void C_ccall f_9752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9755)
static void C_ccall f_9755(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9437)
static void C_ccall f_9437(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9713)
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9711)
static void C_ccall f_9711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9699)
static void C_ccall f_9699(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9669)
static void C_ccall f_9669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9630)
static void C_ccall f_9630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9617)
static void C_ccall f_9617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9613)
static void C_ccall f_9613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9499)
static void C_ccall f_9499(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9446)
static C_word C_fcall f_9446(C_word *a,C_word t0);
C_noret_decl(f_8830)
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8941)
static void C_fcall f_8941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9106)
static void C_ccall f_9106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9133)
static void C_fcall f_9133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9311)
static void C_ccall f_9311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9314)
static void C_ccall f_9314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9317)
static void C_ccall f_9317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9320)
static void C_ccall f_9320(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9290)
static void C_ccall f_9290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9293)
static void C_ccall f_9293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9296)
static void C_ccall f_9296(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9299)
static void C_ccall f_9299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9269)
static void C_ccall f_9269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9272)
static void C_ccall f_9272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9275)
static void C_ccall f_9275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9278)
static void C_ccall f_9278(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9232)
static void C_ccall f_9232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9235)
static void C_ccall f_9235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9238)
static void C_ccall f_9238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9241)
static void C_ccall f_9241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9211)
static void C_ccall f_9211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9214)
static void C_ccall f_9214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9217)
static void C_ccall f_9217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9220)
static void C_ccall f_9220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9190)
static void C_ccall f_9190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9196)
static void C_ccall f_9196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9199)
static void C_ccall f_9199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9172)
static void C_ccall f_9172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9175)
static void C_ccall f_9175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9178)
static void C_ccall f_9178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9148)
static void C_ccall f_9148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9151)
static void C_ccall f_9151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9157)
static void C_ccall f_9157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_fcall f_9110(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9076)
static void C_ccall f_9076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9082)
static void C_ccall f_9082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9055)
static void C_ccall f_9055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9058)
static void C_ccall f_9058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9061)
static void C_ccall f_9061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9064)
static void C_ccall f_9064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9034)
static void C_ccall f_9034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9037)
static void C_ccall f_9037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9040)
static void C_ccall f_9040(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9043)
static void C_ccall f_9043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9010)
static void C_ccall f_9010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9013)
static void C_ccall f_9013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9016)
static void C_ccall f_9016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9019)
static void C_ccall f_9019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8989)
static void C_ccall f_8989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8992)
static void C_ccall f_8992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8995)
static void C_ccall f_8995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8998)
static void C_ccall f_8998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8968)
static void C_ccall f_8968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8971)
static void C_ccall f_8971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8947)
static void C_ccall f_8947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8950)
static void C_ccall f_8950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8953)
static void C_ccall f_8953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8920)
static void C_ccall f_8920(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8923)
static void C_ccall f_8923(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8926)
static void C_ccall f_8926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8929)
static void C_ccall f_8929(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8899)
static void C_ccall f_8899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8902)
static void C_ccall f_8902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8905)
static void C_ccall f_8905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8908)
static void C_ccall f_8908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8832)
static void C_fcall f_8832(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8340)
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8370)
static void C_fcall f_8370(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8397)
static void C_fcall f_8397(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8592)
static void C_fcall f_8592(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8601)
static void C_fcall f_8601(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8610)
static void C_ccall f_8610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8637)
static void C_fcall f_8637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8714)
static void C_ccall f_8714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8342)
static void C_fcall f_8342(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7456)
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7533)
static void C_fcall f_7533(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7635)
static void C_fcall f_7635(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_fcall f_7668(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7764)
static void C_fcall f_7764(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7776)
static void C_fcall f_7776(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7791)
static void C_ccall f_7791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_fcall f_7836(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7853)
static void C_fcall f_7853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_fcall f_7870(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_fcall f_7909(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7926)
static void C_fcall f_7926(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7943)
static void C_fcall f_7943(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7960)
static void C_fcall f_7960(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7977)
static void C_fcall f_7977(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7994)
static void C_fcall f_7994(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8011)
static void C_fcall f_8011(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8023)
static void C_ccall f_8023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8030)
static void C_ccall f_8030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8040)
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8080)
static void C_ccall f_8080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8050)
static void C_fcall f_8050(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8038)
static void C_ccall f_8038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8034)
static void C_ccall f_8034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8001)
static void C_ccall f_8001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7984)
static void C_ccall f_7984(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7967)
static void C_ccall f_7967(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7950)
static void C_ccall f_7950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7933)
static void C_ccall f_7933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7916)
static void C_ccall f_7916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7881)
static void C_ccall f_7881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7891)
static void C_ccall f_7891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7889)
static void C_ccall f_7889(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7885)
static void C_ccall f_7885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7864)
static void C_ccall f_7864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7847)
static void C_ccall f_7847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7795)
static void C_fcall f_7795(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7463)
static void C_fcall f_7463(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7458)
static void C_fcall f_7458(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7391)
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7395)
static void C_ccall f_7395(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7398)
static void C_ccall f_7398(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7401)
static void C_ccall f_7401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7404)
static void C_ccall f_7404(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7410)
static void C_ccall f_7410(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7454)
static void C_ccall f_7454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7413)
static void C_ccall f_7413(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7421)
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7442)
static void C_ccall f_7442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7425)
static void C_ccall f_7425(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7416)
static void C_ccall f_7416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6897)
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6903)
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7378)
static void C_ccall f_7378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6911)
static void C_fcall f_6911(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6915)
static void C_ccall f_6915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6918)
static void C_ccall f_6918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6921)
static void C_ccall f_6921(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6924)
static void C_ccall f_6924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6930)
static void C_ccall f_6930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7276)
static void C_ccall f_7276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7279)
static void C_ccall f_7279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7375)
static void C_ccall f_7375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7282)
static void C_ccall f_7282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7285)
static void C_ccall f_7285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7288)
static void C_ccall f_7288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7291)
static void C_ccall f_7291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7324)
static void C_fcall f_7324(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7340)
static void C_ccall f_7340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7343)
static void C_ccall f_7343(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7294)
static void C_ccall f_7294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7322)
static void C_ccall f_7322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7297)
static void C_ccall f_7297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7300)
static void C_ccall f_7300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7303)
static void C_ccall f_7303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6932)
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6942)
static void C_fcall f_6942(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6951)
static void C_fcall f_6951(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6963)
static void C_fcall f_6963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6975)
static void C_fcall f_6975(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6981)
static void C_ccall f_6981(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7020)
static void C_fcall f_7020(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6985)
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6583)
static void C_ccall f_6583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6589)
static void C_fcall f_6589(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6884)
static void C_ccall f_6884(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6597)
static void C_fcall f_6597(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6604)
static void C_ccall f_6604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6607)
static void C_ccall f_6607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_ccall f_6881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6613)
static void C_ccall f_6613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6616)
static void C_ccall f_6616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6619)
static void C_ccall f_6619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6622)
static void C_ccall f_6622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6625)
static void C_ccall f_6625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6628)
static void C_ccall f_6628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6631)
static void C_ccall f_6631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6634)
static void C_ccall f_6634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6637)
static void C_ccall f_6637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6640)
static void C_ccall f_6640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6870)
static void C_ccall f_6870(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6643)
static void C_ccall f_6643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6646)
static void C_ccall f_6646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6649)
static void C_ccall f_6649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6652)
static void C_ccall f_6652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6655)
static void C_ccall f_6655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6658)
static void C_ccall f_6658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6661)
static void C_ccall f_6661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6664)
static void C_ccall f_6664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6761)
static void C_ccall f_6761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6763)
static void C_fcall f_6763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_6770)
static void C_fcall f_6770(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6797)
static void C_ccall f_6797(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6800)
static void C_ccall f_6800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6803)
static void C_ccall f_6803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6791)
static void C_ccall f_6791(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6779)
static void C_ccall f_6779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6783)
static void C_ccall f_6783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6787)
static void C_ccall f_6787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_ccall f_6809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6667)
static void C_ccall f_6667(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6670)
static void C_ccall f_6670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6700)
static void C_ccall f_6700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6703)
static void C_ccall f_6703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6741)
static void C_ccall f_6741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6737)
static void C_ccall f_6737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6706)
static void C_ccall f_6706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6709)
static void C_ccall f_6709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6712)
static void C_ccall f_6712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6679)
static void C_ccall f_6679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6682)
static void C_ccall f_6682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6673)
static void C_ccall f_6673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6543)
static void C_ccall f_6543(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6549)
static void C_fcall f_6549(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6561)
static void C_ccall f_6561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6564)
static void C_ccall f_6564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6570)
static void C_ccall f_6570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6489)
static void C_ccall f_6489(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6493)
static void C_ccall f_6493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6498)
static void C_fcall f_6498(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6527)
static void C_ccall f_6527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6530)
static void C_ccall f_6530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6473)
static void C_ccall f_6473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6479)
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6487)
static void C_ccall f_6487(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6457)
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6463)
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6471)
static void C_ccall f_6471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6377)
static void C_fcall f_6377(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6406)
static void C_fcall f_6406(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6416)
static void C_ccall f_6416(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6291)
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6295)
static void C_ccall f_6295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6309)
static void C_fcall f_6309(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6322)
static void C_ccall f_6322(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6354)
static void C_ccall f_6354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6325)
static void C_ccall f_6325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6328)
static void C_ccall f_6328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6298)
static void C_ccall f_6298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6301)
static void C_ccall f_6301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6304)
static void C_ccall f_6304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2013)
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_6258)
static void C_ccall f_6258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6262)
static void C_ccall f_6262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6265)
static void C_ccall f_6265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6268)
static void C_ccall f_6268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6271)
static void C_ccall f_6271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6274)
static void C_ccall f_6274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6277)
static void C_ccall f_6277(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6280)
static void C_ccall f_6280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6283)
static void C_ccall f_6283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6286)
static void C_ccall f_6286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_fcall f_5473(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6244)
static void C_ccall f_6244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5487)
static void C_fcall f_5487(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5491)
static void C_ccall f_5491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5494)
static void C_ccall f_5494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5497)
static void C_ccall f_5497(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5500)
static void C_ccall f_5500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5503)
static void C_ccall f_5503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5506)
static void C_ccall f_5506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6241)
static void C_ccall f_6241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5509)
static void C_fcall f_5509(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5515)
static void C_ccall f_5515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5518)
static void C_ccall f_5518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5521)
static void C_ccall f_5521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5524)
static void C_ccall f_5524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5527)
static void C_ccall f_5527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5530)
static void C_ccall f_5530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5536)
static void C_ccall f_5536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5539)
static void C_ccall f_5539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5542)
static void C_ccall f_5542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5545)
static void C_ccall f_5545(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5548)
static void C_ccall f_5548(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5551)
static void C_ccall f_5551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5554)
static void C_ccall f_5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6171)
static void C_ccall f_6171(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6174)
static void C_ccall f_6174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6177)
static void C_ccall f_6177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6193)
static void C_ccall f_6193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6196)
static void C_ccall f_6196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5557)
static void C_ccall f_5557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5560)
static void C_ccall f_5560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5563)
static void C_ccall f_5563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6143)
static void C_fcall f_6143(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6146)
static void C_ccall f_6146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5566)
static void C_ccall f_5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5569)
static void C_ccall f_5569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5572)
static void C_ccall f_5572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5575)
static void C_ccall f_5575(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5578)
static void C_fcall f_5578(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5581)
static void C_ccall f_5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6103)
static void C_fcall f_6103(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6105)
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6115)
static void C_ccall f_6115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6056)
static void C_ccall f_6056(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6061)
static void C_fcall f_6061(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6077)
static void C_ccall f_6077(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6088)
static void C_ccall f_6088(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5584)
static void C_ccall f_5584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6017)
static void C_ccall f_6017(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6029)
static void C_fcall f_6029(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6020)
static void C_ccall f_6020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5927)
static void C_ccall f_5927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5969)
static void C_fcall f_5969(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5930)
static void C_ccall f_5930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5936)
static void C_fcall f_5936(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5939)
static void C_ccall f_5939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5863)
static void C_ccall f_5863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5866)
static void C_ccall f_5866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5869)
static void C_ccall f_5869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5872)
static void C_ccall f_5872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_ccall f_5875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5890)
static void C_fcall f_5890(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5878)
static void C_ccall f_5878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5881)
static void C_ccall f_5881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5849)
static void C_ccall f_5849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5857)
static void C_ccall f_5857(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5774)
static void C_ccall f_5774(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5780)
static void C_ccall f_5780(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5783)
static void C_ccall f_5783(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5817)
static void C_ccall f_5817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5820)
static void C_ccall f_5820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5823)
static void C_ccall f_5823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5786)
static void C_ccall f_5786(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5789)
static void C_ccall f_5789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5792)
static void C_ccall f_5792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5795)
static void C_ccall f_5795(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5804)
static void C_ccall f_5804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5807)
static void C_ccall f_5807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5587)
static void C_ccall f_5587(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5610)
static void C_fcall f_5610(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_ccall f_5715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5718)
static void C_ccall f_5718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5730)
static void C_ccall f_5730(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5721)
static void C_ccall f_5721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5619)
static void C_ccall f_5619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5702)
static void C_ccall f_5702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5622)
static void C_ccall f_5622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5625)
static void C_ccall f_5625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5628)
static void C_ccall f_5628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5696)
static void C_ccall f_5696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5692)
static void C_ccall f_5692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_ccall f_5634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5637)
static void C_ccall f_5637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5640)
static void C_ccall f_5640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5643)
static void C_ccall f_5643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5646)
static void C_ccall f_5646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5649)
static void C_ccall f_5649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5667)
static void C_fcall f_5667(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5677)
static void C_ccall f_5677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5652)
static void C_ccall f_5652(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5590)
static void C_ccall f_5590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5600)
static void C_ccall f_5600(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5593)
static void C_ccall f_5593(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5425)
static void C_fcall f_5425(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5432)
static void C_ccall f_5432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5435)
static void C_ccall f_5435(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5348)
static void C_fcall f_5348(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5355)
static void C_ccall f_5355(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5358)
static void C_ccall f_5358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5363)
static void C_fcall f_5363(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5419)
static void C_ccall f_5419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5415)
static void C_ccall f_5415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5400)
static void C_ccall f_5400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5379)
static void C_fcall f_5379(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5390)
static void C_ccall f_5390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5386)
static void C_ccall f_5386(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5206)
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5346)
static void C_ccall f_5346(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5213)
static void C_fcall f_5213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5219)
static void C_ccall f_5219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5302)
static void C_fcall f_5302(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5305)
static void C_ccall f_5305(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5315)
static void C_ccall f_5315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5308)
static void C_ccall f_5308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_ccall f_5269(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5275)
static void C_ccall f_5275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5012)
static void C_fcall f_5012(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5019)
static void C_ccall f_5019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5128)
static void C_ccall f_5128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5146)
static void C_ccall f_5146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_fcall f_5175(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5197)
static void C_ccall f_5197(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5087)
static void C_ccall f_5087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_fcall f_5089(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5118)
static void C_ccall f_5118(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5083)
static void C_ccall f_5083(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5079)
static void C_ccall f_5079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5050)
static void C_ccall f_5050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5054)
static void C_ccall f_5054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4957)
static void C_fcall f_4957(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4963)
static void C_fcall f_4963(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4998)
static void C_ccall f_4998(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_ccall f_5001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5004)
static void C_ccall f_5004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4637)
static void C_fcall f_4637(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_fcall f_4826(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4944)
static void C_ccall f_4944(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4834)
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4838)
static void C_ccall f_4838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4841)
static void C_ccall f_4841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4844)
static void C_ccall f_4844(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4847)
static void C_ccall f_4847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4850)
static void C_ccall f_4850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4941)
static void C_ccall f_4941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4853)
static void C_fcall f_4853(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4856)
static void C_fcall f_4856(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4862)
static void C_ccall f_4862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4930)
static void C_ccall f_4930(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4896)
static void C_ccall f_4896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4902)
static void C_fcall f_4902(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4910)
static void C_ccall f_4910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_ccall f_4906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4868)
static void C_ccall f_4868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4871)
static void C_ccall f_4871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4874)
static void C_ccall f_4874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4877)
static void C_ccall f_4877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4880)
static void C_ccall f_4880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4890)
static void C_ccall f_4890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4883)
static void C_ccall f_4883(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4756)
static void C_ccall f_4756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4775)
static void C_fcall f_4775(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4813)
static void C_ccall f_4813(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4783)
static void C_fcall f_4783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4787)
static void C_ccall f_4787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4793)
static void C_ccall f_4793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4796)
static void C_ccall f_4796(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4810)
static void C_ccall f_4810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4806)
static void C_ccall f_4806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4799)
static void C_ccall f_4799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4759)
static void C_ccall f_4759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4773)
static void C_ccall f_4773(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4762)
static void C_ccall f_4762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4769)
static void C_ccall f_4769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4676)
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4678)
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4682)
static void C_ccall f_4682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4688)
static void C_ccall f_4688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4691)
static void C_ccall f_4691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4694)
static void C_ccall f_4694(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4697)
static void C_ccall f_4697(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4700)
static void C_ccall f_4700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4703)
static void C_ccall f_4703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4706)
static void C_ccall f_4706(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4709)
static void C_ccall f_4709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4712)
static void C_ccall f_4712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4715)
static void C_ccall f_4715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4729)
static void C_ccall f_4729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4725)
static void C_ccall f_4725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4718)
static void C_ccall f_4718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4640)
static void C_fcall f_4640(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4653)
static void C_fcall f_4653(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4663)
static void C_ccall f_4663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4644)
static void C_ccall f_4644(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4303)
static void C_fcall f_4303(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4307)
static void C_ccall f_4307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4376)
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4624)
static void C_ccall f_4624(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4388)
static void C_ccall f_4388(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4391)
static void C_ccall f_4391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4394)
static void C_fcall f_4394(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_ccall f_4607(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4397)
static void C_ccall f_4397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4400)
static void C_ccall f_4400(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4403)
static void C_ccall f_4403(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4406)
static void C_ccall f_4406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4409)
static void C_ccall f_4409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4412)
static void C_ccall f_4412(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4599)
static void C_ccall f_4599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_fcall f_4415(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4418)
static void C_ccall f_4418(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_fcall f_4555(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4581)
static void C_ccall f_4581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4563)
static void C_fcall f_4563(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4574)
static void C_ccall f_4574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4421)
static void C_ccall f_4421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4508)
static void C_ccall f_4508(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4511)
static void C_ccall f_4511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4517)
static void C_ccall f_4517(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4533)
static void C_ccall f_4533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4536)
static void C_ccall f_4536(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4539)
static void C_ccall f_4539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4424)
static void C_ccall f_4424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4427)
static void C_ccall f_4427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4430)
static void C_ccall f_4430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4480)
static void C_fcall f_4480(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4483)
static void C_ccall f_4483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4433)
static void C_ccall f_4433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4436)
static void C_ccall f_4436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4468)
static void C_ccall f_4468(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4471)
static void C_ccall f_4471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4442)
static void C_ccall f_4442(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4451)
static void C_ccall f_4451(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4454)
static void C_ccall f_4454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4310)
static void C_ccall f_4310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4315)
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4327)
static void C_ccall f_4327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4337)
static void C_ccall f_4337(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4339)
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4349)
static void C_ccall f_4349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4330)
static void C_ccall f_4330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4363)
static void C_ccall f_4363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4132)
static void C_fcall f_4132(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4275)
static void C_fcall f_4275(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4290)
static void C_ccall f_4290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4142)
static void C_ccall f_4142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4145)
static void C_ccall f_4145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4148)
static void C_ccall f_4148(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4163)
static void C_ccall f_4163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4222)
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4172)
static void C_ccall f_4172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4195)
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4175)
static void C_ccall f_4175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4178)
static void C_ccall f_4178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3963)
static void C_fcall f_3963(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4124)
static void C_ccall f_4124(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4082)
static void C_ccall f_4082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_ccall f_4086(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4102)
static void C_ccall f_4102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4098)
static void C_ccall f_4098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4001)
static void C_ccall f_4001(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4004)
static void C_ccall f_4004(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4007)
static void C_ccall f_4007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4071)
static void C_ccall f_4071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4010)
static void C_ccall f_4010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4013)
static void C_ccall f_4013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4016)
static void C_ccall f_4016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4036)
static void C_fcall f_4036(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4051)
static void C_ccall f_4051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4019)
static void C_ccall f_4019(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3966)
static void C_fcall f_3966(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2058)
static void C_fcall f_2058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3931)
static void C_fcall f_3931(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3937)
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3941)
static void C_ccall f_3941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2061)
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3887)
static void C_ccall f_3887(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3890)
static void C_ccall f_3890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3896)
static void C_ccall f_3896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3899)
static void C_ccall f_3899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3902)
static void C_ccall f_3902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3804)
static void C_ccall f_3804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3807)
static void C_ccall f_3807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3810)
static void C_ccall f_3810(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3823)
static void C_fcall f_3823(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3846)
static void C_ccall f_3846(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3852)
static void C_ccall f_3852(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3855)
static void C_ccall f_3855(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3833)
static void C_ccall f_3833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3836)
static void C_ccall f_3836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3788)
static void C_ccall f_3788(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3765)
static void C_ccall f_3765(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3712)
static void C_ccall f_3712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3715)
static void C_ccall f_3715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3732)
static void C_ccall f_3732(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3718)
static void C_ccall f_3718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3721)
static void C_ccall f_3721(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3696)
static void C_ccall f_3696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3700)
static void C_ccall f_3700(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3682)
static void C_ccall f_3682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3685)
static void C_ccall f_3685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3666)
static void C_ccall f_3666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3670)
static void C_ccall f_3670(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_ccall f_3648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3651)
static void C_ccall f_3651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3604)
static void C_ccall f_3604(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3595)
static void C_ccall f_3595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3573)
static void C_ccall f_3573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3576)
static void C_ccall f_3576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3554)
static void C_ccall f_3554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3535)
static void C_ccall f_3535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3538)
static void C_ccall f_3538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3516)
static void C_ccall f_3516(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3512)
static void C_ccall f_3512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3460)
static void C_ccall f_3460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3493)
static void C_ccall f_3493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3463)
static void C_ccall f_3463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3481)
static void C_ccall f_3481(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3466)
static void C_ccall f_3466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3469)
static void C_ccall f_3469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3427)
static void C_ccall f_3427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f10580)
static void C_ccall f10580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3414)
static void C_ccall f_3414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3301)
static void C_ccall f_3301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_fcall f_3358(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3366)
static void C_fcall f_3366(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3373)
static void C_ccall f_3373(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3304)
static void C_ccall f_3304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3314)
static void C_ccall f_3314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_fcall f_3316(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3331)
static void C_ccall f_3331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3307)
static void C_ccall f_3307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2815)
static void C_ccall f_2815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2818)
static void C_fcall f_2818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3244)
static void C_ccall f_3244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2824)
static void C_fcall f_2824(C_word t0,C_word t1) C_noret;
C_noret_decl(f10572)
static void C_ccall f10572(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3237)
static void C_ccall f_3237(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2046)
static void C_ccall f_2046(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_ccall f_3230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2830)
static void C_ccall f_2830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3034)
static void C_fcall f_3034(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3147)
static void C_ccall f_3147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3150)
static void C_ccall f_3150(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3153)
static void C_ccall f_3153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3168)
static void C_fcall f_3168(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3156)
static void C_ccall f_3156(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3159)
static void C_ccall f_3159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3162)
static void C_ccall f_3162(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3054)
static void C_ccall f_3054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3144)
static void C_ccall f_3144(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3137)
static void C_ccall f_3137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3133)
static void C_ccall f_3133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3126)
static void C_ccall f_3126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3119)
static void C_ccall f_3119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3094)
static void C_ccall f_3094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3111)
static void C_ccall f_3111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3107)
static void C_ccall f_3107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3087)
static void C_ccall f_3087(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3080)
static void C_ccall f_3080(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3057)
static void C_ccall f_3057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3060)
static void C_ccall f_3060(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3063)
static void C_ccall f_3063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3028)
static void C_ccall f_3028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2866)
static void C_ccall f_2866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3012)
static void C_ccall f_3012(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3015)
static void C_ccall f_3015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2988)
static void C_ccall f_2988(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2991)
static void C_ccall f_2991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2994)
static void C_ccall f_2994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f10567)
static void C_ccall f10567(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2997)
static void C_ccall f_2997(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3000)
static void C_ccall f_3000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2869)
static void C_ccall f_2869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2872)
static void C_ccall f_2872(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2935)
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2956)
static void C_ccall f_2956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2943)
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2947)
static void C_ccall f_2947(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2950)
static void C_ccall f_2950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2875)
static void C_ccall f_2875(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2891)
static void C_ccall f_2891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2893)
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2908)
static void C_ccall f_2908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2878)
static void C_ccall f_2878(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2881)
static void C_ccall f_2881(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2847)
static void C_ccall f_2847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2850)
static void C_ccall f_2850(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2782)
static void C_ccall f_2782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f10559)
static void C_ccall f10559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2778)
static void C_ccall f_2778(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2764)
static void C_ccall f_2764(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2767)
static void C_ccall f_2767(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2761)
static void C_ccall f_2761(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f10554)
static void C_ccall f10554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2757)
static void C_ccall f_2757(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2743)
static void C_ccall f_2743(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2746)
static void C_ccall f_2746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2695)
static void C_ccall f_2695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2716)
static void C_ccall f_2716(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f10549)
static void C_ccall f10549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2712)
static void C_ccall f_2712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2698)
static void C_ccall f_2698(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2701)
static void C_ccall f_2701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2664)
static void C_ccall f_2664(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2660)
static void C_ccall f_2660(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2618)
static void C_ccall f_2618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2586)
static void C_ccall f_2586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2589)
static void C_ccall f_2589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2515)
static void C_ccall f_2515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2531)
static void C_fcall f_2531(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2539)
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2543)
static void C_ccall f_2543(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2518)
static void C_ccall f_2518(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2483)
static void C_ccall f_2483(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_ccall f_2486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2489)
static void C_ccall f_2489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2492)
static void C_ccall f_2492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2454)
static void C_ccall f_2454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2457)
static void C_ccall f_2457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2460)
static void C_ccall f_2460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2463)
static void C_ccall f_2463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2417)
static void C_ccall f_2417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2420)
static void C_ccall f_2420(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2423)
static void C_ccall f_2423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2426)
static void C_ccall f_2426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2384)
static void C_ccall f_2384(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2387)
static void C_ccall f_2387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2390)
static void C_ccall f_2390(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2365)
static void C_ccall f_2365(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2368)
static void C_ccall f_2368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2338)
static void C_ccall f_2338(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2312)
static void C_ccall f_2312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2315)
static void C_ccall f_2315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2318)
static void C_ccall f_2318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2258)
static void C_fcall f_2258(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2268)
static void C_ccall f_2268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2271)
static void C_ccall f_2271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2274)
static void C_ccall f_2274(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2200)
static void C_ccall f_2200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2206)
static void C_ccall f_2206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2209)
static void C_ccall f_2209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2212)
static void C_ccall f_2212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2215)
static void C_ccall f_2215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2028)
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2036)
static void C_ccall f_2036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2020)
static void C_ccall f_2020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1971)
static void C_ccall f_1971(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1979)
static void C_ccall f_1979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1981)
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1996)
static void C_ccall f_1996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1928)
static void C_ccall f_1928r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1934)
static void C_fcall f_1934(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1958)
static void C_ccall f_1958(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_8941)
static void C_fcall trf_8941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8941(t0,t1);}

C_noret_decl(trf_9133)
static void C_fcall trf_9133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9133(t0,t1);}

C_noret_decl(trf_9110)
static void C_fcall trf_9110(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9110(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9110(t0,t1,t2);}

C_noret_decl(trf_8832)
static void C_fcall trf_8832(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8832(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8832(t0,t1);}

C_noret_decl(trf_8370)
static void C_fcall trf_8370(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8370(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8370(t0,t1);}

C_noret_decl(trf_8397)
static void C_fcall trf_8397(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8397(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8397(t0,t1);}

C_noret_decl(trf_8592)
static void C_fcall trf_8592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8592(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8592(t0,t1);}

C_noret_decl(trf_8601)
static void C_fcall trf_8601(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8601(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8601(t0,t1);}

C_noret_decl(trf_8637)
static void C_fcall trf_8637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8637(t0,t1);}

C_noret_decl(trf_8342)
static void C_fcall trf_8342(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8342(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8342(t0,t1);}

C_noret_decl(trf_7533)
static void C_fcall trf_7533(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7533(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7533(t0,t1);}

C_noret_decl(trf_7635)
static void C_fcall trf_7635(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7635(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7635(t0,t1);}

C_noret_decl(trf_7668)
static void C_fcall trf_7668(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7668(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7668(t0,t1);}

C_noret_decl(trf_7764)
static void C_fcall trf_7764(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7764(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7764(t0,t1);}

C_noret_decl(trf_7776)
static void C_fcall trf_7776(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7776(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7776(t0,t1);}

C_noret_decl(trf_7836)
static void C_fcall trf_7836(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7836(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7836(t0,t1);}

C_noret_decl(trf_7853)
static void C_fcall trf_7853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7853(t0,t1);}

C_noret_decl(trf_7870)
static void C_fcall trf_7870(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7870(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7870(t0,t1);}

C_noret_decl(trf_7909)
static void C_fcall trf_7909(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7909(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7909(t0,t1);}

C_noret_decl(trf_7926)
static void C_fcall trf_7926(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7926(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7926(t0,t1);}

C_noret_decl(trf_7943)
static void C_fcall trf_7943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7943(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7943(t0,t1);}

C_noret_decl(trf_7960)
static void C_fcall trf_7960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7960(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7960(t0,t1);}

C_noret_decl(trf_7977)
static void C_fcall trf_7977(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7977(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7977(t0,t1);}

C_noret_decl(trf_7994)
static void C_fcall trf_7994(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7994(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7994(t0,t1);}

C_noret_decl(trf_8011)
static void C_fcall trf_8011(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8011(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8011(t0,t1);}

C_noret_decl(trf_8040)
static void C_fcall trf_8040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8040(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8040(t0,t1,t2);}

C_noret_decl(trf_8050)
static void C_fcall trf_8050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8050(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8050(t0,t1);}

C_noret_decl(trf_7795)
static void C_fcall trf_7795(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7795(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7795(t0,t1,t2);}

C_noret_decl(trf_7463)
static void C_fcall trf_7463(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7463(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7463(t0,t1,t2);}

C_noret_decl(trf_7458)
static void C_fcall trf_7458(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7458(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7458(t0,t1);}

C_noret_decl(trf_6903)
static void C_fcall trf_6903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6903(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6903(t0,t1,t2);}

C_noret_decl(trf_6911)
static void C_fcall trf_6911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6911(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6911(t0,t1,t2);}

C_noret_decl(trf_7324)
static void C_fcall trf_7324(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7324(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7324(t0,t1,t2,t3);}

C_noret_decl(trf_6942)
static void C_fcall trf_6942(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6942(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6942(t0,t1);}

C_noret_decl(trf_6951)
static void C_fcall trf_6951(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6951(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6951(t0,t1);}

C_noret_decl(trf_6963)
static void C_fcall trf_6963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6963(t0,t1);}

C_noret_decl(trf_6975)
static void C_fcall trf_6975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6975(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6975(t0,t1);}

C_noret_decl(trf_7020)
static void C_fcall trf_7020(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7020(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7020(t0,t1);}

C_noret_decl(trf_6985)
static void C_fcall trf_6985(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6985(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6985(t0,t1,t2);}

C_noret_decl(trf_6589)
static void C_fcall trf_6589(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6589(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6589(t0,t1,t2);}

C_noret_decl(trf_6597)
static void C_fcall trf_6597(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6597(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6597(t0,t1,t2);}

C_noret_decl(trf_6763)
static void C_fcall trf_6763(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6763(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6763(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6770)
static void C_fcall trf_6770(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6770(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6770(t0,t1);}

C_noret_decl(trf_6549)
static void C_fcall trf_6549(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6549(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6549(t0,t1,t2);}

C_noret_decl(trf_6498)
static void C_fcall trf_6498(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6498(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6498(t0,t1,t2);}

C_noret_decl(trf_6377)
static void C_fcall trf_6377(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6377(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6377(t0,t1,t2);}

C_noret_decl(trf_6406)
static void C_fcall trf_6406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6406(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6406(t0,t1);}

C_noret_decl(trf_6309)
static void C_fcall trf_6309(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6309(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6309(t0,t1,t2);}

C_noret_decl(trf_5473)
static void C_fcall trf_5473(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5473(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5473(t0,t1);}

C_noret_decl(trf_5479)
static void C_fcall trf_5479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5479(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5479(t0,t1,t2);}

C_noret_decl(trf_5487)
static void C_fcall trf_5487(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5487(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5487(t0,t1,t2);}

C_noret_decl(trf_5509)
static void C_fcall trf_5509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5509(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5509(t0,t1);}

C_noret_decl(trf_6143)
static void C_fcall trf_6143(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6143(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6143(t0,t1);}

C_noret_decl(trf_5578)
static void C_fcall trf_5578(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5578(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5578(t0,t1);}

C_noret_decl(trf_6103)
static void C_fcall trf_6103(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6103(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6103(t0,t1);}

C_noret_decl(trf_6105)
static void C_fcall trf_6105(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6105(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6105(t0,t1,t2,t3);}

C_noret_decl(trf_6061)
static void C_fcall trf_6061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6061(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6061(t0,t1,t2);}

C_noret_decl(trf_6029)
static void C_fcall trf_6029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6029(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6029(t0,t1);}

C_noret_decl(trf_5969)
static void C_fcall trf_5969(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5969(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5969(t0,t1);}

C_noret_decl(trf_5936)
static void C_fcall trf_5936(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5936(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5936(t0,t1);}

C_noret_decl(trf_5890)
static void C_fcall trf_5890(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5890(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5890(t0,t1);}

C_noret_decl(trf_5610)
static void C_fcall trf_5610(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5610(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5610(t0,t1);}

C_noret_decl(trf_5667)
static void C_fcall trf_5667(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5667(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5667(t0,t1,t2,t3);}

C_noret_decl(trf_5425)
static void C_fcall trf_5425(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5425(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5425(t0,t1,t2,t3);}

C_noret_decl(trf_5348)
static void C_fcall trf_5348(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5348(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5348(t0,t1,t2);}

C_noret_decl(trf_5363)
static void C_fcall trf_5363(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5363(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5363(t0,t1,t2,t3);}

C_noret_decl(trf_5379)
static void C_fcall trf_5379(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5379(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5379(t0,t1);}

C_noret_decl(trf_5206)
static void C_fcall trf_5206(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5206(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5206(t0,t1,t2,t3);}

C_noret_decl(trf_5213)
static void C_fcall trf_5213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5213(t0,t1);}

C_noret_decl(trf_5302)
static void C_fcall trf_5302(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5302(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5302(t0,t1);}

C_noret_decl(trf_5012)
static void C_fcall trf_5012(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5012(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5012(t0,t1,t2);}

C_noret_decl(trf_5175)
static void C_fcall trf_5175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5175(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5175(t0,t1,t2,t3);}

C_noret_decl(trf_5089)
static void C_fcall trf_5089(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5089(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5089(t0,t1,t2);}

C_noret_decl(trf_4957)
static void C_fcall trf_4957(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4957(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4957(t0,t1);}

C_noret_decl(trf_4963)
static void C_fcall trf_4963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4963(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4963(t0,t1,t2,t3);}

C_noret_decl(trf_4637)
static void C_fcall trf_4637(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4637(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4637(t0,t1);}

C_noret_decl(trf_4826)
static void C_fcall trf_4826(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4826(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4826(t0,t1,t2);}

C_noret_decl(trf_4834)
static void C_fcall trf_4834(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4834(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4834(t0,t1,t2);}

C_noret_decl(trf_4853)
static void C_fcall trf_4853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4853(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4853(t0,t1);}

C_noret_decl(trf_4856)
static void C_fcall trf_4856(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4856(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4856(t0,t1);}

C_noret_decl(trf_4902)
static void C_fcall trf_4902(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4902(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4902(t0,t1);}

C_noret_decl(trf_4775)
static void C_fcall trf_4775(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4775(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4775(t0,t1,t2);}

C_noret_decl(trf_4783)
static void C_fcall trf_4783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4783(t0,t1,t2);}

C_noret_decl(trf_4676)
static void C_fcall trf_4676(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4676(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4676(t0,t1,t2);}

C_noret_decl(trf_4640)
static void C_fcall trf_4640(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4640(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4640(t0,t1);}

C_noret_decl(trf_4653)
static void C_fcall trf_4653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4653(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4653(t0,t1,t2,t3);}

C_noret_decl(trf_4303)
static void C_fcall trf_4303(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4303(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4303(t0,t1);}

C_noret_decl(trf_4376)
static void C_fcall trf_4376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4376(t0,t1,t2);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4384(t0,t1,t2);}

C_noret_decl(trf_4394)
static void C_fcall trf_4394(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4394(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4394(t0,t1);}

C_noret_decl(trf_4415)
static void C_fcall trf_4415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4415(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4415(t0,t1);}

C_noret_decl(trf_4555)
static void C_fcall trf_4555(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4555(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4555(t0,t1,t2);}

C_noret_decl(trf_4563)
static void C_fcall trf_4563(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4563(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4563(t0,t1,t2);}

C_noret_decl(trf_4480)
static void C_fcall trf_4480(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4480(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4480(t0,t1);}

C_noret_decl(trf_4315)
static void C_fcall trf_4315(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4315(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4315(t0,t1,t2);}

C_noret_decl(trf_4339)
static void C_fcall trf_4339(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4339(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4339(t0,t1,t2);}

C_noret_decl(trf_4132)
static void C_fcall trf_4132(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4132(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4132(t0,t1);}

C_noret_decl(trf_4275)
static void C_fcall trf_4275(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4275(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4275(t0,t1,t2);}

C_noret_decl(trf_4153)
static void C_fcall trf_4153(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4153(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4153(t0,t1,t2,t3);}

C_noret_decl(trf_4222)
static void C_fcall trf_4222(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4222(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4222(t0,t1,t2);}

C_noret_decl(trf_4195)
static void C_fcall trf_4195(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4195(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4195(t0,t1,t2);}

C_noret_decl(trf_3963)
static void C_fcall trf_3963(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3963(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3963(t0,t1);}

C_noret_decl(trf_4036)
static void C_fcall trf_4036(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4036(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4036(t0,t1,t2);}

C_noret_decl(trf_3966)
static void C_fcall trf_3966(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3966(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3966(t0,t1);}

C_noret_decl(trf_2058)
static void C_fcall trf_2058(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2058(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2058(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3931)
static void C_fcall trf_3931(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3931(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3931(t0,t1,t2,t3);}

C_noret_decl(trf_2061)
static void C_fcall trf_2061(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2061(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2061(t0,t1,t2,t3);}

C_noret_decl(trf_3823)
static void C_fcall trf_3823(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3823(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3823(t0,t1,t2,t3);}

C_noret_decl(trf_3358)
static void C_fcall trf_3358(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3358(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3358(t0,t1,t2,t3);}

C_noret_decl(trf_3366)
static void C_fcall trf_3366(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3366(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3366(t0,t1,t2,t3);}

C_noret_decl(trf_3316)
static void C_fcall trf_3316(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3316(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3316(t0,t1,t2,t3);}

C_noret_decl(trf_2818)
static void C_fcall trf_2818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2818(t0,t1);}

C_noret_decl(trf_2824)
static void C_fcall trf_2824(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2824(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2824(t0,t1);}

C_noret_decl(trf_3034)
static void C_fcall trf_3034(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3034(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3034(t0,t1);}

C_noret_decl(trf_3168)
static void C_fcall trf_3168(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3168(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3168(t0,t1);}

C_noret_decl(trf_2935)
static void C_fcall trf_2935(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2935(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2935(t0,t1,t2,t3);}

C_noret_decl(trf_2943)
static void C_fcall trf_2943(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2943(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2943(t0,t1,t2,t3);}

C_noret_decl(trf_2893)
static void C_fcall trf_2893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2893(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2893(t0,t1,t2,t3);}

C_noret_decl(trf_2531)
static void C_fcall trf_2531(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2531(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2531(t0,t1,t2,t3);}

C_noret_decl(trf_2539)
static void C_fcall trf_2539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2539(t0,t1,t2,t3);}

C_noret_decl(trf_2258)
static void C_fcall trf_2258(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2258(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_2258(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2016)
static void C_fcall trf_2016(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2016(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2016(t0,t1,t2);}

C_noret_decl(trf_1981)
static void C_fcall trf_1981(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1981(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1981(t0,t1,t2);}

C_noret_decl(trf_1934)
static void C_fcall trf_1934(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1934(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1934(t0,t1,t2);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_backend_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_backend_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("backend_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(2494)){
C_save(t1);
C_rereclaim2(2494*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,866);
lf[0]=C_h_intern(&lf[0],15,"\010compileroutput");
lf[1]=C_h_intern(&lf[1],12,"\010compilergen");
lf[2]=C_h_intern(&lf[2],7,"newline");
lf[3]=C_h_intern(&lf[3],7,"display");
lf[4]=C_h_intern(&lf[4],17,"\010compilergen-list");
lf[5]=C_h_intern(&lf[5],11,"intersperse");
lf[6]=C_h_intern(&lf[6],18,"\010compilerunique-id");
lf[7]=C_h_intern(&lf[7],22,"\010compilergenerate-code");
lf[8]=C_h_intern(&lf[8],13,"\010compilerbomb");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\021can\047t find lambda");
lf[10]=C_h_intern(&lf[10],17,"lambda-literal-id");
lf[11]=C_h_intern(&lf[11],4,"find");
lf[12]=C_h_intern(&lf[12],14,"\004coreimmediate");
lf[13]=C_h_intern(&lf[13],4,"bool");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[15]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[16]=C_h_intern(&lf[16],4,"char");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\021C_make_character(");
lf[18]=C_h_intern(&lf[18],3,"nil");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_LIST");
lf[20]=C_h_intern(&lf[20],3,"fix");
lf[21]=C_decode_literal(C_heaptop,"\376B\000\000\006C_fix(");
lf[22]=C_h_intern(&lf[22],3,"eof");
lf[23]=C_decode_literal(C_heaptop,"\376B\000\000\024C_SCHEME_END_OF_FILE");
lf[24]=C_decode_literal(C_heaptop,"\376B\000\000\015bad immediate");
lf[25]=C_h_intern(&lf[25],12,"\004coreliteral");
lf[26]=C_decode_literal(C_heaptop,"\376B\000\000\013((C_word)li");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[29]=C_h_intern(&lf[29],2,"if");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[32]=C_decode_literal(C_heaptop,"\376B\000\000\013if(C_truep(");
lf[33]=C_h_intern(&lf[33],9,"\004coreproc");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\010(C_word)");
lf[35]=C_h_intern(&lf[35],9,"\004corebind");
lf[36]=C_h_intern(&lf[36],16,"\004corelet_unboxed");
lf[37]=C_h_intern(&lf[37],8,"\004coreref");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\002)[");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[40]=C_h_intern(&lf[40],10,"\004coreunbox");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\004)[1]");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\012((C_word*)");
lf[43]=C_h_intern(&lf[43],13,"\004coreupdate_i");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[45]=C_h_intern(&lf[45],11,"\004coreupdate");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\002)+");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[49]=C_h_intern(&lf[49],16,"\004coreupdatebox_i");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\021C_set_block_item(");
lf[52]=C_h_intern(&lf[52],14,"\004coreupdatebox");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\004)+1,");
lf[54]=C_decode_literal(C_heaptop,"\376B\000\000\024C_mutate(((C_word *)");
lf[55]=C_h_intern(&lf[55],12,"\004coreclosure");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000\021tmp=(C_word)a,a+=");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\005,tmp)");
lf[58]=C_decode_literal(C_heaptop,"\376B\000\000\002a[");
lf[59]=C_decode_literal(C_heaptop,"\376B\000\000\002]=");
lf[60]=C_h_intern(&lf[60],4,"iota");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\023(*a=C_CLOSURE_TYPE|");
lf[62]=C_h_intern(&lf[62],8,"\004corebox");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\030,tmp=(C_word)a,a+=2,tmp)");
lf[64]=C_decode_literal(C_heaptop,"\376B\000\000\031(*a=C_VECTOR_TYPE|1,a[1]=");
lf[65]=C_h_intern(&lf[65],10,"\004corelocal");
lf[66]=C_h_intern(&lf[66],13,"\004coresetlocal");
lf[67]=C_h_intern(&lf[67],11,"\004coreglobal");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\017C_retrieve2(lf[");
lf[71]=C_decode_literal(C_heaptop,"\376B\000\000\002],");
lf[72]=C_h_intern(&lf[72],21,"\010compilerc-ify-string");
lf[73]=C_h_intern(&lf[73],14,"symbol->string");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fast_retrieve(lf[");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[78]=C_h_intern(&lf[78],14,"\004coresetglobal");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\012 /* (set! ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\011 ...) */,");
lf[81]=C_h_intern(&lf[81],17,"string-translate*");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376B\000\000\002*/\376B\000\000\003* /\376\377\016");
lf[83]=C_h_intern(&lf[83],8,"->string");
lf[84]=C_h_intern(&lf[84],28,"\003syssymbol->qualified-string");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\015C_mutate(&lf[");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mutate((C_word*)lf[");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\003]+1");
lf[89]=C_h_intern(&lf[89],16,"\004coresetglobal_i");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[92]=C_decode_literal(C_heaptop,"\376B\000\000\005 */ =");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\024C_set_block_item(lf[");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\005] /* ");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\006 */,0,");
lf[96]=C_h_intern(&lf[96],14,"\004coreundefined");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\022C_SCHEME_UNDEFINED");
lf[98]=C_h_intern(&lf[98],9,"\004corecall");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\003,0,");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\002c=");
lf[103]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[104]=C_h_intern(&lf[104],26,"lambda-literal-temporaries");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[106]=C_h_intern(&lf[106],22,"lambda-literal-looping");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[108]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[109]=C_h_intern(&lf[109],35,"\010compilerno-global-procedure-checks");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)(");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\005)+1))");
lf[112]=C_h_intern(&lf[112],13,"string-append");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[114]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\030C_retrieve2_symbol_proc(");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\001]");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fast_retrieve_proc(");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[127]=C_decode_literal(C_heaptop,"\376B\000\000\037C_fast_retrieve_symbol_proc(lf[");
lf[128]=C_decode_literal(C_heaptop,"\376B\000\000\002])");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\016*((C_word*)lf[");
lf[130]=C_decode_literal(C_heaptop,"\376B\000\000\004]+1)");
lf[131]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[132]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[133]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[134]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[135]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[136]=C_h_intern(&lf[136],6,"unsafe");
lf[137]=C_decode_literal(C_heaptop,"\376B\000\000\024(void*)(*((C_word*)t");
lf[138]=C_decode_literal(C_heaptop,"\376B\000\000\004+1))");
lf[139]=C_decode_literal(C_heaptop,"\376B\000\000\026C_fast_retrieve_proc(t");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[141]=C_h_intern(&lf[141],28,"\010compilerno-procedure-checks");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\010((C_proc");
lf[143]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[144]=C_h_intern(&lf[144],24,"\010compileremit-trace-info");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\011C_trace(\042");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\003\042);");
lf[147]=C_h_intern(&lf[147],16,"string-translate");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\001\134");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\001/");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[152]=C_h_intern(&lf[152],27,"lambda-literal-closure-size");
lf[153]=C_h_intern(&lf[153],28,"\010compilersource-info->string");
lf[154]=C_h_intern(&lf[154],12,"\004corerecurse");
lf[155]=C_decode_literal(C_heaptop,"\376B\000\000\012goto loop;");
lf[156]=C_decode_literal(C_heaptop,"\376B\000\000\002=t");
lf[157]=C_decode_literal(C_heaptop,"\376B\000\000\003t0,");
lf[158]=C_h_intern(&lf[158],16,"\004coredirect_call");
lf[159]=C_decode_literal(C_heaptop,"\376B\000\000\011C_a_i(&a,");
lf[160]=C_h_intern(&lf[160],13,"\004corecallunit");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel(");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\024,C_SCHEME_UNDEFINED,");
lf[165]=C_h_intern(&lf[165],11,"\004corereturn");
lf[166]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\007return(");
lf[168]=C_h_intern(&lf[168],11,"\004coreinline");
lf[169]=C_h_intern(&lf[169],20,"\004coreinline_allocate");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\004(&a,");
lf[171]=C_h_intern(&lf[171],15,"\004coreinline_ref");
lf[172]=C_h_intern(&lf[172],34,"\010compilerforeign-result-conversion");
lf[173]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[174]=C_h_intern(&lf[174],18,"\004coreinline_update");
lf[175]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[176]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[177]=C_h_intern(&lf[177],36,"\010compilerforeign-argument-conversion");
lf[178]=C_h_intern(&lf[178],33,"\010compilerforeign-type-declaration");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[180]=C_h_intern(&lf[180],19,"\004coreinline_loc_ref");
lf[181]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[182]=C_decode_literal(C_heaptop,"\376B\000\000\003*((");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[185]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[186]=C_h_intern(&lf[186],22,"\004coreinline_loc_update");
lf[187]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[188]=C_decode_literal(C_heaptop,"\376B\000\000\003))=");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\004((*(");
lf[190]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_data_pointer(");
lf[191]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[192]=C_h_intern(&lf[192],16,"\004coreunboxed_ref");
lf[193]=C_h_intern(&lf[193],17,"\004coreunboxed_set!");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\025),C_SCHEME_UNDEFINED)");
lf[195]=C_decode_literal(C_heaptop,"\376B\000\000\002((");
lf[196]=C_h_intern(&lf[196],19,"\004coreinline_unboxed");
lf[197]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[198]=C_h_intern(&lf[198],11,"\004coreswitch");
lf[199]=C_decode_literal(C_heaptop,"\376B\000\000\010default:");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\005case ");
lf[201]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\007switch(");
lf[203]=C_h_intern(&lf[203],9,"\004corecond");
lf[204]=C_decode_literal(C_heaptop,"\376B\000\000\002)\077");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\011(C_truep(");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\010bad form");
lf[207]=C_h_intern(&lf[207],13,"pair-for-each");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[209]=C_h_intern(&lf[209],30,"\010compilerexternal-protos-first");
lf[210]=C_h_intern(&lf[210],50,"\010compilergenerate-foreign-callback-stub-prototypes");
lf[211]=C_h_intern(&lf[211],22,"foreign-callback-stubs");
lf[212]=C_h_intern(&lf[212],29,"\010compilerforeign-declarations");
lf[213]=C_decode_literal(C_heaptop,"\376B\000\000\002*/");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\012#include \042");
lf[215]=C_h_intern(&lf[215],28,"\010compilertarget-include-file");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[217]=C_h_intern(&lf[217],18,"\010compilerunit-name");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\011   unit: ");
lf[219]=C_h_intern(&lf[219],19,"\010compilerused-units");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\017   used units: ");
lf[221]=C_h_intern(&lf[221],27,"\010compilercompiler-arguments");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\022/* Generated from ");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\030 by the CHICKEN compiler");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\0000   http://www.call-with-current-continuation.org");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\021   command line: ");
lf[227]=C_h_intern(&lf[227],18,"string-intersperse");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\003   ");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[231]=C_h_intern(&lf[231],7,"\003sysmap");
lf[232]=C_h_intern(&lf[232],12,"string-split");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[234]=C_h_intern(&lf[234],15,"chicken-version");
lf[235]=C_h_intern(&lf[235],18,"\003sysdecode-seconds");
lf[236]=C_h_intern(&lf[236],15,"current-seconds");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\002};");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\002,0");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_char C_TLS li");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\026[] C_aligned={C_lihdr(");
lf[241]=C_h_intern(&lf[241],23,"\003syslambda-info->string");
lf[242]=C_decode_literal(C_heaptop,"\376B\000\000)static double C_possibly_force_alignment;");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\027static C_TLS C_word lf[");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\002];");
lf[245]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[246]=C_decode_literal(C_heaptop,"\376B\000\000\012_toplevel)");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\036C_externimport void C_ccall C_");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000._toplevel(C_word c,C_word d,C_word k) C_noret;");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000+static C_PTABLE_ENTRY *create_ptable(void);");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[251]=C_h_intern(&lf[251],9,"make-list");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\007,C_word");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\025typedef void (*C_proc");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\010)(C_word");
lf[255]=C_h_intern(&lf[255],4,"none");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\016,...) C_noret;");
lf[263]=C_decode_literal(C_heaptop,"\376B\000\000\010 C_noret");
lf[264]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[265]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[266]=C_h_intern(&lf[266],8,"toplevel");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[268]=C_decode_literal(C_heaptop,"\376B\000\000\034C_externexport void C_ccall ");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(C_");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[273]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[279]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[280]=C_h_intern(&lf[280],21,"small-parameter-limit");
lf[281]=C_h_intern(&lf[281],11,"lset-adjoin");
lf[282]=C_h_intern(&lf[282],1,"=");
lf[283]=C_h_intern(&lf[283],32,"lambda-literal-callee-signatures");
lf[284]=C_h_intern(&lf[284],24,"lambda-literal-allocated");
lf[285]=C_h_intern(&lf[285],21,"lambda-literal-direct");
lf[286]=C_h_intern(&lf[286],33,"lambda-literal-rest-argument-mode");
lf[287]=C_h_intern(&lf[287],28,"lambda-literal-rest-argument");
lf[288]=C_h_intern(&lf[288],27,"\010compilermake-variable-list");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[290]=C_h_intern(&lf[290],27,"lambda-literal-customizable");
lf[291]=C_h_intern(&lf[291],29,"lambda-literal-argument-count");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\020C_adjust_stack(-");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\010=C_pick(");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[298]=C_h_intern(&lf[298],27,"\010compilermake-argument-list");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\006(a,n);");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\007_vector");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\017=C_restore_rest");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n+1);");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\017a=C_alloc(n*3);");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\022n=C_rest_count(0);");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\006int n;");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word *a,t");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[319]=C_h_intern(&lf[319],12,"\003sysfor-each");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\004(k)(");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\004 k){");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\007(C_proc");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\026 k) C_regparm C_noret;");
lf[331]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[332]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[333]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static void C_fcall tr");
lf[334]=C_decode_literal(C_heaptop,"\376B\000\000\016(void *dummy){");
lf[335]=C_decode_literal(C_heaptop,"\376B\000\000\017C_noret_decl(tr");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\026static void C_fcall tr");
lf[338]=C_decode_literal(C_heaptop,"\376B\000\000 (void *dummy) C_regparm C_noret;");
lf[339]=C_h_intern(&lf[339],23,"lambda-literal-external");
lf[340]=C_h_intern(&lf[340],17,"get-output-string");
lf[341]=C_h_intern(&lf[341],19,"\003syswrite-char/port");
lf[342]=C_h_intern(&lf[342],5,"write");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\003lf[");
lf[344]=C_h_intern(&lf[344],18,"open-output-string");
lf[345]=C_h_intern(&lf[345],25,"\010compilerwords-per-flonum");
lf[346]=C_h_intern(&lf[346],6,"reduce");
lf[347]=C_h_intern(&lf[347],1,"+");
lf[348]=C_h_intern(&lf[348],12,"vector->list");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\035type of literal not supported");
lf[350]=C_h_intern(&lf[350],14,"\010compilerwords");
lf[351]=C_h_intern(&lf[351],15,"\003sysbytevector\077");
lf[352]=C_h_intern(&lf[352],32,"\010compilerblock-variable-literal\077");
lf[353]=C_h_intern(&lf[353],19,"\010compilerimmediate\077");
lf[354]=C_decode_literal(C_heaptop,"\376B\000\000\007=C_fix(");
lf[355]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[356]=C_h_intern(&lf[356],19,"\003sysundefined-value");
lf[357]=C_decode_literal(C_heaptop,"\376B\000\000\024=C_SCHEME_UNDEFINED;");
lf[358]=C_decode_literal(C_heaptop,"\376B\000\000\015C_SCHEME_TRUE");
lf[359]=C_decode_literal(C_heaptop,"\376B\000\000\016C_SCHEME_FALSE");
lf[360]=C_decode_literal(C_heaptop,"\376B\000\000\022=C_make_character(");
lf[361]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[362]=C_decode_literal(C_heaptop,"\376B\000\000\014C_h_intern(&");
lf[363]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[364]=C_decode_literal(C_heaptop,"\376B\000\000\001=");
lf[365]=C_decode_literal(C_heaptop,"\376B\000\000\026=C_SCHEME_END_OF_LIST;");
lf[366]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[367]=C_h_intern(&lf[367],23,"\010compilerencode-literal");
lf[368]=C_decode_literal(C_heaptop,"\376B\000\000\034=C_decode_literal(C_heaptop,");
lf[369]=C_h_intern(&lf[369],20,"\010compilerbig-fixnum\077");
lf[370]=C_h_intern(&lf[370],6,"modulo");
lf[371]=C_h_intern(&lf[371],3,"fx/");
lf[372]=C_h_intern(&lf[372],14,"\003syscopy-bytes");
lf[373]=C_h_intern(&lf[373],11,"make-string");
lf[374]=C_h_intern(&lf[374],19,"lambda-literal-body");
lf[375]=C_decode_literal(C_heaptop,"\376B\000\000\022C_word *a=C_alloc(");
lf[376]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[377]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[378]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[379]=C_decode_literal(C_heaptop,"\376B\000\000\011,C_word t");
lf[380]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[381]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[382]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[383]=C_decode_literal(C_heaptop,"\376B\000\000\002,t");
lf[384]=C_decode_literal(C_heaptop,"\376B\000\000\004);}}");
lf[385]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[386]=C_decode_literal(C_heaptop,"\376B\000\000\002r(");
lf[387]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[388]=C_decode_literal(C_heaptop,"\376B\000\000#=C_restore_rest(a,C_rest_count(0));");
lf[389]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[390]=C_decode_literal(C_heaptop,"\376B\000\000\005else{");
lf[391]=C_decode_literal(C_heaptop,"\376B\000\000\015a=C_alloc((c-");
lf[392]=C_decode_literal(C_heaptop,"\376B\000\000\005)*3);");
lf[393]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[394]=C_decode_literal(C_heaptop,"\376B\000\000\001r");
lf[395]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[396]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[397]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[398]=C_decode_literal(C_heaptop,"\376B\000\000\003);}");
lf[399]=C_decode_literal(C_heaptop,"\376B\000\000\005,NULL");
lf[400]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[401]=C_decode_literal(C_heaptop,"\376B\000\000\022C_save_and_reclaim");
lf[402]=C_decode_literal(C_heaptop,"\376B\000\000\012((void*)tr");
lf[403]=C_decode_literal(C_heaptop,"\376B\000\000\011C_reclaim");
lf[404]=C_decode_literal(C_heaptop,"\376B\000\000\022C_register_lf2(lf,");
lf[405]=C_decode_literal(C_heaptop,"\376B\000\000\022,create_ptable());");
lf[406]=C_decode_literal(C_heaptop,"\376B\000\000\023C_initialize_lf(lf,");
lf[407]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[408]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[410]=C_decode_literal(C_heaptop,"\376B\000\000\017if(!C_demand_2(");
lf[411]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[412]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\015C_rereclaim2(");
lf[414]=C_decode_literal(C_heaptop,"\376B\000\000\024*sizeof(C_word), 1);");
lf[415]=C_decode_literal(C_heaptop,"\376B\000\000\016t1=C_restore;}");
lf[416]=C_decode_literal(C_heaptop,"\376B\000\000\030C_check_nursery_minimum(");
lf[417]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[418]=C_decode_literal(C_heaptop,"\376B\000\000\015if(!C_demand(");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[420]=C_decode_literal(C_heaptop,"\376B\000\000\013C_save(t1);");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\000,C_reclaim((void*)toplevel_trampoline,NULL);}");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\027toplevel_initialized=1;");
lf[423]=C_h_intern(&lf[423],26,"\010compilertarget-stack-size");
lf[424]=C_decode_literal(C_heaptop,"\376B\000\000\017C_resize_stack(");
lf[425]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[426]=C_h_intern(&lf[426],30,"\010compilertarget-heap-shrinkage");
lf[427]=C_decode_literal(C_heaptop,"\376B\000\000\021C_heap_shrinkage=");
lf[428]=C_h_intern(&lf[428],27,"\010compilertarget-heap-growth");
lf[429]=C_decode_literal(C_heaptop,"\376B\000\000\016C_heap_growth=");
lf[430]=C_h_intern(&lf[430],33,"\010compilertarget-initial-heap-size");
lf[431]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[432]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[433]=C_h_intern(&lf[433],25,"\010compilertarget-heap-size");
lf[434]=C_decode_literal(C_heaptop,"\376B\000\000\032C_set_or_change_heap_size(");
lf[435]=C_decode_literal(C_heaptop,"\376B\000\000\004,1);");
lf[436]=C_decode_literal(C_heaptop,"\376B\000\000\027C_heap_size_is_fixed=1;");
lf[437]=C_h_intern(&lf[437],40,"\010compilerdisable-stack-overflow-checking");
lf[438]=C_decode_literal(C_heaptop,"\376B\000\000\033C_disable_overflow_check=1;");
lf[439]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[440]=C_decode_literal(C_heaptop,"\376B\000\000;if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);");
lf[441]=C_decode_literal(C_heaptop,"\376B\000\000\036else C_toplevel_entry(C_text(\042");
lf[442]=C_decode_literal(C_heaptop,"\376B\000\000\004\042));");
lf[443]=C_h_intern(&lf[443],4,"fold");
lf[444]=C_decode_literal(C_heaptop,"\376B\000\000\035if(!C_demand(c*C_SIZEOF_PAIR+");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\003)){");
lf[446]=C_h_intern(&lf[446],28,"\010compilerinsert-timer-checks");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[448]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[449]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[450]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[451]=C_h_intern(&lf[451],23,"\010compilerno-argc-checks");
lf[452]=C_decode_literal(C_heaptop,"\376B\000\000\004,c2,");
lf[453]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[454]=C_decode_literal(C_heaptop,"\376B\000\000\001c");
lf[455]=C_decode_literal(C_heaptop,"\376B\000\000\014C_save_rest(");
lf[456]=C_decode_literal(C_heaptop,"\376B\000\000\017C_word *a,c2=c;");
lf[457]=C_decode_literal(C_heaptop,"\376B\000\000\012va_list v;");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\026if(!C_stack_probe(a)){");
lf[459]=C_decode_literal(C_heaptop,"\376B\000\000\027if(!C_stack_probe(&a)){");
lf[460]=C_decode_literal(C_heaptop,"\376B\000\000\026C_check_for_interrupt;");
lf[461]=C_decode_literal(C_heaptop,"\376B\000\000\005if(c<");
lf[462]=C_decode_literal(C_heaptop,"\376B\000\000\025) C_bad_min_argc_2(c,");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\006if(c!=");
lf[465]=C_decode_literal(C_heaptop,"\376B\000\000\021) C_bad_argc_2(c,");
lf[466]=C_decode_literal(C_heaptop,"\376B\000\000\005,t0);");
lf[467]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[468]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[469]=C_decode_literal(C_heaptop,"\376B\000\000\012a=C_alloc(");
lf[470]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[471]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word ab[");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\010],*a=ab;");
lf[473]=C_decode_literal(C_heaptop,"\376B\000\000\005loop:");
lf[474]=C_decode_literal(C_heaptop,"\376B\000\000\016C_stack_check;");
lf[475]=C_decode_literal(C_heaptop,"\376B\000\000\012C_word *a;");
lf[476]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[477]=C_h_intern(&lf[477],6,"fixnum");
lf[478]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[479]=C_h_intern(&lf[479],6,"flonum");
lf[480]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000\004char");
lf[482]=C_h_intern(&lf[482],7,"pointer");
lf[483]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[484]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[485]=C_decode_literal(C_heaptop,"\376B\000\000\024invalid unboxed type");
lf[486]=C_decode_literal(C_heaptop,"\376B\000\000\010C_word t");
lf[487]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word tmp;");
lf[488]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[489]=C_decode_literal(C_heaptop,"\376B\000\000\004,...");
lf[490]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word *a");
lf[491]=C_decode_literal(C_heaptop,"\376B\000\000\011C_word c,");
lf[492]=C_decode_literal(C_heaptop,"\376B\000\000!C_noret_decl(toplevel_trampoline)");
lf[493]=C_decode_literal(C_heaptop,"\376B\000\000Gstatic void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;");
lf[494]=C_decode_literal(C_heaptop,"\376B\000\000\077C_regparm static void C_fcall toplevel_trampoline(void *dummy){");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\042(2,C_SCHEME_UNDEFINED,C_restore);}");
lf[497]=C_decode_literal(C_heaptop,"\376B\000\000\017void C_ccall C_");
lf[498]=C_decode_literal(C_heaptop,"\376B\000\000\022C_main_entry_point");
lf[499]=C_decode_literal(C_heaptop,"\376B\000\000(static C_TLS int toplevel_initialized=0;");
lf[500]=C_decode_literal(C_heaptop,"\376B\000\000\010C_fcall ");
lf[501]=C_decode_literal(C_heaptop,"\376B\000\000\010C_ccall ");
lf[502]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[503]=C_decode_literal(C_heaptop,"\376B\000\000\005void ");
lf[504]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[505]=C_decode_literal(C_heaptop,"\376B\000\000\003/* ");
lf[506]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[507]=C_h_intern(&lf[507],16,"\010compilercleanup");
lf[508]=C_h_intern(&lf[508],18,"\010compilerdebugging");
lf[509]=C_h_intern(&lf[509],1,"o");
lf[510]=C_decode_literal(C_heaptop,"\376B\000\000 dropping unused closure argument");
lf[511]=C_decode_literal(C_heaptop,"\376B\000\000\011_toplevel");
lf[512]=C_decode_literal(C_heaptop,"\376B\000\000\010toplevel");
lf[513]=C_h_intern(&lf[513],34,"lambda-literal-unboxed-temporaries");
lf[514]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[515]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[516]=C_h_intern(&lf[516],18,"\010compilerreal-name");
lf[517]=C_decode_literal(C_heaptop,"\376B\000\000\021/* end of file */");
lf[518]=C_h_intern(&lf[518],25,"emit-procedure-table-info");
lf[519]=C_h_intern(&lf[519],31,"generate-foreign-callback-stubs");
lf[520]=C_h_intern(&lf[520],31,"\010compilergenerate-foreign-stubs");
lf[521]=C_h_intern(&lf[521],29,"\010compilerforeign-lambda-stubs");
lf[522]=C_h_intern(&lf[522],36,"\010compilergenerate-external-variables");
lf[523]=C_h_intern(&lf[523],27,"\010compilerexternal-variables");
lf[524]=C_h_intern(&lf[524],1,"p");
lf[525]=C_decode_literal(C_heaptop,"\376B\000\000\030code generation phase...");
lf[526]=C_decode_literal(C_heaptop,"\376B\000\000\001{");
lf[527]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[528]=C_decode_literal(C_heaptop,"\376B\000\000\016return ptable;");
lf[529]=C_decode_literal(C_heaptop,"\376B\000\000\005#else");
lf[530]=C_decode_literal(C_heaptop,"\376B\000\000\014return NULL;");
lf[531]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[532]=C_decode_literal(C_heaptop,"\376B\000\000\001}");
lf[533]=C_decode_literal(C_heaptop,"\376B\000\000*static C_PTABLE_ENTRY *create_ptable(void)");
lf[534]=C_decode_literal(C_heaptop,"\376B\000\000\006#endif");
lf[535]=C_decode_literal(C_heaptop,"\376B\000\000\015{NULL,NULL}};");
lf[536]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
lf[537]=C_decode_literal(C_heaptop,"\376B\000\000\013_toplevel},");
lf[538]=C_decode_literal(C_heaptop,"\376B\000\000\014C_toplevel},");
lf[539]=C_decode_literal(C_heaptop,"\376B\000\000\002},");
lf[540]=C_decode_literal(C_heaptop,"\376B\000\000\002{\042");
lf[541]=C_decode_literal(C_heaptop,"\376B\000\000\011\042,(void*)");
lf[542]=C_h_intern(&lf[542],29,"\010compilerstring->c-identifier");
lf[543]=C_decode_literal(C_heaptop,"\376B\000\000\027#ifdef C_ENABLE_PTABLES");
lf[544]=C_decode_literal(C_heaptop,"\376B\000\000\035static C_PTABLE_ENTRY ptable[");
lf[545]=C_decode_literal(C_heaptop,"\376B\000\000\005] = {");
lf[546]=C_h_intern(&lf[546],11,"string-copy");
lf[547]=C_decode_literal(C_heaptop,"\376B\000\000\007C_word ");
lf[548]=C_h_intern(&lf[548],13,"list-tabulate");
lf[549]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[550]=C_decode_literal(C_heaptop,"\376B\000\000\007static ");
lf[551]=C_h_intern(&lf[551],41,"\010compilergenerate-foreign-callback-header");
lf[552]=C_decode_literal(C_heaptop,"\376B\000\000\017C_externexport ");
lf[553]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[554]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[555]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[556]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[557]=C_decode_literal(C_heaptop,"\376B\000\000\015#undef return");
lf[558]=C_decode_literal(C_heaptop,"\376B\000\000\006C_ret:");
lf[559]=C_decode_literal(C_heaptop,"\376B\000\000.C_k=C_restore_callback_continuation2(C_level);");
lf[560]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[561]=C_decode_literal(C_heaptop,"\376B\000\000\024C_kontinue(C_k,C_r);");
lf[562]=C_decode_literal(C_heaptop,"\376B\000\000\013return C_r;");
lf[563]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[564]=C_h_intern(&lf[564],4,"void");
lf[565]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[566]=C_decode_literal(C_heaptop,"\376B\000\000\004C_r=");
lf[567]=C_decode_literal(C_heaptop,"\376B\000\0003int C_level=C_save_callback_continuation(&C_a,C_k);");
lf[568]=C_decode_literal(C_heaptop,"\376B\000\000\002=(");
lf[569]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[570]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[571]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[572]=C_decode_literal(C_heaptop,"\376B\000\0002C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;");
lf[573]=C_decode_literal(C_heaptop,"\376B\000\000\002){");
lf[574]=C_decode_literal(C_heaptop,"\376B\000\000\012) C_noret;");
lf[575]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[576]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[577]=C_decode_literal(C_heaptop,"\376B\000\000\014) C_regparm;");
lf[578]=C_decode_literal(C_heaptop,"\376B\000\000 C_regparm static C_word C_fcall ");
lf[579]=C_decode_literal(C_heaptop,"\376B\000\000\015C_noret_decl(");
lf[580]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[581]=C_decode_literal(C_heaptop,"\376B\000\000\024static void C_ccall ");
lf[582]=C_decode_literal(C_heaptop,"\376B\000\000%(C_word C_c,C_word C_self,C_word C_k,");
lf[583]=C_decode_literal(C_heaptop,"\376B\000\000\026static C_word C_fcall ");
lf[584]=C_decode_literal(C_heaptop,"\376B\000\000\042#define return(x) C_cblock C_r = (");
lf[585]=C_decode_literal(C_heaptop,"\376B\000\000\036(x))); goto C_ret; C_cblockend");
lf[586]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[587]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[588]=C_h_intern(&lf[588],21,"foreign-stub-callback");
lf[589]=C_h_intern(&lf[589],16,"foreign-stub-cps");
lf[590]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[591]=C_h_intern(&lf[591],27,"foreign-stub-argument-names");
lf[592]=C_h_intern(&lf[592],17,"foreign-stub-body");
lf[593]=C_h_intern(&lf[593],17,"foreign-stub-name");
lf[594]=C_h_intern(&lf[594],24,"foreign-stub-return-type");
lf[595]=C_decode_literal(C_heaptop,"\376B\000\000\014C_word C_buf");
lf[596]=C_decode_literal(C_heaptop,"\376B\000\000\003C_a");
lf[597]=C_h_intern(&lf[597],27,"foreign-stub-argument-types");
lf[598]=C_h_intern(&lf[598],19,"\010compilerreal-name2");
lf[599]=C_h_intern(&lf[599],15,"foreign-stub-id");
lf[600]=C_h_intern(&lf[600],5,"float");
lf[601]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[602]=C_h_intern(&lf[602],8,"c-string");
lf[603]=C_decode_literal(C_heaptop,"\376B\000\000\004+2+(");
lf[604]=C_decode_literal(C_heaptop,"\376B\000\000!==NULL\0771:C_bytestowords(C_strlen(");
lf[605]=C_decode_literal(C_heaptop,"\376B\000\000\003)))");
lf[606]=C_h_intern(&lf[606],16,"nonnull-c-string");
lf[607]=C_decode_literal(C_heaptop,"\376B\000\000\033+2+C_bytestowords(C_strlen(");
lf[608]=C_decode_literal(C_heaptop,"\376B\000\000\002))");
lf[609]=C_h_intern(&lf[609],3,"ref");
lf[610]=C_decode_literal(C_heaptop,"\376B\000\000\002+3");
lf[611]=C_h_intern(&lf[611],5,"const");
lf[612]=C_h_intern(&lf[612],9,"c-pointer");
lf[613]=C_h_intern(&lf[613],15,"nonnull-pointer");
lf[614]=C_h_intern(&lf[614],17,"nonnull-c-pointer");
lf[615]=C_h_intern(&lf[615],8,"function");
lf[616]=C_h_intern(&lf[616],8,"instance");
lf[617]=C_h_intern(&lf[617],16,"nonnull-instance");
lf[618]=C_h_intern(&lf[618],12,"instance-ref");
lf[619]=C_h_intern(&lf[619],18,"\003syshash-table-ref");
lf[620]=C_h_intern(&lf[620],27,"\010compilerforeign-type-table");
lf[621]=C_h_intern(&lf[621],17,"nonnull-c-string*");
lf[622]=C_h_intern(&lf[622],25,"nonnull-unsigned-c-string");
lf[623]=C_h_intern(&lf[623],26,"nonnull-unsigned-c-string*");
lf[624]=C_h_intern(&lf[624],6,"symbol");
lf[625]=C_h_intern(&lf[625],9,"c-string*");
lf[626]=C_h_intern(&lf[626],17,"unsigned-c-string");
lf[627]=C_h_intern(&lf[627],18,"unsigned-c-string*");
lf[628]=C_h_intern(&lf[628],6,"double");
lf[629]=C_h_intern(&lf[629],16,"unsigned-integer");
lf[630]=C_h_intern(&lf[630],18,"unsigned-integer32");
lf[631]=C_h_intern(&lf[631],4,"long");
lf[632]=C_h_intern(&lf[632],7,"integer");
lf[633]=C_h_intern(&lf[633],9,"integer32");
lf[634]=C_h_intern(&lf[634],13,"unsigned-long");
lf[635]=C_h_intern(&lf[635],6,"number");
lf[636]=C_h_intern(&lf[636],9,"integer64");
lf[637]=C_h_intern(&lf[637],13,"c-string-list");
lf[638]=C_h_intern(&lf[638],14,"c-string-list*");
lf[639]=C_h_intern(&lf[639],3,"int");
lf[640]=C_h_intern(&lf[640],5,"int32");
lf[641]=C_h_intern(&lf[641],5,"short");
lf[642]=C_h_intern(&lf[642],14,"unsigned-short");
lf[643]=C_h_intern(&lf[643],13,"scheme-object");
lf[644]=C_h_intern(&lf[644],13,"unsigned-char");
lf[645]=C_h_intern(&lf[645],12,"unsigned-int");
lf[646]=C_h_intern(&lf[646],14,"unsigned-int32");
lf[647]=C_h_intern(&lf[647],4,"byte");
lf[648]=C_h_intern(&lf[648],13,"unsigned-byte");
lf[649]=C_decode_literal(C_heaptop,"\376B\000\000\002;}");
lf[650]=C_decode_literal(C_heaptop,"\376B\000\000\033C_callback_wrapper((void *)");
lf[651]=C_decode_literal(C_heaptop,"\376B\000\000\007return ");
lf[652]=C_decode_literal(C_heaptop,"\376B\000\000\002x=");
lf[653]=C_decode_literal(C_heaptop,"\376B\000\000\002);");
lf[654]=C_decode_literal(C_heaptop,"\376B\000\000\012C_save(x);");
lf[655]=C_decode_literal(C_heaptop,"\376B\000\000\001a");
lf[656]=C_decode_literal(C_heaptop,"\376B\000\000\035C_callback_adjust_stack(a,s);");
lf[657]=C_decode_literal(C_heaptop,"\376B\000\000\013C_word x,s=");
lf[658]=C_decode_literal(C_heaptop,"\376B\000\000\017,*a=C_alloc(s);");
lf[659]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[660]=C_decode_literal(C_heaptop,"\376B\000\000\010/* from ");
lf[661]=C_decode_literal(C_heaptop,"\376B\000\000\003 */");
lf[662]=C_decode_literal(C_heaptop,"\376B\000\000\0010");
lf[663]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[664]=C_h_intern(&lf[664],36,"foreign-callback-stub-argument-types");
lf[665]=C_h_intern(&lf[665],33,"foreign-callback-stub-return-type");
lf[666]=C_h_intern(&lf[666],24,"foreign-callback-stub-id");
lf[667]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[668]=C_decode_literal(C_heaptop,"\376B\000\000\001t");
lf[669]=C_h_intern(&lf[669],32,"foreign-callback-stub-qualifiers");
lf[670]=C_h_intern(&lf[670],26,"foreign-callback-stub-name");
lf[671]=C_h_intern(&lf[671],4,"quit");
lf[672]=C_decode_literal(C_heaptop,"\376B\000\000\031illegal foreign type `~A\047");
lf[673]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[674]=C_decode_literal(C_heaptop,"\376B\000\000\006C_word");
lf[675]=C_decode_literal(C_heaptop,"\376B\000\000\006C_char");
lf[676]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned C_char");
lf[677]=C_decode_literal(C_heaptop,"\376B\000\000\014unsigned int");
lf[678]=C_decode_literal(C_heaptop,"\376B\000\000\005C_u32");
lf[679]=C_decode_literal(C_heaptop,"\376B\000\000\003int");
lf[680]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s32");
lf[681]=C_decode_literal(C_heaptop,"\376B\000\000\005C_s64");
lf[682]=C_decode_literal(C_heaptop,"\376B\000\000\005short");
lf[683]=C_decode_literal(C_heaptop,"\376B\000\000\004long");
lf[684]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned short");
lf[685]=C_decode_literal(C_heaptop,"\376B\000\000\015unsigned long");
lf[686]=C_decode_literal(C_heaptop,"\376B\000\000\005float");
lf[687]=C_decode_literal(C_heaptop,"\376B\000\000\006double");
lf[688]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[689]=C_decode_literal(C_heaptop,"\376B\000\000\006void *");
lf[690]=C_decode_literal(C_heaptop,"\376B\000\000\011C_char **");
lf[691]=C_h_intern(&lf[691],11,"byte-vector");
lf[692]=C_h_intern(&lf[692],19,"nonnull-byte-vector");
lf[693]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[694]=C_h_intern(&lf[694],4,"blob");
lf[695]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[696]=C_h_intern(&lf[696],9,"u16vector");
lf[697]=C_h_intern(&lf[697],17,"nonnull-u16vector");
lf[698]=C_decode_literal(C_heaptop,"\376B\000\000\020unsigned short *");
lf[699]=C_h_intern(&lf[699],8,"s8vector");
lf[700]=C_h_intern(&lf[700],16,"nonnull-s8vector");
lf[701]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[702]=C_h_intern(&lf[702],9,"u32vector");
lf[703]=C_h_intern(&lf[703],17,"nonnull-u32vector");
lf[704]=C_decode_literal(C_heaptop,"\376B\000\000\016unsigned int *");
lf[705]=C_h_intern(&lf[705],9,"s16vector");
lf[706]=C_h_intern(&lf[706],17,"nonnull-s16vector");
lf[707]=C_decode_literal(C_heaptop,"\376B\000\000\007short *");
lf[708]=C_h_intern(&lf[708],9,"s32vector");
lf[709]=C_h_intern(&lf[709],17,"nonnull-s32vector");
lf[710]=C_decode_literal(C_heaptop,"\376B\000\000\005int *");
lf[711]=C_h_intern(&lf[711],9,"f32vector");
lf[712]=C_h_intern(&lf[712],17,"nonnull-f32vector");
lf[713]=C_decode_literal(C_heaptop,"\376B\000\000\007float *");
lf[714]=C_h_intern(&lf[714],9,"f64vector");
lf[715]=C_h_intern(&lf[715],17,"nonnull-f64vector");
lf[716]=C_decode_literal(C_heaptop,"\376B\000\000\010double *");
lf[717]=C_decode_literal(C_heaptop,"\376B\000\000\006char *");
lf[718]=C_decode_literal(C_heaptop,"\376B\000\000\017unsigned char *");
lf[719]=C_decode_literal(C_heaptop,"\376B\000\000\004void");
lf[720]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[721]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[722]=C_decode_literal(C_heaptop,"\376B\000\000\001<");
lf[723]=C_decode_literal(C_heaptop,"\376B\000\000\002> ");
lf[724]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[725]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[726]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[727]=C_decode_literal(C_heaptop,"\376B\000\000\006const ");
lf[728]=C_decode_literal(C_heaptop,"\376B\000\000\007struct ");
lf[729]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[730]=C_decode_literal(C_heaptop,"\376B\000\000\006union ");
lf[731]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[732]=C_decode_literal(C_heaptop,"\376B\000\000\005enum ");
lf[733]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[734]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[735]=C_decode_literal(C_heaptop,"\376B\000\000\001&");
lf[736]=C_decode_literal(C_heaptop,"\376B\000\000\003 (*");
lf[737]=C_decode_literal(C_heaptop,"\376B\000\000\002)(");
lf[738]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[739]=C_decode_literal(C_heaptop,"\376B\000\000\001,");
lf[740]=C_h_intern(&lf[740],3,"...");
lf[741]=C_decode_literal(C_heaptop,"\376B\000\000\003...");
lf[742]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[743]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[744]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[745]=C_h_intern(&lf[745],9,"\003syserror");
lf[746]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[747]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\020nonnull-instance\376\377\016");
lf[748]=C_h_intern(&lf[748],4,"enum");
lf[749]=C_h_intern(&lf[749],5,"union");
lf[750]=C_h_intern(&lf[750],6,"struct");
lf[751]=C_h_intern(&lf[751],8,"template");
lf[752]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007pointer\376\003\000\000\002\376\001\000\000\017nonnull-pointer\376\003\000\000\002\376\001\000\000\011c-pointer\376\003\000\000\002\376\001\000\000\021nonnull-c"
"-pointer\376\377\016");
lf[753]=C_h_intern(&lf[753],12,"nonnull-blob");
lf[754]=C_h_intern(&lf[754],8,"u8vector");
lf[755]=C_h_intern(&lf[755],16,"nonnull-u8vector");
lf[756]=C_h_intern(&lf[756],14,"scheme-pointer");
lf[757]=C_h_intern(&lf[757],22,"nonnull-scheme-pointer");
lf[758]=C_decode_literal(C_heaptop,"\376B\000\000\042illegal foreign argument type `~A\047");
lf[759]=C_decode_literal(C_heaptop,"\376B\000\000\001(");
lf[760]=C_decode_literal(C_heaptop,"\376B\000\000\031C_character_code((C_word)");
lf[761]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[762]=C_decode_literal(C_heaptop,"\376B\000\000\010C_unfix(");
lf[763]=C_decode_literal(C_heaptop,"\376B\000\000\030(unsigned short)C_unfix(");
lf[764]=C_decode_literal(C_heaptop,"\376B\000\000\027C_num_to_unsigned_long(");
lf[765]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_double(");
lf[766]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[767]=C_decode_literal(C_heaptop,"\376B\000\000\017C_num_to_int64(");
lf[768]=C_decode_literal(C_heaptop,"\376B\000\000\016C_num_to_long(");
lf[769]=C_decode_literal(C_heaptop,"\376B\000\000\026C_num_to_unsigned_int(");
lf[770]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[771]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[772]=C_decode_literal(C_heaptop,"\376B\000\000\027C_data_pointer_or_null(");
lf[773]=C_decode_literal(C_heaptop,"\376B\000\000\017C_data_pointer(");
lf[774]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[775]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[776]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[777]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[778]=C_decode_literal(C_heaptop,"\376B\000\000\027C_c_bytevector_or_null(");
lf[779]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_bytevector(");
lf[780]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_u8vector_or_null(");
lf[781]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_u8vector(");
lf[782]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u16vector_or_null(");
lf[783]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u16vector(");
lf[784]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_u32vector_or_null(");
lf[785]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_u32vector(");
lf[786]=C_decode_literal(C_heaptop,"\376B\000\000\025C_c_s8vector_or_null(");
lf[787]=C_decode_literal(C_heaptop,"\376B\000\000\015C_c_s8vector(");
lf[788]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s16vector_or_null(");
lf[789]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s16vector(");
lf[790]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_s32vector_or_null(");
lf[791]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_s32vector(");
lf[792]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f32vector_or_null(");
lf[793]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f32vector(");
lf[794]=C_decode_literal(C_heaptop,"\376B\000\000\026C_c_f64vector_or_null(");
lf[795]=C_decode_literal(C_heaptop,"\376B\000\000\016C_c_f64vector(");
lf[796]=C_decode_literal(C_heaptop,"\376B\000\000\021C_string_or_null(");
lf[797]=C_decode_literal(C_heaptop,"\376B\000\000\013C_c_string(");
lf[798]=C_decode_literal(C_heaptop,"\376B\000\000\010C_truep(");
lf[799]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[800]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[801]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[802]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[803]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[804]=C_decode_literal(C_heaptop,"\376B\000\000\017C_c_pointer_nn(");
lf[805]=C_decode_literal(C_heaptop,"\376B\000\000\024C_c_pointer_or_null(");
lf[806]=C_decode_literal(C_heaptop,"\376B\000\000\015C_num_to_int(");
lf[807]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[808]=C_decode_literal(C_heaptop,"\376B\000\000\020)C_c_pointer_nn(");
lf[809]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[810]=C_decode_literal(C_heaptop,"\376B\000\000\002*(");
lf[811]=C_decode_literal(C_heaptop,"\376B\000\000\021*)C_c_pointer_nn(");
lf[812]=C_decode_literal(C_heaptop,"\376B\000\000 illegal foreign return type `~A\047");
lf[813]=C_decode_literal(C_heaptop,"\376B\000\000\031C_make_character((C_word)");
lf[814]=C_decode_literal(C_heaptop,"\376B\000\000\016C_fix((C_word)");
lf[815]=C_decode_literal(C_heaptop,"\376B\000\000%C_fix(C_MOST_POSITIVE_FIXNUM&(C_word)");
lf[816]=C_decode_literal(C_heaptop,"\376B\000\000\015C_fix((short)");
lf[817]=C_decode_literal(C_heaptop,"\376B\000\000\025C_fix(0xffff&(C_word)");
lf[818]=C_decode_literal(C_heaptop,"\376B\000\000\014C_fix((char)");
lf[819]=C_decode_literal(C_heaptop,"\376B\000\000\023C_fix(0xff&(C_word)");
lf[820]=C_decode_literal(C_heaptop,"\376B\000\000\012C_flonum(&");
lf[821]=C_decode_literal(C_heaptop,"\376B\000\000\012C_number(&");
lf[822]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[823]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[824]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[825]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[826]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[827]=C_decode_literal(C_heaptop,"\376B\000\000\023C_a_double_to_num(&");
lf[828]=C_decode_literal(C_heaptop,"\376B\000\000\027C_unsigned_int_to_num(&");
lf[829]=C_decode_literal(C_heaptop,"\376B\000\000\017C_long_to_num(&");
lf[830]=C_decode_literal(C_heaptop,"\376B\000\000\030C_unsigned_long_to_num(&");
lf[831]=C_decode_literal(C_heaptop,"\376B\000\000\012C_mk_bool(");
lf[832]=C_decode_literal(C_heaptop,"\376B\000\000\011((C_word)");
lf[833]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[834]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[835]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[836]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[837]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[838]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[839]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[840]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[841]=C_decode_literal(C_heaptop,"\376B\000\000\011,(void*)&");
lf[842]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[843]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[844]=C_decode_literal(C_heaptop,"\376B\000\000\025C_mpointer_or_false(&");
lf[845]=C_decode_literal(C_heaptop,"\376B\000\000\010,(void*)");
lf[846]=C_decode_literal(C_heaptop,"\376B\000\000\014C_mpointer(&");
lf[847]=C_decode_literal(C_heaptop,"\376B\000\000\016C_int_to_num(&");
lf[848]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\001");
lf[849]=C_decode_literal(C_heaptop,"\376B\000\000\003\377\006\000");
lf[850]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\012");
lf[851]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\016");
lf[852]=C_decode_literal(C_heaptop,"\376B\000\000\002\377>");
lf[853]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\036");
lf[854]=C_decode_literal(C_heaptop,"\376B\000\000\002\377U");
lf[855]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[856]=C_decode_literal(C_heaptop,"\376B\000\000\002\377\001");
lf[857]=C_decode_literal(C_heaptop,"\376B\000\000\001U");
lf[858]=C_decode_literal(C_heaptop,"\376B\000\000\001\000");
lf[859]=C_decode_literal(C_heaptop,"\376B\000\000\001\001");
lf[860]=C_decode_literal(C_heaptop,"\376B\000\000\037invalid literal - cannot encode");
lf[861]=C_h_intern(&lf[861],17,"\003sysstring-append");
lf[862]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[863]=C_h_intern(&lf[863],5,"cons*");
lf[864]=C_h_intern(&lf[864],6,"random");
lf[865]=C_decode_literal(C_heaptop,"\376B\000\000\002C_");
C_register_lf2(lf,866,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1922,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1920 */
static void C_ccall f_1922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1922,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1925,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1923 in k1920 */
static void C_ccall f_1925(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1925,2,t0,t1);}
t2=C_set_block_item(lf[0] /* output */,0,C_SCHEME_FALSE);
t3=C_mutate((C_word*)lf[1]+1 /* (set! ##compiler#gen ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1928,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[4]+1 /* (set! ##compiler#gen-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1971,tmp=(C_word)a,a+=2,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9737,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
t7=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k9735 in k1923 in k1920 */
static void C_ccall f_9737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9737,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9740,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[865],t1);}

/* k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9740,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9743,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9763,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9767,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:57: random */
t5=*((C_word*)lf[864]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_fix(16777216));}

/* k9765 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* number->string */
C_number_to_string(4,0,((C_word*)t0)[2],t1,C_fix(16));}

/* k9761 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9763(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9746,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k9744 in k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9746,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9749,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9759,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:57: current-seconds */
t4=*((C_word*)lf[236]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k9757 in k9744 in k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9747 in k9744 in k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9749(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9749,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9752,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(95),((C_word*)t0)[2]);}

/* k9750 in k9747 in k9744 in k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9752,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9755,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k9753 in k9750 in k9747 in k9744 in k9741 in k9738 in k9735 in k1923 in k1920 */
static void C_ccall f_9755(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:56: string->c-identifier */
t2=*((C_word*)lf[542]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2009 in k1923 in k1920 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
t2=C_mutate((C_word*)lf[6]+1 /* (set! ##compiler#unique-id ...) */,t1);
t3=C_mutate((C_word*)lf[7]+1 /* (set! ##compiler#generate-code ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2013,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[518]+1 /* (set! emit-procedure-table-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6291,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[507]+1 /* (set! ##compiler#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6368,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[288]+1 /* (set! ##compiler#make-variable-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6457,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[298]+1 /* (set! ##compiler#make-argument-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6473,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[522]+1 /* (set! ##compiler#generate-external-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6489,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[210]+1 /* (set! ##compiler#generate-foreign-callback-stub-prototypes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6543,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[520]+1 /* (set! ##compiler#generate-foreign-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6583,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[519]+1 /* (set! generate-foreign-callback-stubs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6897,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[551]+1 /* (set! ##compiler#generate-foreign-callback-header ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7391,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[178]+1 /* (set! ##compiler#foreign-type-declaration ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7456,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[177]+1 /* (set! ##compiler#foreign-argument-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8340,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[172]+1 /* (set! ##compiler#foreign-result-conversion ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8830,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[367]+1 /* (set! ##compiler#encode-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9437,tmp=(C_word)a,a+=2,tmp));
t17=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,C_SCHEME_UNDEFINED);}

/* ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9437(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9437,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9446,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9499,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=C_eqp(C_SCHEME_TRUE,t2);
if(C_truep(t5)){
t6=t1;
t7=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t8=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,t7,lf[848]);}
else{
t6=C_eqp(C_SCHEME_FALSE,t2);
if(C_truep(t6)){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t9=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[849]);}
else{
if(C_truep(C_charp(t2))){
t7=C_fix(C_character_code(t2));
t8=f_9446(C_a_i(&a,24),t7);
/* c-backend.scm:1394: string-append */
t9=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,lf[850],t8);}
else{
if(C_truep(C_i_nullp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t9=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[851]);}
else{
if(C_truep(C_eofp(t2))){
t7=t1;
t8=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t9=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,t8,lf[852]);}
else{
t7=*((C_word*)lf[356]+1);
t8=C_eqp(t7,t2);
if(C_truep(t8)){
t9=t1;
t10=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t11=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t9,t10,lf[853]);}
else{
if(C_truep(C_fixnump(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9617,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1399: big-fixnum? */
t10=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,t2);}
else{
if(C_truep(C_i_numberp(t2))){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9630,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1408: number->string */
C_number_to_string(3,0,t9,t2);}
else{
if(C_truep(C_i_symbolp(t2))){
t9=C_slot(t2,C_fix(1));
t10=C_i_string_length(t9);
t11=f_9446(C_a_i(&a,24),t10);
/* c-backend.scm:1411: string-append */
t12=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t12+1)))(5,t12,t4,lf[859],t11,t9);}
else{
if(C_truep(C_immp(t2))){
/* c-backend.scm:1416: bomb */
t9=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t4,lf[860],t2);}
else{
if(C_truep(C_byteblockp(t2))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9669,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=t2;
t11=stub1876(C_SCHEME_UNDEFINED,t10);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,1,t12);
t14=t2;
t15=stub1880(C_SCHEME_UNDEFINED,t14);
t16=f_9446(C_a_i(&a,24),t15);
/* c-backend.scm:1419: string-append */
t17=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t9,t13,t16);}
else{
t9=t2;
t10=stub1880(C_SCHEME_UNDEFINED,t9);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9699,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t12=t2;
t13=stub1876(C_SCHEME_UNDEFINED,t12);
t14=C_make_character(C_unfix(t13));
t15=C_a_i_string(&a,1,t14);
t16=f_9446(C_a_i(&a,24),t10);
t17=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9711,a[2]=t16,a[3]=t15,a[4]=t11,tmp=(C_word)a,a+=5,tmp);
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9713,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1429: list-tabulate */
t19=*((C_word*)lf[548]+1);
((C_proc4)(void*)(*((C_word*)t19+1)))(4,t19,t17,t10,t18);}}}}}}}}}}}}

/* a9712 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9713(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9713,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[2],t2);
/* c-backend.scm:1429: encode-literal */
t4=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* k9709 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1426: cons* */
t2=*((C_word*)lf[863]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k9697 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9699(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1425: string-intersperse */
t2=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[862]);}

/* k9667 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1418: ##sys#string-append */
t2=*((C_word*)lf[861]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k9628 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1408: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[857],t1,lf[858]);}

/* k9615 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[33],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9617,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9613,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1406: number->string */
C_number_to_string(3,0,t2,((C_word*)t0)[2]);}
else{
t2=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[2],C_fix(-24));
t3=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[2],C_fix(-16));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_a_i_arithmetic_shift(&a,2,((C_word*)t0)[2],C_fix(-8));
t9=C_a_i_bitwise_and(&a,2,C_fix(255),t8);
t10=C_make_character(C_unfix(t9));
t11=C_a_i_bitwise_and(&a,2,C_fix(255),((C_word*)t0)[2]);
t12=C_make_character(C_unfix(t11));
t13=C_a_i_string(&a,4,t4,t7,t10,t12);
/* c-backend.scm:1400: string-append */
t14=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,((C_word*)t0)[3],lf[856],t13);}}

/* k9611 in k9615 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1406: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[854],t1,lf[855]);}

/* k9497 in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static void C_ccall f_9499(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9499,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_string(&a,1,C_make_character(254));
/* c-backend.scm:1390: string-append */
t4=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,t1);}

/* encode-size in ##compiler#encode-literal in k2009 in k1923 in k1920 */
static C_word C_fcall f_9446(C_word *a,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_stack_check;
t2=C_a_i_arithmetic_shift(&a,2,t1,C_fix(-16));
t3=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
t4=C_make_character(C_unfix(t3));
t5=C_a_i_arithmetic_shift(&a,2,t1,C_fix(-8));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_make_character(C_unfix(t6));
t8=C_a_i_bitwise_and(&a,2,C_fix(255),t1);
t9=C_make_character(C_unfix(t8));
return(C_a_i_string(&a,3,t4,t7,t9));}

/* ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8830(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8830,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8832,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=t2;
t6=C_eqp(t5,lf[16]);
t7=(C_truep(t6)?t6:C_eqp(t5,lf[644]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[813]);}
else{
t8=C_eqp(t5,lf[639]);
t9=(C_truep(t8)?t8:C_eqp(t5,lf[640]));
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[814]);}
else{
t10=C_eqp(t5,lf[645]);
t11=(C_truep(t10)?t10:C_eqp(t5,lf[646]));
if(C_truep(t11)){
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[815]);}
else{
t12=C_eqp(t5,lf[641]);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[816]);}
else{
t13=C_eqp(t5,lf[642]);
if(C_truep(t13)){
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[817]);}
else{
t14=C_eqp(t5,lf[647]);
if(C_truep(t14)){
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[818]);}
else{
t15=C_eqp(t5,lf[648]);
if(C_truep(t15)){
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[819]);}
else{
t16=C_eqp(t5,lf[600]);
t17=(C_truep(t16)?t16:C_eqp(t5,lf[628]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8899,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t19=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,t18);}
else{
t18=C_eqp(t5,lf[635]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8920,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t20=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t19);}
else{
t19=C_eqp(t5,lf[606]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8941,a[2]=t4,a[3]=t2,a[4]=t5,a[5]=t3,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_8941(t21,t19);}
else{
t21=C_eqp(t5,lf[602]);
if(C_truep(t21)){
t22=t20;
f_8941(t22,t21);}
else{
t22=C_eqp(t5,lf[614]);
if(C_truep(t22)){
t23=t20;
f_8941(t23,t22);}
else{
t23=C_eqp(t5,lf[625]);
if(C_truep(t23)){
t24=t20;
f_8941(t24,t23);}
else{
t24=C_eqp(t5,lf[621]);
if(C_truep(t24)){
t25=t20;
f_8941(t25,t24);}
else{
t25=C_eqp(t5,lf[626]);
if(C_truep(t25)){
t26=t20;
f_8941(t26,t25);}
else{
t26=C_eqp(t5,lf[627]);
if(C_truep(t26)){
t27=t20;
f_8941(t27,t26);}
else{
t27=C_eqp(t5,lf[622]);
if(C_truep(t27)){
t28=t20;
f_8941(t28,t27);}
else{
t28=C_eqp(t5,lf[623]);
if(C_truep(t28)){
t29=t20;
f_8941(t29,t28);}
else{
t29=C_eqp(t5,lf[624]);
if(C_truep(t29)){
t30=t20;
f_8941(t30,t29);}
else{
t30=C_eqp(t5,lf[637]);
t31=t20;
f_8941(t31,(C_truep(t30)?t30:C_eqp(t5,lf[638])));}}}}}}}}}}}}}}}}}}}}

/* k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8941,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8944,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t3=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8965,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t4=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[632]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[4],lf[633]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8989,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t6=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[636]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9010,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t7=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[629]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[630]));
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9034,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t9=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[631]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9055,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t10=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[634]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9076,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t11=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[831]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[564]);
t12=(C_truep(t11)?t11:C_eqp(((C_word*)t0)[4],lf[643]));
if(C_truep(t12)){
t13=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[832]);}
else{
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9106,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm:1343: ##sys#hash-table-ref */
t14=*((C_word*)lf[619]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,*((C_word*)lf[620]+1),((C_word*)t0)[3]);}
else{
t14=t13;
f_9106(2,t14,C_SCHEME_FALSE);}}}}}}}}}}}

/* k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9106,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* g17911792 */
t3=t2;
f_9110(t3,((C_word*)t0)[4],t1);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9133,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
t4=t2;
f_9133(t4,C_i_greater_or_equalp(t3,C_fix(2)));}
else{
t3=t2;
f_9133(t3,C_SCHEME_FALSE);}}}

/* k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_9133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9133,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(t2,lf[613]);
t4=(C_truep(t3)?t3:C_eqp(t2,lf[614]));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9148,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t6=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_eqp(t2,lf[609]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t7=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=C_eqp(t2,lf[616]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9190,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t8=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=C_eqp(t2,lf[617]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9211,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t9=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t8=C_eqp(t2,lf[618]);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9232,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t10=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,t9);}
else{
t9=C_eqp(t2,lf[611]);
if(C_truep(t9)){
t10=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:1358: foreign-result-conversion */
t11=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,((C_word*)t0)[4],t10,((C_word*)t0)[3]);}
else{
t10=C_eqp(t2,lf[482]);
t11=(C_truep(t10)?t10:C_eqp(t2,lf[612]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t13=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t12=C_eqp(t2,lf[615]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t14=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}
else{
t13=C_eqp(t2,lf[748]);
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9311,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t15=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
/* c-backend.scm:1363: err */
t14=((C_word*)t0)[2];
f_8832(t14,((C_word*)t0)[4]);}}}}}}}}}}
else{
/* c-backend.scm:1364: err */
t2=((C_word*)t0)[2];
f_8832(t2,((C_word*)t0)[4]);}}

/* k9309 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9314,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[847],t1);}

/* k9312 in k9309 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9317,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9315 in k9312 in k9309 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9317,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9318 in k9315 in k9312 in k9309 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9320(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9288 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9293,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[846],t1);}

/* k9291 in k9288 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9293,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9296,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9294 in k9291 in k9288 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9296(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9296,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9299,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[845],((C_word*)t0)[2]);}

/* k9297 in k9294 in k9291 in k9288 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9267 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9269,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9272,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[844],t1);}

/* k9270 in k9267 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9275,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9273 in k9270 in k9267 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9275,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9278,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[843],((C_word*)t0)[2]);}

/* k9276 in k9273 in k9270 in k9267 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9278(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9230 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9235,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[842],t1);}

/* k9233 in k9230 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9238,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9236 in k9233 in k9230 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9241,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[841],((C_word*)t0)[2]);}

/* k9239 in k9236 in k9233 in k9230 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9209 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9214,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[840],t1);}

/* k9212 in k9209 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9217,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9215 in k9212 in k9209 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[839],((C_word*)t0)[2]);}

/* k9218 in k9215 in k9212 in k9209 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9188 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9193,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[838],t1);}

/* k9191 in k9188 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9194 in k9191 in k9188 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9199,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[837],((C_word*)t0)[2]);}

/* k9197 in k9194 in k9191 in k9188 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9167 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9172,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[836],t1);}

/* k9170 in k9167 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9173 in k9170 in k9167 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[835],((C_word*)t0)[2]);}

/* k9176 in k9173 in k9170 in k9167 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9146 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9148,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9151,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[834],t1);}

/* k9149 in k9146 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9154,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9152 in k9149 in k9146 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9157,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[833],((C_word*)t0)[2]);}

/* k9155 in k9152 in k9149 in k9146 in k9131 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* g1791 in k9104 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_9110(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9110,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1345: foreign-result-conversion */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm:1345: foreign-result-conversion */
t4=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}}

/* k9074 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9076,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9079,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[830],t1);}

/* k9077 in k9074 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9079,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9082,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9080 in k9077 in k9074 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9085,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9083 in k9080 in k9077 in k9074 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9053 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[829],t1);}

/* k9056 in k9053 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9061,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9059 in k9056 in k9053 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9062 in k9059 in k9056 in k9053 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9032 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9037,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[828],t1);}

/* k9035 in k9032 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9037,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9040,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9038 in k9035 in k9032 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9040(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9040,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9043,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9041 in k9038 in k9035 in k9032 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k9008 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9013,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[827],t1);}

/* k9011 in k9008 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9014 in k9011 in k9008 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9019,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k9017 in k9014 in k9011 in k9008 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_9019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8987 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8992,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[826],t1);}

/* k8990 in k8987 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8993 in k8990 in k8987 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8998,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8996 in k8993 in k8990 in k8987 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8963 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8965,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8968,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[825],t1);}

/* k8966 in k8963 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8968,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8971,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8969 in k8966 in k8963 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8971,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8974,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[824],((C_word*)t0)[2]);}

/* k8972 in k8969 in k8966 in k8963 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8942 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8944,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8947,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[823],t1);}

/* k8945 in k8942 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8948 in k8945 in k8942 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8953,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[822],((C_word*)t0)[2]);}

/* k8951 in k8948 in k8945 in k8942 in k8939 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8918 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8920(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8920,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8923,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[821],t1);}

/* k8921 in k8918 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8923(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8923,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8926,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8924 in k8921 in k8918 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8926,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8929,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8927 in k8924 in k8921 in k8918 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8929(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k8897 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8902,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[820],t1);}

/* k8900 in k8897 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k8903 in k8900 in k8897 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(44),((C_word*)t0)[2]);}

/* k8906 in k8903 in k8900 in k8897 in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-result-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8832(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8832,NULL,2,t0,t1);}
/* c-backend.scm:1319: quit */
t2=*((C_word*)lf[671]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[812],((C_word*)t0)[2]);}

/* ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8340(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8340,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8342,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=t2;
t5=C_eqp(t4,lf[643]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[759]);}
else{
t6=C_eqp(t4,lf[16]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[644]));
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[760]);}
else{
t8=C_eqp(t4,lf[647]);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8370,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t8)){
t10=t9;
f_8370(t10,t8);}
else{
t10=C_eqp(t4,lf[639]);
if(C_truep(t10)){
t11=t9;
f_8370(t11,t10);}
else{
t11=C_eqp(t4,lf[645]);
if(C_truep(t11)){
t12=t9;
f_8370(t12,t11);}
else{
t12=C_eqp(t4,lf[646]);
t13=t9;
f_8370(t13,(C_truep(t12)?t12:C_eqp(t4,lf[648])));}}}}}}

/* k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8370(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8370,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[761]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[641]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[762]);}
else{
t3=C_eqp(((C_word*)t0)[4],lf[642]);
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[763]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[634]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[764]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[628]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_8397(t7,t5);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[635]);
t8=t6;
f_8397(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[600])));}}}}}}

/* k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8397(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8397,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[765]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[632]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[633]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[766]);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[636]);
if(C_truep(t4)){
t5=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[767]);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[631]);
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[768]);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[629]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[630]));
if(C_truep(t7)){
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[769]);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[482]);
if(C_truep(t8)){
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[770]);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[613]);
if(C_truep(t9)){
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[771]);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[756]);
if(C_truep(t10)){
t11=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,lf[772]);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[757]);
if(C_truep(t11)){
t12=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[773]);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[612]);
if(C_truep(t12)){
t13=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,lf[774]);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[614]);
if(C_truep(t13)){
t14=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,lf[775]);}
else{
t14=C_eqp(((C_word*)t0)[4],lf[694]);
if(C_truep(t14)){
t15=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,lf[776]);}
else{
t15=C_eqp(((C_word*)t0)[4],lf[753]);
if(C_truep(t15)){
t16=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,lf[777]);}
else{
t16=C_eqp(((C_word*)t0)[4],lf[691]);
if(C_truep(t16)){
t17=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[778]);}
else{
t17=C_eqp(((C_word*)t0)[4],lf[692]);
if(C_truep(t17)){
t18=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[779]);}
else{
t18=C_eqp(((C_word*)t0)[4],lf[754]);
if(C_truep(t18)){
t19=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,lf[780]);}
else{
t19=C_eqp(((C_word*)t0)[4],lf[755]);
if(C_truep(t19)){
t20=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,lf[781]);}
else{
t20=C_eqp(((C_word*)t0)[4],lf[696]);
if(C_truep(t20)){
t21=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,lf[782]);}
else{
t21=C_eqp(((C_word*)t0)[4],lf[697]);
if(C_truep(t21)){
t22=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,lf[783]);}
else{
t22=C_eqp(((C_word*)t0)[4],lf[702]);
if(C_truep(t22)){
t23=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,lf[784]);}
else{
t23=C_eqp(((C_word*)t0)[4],lf[703]);
if(C_truep(t23)){
t24=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t24+1)))(2,t24,lf[785]);}
else{
t24=C_eqp(((C_word*)t0)[4],lf[699]);
if(C_truep(t24)){
t25=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t25+1)))(2,t25,lf[786]);}
else{
t25=C_eqp(((C_word*)t0)[4],lf[700]);
if(C_truep(t25)){
t26=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t26+1)))(2,t26,lf[787]);}
else{
t26=C_eqp(((C_word*)t0)[4],lf[705]);
if(C_truep(t26)){
t27=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t27+1)))(2,t27,lf[788]);}
else{
t27=C_eqp(((C_word*)t0)[4],lf[706]);
if(C_truep(t27)){
t28=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[789]);}
else{
t28=C_eqp(((C_word*)t0)[4],lf[708]);
if(C_truep(t28)){
t29=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t29+1)))(2,t29,lf[790]);}
else{
t29=C_eqp(((C_word*)t0)[4],lf[709]);
if(C_truep(t29)){
t30=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t30+1)))(2,t30,lf[791]);}
else{
t30=C_eqp(((C_word*)t0)[4],lf[711]);
if(C_truep(t30)){
t31=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t31+1)))(2,t31,lf[792]);}
else{
t31=C_eqp(((C_word*)t0)[4],lf[712]);
if(C_truep(t31)){
t32=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t32+1)))(2,t32,lf[793]);}
else{
t32=C_eqp(((C_word*)t0)[4],lf[714]);
if(C_truep(t32)){
t33=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t33+1)))(2,t33,lf[794]);}
else{
t33=C_eqp(((C_word*)t0)[4],lf[715]);
if(C_truep(t33)){
t34=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t34+1)))(2,t34,lf[795]);}
else{
t34=C_eqp(((C_word*)t0)[4],lf[602]);
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t34)){
t36=t35;
f_8592(t36,t34);}
else{
t36=C_eqp(((C_word*)t0)[4],lf[625]);
if(C_truep(t36)){
t37=t35;
f_8592(t37,t36);}
else{
t37=C_eqp(((C_word*)t0)[4],lf[626]);
t38=t35;
f_8592(t38,(C_truep(t37)?t37:C_eqp(((C_word*)t0)[4],lf[627])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k8590 in k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8592(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8592,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[796]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[606]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8601,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_8601(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[621]);
if(C_truep(t4)){
t5=t3;
f_8601(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[622]);
if(C_truep(t5)){
t6=t3;
f_8601(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[623]);
t7=t3;
f_8601(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[624])));}}}}}

/* k8599 in k8590 in k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8601(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8601,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[797]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[13]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[798]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8610,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm:1292: ##sys#hash-table-ref */
t4=*((C_word*)lf[619]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[620]+1),((C_word*)t0)[3]);}
else{
t4=t3;
f_8610(2,t4,C_SCHEME_FALSE);}}}}

/* k8608 in k8599 in k8590 in k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8610,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=t1;
if(C_truep(C_i_vectorp(t3))){
t4=C_i_vector_ref(t3,C_fix(0));
/* c-backend.scm:1294: foreign-argument-conversion */
t5=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t2,t4);}
else{
/* c-backend.scm:1294: foreign-argument-conversion */
t4=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
t4=t2;
f_8637(t4,C_i_greater_or_equalp(t3,C_fix(2)));}
else{
t3=t2;
f_8637(t3,C_SCHEME_FALSE);}}}

/* k8635 in k8608 in k8599 in k8590 in k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8637,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[482]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[799]);}
else{
t4=C_eqp(t2,lf[613]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[800]);}
else{
t5=C_eqp(t2,lf[612]);
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[801]);}
else{
t6=C_eqp(t2,lf[614]);
if(C_truep(t6)){
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[802]);}
else{
t7=C_eqp(t2,lf[616]);
if(C_truep(t7)){
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[803]);}
else{
t8=C_eqp(t2,lf[617]);
if(C_truep(t8)){
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,lf[804]);}
else{
t9=C_eqp(t2,lf[615]);
if(C_truep(t9)){
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,lf[805]);}
else{
t10=C_eqp(t2,lf[611]);
if(C_truep(t10)){
t11=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1305: foreign-argument-conversion */
t12=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,((C_word*)t0)[3],t11);}
else{
t11=C_eqp(t2,lf[748]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,lf[806]);}
else{
t12=C_eqp(t2,lf[609]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8714,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t14=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1308: foreign-type-declaration */
t15=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,lf[809]);}
else{
t13=C_eqp(t2,lf[618]);
if(C_truep(t13)){
t14=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1311: string-append */
t15=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,((C_word*)t0)[3],lf[810],t14,lf[811]);}
else{
/* c-backend.scm:1312: err */
t14=((C_word*)t0)[2];
f_8342(t14,((C_word*)t0)[3]);}}}}}}}}}}}}
else{
/* c-backend.scm:1313: err */
t2=((C_word*)t0)[2];
f_8342(t2,((C_word*)t0)[3]);}}

/* k8712 in k8635 in k8608 in k8599 in k8590 in k8395 in k8368 in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_ccall f_8714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1308: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[807],t1,lf[808]);}

/* err in ##compiler#foreign-argument-conversion in k2009 in k1923 in k1920 */
static void C_fcall f_8342(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8342,NULL,2,t0,t1);}
/* c-backend.scm:1246: quit */
t2=*((C_word*)lf[671]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[758],((C_word*)t0)[2]);}

/* ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7456(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7456,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7458,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7463,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t6=t2;
t7=C_eqp(t6,lf[643]);
if(C_truep(t7)){
/* c-backend.scm:1153: str */
t8=t5;
f_7463(t8,t1,lf[674]);}
else{
t8=C_eqp(t6,lf[16]);
t9=(C_truep(t8)?t8:C_eqp(t6,lf[647]));
if(C_truep(t9)){
/* c-backend.scm:1154: str */
t10=t5;
f_7463(t10,t1,lf[675]);}
else{
t10=C_eqp(t6,lf[644]);
t11=(C_truep(t10)?t10:C_eqp(t6,lf[648]));
if(C_truep(t11)){
/* c-backend.scm:1155: str */
t12=t5;
f_7463(t12,t1,lf[676]);}
else{
t12=C_eqp(t6,lf[645]);
t13=(C_truep(t12)?t12:C_eqp(t6,lf[629]));
if(C_truep(t13)){
/* c-backend.scm:1156: str */
t14=t5;
f_7463(t14,t1,lf[677]);}
else{
t14=C_eqp(t6,lf[646]);
t15=(C_truep(t14)?t14:C_eqp(t6,lf[630]));
if(C_truep(t15)){
/* c-backend.scm:1157: str */
t16=t5;
f_7463(t16,t1,lf[678]);}
else{
t16=C_eqp(t6,lf[639]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7533,a[2]=t4,a[3]=t2,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7533(t18,t16);}
else{
t18=C_eqp(t6,lf[632]);
t19=t17;
f_7533(t19,(C_truep(t18)?t18:C_eqp(t6,lf[13])));}}}}}}}

/* k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7533(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7533,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1158: str */
t2=((C_word*)t0)[7];
f_7463(t2,((C_word*)t0)[6],lf[679]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[640]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[633]));
if(C_truep(t3)){
/* c-backend.scm:1159: str */
t4=((C_word*)t0)[7];
f_7463(t4,((C_word*)t0)[6],lf[680]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[636]);
if(C_truep(t4)){
/* c-backend.scm:1160: str */
t5=((C_word*)t0)[7];
f_7463(t5,((C_word*)t0)[6],lf[681]);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[641]);
if(C_truep(t5)){
/* c-backend.scm:1161: str */
t6=((C_word*)t0)[7];
f_7463(t6,((C_word*)t0)[6],lf[682]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[631]);
if(C_truep(t6)){
/* c-backend.scm:1162: str */
t7=((C_word*)t0)[7];
f_7463(t7,((C_word*)t0)[6],lf[683]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[642]);
if(C_truep(t7)){
/* c-backend.scm:1163: str */
t8=((C_word*)t0)[7];
f_7463(t8,((C_word*)t0)[6],lf[684]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[634]);
if(C_truep(t8)){
/* c-backend.scm:1164: str */
t9=((C_word*)t0)[7];
f_7463(t9,((C_word*)t0)[6],lf[685]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[600]);
if(C_truep(t9)){
/* c-backend.scm:1165: str */
t10=((C_word*)t0)[7];
f_7463(t10,((C_word*)t0)[6],lf[686]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[628]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[5],lf[635]));
if(C_truep(t11)){
/* c-backend.scm:1166: str */
t12=((C_word*)t0)[7];
f_7463(t12,((C_word*)t0)[6],lf[687]);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[482]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[5],lf[613]));
if(C_truep(t13)){
/* c-backend.scm:1168: str */
t14=((C_word*)t0)[7];
f_7463(t14,((C_word*)t0)[6],lf[688]);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[612]);
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7635,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t14)){
t16=t15;
f_7635(t16,t14);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t16)){
t17=t15;
f_7635(t17,t16);}
else{
t17=C_eqp(((C_word*)t0)[5],lf[756]);
t18=t15;
f_7635(t18,(C_truep(t17)?t17:C_eqp(((C_word*)t0)[5],lf[757])));}}}}}}}}}}}}}

/* k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7635(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7635,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1169: str */
t2=((C_word*)t0)[7];
f_7463(t2,((C_word*)t0)[6],lf[689]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[637]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[638]));
if(C_truep(t3)){
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[690]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[691]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[692]));
if(C_truep(t5)){
/* c-backend.scm:1172: str */
t6=((C_word*)t0)[7];
f_7463(t6,((C_word*)t0)[6],lf[693]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[694]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_7668(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[753]);
if(C_truep(t8)){
t9=t7;
f_7668(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[754]);
t10=t7;
f_7668(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[755])));}}}}}}

/* k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7668(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7668,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1173: str */
t2=((C_word*)t0)[7];
f_7463(t2,((C_word*)t0)[6],lf[695]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[696]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[697]));
if(C_truep(t3)){
/* c-backend.scm:1174: str */
t4=((C_word*)t0)[7];
f_7463(t4,((C_word*)t0)[6],lf[698]);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[699]);
t5=(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[700]));
if(C_truep(t5)){
/* c-backend.scm:1175: str */
t6=((C_word*)t0)[7];
f_7463(t6,((C_word*)t0)[6],lf[701]);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[702]);
t7=(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[703]));
if(C_truep(t7)){
/* c-backend.scm:1176: str */
t8=((C_word*)t0)[7];
f_7463(t8,((C_word*)t0)[6],lf[704]);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[705]);
t9=(C_truep(t8)?t8:C_eqp(((C_word*)t0)[5],lf[706]));
if(C_truep(t9)){
/* c-backend.scm:1177: str */
t10=((C_word*)t0)[7];
f_7463(t10,((C_word*)t0)[6],lf[707]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[708]);
t11=(C_truep(t10)?t10:C_eqp(((C_word*)t0)[5],lf[709]));
if(C_truep(t11)){
/* c-backend.scm:1178: str */
t12=((C_word*)t0)[7];
f_7463(t12,((C_word*)t0)[6],lf[710]);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[711]);
t13=(C_truep(t12)?t12:C_eqp(((C_word*)t0)[5],lf[712]));
if(C_truep(t13)){
/* c-backend.scm:1179: str */
t14=((C_word*)t0)[7];
f_7463(t14,((C_word*)t0)[6],lf[713]);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[714]);
t15=(C_truep(t14)?t14:C_eqp(((C_word*)t0)[5],lf[715]));
if(C_truep(t15)){
/* c-backend.scm:1180: str */
t16=((C_word*)t0)[7];
f_7463(t16,((C_word*)t0)[6],lf[716]);}
else{
t16=C_eqp(((C_word*)t0)[5],lf[606]);
t17=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7764,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t16)){
t18=t17;
f_7764(t18,t16);}
else{
t18=C_eqp(((C_word*)t0)[5],lf[602]);
if(C_truep(t18)){
t19=t17;
f_7764(t19,t18);}
else{
t19=C_eqp(((C_word*)t0)[5],lf[621]);
if(C_truep(t19)){
t20=t17;
f_7764(t20,t19);}
else{
t20=C_eqp(((C_word*)t0)[5],lf[625]);
t21=t17;
f_7764(t21,(C_truep(t20)?t20:C_eqp(((C_word*)t0)[5],lf[624])));}}}}}}}}}}}}

/* k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7764(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7764,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1182: str */
t2=((C_word*)t0)[7];
f_7463(t2,((C_word*)t0)[6],lf[717]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[622]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_7776(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[623]);
if(C_truep(t4)){
t5=t3;
f_7776(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[626]);
t6=t3;
f_7776(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[627])));}}}}

/* k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7776(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7776,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1184: str */
t2=((C_word*)t0)[7];
f_7463(t2,((C_word*)t0)[6],lf[718]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[564]);
if(C_truep(t2)){
/* c-backend.scm:1185: str */
t3=((C_word*)t0)[7];
f_7463(t3,((C_word*)t0)[6],lf[719]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7791,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* c-backend.scm:1187: ##sys#hash-table-ref */
t4=*((C_word*)lf[619]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[620]+1),((C_word*)t0)[3]);}
else{
t4=t3;
f_7791(2,t4,C_SCHEME_FALSE);}}}}

/* k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7791,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7795,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* g15151516 */
t3=t2;
f_7795(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[4]))){
/* c-backend.scm:1190: str */
t2=((C_word*)t0)[3];
f_7463(t2,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
if(C_truep(C_i_listp(((C_word*)t0)[4]))){
t2=C_i_length(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7836,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nequalp(C_fix(2),t2))){
t4=C_i_car(((C_word*)t0)[4]);
t5=t3;
f_7836(t5,C_i_memq(t4,lf[752]));}
else{
t4=t3;
f_7836(t4,C_SCHEME_FALSE);}}
else{
/* c-backend.scm:1240: err */
t2=((C_word*)t0)[2];
f_7458(t2,((C_word*)t0)[5]);}}}}

/* k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7836(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7836,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7847,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1197: string-append */
t4=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[720],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_nequalp(C_fix(2),((C_word*)t0)[2]))){
t3=C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7853(t4,C_eqp(lf[609],t3));}
else{
t3=t2;
f_7853(t3,C_SCHEME_FALSE);}}}

/* k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7853,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7864,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1200: string-append */
t4=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[721],((C_word*)t0)[5]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7870,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[7]);
t4=t2;
f_7870(t4,C_eqp(lf[751],t3));}
else{
t3=t2;
f_7870(t3,C_SCHEME_FALSE);}}}

/* k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7870(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7870,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7881,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:1205: foreign-type-declaration */
t5=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[726]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7909,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[5]);
t4=t2;
f_7909(t4,C_eqp(lf[611],t3));}
else{
t3=t2;
f_7909(t3,C_SCHEME_FALSE);}}}

/* k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7909(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7909,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7916,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:1212: foreign-type-declaration */
t4=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7926,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[5]);
t4=t2;
f_7926(t4,C_eqp(lf[750],t3));}
else{
t3=t2;
f_7926(t3,C_SCHEME_FALSE);}}}

/* k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7926(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7926,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7933,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1214: ->string */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7943,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7943(t4,C_eqp(lf[749],t3));}
else{
t3=t2;
f_7943(t3,C_SCHEME_FALSE);}}}

/* k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7943(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7943,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7950,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1216: ->string */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(2)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7960(t4,C_eqp(lf[748],t3));}
else{
t3=t2;
f_7960(t3,C_SCHEME_FALSE);}}}

/* k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7960(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7960,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7967,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1218: ->string */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7977,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7977(t4,C_i_memq(t3,lf[747]));}
else{
t3=t2;
f_7977(t3,C_SCHEME_FALSE);}}}

/* k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7977(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7977,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7984,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1220: ->string */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7994,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_nequalp(((C_word*)t0)[2],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_7994(t4,C_eqp(lf[618],t3));}
else{
t3=t2;
f_7994(t3,C_SCHEME_FALSE);}}}

/* k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7994(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7994,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8001,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1222: ->string */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8011,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greater_or_equalp(((C_word*)t0)[2],C_fix(3)))){
t3=C_i_car(((C_word*)t0)[4]);
t4=t2;
f_8011(t4,C_eqp(lf[615],t3));}
else{
t3=t2;
f_8011(t3,C_SCHEME_FALSE);}}}

/* k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_8011(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8011,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_i_caddr(((C_word*)t0)[5]);
t4=C_i_cdddr(((C_word*)t0)[5]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8023,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_nullp(t4))){
t6=t5;
f_8023(2,t6,lf[744]);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=t5;
f_8023(2,t7,C_i_car(t4));}
else{
/* ##sys#error */
t7=*((C_word*)lf[745]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[746],t4);}}}
else{
/* c-backend.scm:1239: err */
t2=((C_word*)t0)[2];
f_7458(t2,((C_word*)t0)[4]);}}

/* k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8023,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8030,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1228: foreign-type-declaration */
t3=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[743]);}

/* k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8038,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8040,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_8040(t11,t7,((C_word*)t0)[2]);}

/* loop1559 in k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_8040(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8040,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8050,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8080,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_slot(t2,C_fix(0));
t6=C_eqp(lf[740],t5);
if(C_truep(t6)){
t7=t3;
f_8050(t7,C_a_i_cons(&a,2,lf[741],C_SCHEME_END_OF_LIST));}
else{
/* c-backend.scm:1235: foreign-type-declaration */
t7=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,lf[742]);}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8078 in loop1559 in k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8080,2,t0,t1);}
t2=((C_word*)t0)[2];
f_8050(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k8048 in loop1559 in k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_8050(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15591572 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8040(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15591572 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_8040(t5,((C_word*)t0)[3],t4);}}

/* k8036 in k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1231: string-intersperse */
t2=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[739]);}

/* k8032 in k8028 in k8021 in k8009 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1227: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[736],((C_word*)t0)[2],lf[737],t1,lf[738]);}

/* k7999 in k7992 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_8001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1222: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[735],((C_word*)t0)[2]);}

/* k7982 in k7975 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7984(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1220: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],t1,lf[734],((C_word*)t0)[2]);}

/* k7965 in k7958 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7967(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1218: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[732],t1,lf[733],((C_word*)t0)[2]);}

/* k7948 in k7941 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1216: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[730],t1,lf[731],((C_word*)t0)[2]);}

/* k7931 in k7924 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1214: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],lf[728],t1,lf[729],((C_word*)t0)[2]);}

/* k7914 in k7907 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1212: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[727],t1);}

/* k7879 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7881,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7885,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7889,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7891,tmp=(C_word)a,a+=2,tmp);
t5=C_i_cddr(((C_word*)t0)[2]);
/* map */
t6=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}

/* a7890 in k7879 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7891,3,t0,t1,t2);}
t3=*((C_word*)lf[178]+1);
/* g15421543 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[725]);}

/* k7887 in k7879 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7889(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1207: string-intersperse */
t2=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[724]);}

/* k7883 in k7879 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1204: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[722],t1,lf[723]);}

/* k7875 in k7868 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1203: str */
t2=((C_word*)t0)[3];
f_7463(t2,((C_word*)t0)[2],t1);}

/* k7862 in k7851 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1200: foreign-type-declaration */
t2=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7845 in k7834 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_ccall f_7847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1197: foreign-type-declaration */
t2=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* g1515 in k7789 in k7774 in k7762 in k7666 in k7633 in k7531 in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7795(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7795,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1189: foreign-type-declaration */
t4=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm:1189: foreign-type-declaration */
t4=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,((C_word*)t0)[2]);}}

/* str in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7463(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7463,NULL,3,t0,t1,t2);}
/* c-backend.scm:1151: string-append */
t3=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t1,t2,lf[673],((C_word*)t0)[2]);}

/* err in ##compiler#foreign-type-declaration in k2009 in k1923 in k1920 */
static void C_fcall f_7458(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7458,NULL,2,t0,t1);}
/* c-backend.scm:1150: quit */
t2=*((C_word*)lf[671]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[672],((C_word*)t0)[2]);}

/* ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7391(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7391,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7395,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1132: foreign-callback-stub-name */
t5=*((C_word*)lf[670]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}

/* k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7395(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7395,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7398,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1133: foreign-callback-stub-qualifiers */
t3=*((C_word*)lf[669]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7398(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7398,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7401,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1134: foreign-callback-stub-return-type */
t3=*((C_word*)lf[665]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7401,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7404,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1135: foreign-callback-stub-argument-types */
t3=*((C_word*)lf[664]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7404(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7404,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7410,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1137: make-argument-list */
t4=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[668]);}

/* k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7410(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7410,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7413,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1138: foreign-type-declaration */
t4=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[667]);}

/* k7452 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1138: gen */
t2=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t2+1)))(10,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],C_make_character(32),t1,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2],C_make_character(40));}

/* k7411 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7413(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7413,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7416,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7421,tmp=(C_word)a,a+=2,tmp);
/* c-backend.scm:1139: pair-for-each */
t4=*((C_word*)lf[207]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a7420 in k7411 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7421(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7421,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7425,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7442,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=C_i_car(t3);
t7=C_i_car(t2);
/* c-backend.scm:1141: foreign-type-declaration */
t8=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t5,t6,t7);}

/* k7440 in a7420 in k7411 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1141: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k7423 in a7420 in k7411 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7425(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
if(C_truep(C_i_pairp(t2))){
/* c-backend.scm:1142: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7414 in k7411 in k7408 in k7402 in k7399 in k7396 in k7393 in ##compiler#generate-foreign-callback-header in k2009 in k1923 in k1920 */
static void C_ccall f_7416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1144: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6897,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6903,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6903(t7,t1,t2);}

/* loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6903(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6903,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6911,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7378,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g12071208 */
t6=t3;
f_6911(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7376 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6903(t3,((C_word*)t0)[2],t2);}

/* g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6911(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6911,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6915,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1079: foreign-callback-stub-id */
t4=*((C_word*)lf[666]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6918,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1080: real-name2 */
t3=*((C_word*)lf[598]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6918,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6921,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1081: foreign-callback-stub-return-type */
t3=*((C_word*)lf[665]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6921(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6921,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6924,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1082: foreign-callback-stub-argument-types */
t3=*((C_word*)lf[664]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6924,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6930,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1084: make-argument-list */
t4=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[663]);}

/* k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6930,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6932,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:1111: fold */
t6=*((C_word*)lf[443]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,((C_word*)t3)[1],lf[662],((C_word*)t0)[4],t1);}

/* k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7279,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:1112: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7282,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7375,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1114: cleanup */
t4=*((C_word*)lf[507]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_7282(2,t3,C_SCHEME_UNDEFINED);}}

/* k7373 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1114: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[660],t1,lf[661]);}

/* k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7285,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1115: generate-foreign-callback-header */
t3=*((C_word*)lf[551]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[659],((C_word*)t0)[2]);}

/* k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7288,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1116: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_make_character(123),C_SCHEME_TRUE,lf[657],((C_word*)t0)[2],lf[658]);}

/* k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:1117: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[656]);}

/* k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7294,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7324,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7324(t6,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1365 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_7324(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7324,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7343,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7340,a[2]=t7,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1120: foreign-result-conversion */
t10=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t8,lf[655]);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7338 in loop1365 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1120: gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[652],t1,((C_word*)t0)[2],lf[653],C_SCHEME_TRUE,lf[654]);}

/* k7341 in loop1365 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7343(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_7324(t4,((C_word*)t0)[2],t2,t3);}

/* k7292 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7297,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_eqp(lf[564],((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t2;
f_7297(2,t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7322,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1125: foreign-argument-conversion */
t5=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[4]);}}

/* k7320 in k7292 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1125: gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[651],t1);}

/* k7295 in k7292 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7300,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1126: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[650],((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],C_make_character(41));}

/* k7298 in k7295 in k7292 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7303,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_eqp(lf[564],((C_word*)t0)[2]);
if(C_truep(t3)){
/* c-backend.scm:1128: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,((C_word*)t0)[3],lf[649]);}
else{
/* c-backend.scm:1127: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_make_character(41));}}

/* k7301 in k7298 in k7295 in k7292 in k7289 in k7286 in k7283 in k7280 in k7277 in k7274 in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_7303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1128: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[649]);}

/* compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6932(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_6932,5,t0,t1,t2,t3,t4);}
t5=t2;
t6=C_eqp(t5,lf[16]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6942,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t5,a[6]=t1,a[7]=t4,tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_6942(t8,t6);}
else{
t8=C_eqp(t5,lf[639]);
if(C_truep(t8)){
t9=t7;
f_6942(t9,t8);}
else{
t9=C_eqp(t5,lf[640]);
if(C_truep(t9)){
t10=t7;
f_6942(t10,t9);}
else{
t10=C_eqp(t5,lf[641]);
if(C_truep(t10)){
t11=t7;
f_6942(t11,t10);}
else{
t11=C_eqp(t5,lf[13]);
if(C_truep(t11)){
t12=t7;
f_6942(t12,t11);}
else{
t12=C_eqp(t5,lf[564]);
if(C_truep(t12)){
t13=t7;
f_6942(t13,t12);}
else{
t13=C_eqp(t5,lf[642]);
if(C_truep(t13)){
t14=t7;
f_6942(t14,t13);}
else{
t14=C_eqp(t5,lf[643]);
if(C_truep(t14)){
t15=t7;
f_6942(t15,t14);}
else{
t15=C_eqp(t5,lf[644]);
if(C_truep(t15)){
t16=t7;
f_6942(t16,t15);}
else{
t16=C_eqp(t5,lf[645]);
if(C_truep(t16)){
t17=t7;
f_6942(t17,t16);}
else{
t17=C_eqp(t5,lf[646]);
if(C_truep(t17)){
t18=t7;
f_6942(t18,t17);}
else{
t18=C_eqp(t5,lf[647]);
t19=t7;
f_6942(t19,(C_truep(t18)?t18:C_eqp(t5,lf[648])));}}}}}}}}}}}}

/* k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6942(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6942,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[600]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6951(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[628]);
if(C_truep(t4)){
t5=t3;
f_6951(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[612]);
if(C_truep(t5)){
t6=t3;
f_6951(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[629]);
if(C_truep(t6)){
t7=t3;
f_6951(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[630]);
if(C_truep(t7)){
t8=t3;
f_6951(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[631]);
if(C_truep(t8)){
t9=t3;
f_6951(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[632]);
if(C_truep(t9)){
t10=t3;
f_6951(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[633]);
if(C_truep(t10)){
t11=t3;
f_6951(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[5],lf[634]);
if(C_truep(t11)){
t12=t3;
f_6951(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[614]);
if(C_truep(t12)){
t13=t3;
f_6951(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[5],lf[635]);
if(C_truep(t13)){
t14=t3;
f_6951(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[636]);
if(C_truep(t14)){
t15=t3;
f_6951(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[637]);
t16=t3;
f_6951(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[5],lf[638])));}}}}}}}}}}}}}}

/* k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6951(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6951,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1093: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[601]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[602]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6963,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_6963(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[625]);
if(C_truep(t4)){
t5=t3;
f_6963(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[626]);
if(C_truep(t5)){
t6=t3;
f_6963(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[626]);
t7=t3;
f_6963(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[627])));}}}}}

/* k6961 in k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6963,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1095: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[603],((C_word*)t0)[5],lf[604],((C_word*)t0)[5],lf[605]);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[606]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6975,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t2)){
t4=t3;
f_6975(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[621]);
if(C_truep(t4)){
t5=t3;
f_6975(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[622]);
if(C_truep(t5)){
t6=t3;
f_6975(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[623]);
t7=t3;
f_6975(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[4],lf[624])));}}}}}

/* k6973 in k6961 in k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6975(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6975,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:1097: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[6],((C_word*)t0)[5],lf[607],((C_word*)t0)[4],lf[608]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6981,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* c-backend.scm:1099: ##sys#hash-table-ref */
t3=*((C_word*)lf[619]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[620]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_6981(2,t3,C_SCHEME_FALSE);}}}

/* k6979 in k6973 in k6961 in k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6981(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6981,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6985,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g13301331 */
t3=t2;
f_6985(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[609]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7020,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_7020(t5,t3);}
else{
t5=C_eqp(t2,lf[482]);
if(C_truep(t5)){
t6=t4;
f_7020(t6,t5);}
else{
t6=C_eqp(t2,lf[612]);
if(C_truep(t6)){
t7=t4;
f_7020(t7,t6);}
else{
t7=C_eqp(t2,lf[613]);
if(C_truep(t7)){
t8=t4;
f_7020(t8,t7);}
else{
t8=C_eqp(t2,lf[614]);
if(C_truep(t8)){
t9=t4;
f_7020(t9,t8);}
else{
t9=C_eqp(t2,lf[615]);
if(C_truep(t9)){
t10=t4;
f_7020(t10,t9);}
else{
t10=C_eqp(t2,lf[616]);
if(C_truep(t10)){
t11=t4;
f_7020(t11,t10);}
else{
t11=C_eqp(t2,lf[617]);
t12=t4;
f_7020(t12,(C_truep(t11)?t11:C_eqp(t2,lf[618])));}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}}}

/* k7018 in k6979 in k6973 in k6961 in k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_7020(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:1106: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[7],((C_word*)t0)[6],lf[610]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[611]);
if(C_truep(t2)){
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:1107: compute-size */
t4=((C_word*)((C_word*)t0)[3])[1];
f_6932(5,t4,((C_word*)t0)[7],t3,((C_word*)t0)[2],((C_word*)t0)[6]);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[6]);}}}

/* g1330 in k6979 in k6973 in k6961 in k6949 in k6940 in compute-size in k6928 in k6922 in k6919 in k6916 in k6913 in g1207 in loop1200 in generate-foreign-callback-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6985(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6985,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* c-backend.scm:1101: compute-size */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6932(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=t2;
/* c-backend.scm:1101: compute-size */
t4=((C_word*)((C_word*)t0)[4])[1];
f_6932(5,t4,t1,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6583(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6583,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6589,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_6589(t7,t1,t2);}

/* loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6589(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6589,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6597,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6884,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11191120 */
t6=t3;
f_6597(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6882 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6884(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6589(t3,((C_word*)t0)[2],t2);}

/* g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6597(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6597,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1012: foreign-stub-id */
t4=*((C_word*)lf[599]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6604,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1013: real-name2 */
t3=*((C_word*)lf[598]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6604,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6607,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1014: foreign-stub-argument-types */
t3=*((C_word*)lf[597]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6607,2,t0,t1);}
t2=C_i_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6613,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6881,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1016: make-variable-list */
t5=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[596]);}

/* k6879 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6881,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[595],t1);
/* c-backend.scm:1016: intersperse */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[2],t2,C_make_character(44));}

/* k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6616,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:1017: foreign-stub-return-type */
t3=*((C_word*)lf[594]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:1018: foreign-stub-name */
t3=*((C_word*)lf[593]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_6622,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:1019: foreign-stub-body */
t3=*((C_word*)lf[592]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1020: foreign-stub-argument-names */
t3=*((C_word*)lf[591]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=t2;
f_6628(2,t3,t1);}
else{
/* c-backend.scm:1020: make-list */
t3=*((C_word*)lf[251]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[8],C_SCHEME_FALSE);}}

/* k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:1021: foreign-result-conversion */
t3=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[9],lf[590]);}

/* k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:1022: foreign-stub-cps */
t3=*((C_word*)lf[589]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=t1,a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
/* c-backend.scm:1023: foreign-stub-callback */
t3=*((C_word*)lf[588]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_6640,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=t1,a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],tmp=(C_word)a,a+=15,tmp);
/* c-backend.scm:1024: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6870,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1026: cleanup */
t4=*((C_word*)lf[507]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_6643(2,t3,C_SCHEME_UNDEFINED);}}

/* k6868 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6870(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1026: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[586],t1,lf[587]);}

/* k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[12])){
/* c-backend.scm:1028: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[584],((C_word*)t0)[6],lf[585]);}
else{
t3=t2;
f_6646(2,t3,C_SCHEME_UNDEFINED);}}

/* k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm:1031: gen */
t3=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t3+1)))(10,t3,t2,C_SCHEME_TRUE,lf[579],((C_word*)t0)[2],lf[580],C_SCHEME_TRUE,lf[581],((C_word*)t0)[2],lf[582]);}
else{
/* c-backend.scm:1033: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[583],((C_word*)t0)[2],C_make_character(40));}}

/* k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_6652,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[3]);}

/* k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6652,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_6655,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],tmp=(C_word)a,a+=13,tmp);
if(C_truep(((C_word*)t0)[10])){
/* c-backend.scm:1036: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[574],C_SCHEME_TRUE,lf[575],((C_word*)t0)[2],lf[576]);}
else{
/* c-backend.scm:1037: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[577],C_SCHEME_TRUE,lf[578],((C_word*)t0)[2],C_make_character(40));}}

/* k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6655,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6658,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],tmp=(C_word)a,a+=12,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6658,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6661,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1039: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[573]);}

/* k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6661,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6664,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:1040: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[572]);}

/* k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6664,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6667,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6761,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1049: iota */
t4=*((C_word*)lf[60]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[6]);}

/* k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6761,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6763,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6763(t5,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6763(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6763,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6770,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t6=C_i_pairp(t3);
t7=t5;
f_6770(t7,(C_truep(t6)?C_i_pairp(t4):C_SCHEME_FALSE));}
else{
t6=t5;
f_6770(t6,C_SCHEME_FALSE);}}

/* k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_fcall f_6770(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6770,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(0));
t4=C_slot(((C_word*)t0)[5],C_fix(0));
t5=C_slot(((C_word*)t0)[4],C_fix(0));
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6779,a[2]=t3,a[3]=t4,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6791,a[2]=t3,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t5)){
/* c-backend.scm:1046: symbol->string */
t8=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t5);}
else{
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6797,a[2]=t4,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t9=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k6795 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6797(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6797,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6800,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(116),t1);}

/* k6798 in k6795 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6800,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6803,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k6801 in k6798 in k6795 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6789 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6791(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1044: foreign-type-declaration */
t2=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k6777 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6779,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1047: foreign-type-declaration */
t3=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[571]);}

/* k6781 in k6777 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6787,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:1048: foreign-argument-conversion */
t3=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k6785 in k6781 in k6777 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1043: gen */
t2=*((C_word*)lf[1]+1);
((C_proc11)(void*)(*((C_word*)t2+1)))(11,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[568],((C_word*)t0)[3],C_make_character(41),t1,lf[569],((C_word*)t0)[2],lf[570]);}

/* k6807 in k6768 in loop1139 in k6759 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_slot(((C_word*)t0)[6],C_fix(1));
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_6763(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6667(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6667,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6670,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[7])){
/* c-backend.scm:1050: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[567]);}
else{
t3=t2;
f_6670(2,t3,C_SCHEME_UNDEFINED);}}

/* k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6670,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6673,a[2]=((C_word*)t0)[9],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[8])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6679,a[2]=((C_word*)t0)[6],a[3]=t2,a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1052: gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[8],C_SCHEME_TRUE,lf[558]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6700,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=C_eqp(((C_word*)t0)[5],lf[564]);
if(C_truep(t4)){
/* c-backend.scm:1063: gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,C_SCHEME_TRUE);}
else{
/* c-backend.scm:1062: gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,C_SCHEME_TRUE,lf[566],((C_word*)t0)[2]);}}}

/* k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6703,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:1064: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(40));}

/* k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6706,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6737,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6741,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1065: make-argument-list */
t5=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[565]);}

/* k6739 in k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1065: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k6735 in k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k6704 in k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(((C_word*)t0)[2],lf[564]);
if(C_truep(t3)){
t4=t2;
f_6709(2,t4,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:1066: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,C_make_character(41));}}

/* k6707 in k6704 in k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1067: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[563]);}

/* k6710 in k6707 in k6704 in k6701 in k6698 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1069: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[559],C_SCHEME_TRUE,lf[560]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1071: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],lf[561]);}
else{
/* c-backend.scm:1072: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[562]);}}}

/* k6677 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6679,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:1054: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,lf[557],C_SCHEME_TRUE);}

/* k6680 in k6677 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:1056: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[553],C_SCHEME_TRUE,lf[554]);}
else{
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:1058: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[555]);}
else{
/* c-backend.scm:1059: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[556]);}}}

/* k6671 in k6668 in k6665 in k6662 in k6659 in k6656 in k6653 in k6650 in k6647 in k6644 in k6641 in k6638 in k6635 in k6632 in k6629 in k6626 in k6623 in k6620 in k6617 in k6614 in k6611 in k6605 in k6602 in k6599 in g1119 in loop1112 in ##compiler#generate-foreign-stubs in k2009 in k1923 in k1920 */
static void C_ccall f_6673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1073: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* ##compiler#generate-foreign-callback-stub-prototypes in k2009 in k1923 in k1920 */
static void C_ccall f_6543(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6543,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6549,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6549(t6,t1,t2);}

/* loop1094 in ##compiler#generate-foreign-callback-stub-prototypes in k2009 in k1923 in k1920 */
static void C_fcall f_6549(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6549,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6570,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6561,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:1004: gen */
t6=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,C_SCHEME_TRUE);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6559 in loop1094 in ##compiler#generate-foreign-callback-stub-prototypes in k2009 in k1923 in k1920 */
static void C_ccall f_6561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6564,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:1005: generate-foreign-callback-header */
t3=*((C_word*)lf[551]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[552],((C_word*)t0)[2]);}

/* k6562 in k6559 in loop1094 in ##compiler#generate-foreign-callback-stub-prototypes in k2009 in k1923 in k1920 */
static void C_ccall f_6564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:1006: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k6568 in loop1094 in ##compiler#generate-foreign-callback-stub-prototypes in k2009 in k1923 in k1920 */
static void C_ccall f_6570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6549(t3,((C_word*)t0)[2],t2);}

/* ##compiler#generate-external-variables in k2009 in k1923 in k1920 */
static void C_ccall f_6489(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6489,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6493,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:989: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}

/* k6491 in ##compiler#generate-external-variables in k2009 in k1923 in k1920 */
static void C_ccall f_6493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6493,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6498,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6498(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop1075 in k6491 in ##compiler#generate-external-variables in k2009 in k1923 in k1920 */
static void C_fcall f_6498(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6498,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6530,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_vector_ref(t4,C_fix(0));
t6=C_i_vector_ref(t4,C_fix(1));
t7=C_i_vector_ref(t4,C_fix(2));
t8=(C_truep(t7)?lf[549]:lf[550]);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6527,a[2]=t8,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:995: foreign-type-declaration */
t10=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,t6,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6525 in loop1075 in k6491 in ##compiler#generate-external-variables in k2009 in k1923 in k1920 */
static void C_ccall f_6527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:995: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,((C_word*)t0)[2],t1,C_make_character(59));}

/* k6528 in loop1075 in k6491 in ##compiler#generate-external-variables in k2009 in k1923 in k1920 */
static void C_ccall f_6530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6498(t3,((C_word*)t0)[2],t2);}

/* ##compiler#make-argument-list in k2009 in k1923 in k1920 */
static void C_ccall f_6473(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6473,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6479,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:981: list-tabulate */
t5=*((C_word*)lf[548]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}

/* a6478 in ##compiler#make-argument-list in k2009 in k1923 in k1920 */
static void C_ccall f_6479(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6479,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6487,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:983: number->string */
C_number_to_string(3,0,t3,t2);}

/* k6485 in a6478 in ##compiler#make-argument-list in k2009 in k1923 in k1920 */
static void C_ccall f_6487(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:983: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#make-variable-list in k2009 in k1923 in k1920 */
static void C_ccall f_6457(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6457,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6463,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:976: list-tabulate */
t5=*((C_word*)lf[548]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}

/* a6462 in ##compiler#make-variable-list in k2009 in k1923 in k1920 */
static void C_ccall f_6463(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6463,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6471,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:978: number->string */
C_number_to_string(3,0,t3,t2);}

/* k6469 in a6462 in ##compiler#make-variable-list in k2009 in k1923 in k1920 */
static void C_ccall f_6471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:978: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[547],((C_word*)t0)[2],t1);}

/* ##compiler#cleanup in k2009 in k1923 in k1920 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6368,3,t0,t1,t2);}
t3=C_SCHEME_FALSE;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_i_string_length(t2);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6377,a[2]=t7,a[3]=t2,a[4]=t4,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_6377(t9,t1,C_fix(0));}

/* loop in ##compiler#cleanup in k2009 in k1923 in k1920 */
static void C_fcall f_6377(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6377,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t3=((C_word*)((C_word*)t0)[4])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:((C_word*)t0)[3]));}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=C_fixnum_lessp(t3,C_make_character(32));
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6406,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t4)){
t6=t5;
f_6406(t6,t4);}
else{
t6=C_fixnum_greaterp(t3,C_make_character(126));
if(C_truep(t6)){
t7=t5;
f_6406(t7,t6);}
else{
t7=C_eqp(t3,C_make_character(42));
if(C_truep(t7)){
t8=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
if(C_truep(C_i_lessp(t2,t8))){
t9=C_a_i_plus(&a,2,t2,C_fix(1));
t10=C_i_string_ref(((C_word*)t0)[3],t9);
t11=t5;
f_6406(t11,C_eqp(C_make_character(47),t10));}
else{
t9=t5;
f_6406(t9,C_SCHEME_FALSE);}}
else{
t8=t5;
f_6406(t8,C_SCHEME_FALSE);}}}}}

/* k6404 in loop in ##compiler#cleanup in k2009 in k1923 in k1920 */
static void C_fcall f_6406(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6406,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],C_make_character(126));
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* c-backend.scm:970: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6377(t4,((C_word*)t0)[4],t3);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6416,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:967: string-copy */
t3=*((C_word*)lf[546]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}
else{
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t2=C_i_string_set(((C_word*)((C_word*)t0)[7])[1],((C_word*)t0)[6],((C_word*)t0)[2]);
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* c-backend.scm:970: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_6377(t4,((C_word*)t0)[4],t3);}
else{
t2=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
/* c-backend.scm:970: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6377(t3,((C_word*)t0)[4],t2);}}}

/* k6414 in k6404 in loop in ##compiler#cleanup in k2009 in k1923 in k1920 */
static void C_ccall f_6416(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6416,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_string_set(((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[4],C_make_character(126));
t4=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:970: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6377(t5,((C_word*)t0)[2],t4);}

/* emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6291(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6291,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6295,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_length(t2);
t6=C_a_i_plus(&a,2,t5,C_fix(1));
/* c-backend.scm:932: gen */
t7=*((C_word*)lf[1]+1);
((C_proc9)(void*)(*((C_word*)t7+1)))(9,t7,t4,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[543],C_SCHEME_TRUE,lf[544],t6,lf[545]);}

/* k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6298,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6309,a[2]=((C_word*)t0)[3],a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_6309(t6,t2,((C_word*)t0)[2]);}

/* doloop1035 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_fcall f_6309(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6309,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* c-backend.scm:936: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,C_SCHEME_TRUE,lf[535]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6322,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_i_car(t2);
/* c-backend.scm:937: lambda-literal-id */
t5=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}

/* k6320 in doloop1035 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6322(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6322,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6325,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6354,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:938: string->c-identifier */
t4=*((C_word*)lf[542]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6352 in k6320 in doloop1035 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:938: gen */
t2=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[540],((C_word*)t0)[2],C_make_character(58),t1,lf[541]);}

/* k6323 in k6320 in doloop1035 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6325,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6328,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(lf[266],((C_word*)t0)[2]);
if(C_truep(t3)){
if(C_truep(*((C_word*)lf[217]+1))){
/* c-backend.scm:941: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,lf[536],*((C_word*)lf[217]+1),lf[537]);}
else{
/* c-backend.scm:942: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,lf[538]);}}
else{
/* c-backend.scm:943: gen */
t4=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],lf[539]);}}

/* k6326 in k6323 in k6320 in doloop1035 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
t3=((C_word*)((C_word*)t0)[3])[1];
f_6309(t3,((C_word*)t0)[2],t2);}

/* k6296 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:944: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[534]);}

/* k6299 in k6296 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:945: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[533]);}

/* k6302 in k6299 in k6296 in k6293 in emit-procedure-table-info in k2009 in k1923 in k1920 */
static void C_ccall f_6304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:946: gen */
t2=*((C_word*)lf[1]+1);
((C_proc15)(void*)(*((C_word*)t2+1)))(15,t2,((C_word*)t0)[2],lf[526],C_SCHEME_TRUE,lf[527],C_SCHEME_TRUE,lf[528],C_SCHEME_TRUE,lf[529],C_SCHEME_TRUE,lf[530],C_SCHEME_TRUE,lf[531],C_SCHEME_TRUE,lf[532]);}

/* ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2013(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word ab[78],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_2013,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_SCHEME_UNDEFINED;
t18=(*a=C_VECTOR_TYPE|1,a[1]=t17,tmp=(C_word)a,a+=2,tmp);
t19=C_SCHEME_UNDEFINED;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_SCHEME_UNDEFINED;
t24=(*a=C_VECTOR_TYPE|1,a[1]=t23,tmp=(C_word)a,a+=2,tmp);
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_SCHEME_UNDEFINED;
t28=(*a=C_VECTOR_TYPE|1,a[1]=t27,tmp=(C_word)a,a+=2,tmp);
t29=C_SCHEME_UNDEFINED;
t30=(*a=C_VECTOR_TYPE|1,a[1]=t29,tmp=(C_word)a,a+=2,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2016,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t34=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2058,a[2]=t10,tmp=(C_word)a,a+=3,tmp));
t35=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3963,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t36=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4132,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t37=C_set_block_item(t18,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4303,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t38=C_set_block_item(t20,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4637,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t39=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4957,a[2]=t2,a[3]=t26,tmp=(C_word)a,a+=4,tmp));
t40=C_set_block_item(t24,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5012,a[2]=t24,tmp=(C_word)a,a+=3,tmp));
t41=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5206,a[2]=t28,tmp=(C_word)a,a+=3,tmp));
t42=C_set_block_item(t28,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5348,a[2]=t30,tmp=(C_word)a,a+=3,tmp));
t43=C_set_block_item(t30,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5425,tmp=(C_word)a,a+=2,tmp));
t44=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5473,a[2]=t4,a[3]=t8,a[4]=t24,a[5]=t22,a[6]=t2,a[7]=t12,tmp=(C_word)a,a+=8,tmp));
t45=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_6258,a[2]=t14,a[3]=t16,a[4]=t18,a[5]=t8,a[6]=t20,a[7]=t32,a[8]=t6,a[9]=t4,a[10]=t1,a[11]=t5,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:915: debugging */
t46=*((C_word*)lf[508]+1);
((C_proc4)(void*)(*((C_word*)t46+1)))(4,t46,t45,lf[524],lf[525]);}

/* k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6258,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! ##compiler#output ...) */,((C_word*)t0)[11]);
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_6262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:917: header */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3963(t4,t3);}

/* k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6265,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:918: declarations */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4132(t3,t2);}

/* k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6268,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:919: generate-external-variables */
t3=*((C_word*)lf[522]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[523]+1));}

/* k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_6271,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:920: generate-foreign-stubs */
t3=*((C_word*)lf[520]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[521]+1),((C_word*)t0)[3]);}

/* k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6274,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:921: prototypes */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4303(t3,t2);}

/* k6272 in k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6274,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:922: generate-foreign-callback-stubs */
t3=*((C_word*)lf[519]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[211]+1),((C_word*)t0)[2]);}

/* k6275 in k6272 in k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6277(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6277,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6280,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:923: trampolines */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4637(t3,t2);}

/* k6278 in k6275 in k6272 in k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6280,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6283,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:924: procedures */
t3=((C_word*)((C_word*)t0)[2])[1];
f_5473(t3,t2);}

/* k6281 in k6278 in k6275 in k6272 in k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6283,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6286,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:925: emit-procedure-table-info */
t3=*((C_word*)lf[518]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6284 in k6281 in k6278 in k6275 in k6272 in k6269 in k6266 in k6263 in k6260 in k6256 in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)t0)[2];
/* c-backend.scm:494: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,lf[517],C_SCHEME_TRUE);}

/* procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5473(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5473,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5479,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp));
t5=((C_word*)t3)[1];
f_5479(t5,t1,((C_word*)t0)[2]);}

/* loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5479(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5479,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5487,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6244,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g848849 */
t6=t3;
f_5487(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6242 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5479(t3,((C_word*)t0)[2],t2);}

/* g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5487(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5487,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5491,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:742: lambda-literal-argument-count */
t4=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5494,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:743: lambda-literal-id */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5494,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5497,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:744: real-name */
t3=*((C_word*)lf[516]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[2]);}

/* k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5497(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5497,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5500,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:745: lambda-literal-allocated */
t3=*((C_word*)lf[284]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[6]);}

/* k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5503,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:746: lambda-literal-rest-argument */
t3=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}

/* k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5503,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_5506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t3,a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:747: lambda-literal-customizable */
t5=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[8]);}

/* k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5506,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_5509,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6241,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:748: lambda-literal-closure-size */
t4=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[8]);}
else{
t3=t2;
f_5509(t3,C_SCHEME_FALSE);}}

/* k6239 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5509(t2,C_i_zerop(t1));}

/* k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5509(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5509,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_a_i_minus(&a,2,((C_word*)t0)[13],C_fix(1)):C_a_i_minus(&a,2,((C_word*)t0)[13],C_fix(0)));
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5515,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[11],a[15]=((C_word*)t0)[12],tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm:750: make-variable-list */
t4=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[13],lf[515]);}

/* k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5518,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],tmp=(C_word)a,a+=17,tmp);
/* c-backend.scm:751: make-argument-list */
t3=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[13],lf[514]);}

/* k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5518,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5521,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_cdr(((C_word*)t0)[2]);
/* c-backend.scm:752: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
/* c-backend.scm:752: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_make_character(44));}}

/* k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_5524,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=t1,a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],tmp=(C_word)a,a+=17,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=C_i_cdr(((C_word*)t0)[2]);
/* c-backend.scm:753: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_make_character(44));}
else{
t3=((C_word*)t0)[2];
/* c-backend.scm:753: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,C_make_character(44));}}

/* k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5524,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|17,a[1]=(C_word)f_5527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],tmp=(C_word)a,a+=18,tmp);
/* c-backend.scm:754: lambda-literal-external */
t3=*((C_word*)lf[339]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[12]);}

/* k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|18,a[1]=(C_word)f_5530,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],tmp=(C_word)a,a+=19,tmp);
/* c-backend.scm:755: lambda-literal-looping */
t3=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[13]);}

/* k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|19,a[1]=(C_word)f_5533,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],tmp=(C_word)a,a+=20,tmp);
/* c-backend.scm:756: lambda-literal-direct */
t3=*((C_word*)lf[285]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[14]);}

/* k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|20,a[1]=(C_word)f_5536,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],tmp=(C_word)a,a+=21,tmp);
/* c-backend.scm:757: lambda-literal-rest-argument-mode */
t3=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[15]);}

/* k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|21,a[1]=(C_word)f_5539,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],tmp=(C_word)a,a+=22,tmp);
/* c-backend.scm:758: lambda-literal-temporaries */
t3=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[16]);}

/* k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5539,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5542,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=t1,a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],tmp=(C_word)a,a+=23,tmp);
/* c-backend.scm:759: lambda-literal-unboxed-temporaries */
t3=*((C_word*)lf[513]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[17]);}

/* k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5542,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5545,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],tmp=(C_word)a,a+=24,tmp);
if(C_truep(*((C_word*)lf[217]+1))){
/* c-backend.scm:761: string-append */
t3=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[217]+1),lf[511]);}
else{
t3=t2;
f_5545(2,t3,lf[512]);}}

/* k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5545(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5545,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5548,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],a[14]=((C_word*)t0)[13],a[15]=((C_word*)t0)[14],a[16]=((C_word*)t0)[15],a[17]=((C_word*)t0)[16],a[18]=((C_word*)t0)[17],a[19]=((C_word*)t0)[18],a[20]=((C_word*)t0)[19],a[21]=((C_word*)t0)[20],a[22]=((C_word*)t0)[21],a[23]=((C_word*)t0)[22],a[24]=((C_word*)t0)[23],tmp=(C_word)a,a+=25,tmp);
if(C_truep(((C_word*)t0)[6])){
/* c-backend.scm:763: debugging */
t3=*((C_word*)lf[508]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[509],lf[510],((C_word*)t0)[15]);}
else{
t3=t2;
f_5548(2,t3,C_SCHEME_UNDEFINED);}}

/* k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5548(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5548,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|24,a[1]=(C_word)f_5551,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],a[24]=((C_word*)t0)[24],tmp=(C_word)a,a+=25,tmp);
/* c-backend.scm:764: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE);}

/* k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5551,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5554,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],a[23]=((C_word*)t0)[24],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6210,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:765: cleanup */
t4=*((C_word*)lf[507]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6208 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:765: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],lf[505],t1,lf[506],C_SCHEME_TRUE);}

/* k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[30],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5557,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(lf[266],((C_word*)t0)[15]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6193,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:774: gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[499]);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6171,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[15],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:767: gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,lf[504]);}}

/* k6169 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6171(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6171,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6174,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:768: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[502]);}
else{
/* c-backend.scm:768: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[503]);}}

/* k6172 in k6169 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:770: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[500]);}
else{
/* c-backend.scm:771: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[501]);}}

/* k6175 in k6172 in k6169 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:772: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k6191 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6193,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6196,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[217]+1))){
t3=t2;
f_6196(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:776: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[498]);}}

/* k6194 in k6191 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:777: gen */
t2=*((C_word*)lf[1]+1);
((C_proc16)(void*)(*((C_word*)t2+1)))(16,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[492],C_SCHEME_TRUE,lf[493],C_SCHEME_TRUE,lf[494],C_SCHEME_TRUE,lf[495],((C_word*)t0)[2],lf[496],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[497],((C_word*)t0)[2]);}

/* k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5557,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5560,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:782: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(40));}

/* k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5560,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5563,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)t0)[12])){
t3=t2;
f_5563(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:783: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[491]);}}

/* k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6143,a[2]=t2,a[3]=((C_word*)t0)[16],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[11])){
t4=C_i_zerop(((C_word*)t0)[18]);
t5=t3;
f_6143(t5,C_i_not(t4));}
else{
t4=t3;
f_6143(t4,C_SCHEME_FALSE);}}

/* k6141 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_6143(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6143,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:785: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[490]);}
else{
t2=((C_word*)t0)[2];
f_5566(2,t2,C_SCHEME_UNDEFINED);}}

/* k6144 in k6141 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm:786: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5566(2,t3,t2);}}

/* k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5569,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[16]);}

/* k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5569,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5572,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm:788: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[489]);}
else{
t3=t2;
f_5572(2,t3,C_SCHEME_UNDEFINED);}}

/* k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5572,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5575,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:789: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[488]);}

/* k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5575(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5575,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5578,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
t3=C_eqp(((C_word*)t0)[3],lf[255]);
if(C_truep(t3)){
t4=C_set_block_item(((C_word*)t0)[22],0,C_SCHEME_FALSE);
t5=t2;
f_5578(t5,t4);}
else{
t4=t2;
f_5578(t4,C_SCHEME_UNDEFINED);}}

/* k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5578(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5578,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|23,a[1]=(C_word)f_5581,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],a[16]=((C_word*)t0)[16],a[17]=((C_word*)t0)[17],a[18]=((C_word*)t0)[18],a[19]=((C_word*)t0)[19],a[20]=((C_word*)t0)[20],a[21]=((C_word*)t0)[21],a[22]=((C_word*)t0)[22],a[23]=((C_word*)t0)[23],tmp=(C_word)a,a+=24,tmp);
/* c-backend.scm:791: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[487]);}

/* k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[39],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5581,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|22,a[1]=(C_word)f_5584,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=((C_word*)t0)[16],a[16]=((C_word*)t0)[17],a[17]=((C_word*)t0)[18],a[18]=((C_word*)t0)[19],a[19]=((C_word*)t0)[20],a[20]=((C_word*)t0)[21],a[21]=((C_word*)t0)[22],a[22]=((C_word*)t0)[23],tmp=(C_word)a,a+=23,tmp);
if(C_truep(((C_word*)((C_word*)t0)[22])[1])){
/* c-backend.scm:793: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[476],((C_word*)t0)[21],C_make_character(59));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6056,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6103,a[2]=((C_word*)t0)[21],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[4])){
t5=C_a_i_minus(&a,2,((C_word*)t0)[21],C_fix(1));
t6=t4;
f_6103(t6,C_a_i_plus(&a,2,((C_word*)t0)[17],t5));}
else{
t5=t4;
f_6103(t5,((C_word*)t0)[17]);}}}

/* k6101 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_6103(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6103,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6105,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6105(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* doloop881 in k6101 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_6105(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6105,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6115,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:798: gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,C_SCHEME_TRUE,lf[486],t2,C_make_character(59));}}

/* k6113 in doloop881 in k6101 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6115,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_6105(t4,((C_word*)t0)[2],t2,t3);}

/* k6054 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6056(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6056,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6061,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_6061(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop889 in k6054 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_6061(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6061,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6088,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6077,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t4);
t7=C_eqp(t6,lf[477]);
if(C_truep(t7)){
t8=C_i_car(t4);
/* c-backend.scm:801: gen */
t9=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t9+1)))(7,t9,t3,C_SCHEME_TRUE,lf[478],C_make_character(32),t8,C_make_character(59));}
else{
t8=C_eqp(t6,lf[479]);
if(C_truep(t8)){
t9=C_i_car(t4);
/* c-backend.scm:801: gen */
t10=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t10+1)))(7,t10,t3,C_SCHEME_TRUE,lf[480],C_make_character(32),t9,C_make_character(59));}
else{
t9=C_eqp(t6,lf[16]);
if(C_truep(t9)){
t10=C_i_car(t4);
/* c-backend.scm:801: gen */
t11=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t11+1)))(7,t11,t3,C_SCHEME_TRUE,lf[481],C_make_character(32),t10,C_make_character(59));}
else{
t10=C_eqp(t6,lf[482]);
if(C_truep(t10)){
t11=C_i_car(t4);
/* c-backend.scm:801: gen */
t12=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t12+1)))(7,t12,t3,C_SCHEME_TRUE,lf[483],C_make_character(32),t11,C_make_character(59));}
else{
t11=C_eqp(t6,lf[13]);
if(C_truep(t11)){
t12=C_i_car(t4);
/* c-backend.scm:801: gen */
t13=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t13+1)))(7,t13,t3,C_SCHEME_TRUE,lf[484],C_make_character(32),t12,C_make_character(59));}
else{
/* c-backend.scm:737: bomb */
t12=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t5,lf[485],t6);}}}}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6075 in loop889 in k6054 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6077(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:801: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,((C_word*)t0)[2],C_SCHEME_TRUE,t1,C_make_character(32),t2,C_make_character(59));}

/* k6086 in loop889 in k6054 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6088(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_6061(t3,((C_word*)t0)[2],t2);}

/* k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[31],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5584,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_5587,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[11],a[5]=((C_word*)t0)[12],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[14],a[8]=((C_word*)t0)[15],a[9]=((C_word*)t0)[16],a[10]=((C_word*)t0)[17],a[11]=((C_word*)t0)[18],a[12]=((C_word*)t0)[19],a[13]=((C_word*)t0)[20],a[14]=((C_word*)t0)[21],a[15]=((C_word*)t0)[22],tmp=(C_word)a,a+=16,tmp);
t3=C_eqp(lf[266],((C_word*)t0)[14]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5774,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[17],a[4]=((C_word*)t0)[7],a[5]=t2,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5849,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:804: fold */
t6=*((C_word*)lf[443]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,C_fix(0),((C_word*)t0)[8]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[21])[1])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5863,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[17],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:838: gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_TRUE,lf[457]);}
else{
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5927,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[20],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=t2,a[8]=((C_word*)t0)[17],a[9]=((C_word*)t0)[3],tmp=(C_word)a,a+=10,tmp);
t5=((C_word*)t0)[10];
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_greaterp(((C_word*)t0)[17],C_fix(0)));
if(C_truep(t6)){
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:852: gen */
t7=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t7+1)))(10,t7,t4,C_SCHEME_TRUE,lf[467],C_SCHEME_TRUE,lf[468],C_SCHEME_TRUE,lf[469],((C_word*)t0)[17],lf[470]);}
else{
/* c-backend.scm:855: gen */
t7=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,C_SCHEME_TRUE,lf[471],((C_word*)t0)[17],lf[472]);}}
else{
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6017,a[2]=((C_word*)t0)[10],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[10])){
t8=t7;
f_6017(2,t8,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:857: gen */
t8=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,C_SCHEME_TRUE,lf[475]);}}}}}

/* k6015 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6017(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6017,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6020,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6029,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t4=*((C_word*)lf[136]+1);
t5=t3;
f_6029(t5,(C_truep(t4)?C_SCHEME_FALSE:C_i_not(*((C_word*)lf[437]+1))));}
else{
t4=t3;
f_6029(t4,C_SCHEME_FALSE);}}

/* k6027 in k6015 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_6029(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:859: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],C_SCHEME_TRUE,lf[474]);}
else{
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:860: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[473]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5927(2,t3,t2);}}}

/* k6018 in k6015 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_6020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:860: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[473]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5927(2,t3,t2);}}

/* k5925 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5927,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5930,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5969,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=*((C_word*)lf[136]+1);
if(C_truep(t4)){
t5=t3;
f_5969(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[451]+1);
t6=t3;
f_5969(t6,(C_truep(t5)?C_SCHEME_FALSE:C_i_not(((C_word*)t0)[2])));}}
else{
t4=t3;
f_5969(t4,C_SCHEME_FALSE);}}

/* k5967 in k5925 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5969(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_eqp(((C_word*)t0)[4],lf[255]);
if(C_truep(t2)){
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(2)))){
/* c-backend.scm:864: gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[461],((C_word*)t0)[3],lf[462],((C_word*)t0)[3],lf[463]);}
else{
t3=((C_word*)t0)[2];
f_5930(2,t3,C_SCHEME_UNDEFINED);}}
else{
/* c-backend.scm:865: gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,((C_word*)t0)[2],C_SCHEME_TRUE,lf[464],((C_word*)t0)[3],lf[465],((C_word*)t0)[3],lf[466]);}}
else{
t2=((C_word*)t0)[2];
f_5930(2,t2,C_SCHEME_UNDEFINED);}}

/* k5928 in k5925 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5930,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5936,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[3];
if(C_truep(t3)){
t4=t2;
f_5936(t4,C_SCHEME_FALSE);}
else{
if(C_truep(((C_word*)t0)[2])){
t4=((C_word*)t0)[2];
t5=t2;
f_5936(t5,t4);}
else{
t4=t2;
f_5936(t4,C_i_greaterp(((C_word*)t0)[5],C_fix(0)));}}}

/* k5934 in k5928 in k5925 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5936(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5936,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[446]+1))){
/* c-backend.scm:867: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[460]);}
else{
t3=t2;
f_5939(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
f_5587(2,t2,C_SCHEME_UNDEFINED);}}

/* k5937 in k5934 in k5928 in k5925 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
/* c-backend.scm:869: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[458]);}
else{
/* c-backend.scm:870: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[459]);}}
else{
/* c-backend.scm:870: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[459]);}}

/* k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5863,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5866,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:839: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[456]);}

/* k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5866,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5869,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:840: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[455]);}

/* k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=C_a_i_minus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:842: gen */
t4=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,C_make_character(116),t3);}
else{
/* c-backend.scm:843: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[454]);}}

/* k5870 in k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:844: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[452],((C_word*)t0)[3],lf[453]);}

/* k5873 in k5870 in k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5890,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=*((C_word*)lf[136]+1);
if(C_truep(t4)){
t5=t3;
f_5890(t5,C_SCHEME_FALSE);}
else{
t5=*((C_word*)lf[451]+1);
if(C_truep(t5)){
t6=t3;
f_5890(t6,C_SCHEME_FALSE);}
else{
t6=C_i_greaterp(((C_word*)t0)[3],C_fix(2));
t7=t3;
f_5890(t7,(C_truep(t6)?C_i_not(((C_word*)t0)[2]):C_SCHEME_FALSE));}}}

/* k5888 in k5873 in k5870 in k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5890(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:846: gen */
t2=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[448],((C_word*)t0)[2],lf[449],((C_word*)t0)[2],lf[450]);}
else{
t2=((C_word*)t0)[3];
f_5878(2,t2,C_SCHEME_UNDEFINED);}}

/* k5876 in k5873 in k5870 in k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5881,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[446]+1))){
/* c-backend.scm:847: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[447]);}
else{
/* c-backend.scm:848: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,((C_word*)t0)[3],C_SCHEME_TRUE,lf[444],((C_word*)t0)[2],lf[445]);}}

/* k5879 in k5876 in k5873 in k5870 in k5867 in k5864 in k5861 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:848: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[444],((C_word*)t0)[2],lf[445]);}

/* a5848 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5849(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5849,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5857,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:804: literal-size */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5012(t5,t4,t2);}

/* k5855 in a5848 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5857(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5857,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_plus(&a,2,((C_word*)t0)[2],t1));}

/* k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5774(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5774,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5780,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:806: gen */
t4=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t4+1)))(10,t4,t3,C_SCHEME_TRUE,lf[439],C_SCHEME_TRUE,lf[440],C_SCHEME_TRUE,lf[441],((C_word*)t0)[2],lf[442]);}

/* k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5780(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5780,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5783,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(*((C_word*)lf[437]+1))){
/* c-backend.scm:810: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[438]);}
else{
t3=t2;
f_5783(2,t3,C_SCHEME_UNDEFINED);}}

/* k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5783(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5783,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(*((C_word*)lf[217]+1))){
t3=t2;
f_5786(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5817,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[430]+1))){
/* c-backend.scm:813: gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_SCHEME_TRUE,lf[431],*((C_word*)lf[430]+1),lf[432]);}
else{
if(C_truep(*((C_word*)lf[433]+1))){
/* c-backend.scm:815: gen */
t4=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t4+1)))(8,t4,t3,C_SCHEME_TRUE,lf[434],*((C_word*)lf[433]+1),lf[435],C_SCHEME_TRUE,lf[436]);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t3;
f_5817(2,t5,t4);}}}}

/* k5815 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5820,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[428]+1))){
/* c-backend.scm:818: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[429],*((C_word*)lf[428]+1),C_make_character(59));}
else{
t3=t2;
f_5820(2,t3,C_SCHEME_UNDEFINED);}}

/* k5818 in k5815 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[426]+1))){
/* c-backend.scm:820: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[427],*((C_word*)lf[426]+1),C_make_character(59));}
else{
t3=t2;
f_5823(2,t3,C_SCHEME_UNDEFINED);}}

/* k5821 in k5818 in k5815 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(*((C_word*)lf[423]+1))){
/* c-backend.scm:822: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[424],*((C_word*)lf[423]+1),lf[425]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_5786(2,t3,t2);}}

/* k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5786(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5786,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5789,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:823: gen */
t3=*((C_word*)lf[1]+1);
((C_proc16)(void*)(*((C_word*)t3+1)))(16,t3,t2,C_SCHEME_TRUE,lf[416],((C_word*)t0)[3],lf[417],C_SCHEME_TRUE,lf[418],((C_word*)t0)[3],lf[419],C_SCHEME_TRUE,lf[420],C_SCHEME_TRUE,lf[421],C_SCHEME_TRUE,lf[422]);}

/* k5787 in k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5789,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5792,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:828: gen */
t3=*((C_word*)lf[1]+1);
((C_proc14)(void*)(*((C_word*)t3+1)))(14,t3,t2,C_SCHEME_TRUE,lf[410],((C_word*)t0)[2],lf[411],C_SCHEME_TRUE,lf[412],C_SCHEME_TRUE,lf[413],((C_word*)t0)[2],lf[414],C_SCHEME_TRUE,lf[415]);}

/* k5790 in k5787 in k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5792,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5795,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:832: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[408],((C_word*)t0)[2],lf[409]);}

/* k5793 in k5790 in k5787 in k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5795(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5795,2,t0,t1);}
if(C_truep(C_i_zerop(((C_word*)t0)[4]))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
f_5587(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5804,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:834: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[406],((C_word*)t0)[4],lf[407]);}}

/* k5802 in k5793 in k5790 in k5787 in k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5807,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:835: literal-frame */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4957(t3,t2);}

/* k5805 in k5802 in k5793 in k5790 in k5787 in k5784 in k5781 in k5778 in k5772 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:836: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[404],((C_word*)t0)[2],lf[405]);}

/* k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5587(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5587,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5590,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],a[6]=((C_word*)t0)[15],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5610,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[13],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[14],tmp=(C_word)a,a+=12,tmp);
t4=C_eqp(lf[266],((C_word*)t0)[7]);
if(C_truep(t4)){
t5=t3;
f_5610(t5,C_SCHEME_FALSE);}
else{
t5=((C_word*)t0)[3];
if(C_truep(t5)){
t6=t3;
f_5610(t6,C_SCHEME_FALSE);}
else{
t6=((C_word*)((C_word*)t0)[14])[1];
if(C_truep(t6)){
t7=t3;
f_5610(t7,t6);}
else{
if(C_truep(((C_word*)t0)[2])){
t7=((C_word*)t0)[2];
t8=t3;
f_5610(t8,t7);}
else{
t7=t3;
f_5610(t7,C_i_greaterp(((C_word*)t0)[10],C_fix(0)));}}}}}

/* k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5610(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5610,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(((C_word*)((C_word*)t0)[11])[1])){
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5616,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
/* c-backend.scm:875: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_SCHEME_TRUE,lf[395],lf[396],((C_word*)t0)[8],C_make_character(114));}
else{
/* c-backend.scm:875: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_SCHEME_TRUE,lf[397],lf[396],((C_word*)t0)[8],C_make_character(114));}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[4],C_fix(0)))){
/* c-backend.scm:898: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,lf[401],lf[402]);}
else{
/* c-backend.scm:898: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,lf[403],lf[402]);}}}
else{
t2=((C_word*)t0)[9];
f_5590(2,t2,C_SCHEME_UNDEFINED);}}

/* k5713 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5718,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:900: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],lf[399]);}
else{
/* c-backend.scm:901: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[2],lf[400],((C_word*)t0)[3]);}}

/* k5716 in k5713 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5721,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5730,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:903: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
/* c-backend.scm:905: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],lf[398]);}}

/* k5728 in k5716 in k5713 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5730(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5719 in k5716 in k5713 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:905: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[398]);}

/* k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:876: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[393],((C_word*)t0)[4],lf[394]);}

/* k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5622,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5702,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:878: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_make_character(44),((C_word*)t0)[3],C_make_character(44));}
else{
t3=t2;
f_5622(2,t3,C_SCHEME_UNDEFINED);}}

/* k5700 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[3],*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5625,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:880: gen */
t3=*((C_word*)lf[1]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,lf[389],C_SCHEME_TRUE,lf[390],C_SCHEME_TRUE,lf[391],((C_word*)t0)[5],lf[392]);}

/* k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5628,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:883: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[387],((C_word*)t0)[5],lf[388]);}

/* k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:884: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[386]);}

/* k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5692,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5696,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:885: make-argument-list */
t5=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[5],lf[385]);}

/* k5694 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:885: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k5690 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5637,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:886: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[383],((C_word*)t0)[5],lf[384]);}

/* k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:888: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[381],((C_word*)t0)[2],lf[382]);}

/* k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5643,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5646,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:890: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[379],((C_word*)t0)[3],lf[380]);}

/* k5644 in k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5646,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5649,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:891: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[378]);}

/* k5647 in k5644 in k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5652,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5667,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_5667(t7,t2,t3,((C_word*)t0)[2]);}

/* doloop964 in k5647 in k5644 in k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5667(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5667,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5677,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:895: gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,C_SCHEME_TRUE,lf[377],t2,C_make_character(59));}}

/* k5675 in doloop964 in k5647 in k5644 in k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5677,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5667(t4,((C_word*)t0)[2],t2,t3);}

/* k5650 in k5647 in k5644 in k5641 in k5638 in k5635 in k5632 in k5629 in k5626 in k5623 in k5620 in k5617 in k5614 in k5608 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5652(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_i_greaterp(((C_word*)t0)[3],C_fix(0)))){
/* c-backend.scm:896: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[375],((C_word*)t0)[3],lf[376]);}
else{
t2=((C_word*)t0)[2];
f_5590(2,t2,C_SCHEME_UNDEFINED);}}

/* k5588 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5593,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5600,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:907: lambda-literal-body */
t4=*((C_word*)lf[374]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5598 in k5588 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5600(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5600,2,t0,t1);}
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
/* c-backend.scm:906: expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2058(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
/* c-backend.scm:906: expression */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2058(t3,((C_word*)t0)[3],t1,t2,((C_word*)t0)[2]);}}

/* k5591 in k5588 in k5585 in k5582 in k5579 in k5576 in k5573 in k5570 in k5567 in k5564 in k5561 in k5558 in k5555 in k5552 in k5549 in k5546 in k5543 in k5540 in k5537 in k5534 in k5531 in k5528 in k5525 in k5522 in k5519 in k5516 in k5513 in k5507 in k5504 in k5501 in k5498 in k5495 in k5492 in k5489 in g848 in loop841 in procedures in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5593(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:912: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* string-like-substring in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5425(C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5425,NULL,4,t1,t2,t3,t4);}
t5=C_a_i_minus(&a,2,t4,t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5432,a[2]=t5,a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:726: make-string */
t7=*((C_word*)lf[373]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}

/* k5430 in string-like-substring in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5432,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5435,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:727: ##sys#copy-bytes */
t3=*((C_word*)lf[372]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,((C_word*)t0)[4],t1,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* k5433 in k5430 in string-like-substring in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5435(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5348(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5348,NULL,3,t0,t1,t2);}
t3=C_block_size(t2);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5355,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:715: fx/ */
t5=*((C_word*)lf[371]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t3,C_fix(80));}

/* k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5355(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5355,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5358,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:716: modulo */
t3=*((C_word*)lf[370]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[5],C_fix(80));}

/* k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5358,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5363,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp));
t5=((C_word*)t3)[1];
f_5363(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_fix(0));}

/* doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5363(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5363,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t2))){
t4=C_i_zerop(((C_word*)t0)[6]);
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5379,a[2]=((C_word*)t0)[6],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t4)){
t6=t5;
f_5379(t6,t4);}
else{
t6=C_i_zerop(((C_word*)t0)[3]);
t7=t5;
f_5379(t7,C_i_not(t6));}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5400,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5415,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5419,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_a_i_plus(&a,2,t3,C_fix(80));
/* c-backend.scm:722: string-like-substring */
f_5425(t6,((C_word*)t0)[4],t3,t7);}}

/* k5417 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:722: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5413 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:722: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_TRUE);}

/* k5398 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5400,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(80));
t4=((C_word*)((C_word*)t0)[3])[1];
f_5363(t4,((C_word*)t0)[2],t2,t3);}

/* k5377 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5379(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5379,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5386,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5390,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:721: string-like-substring */
f_5425(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k5388 in k5377 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:721: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5384 in k5377 in doloop818 in k5356 in k5353 in gen-string-constant in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5386(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:721: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5206(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5206,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5213,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_fixnump(t2))){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5346,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:688: big-fixnum? */
t6=*((C_word*)lf[369]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}
else{
t5=t4;
f_5213(t5,C_SCHEME_FALSE);}}

/* k5344 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5346(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5213(t2,C_i_not(t1));}

/* k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5213,NULL,2,t0,t1);}
if(C_truep(t1)){
/* c-backend.scm:689: gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[4],lf[354],((C_word*)t0)[3],lf[355]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5219,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:690: block-variable-literal? */
t3=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}

/* k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5219,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
t2=*((C_word*)lf[356]+1);
t3=C_eqp(((C_word*)t0)[4],t2);
if(C_truep(t3)){
/* c-backend.scm:692: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[357]);}
else{
if(C_truep(C_booleanp(((C_word*)t0)[4]))){
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:694: gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[358],C_make_character(59));}
else{
/* c-backend.scm:694: gen */
t4=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t4+1)))(7,t4,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],C_make_character(61),lf[359],C_make_character(59));}}
else{
if(C_truep(C_charp(((C_word*)t0)[4]))){
t4=C_fix(C_character_code(((C_word*)t0)[4]));
/* c-backend.scm:696: gen */
t5=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t5+1)))(7,t5,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[360],t4,lf[361]);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[4]))){
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:699: c-ify-string */
t6=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
/* c-backend.scm:704: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],C_SCHEME_TRUE,((C_word*)t0)[3],lf[365]);}
else{
t4=C_immp(((C_word*)t0)[4]);
t5=(C_truep(t4)?C_SCHEME_FALSE:C_lambdainfop(((C_word*)t0)[4]));
if(C_truep(t5)){
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_fixnump(((C_word*)t0)[4]);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5302,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t6)){
t8=t7;
f_5302(t8,t6);}
else{
t8=C_immp(((C_word*)t0)[4]);
t9=t7;
f_5302(t9,C_i_not(t8));}}}}}}}}}

/* k5300 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5302(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5302,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5305,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:708: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],lf[368]);}
else{
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[3];
/* c-backend.scm:665: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[349],t3);}}

/* k5303 in k5300 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5305(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5305,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5308,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5315,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:709: encode-literal */
t4=*((C_word*)lf[367]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5313 in k5303 in k5300 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:709: gen-string-constant */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5348(t2,((C_word*)t0)[2],t1);}

/* k5306 in k5303 in k5300 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:710: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[366]);}

/* k5267 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5269(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5269,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5275,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:701: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_TRUE,((C_word*)t0)[2],lf[364]);}

/* k5273 in k5267 in k5217 in k5211 in gen-lit in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:702: gen */
t2=*((C_word*)lf[1]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[5],lf[362],((C_word*)t0)[4],C_make_character(44),((C_word*)t0)[3],C_make_character(44),((C_word*)t0)[2],lf[363]);}

/* literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5012(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5012,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5019,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:668: immediate? */
t4=*((C_word*)lf[353]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5019,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_stringp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_i_numberp(((C_word*)t0)[3]))){
t2=*((C_word*)lf[345]+1);
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(10));}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5050,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:672: literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5012(t4,t2,t3);}
else{
if(C_truep(C_i_vectorp(((C_word*)t0)[3]))){
t2=C_i_vector_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5079,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5083,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5087,a[2]=t8,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:673: vector->list */
t10=*((C_word*)lf[348]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t9,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5128,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:674: block-variable-literal? */
t3=*((C_word*)lf[352]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}}}}}}

/* k5126 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5128,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
if(C_truep(C_immp(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
/* c-backend.scm:665: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[349],t3);}
else{
if(C_truep(C_lambdainfop(((C_word*)t0)[3]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5146,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:677: ##sys#bytevector? */
t3=*((C_word*)lf[351]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}}}}

/* k5144 in k5126 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5146,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_block_size(((C_word*)t0)[3]);
/* c-backend.scm:677: words */
t4=*((C_word*)lf[350]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
if(C_truep(C_structurep(((C_word*)t0)[3]))){
t2=C_block_size(((C_word*)t0)[3]);
t3=C_a_i_plus(&a,2,C_fix(2),t2);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=t2,tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_5175(t7,((C_word*)t0)[4],C_fix(0),t3);}
else{
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
/* c-backend.scm:665: bomb */
t4=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[349],t3);}}}

/* loop in k5144 in k5126 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5175(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5175,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[5]))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_a_i_plus(&a,2,t2,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5197,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t6=C_slot(((C_word*)t0)[3],t2);
/* c-backend.scm:683: literal-size */
t7=((C_word*)((C_word*)t0)[2])[1];
f_5012(t7,t5,t6);}}

/* k5195 in loop in k5144 in k5126 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5197(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5197,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],t1);
/* c-backend.scm:683: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_5175(t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5151 in k5144 in k5126 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5153,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_plus(&a,2,C_fix(2),t1));}

/* k5085 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5087,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5089,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_5089(t5,((C_word*)t0)[2],t1);}

/* loop766 in k5085 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_5089(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5089,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5118,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g782783 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5012(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5116 in loop766 in k5085 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5118(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5118,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop766779 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5089(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop766779 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5089(t6,((C_word*)t0)[3],t5);}}

/* k5081 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5083(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:673: reduce */
t2=*((C_word*)lf[346]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],*((C_word*)lf[347]+1),C_fix(0),t1);}

/* k5077 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:673: + */
C_plus(5,0,((C_word*)t0)[3],C_fix(1),((C_word*)t0)[2],t1);}

/* k5048 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5050,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5054,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* c-backend.scm:672: literal-size */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5012(t4,t2,t3);}

/* k5052 in k5048 in k5017 in literal-size in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:672: + */
C_plus(5,0,((C_word*)t0)[3],C_fix(3),((C_word*)t0)[2],t1);}

/* literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4957(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4957,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4963,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4963(t5,t1,C_fix(0),((C_word*)t0)[2]);}

/* doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4963(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4963,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4973,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4992,a[2]=t2,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t7=*((C_word*)lf[344]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4990 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4992,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[343],t1);}

/* k4993 in k4990 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4998,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write */
t3=*((C_word*)lf[342]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4996 in k4993 in k4990 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4998(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4998,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5001,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[341]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(93),((C_word*)t0)[2]);}

/* k4999 in k4996 in k4993 in k4990 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5004,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[340]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5002 in k4999 in k4996 in k4993 in k4990 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_5004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:662: gen-lit */
t2=((C_word*)((C_word*)t0)[4])[1];
f_5206(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4971 in doloop745 in literal-frame in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4963(t4,((C_word*)t0)[2],t2,t3);}

/* trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4637(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[28],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4637,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4640,tmp=(C_word)a,a+=2,tmp));
t11=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4676,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4756,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4826,a[2]=t14,a[3]=t3,a[4]=t5,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_4826(t16,t12,((C_word*)t0)[2]);}

/* loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4826(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4826,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4944,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g680681 */
t6=t3;
f_4834(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4942 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4944(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4826(t3,((C_word*)t0)[2],t2);}

/* g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4834(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4834,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4838,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:623: lambda-literal-argument-count */
t4=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4838,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4841,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:624: lambda-literal-rest-argument */
t5=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4841,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4844,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:625: lambda-literal-rest-argument-mode */
t3=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4844(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4844,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4847,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:626: lambda-literal-id */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4850,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:627: lambda-literal-customizable */
t3=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4850,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4853,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=t1,a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4941,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:628: lambda-literal-closure-size */
t4=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4853(t3,C_SCHEME_FALSE);}}

/* k4939 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4853(t2,C_i_zerop(t1));}

/* k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4853(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4853,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4856,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
if(C_truep(t1)){
t3=C_a_i_minus(&a,2,((C_word*)((C_word*)t0)[9])[1],C_fix(1));
t4=C_mutate(((C_word *)((C_word*)t0)[9])+1,t3);
t5=t2;
f_4856(t5,t4);}
else{
t3=t2;
f_4856(t3,C_SCHEME_UNDEFINED);}}

/* k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4856(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4856,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4862,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:630: lambda-literal-direct */
t3=*((C_word*)lf[285]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4862,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[11];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
if(C_truep(((C_word*)t0)[10])){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4868,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:632: gen */
t3=*((C_word*)lf[1]+1);
((C_proc11)(void*)(*((C_word*)t3+1)))(11,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[335],((C_word*)t0)[8],lf[336],C_SCHEME_TRUE,lf[337],((C_word*)t0)[8],lf[338]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4896,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_4896(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4930,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:640: lambda-literal-allocated */
t4=*((C_word*)lf[284]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}}}}

/* k4928 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4930(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_greaterp(t1,C_fix(0));
if(C_truep(t2)){
t3=((C_word*)t0)[3];
f_4896(2,t3,t2);}
else{
/* c-backend.scm:640: lambda-literal-external */
t3=*((C_word*)lf[339]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4894 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4896,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4902,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=C_eqp(((C_word*)t0)[2],lf[255]);
t4=t2;
f_4902(t4,C_i_not(t3));}
else{
t3=t2;
f_4902(t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4900 in k4894 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4902(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4902,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:642: lset-adjoin */
t3=*((C_word*)lf[281]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[282]+1),((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[3])[1]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4910,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:643: lset-adjoin */
t3=*((C_word*)lf[281]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[282]+1),((C_word*)((C_word*)t0)[2])[1],((C_word*)((C_word*)t0)[3])[1]);}}

/* k4908 in k4900 in k4894 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4904 in k4900 in k4894 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4871,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:634: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[333],((C_word*)t0)[3],lf[334]);}

/* k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4871,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:635: restore */
f_4640(t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k4872 in k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4877,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:636: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k4875 in k4872 in k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4880,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:637: make-argument-list */
t3=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],lf[332]);}

/* k4878 in k4875 in k4872 in k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4880,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4883,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4890,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:638: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_make_character(44));}

/* k4888 in k4878 in k4875 in k4872 in k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4881 in k4878 in k4875 in k4872 in k4869 in k4866 in k4860 in k4854 in k4851 in k4848 in k4845 in k4842 in k4839 in k4836 in g680 in loop648 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4883(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:639: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[331]);}

/* k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4759,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4775,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4775(t6,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4775(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4775,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4783,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4813,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g718719 */
t6=t3;
f_4783(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4811 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4813(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4775(t3,((C_word*)t0)[2],t2);}

/* g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4783,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4787,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:647: gen */
t4=*((C_word*)lf[1]+1);
((C_proc13)(void*)(*((C_word*)t4+1)))(13,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[326],t2,lf[327],C_SCHEME_TRUE,lf[328],t2,lf[329],t2,lf[330]);}

/* k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:649: gen */
t3=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t3+1)))(8,t3,t2,C_SCHEME_TRUE,lf[323],((C_word*)t0)[3],lf[324],((C_word*)t0)[3],lf[325]);}

/* k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4793,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:650: restore */
f_4640(t2,((C_word*)t0)[3]);}

/* k4791 in k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4793,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4796,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:651: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[322],((C_word*)t0)[2],C_make_character(44));}

/* k4794 in k4791 in k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4796(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4796,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4799,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4806,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4810,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:652: make-argument-list */
t5=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],lf[321]);}

/* k4808 in k4794 in k4791 in k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:652: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4804 in k4794 in k4791 in k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4797 in k4794 in k4791 in k4788 in k4785 in g718 in loop711 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:653: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[320]);}

/* k4757 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4762,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4773,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:655: emitter */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4676(t4,t3,C_SCHEME_FALSE);}

/* k4771 in k4757 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4773(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4760 in k4757 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4769,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:656: emitter */
t3=((C_word*)((C_word*)t0)[2])[1];
f_4676(t3,t2,C_SCHEME_TRUE);}

/* k4767 in k4760 in k4757 in k4754 in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[319]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* emitter in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4676(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4676,NULL,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4678,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp));}

/* f_4678 in emitter in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4678(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4678,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4682,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t4=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[314]);
t5=(C_truep(((C_word*)t0)[3])?C_make_character(118):lf[315]);
/* c-backend.scm:601: gen */
t6=*((C_word*)lf[1]+1);
((C_proc14)(void*)(*((C_word*)t6+1)))(14,t6,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[316],t2,C_make_character(114),t4,lf[317],C_SCHEME_TRUE,lf[318],t2,C_make_character(114),t5);}

/* k4680 */
static void C_ccall f_4682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4685,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:603: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[312],((C_word*)t0)[4],lf[313]);}

/* k4683 in k4680 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4685,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4688,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:604: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[311],((C_word*)t0)[4],C_make_character(114));}

/* k4686 in k4683 in k4680 */
static void C_ccall f_4688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4688,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4691,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:605: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(118));}
else{
t3=t2;
f_4691(2,t3,C_SCHEME_UNDEFINED);}}

/* k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4691,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4694,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:606: gen */
t3=*((C_word*)lf[1]+1);
((C_proc11)(void*)(*((C_word*)t3+1)))(11,t3,t2,lf[307],((C_word*)t0)[4],lf[308],C_SCHEME_TRUE,lf[309],C_SCHEME_TRUE,lf[310],((C_word*)t0)[4],C_make_character(59));}

/* k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4694(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4694,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4697,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:609: restore */
f_4640(t2,((C_word*)t0)[4]);}

/* k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4697(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4697,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4700,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:610: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[306]);}

/* k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4700,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4703,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:612: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[304]);}
else{
/* c-backend.scm:613: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[305]);}}

/* k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4703,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4706,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:614: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[3],lf[303]);}

/* k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4706(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4706,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4709,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:615: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[302]);}
else{
t3=t2;
f_4709(2,t3,C_SCHEME_UNDEFINED);}}

/* k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4709,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4712,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:616: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[301]);}

/* k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:617: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[300]);}

/* k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4718,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4725,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4729,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(1));
/* c-backend.scm:618: make-argument-list */
t6=*((C_word*)lf[298]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,lf[299]);}

/* k4727 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:618: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4723 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(4,0,((C_word*)t0)[2],*((C_word*)lf[1]+1),t1);}

/* k4716 in k4713 in k4710 in k4707 in k4704 in k4701 in k4698 in k4695 in k4692 in k4689 in k4686 in k4683 in k4680 */
static void C_ccall f_4718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:619: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[297]);}

/* restore in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4640(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4640,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4644,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_minus(&a,2,t2,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
t8=((C_word*)t6)[1];
f_4653(t8,t3,t4,C_fix(0));}

/* doloop656 in restore in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4653(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4653,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_negativep(t2))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4663,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:596: gen */
t5=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t5+1)))(8,t5,t4,C_SCHEME_TRUE,lf[294],t2,lf[295],t3,lf[296]);}}

/* k4661 in doloop656 in restore in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4663,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_4653(t4,((C_word*)t0)[2],t2,t3);}

/* k4642 in restore in trampolines in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4644(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:597: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],C_SCHEME_TRUE,lf[292],((C_word*)t0)[2],lf[293]);}

/* prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4303(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4303,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4307,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:527: gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,C_SCHEME_TRUE);}

/* k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4310,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4376,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t6=((C_word*)t4)[1];
f_4376(t6,t2,((C_word*)t0)[2]);}

/* loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4376,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4384,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4624,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g555556 */
t6=t3;
f_4384(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4622 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4624(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4376(t3,((C_word*)t0)[2],t2);}

/* g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4384(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4384,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4388,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:530: lambda-literal-argument-count */
t4=*((C_word*)lf[291]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4388(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4388,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4391,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:531: lambda-literal-customizable */
t3=*((C_word*)lf[290]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4394,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4621,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:532: lambda-literal-closure-size */
t4=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4394(t3,C_SCHEME_FALSE);}}

/* k4619 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4394(t2,C_i_zerop(t1));}

/* k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4394(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4394,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4397,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4607,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t4=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
/* c-backend.scm:533: make-variable-list */
t5=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[289]);}
else{
t4=((C_word*)t0)[5];
/* c-backend.scm:533: make-variable-list */
t5=*((C_word*)lf[288]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[289]);}}

/* k4605 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4607(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:533: intersperse */
t2=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(44));}

/* k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4397,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4400,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:534: lambda-literal-id */
t3=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4400(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4400,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4403,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:535: lambda-literal-rest-argument */
t3=*((C_word*)lf[287]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4403(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4403,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4406,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:536: lambda-literal-rest-argument-mode */
t3=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4406,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4409,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t1,a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:537: lambda-literal-direct */
t3=*((C_word*)lf[285]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4409,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4412,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:538: lambda-literal-allocated */
t3=*((C_word*)lf[284]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4412(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4412,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_greater_or_equalp(((C_word*)t0)[8],*((C_word*)lf[280]+1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4599,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(1));
/* c-backend.scm:540: lset-adjoin */
t5=*((C_word*)lf[281]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,*((C_word*)lf[282]+1),((C_word*)((C_word*)t0)[3])[1],t4);}
else{
t3=t2;
f_4415(t3,C_SCHEME_UNDEFINED);}}

/* k4597 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_4415(t3,t2);}

/* k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4415(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4415,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_4418,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],tmp=(C_word)a,a+=13,tmp);
/* c-backend.scm:541: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4418(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4418,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4421,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[12],tmp=(C_word)a,a+=11,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4553,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:546: lambda-literal-callee-signatures */
t4=*((C_word*)lf[283]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k4551 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4553,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4555,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4555(t5,((C_word*)t0)[2],t1);}

/* loop570 in k4551 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4555(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4555,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4563,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4581,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g577578 */
t6=t3;
f_4563(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4579 in loop570 in k4551 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4555(t3,((C_word*)t0)[2],t2);}

/* g577 in loop570 in k4551 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4563(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4563,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,*((C_word*)lf[280]+1)))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4574,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_plus(&a,2,t2,C_fix(1));
/* c-backend.scm:545: lset-adjoin */
t5=*((C_word*)lf[281]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,*((C_word*)lf[282]+1),((C_word*)((C_word*)t0)[2])[1],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4572 in g577 in loop570 in k4551 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
t3=C_eqp(lf[266],((C_word*)t0)[5]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4533,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[217]+1))){
/* c-backend.scm:556: string-append */
t5=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[217]+1),lf[271]);}
else{
t5=t4;
f_4533(2,t5,lf[272]);}}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4508,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[5],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:548: gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,lf[278],((C_word*)t0)[5],lf[279],C_SCHEME_TRUE);}}

/* k4506 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4508(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4508,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4511,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:549: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[277]);}

/* k4509 in k4506 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4511,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:550: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[275]);}
else{
/* c-backend.scm:550: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[276]);}}

/* k4512 in k4509 in k4506 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4514,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4517,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:552: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[273]);}
else{
/* c-backend.scm:553: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[274]);}}

/* k4515 in k4512 in k4509 in k4506 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4517(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:554: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4531 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4533,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4536,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:557: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,lf[269],t1,lf[270],C_SCHEME_TRUE);}

/* k4534 in k4531 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4536(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4536,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:558: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[268]);}

/* k4537 in k4534 in k4531 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:559: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[267],((C_word*)t0)[2]);}

/* k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4427,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:560: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(40));}

/* k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4430,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4430(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:561: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[265]);}}

/* k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4480,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=C_i_zerop(((C_word*)t0)[2]);
t5=t3;
f_4480(t5,C_i_not(t4));}
else{
t4=t3;
f_4480(t4,C_SCHEME_FALSE);}}

/* k4478 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4480(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4480,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4483,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:563: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[264]);}
else{
t2=((C_word*)t0)[2];
f_4433(2,t2,C_SCHEME_UNDEFINED);}}

/* k4481 in k4478 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm:564: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4433(2,t3,t2);}}

/* k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[4]);}

/* k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4436,2,t0,t1);}
if(C_truep(((C_word*)t0)[8])){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4442,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:567: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[262]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:575: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(41));}}

/* k4466 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4468(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4468,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4471,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
/* c-backend.scm:578: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_make_character(59));}
else{
/* c-backend.scm:577: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[263]);}}

/* k4469 in k4466 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:578: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k4440 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4442(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4442,2,t0,t1);}
t2=C_eqp(((C_word*)t0)[6],lf[255]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4451,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:570: gen */
t4=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t4+1)))(10,t4,t3,C_SCHEME_TRUE,lf[258],((C_word*)t0)[2],lf[259],C_SCHEME_TRUE,lf[260],((C_word*)t0)[2],lf[261]);}}

/* k4449 in k4440 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4451(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4451,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
C_apply(4,0,t2,*((C_word*)lf[1]+1),((C_word*)t0)[2]);}

/* k4452 in k4449 in k4440 in k4434 in k4431 in k4428 in k4425 in k4422 in k4419 in k4416 in k4413 in k4410 in k4407 in k4404 in k4401 in k4398 in k4395 in k4392 in k4389 in k4386 in g555 in loop548 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4454,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:573: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[256],t2,lf[257]);}

/* k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4310,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4315,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4315(t5,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4315(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4315,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4363,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4327,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:582: gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,C_SCHEME_TRUE,lf[253],t4,lf[254]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4325 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4330,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4337,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:583: make-list */
t4=*((C_word*)lf[251]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],lf[252]);}

/* k4335 in k4325 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4337(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4337,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4339,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4339(t5,((C_word*)t0)[2],t1);}

/* loop626 in k4335 in k4325 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4339(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4339,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4349,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g633634 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4347 in loop626 in k4335 in k4325 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4339(t3,((C_word*)t0)[2],t2);}

/* k4328 in k4325 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:584: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[250]);}

/* k4361 in loop614 in k4308 in k4305 in prototypes in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4315(t3,((C_word*)t0)[2],t2);}

/* declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4132(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4132,NULL,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4139,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:498: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[249]);}

/* k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4142,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4275,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4275(t6,t2,*((C_word*)lf[219]+1));}

/* loop508 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4275(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4275,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4290,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:501: gen */
t5=*((C_word*)lf[1]+1);
((C_proc10)(void*)(*((C_word*)t5+1)))(10,t5,t3,C_SCHEME_TRUE,lf[245],t4,lf[246],C_SCHEME_TRUE,lf[247],t4,lf[248]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4288 in loop508 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4275(t3,((C_word*)t0)[2],t2);}

/* k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4142,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4145,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_zerop(((C_word*)t0)[2]))){
t3=t2;
f_4145(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:505: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_SCHEME_TRUE,C_SCHEME_TRUE,lf[243],((C_word*)t0)[2],lf[244]);}}

/* k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4145,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4148,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:506: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_SCHEME_TRUE,lf[242]);}

/* k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4148(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4148,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4153,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4153(t5,((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}

/* doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4153(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4153,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4163,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t3);
/* c-backend.scm:510: ##sys#lambda-info->string */
t6=*((C_word*)lf[241]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4163,2,t0,t1);}
t2=C_i_string_length(t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4169,a[2]=t1,a[3]=t2,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
t4=C_a_i_arithmetic_shift(&a,2,t2,C_fix(-16));
t5=C_a_i_arithmetic_shift(&a,2,t2,C_fix(-8));
t6=C_a_i_bitwise_and(&a,2,C_fix(255),t5);
t7=C_a_i_bitwise_and(&a,2,C_fix(255),t2);
/* c-backend.scm:512: gen */
t8=*((C_word*)lf[1]+1);
((C_proc12)(void*)(*((C_word*)t8+1)))(12,t8,t3,C_SCHEME_TRUE,lf[239],((C_word*)t0)[5],lf[240],t4,C_make_character(44),t6,C_make_character(44),t7,C_make_character(41));}

/* k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4172,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4222,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_4222(t6,t2,C_fix(0));}

/* doloop526 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4222(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4222,NULL,3,t0,t1,t2);}
if(C_truep(C_i_greater_or_equalp(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4232,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_string_ref(((C_word*)t0)[2],t2);
t5=C_fix(C_character_code(t4));
/* c-backend.scm:519: gen */
t6=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,C_make_character(44),t5);}}

/* k4230 in doloop526 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4222(t3,((C_word*)t0)[2],t2);}

/* k4170 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_a_i_plus(&a,2,((C_word*)t0)[2],C_fix(7));
t4=C_a_i_bitwise_and(&a,2,C_fix(16777208),t3);
t5=C_a_i_minus(&a,2,t4,((C_word*)t0)[2]);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4195,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=((C_word*)t7)[1];
f_4195(t9,t2,t5);}

/* doloop531 in k4170 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4195(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4195,NULL,3,t0,t1,t2);}
if(C_truep(C_i_zerop(t2))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4205,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:522: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[238]);}}

/* k4203 in doloop531 in k4170 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4195(t3,((C_word*)t0)[2],t2);}

/* k4173 in k4170 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4175,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4178,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:523: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[237]);}

/* k4176 in k4173 in k4170 in k4167 in k4161 in doloop520 in k4146 in k4143 in k4140 in k4137 in declarations in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4178,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_4153(t4,((C_word*)t0)[2],t2,t3);}

/* header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3963(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3963,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3966,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3983,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4124,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:464: current-seconds */
t5=*((C_word*)lf[236]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k4122 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4124(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:464: ##sys#decode-seconds */
t2=*((C_word*)lf[235]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_i_vector_ref(t1,C_fix(2));
t4=C_i_vector_ref(t1,C_fix(3));
t5=C_i_vector_ref(t1,C_fix(4));
t6=C_i_vector_ref(t1,C_fix(5));
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4001,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t8=C_a_i_plus(&a,2,C_fix(1900),t6);
t9=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4082,a[2]=t4,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t8,a[7]=((C_word*)t0)[3],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t10=C_a_i_plus(&a,2,t5,C_fix(1));
/* c-backend.scm:472: pad0 */
f_3966(t9,t10);}

/* k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4082,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4086,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:472: pad0 */
f_3966(t2,((C_word*)t0)[2]);}

/* k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4086(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4086,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4090,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:472: pad0 */
f_3966(t2,((C_word*)t0)[2]);}

/* k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4090,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4094,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:472: pad0 */
f_3966(t2,((C_word*)t0)[2]);}

/* k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4098,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4102,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4104,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4112,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4116,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:475: chicken-version */
t7=*((C_word*)lf[234]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,C_SCHEME_TRUE);}

/* k4114 in k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:475: string-split */
t2=*((C_word*)lf[232]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[233]);}

/* k4110 in k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[231]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a4103 in k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4104,3,t0,t1,t2);}
t3=*((C_word*)lf[112]+1);
/* g476477 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,lf[229],t2,lf[230]);}

/* k4100 in k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:473: string-intersperse */
t2=*((C_word*)lf[227]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[228]);}

/* k4096 in k4092 in k4088 in k4084 in k4080 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:470: gen */
t2=*((C_word*)lf[1]+1);
((C_proc21)(void*)(*((C_word*)t2+1)))(21,t2,((C_word*)t0)[8],lf[222],((C_word*)t0)[7],lf[223],C_SCHEME_TRUE,lf[224],C_SCHEME_TRUE,lf[225],((C_word*)t0)[6],C_make_character(45),((C_word*)t0)[5],C_make_character(45),((C_word*)t0)[4],C_make_character(32),((C_word*)t0)[3],C_make_character(58),((C_word*)t0)[2],C_SCHEME_TRUE,t1,lf[226]);}

/* k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4001(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4001,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4004,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:478: gen-list */
t3=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[221]+1));}

/* k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4004(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4004,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4007,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:479: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4010,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[217]+1))){
/* c-backend.scm:480: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[218],*((C_word*)lf[217]+1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4071,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:482: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[220]);}}

/* k4069 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:483: gen-list */
t2=*((C_word*)lf[4]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[219]+1));}

/* k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4013,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:484: gen */
t3=*((C_word*)lf[1]+1);
((C_proc9)(void*)(*((C_word*)t3+1)))(9,t3,t2,C_SCHEME_TRUE,lf[213],C_SCHEME_TRUE,C_SCHEME_TRUE,lf[214],*((C_word*)lf[215]+1),lf[216]);}

/* k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4016,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(*((C_word*)lf[209]+1))){
/* c-backend.scm:486: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,*((C_word*)lf[211]+1));}
else{
t3=t2;
f_4016(2,t3,C_SCHEME_UNDEFINED);}}

/* k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4016,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4019,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(*((C_word*)lf[212]+1)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:488: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}
else{
if(C_truep(*((C_word*)lf[209]+1))){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* c-backend.scm:491: generate-foreign-callback-stub-prototypes */
t3=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],*((C_word*)lf[211]+1));}}}

/* k4029 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4031,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4036,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4036(t5,((C_word*)t0)[2],*((C_word*)lf[212]+1));}

/* loop484 in k4029 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_4036(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4036,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4051,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:489: gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,C_SCHEME_TRUE,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4049 in loop484 in k4029 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4036(t3,((C_word*)t0)[2],t2);}

/* k4017 in k4014 in k4011 in k4008 in k4005 in k4002 in k3999 in k3981 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_4019(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(*((C_word*)lf[209]+1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm:491: generate-foreign-callback-stub-prototypes */
t2=*((C_word*)lf[210]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],*((C_word*)lf[211]+1));}}

/* pad0 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3966(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3966,NULL,2,t1,t2);}
if(C_truep(C_i_lessp(t2,C_fix(10)))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3980,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:462: number->string */
C_number_to_string(3,0,t3,t2);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3978 in pad0 in header in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:462: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[208],t1);}

/* expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2058(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2058,NULL,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2061,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t10=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3931,a[2]=t6,tmp=(C_word)a,a+=3,tmp));
/* c-backend.scm:457: expr */
t11=((C_word*)t6)[1];
f_2061(t11,t1,t2,t3);}

/* expr-args in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3931(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3931,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3937,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:451: pair-for-each */
t5=*((C_word*)lf[207]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t4,t2);}

/* a3936 in expr-args in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3937(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3937,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3941,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=C_eqp(t2,((C_word*)t0)[2]);
if(C_truep(t4)){
t5=C_i_car(t2);
/* c-backend.scm:454: expr */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2061(t6,t1,t5,((C_word*)t0)[3]);}
else{
/* c-backend.scm:453: gen */
t5=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,C_make_character(44));}}

/* k3939 in a3936 in expr-args in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:454: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2061(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word t101;
C_word t102;
C_word t103;
C_word t104;
C_word t105;
C_word t106;
C_word t107;
C_word t108;
C_word t109;
C_word t110;
C_word t111;
C_word t112;
C_word t113;
C_word t114;
C_word t115;
C_word t116;
C_word t117;
C_word t118;
C_word t119;
C_word t120;
C_word t121;
C_word t122;
C_word t123;
C_word t124;
C_word t125;
C_word t126;
C_word t127;
C_word t128;
C_word t129;
C_word t130;
C_word t131;
C_word t132;
C_word t133;
C_word t134;
C_word t135;
C_word t136;
C_word t137;
C_word t138;
C_word t139;
C_word t140;
C_word t141;
C_word t142;
C_word t143;
C_word t144;
C_word t145;
C_word t146;
C_word t147;
C_word t148;
C_word t149;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2061,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[12]);
if(C_truep(t10)){
t11=C_i_car(t7);
t12=C_eqp(t11,lf[13]);
if(C_truep(t12)){
if(C_truep(C_i_cadr(t7))){
/* c-backend.scm:84: gen */
t13=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t1,lf[14]);}
else{
/* c-backend.scm:84: gen */
t13=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t1,lf[15]);}}
else{
t13=C_eqp(t11,lf[16]);
if(C_truep(t13)){
t14=C_i_cadr(t7);
t15=C_fix(C_character_code(t14));
/* c-backend.scm:85: gen */
t16=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t1,lf[17],t15,C_make_character(41));}
else{
t14=C_eqp(t11,lf[18]);
if(C_truep(t14)){
/* c-backend.scm:86: gen */
t15=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t1,lf[19]);}
else{
t15=C_eqp(t11,lf[20]);
if(C_truep(t15)){
t16=C_i_cadr(t7);
/* c-backend.scm:87: gen */
t17=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t17+1)))(5,t17,t1,lf[21],t16,C_make_character(41));}
else{
t16=C_eqp(t11,lf[22]);
if(C_truep(t16)){
/* c-backend.scm:88: gen */
t17=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t1,lf[23]);}
else{
/* c-backend.scm:89: bomb */
t17=*((C_word*)lf[8]+1);
((C_proc3)(void*)(*((C_word*)t17+1)))(3,t17,t1,lf[24]);}}}}}}
else{
t11=C_eqp(t9,lf[25]);
if(C_truep(t11)){
t12=C_i_car(t7);
if(C_truep(C_i_vectorp(t12))){
t13=C_i_vector_ref(t12,C_fix(0));
/* c-backend.scm:94: gen */
t14=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[26],t13,lf[27]);}
else{
t13=C_i_car(t7);
/* c-backend.scm:95: gen */
t14=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t14+1)))(5,t14,t1,lf[28],t13,C_make_character(93));}}
else{
t12=C_eqp(t9,lf[29]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2200,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:98: gen */
t14=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t13,C_SCHEME_TRUE,lf[32]);}
else{
t13=C_eqp(t9,lf[33]);
if(C_truep(t13)){
t14=C_i_car(t7);
/* c-backend.scm:107: gen */
t15=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,lf[34],t14);}
else{
t14=C_eqp(t9,lf[35]);
if(C_truep(t14)){
t15=C_i_car(t7);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2258,a[2]=((C_word*)t0)[5],a[3]=t17,tmp=(C_word)a,a+=4,tmp));
t19=((C_word*)t17)[1];
f_2258(t19,t1,t5,t3,t15);}
else{
t15=C_eqp(t9,lf[36]);
if(C_truep(t15)){
t16=C_i_car(t7);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2312,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:120: gen */
t18=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t18+1)))(5,t18,t17,C_SCHEME_TRUE,t16,C_make_character(61));}
else{
t16=C_eqp(t9,lf[37]);
if(C_truep(t16)){
t17=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2338,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:126: gen */
t18=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,lf[39]);}
else{
t17=C_eqp(t9,lf[40]);
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2365,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:131: gen */
t19=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t19+1)))(3,t19,t18,lf[42]);}
else{
t18=C_eqp(t9,lf[43]);
if(C_truep(t18)){
t19=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2384,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:136: gen */
t20=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t20+1)))(3,t20,t19,lf[44]);}
else{
t19=C_eqp(t9,lf[45]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2417,a[2]=t7,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:143: gen */
t21=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t21+1)))(3,t21,t20,lf[48]);}
else{
t20=C_eqp(t9,lf[49]);
if(C_truep(t20)){
t21=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2454,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:150: gen */
t22=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t22+1)))(3,t22,t21,lf[51]);}
else{
t21=C_eqp(t9,lf[52]);
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2483,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:157: gen */
t23=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t23+1)))(3,t23,t22,lf[54]);}
else{
t22=C_eqp(t9,lf[55]);
if(C_truep(t22)){
t23=C_i_car(t7);
t24=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2515,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=t23,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:165: gen */
t25=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t25+1)))(5,t25,t24,lf[61],t23,C_make_character(44));}
else{
t23=C_eqp(t9,lf[62]);
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2586,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:175: gen */
t25=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t25+1)))(3,t25,t24,lf[64]);}
else{
t24=C_eqp(t9,lf[65]);
if(C_truep(t24)){
t25=C_i_car(t7);
/* c-backend.scm:179: gen */
t26=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t26+1)))(4,t26,t1,C_make_character(116),t25);}
else{
t25=C_eqp(t9,lf[66]);
if(C_truep(t25)){
t26=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2618,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t27=C_i_car(t7);
/* c-backend.scm:182: gen */
t28=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t28+1)))(5,t28,t26,C_make_character(116),t27,C_make_character(61));}
else{
t26=C_eqp(t9,lf[67]);
if(C_truep(t26)){
t27=C_i_car(t7);
t28=C_i_cadr(t7);
if(C_truep(C_i_caddr(t7))){
if(C_truep(t28)){
/* c-backend.scm:191: gen */
t29=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t29+1)))(5,t29,t1,lf[68],t27,lf[69]);}
else{
t29=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2660,a[2]=t27,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2664,a[2]=t29,tmp=(C_word)a,a+=3,tmp);
t31=C_i_cadddr(t7);
/* c-backend.scm:192: symbol->string */
t32=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t32+1)))(3,t32,t30,t31);}}
else{
if(C_truep(t28)){
/* c-backend.scm:193: gen */
t29=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t29+1)))(5,t29,t1,lf[74],t27,lf[75]);}
else{
/* c-backend.scm:194: gen */
t29=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t29+1)))(5,t29,t1,lf[76],t27,lf[77]);}}}
else{
t27=C_eqp(t9,lf[78]);
if(C_truep(t27)){
t28=C_i_car(t7);
t29=C_i_cadr(t7);
t30=C_i_caddr(t7);
t31=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2695,a[2]=t30,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t29)){
/* c-backend.scm:201: gen */
t32=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t32+1)))(5,t32,t31,lf[85],t28,lf[86]);}
else{
/* c-backend.scm:202: gen */
t32=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t32+1)))(5,t32,t31,lf[87],t28,lf[88]);}}
else{
t28=C_eqp(t9,lf[89]);
if(C_truep(t28)){
t29=C_i_car(t7);
t30=C_i_cadr(t7);
t31=C_i_caddr(t7);
if(C_truep(t30)){
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2743,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2757,a[2]=t29,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2761,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:213: symbol->string */
t35=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,t31);}
else{
t32=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2764,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t33=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2778,a[2]=t29,a[3]=t32,tmp=(C_word)a,a+=4,tmp);
t34=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2782,a[2]=t33,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:218: symbol->string */
t35=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t35+1)))(3,t35,t34,t31);}}
else{
t29=C_eqp(t9,lf[96]);
if(C_truep(t29)){
/* c-backend.scm:222: gen */
t30=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t30+1)))(3,t30,t1,lf[97]);}
else{
t30=C_eqp(t9,lf[98]);
if(C_truep(t30)){
t31=C_i_cdr(t5);
t32=C_i_length(t31);
t33=t3;
t34=C_a_i_plus(&a,2,t32,C_fix(1));
t35=C_i_cdr(t7);
t36=C_i_pairp(t35);
t37=(C_truep(t36)?C_i_cadr(t7):C_SCHEME_FALSE);
t38=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2815,a[2]=t36,a[3]=((C_word*)t0)[2],a[4]=t37,a[5]=t33,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[5],a[8]=t32,a[9]=t34,a[10]=t3,a[11]=t31,a[12]=((C_word*)t0)[4],a[13]=t1,a[14]=t5,a[15]=t7,tmp=(C_word)a,a+=16,tmp);
/* c-backend.scm:231: source-info->string */
t39=*((C_word*)lf[153]+1);
((C_proc3)(void*)(*((C_word*)t39+1)))(3,t39,t38,t37);}
else{
t31=C_eqp(t9,lf[154]);
if(C_truep(t31)){
t32=C_i_length(t5);
t33=C_a_i_plus(&a,2,t32,C_fix(1));
t34=C_i_car(t7);
t35=C_i_cadr(t7);
t36=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3427,a[2]=t35,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],a[5]=t33,a[6]=t5,a[7]=t3,a[8]=((C_word*)t0)[5],a[9]=t32,a[10]=t1,a[11]=t34,tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:321: lambda-literal-closure-size */
t37=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t37+1)))(3,t37,t36,((C_word*)t0)[3]);}
else{
t32=C_eqp(t9,lf[158]);
if(C_truep(t32)){
t33=C_i_cdr(t5);
t34=C_i_length(t33);
t35=C_a_i_plus(&a,2,t34,C_fix(1));
t36=C_i_caddr(t7);
t37=C_i_cadddr(t7);
t38=C_i_zerop(t37);
t39=C_i_not(t38);
t40=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3512,a[2]=t36,a[3]=t37,a[4]=t39,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[4],a[8]=t33,a[9]=t1,a[10]=t5,tmp=(C_word)a,a+=11,tmp);
t41=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3516,a[2]=t40,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:349: find-lambda */
t42=((C_word*)((C_word*)t0)[2])[1];
f_2016(t42,t41,t36);}
else{
t33=C_eqp(t9,lf[160]);
if(C_truep(t33)){
t34=C_i_length(t5);
t35=C_a_i_plus(&a,2,t34,C_fix(1));
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3535,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=C_i_car(t7);
/* c-backend.scm:366: gen */
t38=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t38+1)))(8,t38,t36,C_SCHEME_TRUE,lf[162],t37,lf[163],t35,lf[164]);}
else{
t34=C_eqp(t9,lf[165]);
if(C_truep(t34)){
t35=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3554,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:371: gen */
t36=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t36+1)))(4,t36,t35,C_SCHEME_TRUE,lf[167]);}
else{
t35=C_eqp(t9,lf[168]);
if(C_truep(t35)){
t36=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3573,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t37=C_i_car(t7);
/* c-backend.scm:376: gen */
t38=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t38+1)))(4,t38,t36,t37,C_make_character(40));}
else{
t36=C_eqp(t9,lf[169]);
if(C_truep(t36)){
t37=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3592,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t38=C_i_car(t7);
t39=C_i_length(t5);
/* c-backend.scm:381: gen */
t40=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t40+1)))(5,t40,t37,t38,lf[170],t39);}
else{
t37=C_eqp(t9,lf[171]);
if(C_truep(t37)){
t38=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3628,a[2]=t1,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t39=C_i_cadr(t7);
/* c-backend.scm:389: foreign-result-conversion */
t40=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t40+1)))(4,t40,t38,t39,lf[173]);}
else{
t38=C_eqp(t9,lf[174]);
if(C_truep(t38)){
t39=C_i_cadr(t7);
t40=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3648,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t41=C_i_car(t7);
t42=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3666,a[2]=t39,a[3]=t41,a[4]=t40,tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:393: foreign-type-declaration */
t43=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t43+1)))(4,t43,t42,t39,lf[179]);}
else{
t39=C_eqp(t9,lf[180]);
if(C_truep(t39)){
t40=C_i_car(t7);
t41=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3682,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t42=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3696,a[2]=t40,a[3]=t41,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:399: foreign-result-conversion */
t43=*((C_word*)lf[172]+1);
((C_proc4)(void*)(*((C_word*)t43+1)))(4,t43,t42,t40,lf[185]);}
else{
t40=C_eqp(t9,lf[186]);
if(C_truep(t40)){
t41=C_i_car(t7);
t42=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3712,a[2]=t41,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t43=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=t42,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:405: foreign-type-declaration */
t44=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t44+1)))(4,t44,t43,t41,lf[191]);}
else{
t41=C_eqp(t9,lf[192]);
if(C_truep(t41)){
t42=C_i_car(t7);
/* c-backend.scm:412: gen */
t43=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t43+1)))(3,t43,t1,t42);}
else{
t42=C_eqp(t9,lf[193]);
if(C_truep(t42)){
t43=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3762,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t44=C_i_car(t7);
/* c-backend.scm:415: gen */
t45=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t45+1)))(5,t45,t43,lf[195],t44,C_make_character(61));}
else{
t43=C_eqp(t9,lf[196]);
if(C_truep(t43)){
t44=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3785,a[2]=t3,a[3]=t5,a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t45=C_i_car(t7);
/* c-backend.scm:420: gen */
t46=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t46+1)))(4,t46,t44,t45,lf[197]);}
else{
t44=C_eqp(t9,lf[198]);
if(C_truep(t44)){
t45=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3804,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=t5,a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:425: gen */
t46=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t46+1)))(4,t46,t45,C_SCHEME_TRUE,lf[202]);}
else{
t45=C_eqp(t9,lf[203]);
if(C_truep(t45)){
t46=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3887,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:440: gen */
t47=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t47+1)))(3,t47,t46,lf[205]);}
else{
t46=t2;
t47=C_slot(t46,C_fix(1));
/* c-backend.scm:448: bomb */
t48=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t48+1)))(4,t48,t1,lf[206],t47);}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3887(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3887,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3890,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:441: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3888 in k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:442: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[204]);}

/* k3891 in k3888 in k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:443: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3894 in k3891 in k3888 in k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:444: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k3897 in k3894 in k3891 in k3888 in k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3902,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm:445: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3900 in k3897 in k3894 in k3891 in k3888 in k3885 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:446: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3804,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3807,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:426: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2061(t4,t2,t3,((C_word*)t0)[3]);}

/* k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3807,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3810,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:427: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[201]);}

/* k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3810(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3810,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3823,a[2]=t5,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_3823(t7,((C_word*)t0)[2],t2,t3);}

/* doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3823(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3823,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_zerop(t2))){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3833,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:431: gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_TRUE,lf[199]);}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3846,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:434: gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_SCHEME_TRUE,lf[200]);}}

/* k3844 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3846(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3846,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[6]);
/* c-backend.scm:435: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3847 in k3844 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3849,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3852,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:436: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(58));}

/* k3850 in k3847 in k3844 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3852(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3852,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3855,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[6]);
/* c-backend.scm:437: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3853 in k3850 in k3847 in k3844 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3855(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3855,2,t0,t1);}
t2=C_a_i_minus(&a,2,((C_word*)t0)[5],C_fix(1));
t3=C_i_cddr(((C_word*)t0)[4]);
t4=((C_word*)((C_word*)t0)[3])[1];
f_3823(t4,((C_word*)t0)[2],t2,t3);}

/* k3831 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3833,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3836,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:432: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3834 in k3831 in doloop422 in k3808 in k3805 in k3802 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:433: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* k3783 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3785,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3788,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:421: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3786 in k3783 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3788(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:422: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3760 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3762,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3765,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:416: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3763 in k3760 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3765(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:417: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[194]);}

/* k3738 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:405: gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[189],t1,lf[190]);}

/* k3710 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3712,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3715,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:406: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2061(t4,t2,t3,((C_word*)t0)[3]);}

/* k3713 in k3710 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3715,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3718,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3732,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:407: foreign-argument-conversion */
t4=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3730 in k3713 in k3710 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3732(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:407: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],lf[188],t1);}

/* k3716 in k3713 in k3710 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3718,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3721,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:408: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3719 in k3716 in k3713 in k3710 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3721(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:409: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[187]);}

/* k3694 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3696,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3700,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:399: foreign-type-declaration */
t3=*((C_word*)lf[178]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[184]);}

/* k3698 in k3694 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3700(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:399: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[182],t1,lf[183]);}

/* k3680 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3682,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3685,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:400: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3683 in k3680 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:401: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[181]);}

/* k3664 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3670,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:393: foreign-argument-conversion */
t3=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3668 in k3664 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3670(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:393: gen */
t2=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t2+1)))(8,t2,((C_word*)t0)[4],C_make_character(40),((C_word*)t0)[3],lf[176],((C_word*)t0)[2],C_make_character(41),t1);}

/* k3646 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3648,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3651,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:394: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3649 in k3646 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:395: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[175]);}

/* k3626 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[3]);
/* c-backend.scm:389: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],t1,t2,C_make_character(41));}

/* k3590 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3595,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3604,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:384: gen */
t4=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_make_character(44));}
else{
/* c-backend.scm:386: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],C_make_character(41));}}

/* k3602 in k3590 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3604(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:385: expr-args */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3931(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3593 in k3590 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:386: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3571 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3576,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:377: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3574 in k3571 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:378: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3552 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3554,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3557,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:372: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k3555 in k3552 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:373: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[166]);}

/* k3533 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3538,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:367: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3536 in k3533 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:368: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[161]);}

/* k3514 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3516(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:349: lambda-literal-closure-size */
t2=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3512,2,t0,t1);}
t2=C_i_zerop(t1);
t3=C_i_car(((C_word*)t0)[10]);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3460,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:351: gen */
t5=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)t0)[2],C_make_character(40));}

/* k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3463,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3493,a[2]=((C_word*)t0)[9],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:353: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,lf[159],((C_word*)t0)[2],C_make_character(41));}
else{
t3=t2;
f_3463(2,t3,C_SCHEME_UNDEFINED);}}

/* k3491 in k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_not(((C_word*)t0)[4]);
if(C_truep(t2)){
if(C_truep(t2)){
/* c-backend.scm:354: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3463(2,t4,t3);}}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
/* c-backend.scm:354: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],C_make_character(44));}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
f_3463(2,t4,t3);}}}

/* k3461 in k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3466,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[4])){
t3=t2;
f_3466(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3481,a[2]=t2,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:356: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t3,((C_word*)t0)[2],((C_word*)t0)[5]);}}

/* k3479 in k3461 in k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3481(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
/* c-backend.scm:357: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(44));}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3466(2,t3,t2);}}

/* k3464 in k3461 in k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3469,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
/* c-backend.scm:358: expr-args */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3931(t3,t2,((C_word*)t0)[4],((C_word*)t0)[2]);}
else{
/* c-backend.scm:359: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[5],C_make_character(41));}}

/* k3467 in k3464 in k3461 in k3458 in k3510 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:359: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3427,2,t0,t1);}
t2=C_i_zerop(t1);
if(C_truep(((C_word*)t0)[11])){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:323: lambda-literal-temporaries */
t4=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3411,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:336: gen */
t4=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[2],C_make_character(40));}}

/* k3409 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3411,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3414,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10580,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:338: expr-args */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3931(t4,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
/* c-backend.scm:337: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[157]);}}

/* f10580 in k3409 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:339: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3412 in k3409 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3414,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:338: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3415 in k3412 in k3409 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:339: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[2]);
/* c-backend.scm:324: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[6],t3,C_fix(1));}

/* k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3304,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3358,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_3358(t6,t2,((C_word*)t0)[2],t1);}

/* loop338 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3358(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3358,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3366,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3379,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g348349 */
t10=t6;
f_3366(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3377 in loop338 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3358(t4,((C_word*)t0)[2],t2,t3);}

/* g348 in loop338 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3366(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3366,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3370,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:327: gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k3368 in g348 in loop338 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3370,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3373,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:328: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3371 in k3368 in g348 in loop338 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3373(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:329: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k3302 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3307,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3314,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:333: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k3312 in k3302 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3314,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3316(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop358 in k3312 in k3302 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3316(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3316,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3331,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:332: gen */
t9=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[156],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3329 in loop358 in k3312 in k3302 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3316(t4,((C_word*)t0)[2],t2,t3);}

/* k3305 in k3302 in k3299 in k3296 in k3425 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:334: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[155]);}

/* k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2818,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],a[14]=((C_word*)t0)[14],a[15]=((C_word*)t0)[15],tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_cddr(((C_word*)t0)[15]);
t4=C_i_pairp(t3);
t5=t2;
f_2818(t5,(C_truep(t4)?C_i_caddr(((C_word*)t0)[15]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2818(t3,C_SCHEME_FALSE);}}

/* k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[23],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2818,NULL,2,t0,t1);}
t2=(C_truep(t1)?C_i_cadddr(((C_word*)t0)[15]):C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|16,a[1]=(C_word)f_2824,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[15],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=t2,a[10]=t1,a[11]=((C_word*)t0)[9],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[11],a[14]=((C_word*)t0)[12],a[15]=((C_word*)t0)[13],a[16]=((C_word*)t0)[14],tmp=(C_word)a,a+=17,tmp);
if(C_truep(t2)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3244,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3248,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:234: find-lambda */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2016(t6,t5,t1);}
else{
t4=t3;
f_2824(t4,C_SCHEME_FALSE);}}

/* k3246 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:234: lambda-literal-closure-size */
t2=*((C_word*)lf[152]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3242 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2824(t2,C_i_zerop(t1));}

/* k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2824(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2824,NULL,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[16]);
t3=(*a=C_CLOSURE_TYPE|15,a[1]=(C_word)f_2830,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],a[14]=((C_word*)t0)[15],a[15]=t2,tmp=(C_word)a,a+=16,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(*((C_word*)lf[144]+1))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3230,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2046,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:71: ->string */
t7=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3237,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[2];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10572,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:72: ->string */
t7=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,t5);}}
else{
t4=t3;
f_2830(2,t4,C_SCHEME_UNDEFINED);}}

/* f10572 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10572(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:72: string-translate* */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[82]);}

/* k3235 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3237(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:239: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[150],t1,lf[151]);}

/* k2044 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2046(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:71: string-translate */
t2=*((C_word*)lf[147]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],t1,lf[148],lf[149]);}

/* k3228 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:238: gen */
t2=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[145],t1,lf[146]);}

/* k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2830,2,t0,t1);}
t2=C_slot(((C_word*)t0)[15],C_fix(1));
t3=C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=C_slot(((C_word*)t0)[15],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2847,a[2]=((C_word*)t0)[11],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[14],tmp=(C_word)a,a+=6,tmp);
t6=C_i_car(t4);
/* c-backend.scm:242: gen */
t7=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t5,C_SCHEME_TRUE,t6,C_make_character(40),((C_word*)t0)[10],lf[100]);}
else{
if(C_truep(((C_word*)t0)[9])){
t4=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_2866,a[2]=((C_word*)t0)[15],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[13],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[12],a[9]=((C_word*)t0)[11],a[10]=((C_word*)t0)[6],a[11]=((C_word*)t0)[7],a[12]=((C_word*)t0)[10],a[13]=((C_word*)t0)[8],a[14]=((C_word*)t0)[14],tmp=(C_word)a,a+=15,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3028,a[2]=((C_word*)t0)[5],a[3]=t4,a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
/* c-backend.scm:246: lambda-literal-id */
t6=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[5]);}
else{
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3034,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[10],a[6]=((C_word*)t0)[11],a[7]=((C_word*)t0)[12],a[8]=((C_word*)t0)[13],a[9]=((C_word*)t0)[14],a[10]=((C_word*)t0)[15],tmp=(C_word)a,a+=11,tmp);
t5=C_slot(((C_word*)t0)[15],C_fix(1));
t6=C_eqp(lf[67],t5);
if(C_truep(t6)){
t7=*((C_word*)lf[136]+1);
if(C_truep(t7)){
t8=t4;
f_3034(t8,C_SCHEME_FALSE);}
else{
t8=*((C_word*)lf[141]+1);
if(C_truep(t8)){
t9=t4;
f_3034(t9,C_SCHEME_FALSE);}
else{
t9=C_i_car(((C_word*)t0)[2]);
t10=t4;
f_3034(t10,C_i_not(t9));}}}
else{
t7=t4;
f_3034(t7,C_SCHEME_FALSE);}}}}

/* k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3034(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3034,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_slot(((C_word*)t0)[10],C_fix(2));
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=C_i_caddr(t2);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3054,a[2]=t2,a[3]=t4,a[4]=t3,a[5]=t5,a[6]=t7,a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=((C_word*)t0)[7],a[10]=((C_word*)t0)[8],a[11]=((C_word*)t0)[9],tmp=(C_word)a,a+=12,tmp);
/* c-backend.scm:280: gen */
t9=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t9+1)))(6,t9,t8,C_SCHEME_TRUE,lf[131],((C_word*)t0)[5],lf[132]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3147,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* c-backend.scm:305: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}

/* k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3147,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3150,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:306: expr */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2061(t3,t2,((C_word*)t0)[2],((C_word*)t0)[7]);}

/* k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3150(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3150,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_3153,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:307: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,C_make_character(59),C_SCHEME_TRUE,lf[142],((C_word*)t0)[4],lf[143]);}

/* k3151 in k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3156,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=*((C_word*)lf[136]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3168,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_3168(t5,t3);}
else{
t5=*((C_word*)lf[141]+1);
t6=t4;
f_3168(t6,(C_truep(t5)?t5:C_i_car(((C_word*)t0)[2])));}}

/* k3166 in k3151 in k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_3168(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* c-backend.scm:310: gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[137],((C_word*)t0)[2],lf[138]);}
else{
/* c-backend.scm:311: gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[139],((C_word*)t0)[2],lf[140]);}}

/* k3154 in k3151 in k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3156(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3156,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3159,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:312: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[134],((C_word*)t0)[3],lf[135],((C_word*)t0)[2],C_make_character(44));}

/* k3157 in k3154 in k3151 in k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3162,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:313: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3160 in k3157 in k3154 in k3151 in k3148 in k3145 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3162(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:314: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[133]);}

/* k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3054,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3057,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],tmp=(C_word)a,a+=8,tmp);
if(C_truep(*((C_word*)lf[109]+1))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3070,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[5])){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3080,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:284: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3087,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:285: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[4]);}}
else{
if(C_truep(((C_word*)t0)[5])){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3094,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3119,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:288: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[4]);}
else{
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3126,a[2]=t2,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3133,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:295: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3137,a[2]=((C_word*)t0)[4],a[3]=t2,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3144,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:299: number->string */
C_number_to_string(3,0,t4,((C_word*)t0)[4]);}}}}

/* k3142 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3144(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:299: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[129],t1,lf[130]);}

/* k3135 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,t1);
/* c-backend.scm:300: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[127],((C_word*)t0)[2],lf[128]);}

/* k3131 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:295: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[125],t1,lf[126]);}

/* k3124 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm:296: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[123],((C_word*)((C_word*)t0)[3])[1],lf[124]);}

/* k3117 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:288: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[121],t1,lf[122]);}

/* k3092 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3094,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
if(C_truep(((C_word*)t0)[4])){
/* c-backend.scm:290: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[117],((C_word*)((C_word*)t0)[5])[1],lf[118]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3107,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3111,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadddr(((C_word*)t0)[2]);
/* c-backend.scm:292: symbol->string */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k3109 in k3092 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:292: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3105 in k3092 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:291: gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[119],((C_word*)((C_word*)t0)[2])[1],lf[120],t1,C_make_character(41));}

/* k3085 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3087(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:285: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[115],t1,lf[116]);}

/* k3078 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3080(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:284: string-append */
t2=*((C_word*)lf[112]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[113],t1,lf[114]);}

/* k3068 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
/* c-backend.scm:286: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[110],((C_word*)((C_word*)t0)[3])[1],lf[111]);}

/* k3055 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3057,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3060,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:301: gen */
t3=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t3+1)))(7,t3,t2,lf[108],((C_word*)t0)[3],C_make_character(44),((C_word*)((C_word*)t0)[2])[1],C_make_character(44));}

/* k3058 in k3055 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3060(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3060,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3063,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:302: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3061 in k3058 in k3055 in k3052 in k3032 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:303: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[107]);}

/* k3026 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_eqp(((C_word*)t0)[4],t1);
if(C_truep(t2)){
/* c-backend.scm:247: lambda-literal-looping */
t3=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t3=((C_word*)t0)[3];
f_2866(2,t3,C_SCHEME_FALSE);}}

/* k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2866,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2869,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],a[6]=((C_word*)t0)[12],a[7]=((C_word*)t0)[13],a[8]=((C_word*)t0)[14],tmp=(C_word)a,a+=9,tmp);
/* c-backend.scm:248: lambda-literal-temporaries */
t3=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[7]);}
else{
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_2988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[12],a[4]=((C_word*)t0)[13],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[14],tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_2988(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3012,a[2]=((C_word*)t0)[9],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[10],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:263: gen */
t4=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t3,C_SCHEME_TRUE,C_make_character(116),((C_word*)t0)[4],C_make_character(61));}}}

/* k3010 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3012(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3012,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3015,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:264: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3013 in k3010 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:265: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2988(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2988,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2991,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* c-backend.scm:266: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_SCHEME_TRUE,((C_word*)t0)[2],C_make_character(40));}

/* k2989 in k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2991,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2994,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_2994(2,t3,C_SCHEME_UNDEFINED);}
else{
/* c-backend.scm:267: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],C_make_character(44));}}

/* k2992 in k2989 in k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2994,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2997,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10567,a[2]=((C_word*)t0)[7],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:269: expr-args */
t4=((C_word*)((C_word*)t0)[6])[1];
f_3931(t4,t3,((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
/* c-backend.scm:268: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_make_character(116),((C_word*)t0)[2],C_make_character(44));}}

/* f10567 in k2992 in k2989 in k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10567(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:270: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[105]);}

/* k2995 in k2992 in k2989 in k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2997(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2997,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3000,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:269: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2998 in k2995 in k2992 in k2989 in k2986 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_3000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:270: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[105]);}

/* k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2872,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=C_a_i_plus(&a,2,t1,((C_word*)t0)[6]);
/* c-backend.scm:249: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,((C_word*)t0)[5],t3,C_fix(1));}

/* k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2872(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2872,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2875,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2935,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2935(t6,t2,((C_word*)t0)[2],t1);}

/* loop242 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2935(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2935,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2943,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2956,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g252253 */
t10=t6;
f_2943(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2954 in loop242 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2935(t4,((C_word*)t0)[2],t2,t3);}

/* g252 in loop242 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2943(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2943,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2947,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:252: gen */
t5=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,t4,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}

/* k2945 in g252 in loop242 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2947(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2947,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2950,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:253: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2948 in k2945 in g252 in loop242 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:254: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2875(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2875,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2878,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2891,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:258: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[2],C_fix(1),C_fix(1));}

/* k2889 in k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2891,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2893,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2893(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop262 in k2889 in k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2893(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2893,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2908,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_slot(t2,C_fix(0));
t8=C_slot(t3,C_fix(0));
/* c-backend.scm:257: gen */
t9=*((C_word*)lf[1]+1);
((C_proc8)(void*)(*((C_word*)t9+1)))(8,t9,t6,C_SCHEME_TRUE,C_make_character(116),t8,lf[103],t7,C_make_character(59));}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2906 in loop262 in k2889 in k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2893(t4,((C_word*)t0)[2],t2,t3);}

/* k2876 in k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2878(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2878,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2881,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[3])){
/* c-backend.scm:260: gen */
t3=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[4],C_SCHEME_TRUE,lf[101]);}
else{
/* c-backend.scm:259: gen */
t3=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,C_SCHEME_TRUE,lf[102],((C_word*)t0)[2],C_make_character(59));}}

/* k2879 in k2876 in k2873 in k2870 in k2867 in k2864 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2881(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:260: gen */
t2=*((C_word*)lf[1]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_SCHEME_TRUE,lf[101]);}

/* k2845 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2847,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2850,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:243: expr-args */
t3=((C_word*)((C_word*)t0)[4])[1];
f_3931(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2848 in k2845 in k2828 in k2822 in k2816 in k2813 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2850(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:244: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[99]);}

/* k2780 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2782,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10559,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:72: ->string */
t3=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f10559 in k2780 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:72: string-translate* */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[82]);}

/* k2776 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2778(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:217: gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[93],((C_word*)t0)[2],lf[94],t1,lf[95]);}

/* k2762 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2764(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2764,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2767,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:219: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2765 in k2762 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2767(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:220: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2759 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2761(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2761,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10554,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:72: ->string */
t3=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f10554 in k2759 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:72: string-translate* */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[82]);}

/* k2755 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2757(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:212: gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[90],((C_word*)t0)[2],lf[91],t1,lf[92]);}

/* k2741 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2743(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2743,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2746,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:214: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2744 in k2741 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:215: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(59));}

/* k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2698,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2712,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2716,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:203: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[84]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k2714 in k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2716(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2716,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f10549,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:72: ->string */
t3=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,t1);}

/* f10549 in k2714 in k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f10549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:72: string-translate* */
t2=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[82]);}

/* k2710 in k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:203: gen */
t2=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],lf[79],t1,lf[80]);}

/* k2696 in k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2698(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2698,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2701,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:204: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2699 in k2696 in k2693 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:205: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2662 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2664(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:192: c-ify-string */
t2=*((C_word*)lf[72]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k2658 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2660(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:192: gen */
t2=*((C_word*)lf[1]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[3],lf[70],((C_word*)t0)[2],lf[71],t1,C_make_character(41));}

/* k2616 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:183: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2584 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2589,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:176: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2587 in k2584 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:177: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[63]);}

/* k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2515,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2518,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:171: iota */
t4=*((C_word*)lf[60]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t3,((C_word*)t0)[6],C_fix(1),C_fix(1));}

/* k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2531,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2531(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop161 in k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2531(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2531,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2539,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2552,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g171172 */
t10=t6;
f_2539(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k2550 in loop161 in k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_2531(t4,((C_word*)t0)[2],t2,t3);}

/* g171 in loop161 in k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2539,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2543,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:168: gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,lf[58],t3,lf[59]);}

/* k2541 in g171 in loop161 in k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2543(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2543,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:169: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2544 in k2541 in g171 in loop161 in k2527 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:170: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(44));}

/* k2516 in k2513 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2518(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2518,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[3],C_fix(1));
/* c-backend.scm:172: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[2],lf[56],t2,lf[57]);}

/* k2481 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2483(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2483,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2486,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:158: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2484 in k2481 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:159: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[53]);}

/* k2487 in k2484 in k2481 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2492,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:160: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2490 in k2487 in k2484 in k2481 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:161: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2452 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2457,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:151: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2455 in k2452 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:152: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[50]);}

/* k2458 in k2455 in k2452 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2463,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:153: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2461 in k2458 in k2455 in k2452 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:154: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2415 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2417,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2420,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:144: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2061(t4,t2,t3,((C_word*)t0)[3]);}

/* k2418 in k2415 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2420(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2420,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2423,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
t4=C_a_i_plus(&a,2,t3,C_fix(1));
/* c-backend.scm:145: gen */
t5=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[46],t4,lf[47]);}

/* k2421 in k2418 in k2415 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2423,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2426,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:146: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2424 in k2421 in k2418 in k2415 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:147: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2382 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2384(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2384,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2387,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:137: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2061(t4,t2,t3,((C_word*)t0)[3]);}

/* k2385 in k2382 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2390,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* c-backend.scm:138: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t2,C_make_character(44),t3,C_make_character(44));}

/* k2388 in k2385 in k2382 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2390(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2390,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:139: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2391 in k2388 in k2385 in k2382 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:140: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(41));}

/* k2363 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2365(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2365,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2368,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:132: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2366 in k2363 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:133: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[41]);}

/* k2336 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2338(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2338,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2341,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:127: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2339 in k2336 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[3]);
t3=C_a_i_plus(&a,2,t2,C_fix(1));
/* c-backend.scm:128: gen */
t4=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[2],lf[38],t3,C_make_character(93));}

/* k2310 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2315,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* c-backend.scm:121: expr */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2313 in k2310 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2318,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:122: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(59));}

/* k2316 in k2313 in k2310 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
/* c-backend.scm:123: expr */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2061(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* loop in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2258(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2258,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_greaterp(t4,C_fix(0)))){
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2268,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t4,a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* c-backend.scm:112: gen */
t6=*((C_word*)lf[1]+1);
((C_proc6)(void*)(*((C_word*)t6+1)))(6,t6,t5,C_SCHEME_TRUE,C_make_character(116),t3,C_make_character(61));}
else{
t5=C_i_car(t2);
/* c-backend.scm:116: expr */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2061(t6,t1,t5,t3);}}

/* k2266 in loop in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2268,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2271,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[7]);
/* c-backend.scm:113: expr */
t4=((C_word*)((C_word*)t0)[2])[1];
f_2061(t4,t2,t3,((C_word*)t0)[6]);}

/* k2269 in k2266 in loop in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2271,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2274,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* c-backend.scm:114: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_make_character(59));}

/* k2272 in k2269 in k2266 in loop in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2274(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2274,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_plus(&a,2,((C_word*)t0)[5],C_fix(1));
t4=C_a_i_minus(&a,2,((C_word*)t0)[4],C_fix(1));
/* c-backend.scm:115: loop */
t5=((C_word*)((C_word*)t0)[3])[1];
f_2258(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2200,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* c-backend.scm:99: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2201 in k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2206,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:100: gen */
t3=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[31]);}

/* k2204 in k2201 in k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2209,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[4]);
/* c-backend.scm:101: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2207 in k2204 in k2201 in k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2212,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* c-backend.scm:102: gen */
t3=*((C_word*)lf[1]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,C_make_character(125),C_SCHEME_TRUE,lf[30]);}

/* k2210 in k2207 in k2204 in k2201 in k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2212,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2215,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_caddr(((C_word*)t0)[4]);
/* c-backend.scm:103: expr */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2061(t4,t2,t3,((C_word*)t0)[2]);}

/* k2213 in k2210 in k2207 in k2204 in k2201 in k2198 in expr in expression in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* c-backend.scm:104: gen */
t2=*((C_word*)lf[1]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_make_character(125));}

/* find-lambda in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_fcall f_2016(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2016,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2020,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2028,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:68: find */
t5=*((C_word*)lf[11]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}

/* a2027 in find-lambda in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2028(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2028,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2036,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* c-backend.scm:68: lambda-literal-id */
t4=*((C_word*)lf[10]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k2034 in a2027 in find-lambda in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[2],t1));}

/* k2018 in find-lambda in ##compiler#generate-code in k2009 in k1923 in k1920 */
static void C_ccall f_2020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* c-backend.scm:69: bomb */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[9],((C_word*)t0)[2]);}}

/* ##compiler#gen-list in k1923 in k1920 */
static void C_ccall f_1971(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1971,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1979,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* c-backend.scm:50: intersperse */
t4=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,C_make_character(32));}

/* k1977 in ##compiler#gen-list in k1923 in k1920 */
static void C_ccall f_1979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1979,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1981,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1981(t5,((C_word*)t0)[2],t1);}

/* loop35 in k1977 in ##compiler#gen-list in k1923 in k1920 */
static void C_fcall f_1981(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1981,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1996,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* c-backend.scm:49: display */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,*((C_word*)lf[0]+1));}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1994 in loop35 in k1977 in ##compiler#gen-list in k1923 in k1920 */
static void C_ccall f_1996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1981(t3,((C_word*)t0)[2],t2);}

/* ##compiler#gen in k1923 in k1920 */
static void C_ccall f_1928(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr2r,(void*)f_1928r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1928r(t0,t1,t2);}}

static void C_ccall f_1928r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(5);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1934,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_1934(t6,t1,t2);}

/* loop20 in ##compiler#gen in k1923 in k1920 */
static void C_fcall f_1934(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1934,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1958,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_eqp(C_SCHEME_TRUE,t4);
if(C_truep(t5)){
/* c-backend.scm:43: newline */
t6=*((C_word*)lf[2]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t3,*((C_word*)lf[0]+1));}
else{
/* c-backend.scm:44: display */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,*((C_word*)lf[0]+1));}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1956 in loop20 in ##compiler#gen in k1923 in k1920 */
static void C_ccall f_1958(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1934(t3,((C_word*)t0)[2],t2);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[796] = {
{"toplevel:c_backend_scm",(void*)C_backend_toplevel},
{"f_1922:c_backend_scm",(void*)f_1922},
{"f_1925:c_backend_scm",(void*)f_1925},
{"f_9737:c_backend_scm",(void*)f_9737},
{"f_9740:c_backend_scm",(void*)f_9740},
{"f_9767:c_backend_scm",(void*)f_9767},
{"f_9763:c_backend_scm",(void*)f_9763},
{"f_9743:c_backend_scm",(void*)f_9743},
{"f_9746:c_backend_scm",(void*)f_9746},
{"f_9759:c_backend_scm",(void*)f_9759},
{"f_9749:c_backend_scm",(void*)f_9749},
{"f_9752:c_backend_scm",(void*)f_9752},
{"f_9755:c_backend_scm",(void*)f_9755},
{"f_2011:c_backend_scm",(void*)f_2011},
{"f_9437:c_backend_scm",(void*)f_9437},
{"f_9713:c_backend_scm",(void*)f_9713},
{"f_9711:c_backend_scm",(void*)f_9711},
{"f_9699:c_backend_scm",(void*)f_9699},
{"f_9669:c_backend_scm",(void*)f_9669},
{"f_9630:c_backend_scm",(void*)f_9630},
{"f_9617:c_backend_scm",(void*)f_9617},
{"f_9613:c_backend_scm",(void*)f_9613},
{"f_9499:c_backend_scm",(void*)f_9499},
{"f_9446:c_backend_scm",(void*)f_9446},
{"f_8830:c_backend_scm",(void*)f_8830},
{"f_8941:c_backend_scm",(void*)f_8941},
{"f_9106:c_backend_scm",(void*)f_9106},
{"f_9133:c_backend_scm",(void*)f_9133},
{"f_9311:c_backend_scm",(void*)f_9311},
{"f_9314:c_backend_scm",(void*)f_9314},
{"f_9317:c_backend_scm",(void*)f_9317},
{"f_9320:c_backend_scm",(void*)f_9320},
{"f_9290:c_backend_scm",(void*)f_9290},
{"f_9293:c_backend_scm",(void*)f_9293},
{"f_9296:c_backend_scm",(void*)f_9296},
{"f_9299:c_backend_scm",(void*)f_9299},
{"f_9269:c_backend_scm",(void*)f_9269},
{"f_9272:c_backend_scm",(void*)f_9272},
{"f_9275:c_backend_scm",(void*)f_9275},
{"f_9278:c_backend_scm",(void*)f_9278},
{"f_9232:c_backend_scm",(void*)f_9232},
{"f_9235:c_backend_scm",(void*)f_9235},
{"f_9238:c_backend_scm",(void*)f_9238},
{"f_9241:c_backend_scm",(void*)f_9241},
{"f_9211:c_backend_scm",(void*)f_9211},
{"f_9214:c_backend_scm",(void*)f_9214},
{"f_9217:c_backend_scm",(void*)f_9217},
{"f_9220:c_backend_scm",(void*)f_9220},
{"f_9190:c_backend_scm",(void*)f_9190},
{"f_9193:c_backend_scm",(void*)f_9193},
{"f_9196:c_backend_scm",(void*)f_9196},
{"f_9199:c_backend_scm",(void*)f_9199},
{"f_9169:c_backend_scm",(void*)f_9169},
{"f_9172:c_backend_scm",(void*)f_9172},
{"f_9175:c_backend_scm",(void*)f_9175},
{"f_9178:c_backend_scm",(void*)f_9178},
{"f_9148:c_backend_scm",(void*)f_9148},
{"f_9151:c_backend_scm",(void*)f_9151},
{"f_9154:c_backend_scm",(void*)f_9154},
{"f_9157:c_backend_scm",(void*)f_9157},
{"f_9110:c_backend_scm",(void*)f_9110},
{"f_9076:c_backend_scm",(void*)f_9076},
{"f_9079:c_backend_scm",(void*)f_9079},
{"f_9082:c_backend_scm",(void*)f_9082},
{"f_9085:c_backend_scm",(void*)f_9085},
{"f_9055:c_backend_scm",(void*)f_9055},
{"f_9058:c_backend_scm",(void*)f_9058},
{"f_9061:c_backend_scm",(void*)f_9061},
{"f_9064:c_backend_scm",(void*)f_9064},
{"f_9034:c_backend_scm",(void*)f_9034},
{"f_9037:c_backend_scm",(void*)f_9037},
{"f_9040:c_backend_scm",(void*)f_9040},
{"f_9043:c_backend_scm",(void*)f_9043},
{"f_9010:c_backend_scm",(void*)f_9010},
{"f_9013:c_backend_scm",(void*)f_9013},
{"f_9016:c_backend_scm",(void*)f_9016},
{"f_9019:c_backend_scm",(void*)f_9019},
{"f_8989:c_backend_scm",(void*)f_8989},
{"f_8992:c_backend_scm",(void*)f_8992},
{"f_8995:c_backend_scm",(void*)f_8995},
{"f_8998:c_backend_scm",(void*)f_8998},
{"f_8965:c_backend_scm",(void*)f_8965},
{"f_8968:c_backend_scm",(void*)f_8968},
{"f_8971:c_backend_scm",(void*)f_8971},
{"f_8974:c_backend_scm",(void*)f_8974},
{"f_8944:c_backend_scm",(void*)f_8944},
{"f_8947:c_backend_scm",(void*)f_8947},
{"f_8950:c_backend_scm",(void*)f_8950},
{"f_8953:c_backend_scm",(void*)f_8953},
{"f_8920:c_backend_scm",(void*)f_8920},
{"f_8923:c_backend_scm",(void*)f_8923},
{"f_8926:c_backend_scm",(void*)f_8926},
{"f_8929:c_backend_scm",(void*)f_8929},
{"f_8899:c_backend_scm",(void*)f_8899},
{"f_8902:c_backend_scm",(void*)f_8902},
{"f_8905:c_backend_scm",(void*)f_8905},
{"f_8908:c_backend_scm",(void*)f_8908},
{"f_8832:c_backend_scm",(void*)f_8832},
{"f_8340:c_backend_scm",(void*)f_8340},
{"f_8370:c_backend_scm",(void*)f_8370},
{"f_8397:c_backend_scm",(void*)f_8397},
{"f_8592:c_backend_scm",(void*)f_8592},
{"f_8601:c_backend_scm",(void*)f_8601},
{"f_8610:c_backend_scm",(void*)f_8610},
{"f_8637:c_backend_scm",(void*)f_8637},
{"f_8714:c_backend_scm",(void*)f_8714},
{"f_8342:c_backend_scm",(void*)f_8342},
{"f_7456:c_backend_scm",(void*)f_7456},
{"f_7533:c_backend_scm",(void*)f_7533},
{"f_7635:c_backend_scm",(void*)f_7635},
{"f_7668:c_backend_scm",(void*)f_7668},
{"f_7764:c_backend_scm",(void*)f_7764},
{"f_7776:c_backend_scm",(void*)f_7776},
{"f_7791:c_backend_scm",(void*)f_7791},
{"f_7836:c_backend_scm",(void*)f_7836},
{"f_7853:c_backend_scm",(void*)f_7853},
{"f_7870:c_backend_scm",(void*)f_7870},
{"f_7909:c_backend_scm",(void*)f_7909},
{"f_7926:c_backend_scm",(void*)f_7926},
{"f_7943:c_backend_scm",(void*)f_7943},
{"f_7960:c_backend_scm",(void*)f_7960},
{"f_7977:c_backend_scm",(void*)f_7977},
{"f_7994:c_backend_scm",(void*)f_7994},
{"f_8011:c_backend_scm",(void*)f_8011},
{"f_8023:c_backend_scm",(void*)f_8023},
{"f_8030:c_backend_scm",(void*)f_8030},
{"f_8040:c_backend_scm",(void*)f_8040},
{"f_8080:c_backend_scm",(void*)f_8080},
{"f_8050:c_backend_scm",(void*)f_8050},
{"f_8038:c_backend_scm",(void*)f_8038},
{"f_8034:c_backend_scm",(void*)f_8034},
{"f_8001:c_backend_scm",(void*)f_8001},
{"f_7984:c_backend_scm",(void*)f_7984},
{"f_7967:c_backend_scm",(void*)f_7967},
{"f_7950:c_backend_scm",(void*)f_7950},
{"f_7933:c_backend_scm",(void*)f_7933},
{"f_7916:c_backend_scm",(void*)f_7916},
{"f_7881:c_backend_scm",(void*)f_7881},
{"f_7891:c_backend_scm",(void*)f_7891},
{"f_7889:c_backend_scm",(void*)f_7889},
{"f_7885:c_backend_scm",(void*)f_7885},
{"f_7877:c_backend_scm",(void*)f_7877},
{"f_7864:c_backend_scm",(void*)f_7864},
{"f_7847:c_backend_scm",(void*)f_7847},
{"f_7795:c_backend_scm",(void*)f_7795},
{"f_7463:c_backend_scm",(void*)f_7463},
{"f_7458:c_backend_scm",(void*)f_7458},
{"f_7391:c_backend_scm",(void*)f_7391},
{"f_7395:c_backend_scm",(void*)f_7395},
{"f_7398:c_backend_scm",(void*)f_7398},
{"f_7401:c_backend_scm",(void*)f_7401},
{"f_7404:c_backend_scm",(void*)f_7404},
{"f_7410:c_backend_scm",(void*)f_7410},
{"f_7454:c_backend_scm",(void*)f_7454},
{"f_7413:c_backend_scm",(void*)f_7413},
{"f_7421:c_backend_scm",(void*)f_7421},
{"f_7442:c_backend_scm",(void*)f_7442},
{"f_7425:c_backend_scm",(void*)f_7425},
{"f_7416:c_backend_scm",(void*)f_7416},
{"f_6897:c_backend_scm",(void*)f_6897},
{"f_6903:c_backend_scm",(void*)f_6903},
{"f_7378:c_backend_scm",(void*)f_7378},
{"f_6911:c_backend_scm",(void*)f_6911},
{"f_6915:c_backend_scm",(void*)f_6915},
{"f_6918:c_backend_scm",(void*)f_6918},
{"f_6921:c_backend_scm",(void*)f_6921},
{"f_6924:c_backend_scm",(void*)f_6924},
{"f_6930:c_backend_scm",(void*)f_6930},
{"f_7276:c_backend_scm",(void*)f_7276},
{"f_7279:c_backend_scm",(void*)f_7279},
{"f_7375:c_backend_scm",(void*)f_7375},
{"f_7282:c_backend_scm",(void*)f_7282},
{"f_7285:c_backend_scm",(void*)f_7285},
{"f_7288:c_backend_scm",(void*)f_7288},
{"f_7291:c_backend_scm",(void*)f_7291},
{"f_7324:c_backend_scm",(void*)f_7324},
{"f_7340:c_backend_scm",(void*)f_7340},
{"f_7343:c_backend_scm",(void*)f_7343},
{"f_7294:c_backend_scm",(void*)f_7294},
{"f_7322:c_backend_scm",(void*)f_7322},
{"f_7297:c_backend_scm",(void*)f_7297},
{"f_7300:c_backend_scm",(void*)f_7300},
{"f_7303:c_backend_scm",(void*)f_7303},
{"f_6932:c_backend_scm",(void*)f_6932},
{"f_6942:c_backend_scm",(void*)f_6942},
{"f_6951:c_backend_scm",(void*)f_6951},
{"f_6963:c_backend_scm",(void*)f_6963},
{"f_6975:c_backend_scm",(void*)f_6975},
{"f_6981:c_backend_scm",(void*)f_6981},
{"f_7020:c_backend_scm",(void*)f_7020},
{"f_6985:c_backend_scm",(void*)f_6985},
{"f_6583:c_backend_scm",(void*)f_6583},
{"f_6589:c_backend_scm",(void*)f_6589},
{"f_6884:c_backend_scm",(void*)f_6884},
{"f_6597:c_backend_scm",(void*)f_6597},
{"f_6601:c_backend_scm",(void*)f_6601},
{"f_6604:c_backend_scm",(void*)f_6604},
{"f_6607:c_backend_scm",(void*)f_6607},
{"f_6881:c_backend_scm",(void*)f_6881},
{"f_6613:c_backend_scm",(void*)f_6613},
{"f_6616:c_backend_scm",(void*)f_6616},
{"f_6619:c_backend_scm",(void*)f_6619},
{"f_6622:c_backend_scm",(void*)f_6622},
{"f_6625:c_backend_scm",(void*)f_6625},
{"f_6628:c_backend_scm",(void*)f_6628},
{"f_6631:c_backend_scm",(void*)f_6631},
{"f_6634:c_backend_scm",(void*)f_6634},
{"f_6637:c_backend_scm",(void*)f_6637},
{"f_6640:c_backend_scm",(void*)f_6640},
{"f_6870:c_backend_scm",(void*)f_6870},
{"f_6643:c_backend_scm",(void*)f_6643},
{"f_6646:c_backend_scm",(void*)f_6646},
{"f_6649:c_backend_scm",(void*)f_6649},
{"f_6652:c_backend_scm",(void*)f_6652},
{"f_6655:c_backend_scm",(void*)f_6655},
{"f_6658:c_backend_scm",(void*)f_6658},
{"f_6661:c_backend_scm",(void*)f_6661},
{"f_6664:c_backend_scm",(void*)f_6664},
{"f_6761:c_backend_scm",(void*)f_6761},
{"f_6763:c_backend_scm",(void*)f_6763},
{"f_6770:c_backend_scm",(void*)f_6770},
{"f_6797:c_backend_scm",(void*)f_6797},
{"f_6800:c_backend_scm",(void*)f_6800},
{"f_6803:c_backend_scm",(void*)f_6803},
{"f_6791:c_backend_scm",(void*)f_6791},
{"f_6779:c_backend_scm",(void*)f_6779},
{"f_6783:c_backend_scm",(void*)f_6783},
{"f_6787:c_backend_scm",(void*)f_6787},
{"f_6809:c_backend_scm",(void*)f_6809},
{"f_6667:c_backend_scm",(void*)f_6667},
{"f_6670:c_backend_scm",(void*)f_6670},
{"f_6700:c_backend_scm",(void*)f_6700},
{"f_6703:c_backend_scm",(void*)f_6703},
{"f_6741:c_backend_scm",(void*)f_6741},
{"f_6737:c_backend_scm",(void*)f_6737},
{"f_6706:c_backend_scm",(void*)f_6706},
{"f_6709:c_backend_scm",(void*)f_6709},
{"f_6712:c_backend_scm",(void*)f_6712},
{"f_6679:c_backend_scm",(void*)f_6679},
{"f_6682:c_backend_scm",(void*)f_6682},
{"f_6673:c_backend_scm",(void*)f_6673},
{"f_6543:c_backend_scm",(void*)f_6543},
{"f_6549:c_backend_scm",(void*)f_6549},
{"f_6561:c_backend_scm",(void*)f_6561},
{"f_6564:c_backend_scm",(void*)f_6564},
{"f_6570:c_backend_scm",(void*)f_6570},
{"f_6489:c_backend_scm",(void*)f_6489},
{"f_6493:c_backend_scm",(void*)f_6493},
{"f_6498:c_backend_scm",(void*)f_6498},
{"f_6527:c_backend_scm",(void*)f_6527},
{"f_6530:c_backend_scm",(void*)f_6530},
{"f_6473:c_backend_scm",(void*)f_6473},
{"f_6479:c_backend_scm",(void*)f_6479},
{"f_6487:c_backend_scm",(void*)f_6487},
{"f_6457:c_backend_scm",(void*)f_6457},
{"f_6463:c_backend_scm",(void*)f_6463},
{"f_6471:c_backend_scm",(void*)f_6471},
{"f_6368:c_backend_scm",(void*)f_6368},
{"f_6377:c_backend_scm",(void*)f_6377},
{"f_6406:c_backend_scm",(void*)f_6406},
{"f_6416:c_backend_scm",(void*)f_6416},
{"f_6291:c_backend_scm",(void*)f_6291},
{"f_6295:c_backend_scm",(void*)f_6295},
{"f_6309:c_backend_scm",(void*)f_6309},
{"f_6322:c_backend_scm",(void*)f_6322},
{"f_6354:c_backend_scm",(void*)f_6354},
{"f_6325:c_backend_scm",(void*)f_6325},
{"f_6328:c_backend_scm",(void*)f_6328},
{"f_6298:c_backend_scm",(void*)f_6298},
{"f_6301:c_backend_scm",(void*)f_6301},
{"f_6304:c_backend_scm",(void*)f_6304},
{"f_2013:c_backend_scm",(void*)f_2013},
{"f_6258:c_backend_scm",(void*)f_6258},
{"f_6262:c_backend_scm",(void*)f_6262},
{"f_6265:c_backend_scm",(void*)f_6265},
{"f_6268:c_backend_scm",(void*)f_6268},
{"f_6271:c_backend_scm",(void*)f_6271},
{"f_6274:c_backend_scm",(void*)f_6274},
{"f_6277:c_backend_scm",(void*)f_6277},
{"f_6280:c_backend_scm",(void*)f_6280},
{"f_6283:c_backend_scm",(void*)f_6283},
{"f_6286:c_backend_scm",(void*)f_6286},
{"f_5473:c_backend_scm",(void*)f_5473},
{"f_5479:c_backend_scm",(void*)f_5479},
{"f_6244:c_backend_scm",(void*)f_6244},
{"f_5487:c_backend_scm",(void*)f_5487},
{"f_5491:c_backend_scm",(void*)f_5491},
{"f_5494:c_backend_scm",(void*)f_5494},
{"f_5497:c_backend_scm",(void*)f_5497},
{"f_5500:c_backend_scm",(void*)f_5500},
{"f_5503:c_backend_scm",(void*)f_5503},
{"f_5506:c_backend_scm",(void*)f_5506},
{"f_6241:c_backend_scm",(void*)f_6241},
{"f_5509:c_backend_scm",(void*)f_5509},
{"f_5515:c_backend_scm",(void*)f_5515},
{"f_5518:c_backend_scm",(void*)f_5518},
{"f_5521:c_backend_scm",(void*)f_5521},
{"f_5524:c_backend_scm",(void*)f_5524},
{"f_5527:c_backend_scm",(void*)f_5527},
{"f_5530:c_backend_scm",(void*)f_5530},
{"f_5533:c_backend_scm",(void*)f_5533},
{"f_5536:c_backend_scm",(void*)f_5536},
{"f_5539:c_backend_scm",(void*)f_5539},
{"f_5542:c_backend_scm",(void*)f_5542},
{"f_5545:c_backend_scm",(void*)f_5545},
{"f_5548:c_backend_scm",(void*)f_5548},
{"f_5551:c_backend_scm",(void*)f_5551},
{"f_6210:c_backend_scm",(void*)f_6210},
{"f_5554:c_backend_scm",(void*)f_5554},
{"f_6171:c_backend_scm",(void*)f_6171},
{"f_6174:c_backend_scm",(void*)f_6174},
{"f_6177:c_backend_scm",(void*)f_6177},
{"f_6193:c_backend_scm",(void*)f_6193},
{"f_6196:c_backend_scm",(void*)f_6196},
{"f_5557:c_backend_scm",(void*)f_5557},
{"f_5560:c_backend_scm",(void*)f_5560},
{"f_5563:c_backend_scm",(void*)f_5563},
{"f_6143:c_backend_scm",(void*)f_6143},
{"f_6146:c_backend_scm",(void*)f_6146},
{"f_5566:c_backend_scm",(void*)f_5566},
{"f_5569:c_backend_scm",(void*)f_5569},
{"f_5572:c_backend_scm",(void*)f_5572},
{"f_5575:c_backend_scm",(void*)f_5575},
{"f_5578:c_backend_scm",(void*)f_5578},
{"f_5581:c_backend_scm",(void*)f_5581},
{"f_6103:c_backend_scm",(void*)f_6103},
{"f_6105:c_backend_scm",(void*)f_6105},
{"f_6115:c_backend_scm",(void*)f_6115},
{"f_6056:c_backend_scm",(void*)f_6056},
{"f_6061:c_backend_scm",(void*)f_6061},
{"f_6077:c_backend_scm",(void*)f_6077},
{"f_6088:c_backend_scm",(void*)f_6088},
{"f_5584:c_backend_scm",(void*)f_5584},
{"f_6017:c_backend_scm",(void*)f_6017},
{"f_6029:c_backend_scm",(void*)f_6029},
{"f_6020:c_backend_scm",(void*)f_6020},
{"f_5927:c_backend_scm",(void*)f_5927},
{"f_5969:c_backend_scm",(void*)f_5969},
{"f_5930:c_backend_scm",(void*)f_5930},
{"f_5936:c_backend_scm",(void*)f_5936},
{"f_5939:c_backend_scm",(void*)f_5939},
{"f_5863:c_backend_scm",(void*)f_5863},
{"f_5866:c_backend_scm",(void*)f_5866},
{"f_5869:c_backend_scm",(void*)f_5869},
{"f_5872:c_backend_scm",(void*)f_5872},
{"f_5875:c_backend_scm",(void*)f_5875},
{"f_5890:c_backend_scm",(void*)f_5890},
{"f_5878:c_backend_scm",(void*)f_5878},
{"f_5881:c_backend_scm",(void*)f_5881},
{"f_5849:c_backend_scm",(void*)f_5849},
{"f_5857:c_backend_scm",(void*)f_5857},
{"f_5774:c_backend_scm",(void*)f_5774},
{"f_5780:c_backend_scm",(void*)f_5780},
{"f_5783:c_backend_scm",(void*)f_5783},
{"f_5817:c_backend_scm",(void*)f_5817},
{"f_5820:c_backend_scm",(void*)f_5820},
{"f_5823:c_backend_scm",(void*)f_5823},
{"f_5786:c_backend_scm",(void*)f_5786},
{"f_5789:c_backend_scm",(void*)f_5789},
{"f_5792:c_backend_scm",(void*)f_5792},
{"f_5795:c_backend_scm",(void*)f_5795},
{"f_5804:c_backend_scm",(void*)f_5804},
{"f_5807:c_backend_scm",(void*)f_5807},
{"f_5587:c_backend_scm",(void*)f_5587},
{"f_5610:c_backend_scm",(void*)f_5610},
{"f_5715:c_backend_scm",(void*)f_5715},
{"f_5718:c_backend_scm",(void*)f_5718},
{"f_5730:c_backend_scm",(void*)f_5730},
{"f_5721:c_backend_scm",(void*)f_5721},
{"f_5616:c_backend_scm",(void*)f_5616},
{"f_5619:c_backend_scm",(void*)f_5619},
{"f_5702:c_backend_scm",(void*)f_5702},
{"f_5622:c_backend_scm",(void*)f_5622},
{"f_5625:c_backend_scm",(void*)f_5625},
{"f_5628:c_backend_scm",(void*)f_5628},
{"f_5631:c_backend_scm",(void*)f_5631},
{"f_5696:c_backend_scm",(void*)f_5696},
{"f_5692:c_backend_scm",(void*)f_5692},
{"f_5634:c_backend_scm",(void*)f_5634},
{"f_5637:c_backend_scm",(void*)f_5637},
{"f_5640:c_backend_scm",(void*)f_5640},
{"f_5643:c_backend_scm",(void*)f_5643},
{"f_5646:c_backend_scm",(void*)f_5646},
{"f_5649:c_backend_scm",(void*)f_5649},
{"f_5667:c_backend_scm",(void*)f_5667},
{"f_5677:c_backend_scm",(void*)f_5677},
{"f_5652:c_backend_scm",(void*)f_5652},
{"f_5590:c_backend_scm",(void*)f_5590},
{"f_5600:c_backend_scm",(void*)f_5600},
{"f_5593:c_backend_scm",(void*)f_5593},
{"f_5425:c_backend_scm",(void*)f_5425},
{"f_5432:c_backend_scm",(void*)f_5432},
{"f_5435:c_backend_scm",(void*)f_5435},
{"f_5348:c_backend_scm",(void*)f_5348},
{"f_5355:c_backend_scm",(void*)f_5355},
{"f_5358:c_backend_scm",(void*)f_5358},
{"f_5363:c_backend_scm",(void*)f_5363},
{"f_5419:c_backend_scm",(void*)f_5419},
{"f_5415:c_backend_scm",(void*)f_5415},
{"f_5400:c_backend_scm",(void*)f_5400},
{"f_5379:c_backend_scm",(void*)f_5379},
{"f_5390:c_backend_scm",(void*)f_5390},
{"f_5386:c_backend_scm",(void*)f_5386},
{"f_5206:c_backend_scm",(void*)f_5206},
{"f_5346:c_backend_scm",(void*)f_5346},
{"f_5213:c_backend_scm",(void*)f_5213},
{"f_5219:c_backend_scm",(void*)f_5219},
{"f_5302:c_backend_scm",(void*)f_5302},
{"f_5305:c_backend_scm",(void*)f_5305},
{"f_5315:c_backend_scm",(void*)f_5315},
{"f_5308:c_backend_scm",(void*)f_5308},
{"f_5269:c_backend_scm",(void*)f_5269},
{"f_5275:c_backend_scm",(void*)f_5275},
{"f_5012:c_backend_scm",(void*)f_5012},
{"f_5019:c_backend_scm",(void*)f_5019},
{"f_5128:c_backend_scm",(void*)f_5128},
{"f_5146:c_backend_scm",(void*)f_5146},
{"f_5175:c_backend_scm",(void*)f_5175},
{"f_5197:c_backend_scm",(void*)f_5197},
{"f_5153:c_backend_scm",(void*)f_5153},
{"f_5087:c_backend_scm",(void*)f_5087},
{"f_5089:c_backend_scm",(void*)f_5089},
{"f_5118:c_backend_scm",(void*)f_5118},
{"f_5083:c_backend_scm",(void*)f_5083},
{"f_5079:c_backend_scm",(void*)f_5079},
{"f_5050:c_backend_scm",(void*)f_5050},
{"f_5054:c_backend_scm",(void*)f_5054},
{"f_4957:c_backend_scm",(void*)f_4957},
{"f_4963:c_backend_scm",(void*)f_4963},
{"f_4992:c_backend_scm",(void*)f_4992},
{"f_4995:c_backend_scm",(void*)f_4995},
{"f_4998:c_backend_scm",(void*)f_4998},
{"f_5001:c_backend_scm",(void*)f_5001},
{"f_5004:c_backend_scm",(void*)f_5004},
{"f_4973:c_backend_scm",(void*)f_4973},
{"f_4637:c_backend_scm",(void*)f_4637},
{"f_4826:c_backend_scm",(void*)f_4826},
{"f_4944:c_backend_scm",(void*)f_4944},
{"f_4834:c_backend_scm",(void*)f_4834},
{"f_4838:c_backend_scm",(void*)f_4838},
{"f_4841:c_backend_scm",(void*)f_4841},
{"f_4844:c_backend_scm",(void*)f_4844},
{"f_4847:c_backend_scm",(void*)f_4847},
{"f_4850:c_backend_scm",(void*)f_4850},
{"f_4941:c_backend_scm",(void*)f_4941},
{"f_4853:c_backend_scm",(void*)f_4853},
{"f_4856:c_backend_scm",(void*)f_4856},
{"f_4862:c_backend_scm",(void*)f_4862},
{"f_4930:c_backend_scm",(void*)f_4930},
{"f_4896:c_backend_scm",(void*)f_4896},
{"f_4902:c_backend_scm",(void*)f_4902},
{"f_4910:c_backend_scm",(void*)f_4910},
{"f_4906:c_backend_scm",(void*)f_4906},
{"f_4868:c_backend_scm",(void*)f_4868},
{"f_4871:c_backend_scm",(void*)f_4871},
{"f_4874:c_backend_scm",(void*)f_4874},
{"f_4877:c_backend_scm",(void*)f_4877},
{"f_4880:c_backend_scm",(void*)f_4880},
{"f_4890:c_backend_scm",(void*)f_4890},
{"f_4883:c_backend_scm",(void*)f_4883},
{"f_4756:c_backend_scm",(void*)f_4756},
{"f_4775:c_backend_scm",(void*)f_4775},
{"f_4813:c_backend_scm",(void*)f_4813},
{"f_4783:c_backend_scm",(void*)f_4783},
{"f_4787:c_backend_scm",(void*)f_4787},
{"f_4790:c_backend_scm",(void*)f_4790},
{"f_4793:c_backend_scm",(void*)f_4793},
{"f_4796:c_backend_scm",(void*)f_4796},
{"f_4810:c_backend_scm",(void*)f_4810},
{"f_4806:c_backend_scm",(void*)f_4806},
{"f_4799:c_backend_scm",(void*)f_4799},
{"f_4759:c_backend_scm",(void*)f_4759},
{"f_4773:c_backend_scm",(void*)f_4773},
{"f_4762:c_backend_scm",(void*)f_4762},
{"f_4769:c_backend_scm",(void*)f_4769},
{"f_4676:c_backend_scm",(void*)f_4676},
{"f_4678:c_backend_scm",(void*)f_4678},
{"f_4682:c_backend_scm",(void*)f_4682},
{"f_4685:c_backend_scm",(void*)f_4685},
{"f_4688:c_backend_scm",(void*)f_4688},
{"f_4691:c_backend_scm",(void*)f_4691},
{"f_4694:c_backend_scm",(void*)f_4694},
{"f_4697:c_backend_scm",(void*)f_4697},
{"f_4700:c_backend_scm",(void*)f_4700},
{"f_4703:c_backend_scm",(void*)f_4703},
{"f_4706:c_backend_scm",(void*)f_4706},
{"f_4709:c_backend_scm",(void*)f_4709},
{"f_4712:c_backend_scm",(void*)f_4712},
{"f_4715:c_backend_scm",(void*)f_4715},
{"f_4729:c_backend_scm",(void*)f_4729},
{"f_4725:c_backend_scm",(void*)f_4725},
{"f_4718:c_backend_scm",(void*)f_4718},
{"f_4640:c_backend_scm",(void*)f_4640},
{"f_4653:c_backend_scm",(void*)f_4653},
{"f_4663:c_backend_scm",(void*)f_4663},
{"f_4644:c_backend_scm",(void*)f_4644},
{"f_4303:c_backend_scm",(void*)f_4303},
{"f_4307:c_backend_scm",(void*)f_4307},
{"f_4376:c_backend_scm",(void*)f_4376},
{"f_4624:c_backend_scm",(void*)f_4624},
{"f_4384:c_backend_scm",(void*)f_4384},
{"f_4388:c_backend_scm",(void*)f_4388},
{"f_4391:c_backend_scm",(void*)f_4391},
{"f_4621:c_backend_scm",(void*)f_4621},
{"f_4394:c_backend_scm",(void*)f_4394},
{"f_4607:c_backend_scm",(void*)f_4607},
{"f_4397:c_backend_scm",(void*)f_4397},
{"f_4400:c_backend_scm",(void*)f_4400},
{"f_4403:c_backend_scm",(void*)f_4403},
{"f_4406:c_backend_scm",(void*)f_4406},
{"f_4409:c_backend_scm",(void*)f_4409},
{"f_4412:c_backend_scm",(void*)f_4412},
{"f_4599:c_backend_scm",(void*)f_4599},
{"f_4415:c_backend_scm",(void*)f_4415},
{"f_4418:c_backend_scm",(void*)f_4418},
{"f_4553:c_backend_scm",(void*)f_4553},
{"f_4555:c_backend_scm",(void*)f_4555},
{"f_4581:c_backend_scm",(void*)f_4581},
{"f_4563:c_backend_scm",(void*)f_4563},
{"f_4574:c_backend_scm",(void*)f_4574},
{"f_4421:c_backend_scm",(void*)f_4421},
{"f_4508:c_backend_scm",(void*)f_4508},
{"f_4511:c_backend_scm",(void*)f_4511},
{"f_4514:c_backend_scm",(void*)f_4514},
{"f_4517:c_backend_scm",(void*)f_4517},
{"f_4533:c_backend_scm",(void*)f_4533},
{"f_4536:c_backend_scm",(void*)f_4536},
{"f_4539:c_backend_scm",(void*)f_4539},
{"f_4424:c_backend_scm",(void*)f_4424},
{"f_4427:c_backend_scm",(void*)f_4427},
{"f_4430:c_backend_scm",(void*)f_4430},
{"f_4480:c_backend_scm",(void*)f_4480},
{"f_4483:c_backend_scm",(void*)f_4483},
{"f_4433:c_backend_scm",(void*)f_4433},
{"f_4436:c_backend_scm",(void*)f_4436},
{"f_4468:c_backend_scm",(void*)f_4468},
{"f_4471:c_backend_scm",(void*)f_4471},
{"f_4442:c_backend_scm",(void*)f_4442},
{"f_4451:c_backend_scm",(void*)f_4451},
{"f_4454:c_backend_scm",(void*)f_4454},
{"f_4310:c_backend_scm",(void*)f_4310},
{"f_4315:c_backend_scm",(void*)f_4315},
{"f_4327:c_backend_scm",(void*)f_4327},
{"f_4337:c_backend_scm",(void*)f_4337},
{"f_4339:c_backend_scm",(void*)f_4339},
{"f_4349:c_backend_scm",(void*)f_4349},
{"f_4330:c_backend_scm",(void*)f_4330},
{"f_4363:c_backend_scm",(void*)f_4363},
{"f_4132:c_backend_scm",(void*)f_4132},
{"f_4139:c_backend_scm",(void*)f_4139},
{"f_4275:c_backend_scm",(void*)f_4275},
{"f_4290:c_backend_scm",(void*)f_4290},
{"f_4142:c_backend_scm",(void*)f_4142},
{"f_4145:c_backend_scm",(void*)f_4145},
{"f_4148:c_backend_scm",(void*)f_4148},
{"f_4153:c_backend_scm",(void*)f_4153},
{"f_4163:c_backend_scm",(void*)f_4163},
{"f_4169:c_backend_scm",(void*)f_4169},
{"f_4222:c_backend_scm",(void*)f_4222},
{"f_4232:c_backend_scm",(void*)f_4232},
{"f_4172:c_backend_scm",(void*)f_4172},
{"f_4195:c_backend_scm",(void*)f_4195},
{"f_4205:c_backend_scm",(void*)f_4205},
{"f_4175:c_backend_scm",(void*)f_4175},
{"f_4178:c_backend_scm",(void*)f_4178},
{"f_3963:c_backend_scm",(void*)f_3963},
{"f_4124:c_backend_scm",(void*)f_4124},
{"f_3983:c_backend_scm",(void*)f_3983},
{"f_4082:c_backend_scm",(void*)f_4082},
{"f_4086:c_backend_scm",(void*)f_4086},
{"f_4090:c_backend_scm",(void*)f_4090},
{"f_4094:c_backend_scm",(void*)f_4094},
{"f_4116:c_backend_scm",(void*)f_4116},
{"f_4112:c_backend_scm",(void*)f_4112},
{"f_4104:c_backend_scm",(void*)f_4104},
{"f_4102:c_backend_scm",(void*)f_4102},
{"f_4098:c_backend_scm",(void*)f_4098},
{"f_4001:c_backend_scm",(void*)f_4001},
{"f_4004:c_backend_scm",(void*)f_4004},
{"f_4007:c_backend_scm",(void*)f_4007},
{"f_4071:c_backend_scm",(void*)f_4071},
{"f_4010:c_backend_scm",(void*)f_4010},
{"f_4013:c_backend_scm",(void*)f_4013},
{"f_4016:c_backend_scm",(void*)f_4016},
{"f_4031:c_backend_scm",(void*)f_4031},
{"f_4036:c_backend_scm",(void*)f_4036},
{"f_4051:c_backend_scm",(void*)f_4051},
{"f_4019:c_backend_scm",(void*)f_4019},
{"f_3966:c_backend_scm",(void*)f_3966},
{"f_3980:c_backend_scm",(void*)f_3980},
{"f_2058:c_backend_scm",(void*)f_2058},
{"f_3931:c_backend_scm",(void*)f_3931},
{"f_3937:c_backend_scm",(void*)f_3937},
{"f_3941:c_backend_scm",(void*)f_3941},
{"f_2061:c_backend_scm",(void*)f_2061},
{"f_3887:c_backend_scm",(void*)f_3887},
{"f_3890:c_backend_scm",(void*)f_3890},
{"f_3893:c_backend_scm",(void*)f_3893},
{"f_3896:c_backend_scm",(void*)f_3896},
{"f_3899:c_backend_scm",(void*)f_3899},
{"f_3902:c_backend_scm",(void*)f_3902},
{"f_3804:c_backend_scm",(void*)f_3804},
{"f_3807:c_backend_scm",(void*)f_3807},
{"f_3810:c_backend_scm",(void*)f_3810},
{"f_3823:c_backend_scm",(void*)f_3823},
{"f_3846:c_backend_scm",(void*)f_3846},
{"f_3849:c_backend_scm",(void*)f_3849},
{"f_3852:c_backend_scm",(void*)f_3852},
{"f_3855:c_backend_scm",(void*)f_3855},
{"f_3833:c_backend_scm",(void*)f_3833},
{"f_3836:c_backend_scm",(void*)f_3836},
{"f_3785:c_backend_scm",(void*)f_3785},
{"f_3788:c_backend_scm",(void*)f_3788},
{"f_3762:c_backend_scm",(void*)f_3762},
{"f_3765:c_backend_scm",(void*)f_3765},
{"f_3740:c_backend_scm",(void*)f_3740},
{"f_3712:c_backend_scm",(void*)f_3712},
{"f_3715:c_backend_scm",(void*)f_3715},
{"f_3732:c_backend_scm",(void*)f_3732},
{"f_3718:c_backend_scm",(void*)f_3718},
{"f_3721:c_backend_scm",(void*)f_3721},
{"f_3696:c_backend_scm",(void*)f_3696},
{"f_3700:c_backend_scm",(void*)f_3700},
{"f_3682:c_backend_scm",(void*)f_3682},
{"f_3685:c_backend_scm",(void*)f_3685},
{"f_3666:c_backend_scm",(void*)f_3666},
{"f_3670:c_backend_scm",(void*)f_3670},
{"f_3648:c_backend_scm",(void*)f_3648},
{"f_3651:c_backend_scm",(void*)f_3651},
{"f_3628:c_backend_scm",(void*)f_3628},
{"f_3592:c_backend_scm",(void*)f_3592},
{"f_3604:c_backend_scm",(void*)f_3604},
{"f_3595:c_backend_scm",(void*)f_3595},
{"f_3573:c_backend_scm",(void*)f_3573},
{"f_3576:c_backend_scm",(void*)f_3576},
{"f_3554:c_backend_scm",(void*)f_3554},
{"f_3557:c_backend_scm",(void*)f_3557},
{"f_3535:c_backend_scm",(void*)f_3535},
{"f_3538:c_backend_scm",(void*)f_3538},
{"f_3516:c_backend_scm",(void*)f_3516},
{"f_3512:c_backend_scm",(void*)f_3512},
{"f_3460:c_backend_scm",(void*)f_3460},
{"f_3493:c_backend_scm",(void*)f_3493},
{"f_3463:c_backend_scm",(void*)f_3463},
{"f_3481:c_backend_scm",(void*)f_3481},
{"f_3466:c_backend_scm",(void*)f_3466},
{"f_3469:c_backend_scm",(void*)f_3469},
{"f_3427:c_backend_scm",(void*)f_3427},
{"f_3411:c_backend_scm",(void*)f_3411},
{"f10580:c_backend_scm",(void*)f10580},
{"f_3414:c_backend_scm",(void*)f_3414},
{"f_3417:c_backend_scm",(void*)f_3417},
{"f_3298:c_backend_scm",(void*)f_3298},
{"f_3301:c_backend_scm",(void*)f_3301},
{"f_3358:c_backend_scm",(void*)f_3358},
{"f_3379:c_backend_scm",(void*)f_3379},
{"f_3366:c_backend_scm",(void*)f_3366},
{"f_3370:c_backend_scm",(void*)f_3370},
{"f_3373:c_backend_scm",(void*)f_3373},
{"f_3304:c_backend_scm",(void*)f_3304},
{"f_3314:c_backend_scm",(void*)f_3314},
{"f_3316:c_backend_scm",(void*)f_3316},
{"f_3331:c_backend_scm",(void*)f_3331},
{"f_3307:c_backend_scm",(void*)f_3307},
{"f_2815:c_backend_scm",(void*)f_2815},
{"f_2818:c_backend_scm",(void*)f_2818},
{"f_3248:c_backend_scm",(void*)f_3248},
{"f_3244:c_backend_scm",(void*)f_3244},
{"f_2824:c_backend_scm",(void*)f_2824},
{"f10572:c_backend_scm",(void*)f10572},
{"f_3237:c_backend_scm",(void*)f_3237},
{"f_2046:c_backend_scm",(void*)f_2046},
{"f_3230:c_backend_scm",(void*)f_3230},
{"f_2830:c_backend_scm",(void*)f_2830},
{"f_3034:c_backend_scm",(void*)f_3034},
{"f_3147:c_backend_scm",(void*)f_3147},
{"f_3150:c_backend_scm",(void*)f_3150},
{"f_3153:c_backend_scm",(void*)f_3153},
{"f_3168:c_backend_scm",(void*)f_3168},
{"f_3156:c_backend_scm",(void*)f_3156},
{"f_3159:c_backend_scm",(void*)f_3159},
{"f_3162:c_backend_scm",(void*)f_3162},
{"f_3054:c_backend_scm",(void*)f_3054},
{"f_3144:c_backend_scm",(void*)f_3144},
{"f_3137:c_backend_scm",(void*)f_3137},
{"f_3133:c_backend_scm",(void*)f_3133},
{"f_3126:c_backend_scm",(void*)f_3126},
{"f_3119:c_backend_scm",(void*)f_3119},
{"f_3094:c_backend_scm",(void*)f_3094},
{"f_3111:c_backend_scm",(void*)f_3111},
{"f_3107:c_backend_scm",(void*)f_3107},
{"f_3087:c_backend_scm",(void*)f_3087},
{"f_3080:c_backend_scm",(void*)f_3080},
{"f_3070:c_backend_scm",(void*)f_3070},
{"f_3057:c_backend_scm",(void*)f_3057},
{"f_3060:c_backend_scm",(void*)f_3060},
{"f_3063:c_backend_scm",(void*)f_3063},
{"f_3028:c_backend_scm",(void*)f_3028},
{"f_2866:c_backend_scm",(void*)f_2866},
{"f_3012:c_backend_scm",(void*)f_3012},
{"f_3015:c_backend_scm",(void*)f_3015},
{"f_2988:c_backend_scm",(void*)f_2988},
{"f_2991:c_backend_scm",(void*)f_2991},
{"f_2994:c_backend_scm",(void*)f_2994},
{"f10567:c_backend_scm",(void*)f10567},
{"f_2997:c_backend_scm",(void*)f_2997},
{"f_3000:c_backend_scm",(void*)f_3000},
{"f_2869:c_backend_scm",(void*)f_2869},
{"f_2872:c_backend_scm",(void*)f_2872},
{"f_2935:c_backend_scm",(void*)f_2935},
{"f_2956:c_backend_scm",(void*)f_2956},
{"f_2943:c_backend_scm",(void*)f_2943},
{"f_2947:c_backend_scm",(void*)f_2947},
{"f_2950:c_backend_scm",(void*)f_2950},
{"f_2875:c_backend_scm",(void*)f_2875},
{"f_2891:c_backend_scm",(void*)f_2891},
{"f_2893:c_backend_scm",(void*)f_2893},
{"f_2908:c_backend_scm",(void*)f_2908},
{"f_2878:c_backend_scm",(void*)f_2878},
{"f_2881:c_backend_scm",(void*)f_2881},
{"f_2847:c_backend_scm",(void*)f_2847},
{"f_2850:c_backend_scm",(void*)f_2850},
{"f_2782:c_backend_scm",(void*)f_2782},
{"f10559:c_backend_scm",(void*)f10559},
{"f_2778:c_backend_scm",(void*)f_2778},
{"f_2764:c_backend_scm",(void*)f_2764},
{"f_2767:c_backend_scm",(void*)f_2767},
{"f_2761:c_backend_scm",(void*)f_2761},
{"f10554:c_backend_scm",(void*)f10554},
{"f_2757:c_backend_scm",(void*)f_2757},
{"f_2743:c_backend_scm",(void*)f_2743},
{"f_2746:c_backend_scm",(void*)f_2746},
{"f_2695:c_backend_scm",(void*)f_2695},
{"f_2716:c_backend_scm",(void*)f_2716},
{"f10549:c_backend_scm",(void*)f10549},
{"f_2712:c_backend_scm",(void*)f_2712},
{"f_2698:c_backend_scm",(void*)f_2698},
{"f_2701:c_backend_scm",(void*)f_2701},
{"f_2664:c_backend_scm",(void*)f_2664},
{"f_2660:c_backend_scm",(void*)f_2660},
{"f_2618:c_backend_scm",(void*)f_2618},
{"f_2586:c_backend_scm",(void*)f_2586},
{"f_2589:c_backend_scm",(void*)f_2589},
{"f_2515:c_backend_scm",(void*)f_2515},
{"f_2529:c_backend_scm",(void*)f_2529},
{"f_2531:c_backend_scm",(void*)f_2531},
{"f_2552:c_backend_scm",(void*)f_2552},
{"f_2539:c_backend_scm",(void*)f_2539},
{"f_2543:c_backend_scm",(void*)f_2543},
{"f_2546:c_backend_scm",(void*)f_2546},
{"f_2518:c_backend_scm",(void*)f_2518},
{"f_2483:c_backend_scm",(void*)f_2483},
{"f_2486:c_backend_scm",(void*)f_2486},
{"f_2489:c_backend_scm",(void*)f_2489},
{"f_2492:c_backend_scm",(void*)f_2492},
{"f_2454:c_backend_scm",(void*)f_2454},
{"f_2457:c_backend_scm",(void*)f_2457},
{"f_2460:c_backend_scm",(void*)f_2460},
{"f_2463:c_backend_scm",(void*)f_2463},
{"f_2417:c_backend_scm",(void*)f_2417},
{"f_2420:c_backend_scm",(void*)f_2420},
{"f_2423:c_backend_scm",(void*)f_2423},
{"f_2426:c_backend_scm",(void*)f_2426},
{"f_2384:c_backend_scm",(void*)f_2384},
{"f_2387:c_backend_scm",(void*)f_2387},
{"f_2390:c_backend_scm",(void*)f_2390},
{"f_2393:c_backend_scm",(void*)f_2393},
{"f_2365:c_backend_scm",(void*)f_2365},
{"f_2368:c_backend_scm",(void*)f_2368},
{"f_2338:c_backend_scm",(void*)f_2338},
{"f_2341:c_backend_scm",(void*)f_2341},
{"f_2312:c_backend_scm",(void*)f_2312},
{"f_2315:c_backend_scm",(void*)f_2315},
{"f_2318:c_backend_scm",(void*)f_2318},
{"f_2258:c_backend_scm",(void*)f_2258},
{"f_2268:c_backend_scm",(void*)f_2268},
{"f_2271:c_backend_scm",(void*)f_2271},
{"f_2274:c_backend_scm",(void*)f_2274},
{"f_2200:c_backend_scm",(void*)f_2200},
{"f_2203:c_backend_scm",(void*)f_2203},
{"f_2206:c_backend_scm",(void*)f_2206},
{"f_2209:c_backend_scm",(void*)f_2209},
{"f_2212:c_backend_scm",(void*)f_2212},
{"f_2215:c_backend_scm",(void*)f_2215},
{"f_2016:c_backend_scm",(void*)f_2016},
{"f_2028:c_backend_scm",(void*)f_2028},
{"f_2036:c_backend_scm",(void*)f_2036},
{"f_2020:c_backend_scm",(void*)f_2020},
{"f_1971:c_backend_scm",(void*)f_1971},
{"f_1979:c_backend_scm",(void*)f_1979},
{"f_1981:c_backend_scm",(void*)f_1981},
{"f_1996:c_backend_scm",(void*)f_1996},
{"f_1928:c_backend_scm",(void*)f_1928},
{"f_1934:c_backend_scm",(void*)f_1934},
{"f_1958:c_backend_scm",(void*)f_1958},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
