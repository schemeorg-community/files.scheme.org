/* Generated from utils.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: utils.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file utils.c
   unit: utils
*/

#include "chicken.h"


#if defined(_WIN32) && !defined(__CYGWIN__)
# include <windows.h>
# define C_HAS_MESSAGE_BOX 1
static int
C_confirmation_dialog(char *msg, char *caption, int def, int abort)
{
  int d = 0, r;
  int t = abort ? MB_YESNOCANCEL : MB_YESNO;

  switch(def) {
  case 0: d = MB_DEFBUTTON1; break;
  case 1: d = MB_DEFBUTTON2; break;
  case 2: d = MB_DEFBUTTON3;
  }

  r = MessageBox(NULL, msg, caption, t | MB_ICONQUESTION | d);

  switch(r) {
  case IDYES: return 1;
  case IDNO: return 0;
  default: return -1;
  }
}
#else
# define C_HAS_MESSAGE_BOX 0
static int
C_confirmation_dialog(char *msg, char *caption, int def, int abort) { return -1; }
#endif


static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[91];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,25),40,115,121,115,116,101,109,42,32,102,115,116,114,54,49,32,46,32,97,114,103,115,54,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,6),40,97,51,52,55,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,19),40,114,101,97,100,45,97,108,108,32,46,32,102,105,108,101,54,53,41,0,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,16),40,108,111,111,112,57,53,32,103,49,48,53,49,48,57,41};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,20),40,113,115,32,115,116,114,56,48,32,46,32,116,109,112,55,57,56,49,41,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,6),40,97,53,53,56,41,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,12),40,97,53,53,50,32,101,120,49,54,50,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,6),40,97,53,55,51,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,6),40,97,53,56,53,41,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,19),40,97,53,55,57,32,46,32,97,114,103,115,49,53,56,49,54,53,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,6),40,97,53,54,55,41,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,14),40,97,53,52,54,32,107,49,53,55,49,54,49,41,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,54,49,53,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,12),40,97,54,48,57,32,101,120,49,53,49,41,0,0,0,0};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,6),40,97,54,50,52,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,6),40,97,54,51,54,41,0,0};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,19),40,97,54,51,48,32,46,32,97,114,103,115,49,52,55,49,53,50,41,0,0,0,0,0};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,6),40,97,54,49,56,41,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,14),40,97,54,48,51,32,107,49,52,54,49,53,48,41,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,6),40,97,53,57,52,41,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,6),40,97,54,57,50,41,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,6),40,97,54,57,53,41,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,38),40,99,111,109,112,105,108,101,45,102,105,108,101,32,102,105,108,101,110,97,109,101,49,51,49,32,46,32,116,109,112,49,51,48,49,51,50,41,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,18),40,102,95,55,51,56,32,103,49,56,51,49,56,52,49,56,53,41,0,0,0,0,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,36),40,115,99,97,110,45,105,110,112,117,116,45,108,105,110,101,115,32,114,120,49,55,53,32,46,32,116,109,112,49,55,52,49,55,54,41,0,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,11),40,103,101,116,45,105,110,112,117,116,41,0,0,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,108,111,111,112,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,6),40,97,57,55,56,41,0,0};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,31),40,121,101,115,45,111,114,45,110,111,63,32,115,116,114,50,49,54,32,46,32,116,109,112,50,49,53,50,49,55,41,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


/* from k778 */
static C_word C_fcall stub200(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3) C_regparm;
C_regparm static C_word C_fcall stub200(C_word C_buf,C_word C_a0,C_word C_a1,C_word C_a2,C_word C_a3){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
char * t0=(char * )C_string_or_null(C_a0);
char * t1=(char * )C_string_or_null(C_a1);
int t2=(int )C_unfix(C_a2);
int t3=(int )C_truep(C_a3);
C_r=C_fix((C_word)C_confirmation_dialog(t0,t1,t2,t3));
return C_r;}

C_noret_decl(C_utils_toplevel)
C_externexport void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_295)
static void C_ccall f_295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_298)
static void C_ccall f_298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_301)
static void C_ccall f_301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_304)
static void C_ccall f_304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_307)
static void C_ccall f_307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_310)
static void C_ccall f_310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_494)
static void C_ccall f_494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_498)
static void C_ccall f_498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_501)
static void C_ccall f_501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_795)
static void C_ccall f_795r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_979)
static void C_ccall f_979(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_805)
static void C_ccall f_805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_808)
static void C_fcall f_808(C_word t0,C_word t1) C_noret;
C_noret_decl(f_864)
static void C_fcall f_864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_939)
static void C_ccall f_939(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_942)
static void C_ccall f_942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_945)
static void C_ccall f_945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_948)
static void C_ccall f_948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_951)
static void C_ccall f_951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_960)
static void C_ccall f_960(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_963)
static void C_ccall f_963(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_954)
static void C_ccall f_954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_868)
static void C_ccall f_868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_871)
static void C_ccall f_871(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_874)
static void C_fcall f_874(C_word t0,C_word t1) C_noret;
C_noret_decl(f_913)
static void C_ccall f_913(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_916)
static void C_ccall f_916(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_904)
static void C_ccall f_904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_907)
static void C_ccall f_907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_898)
static void C_ccall f_898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_810)
static void C_fcall f_810(C_word t0,C_word t1) C_noret;
C_noret_decl(f_859)
static void C_ccall f_859(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_837)
static void C_fcall f_837(C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_699)
static void C_ccall f_699r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_703)
static void C_ccall f_703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_711)
static void C_fcall f_711(C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_724)
static void C_ccall f_724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_738)
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_746)
static void C_ccall f_746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_502)
static void C_ccall f_502r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_696)
static void C_ccall f_696(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_506)
static void C_ccall f_506(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_693)
static void C_ccall f_693(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_512)
static void C_ccall f_512(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_691)
static void C_ccall f_691(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_515)
static void C_ccall f_515(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_521)
static void C_ccall f_521(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_527)
static void C_ccall f_527(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_649)
static void C_ccall f_649(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_677)
static void C_ccall f_677(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_673)
static void C_ccall f_673(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_653)
static void C_ccall f_653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_657)
static void C_ccall f_657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_661)
static void C_ccall f_661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_530)
static void C_ccall f_530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_595)
static void C_ccall f_595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_604)
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_619)
static void C_ccall f_619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_631)
static void C_ccall f_631r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_637)
static void C_ccall f_637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_625)
static void C_ccall f_625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_610)
static void C_ccall f_610(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_547)
static void C_ccall f_547(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_568)
static void C_ccall f_568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_580)
static void C_ccall f_580r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_586)
static void C_ccall f_586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_574)
static void C_ccall f_574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_578)
static void C_ccall f_578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_553)
static void C_ccall f_553(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_559)
static void C_ccall f_559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_563)
static void C_ccall f_563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_542)
static void C_ccall f_542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_373)
static void C_ccall f_373r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_377)
static void C_ccall f_377(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_406)
static void C_ccall f_406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_408)
static void C_fcall f_408(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_457)
static void C_fcall f_457(C_word t0,C_word t1) C_noret;
C_noret_decl(f_402)
static void C_ccall f_402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_330)
static void C_ccall f_330r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_334)
static void C_ccall f_334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_340)
static void C_ccall f_340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_348)
static void C_ccall f_348(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_312)
static void C_ccall f_312r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_316)
static void C_ccall f_316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_319)
static void C_ccall f_319(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_808)
static void C_fcall trf_808(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_808(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_808(t0,t1);}

C_noret_decl(trf_864)
static void C_fcall trf_864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_864(t0,t1);}

C_noret_decl(trf_874)
static void C_fcall trf_874(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_874(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_874(t0,t1);}

C_noret_decl(trf_810)
static void C_fcall trf_810(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_810(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_810(t0,t1);}

C_noret_decl(trf_837)
static void C_fcall trf_837(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_837(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_837(t0,t1);}

C_noret_decl(trf_711)
static void C_fcall trf_711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_711(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_711(t0,t1);}

C_noret_decl(trf_408)
static void C_fcall trf_408(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_408(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_408(t0,t1,t2);}

C_noret_decl(trf_457)
static void C_fcall trf_457(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_457(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_457(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_utils_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_utils_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("utils_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(638)){
C_save(t1);
C_rereclaim2(638*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,91);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],7,"system*");
lf[3]=C_h_intern(&lf[3],9,"\003syserror");
lf[4]=C_decode_literal(C_heaptop,"\376B\000\0003shell invocation failed with non-zero return status");
lf[5]=C_h_intern(&lf[5],6,"system");
lf[6]=C_h_intern(&lf[6],7,"sprintf");
lf[7]=C_h_intern(&lf[7],8,"read-all");
lf[8]=C_h_intern(&lf[8],20,"\003sysread-string/port");
lf[9]=C_h_intern(&lf[9],11,"read-string");
lf[10]=C_h_intern(&lf[10],20,"with-input-from-file");
lf[11]=C_h_intern(&lf[11],5,"port\077");
lf[12]=C_h_intern(&lf[12],18,"\003sysstandard-input");
lf[13]=C_h_intern(&lf[13],2,"qs");
lf[14]=C_h_intern(&lf[14],7,"mingw32");
lf[15]=C_h_intern(&lf[15],4,"msvc");
lf[16]=C_h_intern(&lf[16],13,"string-append");
lf[17]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[19]=C_decode_literal(C_heaptop,"\376B\000\000\002\047\047");
lf[20]=C_h_intern(&lf[20],18,"string-concatenate");
lf[21]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000#\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000`\376\003\000\000\002\376\377\012\000\000\264\376\003\000\000\002\376\377\012\000\000~\376\003\000\000\002\376\377\012\000\000&\376\003\000"
"\000\002\376\377\012\000\000%\376\003\000\000\002\376\377\012\000\000$\376\003\000\000\002\376\377\012\000\000!\376\003\000\000\002\376\377\012\000\000*\376\003\000\000\002\376\377\012\000\000;\376\003\000\000\002\376\377\012\000\000<\376\003\000\000\002\376\377\012\000\000>\376\003\000\000\002\376"
"\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000(\376\003\000\000\002\376\377\012\000\000)\376\003\000\000\002\376\377\012\000\000[\376\003\000\000\002\376\377\012\000\000]\376\003\000\000\002\376\377\012\000\000{\376\003\000\000\002\376\377\012\000\000}\376\377\016");
lf[22]=C_h_intern(&lf[22],16,"\003sysstring->list");
lf[23]=C_h_intern(&lf[23],14,"build-platform");
lf[24]=C_h_intern(&lf[24],20,"compile-file-options");
lf[25]=C_h_intern(&lf[25],4,"load");
lf[26]=C_h_intern(&lf[26],12,"compile-file");
lf[27]=C_h_intern(&lf[27],12,"\000output-file");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\003csc");
lf[29]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\007mingw32\376\003\000\000\002\376\001\000\000\004msvc\376\377\016");
lf[30]=C_h_intern(&lf[30],5,"abort");
lf[31]=C_h_intern(&lf[31],12,"delete-file*");
lf[32]=C_h_intern(&lf[32],22,"with-exception-handler");
lf[33]=C_h_intern(&lf[33],30,"call-with-current-continuation");
lf[34]=C_h_intern(&lf[34],7,"on-exit");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[37]=C_decode_literal(C_heaptop,"\376B\000\000\025~a~a -s ~a ~a -o ~a~a");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[39]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[40]=C_h_intern(&lf[40],18,"string-intersperse");
lf[41]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[42]=C_h_intern(&lf[42],6,"append");
lf[43]=C_h_intern(&lf[43],5,"print");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\014; compiling ");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[46]=C_h_intern(&lf[46],21,"create-temporary-file");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\002so");
lf[48]=C_h_intern(&lf[48],12,"file-exists\077");
lf[49]=C_h_intern(&lf[49],13,"make-pathname");
lf[50]=C_h_intern(&lf[50],15,"\003sysget-keyword");
lf[51]=C_h_intern(&lf[51],5,"\000load");
lf[52]=C_h_intern(&lf[52],8,"\000options");
lf[53]=C_h_intern(&lf[53],16,"scan-input-lines");
lf[54]=C_h_intern(&lf[54],13,"string-search");
lf[55]=C_h_intern(&lf[55],6,"regexp");
lf[56]=C_h_intern(&lf[56],9,"read-line");
lf[57]=C_h_intern(&lf[57],10,"yes-or-no\077");
lf[58]=C_h_intern(&lf[58],8,"\000default");
lf[59]=C_h_intern(&lf[59],6,"\000title");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\000\017CHICKEN Runtime");
lf[61]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[62]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[64]=C_h_intern(&lf[64],17,"\003sysmake-c-string");
lf[65]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[67]=C_h_intern(&lf[67],16,"string-trim-both");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\003yes");
lf[69]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[71]=C_h_intern(&lf[71],19,"\003sysstandard-output");
lf[72]=C_h_intern(&lf[72],19,"\003syswrite-char/port");
lf[73]=C_h_intern(&lf[73],7,"display");
lf[74]=C_decode_literal(C_heaptop,"\376B\000\000\033Please enter \042yes\042 or \042no\042.");
lf[75]=C_decode_literal(C_heaptop,"\376B\000\000$Please enter \042yes\042, \042no\042 or \042abort\042.");
lf[76]=C_decode_literal(C_heaptop,"\376B\000\000\005abort");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[78]=C_h_intern(&lf[78],12,"flush-output");
lf[79]=C_decode_literal(C_heaptop,"\376B\000\000\002] ");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\002) ");
lf[81]=C_decode_literal(C_heaptop,"\376B\000\000\006/abort");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\010 (yes/no");
lf[84]=C_h_intern(&lf[84],5,"reset");
lf[85]=C_h_intern(&lf[85],6,"\000abort");
lf[86]=C_h_intern(&lf[86],17,"\003syspeek-c-string");
lf[87]=C_h_intern(&lf[87],14,"make-parameter");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\002-S\376\003\000\000\002\376B\000\000\003-O2\376\003\000\000\002\376B\000\000\003-d2\376\377\016");
lf[89]=C_h_intern(&lf[89],17,"register-feature!");
lf[90]=C_h_intern(&lf[90],5,"utils");
C_register_lf2(lf,91,create_ptable());
t2=C_mutate(&lf[0] /* (set! c69 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_295,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k293 */
static void C_ccall f_295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_298,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k296 in k293 */
static void C_ccall f_298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_301,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k299 in k296 in k293 */
static void C_ccall f_301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_304,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k302 in k299 in k296 in k293 */
static void C_ccall f_304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_307,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_310,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm:37: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[89]+1)))(3,*((C_word*)lf[89]+1),t2,lf[90]);}

/* k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_310,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! system* ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_312,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[7]+1 /* (set! read-all ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_330,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[13]+1 /* (set! qs ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_373,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_494,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* utils.scm:80: make-parameter */
((C_proc3)C_retrieve_proc(*((C_word*)lf[87]+1)))(3,*((C_word*)lf[87]+1),t5,lf[88]);}

/* k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_494,2,t0,t1);}
t2=C_mutate((C_word*)lf[24]+1 /* (set! compile-file-options ...) */,t1);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_498,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_CSC_PROGRAM),C_fix(0));}

/* k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_498,2,t0,t1);}
t2=*((C_word*)lf[25]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_501,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* ##sys#peek-c-string */
t4=*((C_word*)lf[86]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}

/* k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_501,2,t0,t1);}
t2=C_mutate((C_word*)lf[26]+1 /* (set! compile-file ...) */,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_502,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word)li22),tmp=(C_word)a,a+=6,tmp));
t3=C_mutate((C_word*)lf[53]+1 /* (set! scan-input-lines ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_699,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[57]+1 /* (set! yes-or-no? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_795,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_795(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_795r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_795r(t0,t1,t2,t3);}}

static void C_ccall f_795r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(9);
t4=C_i_get_keyword(lf[58],t3,C_SCHEME_FALSE);
t5=C_i_get_keyword(lf[59],t3,C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_805,a[2]=t1,a[3]=t4,a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_979,a[2]=((C_word)li28),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t6,lf[85],t3,t7);}

/* a978 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_979(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_979,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[84]+1));}

/* k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_805,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_808,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_mk_bool(C_HAS_MESSAGE_BOX))){
t3=C_fudge(C_fix(4));
t4=t2;
f_808(t4,C_i_not(t3));}
else{
t3=t2;
f_808(t3,C_SCHEME_FALSE);}}

/* k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_808(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_808,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_810,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t1,a[7]=((C_word)li26),tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_864,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=t2,a[5]=((C_word*)t0)[3],a[6]=t4,a[7]=((C_word*)t0)[4],a[8]=((C_word)li27),tmp=(C_word)a,a+=9,tmp));
t6=((C_word*)t4)[1];
f_864(t6,((C_word*)t0)[2]);}

/* loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_864(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_864,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_868,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=t2;
f_868(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[71]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_939,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=t3,a[5]=((C_word*)t0)[5],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),t3);}}

/* k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_939(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_939,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_942,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_942,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[83],((C_word*)t0)[3]);}

/* k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[81],((C_word*)t0)[3]);}
else{
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[82],((C_word*)t0)[3]);}}

/* k946 in k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_951,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[80],((C_word*)t0)[2]);}

/* k949 in k946 in k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_954,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=*((C_word*)lf[71]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_960,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t5=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(91),t3);}
else{
/* utils.scm:189: flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[3]);}}

/* k958 in k949 in k946 in k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_960(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_960,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_963,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k961 in k958 in k949 in k946 in k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_963(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),((C_word*)t0)[3],lf[79],((C_word*)t0)[2]);}

/* k952 in k949 in k946 in k943 in k940 in k937 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:189: flush-output */
((C_proc2)C_retrieve_proc(*((C_word*)lf[78]+1)))(2,*((C_word*)lf[78]+1),((C_word*)t0)[2]);}

/* k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_868,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_871,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* utils.scm:190: get-input */
t3=((C_word*)t0)[2];
f_810(t3,t2);}

/* k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_871(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_871,2,t0,t1);}
t2=t1;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_874,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_eofp(((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,lf[76]);
t6=t4;
f_874(t6,t5);}
else{
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_string_equal_p(lf[77],((C_word*)t3)[1]))){
t5=C_set_block_item(t3,0,((C_word*)t0)[2]);
t6=t4;
f_874(t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_874(t6,t5);}}
else{
t5=C_SCHEME_UNDEFINED;
t6=t4;
f_874(t6,t5);}}}

/* k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_874(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_874,NULL,2,t0,t1);}
if(C_truep(C_i_string_ci_equal_p(lf[68],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}
else{
if(C_truep(C_i_string_ci_equal_p(lf[69],((C_word*)((C_word*)t0)[5])[1]))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(C_truep(((C_word*)t0)[3])?C_i_string_ci_equal_p(lf[70],((C_word*)((C_word*)t0)[5])[1]):C_SCHEME_FALSE);
if(C_truep(t2)){
/* utils.scm:195: abort */
t3=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t3))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_898,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=*((C_word*)lf[71]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_904,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(10),t4);}
else{
t4=*((C_word*)lf[71]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_913,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t6=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(10),t4);}}}}}

/* k911 in k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_913(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_913,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_916,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[75],((C_word*)t0)[2]);}

/* k914 in k911 in k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_916(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k902 in k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[73]+1)))(4,*((C_word*)lf[73]+1),t2,lf[74],((C_word*)t0)[2]);}

/* k905 in k902 in k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[72]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k896 in k872 in k869 in k866 in loop in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:200: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_864(t2,((C_word*)t0)[2]);}

/* get-input in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_810(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_810,NULL,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:lf[60]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_837,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
if(C_truep(C_i_string_ci_equal_p(((C_word*)t0)[2],lf[65]))){
t4=t3;
f_837(t4,C_fix(0));}
else{
t4=C_i_string_ci_equal_p(((C_word*)t0)[2],lf[66]);
t5=t3;
f_837(t5,(C_truep(t4)?C_fix(1):C_fix(2)));}}
else{
t4=t3;
f_837(t4,C_fix(3));}}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_859,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* utils.scm:184: read-line */
((C_proc2)C_retrieve_proc(*((C_word*)lf[56]+1)))(2,*((C_word*)lf[56]+1),t2);}}

/* k857 in get-input in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_859(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:184: string-trim-both */
((C_proc3)C_retrieve_proc(*((C_word*)lf[67]+1)))(3,*((C_word*)lf[67]+1),((C_word*)t0)[2],t1);}

/* k835 in get-input in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_837(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_837,NULL,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_772,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=C_i_foreign_string_argumentp(t2);
/* ##sys#make-c-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[64]+1)))(3,*((C_word*)lf[64]+1),t4,t5);}
else{
t5=t4;
f_772(2,t5,C_SCHEME_FALSE);}}

/* k770 in k835 in get-input in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_776,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_foreign_string_argumentp(((C_word*)t0)[2]);
/* ##sys#make-c-string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[64]+1)))(3,*((C_word*)lf[64]+1),t2,t3);}
else{
t3=t2;
f_776(2,t3,C_SCHEME_FALSE);}}

/* k774 in k770 in k835 in get-input in k806 in k803 in yes-or-no? in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
t2=C_i_foreign_fixnum_argumentp(((C_word*)t0)[5]);
t3=stub200(C_SCHEME_UNDEFINED,((C_word*)t0)[4],t1,t2,((C_word*)t0)[3]);
t4=C_eqp(t3,C_fix(0));
if(C_truep(t4)){
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[61]);}
else{
t5=C_eqp(t3,C_fix(1));
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?lf[62]:lf[63]));}}

/* scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_699(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_699r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_699r(t0,t1,t2,t3);}}

static void C_ccall f_699r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_703,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_703(2,t5,*((C_word*)lf[12]+1));}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_703(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k701 in scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_703,2,t0,t1);}
t2=C_i_closurep(((C_word*)t0)[3]);
t3=(C_truep(t2)?((C_word*)t0)[3]:(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_738,a[2]=((C_word*)t0)[3],a[3]=((C_word)li23),tmp=(C_word)a,a+=4,tmp));
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_711,a[2]=t1,a[3]=t3,a[4]=t5,a[5]=((C_word)li24),tmp=(C_word)a,a+=6,tmp));
t7=((C_word*)t5)[1];
f_711(t7,((C_word*)t0)[2]);}

/* loop in k701 in scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_711(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_711,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_715,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* utils.scm:121: read-line */
((C_proc3)C_retrieve_proc(*((C_word*)lf[56]+1)))(3,*((C_word*)lf[56]+1),t2,((C_word*)t0)[2]);}

/* k713 in loop in k701 in scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_715,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_724,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:123: rx */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,t1);}}

/* k722 in k713 in loop in k701 in scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* utils.scm:124: loop */
t2=((C_word*)((C_word*)t0)[2])[1];
f_711(t2,((C_word*)t0)[3]);}}

/* f_738 in k701 in scan-input-lines in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_738(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_738,3,t0,t1,t2);}
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_746,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* utils.scm:119: regexp */
((C_proc3)C_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),t4,((C_word*)t0)[2]);}

/* k744 */
static void C_ccall f_746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g186187 */
t2=((C_word*)t0)[4];
((C_proc4)C_retrieve_proc(t2))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_502(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+11)){
C_save_and_reclaim((void*)tr3r,(void*)f_502r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_502r(t0,t1,t2,t3);}}

static void C_ccall f_502r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(11);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_506,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_696,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t4,lf[52],t3,t5);}

/* a695 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_696(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_696,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}

/* k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_506(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_506,2,t0,t1);}
t2=C_i_get_keyword(lf[27],((C_word*)t0)[7],C_SCHEME_FALSE);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_512,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_693,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp);
/* ##sys#get-keyword */
((C_proc5)C_retrieve_proc(*((C_word*)lf[50]+1)))(5,*((C_word*)lf[50]+1),t3,lf[51],((C_word*)t0)[7],t4);}

/* a692 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_693(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_693,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_512(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_512,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_515,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_691,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* utils.scm:87: make-pathname */
((C_proc4)C_retrieve_proc(*((C_word*)lf[49]+1)))(4,*((C_word*)lf[49]+1),t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k689 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_691(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:87: file-exists? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[48]+1)))(3,*((C_word*)lf[48]+1),((C_word*)t0)[2],t1);}

/* k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_515(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_515,2,t0,t1);}
t2=(C_truep(t1)?t1:lf[28]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_521,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(((C_word*)t0)[6])){
t4=t3;
f_521(2,t4,C_SCHEME_FALSE);}
else{
/* utils.scm:88: create-temporary-file */
((C_proc3)C_retrieve_proc(*((C_word*)lf[46]+1)))(3,*((C_word*)lf[46]+1),t3,lf[47]);}}

/* k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_521(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_521,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_681,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* utils.scm:89: build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t2);}

/* k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_681,2,t0,t1);}
t2=C_i_memq(t1,lf[29]);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_527,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* utils.scm:90: print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[43]+1)))(5,*((C_word*)lf[43]+1),t3,lf[44],((C_word*)t0)[4],lf[45]);}

/* k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_527(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_527,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_530,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],tmp=(C_word)a,a+=7,tmp);
t3=(C_truep(((C_word*)t0)[5])?lf[35]:lf[36]);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_649,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=t3,a[7]=t2,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
/* utils.scm:94: qs */
t5=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[2]);}

/* k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_649(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_649,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_673,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_677,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:95: compile-file-options */
t5=*((C_word*)lf[24]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k675 in k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_677(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:95: append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[42]+1)))(4,*((C_word*)lf[42]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k671 in k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_673(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:95: string-intersperse */
((C_proc4)C_retrieve_proc(*((C_word*)lf[40]+1)))(4,*((C_word*)lf[40]+1),((C_word*)t0)[2],t1,lf[41]);}

/* k651 in k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_657,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* utils.scm:96: qs */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k655 in k651 in k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_657,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_661,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
/* utils.scm:97: qs */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}
else{
t3=((C_word*)t0)[2];
/* utils.scm:97: qs */
t4=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}}

/* k659 in k655 in k651 in k647 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[7])){
/* utils.scm:91: system* */
t2=*((C_word*)lf[2]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[6],lf[37],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[38]);}
else{
/* utils.scm:91: system* */
t2=*((C_word*)lf[2]+1);
((C_proc9)(void*)(*((C_word*)t2+1)))(9,t2,((C_word*)t0)[6],lf[37],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[39]);}}

/* k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_530,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_533,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[5])){
t3=t2;
f_533(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_595,a[2]=((C_word*)t0)[4],a[3]=((C_word)li19),tmp=(C_word)a,a+=4,tmp);
/* utils.scm:100: on-exit */
((C_proc3)C_retrieve_proc(*((C_word*)lf[34]+1)))(3,*((C_word*)lf[34]+1),t2,t3);}}

/* a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_604,a[2]=((C_word*)t0)[2],a[3]=((C_word)li18),tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,t3);}

/* a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_604(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_604,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_610,a[2]=t2,a[3]=((C_word)li13),tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_619,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word)li17),tmp=(C_word)a,a+=5,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t1,t3,t4);}

/* a618 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_625,a[2]=((C_word*)t0)[3],a[3]=((C_word)li14),tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_631,a[2]=((C_word*)t0)[2],a[3]=((C_word)li16),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a630 in a618 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_631(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_631r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_631r(t0,t1,t2);}}

static void C_ccall f_631r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_637,a[2]=t2,a[3]=((C_word)li15),tmp=(C_word)a,a+=4,tmp);
/* k146150 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a636 in a630 in a618 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_637,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a624 in a618 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_625,2,t0,t1);}
/* utils.scm:102: delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t1,((C_word*)t0)[2]);}

/* a609 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_610(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_610,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_616,a[2]=((C_word)li12),tmp=(C_word)a,a+=3,tmp);
/* k146150 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a615 in a609 in a603 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_616,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k597 in a594 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g148149 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_533,2,t0,t1);}
if(C_truep(((C_word*)t0)[6])){
t2=(C_truep(((C_word*)t0)[5])?((C_word*)t0)[5]:((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_542,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_547,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word)li11),tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,t4);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_547(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_547,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_553,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word)li6),tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_568,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word)li10),tmp=(C_word)a,a+=6,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_proc(*((C_word*)lf[32]+1)))(4,*((C_word*)lf[32]+1),t1,t3,t4);}

/* a567 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_568,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_574,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word)li7),tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_580,a[2]=((C_word*)t0)[2],a[3]=((C_word)li9),tmp=(C_word)a,a+=4,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a579 in a567 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_580(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_580r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_580r(t0,t1,t2);}}

static void C_ccall f_580r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_586,a[2]=t2,a[3]=((C_word)li8),tmp=(C_word)a,a+=4,tmp);
/* k157161 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a585 in a579 in a567 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_586,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a573 in a567 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_574,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_578,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:109: load-file */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)t0)[3]);}

/* k576 in a573 in a567 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* a552 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_553(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_553,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_559,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word)li5),tmp=(C_word)a,a+=5,tmp);
/* k157161 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a558 in a552 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_559,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_563,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* utils.scm:107: delete-file* */
((C_proc3)C_retrieve_proc(*((C_word*)lf[31]+1)))(3,*((C_word*)lf[31]+1),t2,((C_word*)t0)[2]);}

/* k561 in a558 in a552 in a546 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:108: abort */
((C_proc3)C_retrieve_proc(*((C_word*)lf[30]+1)))(3,*((C_word*)lf[30]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k540 in k531 in k528 in k525 in k679 in k519 in k513 in k510 in k504 in compile-file in k499 in k496 in k492 in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g159160 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_373(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_373r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_373r(t0,t1,t2,t3);}}

static void C_ccall f_373r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_377,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* utils.scm:61: build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[23]+1)))(2,*((C_word*)lf[23]+1),t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_377(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k375 in qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_377(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_377,2,t0,t1);}
t2=C_eqp(t1,lf[14]);
t3=(C_truep(t2)?t2:C_eqp(t1,lf[15]));
if(C_truep(t3)){
/* utils.scm:64: string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[16]+1)))(5,*((C_word*)lf[16]+1),((C_word*)t0)[3],lf[17],((C_word*)t0)[2],lf[18]);}
else{
t4=C_i_string_length(((C_word*)t0)[2]);
t5=C_eqp(t4,C_fix(0));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[19]);}
else{
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_402,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_406,a[2]=t10,a[3]=t7,a[4]=t9,tmp=(C_word)a,a+=5,tmp);
/* string->list */
t12=*((C_word*)lf[22]+1);
((C_proc3)(void*)(*((C_word*)t12+1)))(3,t12,t11,((C_word*)t0)[2]);}}}

/* k404 in k375 in qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_406,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_408,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=((C_word)li3),tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_408(t5,((C_word*)t0)[2],t1);}

/* loop95 in k404 in k375 in qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_408(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_408,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_457,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_u_i_char_whitespacep(t4);
if(C_truep(t5)){
t6=t3;
f_457(t6,(C_truep(t5)?C_a_i_string(&a,2,C_make_character(92),t4):C_a_i_string(&a,1,t4)));}
else{
t6=C_i_memq(t4,lf[21]);
t7=t3;
f_457(t7,(C_truep(t6)?C_a_i_string(&a,2,C_make_character(92),t4):C_a_i_string(&a,1,t4)));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k455 in loop95 in k404 in k375 in qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_fcall f_457(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_457,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop95108 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_408(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop95108 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_408(t6,((C_word*)t0)[3],t5);}}

/* k400 in k375 in qs in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* utils.scm:68: string-concatenate */
((C_proc3)C_retrieve_proc(*((C_word*)lf[20]+1)))(3,*((C_word*)lf[20]+1),((C_word*)t0)[2],t1);}

/* read-all in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_330(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_330r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_330r(t0,t1,t2);}}

static void C_ccall f_330r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_334,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_334(2,t4,*((C_word*)lf[12]+1));}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_334(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[3]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k332 in read-all in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_334,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_340,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:54: port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[11]+1)))(3,*((C_word*)lf[11]+1),t2,t1);}

/* k338 in k332 in read-all in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_340,2,t0,t1);}
if(C_truep(t1)){
/* read-string/port */
t2=*((C_word*)lf[8]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_SCHEME_FALSE,((C_word*)t0)[2]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_348,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp);
/* utils.scm:56: with-input-from-file */
((C_proc4)C_retrieve_proc(*((C_word*)lf[10]+1)))(4,*((C_word*)lf[10]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2);}}

/* a347 in k338 in k332 in read-all in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_348(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_348,2,t0,t1);}
t2=*((C_word*)lf[9]+1);
/* g7273 */
t3=t2;
((C_proc3)C_retrieve_proc(t3))(3,t3,t1,C_SCHEME_FALSE);}

/* system* in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_312(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr3r,(void*)f_312r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_312r(t0,t1,t2,t3);}}

static void C_ccall f_312r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_316,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t4,*((C_word*)lf[6]+1),t2,t3);}

/* k314 in system* in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_319,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* utils.scm:45: system */
((C_proc3)C_retrieve_proc(*((C_word*)lf[5]+1)))(3,*((C_word*)lf[5]+1),t2,t1);}

/* k317 in k314 in system* in k308 in k305 in k302 in k299 in k296 in k293 */
static void C_ccall f_319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,C_fix(0));
if(C_truep(t2)){
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
/* utils.scm:47: ##sys#error */
t3=*((C_word*)lf[3]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[3],lf[4],((C_word*)t0)[2],t1);}}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[94] = {
{"toplevel:utils_scm",(void*)C_utils_toplevel},
{"f_295:utils_scm",(void*)f_295},
{"f_298:utils_scm",(void*)f_298},
{"f_301:utils_scm",(void*)f_301},
{"f_304:utils_scm",(void*)f_304},
{"f_307:utils_scm",(void*)f_307},
{"f_310:utils_scm",(void*)f_310},
{"f_494:utils_scm",(void*)f_494},
{"f_498:utils_scm",(void*)f_498},
{"f_501:utils_scm",(void*)f_501},
{"f_795:utils_scm",(void*)f_795},
{"f_979:utils_scm",(void*)f_979},
{"f_805:utils_scm",(void*)f_805},
{"f_808:utils_scm",(void*)f_808},
{"f_864:utils_scm",(void*)f_864},
{"f_939:utils_scm",(void*)f_939},
{"f_942:utils_scm",(void*)f_942},
{"f_945:utils_scm",(void*)f_945},
{"f_948:utils_scm",(void*)f_948},
{"f_951:utils_scm",(void*)f_951},
{"f_960:utils_scm",(void*)f_960},
{"f_963:utils_scm",(void*)f_963},
{"f_954:utils_scm",(void*)f_954},
{"f_868:utils_scm",(void*)f_868},
{"f_871:utils_scm",(void*)f_871},
{"f_874:utils_scm",(void*)f_874},
{"f_913:utils_scm",(void*)f_913},
{"f_916:utils_scm",(void*)f_916},
{"f_904:utils_scm",(void*)f_904},
{"f_907:utils_scm",(void*)f_907},
{"f_898:utils_scm",(void*)f_898},
{"f_810:utils_scm",(void*)f_810},
{"f_859:utils_scm",(void*)f_859},
{"f_837:utils_scm",(void*)f_837},
{"f_772:utils_scm",(void*)f_772},
{"f_776:utils_scm",(void*)f_776},
{"f_699:utils_scm",(void*)f_699},
{"f_703:utils_scm",(void*)f_703},
{"f_711:utils_scm",(void*)f_711},
{"f_715:utils_scm",(void*)f_715},
{"f_724:utils_scm",(void*)f_724},
{"f_738:utils_scm",(void*)f_738},
{"f_746:utils_scm",(void*)f_746},
{"f_502:utils_scm",(void*)f_502},
{"f_696:utils_scm",(void*)f_696},
{"f_506:utils_scm",(void*)f_506},
{"f_693:utils_scm",(void*)f_693},
{"f_512:utils_scm",(void*)f_512},
{"f_691:utils_scm",(void*)f_691},
{"f_515:utils_scm",(void*)f_515},
{"f_521:utils_scm",(void*)f_521},
{"f_681:utils_scm",(void*)f_681},
{"f_527:utils_scm",(void*)f_527},
{"f_649:utils_scm",(void*)f_649},
{"f_677:utils_scm",(void*)f_677},
{"f_673:utils_scm",(void*)f_673},
{"f_653:utils_scm",(void*)f_653},
{"f_657:utils_scm",(void*)f_657},
{"f_661:utils_scm",(void*)f_661},
{"f_530:utils_scm",(void*)f_530},
{"f_595:utils_scm",(void*)f_595},
{"f_604:utils_scm",(void*)f_604},
{"f_619:utils_scm",(void*)f_619},
{"f_631:utils_scm",(void*)f_631},
{"f_637:utils_scm",(void*)f_637},
{"f_625:utils_scm",(void*)f_625},
{"f_610:utils_scm",(void*)f_610},
{"f_616:utils_scm",(void*)f_616},
{"f_599:utils_scm",(void*)f_599},
{"f_533:utils_scm",(void*)f_533},
{"f_547:utils_scm",(void*)f_547},
{"f_568:utils_scm",(void*)f_568},
{"f_580:utils_scm",(void*)f_580},
{"f_586:utils_scm",(void*)f_586},
{"f_574:utils_scm",(void*)f_574},
{"f_578:utils_scm",(void*)f_578},
{"f_553:utils_scm",(void*)f_553},
{"f_559:utils_scm",(void*)f_559},
{"f_563:utils_scm",(void*)f_563},
{"f_542:utils_scm",(void*)f_542},
{"f_373:utils_scm",(void*)f_373},
{"f_377:utils_scm",(void*)f_377},
{"f_406:utils_scm",(void*)f_406},
{"f_408:utils_scm",(void*)f_408},
{"f_457:utils_scm",(void*)f_457},
{"f_402:utils_scm",(void*)f_402},
{"f_330:utils_scm",(void*)f_330},
{"f_334:utils_scm",(void*)f_334},
{"f_340:utils_scm",(void*)f_340},
{"f_348:utils_scm",(void*)f_348},
{"f_312:utils_scm",(void*)f_312},
{"f_316:utils_scm",(void*)f_316},
{"f_319:utils_scm",(void*)f_319},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
