/* Generated from srfi-18.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:49
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: srfi-18.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -explicit-use -no-trace -output-file srfi-18.c
   unit: srfi_18
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_scheduler_toplevel)
C_externimport void C_ccall C_scheduler_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[114];
static double C_possibly_force_alignment;
static C_char C_TLS li0[] C_aligned={C_lihdr(0,0,37),40,35,35,115,121,115,35,99,111,109,112,117,116,101,45,116,105,109,101,45,108,105,109,105,116,32,116,109,56,55,32,108,111,99,56,56,41,0,0,0};
static C_char C_TLS li1[] C_aligned={C_lihdr(0,0,14),40,99,117,114,114,101,110,116,45,116,105,109,101,41,0,0};
static C_char C_TLS li2[] C_aligned={C_lihdr(0,0,20),40,116,105,109,101,45,62,115,101,99,111,110,100,115,32,116,109,57,50,41,0,0,0,0};
static C_char C_TLS li3[] C_aligned={C_lihdr(0,0,25),40,116,105,109,101,45,62,109,105,108,108,105,115,101,99,111,110,100,115,32,116,109,57,52,41,0,0,0,0,0,0,0};
static C_char C_TLS li4[] C_aligned={C_lihdr(0,0,19),40,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,57,54,41,0,0,0,0,0};
static C_char C_TLS li5[] C_aligned={C_lihdr(0,0,26),40,109,105,108,108,105,115,101,99,111,110,100,115,45,62,116,105,109,101,32,110,109,115,57,56,41,0,0,0,0,0,0};
static C_char C_TLS li6[] C_aligned={C_lihdr(0,0,12),40,116,105,109,101,63,32,120,49,48,48,41,0,0,0,0};
static C_char C_TLS li7[] C_aligned={C_lihdr(0,0,30),40,106,111,105,110,45,116,105,109,101,111,117,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,48,49,41,0,0};
static C_char C_TLS li8[] C_aligned={C_lihdr(0,0,33),40,97,98,97,110,100,111,110,101,100,45,109,117,116,101,120,45,101,120,99,101,112,116,105,111,110,63,32,120,49,48,51,41,0,0,0,0,0,0,0};
static C_char C_TLS li9[] C_aligned={C_lihdr(0,0,35),40,116,101,114,109,105,110,97,116,101,100,45,116,104,114,101,97,100,45,101,120,99,101,112,116,105,111,110,63,32,120,49,48,53,41,0,0,0,0,0};
static C_char C_TLS li10[] C_aligned={C_lihdr(0,0,26),40,117,110,99,97,117,103,104,116,45,101,120,99,101,112,116,105,111,110,63,32,120,49,48,55,41,0,0,0,0,0,0};
static C_char C_TLS li11[] C_aligned={C_lihdr(0,0,19),40,97,54,49,53,32,46,32,114,101,115,117,108,116,115,49,49,50,41,0,0,0,0,0};
static C_char C_TLS li12[] C_aligned={C_lihdr(0,0,6),40,97,54,48,57,41,0,0};
static C_char C_TLS li13[] C_aligned={C_lihdr(0,0,32),40,109,97,107,101,45,116,104,114,101,97,100,32,116,104,117,110,107,49,48,57,32,46,32,110,97,109,101,49,49,48,41};
static C_char C_TLS li14[] C_aligned={C_lihdr(0,0,14),40,116,104,114,101,97,100,63,32,120,49,49,54,41,0,0};
static C_char C_TLS li15[] C_aligned={C_lihdr(0,0,16),40,99,117,114,114,101,110,116,45,116,104,114,101,97,100,41};
static C_char C_TLS li16[] C_aligned={C_lihdr(0,0,24),40,116,104,114,101,97,100,45,115,116,97,116,101,32,116,104,114,101,97,100,49,49,55,41};
static C_char C_TLS li17[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,32,116,104,114,101,97,100,49,49,57,41,0,0,0,0,0};
static C_char C_TLS li18[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,116,104,114,101,97,100,49,50,49,32,120,49,50,50,41,0,0,0};
static C_char C_TLS li19[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,32,116,104,114,101,97,100,49,50,52,41,0,0,0,0,0,0};
static C_char C_TLS li20[] C_aligned={C_lihdr(0,0,36),40,116,104,114,101,97,100,45,113,117,97,110,116,117,109,45,115,101,116,33,32,116,104,114,101,97,100,49,50,54,32,113,49,50,55,41,0,0,0,0};
static C_char C_TLS li21[] C_aligned={C_lihdr(0,0,18),40,116,104,114,101,97,100,45,110,97,109,101,32,120,49,51,48,41,0,0,0,0,0,0};
static C_char C_TLS li22[] C_aligned={C_lihdr(0,0,25),40,116,104,114,101,97,100,45,115,116,97,114,116,33,32,116,104,114,101,97,100,49,51,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li23[] C_aligned={C_lihdr(0,0,6),40,97,55,56,54,41,0,0};
static C_char C_TLS li24[] C_aligned={C_lihdr(0,0,16),40,97,55,55,49,32,114,101,116,117,114,110,49,52,55,41};
static C_char C_TLS li25[] C_aligned={C_lihdr(0,0,37),40,116,104,114,101,97,100,45,106,111,105,110,33,32,116,104,114,101,97,100,49,51,55,32,46,32,116,105,109,101,111,117,116,49,51,56,41,0,0,0};
static C_char C_TLS li26[] C_aligned={C_lihdr(0,0,29),40,116,104,114,101,97,100,45,116,101,114,109,105,110,97,116,101,33,32,116,104,114,101,97,100,49,53,57,41,0,0,0};
static C_char C_TLS li27[] C_aligned={C_lihdr(0,0,6),40,97,57,52,57,41,0,0};
static C_char C_TLS li28[] C_aligned={C_lihdr(0,0,16),40,97,57,52,48,32,114,101,116,117,114,110,49,54,56,41};
static C_char C_TLS li29[] C_aligned={C_lihdr(0,0,27),40,116,104,114,101,97,100,45,115,117,115,112,101,110,100,33,32,116,104,114,101,97,100,49,54,55,41,0,0,0,0,0};
static C_char C_TLS li30[] C_aligned={C_lihdr(0,0,26),40,116,104,114,101,97,100,45,114,101,115,117,109,101,33,32,116,104,114,101,97,100,49,55,50,41,0,0,0,0,0,0};
static C_char C_TLS li31[] C_aligned={C_lihdr(0,0,6),40,97,57,57,56,41,0,0};
static C_char C_TLS li32[] C_aligned={C_lihdr(0,0,16),40,97,57,56,54,32,114,101,116,117,114,110,49,55,56,41};
static C_char C_TLS li33[] C_aligned={C_lihdr(0,0,21),40,116,104,114,101,97,100,45,115,108,101,101,112,33,32,116,109,49,55,53,41,0,0,0};
static C_char C_TLS li34[] C_aligned={C_lihdr(0,0,13),40,109,117,116,101,120,63,32,120,49,56,52,41,0,0,0};
static C_char C_TLS li35[] C_aligned={C_lihdr(0,0,20),40,109,97,107,101,45,109,117,116,101,120,32,46,32,105,100,49,56,53,41,0,0,0,0};
static C_char C_TLS li36[] C_aligned={C_lihdr(0,0,17),40,109,117,116,101,120,45,110,97,109,101,32,120,49,56,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li37[] C_aligned={C_lihdr(0,0,25),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,32,109,117,116,101,120,49,57,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li38[] C_aligned={C_lihdr(0,0,35),40,109,117,116,101,120,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,109,117,116,101,120,49,57,50,32,120,49,57,51,41,0,0,0,0,0};
static C_char C_TLS li39[] C_aligned={C_lihdr(0,0,22),40,109,117,116,101,120,45,115,116,97,116,101,32,109,117,116,101,120,49,57,53,41,0,0};
static C_char C_TLS li40[] C_aligned={C_lihdr(0,0,8),40,115,119,105,116,99,104,41};
static C_char C_TLS li41[] C_aligned={C_lihdr(0,0,7),40,99,104,101,99,107,41,0};
static C_char C_TLS li42[] C_aligned={C_lihdr(0,0,7),40,97,49,50,52,51,41,0};
static C_char C_TLS li43[] C_aligned={C_lihdr(0,0,7),40,97,49,51,48,49,41,0};
static C_char C_TLS li44[] C_aligned={C_lihdr(0,0,17),40,97,49,49,49,54,32,114,101,116,117,114,110,50,49,49,41,0,0,0,0,0,0,0};
static C_char C_TLS li45[] C_aligned={C_lihdr(0,0,36),40,109,117,116,101,120,45,108,111,99,107,33,32,109,117,116,101,120,50,48,51,32,46,32,109,115,45,97,110,100,45,116,50,48,52,41,0,0,0,0};
static C_char C_TLS li46[] C_aligned={C_lihdr(0,0,7),40,97,49,52,54,52,41,0};
static C_char C_TLS li47[] C_aligned={C_lihdr(0,0,7),40,97,49,53,48,50,41,0};
static C_char C_TLS li48[] C_aligned={C_lihdr(0,0,17),40,97,49,51,52,57,32,114,101,116,117,114,110,50,53,56,41,0,0,0,0,0,0,0};
static C_char C_TLS li49[] C_aligned={C_lihdr(0,0,41),40,109,117,116,101,120,45,117,110,108,111,99,107,33,32,109,117,116,101,120,50,53,49,32,46,32,99,118,97,114,45,97,110,100,45,116,111,50,53,50,41,0,0,0,0,0,0,0};
static C_char C_TLS li50[] C_aligned={C_lihdr(0,0,35),40,109,97,107,101,45,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,32,46,32,110,97,109,101,50,57,48,41,0,0,0,0,0};
static C_char C_TLS li51[] C_aligned={C_lihdr(0,0,26),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,63,32,120,50,57,49,41,0,0,0,0,0,0};
static C_char C_TLS li52[] C_aligned={C_lihdr(0,0,31),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,110,97,109,101,32,99,118,50,57,50,41,0};
static C_char C_TLS li53[] C_aligned={C_lihdr(0,0,35),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,32,99,118,50,57,52,41,0,0,0,0,0};
static C_char C_TLS li54[] C_aligned={C_lihdr(0,0,45),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,112,101,99,105,102,105,99,45,115,101,116,33,32,99,118,50,57,54,32,120,50,57,55,41,0,0,0};
static C_char C_TLS li55[] C_aligned={C_lihdr(0,0,36),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,115,105,103,110,97,108,33,32,99,118,97,114,50,57,57,41,0,0,0,0};
static C_char C_TLS li56[] C_aligned={C_lihdr(0,0,17),40,108,111,111,112,51,49,49,32,103,51,49,53,51,49,55,41,0,0,0,0,0,0,0};
static C_char C_TLS li57[] C_aligned={C_lihdr(0,0,39),40,99,111,110,100,105,116,105,111,110,45,118,97,114,105,97,98,108,101,45,98,114,111,97,100,99,97,115,116,33,32,99,118,97,114,51,48,56,41,0};
static C_char C_TLS li58[] C_aligned={C_lihdr(0,0,7),40,97,49,55,52,48,41,0};
static C_char C_TLS li59[] C_aligned={C_lihdr(0,0,33),40,116,104,114,101,97,100,45,115,105,103,110,97,108,33,32,116,104,114,101,97,100,51,50,57,32,101,120,110,51,51,48,41,0,0,0,0,0,0,0};
static C_char C_TLS li60[] C_aligned={C_lihdr(0,0,40),40,116,104,114,101,97,100,45,119,97,105,116,45,102,111,114,45,105,47,111,33,32,102,100,51,53,51,32,46,32,116,109,112,51,53,50,51,53,52,41};
static C_char C_TLS li61[] C_aligned={C_lihdr(0,0,24),40,35,35,115,121,115,35,114,101,97,100,45,112,114,111,109,112,116,45,104,111,111,107,41};
static C_char C_TLS li62[] C_aligned={C_lihdr(0,0,10),40,116,111,112,108,101,118,101,108,41,0,0,0,0,0,0};


C_noret_decl(C_srfi_18_toplevel)
C_externexport void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_419)
static void C_ccall f_419(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_422)
static void C_ccall f_422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_599)
static void C_ccall f_599(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1864)
static void C_ccall f_1864(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1838)
static void C_ccall f_1838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1851)
static void C_ccall f_1851(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1854)
static void C_ccall f_1854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1799)
static void C_fcall f_1799(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1801)
static void C_ccall f_1801r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1805)
static void C_ccall f_1805(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1811)
static void C_ccall f_1811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1708)
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1792)
static void C_ccall f_1792(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1775)
static void C_ccall f_1775(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1758)
static void C_ccall f_1758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1730)
static void C_fcall f_1730(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_ccall f_1741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1745)
static void C_ccall f_1745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1649)
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1665)
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1695)
static void C_ccall f_1695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1656)
static void C_ccall f_1656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1606)
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1597)
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1579)
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1554)
static void C_ccall f_1554r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1562)
static void C_ccall f_1562(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1332)
static void C_ccall f_1332r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1350)
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1357)
static void C_ccall f_1357(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1526)
static void C_ccall f_1526(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1369)
static void C_fcall f_1369(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1511)
static void C_ccall f_1511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1503)
static void C_ccall f_1503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1465)
static void C_ccall f_1465(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1491)
static void C_ccall f_1491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1484)
static void C_ccall f_1484(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1372)
static void C_ccall f_1372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1375)
static void C_ccall f_1375(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1093)
static void C_ccall f_1093r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1103)
static void C_ccall f_1103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1117)
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f1953)
static void C_ccall f1953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1949)
static void C_ccall f1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f1945)
static void C_ccall f1945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1302)
static void C_ccall f_1302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1233)
static void C_ccall f_1233(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1239)
static void C_ccall f_1239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1244)
static void C_ccall f_1244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1284)
static void C_ccall f_1284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1254)
static void C_ccall f_1254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1141)
static void C_fcall f_1141(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1155)
static void C_ccall f_1155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1120)
static void C_fcall f_1120(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1131)
static void C_ccall f_1131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1069)
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1060)
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1051)
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1042)
static void C_ccall f_1042(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_1024)
static void C_ccall f_1024r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_1028)
static void C_ccall f_1028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1018)
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_978)
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1006)
static void C_ccall f_1006(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1013)
static void C_ccall f_1013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_987)
static void C_ccall f_987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_994)
static void C_ccall f_994(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_999)
static void C_ccall f_999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_956)
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_923)
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_941)
static void C_ccall f_941(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_950)
static void C_ccall f_950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_879)
static void C_ccall f_879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_918)
static void C_ccall f_918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_886)
static void C_ccall f_886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_895)
static void C_ccall f_895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_751)
static void C_ccall f_751r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_758)
static void C_ccall f_758(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_772)
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_776)
static void C_ccall f_776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_782)
static void C_ccall f_782(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_787)
static void C_ccall f_787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_845)
static void C_ccall f_845(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_826)
static void C_ccall f_826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_800)
static void C_ccall f_800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_715)
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_745)
static void C_ccall f_745(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_719)
static void C_fcall f_719(C_word t0,C_word t1) C_noret;
C_noret_decl(f_722)
static void C_ccall f_722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_728)
static void C_ccall f_728(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_706)
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_690)
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_704)
static void C_ccall f_704(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_681)
static void C_ccall f_681(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_672)
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_663)
static void C_ccall f_663(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_654)
static void C_ccall f_654(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_651)
static void C_ccall f_651(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_645)
static void C_ccall f_645(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_601)
static void C_ccall f_601(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_601)
static void C_ccall f_601r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_630)
static void C_ccall f_630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_605)
static void C_ccall f_605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_610)
static void C_ccall f_610(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_616)
static void C_ccall f_616r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_623)
static void C_ccall f_623(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_581)
static void C_ccall f_581(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_565)
static void C_ccall f_565(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_549)
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_533)
static void C_ccall f_533(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_525)
static void C_ccall f_525(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_512)
static void C_ccall f_512(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_523)
static void C_ccall f_523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_495)
static void C_ccall f_495(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_510)
static void C_ccall f_510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_486)
static void C_ccall f_486(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_473)
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_462)
static void C_ccall f_462(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_470)
static void C_ccall f_470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_424)
static void C_fcall f_424(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_453)
static void C_ccall f_453(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_1799)
static void C_fcall trf_1799(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1799(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1799(t0,t1);}

C_noret_decl(trf_1730)
static void C_fcall trf_1730(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1730(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1730(t0,t1);}

C_noret_decl(trf_1665)
static void C_fcall trf_1665(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1665(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1665(t0,t1,t2);}

C_noret_decl(trf_1369)
static void C_fcall trf_1369(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1369(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1369(t0,t1);}

C_noret_decl(trf_1141)
static void C_fcall trf_1141(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1141(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1141(t0,t1);}

C_noret_decl(trf_1120)
static void C_fcall trf_1120(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1120(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1120(t0,t1);}

C_noret_decl(trf_719)
static void C_fcall trf_719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_719(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_719(t0,t1);}

C_noret_decl(trf_424)
static void C_fcall trf_424(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_424(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_424(t0,t1,t2);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_srfi_18_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_srfi_18_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("srfi_18_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1103)){
C_save(t1);
C_rereclaim2(1103*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,114);
lf[1]=C_h_intern(&lf[1],4,"time");
lf[2]=C_h_intern(&lf[2],20,"current-milliseconds");
lf[3]=C_h_intern(&lf[3],15,"\003syssignal-hook");
lf[4]=C_h_intern(&lf[4],11,"\000type-error");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[6]=C_h_intern(&lf[6],12,"current-time");
lf[7]=C_h_intern(&lf[7],20,"srfi-18:current-time");
lf[8]=C_h_intern(&lf[8],13,"time->seconds");
lf[9]=C_decode_literal(C_heaptop,"\376U1000.0\000");
lf[10]=C_h_intern(&lf[10],18,"time->milliseconds");
lf[11]=C_h_intern(&lf[11],13,"seconds->time");
lf[12]=C_decode_literal(C_heaptop,"\376U1000.0\000");
lf[13]=C_h_intern(&lf[13],18,"\003sysexact->inexact");
lf[14]=C_h_intern(&lf[14],18,"milliseconds->time");
lf[15]=C_h_intern(&lf[15],5,"time\077");
lf[16]=C_h_intern(&lf[16],13,"srfi-18:time\077");
lf[17]=C_h_intern(&lf[17],5,"raise");
lf[18]=C_h_intern(&lf[18],10,"\003syssignal");
lf[19]=C_h_intern(&lf[19],23,"join-timeout-exception\077");
lf[20]=C_h_intern(&lf[20],9,"condition");
lf[21]=C_h_intern(&lf[21],22,"join-timeout-exception");
lf[22]=C_h_intern(&lf[22],26,"abandoned-mutex-exception\077");
lf[23]=C_h_intern(&lf[23],25,"abandoned-mutex-exception");
lf[24]=C_h_intern(&lf[24],28,"terminated-thread-exception\077");
lf[25]=C_h_intern(&lf[25],27,"terminated-thread-exception");
lf[26]=C_h_intern(&lf[26],19,"uncaught-exception\077");
lf[27]=C_h_intern(&lf[27],18,"uncaught-exception");
lf[28]=C_h_intern(&lf[28],25,"uncaught-exception-reason");
lf[29]=C_h_intern(&lf[29],11,"make-thread");
lf[30]=C_h_intern(&lf[30],12,"\003sysschedule");
lf[31]=C_h_intern(&lf[31],16,"\003systhread-kill!");
lf[32]=C_h_intern(&lf[32],4,"dead");
lf[33]=C_h_intern(&lf[33],18,"\003syscurrent-thread");
lf[34]=C_h_intern(&lf[34],15,"\003sysmake-thread");
lf[35]=C_h_intern(&lf[35],7,"created");
lf[36]=C_h_intern(&lf[36],6,"gensym");
lf[37]=C_h_intern(&lf[37],6,"thread");
lf[38]=C_h_intern(&lf[38],7,"thread\077");
lf[39]=C_h_intern(&lf[39],14,"current-thread");
lf[40]=C_h_intern(&lf[40],12,"thread-state");
lf[41]=C_h_intern(&lf[41],15,"thread-specific");
lf[42]=C_h_intern(&lf[42],20,"thread-specific-set!");
lf[43]=C_h_intern(&lf[43],14,"thread-quantum");
lf[44]=C_h_intern(&lf[44],19,"thread-quantum-set!");
lf[45]=C_h_intern(&lf[45],5,"fxmax");
lf[46]=C_h_intern(&lf[46],11,"thread-name");
lf[47]=C_h_intern(&lf[47],13,"thread-start!");
lf[48]=C_h_intern(&lf[48],5,"ready");
lf[49]=C_h_intern(&lf[49],22,"\003sysadd-to-ready-queue");
lf[50]=C_h_intern(&lf[50],9,"\003syserror");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000&thread cannot be started a second time");
lf[52]=C_h_intern(&lf[52],13,"thread-yield!");
lf[53]=C_h_intern(&lf[53],17,"\003systhread-yield!");
lf[54]=C_h_intern(&lf[54],12,"thread-join!");
lf[55]=C_h_intern(&lf[55],28,"\003sysremove-from-timeout-list");
lf[56]=C_h_intern(&lf[56],10,"terminated");
lf[57]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\001\000\000\006reason");
lf[58]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\022uncaught-exception\376\377\016");
lf[59]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\026join-timeout-exception\376\377\016");
lf[60]=C_h_intern(&lf[60],33,"\003systhread-block-for-termination!");
lf[61]=C_h_intern(&lf[61],29,"\003systhread-block-for-timeout!");
lf[62]=C_h_intern(&lf[62],17,"thread-terminate!");
lf[63]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\033terminated-thread-exception\376\377\016");
lf[64]=C_h_intern(&lf[64],21,"\003sysprimordial-thread");
lf[65]=C_h_intern(&lf[65],16,"\003sysexit-handler");
lf[66]=C_h_intern(&lf[66],15,"thread-suspend!");
lf[67]=C_h_intern(&lf[67],9,"suspended");
lf[68]=C_h_intern(&lf[68],14,"thread-resume!");
lf[69]=C_h_intern(&lf[69],13,"thread-sleep!");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\030invalid timeout argument");
lf[71]=C_h_intern(&lf[71],6,"mutex\077");
lf[72]=C_h_intern(&lf[72],5,"mutex");
lf[73]=C_h_intern(&lf[73],10,"make-mutex");
lf[74]=C_h_intern(&lf[74],14,"\003sysmake-mutex");
lf[75]=C_h_intern(&lf[75],10,"mutex-name");
lf[76]=C_h_intern(&lf[76],14,"mutex-specific");
lf[77]=C_h_intern(&lf[77],19,"mutex-specific-set!");
lf[78]=C_h_intern(&lf[78],11,"mutex-state");
lf[79]=C_h_intern(&lf[79],9,"not-owned");
lf[80]=C_h_intern(&lf[80],9,"abandoned");
lf[81]=C_h_intern(&lf[81],13,"not-abandoned");
lf[82]=C_h_intern(&lf[82],11,"mutex-lock!");
lf[83]=C_h_intern(&lf[83],10,"\003sysappend");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\031abandoned-mutex-exception\376\377\016");
lf[85]=C_h_intern(&lf[85],8,"\003sysdelq");
lf[86]=C_h_intern(&lf[86],8,"sleeping");
lf[87]=C_h_intern(&lf[87],13,"mutex-unlock!");
lf[88]=C_h_intern(&lf[88],18,"condition-variable");
lf[89]=C_h_intern(&lf[89],7,"running");
lf[90]=C_h_intern(&lf[90],7,"blocked");
lf[91]=C_h_intern(&lf[91],23,"make-condition-variable");
lf[92]=C_h_intern(&lf[92],19,"condition-variable\077");
lf[93]=C_h_intern(&lf[93],23,"condition-variable-name");
lf[94]=C_h_intern(&lf[94],27,"condition-variable-specific");
lf[95]=C_h_intern(&lf[95],32,"condition-variable-specific-set!");
lf[96]=C_h_intern(&lf[96],26,"condition-variable-signal!");
lf[97]=C_h_intern(&lf[97],25,"\003systhread-basic-unblock!");
lf[98]=C_h_intern(&lf[98],29,"condition-variable-broadcast!");
lf[99]=C_h_intern(&lf[99],14,"thread-signal!");
lf[100]=C_h_intern(&lf[100],19,"\003systhread-unblock!");
lf[101]=C_h_intern(&lf[101],20,"thread-wait-for-i/o!");
lf[102]=C_h_intern(&lf[102],25,"\003systhread-block-for-i/o!");
lf[103]=C_h_intern(&lf[103],4,"\000all");
lf[104]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[105]=C_h_intern(&lf[105],4,"msvc");
lf[106]=C_h_intern(&lf[106],20,"\003sysread-prompt-hook");
lf[107]=C_h_intern(&lf[107],13,"\003systty-port\077");
lf[108]=C_h_intern(&lf[108],18,"\003sysstandard-input");
lf[109]=C_h_intern(&lf[109],14,"build-platform");
lf[110]=C_h_intern(&lf[110],27,"condition-property-accessor");
lf[111]=C_h_intern(&lf[111],6,"reason");
lf[112]=C_h_intern(&lf[112],17,"register-feature!");
lf[113]=C_h_intern(&lf[113],7,"srfi-18");
C_register_lf2(lf,114,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_419,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_scheduler_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k417 */
static void C_ccall f_419(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_419,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_422,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:36: register-feature! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[112]+1)))(3,*((C_word*)lf[112]+1),t2,lf[113]);}

/* k420 in k417 */
static void C_ccall f_422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[36],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_422,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! ##sys#compute-time-limit ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_424,a[2]=((C_word)li0),tmp=(C_word)a,a+=3,tmp));
t3=C_mutate((C_word*)lf[6]+1 /* (set! current-time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_462,a[2]=((C_word)li1),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[7]+1 /* (set! srfi-18:current-time ...) */,*((C_word*)lf[6]+1));
t5=C_mutate((C_word*)lf[8]+1 /* (set! time->seconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_473,a[2]=((C_word)li2),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! time->milliseconds ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_486,a[2]=((C_word)li3),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[11]+1 /* (set! seconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_495,a[2]=((C_word)li4),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[14]+1 /* (set! milliseconds->time ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_512,a[2]=((C_word)li5),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[15]+1 /* (set! time? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_525,a[2]=((C_word)li6),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[16]+1 /* (set! srfi-18:time? ...) */,*((C_word*)lf[15]+1));
t11=C_mutate((C_word*)lf[17]+1 /* (set! raise ...) */,*((C_word*)lf[18]+1));
t12=C_mutate((C_word*)lf[19]+1 /* (set! join-timeout-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_533,a[2]=((C_word)li7),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[22]+1 /* (set! abandoned-mutex-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_549,a[2]=((C_word)li8),tmp=(C_word)a,a+=3,tmp));
t14=C_mutate((C_word*)lf[24]+1 /* (set! terminated-thread-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_565,a[2]=((C_word)li9),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[26]+1 /* (set! uncaught-exception? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_581,a[2]=((C_word)li10),tmp=(C_word)a,a+=3,tmp));
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_599,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:104: condition-property-accessor */
((C_proc4)C_retrieve_proc(*((C_word*)lf[110]+1)))(4,*((C_word*)lf[110]+1),t16,lf[27],lf[111]);}

/* k597 in k420 in k417 */
static void C_ccall f_599(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word ab[99],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_599,2,t0,t1);}
t2=C_mutate((C_word*)lf[28]+1 /* (set! uncaught-exception-reason ...) */,t1);
t3=C_mutate((C_word*)lf[29]+1 /* (set! make-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_601,a[2]=((C_word)li13),tmp=(C_word)a,a+=3,tmp));
t4=C_mutate((C_word*)lf[38]+1 /* (set! thread? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_645,a[2]=((C_word)li14),tmp=(C_word)a,a+=3,tmp));
t5=C_mutate((C_word*)lf[39]+1 /* (set! current-thread ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_651,a[2]=((C_word)li15),tmp=(C_word)a,a+=3,tmp));
t6=C_mutate((C_word*)lf[40]+1 /* (set! thread-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_654,a[2]=((C_word)li16),tmp=(C_word)a,a+=3,tmp));
t7=C_mutate((C_word*)lf[41]+1 /* (set! thread-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_663,a[2]=((C_word)li17),tmp=(C_word)a,a+=3,tmp));
t8=C_mutate((C_word*)lf[42]+1 /* (set! thread-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_672,a[2]=((C_word)li18),tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[43]+1 /* (set! thread-quantum ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_681,a[2]=((C_word)li19),tmp=(C_word)a,a+=3,tmp));
t10=C_mutate((C_word*)lf[44]+1 /* (set! thread-quantum-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_690,a[2]=((C_word)li20),tmp=(C_word)a,a+=3,tmp));
t11=C_mutate((C_word*)lf[46]+1 /* (set! thread-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_706,a[2]=((C_word)li21),tmp=(C_word)a,a+=3,tmp));
t12=C_mutate((C_word*)lf[47]+1 /* (set! thread-start! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_715,a[2]=((C_word)li22),tmp=(C_word)a,a+=3,tmp));
t13=C_mutate((C_word*)lf[52]+1 /* (set! thread-yield! ...) */,*((C_word*)lf[53]+1));
t14=C_mutate((C_word*)lf[54]+1 /* (set! thread-join! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_751,a[2]=((C_word)li25),tmp=(C_word)a,a+=3,tmp));
t15=C_mutate((C_word*)lf[62]+1 /* (set! thread-terminate! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_879,a[2]=((C_word)li26),tmp=(C_word)a,a+=3,tmp));
t16=C_mutate((C_word*)lf[66]+1 /* (set! thread-suspend! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_923,a[2]=((C_word)li29),tmp=(C_word)a,a+=3,tmp));
t17=C_mutate((C_word*)lf[68]+1 /* (set! thread-resume! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_956,a[2]=((C_word)li30),tmp=(C_word)a,a+=3,tmp));
t18=C_mutate((C_word*)lf[69]+1 /* (set! thread-sleep! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_978,a[2]=((C_word)li33),tmp=(C_word)a,a+=3,tmp));
t19=C_mutate((C_word*)lf[71]+1 /* (set! mutex? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1018,a[2]=((C_word)li34),tmp=(C_word)a,a+=3,tmp));
t20=C_mutate((C_word*)lf[73]+1 /* (set! make-mutex ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1024,a[2]=((C_word)li35),tmp=(C_word)a,a+=3,tmp));
t21=C_mutate((C_word*)lf[75]+1 /* (set! mutex-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1042,a[2]=((C_word)li36),tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[76]+1 /* (set! mutex-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1051,a[2]=((C_word)li37),tmp=(C_word)a,a+=3,tmp));
t23=C_mutate((C_word*)lf[77]+1 /* (set! mutex-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1060,a[2]=((C_word)li38),tmp=(C_word)a,a+=3,tmp));
t24=C_mutate((C_word*)lf[78]+1 /* (set! mutex-state ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1069,a[2]=((C_word)li39),tmp=(C_word)a,a+=3,tmp));
t25=C_mutate((C_word*)lf[82]+1 /* (set! mutex-lock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1093,a[2]=((C_word)li45),tmp=(C_word)a,a+=3,tmp));
t26=C_mutate((C_word*)lf[87]+1 /* (set! mutex-unlock! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1332,a[2]=((C_word)li49),tmp=(C_word)a,a+=3,tmp));
t27=C_mutate((C_word*)lf[91]+1 /* (set! make-condition-variable ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1554,a[2]=((C_word)li50),tmp=(C_word)a,a+=3,tmp));
t28=C_mutate((C_word*)lf[92]+1 /* (set! condition-variable? ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1573,a[2]=((C_word)li51),tmp=(C_word)a,a+=3,tmp));
t29=C_mutate((C_word*)lf[93]+1 /* (set! condition-variable-name ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1579,a[2]=((C_word)li52),tmp=(C_word)a,a+=3,tmp));
t30=C_mutate((C_word*)lf[94]+1 /* (set! condition-variable-specific ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1588,a[2]=((C_word)li53),tmp=(C_word)a,a+=3,tmp));
t31=C_mutate((C_word*)lf[95]+1 /* (set! condition-variable-specific-set! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1597,a[2]=((C_word)li54),tmp=(C_word)a,a+=3,tmp));
t32=C_mutate((C_word*)lf[96]+1 /* (set! condition-variable-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1606,a[2]=((C_word)li55),tmp=(C_word)a,a+=3,tmp));
t33=C_mutate((C_word*)lf[98]+1 /* (set! condition-variable-broadcast! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1649,a[2]=((C_word)li57),tmp=(C_word)a,a+=3,tmp));
t34=C_mutate((C_word*)lf[99]+1 /* (set! thread-signal! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1708,a[2]=((C_word)li59),tmp=(C_word)a,a+=3,tmp));
t35=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1799,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t36=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1864,a[2]=t35,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:452: build-platform */
((C_proc2)C_retrieve_proc(*((C_word*)lf[109]+1)))(2,*((C_word*)lf[109]+1),t36);}

/* k1862 in k597 in k420 in k417 */
static void C_ccall f_1864(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1864,2,t0,t1);}
t2=C_eqp(t1,lf[105]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
f_1799(t3,C_SCHEME_UNDEFINED);}
else{
t3=*((C_word*)lf[106]+1);
t4=C_mutate((C_word*)lf[106]+1 /* (set! ##sys#read-prompt-hook ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1838,a[2]=t3,a[3]=((C_word)li61),tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t0)[2];
f_1799(t5,t4);}}

/* ##sys#read-prompt-hook in k1862 in k597 in k420 in k417 */
static void C_ccall f_1838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1838,2,t0,t1);}
t2=C_fudge(C_fix(12));
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_1848(2,t4,t2);}
else{
/* srfi-18.scm:456: ##sys#tty-port? */
((C_proc3)C_retrieve_proc(*((C_word*)lf[107]+1)))(3,*((C_word*)lf[107]+1),t3,*((C_word*)lf[108]+1));}}

/* k1846 in ##sys#read-prompt-hook in k1862 in k597 in k420 in k417 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1851,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:457: old */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1849 in k1846 in ##sys#read-prompt-hook in k1862 in k597 in k420 in k417 */
static void C_ccall f_1851(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1851,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1854,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:458: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[102]+1)))(5,*((C_word*)lf[102]+1),t2,*((C_word*)lf[33]+1),C_fix(0),C_SCHEME_TRUE);}

/* k1852 in k1849 in k1846 in ##sys#read-prompt-hook in k1862 in k597 in k420 in k417 */
static void C_ccall f_1854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:459: thread-yield! */
t2=*((C_word*)lf[52]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k1797 in k597 in k420 in k417 */
static void C_fcall f_1799(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1799,NULL,2,t0,t1);}
t2=C_mutate((C_word*)lf[101]+1 /* (set! thread-wait-for-i/o! ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1801,a[2]=((C_word)li60),tmp=(C_word)a,a+=3,tmp));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_UNDEFINED);}

/* thread-wait-for-i/o! in k1797 in k597 in k420 in k417 */
static void C_ccall f_1801(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_1801r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1801r(t0,t1,t2,t3);}}

static void C_ccall f_1801r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1805,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
t5=t4;
f_1805(2,t5,lf[103]);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_1805(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[50]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[104],t3);}}}

/* k1803 in thread-wait-for-i/o! in k1797 in k597 in k420 in k417 */
static void C_ccall f_1805(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1805,2,t0,t1);}
t2=C_i_check_exact_2(((C_word*)t0)[3],lf[101]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1811,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:466: ##sys#thread-block-for-i/o! */
((C_proc5)C_retrieve_proc(*((C_word*)lf[102]+1)))(5,*((C_word*)lf[102]+1),t3,*((C_word*)lf[33]+1),((C_word*)t0)[3],t1);}

/* k1809 in k1803 in thread-wait-for-i/o! in k1797 in k597 in k420 in k417 */
static void C_ccall f_1811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:467: thread-yield! */
t2=*((C_word*)lf[52]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1708(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[10],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1708,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[99]);
t5=C_eqp(t2,*((C_word*)lf[33]+1));
if(C_truep(t5)){
/* srfi-18.scm:431: ##sys#signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t1,t3);}
else{
t6=C_slot(t2,C_fix(1));
t7=C_slot(t2,C_fix(11));
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1730,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_structurep(t7,lf[88]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1758,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t7,C_fix(2));
/* srfi-18.scm:436: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t9,t2,t10);}
else{
if(C_truep(C_i_structurep(t7,lf[72]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1775,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t7,C_fix(3));
/* srfi-18.scm:438: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t9,t2,t10);}
else{
if(C_truep(C_i_structurep(t7,lf[37]))){
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1792,a[2]=t7,a[3]=t8,tmp=(C_word)a,a+=4,tmp);
t10=C_slot(t7,C_fix(12));
/* srfi-18.scm:440: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t9,t2,t10);}
else{
t9=t8;
f_1730(t9,C_SCHEME_UNDEFINED);}}}}}

/* k1790 in thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1792(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1730(t2,C_i_setslot(((C_word*)t0)[2],C_fix(12),t1));}

/* k1773 in thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1775(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1730(t2,C_i_setslot(((C_word*)t0)[2],C_fix(3),t1));}

/* k1756 in thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1730(t2,C_i_setslot(((C_word*)t0)[2],C_fix(2),t1));}

/* k1728 in thread-signal! in k597 in k420 in k417 */
static void C_fcall f_1730(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1730,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1741,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word)li58),tmp=(C_word)a,a+=5,tmp);
t3=C_i_setslot(((C_word*)t0)[3],C_fix(1),t2);
t4=C_i_setslot(((C_word*)t0)[3],C_fix(3),lf[90]);
/* srfi-18.scm:447: ##sys#thread-unblock! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[100]+1)))(3,*((C_word*)lf[100]+1),((C_word*)t0)[2],((C_word*)t0)[3]);}

/* a1740 in k1728 in thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1741,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1745,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:444: ##sys#signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,((C_word*)t0)[2]);}

/* k1743 in a1740 in k1728 in thread-signal! in k597 in k420 in k417 */
static void C_ccall f_1745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:445: old */
t2=((C_word*)t0)[3];
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* condition-variable-broadcast! in k597 in k420 in k417 */
static void C_ccall f_1649(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1649,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[88],lf[98]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1656,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_slot(t2,C_fix(2));
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1665,a[2]=t7,a[3]=((C_word)li56),tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_1665(t9,t4,t5);}

/* loop311 in condition-variable-broadcast! in k597 in k420 in k417 */
static void C_fcall f_1665(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_1665,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1695,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_slot(t4,C_fix(3));
t6=C_eqp(t5,lf[90]);
t7=(C_truep(t6)?t6:C_eqp(t5,lf[86]));
if(C_truep(t7)){
/* srfi-18.scm:420: ##sys#thread-basic-unblock! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),t3,t4);}
else{
t8=C_slot(t2,C_fix(1));
t11=t1;
t12=t8;
t1=t11;
t2=t12;
goto loop;}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1693 in loop311 in condition-variable-broadcast! in k597 in k420 in k417 */
static void C_ccall f_1695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1665(t3,((C_word*)t0)[2],t2);}

/* k1654 in condition-variable-broadcast! in k597 in k420 in k417 */
static void C_ccall f_1656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(2),C_SCHEME_END_OF_LIST));}

/* condition-variable-signal! in k597 in k420 in k417 */
static void C_ccall f_1606(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1606,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[88],lf[96]);
t4=C_slot(t2,C_fix(2));
if(C_truep(C_i_nullp(t4))){
t5=C_SCHEME_UNDEFINED;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_slot(t4,C_fix(0));
t6=C_slot(t5,C_fix(3));
t7=C_slot(t4,C_fix(1));
t8=C_i_setslot(t2,C_fix(2),t7);
t9=C_eqp(t6,lf[90]);
if(C_truep(t9)){
if(C_truep(t9)){
/* srfi-18.scm:411: ##sys#thread-basic-unblock! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),t1,t5);}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_UNDEFINED);}}
else{
t10=C_eqp(t6,lf[86]);
if(C_truep(t10)){
/* srfi-18.scm:411: ##sys#thread-basic-unblock! */
((C_proc3)C_retrieve_proc(*((C_word*)lf[97]+1)))(3,*((C_word*)lf[97]+1),t1,t5);}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_UNDEFINED);}}}}

/* condition-variable-specific-set! in k597 in k420 in k417 */
static void C_ccall f_1597(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1597,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[88],lf[95]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(3),t3));}

/* condition-variable-specific in k597 in k420 in k417 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1588,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[88],lf[94]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* condition-variable-name in k597 in k420 in k417 */
static void C_ccall f_1579(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1579,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[88],lf[93]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* condition-variable? in k597 in k420 in k417 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1573,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[88]));}

/* make-condition-variable in k597 in k420 in k417 */
static void C_ccall f_1554(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr2r,(void*)f_1554r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1554r(t0,t1,t2);}}

static void C_ccall f_1554r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(8);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1562,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[88],t4,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}
else{
/* srfi-18.scm:383: gensym */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,lf[88]);}}

/* k1560 in make-condition-variable in k597 in k420 in k417 */
static void C_ccall f_1562(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1562,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,4,lf[88],t1,C_SCHEME_END_OF_LIST,C_SCHEME_UNDEFINED));}

/* mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1332(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_1332r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1332r(t0,t1,t2,t3);}}

static void C_ccall f_1332r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word *a=C_alloc(7);
t4=C_i_check_structure_2(t2,lf[72],lf[87]);
t5=*((C_word*)lf[33]+1);
t6=C_i_pairp(t3);
t7=(C_truep(t6)?C_i_car(t3):C_SCHEME_FALSE);
t8=C_i_length(t3);
t9=C_fixnum_greaterp(t8,C_fix(1));
t10=(C_truep(t9)?C_i_cadr(t3):C_SCHEME_FALSE);
t11=(C_truep(t7)?C_i_check_structure_2(t7,lf[88],lf[87]):C_SCHEME_UNDEFINED);
t12=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1350,a[2]=t10,a[3]=t7,a[4]=t5,a[5]=t2,a[6]=((C_word)li48),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:334: ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t12);}

/* a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1350(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1350,3,t0,t1,t2);}
t3=C_slot(((C_word*)t0)[5],C_fix(3));
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1357,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm:337: ##sys#compute-time-limit */
f_424(t4,((C_word*)t0)[2],lf[87]);}
else{
t5=t4;
f_1357(2,t5,C_SCHEME_FALSE);}}

/* k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1357(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1357,2,t0,t1);}
t2=C_i_set_i_slot(((C_word*)t0)[7],C_fix(4),C_SCHEME_FALSE);
t3=C_i_set_i_slot(((C_word*)t0)[7],C_fix(5),C_SCHEME_FALSE);
t4=C_slot(((C_word*)t0)[7],C_fix(2));
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1369,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t4)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1526,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_slot(t4,C_fix(8));
/* srfi-18.scm:342: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t6,((C_word*)t0)[7],t7);}
else{
t6=t5;
f_1369(t6,C_SCHEME_UNDEFINED);}}

/* k1524 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1526(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
f_1369(t2,C_i_setslot(((C_word*)t0)[2],C_fix(8),t1));}

/* k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_fcall f_1369(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1369,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1372,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1511,a[2]=t2,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(((C_word*)t0)[3],C_fix(2));
t5=C_a_i_list(&a,1,((C_word*)t0)[8]);
/* srfi-18.scm:344: ##sys#append */
t6=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t3,t4,t5);}
else{
t3=t2;
f_1372(2,t3,C_SCHEME_UNDEFINED);}}

/* k1509 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1511,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[6],C_fix(2),t1);
t3=C_i_setslot(((C_word*)t0)[5],C_fix(11),((C_word*)t0)[6]);
if(C_truep(((C_word*)t0)[4])){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1465,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word)li46),tmp=(C_word)a,a+=6,tmp);
t5=C_i_setslot(((C_word*)t0)[5],C_fix(1),t4);
/* srfi-18.scm:357: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),((C_word*)t0)[2],((C_word*)t0)[5],((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1503,a[2]=((C_word*)t0)[3],a[3]=((C_word)li47),tmp=(C_word)a,a+=4,tmp);
t5=C_i_setslot(((C_word*)t0)[5],C_fix(1),t4);
t6=((C_word*)t0)[2];
f_1372(2,t6,C_i_setslot(((C_word*)t0)[5],C_fix(3),lf[86]));}}

/* a1502 in k1509 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1503,2,t0,t1);}
/* srfi-18.scm:359: return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_TRUE);}

/* a1464 in k1509 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1465(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1465,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1491,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=C_slot(((C_word*)t0)[4],C_fix(2));
/* srfi-18.scm:350: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t2,((C_word*)t0)[3],t3);}

/* k1489 in a1464 in k1509 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1491,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[5],C_fix(2),t1);
t3=C_i_set_i_slot(((C_word*)t0)[4],C_fix(11),C_SCHEME_FALSE);
if(C_truep(C_slot(((C_word*)t0)[4],C_fix(13)))){
/* srfi-18.scm:353: return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1484,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:355: ##sys#remove-from-timeout-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),t4,((C_word*)t0)[4]);}}

/* k1482 in k1489 in a1464 in k1509 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1484(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:356: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1370 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1372,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1375,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[3]))){
t3=t2;
f_1375(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=C_slot(((C_word*)t0)[3],C_fix(0));
t4=C_slot(t3,C_fix(3));
t5=C_slot(((C_word*)t0)[3],C_fix(1));
t6=C_i_setslot(((C_word*)t0)[2],C_fix(3),t5);
t7=C_i_set_i_slot(((C_word*)t0)[2],C_fix(5),C_SCHEME_TRUE);
t8=C_eqp(t4,lf[90]);
t9=(C_truep(t8)?t8:C_eqp(t4,lf[86]));
if(C_truep(t9)){
t10=C_i_setslot(((C_word*)t0)[2],C_fix(2),t3);
t11=C_slot(t3,C_fix(8));
t12=C_a_i_cons(&a,2,((C_word*)t0)[2],t11);
t13=C_i_setslot(t3,C_fix(8),t12);
t14=C_i_set_i_slot(t3,C_fix(11),C_SCHEME_FALSE);
t15=C_eqp(t4,lf[86]);
if(C_truep(t15)){
/* srfi-18.scm:370: ##sys#add-to-ready-queue */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t2,t3);}
else{
t16=t2;
f_1375(2,t16,C_SCHEME_UNDEFINED);}}
else{
t10=C_SCHEME_UNDEFINED;
t11=t2;
f_1375(2,t11,t10);}}}

/* k1373 in k1370 in k1367 in k1355 in a1349 in mutex-unlock! in k597 in k420 in k417 */
static void C_ccall f_1375(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(3));
t3=C_eqp(t2,lf[89]);
if(C_truep(t3)){
/* srfi-18.scm:372: return */
t4=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t4))(3,t4,((C_word*)t0)[2],C_SCHEME_TRUE);}
else{
/* srfi-18.scm:373: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}}

/* mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1093(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_1093r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1093r(t0,t1,t2,t3);}}

static void C_ccall f_1093r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[72],lf[82]);
t5=C_i_pairp(t3);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1103,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=C_i_car(t3);
/* srfi-18.scm:272: ##sys#compute-time-limit */
f_424(t6,t7,lf[82]);}
else{
t7=t6;
f_1103(2,t7,C_SCHEME_FALSE);}}

/* k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1103,2,t0,t1);}
t2=C_i_length(((C_word*)t0)[4]);
t3=C_fixnum_greaterp(t2,C_fix(1));
t4=(C_truep(t3)?C_i_cadr(((C_word*)t0)[4]):C_SCHEME_FALSE);
t5=(C_truep(t4)?C_i_check_structure_2(t4,lf[37],lf[82]):C_SCHEME_UNDEFINED);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1117,a[2]=t3,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word)li44),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:276: ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1117(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[24],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1117,3,t0,t1,t2);}
t3=*((C_word*)lf[33]+1);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1120,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word)li40),tmp=(C_word)a,a+=5,tmp));
t9=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1141,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word)li41),tmp=(C_word)a,a+=5,tmp));
if(C_truep(C_slot(((C_word*)t0)[5],C_fix(5)))){
if(C_truep(((C_word*)t0)[4])){
t10=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_1233,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=t5,a[5]=t7,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=t3,a[9]=((C_word*)t0)[5],tmp=(C_word)a,a+=10,tmp);
/* srfi-18.scm:305: check */
t11=((C_word*)t7)[1];
f_1141(t11,t10);}
else{
t10=C_i_setslot(t3,C_fix(3),lf[86]);
t11=C_i_setslot(t3,C_fix(11),((C_word*)t0)[5]);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1302,a[2]=t7,a[3]=t2,a[4]=((C_word)li43),tmp=(C_word)a,a+=5,tmp);
t13=C_i_setslot(t3,C_fix(1),t12);
/* srfi-18.scm:323: switch */
t14=((C_word*)t5)[1];
f_1120(t14,t1);}}
else{
t10=(C_truep(((C_word*)t0)[2])?C_i_not(((C_word*)t0)[3]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=C_i_set_i_slot(((C_word*)t0)[5],C_fix(2),C_SCHEME_FALSE);
t12=C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),C_SCHEME_TRUE);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f1945,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:302: check */
t14=((C_word*)t7)[1];
f_1141(t14,t13);}
else{
t11=(C_truep(((C_word*)t0)[3])?((C_word*)t0)[3]:t3);
t12=C_slot(t11,C_fix(3));
t13=C_eqp(lf[56],t12);
t14=(C_truep(t13)?t13:C_eqp(lf[32],t12));
if(C_truep(t14)){
t15=C_i_set_i_slot(((C_word*)t0)[5],C_fix(4),C_SCHEME_TRUE);
t16=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f1949,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:302: check */
t17=((C_word*)t7)[1];
f_1141(t17,t16);}
else{
t15=C_i_set_i_slot(((C_word*)t0)[5],C_fix(5),C_SCHEME_TRUE);
t16=C_slot(t11,C_fix(8));
t17=C_a_i_cons(&a,2,((C_word*)t0)[5],t16);
t18=C_i_setslot(t11,C_fix(8),t17);
t19=C_i_setslot(t11,C_fix(11),((C_word*)t0)[5]);
t20=C_i_setslot(((C_word*)t0)[5],C_fix(2),t11);
t21=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f1953,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:302: check */
t22=((C_word*)t7)[1];
f_1141(t22,t21);}}}}

/* f1953 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f1953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:303: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* f1949 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:303: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* f1945 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f1945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:303: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* a1301 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1302,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1306,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:322: check */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1141(t3,t2);}

/* k1304 in a1301 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:322: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],C_SCHEME_TRUE);}

/* k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1233(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1233,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1244,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],a[7]=((C_word)li42),tmp=(C_word)a,a+=8,tmp);
t3=C_i_setslot(((C_word*)t0)[8],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1239,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:317: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t4,((C_word*)t0)[8],((C_word*)t0)[2]);}

/* k1237 in k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:318: switch */
t2=((C_word*)((C_word*)t0)[3])[1];
f_1120(t2,((C_word*)t0)[2]);}

/* a1243 in k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1244,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1284,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=C_slot(((C_word*)t0)[6],C_fix(3));
/* srfi-18.scm:309: ##sys#delq */
((C_proc4)C_retrieve_proc(*((C_word*)lf[85]+1)))(4,*((C_word*)lf[85]+1),t2,((C_word*)t0)[5],t3);}

/* k1282 in a1243 in k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1284,2,t0,t1);}
t2=C_i_setslot(((C_word*)t0)[7],C_fix(3),t1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1251,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_slot(((C_word*)t0)[6],C_fix(13)))){
t4=t3;
f_1251(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm:311: ##sys#remove-from-timeout-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),t3,((C_word*)t0)[6]);}}

/* k1249 in k1282 in a1243 in k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1251,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1254,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:312: check */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1141(t3,t2);}

/* k1252 in k1249 in k1282 in a1243 in k1231 in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1254,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(8));
t3=C_a_i_cons(&a,2,((C_word*)t0)[5],t2);
t4=C_i_setslot(((C_word*)t0)[6],C_fix(8),t3);
t5=C_i_set_i_slot(((C_word*)t0)[6],C_fix(11),C_SCHEME_FALSE);
t6=C_i_setslot(((C_word*)t0)[5],C_fix(2),((C_word*)t0)[4]);
/* srfi-18.scm:316: return */
t7=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t7))(3,t7,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* check in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_fcall f_1141(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1141,NULL,2,t0,t1);}
if(C_truep(C_slot(((C_word*)t0)[3],C_fix(4)))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1155,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_a_i_record(&a,3,lf[20],lf[84],C_SCHEME_END_OF_LIST);
/* srfi-18.scm:285: ##sys#signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t2,t3);}
else{
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1153 in check in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:284: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* switch in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_fcall f_1120(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1120,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1131,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(3));
t4=C_a_i_list(&a,1,((C_word*)t0)[2]);
/* srfi-18.scm:280: ##sys#append */
t5=*((C_word*)lf[83]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}

/* k1129 in switch in a1116 in k1101 in mutex-lock! in k597 in k420 in k417 */
static void C_ccall f_1131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_setslot(((C_word*)t0)[3],C_fix(3),t1);
/* srfi-18.scm:281: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}

/* mutex-state in k597 in k420 in k417 */
static void C_ccall f_1069(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1069,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[72],lf[78]);
if(C_truep(C_slot(t2,C_fix(5)))){
t4=C_slot(t2,C_fix(2));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:lf[79]));}
else{
t4=C_slot(t2,C_fix(4));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?lf[80]:lf[81]));}}

/* mutex-specific-set! in k597 in k420 in k417 */
static void C_ccall f_1060(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1060,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[72],lf[77]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(6),t3));}

/* mutex-specific in k597 in k420 in k417 */
static void C_ccall f_1051(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1051,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[72],lf[76]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(6)));}

/* mutex-name in k597 in k420 in k417 */
static void C_ccall f_1042(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1042,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[72],lf[75]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* make-mutex in k597 in k420 in k417 */
static void C_ccall f_1024(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_1024r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_1024r(t0,t1,t2);}}

static void C_ccall f_1024r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1028,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
/* srfi-18.scm:247: ##sys#make-mutex */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),t1,t4,*((C_word*)lf[33]+1));}
else{
/* srfi-18.scm:246: gensym */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t3,lf[72]);}}

/* k1026 in make-mutex in k597 in k420 in k417 */
static void C_ccall f_1028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:247: ##sys#make-mutex */
((C_proc4)C_retrieve_proc(*((C_word*)lf[74]+1)))(4,*((C_word*)lf[74]+1),((C_word*)t0)[2],t1,*((C_word*)lf[33]+1));}

/* mutex? in k597 in k420 in k417 */
static void C_ccall f_1018(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1018,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[72]));}

/* thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_978(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_978,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1006,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t2)){
t4=t3;
f_1006(2,t4,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm:236: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t3,lf[4],lf[69],lf[70],t2);}}

/* k1004 in thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_1006(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1006,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1013,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:237: ##sys#compute-time-limit */
f_424(t2,((C_word*)t0)[2],lf[69]);}

/* k1011 in k1004 in thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_1013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1013,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_987,a[2]=t1,a[3]=((C_word)li32),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:230: ##sys#call-with-current-continuation */
C_call_cc(3,0,t2,t3);}

/* a986 in k1011 in k1004 in thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_987,3,t0,t1,t2);}
t3=*((C_word*)lf[33]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_999,a[2]=t2,a[3]=((C_word)li31),tmp=(C_word)a,a+=4,tmp);
t5=C_i_setslot(t3,C_fix(1),t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_994,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:234: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t6,t3,((C_word*)t0)[2]);}

/* k992 in a986 in k1011 in k1004 in thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_994(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:235: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}

/* a998 in a986 in k1011 in k1004 in thread-sleep! in k597 in k420 in k417 */
static void C_ccall f_999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_999,2,t0,t1);}
/* srfi-18.scm:233: return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-resume! in k597 in k420 in k417 */
static void C_ccall f_956(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_956,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[68]);
t4=C_slot(t2,C_fix(3));
t5=C_eqp(t4,lf[67]);
if(C_truep(t5)){
t6=C_i_setslot(t2,C_fix(3),lf[48]);
/* srfi-18.scm:226: ##sys#add-to-ready-queue */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t1,t2);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* thread-suspend! in k597 in k420 in k417 */
static void C_ccall f_923(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_923,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[66]);
t4=C_i_setslot(t2,C_fix(3),lf[67]);
t5=C_eqp(t2,*((C_word*)lf[33]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_941,a[2]=t2,a[3]=((C_word)li28),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:217: ##sys#call-with-current-continuation */
C_call_cc(3,0,t1,t6);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* a940 in thread-suspend! in k597 in k420 in k417 */
static void C_ccall f_941(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_941,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_950,a[2]=t2,a[3]=((C_word)li27),tmp=(C_word)a,a+=4,tmp);
t4=C_i_setslot(((C_word*)t0)[2],C_fix(1),t3);
/* srfi-18.scm:220: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),t1);}

/* a949 in a940 in thread-suspend! in k597 in k420 in k417 */
static void C_ccall f_950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_950,2,t0,t1);}
/* srfi-18.scm:219: return */
t2=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t2))(3,t2,t1,C_SCHEME_UNDEFINED);}

/* thread-terminate! in k597 in k420 in k417 */
static void C_ccall f_879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_879,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[62]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_886,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_eqp(t2,*((C_word*)lf[64]+1));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_918,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:207: ##sys#exit-handler */
((C_proc2)C_retrieve_proc(*((C_word*)lf[65]+1)))(2,*((C_word*)lf[65]+1),t6);}
else{
t6=t4;
f_886(2,t6,C_SCHEME_UNDEFINED);}}

/* k916 in thread-terminate! in k597 in k420 in k417 */
static void C_ccall f_918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g160161 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k884 in thread-terminate! in k597 in k420 in k417 */
static void C_ccall f_886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_886,2,t0,t1);}
t2=C_a_i_list(&a,1,C_SCHEME_UNDEFINED);
t3=C_i_setslot(((C_word*)t0)[3],C_fix(2),t2);
t4=C_a_i_record(&a,3,lf[20],lf[63],C_SCHEME_END_OF_LIST);
t5=C_i_setslot(((C_word*)t0)[3],C_fix(7),t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_895,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:210: ##sys#thread-kill! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t6,((C_word*)t0)[3],lf[56]);}

/* k893 in k884 in thread-terminate! in k597 in k420 in k417 */
static void C_ccall f_895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(((C_word*)t0)[3],*((C_word*)lf[33]+1));
if(C_truep(t2)){
/* srfi-18.scm:211: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* thread-join! in k597 in k420 in k417 */
static void C_ccall f_751(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_751r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_751r(t0,t1,t2,t3);}}

static void C_ccall f_751r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(5);
t4=C_i_check_structure_2(t2,lf[37],lf[54]);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_758,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t3))){
t6=C_slot(t3,C_fix(0));
/* srfi-18.scm:173: ##sys#compute-time-limit */
f_424(t5,t6,lf[54]);}
else{
t6=t5;
f_758(2,t6,C_SCHEME_FALSE);}}

/* k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_758(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_758,2,t0,t1);}
t2=C_i_pairp(((C_word*)t0)[4]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[4],C_fix(1)):C_SCHEME_FALSE);
t4=(C_truep(t3)?C_i_pairp(t3):C_SCHEME_FALSE);
t5=(C_truep(t4)?C_slot(t3,C_fix(0)):C_SCHEME_FALSE);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_772,a[2]=t1,a[3]=t5,a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word)li24),tmp=(C_word)a,a+=7,tmp);
/* srfi-18.scm:177: ##sys#call-with-current-continuation */
C_call_cc(3,0,((C_word*)t0)[2],t6);}

/* a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_772(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_772,3,t0,t1,t2);}
t3=*((C_word*)lf[33]+1);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_776,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* srfi-18.scm:180: ##sys#thread-block-for-timeout! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[61]+1)))(4,*((C_word*)lf[61]+1),t4,t3,((C_word*)t0)[2]);}
else{
t5=t4;
f_776(2,t5,C_SCHEME_UNDEFINED);}}

/* k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_776,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_787,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word)li23),tmp=(C_word)a,a+=8,tmp);
t3=C_i_setslot(((C_word*)t0)[5],C_fix(1),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_782,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:201: ##sys#thread-block-for-termination! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[60]+1)))(4,*((C_word*)lf[60]+1),t4,((C_word*)t0)[5],((C_word*)t0)[7]);}

/* k780 in k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_782(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:202: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}

/* a786 in k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[14],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_787,2,t0,t1);}
t2=C_slot(((C_word*)t0)[6],C_fix(3));
t3=C_eqp(t2,lf[32]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_800,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_slot(((C_word*)t0)[4],C_fix(13)))){
t5=C_slot(((C_word*)t0)[6],C_fix(2));
C_apply(4,0,t1,((C_word*)t0)[5],t5);}
else{
/* srfi-18.scm:187: ##sys#remove-from-timeout-list */
((C_proc3)C_retrieve_proc(*((C_word*)lf[55]+1)))(3,*((C_word*)lf[55]+1),t4,((C_word*)t0)[4]);}}
else{
t4=C_eqp(t2,lf[56]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_826,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=C_slot(((C_word*)t0)[6],C_fix(7));
t7=C_a_i_list(&a,2,lf[57],t6);
t8=C_a_i_record(&a,3,lf[20],lf[58],t7);
/* srfi-18.scm:191: ##sys#signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t5,t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_845,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[3])){
/* srfi-18.scm:196: return */
t6=((C_word*)t0)[5];
((C_proc3)C_retrieve_proc(t6))(3,t6,t1,((C_word*)t0)[2]);}
else{
t6=C_a_i_record(&a,3,lf[20],lf[59],C_SCHEME_END_OF_LIST);
/* srfi-18.scm:199: ##sys#signal */
((C_proc3)C_retrieve_proc(*((C_word*)lf[18]+1)))(3,*((C_word*)lf[18]+1),t5,t6);}}}}

/* k843 in a786 in k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_845(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:196: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k824 in a786 in k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:190: return */
t2=((C_word*)t0)[3];
((C_proc3)C_retrieve_proc(t2))(3,t2,((C_word*)t0)[2],t1);}

/* k798 in a786 in k774 in a771 in k756 in thread-join! in k597 in k420 in k417 */
static void C_ccall f_800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(2));
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* thread-start! in k597 in k420 in k417 */
static void C_ccall f_715(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_715,3,t0,t1,t2);}
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_719,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_closurep(((C_word*)t3)[1]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_745,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:159: make-thread */
t6=*((C_word*)lf[29]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t3)[1]);}
else{
t5=t4;
f_719(t5,C_i_check_structure_2(((C_word*)t3)[1],lf[37],lf[47]));}}

/* k743 in thread-start! in k597 in k420 in k417 */
static void C_ccall f_745(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_719(t3,t2);}

/* k717 in thread-start! in k597 in k420 in k417 */
static void C_fcall f_719(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_719,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_722,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_slot(((C_word*)((C_word*)t0)[3])[1],C_fix(3));
t4=C_eqp(lf[35],t3);
if(C_truep(t4)){
t5=t2;
f_722(2,t5,C_SCHEME_UNDEFINED);}
else{
/* srfi-18.scm:162: ##sys#error */
t5=*((C_word*)lf[50]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t2,lf[47],lf[51],((C_word*)((C_word*)t0)[3])[1]);}}

/* k720 in k717 in thread-start! in k597 in k420 in k417 */
static void C_ccall f_722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_722,2,t0,t1);}
t2=C_i_setslot(((C_word*)((C_word*)t0)[3])[1],C_fix(3),lf[48]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_728,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:164: ##sys#add-to-ready-queue */
((C_proc3)C_retrieve_proc(*((C_word*)lf[49]+1)))(3,*((C_word*)lf[49]+1),t3,((C_word*)((C_word*)t0)[3])[1]);}

/* k726 in k720 in k717 in thread-start! in k597 in k420 in k417 */
static void C_ccall f_728(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* thread-name in k597 in k420 in k417 */
static void C_ccall f_706(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_706,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[46]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(6)));}

/* thread-quantum-set! in k597 in k420 in k417 */
static void C_ccall f_690(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_690,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[44]);
t5=C_i_check_exact_2(t3,lf[44]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_704,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:150: fxmax */
((C_proc4)C_retrieve_proc(*((C_word*)lf[45]+1)))(4,*((C_word*)lf[45]+1),t6,t3,C_fix(10));}

/* k702 in thread-quantum-set! in k597 in k420 in k417 */
static void C_ccall f_704(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_set_i_slot(((C_word*)t0)[2],C_fix(9),t1));}

/* thread-quantum in k597 in k420 in k417 */
static void C_ccall f_681(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_681,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[43]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(9)));}

/* thread-specific-set! in k597 in k420 in k417 */
static void C_ccall f_672(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(c!=4) C_bad_argc_2(c,4,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_672,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[37],lf[42]);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(10),t3));}

/* thread-specific in k597 in k420 in k417 */
static void C_ccall f_663(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_663,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[41]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(10)));}

/* thread-state in k597 in k420 in k417 */
static void C_ccall f_654(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_654,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[37],lf[40]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(3)));}

/* current-thread in k597 in k420 in k417 */
static void C_ccall f_651(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_651,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,*((C_word*)lf[33]+1));}

/* thread? in k597 in k420 in k417 */
static void C_ccall f_645(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_645,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[37]));}

/* make-thread in k597 in k420 in k417 */
static void C_ccall f_601(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(c<3) C_bad_min_argc_2(c,3,t0);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr3r,(void*)f_601r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_601r(t0,t1,t2,t3);}}

static void C_ccall f_601r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(7);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_605,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_630,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(t3))){
t6=C_slot(t3,C_fix(0));
t7=C_slot(*((C_word*)lf[33]+1),C_fix(9));
/* srfi-18.scm:112: ##sys#make-thread */
((C_proc6)C_retrieve_proc(*((C_word*)lf[34]+1)))(6,*((C_word*)lf[34]+1),t4,C_SCHEME_FALSE,lf[35],t6,t7);}
else{
/* srfi-18.scm:115: gensym */
((C_proc3)C_retrieve_proc(*((C_word*)lf[36]+1)))(3,*((C_word*)lf[36]+1),t5,lf[37]);}}

/* k628 in make-thread in k597 in k420 in k417 */
static void C_ccall f_630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(*((C_word*)lf[33]+1),C_fix(9));
/* srfi-18.scm:112: ##sys#make-thread */
((C_proc6)C_retrieve_proc(*((C_word*)lf[34]+1)))(6,*((C_word*)lf[34]+1),((C_word*)t0)[2],C_SCHEME_FALSE,lf[35],t1,t2);}

/* k603 in make-thread in k597 in k420 in k417 */
static void C_ccall f_605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_605,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_610,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word)li12),tmp=(C_word)a,a+=5,tmp);
t3=C_i_setslot(t1,C_fix(1),t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}

/* a609 in k603 in make-thread in k597 in k420 in k417 */
static void C_ccall f_610(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_610,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_616,a[2]=((C_word*)t0)[3],a[3]=((C_word)li11),tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:120: ##sys#call-with-values */
C_call_with_values(4,0,t1,((C_word*)t0)[2],t2);}

/* a615 in a609 in k603 in make-thread in k597 in k420 in k417 */
static void C_ccall f_616(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_616r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_616r(t0,t1,t2);}}

static void C_ccall f_616r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=C_i_setslot(((C_word*)t0)[2],C_fix(2),t2);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_623,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:124: ##sys#thread-kill! */
((C_proc4)C_retrieve_proc(*((C_word*)lf[31]+1)))(4,*((C_word*)lf[31]+1),t4,((C_word*)t0)[2],lf[32]);}

/* k621 in a615 in a609 in k603 in make-thread in k597 in k420 in k417 */
static void C_ccall f_623(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* srfi-18.scm:125: ##sys#schedule */
((C_proc2)C_retrieve_proc(*((C_word*)lf[30]+1)))(2,*((C_word*)lf[30]+1),((C_word*)t0)[2]);}

/* uncaught-exception? in k420 in k417 */
static void C_ccall f_581(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_581,3,t0,t1,t2);}
if(C_truep(C_i_structurep(t2,lf[20]))){
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(lf[27],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* terminated-thread-exception? in k420 in k417 */
static void C_ccall f_565(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_565,3,t0,t1,t2);}
if(C_truep(C_i_structurep(t2,lf[20]))){
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(lf[25],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* abandoned-mutex-exception? in k420 in k417 */
static void C_ccall f_549(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_549,3,t0,t1,t2);}
if(C_truep(C_i_structurep(t2,lf[20]))){
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(lf[23],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* join-timeout-exception? in k420 in k417 */
static void C_ccall f_533(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_533,3,t0,t1,t2);}
if(C_truep(C_i_structurep(t2,lf[20]))){
t3=C_slot(t2,C_fix(1));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(lf[21],t3));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* time? in k420 in k417 */
static void C_ccall f_525(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_525,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[1]));}

/* milliseconds->time in k420 in k417 */
static void C_ccall f_512(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_512,3,t0,t1,t2);}
t3=C_i_check_number_2(t2,lf[14]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_523,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:76: ##sys#exact->inexact */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t4,t2);}

/* k521 in milliseconds->time in k420 in k417 */
static void C_ccall f_523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_523,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,2,lf[1],t1));}

/* seconds->time in k420 in k417 */
static void C_ccall f_495(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_495,3,t0,t1,t2);}
t3=C_i_check_number_2(t2,lf[11]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_510,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:72: ##sys#exact->inexact */
((C_proc3)C_retrieve_proc(*((C_word*)lf[13]+1)))(3,*((C_word*)lf[13]+1),t4,t2);}

/* k508 in seconds->time in k420 in k417 */
static void C_ccall f_510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_510,2,t0,t1);}
t2=C_a_i_flonum_times(&a,2,t1,lf[12]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,2,lf[1],t2));}

/* time->milliseconds in k420 in k417 */
static void C_ccall f_486(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_486,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[1],lf[10]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_slot(t2,C_fix(1)));}

/* time->seconds in k420 in k417 */
static void C_ccall f_473(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_473,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[1],lf[8]);
t4=C_slot(t2,C_fix(1));
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_flonum_times(&a,2,t4,lf[9]));}

/* current-time in k420 in k417 */
static void C_ccall f_462(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_462,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_470,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* srfi-18.scm:58: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[2]+1)))(2,*((C_word*)lf[2]+1),t2);}

/* k468 in current-time in k420 in k417 */
static void C_ccall f_470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_470,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_record(&a,2,lf[1],t1));}

/* ##sys#compute-time-limit in k420 in k417 */
static void C_fcall f_424(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_424,NULL,3,t1,t2,t3);}
t4=t2;
if(C_truep(t4)){
if(C_truep(C_i_structurep(t2,lf[1]))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_slot(t2,C_fix(1)));}
else{
if(C_truep(C_i_numberp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_453,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* srfi-18.scm:51: current-milliseconds */
((C_proc2)C_retrieve_proc(*((C_word*)lf[2]+1)))(2,*((C_word*)lf[2]+1),t5);}
else{
/* srfi-18.scm:52: ##sys#signal-hook */
((C_proc6)C_retrieve_proc(*((C_word*)lf[3]+1)))(6,*((C_word*)lf[3]+1),t1,lf[4],t3,lf[5],t2);}}}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k451 in ##sys#compute-time-limit in k420 in k417 */
static void C_ccall f_453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_453,2,t0,t1);}
t2=C_a_i_times(&a,2,((C_word*)t0)[3],C_fix(1000));
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_plus(&a,2,t1,t2));}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[127] = {
{"toplevel:srfi_18_scm",(void*)C_srfi_18_toplevel},
{"f_419:srfi_18_scm",(void*)f_419},
{"f_422:srfi_18_scm",(void*)f_422},
{"f_599:srfi_18_scm",(void*)f_599},
{"f_1864:srfi_18_scm",(void*)f_1864},
{"f_1838:srfi_18_scm",(void*)f_1838},
{"f_1848:srfi_18_scm",(void*)f_1848},
{"f_1851:srfi_18_scm",(void*)f_1851},
{"f_1854:srfi_18_scm",(void*)f_1854},
{"f_1799:srfi_18_scm",(void*)f_1799},
{"f_1801:srfi_18_scm",(void*)f_1801},
{"f_1805:srfi_18_scm",(void*)f_1805},
{"f_1811:srfi_18_scm",(void*)f_1811},
{"f_1708:srfi_18_scm",(void*)f_1708},
{"f_1792:srfi_18_scm",(void*)f_1792},
{"f_1775:srfi_18_scm",(void*)f_1775},
{"f_1758:srfi_18_scm",(void*)f_1758},
{"f_1730:srfi_18_scm",(void*)f_1730},
{"f_1741:srfi_18_scm",(void*)f_1741},
{"f_1745:srfi_18_scm",(void*)f_1745},
{"f_1649:srfi_18_scm",(void*)f_1649},
{"f_1665:srfi_18_scm",(void*)f_1665},
{"f_1695:srfi_18_scm",(void*)f_1695},
{"f_1656:srfi_18_scm",(void*)f_1656},
{"f_1606:srfi_18_scm",(void*)f_1606},
{"f_1597:srfi_18_scm",(void*)f_1597},
{"f_1588:srfi_18_scm",(void*)f_1588},
{"f_1579:srfi_18_scm",(void*)f_1579},
{"f_1573:srfi_18_scm",(void*)f_1573},
{"f_1554:srfi_18_scm",(void*)f_1554},
{"f_1562:srfi_18_scm",(void*)f_1562},
{"f_1332:srfi_18_scm",(void*)f_1332},
{"f_1350:srfi_18_scm",(void*)f_1350},
{"f_1357:srfi_18_scm",(void*)f_1357},
{"f_1526:srfi_18_scm",(void*)f_1526},
{"f_1369:srfi_18_scm",(void*)f_1369},
{"f_1511:srfi_18_scm",(void*)f_1511},
{"f_1503:srfi_18_scm",(void*)f_1503},
{"f_1465:srfi_18_scm",(void*)f_1465},
{"f_1491:srfi_18_scm",(void*)f_1491},
{"f_1484:srfi_18_scm",(void*)f_1484},
{"f_1372:srfi_18_scm",(void*)f_1372},
{"f_1375:srfi_18_scm",(void*)f_1375},
{"f_1093:srfi_18_scm",(void*)f_1093},
{"f_1103:srfi_18_scm",(void*)f_1103},
{"f_1117:srfi_18_scm",(void*)f_1117},
{"f1953:srfi_18_scm",(void*)f1953},
{"f1949:srfi_18_scm",(void*)f1949},
{"f1945:srfi_18_scm",(void*)f1945},
{"f_1302:srfi_18_scm",(void*)f_1302},
{"f_1306:srfi_18_scm",(void*)f_1306},
{"f_1233:srfi_18_scm",(void*)f_1233},
{"f_1239:srfi_18_scm",(void*)f_1239},
{"f_1244:srfi_18_scm",(void*)f_1244},
{"f_1284:srfi_18_scm",(void*)f_1284},
{"f_1251:srfi_18_scm",(void*)f_1251},
{"f_1254:srfi_18_scm",(void*)f_1254},
{"f_1141:srfi_18_scm",(void*)f_1141},
{"f_1155:srfi_18_scm",(void*)f_1155},
{"f_1120:srfi_18_scm",(void*)f_1120},
{"f_1131:srfi_18_scm",(void*)f_1131},
{"f_1069:srfi_18_scm",(void*)f_1069},
{"f_1060:srfi_18_scm",(void*)f_1060},
{"f_1051:srfi_18_scm",(void*)f_1051},
{"f_1042:srfi_18_scm",(void*)f_1042},
{"f_1024:srfi_18_scm",(void*)f_1024},
{"f_1028:srfi_18_scm",(void*)f_1028},
{"f_1018:srfi_18_scm",(void*)f_1018},
{"f_978:srfi_18_scm",(void*)f_978},
{"f_1006:srfi_18_scm",(void*)f_1006},
{"f_1013:srfi_18_scm",(void*)f_1013},
{"f_987:srfi_18_scm",(void*)f_987},
{"f_994:srfi_18_scm",(void*)f_994},
{"f_999:srfi_18_scm",(void*)f_999},
{"f_956:srfi_18_scm",(void*)f_956},
{"f_923:srfi_18_scm",(void*)f_923},
{"f_941:srfi_18_scm",(void*)f_941},
{"f_950:srfi_18_scm",(void*)f_950},
{"f_879:srfi_18_scm",(void*)f_879},
{"f_918:srfi_18_scm",(void*)f_918},
{"f_886:srfi_18_scm",(void*)f_886},
{"f_895:srfi_18_scm",(void*)f_895},
{"f_751:srfi_18_scm",(void*)f_751},
{"f_758:srfi_18_scm",(void*)f_758},
{"f_772:srfi_18_scm",(void*)f_772},
{"f_776:srfi_18_scm",(void*)f_776},
{"f_782:srfi_18_scm",(void*)f_782},
{"f_787:srfi_18_scm",(void*)f_787},
{"f_845:srfi_18_scm",(void*)f_845},
{"f_826:srfi_18_scm",(void*)f_826},
{"f_800:srfi_18_scm",(void*)f_800},
{"f_715:srfi_18_scm",(void*)f_715},
{"f_745:srfi_18_scm",(void*)f_745},
{"f_719:srfi_18_scm",(void*)f_719},
{"f_722:srfi_18_scm",(void*)f_722},
{"f_728:srfi_18_scm",(void*)f_728},
{"f_706:srfi_18_scm",(void*)f_706},
{"f_690:srfi_18_scm",(void*)f_690},
{"f_704:srfi_18_scm",(void*)f_704},
{"f_681:srfi_18_scm",(void*)f_681},
{"f_672:srfi_18_scm",(void*)f_672},
{"f_663:srfi_18_scm",(void*)f_663},
{"f_654:srfi_18_scm",(void*)f_654},
{"f_651:srfi_18_scm",(void*)f_651},
{"f_645:srfi_18_scm",(void*)f_645},
{"f_601:srfi_18_scm",(void*)f_601},
{"f_630:srfi_18_scm",(void*)f_630},
{"f_605:srfi_18_scm",(void*)f_605},
{"f_610:srfi_18_scm",(void*)f_610},
{"f_616:srfi_18_scm",(void*)f_616},
{"f_623:srfi_18_scm",(void*)f_623},
{"f_581:srfi_18_scm",(void*)f_581},
{"f_565:srfi_18_scm",(void*)f_565},
{"f_549:srfi_18_scm",(void*)f_549},
{"f_533:srfi_18_scm",(void*)f_533},
{"f_525:srfi_18_scm",(void*)f_525},
{"f_512:srfi_18_scm",(void*)f_512},
{"f_523:srfi_18_scm",(void*)f_523},
{"f_495:srfi_18_scm",(void*)f_495},
{"f_510:srfi_18_scm",(void*)f_510},
{"f_486:srfi_18_scm",(void*)f_486},
{"f_473:srfi_18_scm",(void*)f_473},
{"f_462:srfi_18_scm",(void*)f_462},
{"f_470:srfi_18_scm",(void*)f_470},
{"f_424:srfi_18_scm",(void*)f_424},
{"f_453:srfi_18_scm",(void*)f_453},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
