/* Generated from scrutinizer.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: scrutinizer.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file scrutinizer.c
   unit: scrutinizer
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[190];
static double C_possibly_force_alignment;


C_noret_decl(C_scrutinizer_toplevel)
C_externexport void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1246)
static void C_ccall f_1246(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1249)
static void C_ccall f_1249(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_5430)
static void C_ccall f_5430r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_5434)
static void C_ccall f_5434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5547)
static void C_ccall f_5547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5437)
static void C_ccall f_5437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5534)
static void C_ccall f_5534(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5537)
static void C_ccall f_5537(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5540)
static void C_ccall f_5540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5443)
static void C_ccall f_5443(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5450)
static void C_ccall f_5450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5452)
static void C_fcall f_5452(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5467)
static void C_ccall f_5467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5479)
static void C_fcall f_5479(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5486)
static void C_ccall f_5486(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5489)
static void C_ccall f_5489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5492)
static void C_ccall f_5492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5495)
static void C_ccall f_5495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5498)
static void C_ccall f_5498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5501)
static void C_ccall f_5501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5504)
static void C_ccall f_5504(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5507)
static void C_ccall f_5507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5510)
static void C_ccall f_5510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5473)
static void C_ccall f_5473(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5520)
static void C_ccall f_5520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1269)
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4622)
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_5374)
static void C_fcall f_5374(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5389)
static void C_ccall f_5389(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5382)
static void C_fcall f_5382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5372)
static void C_ccall f_5372(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5240)
static void C_ccall f_5240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5254)
static void C_ccall f_5254(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5256)
static void C_fcall f_5256(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5339)
static void C_ccall f_5339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5269)
static void C_fcall f_5269(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5287)
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5295)
static void C_ccall f_5295(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5298)
static void C_ccall f_5298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5327)
static void C_ccall f_5327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5330)
static void C_ccall f_5330(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5333)
static void C_ccall f_5333(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5321)
static void C_ccall f_5321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5304)
static void C_ccall f_5304(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5307)
static void C_ccall f_5307(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5310)
static void C_ccall f_5310(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5313)
static void C_ccall f_5313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5317)
static void C_ccall f_5317(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5243)
static void C_ccall f_5243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5116)
static void C_ccall f_5116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5202)
static void C_ccall f_5202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5205)
static void C_ccall f_5205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5208)
static void C_ccall f_5208(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5211)
static void C_ccall f_5211(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5214)
static void C_ccall f_5214(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_ccall f_5218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5119)
static void C_ccall f_5119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5194)
static void C_ccall f_5194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5144)
static void C_fcall f_5144(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5154)
static void C_ccall f_5154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5157)
static void C_ccall f_5157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5160)
static void C_ccall f_5160(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5166)
static void C_ccall f_5166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5169)
static void C_ccall f_5169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5175)
static void C_ccall f_5175(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5125)
static void C_ccall f_5125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5000)
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5094)
static void C_ccall f_5094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5007)
static void C_ccall f_5007(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5047)
static void C_ccall f_5047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5049)
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5043)
static void C_ccall f_5043(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5010)
static void C_ccall f_5010(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5032)
static void C_ccall f_5032(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5013)
static void C_ccall f_5013(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5020)
static void C_ccall f_5020(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4906)
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4953)
static void C_ccall f_4953(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4978)
static void C_ccall f_4978(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4956)
static void C_ccall f_4956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4959)
static void C_ccall f_4959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4962)
static void C_ccall f_4962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4966)
static void C_ccall f_4966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4927)
static void C_ccall f_4927(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4942)
static void C_ccall f_4942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4924)
static void C_ccall f_4924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4891)
static void C_ccall f_4891(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4717)
static void C_ccall f_4717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4723)
static void C_ccall f_4723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4726)
static void C_ccall f_4726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4732)
static void C_fcall f_4732(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4865)
static void C_ccall f_4865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4861)
static void C_ccall f_4861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4807)
static void C_fcall f_4807(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4814)
static void C_ccall f_4814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4817)
static void C_ccall f_4817(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4820)
static void C_ccall f_4820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4823)
static void C_ccall f_4823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4833)
static void C_ccall f_4833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4826)
static void C_ccall f_4826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4829)
static void C_ccall f_4829(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4735)
static void C_ccall f_4735(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4740)
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4790)
static void C_ccall f_4790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4753)
static void C_fcall f_4753(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4771)
static void C_fcall f_4771(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4653)
static void C_ccall f_4653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4590)
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4319)
static void C_fcall f_4319(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4329)
static void C_fcall f_4329(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4352)
static void C_fcall f_4352(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4354)
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4426)
static void C_ccall f_4426(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4384)
static void C_fcall f_4384(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4345)
static void C_ccall f_4345(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4277)
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3938)
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4267)
static void C_ccall f_4267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4259)
static void C_ccall f_4259(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4255)
static void C_ccall f_4255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4213)
static void C_fcall f_4213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4220)
static void C_ccall f_4220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4245)
static void C_ccall f_4245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4229)
static void C_ccall f_4229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4232)
static void C_ccall f_4232(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4235)
static void C_ccall f_4235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4238)
static void C_ccall f_4238(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4241)
static void C_ccall f_4241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4018)
static void C_ccall f_4018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4037)
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4164)
static void C_ccall f_4164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4206)
static void C_ccall f_4206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4167)
static void C_ccall f_4167(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4170)
static void C_ccall f_4170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4173)
static void C_ccall f_4173(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4179)
static void C_ccall f_4179(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4182)
static void C_ccall f_4182(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4185)
static void C_ccall f_4185(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4188)
static void C_ccall f_4188(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4191)
static void C_ccall f_4191(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4044)
static void C_ccall f_4044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4063)
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4094)
static void C_ccall f_4094(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4101)
static void C_ccall f_4101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4140)
static void C_ccall f_4140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4104)
static void C_ccall f_4104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4107)
static void C_ccall f_4107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4110)
static void C_ccall f_4110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4113)
static void C_ccall f_4113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4116)
static void C_ccall f_4116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4119)
static void C_ccall f_4119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4122)
static void C_ccall f_4122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4125)
static void C_ccall f_4125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4128)
static void C_ccall f_4128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4047)
static void C_ccall f_4047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4514)
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4522)
static void C_fcall f_4522(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4524)
static void C_fcall f_4524(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4551)
static void C_ccall f_4551(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4050)
static void C_ccall f_4050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4023)
static void C_ccall f_4023(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3941)
static void C_fcall f_3941(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3971)
static void C_fcall f_3971(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3974)
static void C_ccall f_3974(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3980)
static void C_ccall f_3980(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3983)
static void C_ccall f_3983(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3986)
static void C_ccall f_3986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3968)
static void C_ccall f_3968(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3948)
static void C_ccall f_3948(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3951)
static void C_ccall f_3951(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3964)
static void C_ccall f_3964(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3954)
static void C_ccall f_3954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3918)
static void C_fcall f_3918(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3928)
static void C_ccall f_3928(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3936)
static void C_ccall f_3936(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3926)
static void C_ccall f_3926(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3864)
static void C_fcall f_3864(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_fcall f_3873(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3912)
static void C_ccall f_3912(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3908)
static void C_ccall f_3908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3743)
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3809)
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3822)
static void C_ccall f_3822(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3825)
static void C_ccall f_3825(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3849)
static void C_ccall f_3849(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3828)
static void C_ccall f_3828(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3831)
static void C_ccall f_3831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3841)
static void C_ccall f_3841(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3834)
static void C_ccall f_3834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3784)
static void C_ccall f_3784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3787)
static void C_ccall f_3787(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3800)
static void C_ccall f_3800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3790)
static void C_ccall f_3790(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3793)
static void C_ccall f_3793(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3746)
static void C_fcall f_3746(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3753)
static void C_ccall f_3753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3756)
static void C_ccall f_3756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3769)
static void C_ccall f_3769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3759)
static void C_ccall f_3759(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3762)
static void C_ccall f_3762(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_fcall f_3729(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3741)
static void C_ccall f_3741(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3737)
static void C_ccall f_3737(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3648)
static void C_fcall f_3648(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3702)
static void C_ccall f_3702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3708)
static void C_ccall f_3708(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3711)
static void C_ccall f_3711(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3714)
static void C_ccall f_3714(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3717)
static void C_ccall f_3717(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3720)
static void C_ccall f_3720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3723)
static void C_ccall f_3723(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3683)
static void C_ccall f_3683(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3686)
static void C_ccall f_3686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3689)
static void C_ccall f_3689(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3692)
static void C_ccall f_3692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3676)
static void C_ccall f_3676(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3308)
static void C_fcall f_3308(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3415)
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3550)
static void C_ccall f_3550(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_fcall f_3436(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3464)
static void C_ccall f_3464(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3384)
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3253)
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3043)
static void C_fcall f_3043(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3108)
static void C_fcall f_3108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_3216)
static void C_ccall f_3216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3049)
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3067)
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3093)
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3074)
static void C_ccall f_3074(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3055)
static void C_ccall f_3055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3061)
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2771)
static void C_fcall f_2771(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2858)
static void C_fcall f_2858(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2877)
static void C_fcall f_2877(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2914)
static void C_fcall f_2914(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2941)
static void C_ccall f_2941(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2882)
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2863)
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2762)
static void C_fcall f_2762(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2766)
static void C_ccall f_2766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2696)
static void C_fcall f_2696(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2725)
static void C_ccall f_2725(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2729)
static void C_ccall f_2729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2494)
static void C_fcall f_2494(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2654)
static void C_ccall f_2654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2658)
static void C_ccall f_2658(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2590)
static void C_fcall f_2590(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2601)
static void C_ccall f_2601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2609)
static void C_ccall f_2609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2605)
static void C_ccall f_2605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_fcall f_2529(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2540)
static void C_ccall f_2540(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2472)
static C_word C_fcall f_2472(C_word t0);
C_noret_decl(f_2432)
static C_word C_fcall f_2432(C_word t0);
C_noret_decl(f_1964)
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2376)
static void C_fcall f_2376(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2405)
static void C_ccall f_2405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2370)
static void C_ccall f_2370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2333)
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2362)
static void C_ccall f_2362(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_ccall f_2325(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2005)
static void C_ccall f_2005(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2251)
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2255)
static void C_ccall f_2255(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2261)
static void C_fcall f_2261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2119)
static void C_ccall f_2119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2161)
static void C_fcall f_2161(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2233)
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2223)
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2199)
static void C_ccall f_2199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2151)
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2149)
static void C_ccall f_2149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2142)
static void C_ccall f_2142(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2108)
static void C_ccall f_2108(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2011)
static void C_ccall f_2011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2016)
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2042)
static void C_fcall f_2042(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2054)
static void C_ccall f_2054(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2050)
static void C_ccall f_2050(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1955)
static void C_fcall f_1955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1959)
static void C_ccall f_1959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1868)
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1890)
static void C_ccall f_1890(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_ccall f_1893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1896)
static void C_ccall f_1896(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1899)
static void C_ccall f_1899(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1902)
static void C_ccall f_1902(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1905)
static void C_ccall f_1905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1908)
static void C_ccall f_1908(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1920)
static void C_fcall f_1920(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1949)
static void C_ccall f_1949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1918)
static void C_ccall f_1918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1911)
static void C_ccall f_1911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1787)
static void C_fcall f_1787(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1803)
static void C_ccall f_1803(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1806)
static void C_ccall f_1806(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1809)
static void C_ccall f_1809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1812)
static void C_ccall f_1812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1815)
static void C_ccall f_1815(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1818)
static void C_ccall f_1818(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1833)
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1862)
static void C_ccall f_1862(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1831)
static void C_ccall f_1831(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1824)
static void C_ccall f_1824(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1607)
static void C_fcall f_1607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1766)
static void C_ccall f_1766(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1769)
static void C_ccall f_1769(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1772)
static void C_ccall f_1772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1724)
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1753)
static void C_ccall f_1753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1718)
static void C_ccall f_1718(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1653)
static void C_fcall f_1653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1663)
static void C_ccall f_1663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1666)
static void C_ccall f_1666(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1690)
static void C_ccall f_1690(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1669)
static void C_ccall f_1669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1672)
static void C_ccall f_1672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1682)
static void C_ccall f_1682(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1675)
static void C_ccall f_1675(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1566)
static void C_fcall f_1566(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1570)
static void C_ccall f_1570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1580)
static void C_ccall f_1580(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1583)
static void C_ccall f_1583(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1586)
static void C_ccall f_1586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1589)
static void C_ccall f_1589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1592)
static void C_ccall f_1592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1605)
static void C_ccall f_1605(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1598)
static void C_ccall f_1598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1601)
static void C_ccall f_1601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1573)
static void C_ccall f_1573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1534)
static void C_ccall f_1534(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1541)
static void C_fcall f_1541(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1461)
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_1525)
static void C_ccall f_1525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1532)
static void C_ccall f_1532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1468)
static void C_fcall f_1468(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1475)
static void C_fcall f_1475(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1489)
static void C_ccall f_1489(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1492)
static void C_ccall f_1492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1505)
static void C_ccall f_1505(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1495)
static void C_ccall f_1495(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1498)
static void C_ccall f_1498(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1501)
static void C_ccall f_1501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1485)
static void C_ccall f_1485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1374)
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1378)
static void C_ccall f_1378(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1382)
static void C_fcall f_1382(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1414)
static void C_fcall f_1414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1421)
static void C_ccall f_1421(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1424)
static void C_ccall f_1424(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1427)
static void C_ccall f_1427(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1430)
static void C_ccall f_1430(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1433)
static void C_ccall f_1433(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1436)
static void C_ccall f_1436(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1439)
static void C_ccall f_1439(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1417)
static void C_ccall f_1417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1399)
static void C_ccall f_1399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1402)
static void C_ccall f_1402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1405)
static void C_ccall f_1405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1408)
static void C_ccall f_1408(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1392)
static void C_ccall f_1392(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_1251)
static void C_ccall f_1251r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_1261)
static void C_ccall f_1261(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1264)
static void C_ccall f_1264(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_5452)
static void C_fcall trf_5452(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5452(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5452(t0,t1,t2);}

C_noret_decl(trf_5479)
static void C_fcall trf_5479(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5479(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5479(t0,t1);}

C_noret_decl(trf_4622)
static void C_fcall trf_4622(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4622(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_4622(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_5374)
static void C_fcall trf_5374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5374(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5374(t0,t1,t2);}

C_noret_decl(trf_5382)
static void C_fcall trf_5382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5382(t0,t1,t2);}

C_noret_decl(trf_5256)
static void C_fcall trf_5256(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5256(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5256(t0,t1,t2,t3);}

C_noret_decl(trf_5269)
static void C_fcall trf_5269(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5269(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5269(t0,t1);}

C_noret_decl(trf_5287)
static void C_fcall trf_5287(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5287(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_5287(t0,t1,t2,t3);}

C_noret_decl(trf_5144)
static void C_fcall trf_5144(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5144(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5144(t0,t1);}

C_noret_decl(trf_5049)
static void C_fcall trf_5049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5049(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5049(t0,t1,t2);}

C_noret_decl(trf_4906)
static void C_fcall trf_4906(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4906(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4906(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4732)
static void C_fcall trf_4732(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4732(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4732(t0,t1);}

C_noret_decl(trf_4807)
static void C_fcall trf_4807(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4807(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4807(t0,t1);}

C_noret_decl(trf_4740)
static void C_fcall trf_4740(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4740(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4740(t0,t1,t2,t3);}

C_noret_decl(trf_4753)
static void C_fcall trf_4753(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4753(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4753(t0,t1);}

C_noret_decl(trf_4771)
static void C_fcall trf_4771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4771(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4771(t0,t1,t2,t3);}

C_noret_decl(trf_4319)
static void C_fcall trf_4319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4319(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4319(t0,t1,t2,t3);}

C_noret_decl(trf_4329)
static void C_fcall trf_4329(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4329(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4329(t0,t1);}

C_noret_decl(trf_4352)
static void C_fcall trf_4352(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4352(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4352(t0,t1);}

C_noret_decl(trf_4354)
static void C_fcall trf_4354(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4354(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4354(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4384)
static void C_fcall trf_4384(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4384(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4384(t0,t1);}

C_noret_decl(trf_3938)
static void C_fcall trf_3938(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3938(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3938(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_4213)
static void C_fcall trf_4213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4213(t0,t1);}

C_noret_decl(trf_4063)
static void C_fcall trf_4063(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4063(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_4063(t0,t1,t2,t3,t4);}

C_noret_decl(trf_4522)
static void C_fcall trf_4522(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4522(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4522(t0,t1);}

C_noret_decl(trf_4524)
static void C_fcall trf_4524(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4524(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4524(t0,t1,t2);}

C_noret_decl(trf_3941)
static void C_fcall trf_3941(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3941(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3941(t0,t1);}

C_noret_decl(trf_3971)
static void C_fcall trf_3971(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3971(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3971(t0,t1);}

C_noret_decl(trf_3918)
static void C_fcall trf_3918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3918(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3918(t0,t1,t2);}

C_noret_decl(trf_3864)
static void C_fcall trf_3864(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3864(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3864(t0,t1);}

C_noret_decl(trf_3873)
static void C_fcall trf_3873(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3873(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3873(t0,t1,t2,t3);}

C_noret_decl(trf_3743)
static void C_fcall trf_3743(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3743(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3743(t0,t1,t2);}

C_noret_decl(trf_3809)
static void C_fcall trf_3809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3809(t0,t1,t2);}

C_noret_decl(trf_3746)
static void C_fcall trf_3746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3746(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3746(t0,t1);}

C_noret_decl(trf_3729)
static void C_fcall trf_3729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3729(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3729(t0,t1,t2,t3);}

C_noret_decl(trf_3648)
static void C_fcall trf_3648(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3648(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_3648(t0,t1,t2,t3,t4);}

C_noret_decl(trf_3308)
static void C_fcall trf_3308(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3308(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3308(t0,t1,t2,t3);}

C_noret_decl(trf_3415)
static void C_fcall trf_3415(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3415(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3415(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3436)
static void C_fcall trf_3436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3436(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3436(t0,t1,t2,t3);}

C_noret_decl(trf_3253)
static void C_fcall trf_3253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3253(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3253(t0,t1,t2,t3);}

C_noret_decl(trf_3043)
static void C_fcall trf_3043(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3043(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3043(t0,t1,t2,t3);}

C_noret_decl(trf_3108)
static void C_fcall trf_3108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3108(void *dummy){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
f_3108(t0,t1,t2,t3,t4,t5);}

C_noret_decl(trf_3049)
static void C_fcall trf_3049(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3049(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3049(t0,t1,t2,t3);}

C_noret_decl(trf_2771)
static void C_fcall trf_2771(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2771(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2771(t0,t1,t2,t3);}

C_noret_decl(trf_2858)
static void C_fcall trf_2858(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2858(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2858(t0,t1);}

C_noret_decl(trf_2877)
static void C_fcall trf_2877(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2877(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2877(t0,t1);}

C_noret_decl(trf_2914)
static void C_fcall trf_2914(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2914(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2914(t0,t1);}

C_noret_decl(trf_2762)
static void C_fcall trf_2762(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2762(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2762(t0,t1,t2,t3);}

C_noret_decl(trf_2696)
static void C_fcall trf_2696(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2696(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2696(t0,t1,t2,t3);}

C_noret_decl(trf_2494)
static void C_fcall trf_2494(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2494(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2494(t0,t1,t2,t3);}

C_noret_decl(trf_2590)
static void C_fcall trf_2590(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2590(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2590(t0,t1);}

C_noret_decl(trf_2529)
static void C_fcall trf_2529(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2529(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2529(t0,t1);}

C_noret_decl(trf_1964)
static void C_fcall trf_1964(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1964(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1964(t0,t1,t2);}

C_noret_decl(trf_2376)
static void C_fcall trf_2376(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2376(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2376(t0,t1,t2);}

C_noret_decl(trf_2333)
static void C_fcall trf_2333(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2333(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2333(t0,t1,t2);}

C_noret_decl(trf_2261)
static void C_fcall trf_2261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2261(t0,t1);}

C_noret_decl(trf_2161)
static void C_fcall trf_2161(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2161(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_2161(t0,t1,t2,t3);}

C_noret_decl(trf_2042)
static void C_fcall trf_2042(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2042(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2042(t0,t1);}

C_noret_decl(trf_1955)
static void C_fcall trf_1955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1955(t0,t1,t2);}

C_noret_decl(trf_1868)
static void C_fcall trf_1868(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1868(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1868(t0,t1,t2);}

C_noret_decl(trf_1920)
static void C_fcall trf_1920(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1920(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1920(t0,t1,t2);}

C_noret_decl(trf_1787)
static void C_fcall trf_1787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1787(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1787(t0,t1,t2);}

C_noret_decl(trf_1833)
static void C_fcall trf_1833(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1833(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1833(t0,t1,t2);}

C_noret_decl(trf_1607)
static void C_fcall trf_1607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1607(t0,t1,t2);}

C_noret_decl(trf_1724)
static void C_fcall trf_1724(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1724(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1724(t0,t1,t2);}

C_noret_decl(trf_1653)
static void C_fcall trf_1653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1653(t0,t1);}

C_noret_decl(trf_1566)
static void C_fcall trf_1566(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1566(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1566(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1541)
static void C_fcall trf_1541(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1541(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1541(t0,t1);}

C_noret_decl(trf_1461)
static void C_fcall trf_1461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1461(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1461(t0,t1,t2,t3,t4);}

C_noret_decl(trf_1468)
static void C_fcall trf_1468(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1468(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1468(t0,t1);}

C_noret_decl(trf_1475)
static void C_fcall trf_1475(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1475(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1475(t0,t1,t2);}

C_noret_decl(trf_1374)
static void C_fcall trf_1374(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1374(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_1374(t0,t1,t2,t3);}

C_noret_decl(trf_1382)
static void C_fcall trf_1382(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1382(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1382(t0,t1,t2);}

C_noret_decl(trf_1414)
static void C_fcall trf_1414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1414(t0,t1);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_scrutinizer_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_scrutinizer_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("scrutinizer_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1441)){
C_save(t1);
C_rereclaim2(1441*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,190);
lf[0]=C_h_intern(&lf[0],1,"d");
lf[1]=C_h_intern(&lf[1],19,"\003sysstandard-output");
lf[2]=C_h_intern(&lf[2],19,"\003syswrite-char/port");
lf[3]=C_h_intern(&lf[3],7,"fprintf");
lf[4]=C_h_intern(&lf[4],7,"display");
lf[5]=C_decode_literal(C_heaptop,"\376B\000\000\010[debug] ");
lf[6]=C_h_intern(&lf[6],19,"\010compilerscrutinize");
lf[7]=C_h_intern(&lf[7],10,"deprecated");
lf[8]=C_h_intern(&lf[8],1,"*");
lf[9]=C_h_intern(&lf[9],17,"get-output-string");
lf[10]=C_decode_literal(C_heaptop,"\376B\000\000%use of deprecated library procedure `");
lf[11]=C_h_intern(&lf[11],18,"open-output-string");
lf[12]=C_decode_literal(C_heaptop,"\376B\000\000\011\047 instead");
lf[13]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 - consider using `");
lf[14]=C_decode_literal(C_heaptop,"\376B\000\000%use of deprecated library procedure `");
lf[15]=C_h_intern(&lf[15],7,"\003sysget");
lf[16]=C_h_intern(&lf[16],9,"\004coretype");
lf[17]=C_h_intern(&lf[17],9,"undefined");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\036\047 which has an undefined value");
lf[19]=C_h_intern(&lf[19],18,"\010compilerreal-name");
lf[20]=C_decode_literal(C_heaptop,"\376B\000\000\024access to variable `");
lf[21]=C_h_intern(&lf[21],18,"\004coredeclared-type");
lf[22]=C_h_intern(&lf[22],12,"\010compilerget");
lf[23]=C_h_intern(&lf[23],8,"assigned");
lf[24]=C_h_intern(&lf[24],5,"every");
lf[25]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\007boolean\376\003\000\000\002\376\001\000\000\011undefined\376\003\000\000\002\376\001\000\000\010noreturn\376\377\016");
lf[26]=C_h_intern(&lf[26],2,"or");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\027\047 which is always true:");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000Nexpected value of type boolean in conditional but were given a value of\012typ"
"e `");
lf[29]=C_decode_literal(C_heaptop,"\376B\000\000\010anything");
lf[30]=C_h_intern(&lf[30],4,"char");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\011character");
lf[32]=C_h_intern(&lf[32],14,"symbol->string");
lf[33]=C_h_intern(&lf[33],9,"procedure");
lf[34]=C_h_intern(&lf[34],8,"->string");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\013 returning ");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000\021a procedure with ");
lf[37]=C_h_intern(&lf[37],18,"string-intersperse");
lf[38]=C_decode_literal(C_heaptop,"\376B\000\000\004 OR ");
lf[39]=C_h_intern(&lf[39],6,"struct");
lf[40]=C_decode_literal(C_heaptop,"\376B\000\000\024a structure of type ");
lf[41]=C_h_intern(&lf[41],13,"\010compilerbomb");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[43]=C_decode_literal(C_heaptop,"\376B\000\000\020invalid type: ~a");
lf[44]=C_h_intern(&lf[44],3,"len");
lf[45]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[46]=C_decode_literal(C_heaptop,"\376B\000\000\001s");
lf[47]=C_decode_literal(C_heaptop,"\376B\000\000\016zero arguments");
lf[48]=C_decode_literal(C_heaptop,"\376B\000\000\010 of type");
lf[49]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[50]=C_decode_literal(C_heaptop,"\376B\000\000\033an unknown number of values");
lf[51]=C_decode_literal(C_heaptop,"\376B\000\000\013zero values");
lf[52]=C_decode_literal(C_heaptop,"\376B\000\000\010 of type");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\006 value");
lf[54]=C_h_intern(&lf[54],19,"\003sysundefined-value");
lf[55]=C_h_intern(&lf[55],6,"append");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[57]=C_h_intern(&lf[57],6,"reduce");
lf[58]=C_h_intern(&lf[58],3,"eq\077");
lf[59]=C_h_intern(&lf[59],3,"any");
lf[60]=C_h_intern(&lf[60],10,"\003sysappend");
lf[61]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[62]=C_h_intern(&lf[62],7,"reverse");
lf[63]=C_h_intern(&lf[63],10,"append-map");
lf[64]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[65]=C_h_intern(&lf[65],7,"call/cc");
lf[66]=C_h_intern(&lf[66],6,"values");
lf[67]=C_h_intern(&lf[67],6,"#!rest");
lf[68]=C_h_intern(&lf[68],10,"#!optional");
lf[69]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[70]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[71]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[72]=C_h_intern(&lf[72],8,"noreturn");
lf[73]=C_h_intern(&lf[73],6,"number");
lf[74]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[75]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006number\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[76]=C_h_intern(&lf[76],4,"pair");
lf[77]=C_h_intern(&lf[77],4,"list");
lf[78]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004pair\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[79]=C_h_intern(&lf[79],4,"null");
lf[80]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004list\376\377\016");
lf[81]=C_h_intern(&lf[81],5,"break");
lf[82]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\003\000\000\002\376\001\000\000\012#!optional\376\377\016");
lf[83]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[84]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\004null\376\003\000\000\002\376\001\000\000\004pair\376\377\016");
lf[85]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006fixnum\376\003\000\000\002\376\001\000\000\005float\376\377\016");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000- a single result, but were given zero results");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[88]=C_decode_literal(C_heaptop,"\376B\000\000\007 result");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000! a single result, but were given ");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[91]=C_h_intern(&lf[91],7,"warning");
lf[92]=C_h_intern(&lf[92],4,"conc");
lf[93]=C_decode_literal(C_heaptop,"\376B\000\000\013procedure `");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\021unknown procedure");
lf[95]=C_decode_literal(C_heaptop,"\376B\000\000\017at toplevel:\012  ");
lf[96]=C_decode_literal(C_heaptop,"\376B\000\000\004:\012  ");
lf[97]=C_decode_literal(C_heaptop,"\376B\000\000\014in toplevel ");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\004,\012  ");
lf[99]=C_decode_literal(C_heaptop,"\376B\000\000\011in local ");
lf[100]=C_h_intern(&lf[100],4,"cons");
lf[101]=C_h_intern(&lf[101],3,"...");
lf[102]=C_h_intern(&lf[102],7,"\003sysmap");
lf[103]=C_h_intern(&lf[103],4,"take");
lf[104]=C_h_intern(&lf[104],3,"min");
lf[105]=C_h_intern(&lf[105],30,"\010compilerbuild-expression-tree");
lf[106]=C_h_intern(&lf[106],12,"string-chomp");
lf[107]=C_h_intern(&lf[107],2,"pp");
lf[108]=C_h_intern(&lf[108],21,"with-output-to-string");
lf[109]=C_decode_literal(C_heaptop,"\376B\000\000\003\047, ");
lf[110]=C_h_intern(&lf[110],5,"write");
lf[111]=C_decode_literal(C_heaptop,"\376B\000\000\026in procedure call to `");
lf[112]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[114]=C_h_intern(&lf[114],26,"\010compilersource-info->line");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\030not a procedure type: ~a");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000(\047, but where given an argument of type `");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\012 of type `");
lf[120]=C_decode_literal(C_heaptop,"\376B\000\000\023expected argument #");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[122]=C_decode_literal(C_heaptop,"\376B\000\000\022, but where given ");
lf[123]=C_decode_literal(C_heaptop,"\376B\000\000\011 argument");
lf[124]=C_decode_literal(C_heaptop,"\376B\000\000\011expected ");
lf[125]=C_decode_literal(C_heaptop,"\376B\000\000#\047, but were given a value of type `");
lf[126]=C_decode_literal(C_heaptop,"\376B\000\000\032expected a value of type `");
lf[127]=C_h_intern(&lf[127],9,"make-list");
lf[128]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[129]=C_decode_literal(C_heaptop,"\376B\000\000\024not a procedure type");
lf[130]=C_h_intern(&lf[130],5,"quote");
lf[131]=C_h_intern(&lf[131],6,"string");
lf[132]=C_h_intern(&lf[132],6,"symbol");
lf[133]=C_h_intern(&lf[133],6,"fixnum");
lf[134]=C_h_intern(&lf[134],5,"float");
lf[135]=C_h_intern(&lf[135],7,"boolean");
lf[136]=C_h_intern(&lf[136],3,"eof");
lf[137]=C_h_intern(&lf[137],6,"vector");
lf[138]=C_h_intern(&lf[138],22,"\003sysgeneric-structure\077");
lf[139]=C_h_intern(&lf[139],14,"\004coreundefined");
lf[140]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\001*\376\377\016");
lf[141]=C_h_intern(&lf[141],9,"\004coreproc");
lf[142]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[143]=C_h_intern(&lf[143],15,"\004coreglobal-ref");
lf[144]=C_h_intern(&lf[144],13,"\004corevariable");
lf[145]=C_h_intern(&lf[145],2,"if");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000Cbranches in conditional expression differ in the number of results:");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\016in conditional");
lf[148]=C_h_intern(&lf[148],3,"let");
lf[149]=C_h_intern(&lf[149],10,"alist-cons");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\025in `let\047 binding of `");
lf[151]=C_h_intern(&lf[151],11,"\004corelambda");
lf[152]=C_h_intern(&lf[152],6,"lambda");
lf[153]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011procedure\376\377\016");
lf[154]=C_h_intern(&lf[154],7,"butlast");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\006#!rest\376\377\016");
lf[156]=C_h_intern(&lf[156],30,"\010compilerdecompose-lambda-list");
lf[157]=C_h_intern(&lf[157],4,"set!");
lf[158]=C_h_intern(&lf[158],9,"\004coreset!");
lf[159]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\011undefined\376\377\016");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000 \047 does not match declared type `");
lf[161]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 to toplevel variable `");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\035assignment of value of type `");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\022in assignment to `");
lf[164]=C_h_intern(&lf[164],14,"\004coreprimitive");
lf[165]=C_h_intern(&lf[165],15,"\004coreinline_ref");
lf[166]=C_h_intern(&lf[166],9,"\004corecall");
lf[167]=C_decode_literal(C_heaptop,"\376B\000\000\024 of procedure call `");
lf[168]=C_decode_literal(C_heaptop,"\376B\000\000\021operator position");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\012argument #");
lf[170]=C_decode_literal(C_heaptop,"\376B\000\000\003in ");
lf[171]=C_h_intern(&lf[171],4,"iota");
lf[172]=C_h_intern(&lf[172],11,"\004coreswitch");
lf[173]=C_h_intern(&lf[173],9,"\004corecond");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000\031unexpected node class: ~a");
lf[175]=C_h_intern(&lf[175],27,"\010compilerload-type-database");
lf[176]=C_h_intern(&lf[176],8,"\003sysput!");
lf[177]=C_h_intern(&lf[177],10,"\003sysnotice");
lf[178]=C_decode_literal(C_heaptop,"\376B\000\000)\047 conflicts with previously loaded type `");
lf[179]=C_decode_literal(C_heaptop,"\376B\000\000\030\047 for toplevel binding `");
lf[180]=C_decode_literal(C_heaptop,"\376B\000\000\021type-definition `");
lf[181]=C_h_intern(&lf[181],9,"read-file");
lf[182]=C_h_intern(&lf[182],21,"\010compilerverbose-mode");
lf[183]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[184]=C_decode_literal(C_heaptop,"\376B\000\000\026loading type database ");
lf[185]=C_h_intern(&lf[185],12,"file-exists\077");
lf[186]=C_h_intern(&lf[186],13,"make-pathname");
lf[187]=C_h_intern(&lf[187],15,"repository-path");
lf[188]=C_h_intern(&lf[188],9,"\003syserror");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
C_register_lf2(lf,190,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1246,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1244 */
static void C_ccall f_1246(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1246,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1249,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1247 in k1244 */
static void C_ccall f_1249(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1249,2,t0,t1);}
t2=C_mutate((C_word*)lf[0]+1 /* (set! d ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1251,tmp=(C_word)a,a+=2,tmp));
t3=C_mutate((C_word*)lf[6]+1 /* (set! ##compiler#scrutinize ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1269,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate((C_word*)lf[175]+1 /* (set! ##compiler#load-type-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5430,tmp=(C_word)a,a+=2,tmp));
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_UNDEFINED);}

/* ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5430(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr3r,(void*)f_5430r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_5430r(t0,t1,t2,t3);}}

static void C_ccall f_5430r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5434,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* scrutinizer.scm:618: repository-path */
t5=*((C_word*)lf[187]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=t4;
f_5434(2,t6,C_i_car(t3));}
else{
/* ##sys#error */
t6=*((C_word*)lf[188]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[189],t3);}}}

/* k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5434,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5437,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5547,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:619: make-pathname */
t4=*((C_word*)lf[186]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,((C_word*)t0)[2]);}

/* k5545 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:619: file-exists? */
t2=*((C_word*)lf[185]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5437,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5443,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[182]+1))){
t3=*((C_word*)lf[1]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5534,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* display */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[184],t3);}
else{
t3=t2;
f_5443(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k5532 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5534(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5534,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5537,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5535 in k5532 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5537(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5537,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5540,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[183],((C_word*)t0)[2]);}

/* k5538 in k5535 in k5532 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5443(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5443,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5450,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:633: read-file */
t3=*((C_word*)lf[181]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5450,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5452,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_5452(t5,((C_word*)t0)[2],t1);}

/* loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_fcall f_5452(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5452,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5520,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5467,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm:625: ##sys#get */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t5,lf[16]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5467,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5473,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5479,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t1)){
t5=C_i_equalp(t1,t2);
t6=t4;
f_5479(t6,C_i_not(t5));}
else{
t5=t4;
f_5479(t5,C_SCHEME_FALSE);}}

/* k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_fcall f_5479(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5479,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5486,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* scrutinizer.scm:632: ##sys#put! */
t2=*((C_word*)lf[176]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[2],((C_word*)t0)[3],lf[16],((C_word*)t0)[4]);}}

/* k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5486(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5486,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[180],t1);}

/* k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5492,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5495,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[179],((C_word*)t0)[4]);}

/* k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5498,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5496 in k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[178],((C_word*)t0)[3]);}

/* k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5501,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5504,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5504(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5504,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5507,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5507,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5510,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5508 in k5505 in k5502 in k5499 in k5496 in k5493 in k5490 in k5487 in k5484 in k5477 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:628: ##sys#notice */
t2=*((C_word*)lf[177]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k5471 in k5465 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5473(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:632: ##sys#put! */
t2=*((C_word*)lf[176]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[16],((C_word*)t0)[2]);}

/* k5518 in loop1204 in k5448 in k5441 in k5435 in k5432 in ##compiler#load-type-database in k1247 in k1244 */
static void C_ccall f_5520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5452(t3,((C_word*)t0)[2],t2);}

/* ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1269(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word ab[174],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1269,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_UNDEFINED;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_SCHEME_UNDEFINED;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_UNDEFINED;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_UNDEFINED;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_SCHEME_UNDEFINED;
t29=(*a=C_VECTOR_TYPE|1,a[1]=t28,tmp=(C_word)a,a+=2,tmp);
t30=C_SCHEME_UNDEFINED;
t31=(*a=C_VECTOR_TYPE|1,a[1]=t30,tmp=(C_word)a,a+=2,tmp);
t32=C_SCHEME_UNDEFINED;
t33=(*a=C_VECTOR_TYPE|1,a[1]=t32,tmp=(C_word)a,a+=2,tmp);
t34=C_SCHEME_UNDEFINED;
t35=(*a=C_VECTOR_TYPE|1,a[1]=t34,tmp=(C_word)a,a+=2,tmp);
t36=C_SCHEME_UNDEFINED;
t37=(*a=C_VECTOR_TYPE|1,a[1]=t36,tmp=(C_word)a,a+=2,tmp);
t38=C_SCHEME_UNDEFINED;
t39=(*a=C_VECTOR_TYPE|1,a[1]=t38,tmp=(C_word)a,a+=2,tmp);
t40=C_SCHEME_UNDEFINED;
t41=(*a=C_VECTOR_TYPE|1,a[1]=t40,tmp=(C_word)a,a+=2,tmp);
t42=C_SCHEME_UNDEFINED;
t43=(*a=C_VECTOR_TYPE|1,a[1]=t42,tmp=(C_word)a,a+=2,tmp);
t44=C_SCHEME_UNDEFINED;
t45=(*a=C_VECTOR_TYPE|1,a[1]=t44,tmp=(C_word)a,a+=2,tmp);
t46=C_SCHEME_UNDEFINED;
t47=(*a=C_VECTOR_TYPE|1,a[1]=t46,tmp=(C_word)a,a+=2,tmp);
t48=C_SCHEME_UNDEFINED;
t49=(*a=C_VECTOR_TYPE|1,a[1]=t48,tmp=(C_word)a,a+=2,tmp);
t50=C_SCHEME_UNDEFINED;
t51=(*a=C_VECTOR_TYPE|1,a[1]=t50,tmp=(C_word)a,a+=2,tmp);
t52=C_SCHEME_UNDEFINED;
t53=(*a=C_VECTOR_TYPE|1,a[1]=t52,tmp=(C_word)a,a+=2,tmp);
t54=C_SCHEME_UNDEFINED;
t55=(*a=C_VECTOR_TYPE|1,a[1]=t54,tmp=(C_word)a,a+=2,tmp);
t56=C_SCHEME_UNDEFINED;
t57=(*a=C_VECTOR_TYPE|1,a[1]=t56,tmp=(C_word)a,a+=2,tmp);
t58=C_SCHEME_UNDEFINED;
t59=(*a=C_VECTOR_TYPE|1,a[1]=t58,tmp=(C_word)a,a+=2,tmp);
t60=C_SCHEME_UNDEFINED;
t61=(*a=C_VECTOR_TYPE|1,a[1]=t60,tmp=(C_word)a,a+=2,tmp);
t62=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1374,a[2]=t43,tmp=(C_word)a,a+=3,tmp));
t63=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1461,a[2]=t5,a[3]=t3,a[4]=t43,tmp=(C_word)a,a+=5,tmp));
t64=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1534,a[2]=t9,tmp=(C_word)a,a+=3,tmp));
t65=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1566,a[2]=t9,a[3]=t51,a[4]=t43,tmp=(C_word)a,a+=5,tmp));
t66=C_set_block_item(t13,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1607,a[2]=t13,a[3]=t15,a[4]=t17,tmp=(C_word)a,a+=5,tmp));
t67=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1787,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t68=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1868,a[2]=t13,tmp=(C_word)a,a+=3,tmp));
t69=C_set_block_item(t19,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1955,a[2]=t21,tmp=(C_word)a,a+=3,tmp));
t70=C_set_block_item(t21,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1964,a[2]=t55,a[3]=t39,a[4]=t27,a[5]=t29,a[6]=t23,a[7]=t19,tmp=(C_word)a,a+=8,tmp));
t71=C_set_block_item(t23,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2432,tmp=(C_word)a,a+=2,tmp));
t72=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2472,tmp=(C_word)a,a+=2,tmp));
t73=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2494,a[2]=t27,a[3]=t19,a[4]=t25,tmp=(C_word)a,a+=5,tmp));
t74=C_set_block_item(t29,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2696,a[2]=t19,a[3]=t29,tmp=(C_word)a,a+=4,tmp));
t75=C_set_block_item(t31,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2762,a[2]=t33,tmp=(C_word)a,a+=3,tmp));
t76=C_set_block_item(t33,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2771,a[2]=t35,a[3]=t37,a[4]=t23,a[5]=t31,tmp=(C_word)a,a+=6,tmp));
t77=C_set_block_item(t35,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3043,a[2]=t31,a[3]=t25,tmp=(C_word)a,a+=4,tmp));
t78=C_set_block_item(t37,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3253,a[2]=t31,a[3]=t37,tmp=(C_word)a,a+=4,tmp));
t79=C_set_block_item(t39,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3308,a[2]=t39,tmp=(C_word)a,a+=3,tmp));
t80=C_set_block_item(t41,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3648,a[2]=t43,tmp=(C_word)a,a+=3,tmp));
t81=C_set_block_item(t43,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3729,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t82=C_set_block_item(t45,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3743,a[2]=t45,tmp=(C_word)a,a+=3,tmp));
t83=C_set_block_item(t47,0,*((C_word*)lf[100]+1));
t84=C_set_block_item(t49,0,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3864,tmp=(C_word)a,a+=2,tmp));
t85=C_set_block_item(t51,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3918,a[2]=t49,tmp=(C_word)a,a+=3,tmp));
t86=C_set_block_item(t53,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3938,a[2]=t55,a[3]=t31,a[4]=t43,a[5]=t57,a[6]=t49,tmp=(C_word)a,a+=7,tmp));
t87=C_set_block_item(t55,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4277,a[2]=t55,tmp=(C_word)a,a+=3,tmp));
t88=C_set_block_item(t57,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4319,a[2]=t25,tmp=(C_word)a,a+=3,tmp));
t89=C_set_block_item(t59,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4590,a[2]=t59,tmp=(C_word)a,a+=3,tmp));
t90=C_set_block_item(t61,0,(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4622,a[2]=t49,a[3]=t53,a[4]=t31,a[5]=t47,a[6]=t41,a[7]=t11,a[8]=t61,a[9]=t59,a[10]=t51,a[11]=t43,a[12]=t19,a[13]=t7,a[14]=t5,tmp=(C_word)a,a+=15,tmp));
t91=C_slot(t2,C_fix(3));
t92=C_i_car(t91);
/* scrutinizer.scm:616: walk */
t93=((C_word*)t61)[1];
f_4622(t93,t1,t92,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST,C_SCHEME_FALSE);}

/* walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4622(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word *a;
loop:
a=C_alloc(23);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4622,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=t2;
t9=C_slot(t8,C_fix(2));
t10=t2;
t11=C_slot(t10,C_fix(1));
t12=*((C_word*)lf[54]+1);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4653,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=C_eqp(t11,lf[130]);
if(C_truep(t14)){
t15=C_i_car(t9);
if(C_truep(C_i_stringp(t15))){
t16=C_a_i_list(&a,1,lf[131]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_symbolp(t15))){
t16=C_a_i_list(&a,1,lf[132]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_fixnump(t15))){
t16=C_a_i_list(&a,1,lf[133]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_flonump(t15))){
t16=C_a_i_list(&a,1,lf[134]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_numberp(t15))){
t16=C_a_i_list(&a,1,lf[73]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_booleanp(t15))){
t16=C_a_i_list(&a,1,lf[135]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_listp(t15))){
t16=C_a_i_list(&a,1,lf[77]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_pairp(t15))){
t16=C_a_i_list(&a,1,lf[76]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_eofp(t15))){
t16=C_a_i_list(&a,1,lf[136]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
if(C_truep(C_i_vectorp(t15))){
t16=C_a_i_list(&a,1,lf[137]);
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,t16);}
else{
t16=C_immp(t15);
t17=(C_truep(t16)?C_SCHEME_FALSE:(C_truep(*((C_word*)lf[138]+1))?t15:C_SCHEME_FALSE));
if(C_truep(t17)){
t18=C_slot(t15,C_fix(0));
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,lf[39],t19);
t21=C_a_i_list(&a,1,t20);
t22=*((C_word*)lf[54]+1);
t23=t1;
((C_proc2)(void*)(*((C_word*)t23+1)))(2,t23,t21);}
else{
if(C_truep(C_i_nullp(t15))){
t18=C_a_i_list(&a,1,lf[79]);
t19=*((C_word*)lf[54]+1);
t20=t1;
((C_proc2)(void*)(*((C_word*)t20+1)))(2,t20,t18);}
else{
t18=C_charp(t15);
t19=(C_truep(t18)?C_a_i_list(&a,1,lf[30]):C_a_i_list(&a,1,lf[8]));
t20=*((C_word*)lf[54]+1);
t21=t1;
((C_proc2)(void*)(*((C_word*)t21+1)))(2,t21,t19);}}}}}}}}}}}}}
else{
t15=C_eqp(t11,lf[139]);
if(C_truep(t15)){
t16=*((C_word*)lf[54]+1);
t17=t1;
((C_proc2)(void*)(*((C_word*)t17+1)))(2,t17,lf[140]);}
else{
t16=C_eqp(t11,lf[141]);
if(C_truep(t16)){
t17=*((C_word*)lf[54]+1);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,lf[142]);}
else{
t17=C_eqp(t11,lf[143]);
if(C_truep(t17)){
t18=C_i_car(t9);
/* scrutinizer.scm:530: global-result */
t19=((C_word*)((C_word*)t0)[14])[1];
f_1374(t19,t13,t18,t4);}
else{
t18=C_eqp(t11,lf[144]);
if(C_truep(t18)){
t19=C_i_car(t9);
/* scrutinizer.scm:531: variable-result */
t20=((C_word*)((C_word*)t0)[13])[1];
f_1461(t20,t13,t19,t3,t4);}
else{
t19=C_eqp(t11,lf[145]);
if(C_truep(t19)){
t20=(*a=C_CLOSURE_TYPE|14,a[1]=(C_word)f_4717,a[2]=((C_word*)t0)[7],a[3]=t5,a[4]=t3,a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t1,a[8]=((C_word*)t0)[9],a[9]=t2,a[10]=((C_word*)t0)[10],a[11]=t4,a[12]=((C_word*)t0)[11],a[13]=t13,a[14]=((C_word*)t0)[12],tmp=(C_word)a,a+=15,tmp);
t21=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4891,a[2]=t4,a[3]=t20,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t22=C_i_car(t7);
/* scrutinizer.scm:532: walk */
t84=t21;
t85=t22;
t86=t3;
t87=t4;
t88=t5;
t1=t84;
t2=t85;
t3=t86;
t4=t87;
t5=t88;
goto loop;}
else{
t20=C_eqp(t11,lf[148]);
if(C_truep(t20)){
t21=C_SCHEME_UNDEFINED;
t22=(*a=C_VECTOR_TYPE|1,a[1]=t21,tmp=(C_word)a,a+=2,tmp);
t23=C_set_block_item(t22,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4906,a[2]=((C_word*)t0)[6],a[3]=t22,a[4]=t3,a[5]=t5,a[6]=t4,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp));
t24=((C_word*)t22)[1];
f_4906(t24,t13,t9,t7,C_SCHEME_END_OF_LIST);}
else{
t21=C_eqp(t11,lf[151]);
t22=(C_truep(t21)?t21:C_eqp(t11,lf[152]));
if(C_truep(t22)){
t23=C_i_car(t9);
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5000,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[8],a[6]=t7,a[7]=t5,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm:558: decompose-lambda-list */
t25=*((C_word*)lf[156]+1);
((C_proc4)(void*)(*((C_word*)t25+1)))(4,t25,t13,t23,t24);}
else{
t23=C_eqp(t11,lf[157]);
t24=(C_truep(t23)?t23:C_eqp(t11,lf[158]));
if(C_truep(t24)){
t25=C_i_car(t9);
t26=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5116,a[2]=((C_word*)t0)[8],a[3]=t7,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=((C_word*)t0)[11],a[8]=t1,a[9]=t3,a[10]=t25,tmp=(C_word)a,a+=11,tmp);
/* scrutinizer.scm:578: ##sys#get */
t27=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t27+1)))(4,t27,t26,t25,lf[16]);}
else{
t25=C_eqp(t11,lf[164]);
t26=(C_truep(t25)?t25:C_eqp(t11,lf[165]));
if(C_truep(t26)){
t27=*((C_word*)lf[54]+1);
t28=t1;
((C_proc2)(void*)(*((C_word*)t28+1)))(2,t28,lf[8]);}
else{
t27=C_eqp(t11,lf[166]);
if(C_truep(t27)){
t28=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5240,a[2]=t3,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[6],a[5]=t9,a[6]=t4,a[7]=t13,a[8]=((C_word*)t0)[3],a[9]=t7,tmp=(C_word)a,a+=10,tmp);
/* scrutinizer.scm:597: fragment */
f_3864(t28,t2);}
else{
t28=C_eqp(t11,lf[172]);
t29=(C_truep(t28)?t28:C_eqp(t11,lf[173]));
if(C_truep(t29)){
/* scrutinizer.scm:610: bomb */
t30=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t30+1)))(4,t30,t13,lf[174],t11);}
else{
t30=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5372,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t31=C_SCHEME_UNDEFINED;
t32=(*a=C_VECTOR_TYPE|1,a[1]=t31,tmp=(C_word)a,a+=2,tmp);
t33=C_set_block_item(t32,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5374,a[2]=t32,a[3]=t4,a[4]=t3,a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp));
t34=((C_word*)t32)[1];
f_5374(t34,t30,t7);}}}}}}}}}}}}}

/* loop1132 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5374(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5374,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5389,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g11391140 */
t6=t3;
f_5382(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5387 in loop1132 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5389(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_5374(t3,((C_word*)t0)[2],t2);}

/* g1139 in loop1132 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5382,NULL,3,t0,t1,t2);}
/* scrutinizer.scm:612: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4622(t3,t1,t2,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}

/* k5370 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5372(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[8]);}

/* k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5240,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5243,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5254,a[2]=((C_word*)t0)[9],a[3]=t6,a[4]=t3,a[5]=t5,a[6]=t1,a[7]=((C_word*)t0)[2],a[8]=((C_word*)t0)[3],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[4],tmp=(C_word)a,a+=11,tmp);
t8=C_i_length(((C_word*)t0)[9]);
/* scrutinizer.scm:607: iota */
t9=*((C_word*)lf[171]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t7,t8);}

/* k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5254(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5254,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5256,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp));
t5=((C_word*)t3)[1];
f_5256(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5256(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5256,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5287,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5339,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g11031104 */
t10=t6;
f_5287(t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k5337 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5339,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5269,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_5269(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_5269(t5,t4);}}

/* k5267 in k5337 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5269(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop10841098 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_5256(t5,((C_word*)t0)[2],t3,t4);}

/* g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5287(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5287,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5295,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
/* open-output-string */
t5=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5295(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5295,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[170],t1);}

/* k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5298,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5321,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_zerop(((C_word*)t0)[2]))){
/* display */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[168],((C_word*)t0)[4]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5327,a[2]=((C_word*)t0)[2],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t5=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k5325 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5327,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5330,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[169],t1);}

/* k5328 in k5325 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5330(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5330,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5333,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5331 in k5328 in k5325 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5333(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5319 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5301,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5304,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[167],((C_word*)t0)[3]);}

/* k5302 in k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5304(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5304,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5307,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* write */
t3=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5305 in k5302 in k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5307(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5307,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5310,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k5308 in k5305 in k5302 in k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5310(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5310,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5313,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5311 in k5308 in k5305 in k5302 in k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5317,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:606: walk */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4622(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],((C_word*)t0)[5],C_SCHEME_FALSE);}

/* k5315 in k5311 in k5308 in k5305 in k5302 in k5299 in k5296 in k5293 in g1103 in loop1084 in k5252 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5317(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:599: single */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3648(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5241 in k5238 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm:608: call-result */
t3=((C_word*)((C_word*)t0)[5])[1];
f_3938(t3,((C_word*)t0)[4],t1,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5119,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5202,a[2]=((C_word*)t0)[10],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[6],a[7]=t2,a[8]=((C_word*)t0)[4],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
t4=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5205,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[163],t1);}

/* k5203 in k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5208,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5206 in k5203 in k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5208(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5208,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5211,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k5209 in k5206 in k5203 in k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5211(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5211,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5214,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5212 in k5209 in k5206 in k5203 in k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5214(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5214,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm:581: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4622(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[6],((C_word*)t0)[2]);}

/* k5216 in k5212 in k5209 in k5206 in k5203 in k5200 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:579: single */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3648(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5119,2,t0,t1);}
t2=C_i_assq(((C_word*)t0)[8],((C_word*)t0)[7]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5125,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5144,a[2]=t1,a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[3])){
if(C_truep(t2)){
t5=t4;
f_5144(t5,C_SCHEME_FALSE);}
else{
t5=C_eqp(((C_word*)t0)[3],lf[7]);
if(C_truep(t5)){
t6=t4;
f_5144(t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5194,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:586: match */
t7=((C_word*)((C_word*)t0)[2])[1];
f_2762(t7,t6,((C_word*)t0)[3],t1);}}}
else{
t5=t4;
f_5144(t5,C_SCHEME_FALSE);}}

/* k5192 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_5144(t2,C_i_not(t1));}

/* k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5144(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5144,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5151,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[6];
f_5125(2,t2,C_SCHEME_UNDEFINED);}}

/* k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5151,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5154,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[162],t1);}

/* k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5157,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5157,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5160,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[161],((C_word*)t0)[4]);}

/* k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5160(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5160,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5163,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k5161 in k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5163,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5166,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[160],((C_word*)t0)[3]);}

/* k5164 in k5161 in k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5169,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k5167 in k5164 in k5161 in k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5169,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k5170 in k5167 in k5164 in k5161 in k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5172,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5175,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5173 in k5170 in k5167 in k5164 in k5161 in k5158 in k5155 in k5152 in k5149 in k5142 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5175(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:587: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5123 in k5117 in k5114 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
t2=C_i_cdr(((C_word*)t0)[4]);
t3=C_eqp(lf[17],t2);
if(C_truep(t3)){
t4=C_i_set_cdr(((C_word*)t0)[4],((C_word*)t0)[3]);
t5=*((C_word*)lf[54]+1);
t6=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[159]);}
else{
t4=*((C_word*)lf[54]+1);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[159]);}}
else{
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[159]);}}

/* a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5000(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5000,5,t0,t1,t2,t3,t4);}
t5=(C_truep(((C_word*)t0)[7])?C_a_i_list(&a,1,((C_word*)t0)[7]):C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5007,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t4,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[4],a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=t5,a[11]=t1,tmp=(C_word)a,a+=12,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5094,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:562: make-list */
t8=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t3,lf[8]);}

/* k5092 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(((C_word*)t0)[3])){
/* scrutinizer.scm:562: append */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[155]);}
else{
/* scrutinizer.scm:562: append */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}}

/* k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5007(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5007,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_5010,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[9],a[8]=((C_word*)t0)[10],a[9]=t1,a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5043,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5047,a[2]=t7,a[3]=t4,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[4])){
/* scrutinizer.scm:564: butlast */
t9=*((C_word*)lf[154]+1);
((C_proc3)(void*)(*((C_word*)t9+1)))(3,t9,t8,((C_word*)t0)[2]);}
else{
t9=t8;
f_5047(2,t9,((C_word*)t0)[2]);}}

/* k5045 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5047,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5049,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_5049(t5,((C_word*)t0)[2],t1);}

/* loop1021 in k5045 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_5049(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5049,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=C_a_i_cons(&a,2,t3,lf[8]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t6=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10211034 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}
else{
t6=C_mutate(((C_word *)((C_word*)t0)[2])+1,t5);
t7=C_mutate(((C_word *)((C_word*)t0)[4])+1,t5);
t8=C_slot(t2,C_fix(1));
/* loop10211034 */
t14=t1;
t15=t8;
t1=t14;
t2=t15;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5041 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5043(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:563: append */
t2=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5008 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5010(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5010,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5013,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[7]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5032,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[2])){
/* scrutinizer.scm:567: alist-cons */
t5=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],lf[77],t1);}
else{
t5=t4;
f_5032(2,t5,t1);}}

/* k5030 in k5008 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5032(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5032,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5036,a[2]=t1,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:568: add-loc */
t3=((C_word*)((C_word*)t0)[4])[1];
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5034 in k5030 in k5008 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:566: walk */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4622(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* k5011 in k5008 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5013(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5013,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5020,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_a_i_list(&a,1,((C_word*)t0)[3]);
/* scrutinizer.scm:571: append */
t4=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,lf[153],((C_word*)t0)[2],t3,t1);}

/* k5018 in k5011 in k5008 in k5005 in a4999 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_5020(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5020,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,1,t1));}

/* loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4906(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4906,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=C_i_car(t3);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4924,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=t5,a[5]=t1,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm:552: append */
t7=*((C_word*)lf[55]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t4,((C_word*)t0)[4]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4927,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[7],a[4]=t2,a[5]=t3,a[6]=((C_word*)t0)[6],a[7]=t5,a[8]=((C_word*)t0)[2],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
t7=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4953,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[150],t1);}

/* k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4953(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4953,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4956,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4978,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[5]);
/* scrutinizer.scm:554: real-name */
t5=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* k4976 in k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4978(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4954 in k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4956,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_4959,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4957 in k4954 in k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4959,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4962,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4960 in k4957 in k4954 in k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4962,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4966,a[2]=((C_word*)t0)[6],a[3]=t1,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
t4=C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm:555: walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4622(t5,t2,t3,((C_word*)t0)[2],((C_word*)t0)[6],t4);}

/* k4964 in k4960 in k4957 in k4954 in k4951 in k4948 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:553: single */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3648(t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4925 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4927(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4927,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4942,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(((C_word*)t0)[6]);
/* scrutinizer.scm:556: alist-cons */
t6=*((C_word*)lf[149]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t4,t5,t1,((C_word*)t0)[2]);}

/* k4940 in k4925 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:556: loop */
t2=((C_word*)((C_word*)t0)[5])[1];
f_4906(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4922 in loop in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:552: walk */
t2=((C_word*)((C_word*)t0)[6])[1];
f_4622(t2,((C_word*)t0)[5],((C_word*)t0)[4],t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k4889 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4891(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:532: single */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3648(t2,((C_word*)t0)[3],lf[147],t1,((C_word*)t0)[2]);}

/* k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],a[11]=((C_word*)t0)[12],a[12]=((C_word*)t0)[13],a[13]=((C_word*)t0)[14],tmp=(C_word)a,a+=14,tmp);
/* scrutinizer.scm:533: always-true */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1566(t3,t2,t1,((C_word*)t0)[11],((C_word*)t0)[9]);}

/* k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_4723,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],a[11]=((C_word*)t0)[11],a[12]=((C_word*)t0)[12],a[13]=((C_word*)t0)[13],tmp=(C_word)a,a+=14,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm:534: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4622(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[10],((C_word*)t0)[2]);}

/* k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4723,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4726,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[10],a[7]=((C_word*)t0)[11],a[8]=t1,a[9]=((C_word*)t0)[12],a[10]=((C_word*)t0)[13],tmp=(C_word)a,a+=11,tmp);
t3=C_i_caddr(((C_word*)t0)[5]);
/* scrutinizer.scm:535: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4622(t4,t2,t3,((C_word*)t0)[3],((C_word*)t0)[10],((C_word*)t0)[2]);}

/* k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4732,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
t3=C_eqp(((C_word*)t0)[8],lf[8]);
if(C_truep(t3)){
t4=t2;
f_4732(t4,C_SCHEME_FALSE);}
else{
t4=C_eqp(lf[8],t1);
t5=t2;
f_4732(t5,C_i_not(t4));}}

/* k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4732(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4732,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4735,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[11],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4807,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4865,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:538: any */
t5=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[9]);}
else{
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[8]);}}

/* k4863 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4865,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4807(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm:539: any */
t3=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)((C_word*)t0)[2])[1],((C_word*)t0)[3]);}}

/* k4859 in k4863 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[4];
f_4807(t2,C_SCHEME_FALSE);}
else{
t2=C_i_length(((C_word*)t0)[3]);
t3=C_i_length(((C_word*)t0)[2]);
t4=C_i_nequalp(t2,t3);
t5=((C_word*)t0)[4];
f_4807(t5,C_i_not(t4));}}

/* k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4807(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4807,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4814,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[5];
f_4735(2,t2,C_SCHEME_UNDEFINED);}}

/* k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4814,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4817,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[146],t1);}

/* k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4817(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4817,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4820,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4818 in k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4823,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k4821 in k4818 in k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4826,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4833,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:545: pp-fragment */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3918(t4,t3,((C_word*)t0)[2]);}

/* k4831 in k4821 in k4818 in k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4824 in k4821 in k4818 in k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4829,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4827 in k4824 in k4821 in k4818 in k4815 in k4812 in k4805 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4829(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:541: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4733 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4735(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4735,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4740,a[2]=t3,a[3]=t7,a[4]=t5,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_4740(t9,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop965 in k4733 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4740(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4740,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4771,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4790,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g984985 */
t10=t6;
f_4771(t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k4788 in loop965 in k4733 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4790,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4753,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_4753(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_4753(t5,t4);}}

/* k4751 in k4788 in loop965 in k4733 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4753(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop965979 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4740(t5,((C_word*)t0)[2],t3,t4);}

/* g984 in loop965 in k4733 in k4730 in k4724 in k4721 in k4718 in k4715 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4771(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4771,NULL,4,t0,t1,t2,t3);}
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t2,t4);
t6=C_a_i_cons(&a,2,lf[26],t5);
/* scrutinizer.scm:546: simplify */
t7=((C_word*)((C_word*)t0)[2])[1];
f_1955(t7,t1,t6);}

/* k4651 in walk in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* noreturn-type? in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4590(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4590,3,t0,t1,t2);}
t3=C_eqp(lf[72],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=C_eqp(lf[26],t4);
if(C_truep(t5)){
t6=C_i_cdr(t2);
/* scrutinizer.scm:519: any */
t7=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t1,((C_word*)((C_word*)t0)[2])[1],t6);}
else{
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4319(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4319,NULL,4,t0,t1,t2,t3);}
t4=C_i_memq(t2,lf[128]);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t3,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t4)){
t6=t5;
f_4329(t6,t4);}
else{
t6=C_i_not_pair_p(t2);
if(C_truep(t6)){
t7=t5;
f_4329(t7,t6);}
else{
t7=C_i_car(t2);
t8=t5;
f_4329(t8,C_eqp(lf[7],t7));}}}

/* k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4329(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4329,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:481: make-list */
t3=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[4],lf[8]);}
else{
t2=C_i_car(((C_word*)t0)[3]);
t3=C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4345,a[2]=t5,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4352,a[2]=((C_word*)t0)[4],a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
t8=C_i_cadr(((C_word*)t0)[3]);
t9=C_i_stringp(t8);
if(C_truep(t9)){
t10=t7;
f_4352(t10,(C_truep(t9)?C_i_caddr(((C_word*)t0)[3]):C_i_cadr(((C_word*)t0)[3])));}
else{
t10=C_i_cadr(((C_word*)t0)[3]);
t11=C_i_symbolp(t10);
t12=t7;
f_4352(t12,(C_truep(t11)?C_i_caddr(((C_word*)t0)[3]):C_i_cadr(((C_word*)t0)[3])));}}
else{
/* scrutinizer.scm:499: bomb */
t4=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],lf[129],((C_word*)t0)[3]);}}}

/* k4350 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4352(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4352,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4354,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4354(t5,((C_word*)t0)[3],t1,((C_word*)t0)[2],C_SCHEME_FALSE);}

/* loop in k4350 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4354(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4354,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_END_OF_LIST);}
else{
t5=C_i_car(t2);
t6=C_eqp(lf[68],t5);
if(C_truep(t6)){
t7=C_i_cdr(t2);
/* scrutinizer.scm:492: loop */
t19=t1;
t20=t7;
t21=t3;
t22=C_SCHEME_TRUE;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}
else{
t7=C_i_car(t2);
t8=C_eqp(lf[67],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4384,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
t10=C_i_cdr(t2);
if(C_truep(C_i_pairp(t10))){
t11=C_i_cadr(t2);
t12=t9;
f_4384(t12,C_eqp(lf[66],t11));}
else{
t11=t9;
f_4384(t11,C_SCHEME_FALSE);}}
else{
t9=(C_truep(t4)?C_i_less_or_equalp(t3,C_fix(0)):C_SCHEME_FALSE);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_END_OF_LIST);}
else{
t10=C_i_car(t2);
t11=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4426,a[2]=t10,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t12=C_i_cdr(t2);
t13=C_a_i_minus(&a,2,t3,C_fix(1));
/* scrutinizer.scm:497: loop */
t19=t11;
t20=t12;
t21=t13;
t22=t4;
t1=t19;
t2=t20;
t3=t21;
t4=t22;
goto loop;}}}}}

/* k4424 in loop in k4350 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4426(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4426,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4382 in loop in k4350 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4384(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=f_2472(t3);
/* scrutinizer.scm:495: make-list */
t5=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[3],((C_word*)t0)[2],t4);}

/* k4343 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4345(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:498: values */
C_values(4,0,((C_word*)t0)[3],t1,((C_word*)((C_word*)t0)[2])[1]);}

/* k4334 in k4327 in procedure-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:481: values */
C_values(4,0,((C_word*)t0)[2],t1,C_SCHEME_FALSE);}

/* procedure-type? in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4277(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4277,3,t0,t1,t2);}
t3=C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=C_eqp(lf[33],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_car(t2);
t7=C_eqp(lf[26],t6);
if(C_truep(t7)){
t8=C_i_cdr(t2);
/* scrutinizer.scm:476: every */
t9=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}
else{
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}}

/* call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3938(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3938,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3941,a[2]=t5,a[3]=t4,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=*((C_word*)lf[54]+1);
t8=C_i_car(t2);
t9=C_i_cdr(t2);
t10=C_i_length(t9);
t11=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_4267,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t10,a[5]=((C_word*)t0)[3],a[6]=t6,a[7]=t3,a[8]=((C_word*)t0)[4],a[9]=t8,a[10]=((C_word*)t0)[5],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
/* scrutinizer.scm:438: make-list */
t12=*((C_word*)lf[127]+1);
((C_proc4)(void*)(*((C_word*)t12+1)))(4,t12,t11,t10,lf[8]);}

/* k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[34],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4267,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[8],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,lf[33],t3);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4018,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],a[10]=((C_word*)t0)[11],tmp=(C_word)a,a+=11,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4213,a[2]=((C_word*)t0)[6],a[3]=t4,a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[7],a[6]=t5,a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4259,a[2]=((C_word*)t0)[9],a[3]=t4,a[4]=((C_word*)t0)[5],a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:439: procedure-type? */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4277(3,t8,t7,((C_word*)t0)[9]);}

/* k4257 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4259(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4259,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
f_4213(t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4255,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:440: match */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2762(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4253 in k4257 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4213(t2,C_i_not(t1));}

/* k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4213,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[6];
f_4018(2,t2,C_SCHEME_UNDEFINED);}}

/* k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4245,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:445: pname */
t4=((C_word*)t0)[2];
f_3941(t4,t3);}

/* k4243 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4223,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[126],((C_word*)t0)[4]);}

/* k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4226,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4229,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4227 in k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4232,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[125],((C_word*)t0)[3]);}

/* k4230 in k4227 in k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4232(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4232,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4235,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4238,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4238(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4238,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4239 in k4236 in k4233 in k4230 in k4227 in k4224 in k4221 in k4218 in k4211 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:441: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4018,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4023,a[2]=((C_word*)t0)[8],a[3]=((C_word*)t0)[9],a[4]=((C_word*)t0)[10],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4037,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[10],tmp=(C_word)a,a+=9,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4037(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4037,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[54]+1);
t5=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_4044,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t3,a[9]=((C_word*)t0)[8],a[10]=t1,tmp=(C_word)a,a+=11,tmp);
t6=C_i_length(t2);
if(C_truep(C_i_nequalp(t6,((C_word*)t0)[2]))){
t7=t5;
f_4044(2,t7,C_SCHEME_UNDEFINED);}
else{
t7=C_i_length(t2);
t8=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4164,a[2]=((C_word*)t0)[4],a[3]=t7,a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=t5,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t9=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}

/* k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4164,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4167,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4206,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:456: pname */
t4=((C_word*)t0)[2];
f_3941(t4,t3);}

/* k4204 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4167(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4167,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4170,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[124],((C_word*)t0)[4]);}

/* k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4170,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4173,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4173(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4173,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4176,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[123],((C_word*)t0)[4]);}

/* k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4176,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4179,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_nequalp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[45]:lf[46]);
/* display */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,((C_word*)t0)[4]);}

/* k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4179(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4179,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4182,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[122],((C_word*)t0)[3]);}

/* k4180 in k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4182(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4182,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4185,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k4183 in k4180 in k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4185(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4185,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[121],((C_word*)t0)[3]);}

/* k4186 in k4183 in k4180 in k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4188(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4188,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4191,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_nequalp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[45]:lf[46]);
/* display */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,((C_word*)t0)[3]);}

/* k4189 in k4186 in k4183 in k4180 in k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4191(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4191,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4192 in k4189 in k4186 in k4183 in k4180 in k4177 in k4174 in k4171 in k4168 in k4165 in k4162 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:452: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4044,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4047,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],a[5]=((C_word*)t0)[10],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cdr(((C_word*)t0)[9]);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4063,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t5,tmp=(C_word)a,a+=7,tmp));
t7=((C_word*)t5)[1];
f_4063(t7,t2,t3,((C_word*)t0)[2],C_fix(1));}

/* doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4063(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4063,NULL,5,t0,t1,t2,t3,t4);}
t5=C_i_nullp(t2);
t6=(C_truep(t5)?t5:C_i_nullp(t3));
if(C_truep(t6)){
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4076,a[2]=t1,a[3]=((C_word*)t0)[6],a[4]=t4,a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t8=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4094,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t3,a[5]=t2,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t7,tmp=(C_word)a,a+=9,tmp);
t9=C_i_car(t3);
t10=C_i_car(t2);
/* scrutinizer.scm:462: match */
t11=((C_word*)((C_word*)t0)[2])[1];
f_2762(t11,t8,t9,t10);}}

/* k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4094(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4094,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
f_4076(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4140,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:467: pname */
t4=((C_word*)t0)[2];
f_3941(t4,t3);}

/* k4138 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4107,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[120],((C_word*)t0)[5]);}

/* k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4107,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4110,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4113,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[119],((C_word*)t0)[4]);}

/* k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[4]);}

/* k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4116,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[118],((C_word*)t0)[3]);}

/* k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4125,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4125,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4128,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k4126 in k4123 in k4120 in k4117 in k4114 in k4111 in k4108 in k4105 in k4102 in k4099 in k4092 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:463: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4074 in doloop829 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4076,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=C_a_i_plus(&a,2,((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_4063(t5,((C_word*)t0)[2],t2,t3,t4);}

/* k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4047,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4050,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
t4=((C_word*)t0)[3];
if(C_truep(t4)){
t5=*((C_word*)lf[54]+1);
t6=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t5=C_i_memq(((C_word*)t0)[2],lf[116]);
t6=(C_truep(t5)?t5:C_i_not_pair_p(((C_word*)t0)[2]));
if(C_truep(t6)){
t7=*((C_word*)lf[54]+1);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[8]);}
else{
t7=C_i_car(((C_word*)t0)[2]);
t8=C_eqp(lf[33],t7);
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4514,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:506: call/cc */
t10=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t10+1)))(3,t10,t2,t9);}
else{
/* scrutinizer.scm:514: bomb */
t9=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t2,lf[117],((C_word*)t0)[2]);}}}}

/* a4513 in k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4514(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4514,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4522,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[2]);
t5=C_i_stringp(t4);
if(C_truep(t5)){
t6=t3;
f_4522(t6,(C_truep(t5)?C_i_cdddr(((C_word*)t0)[2]):C_i_cddr(((C_word*)t0)[2])));}
else{
t6=C_i_cadr(((C_word*)t0)[2]);
t7=C_i_symbolp(t6);
t8=t3;
f_4522(t8,(C_truep(t7)?C_i_cdddr(((C_word*)t0)[2]):C_i_cddr(((C_word*)t0)[2])));}}

/* k4520 in a4513 in k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4522(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4522,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4524,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_4524(t5,((C_word*)t0)[2],t1);}

/* loop in k4520 in a4513 in k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_4524(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_4524,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
t3=C_eqp(lf[8],t2);
if(C_truep(t3)){
/* scrutinizer.scm:512: return */
t4=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,lf[8]);}
else{
t4=C_i_car(t2);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4551,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=C_i_cdr(t2);
/* scrutinizer.scm:513: loop */
t8=t5;
t9=t6;
t1=t8;
t2=t9;
goto loop;}}}

/* k4549 in loop in k4520 in a4513 in k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4551(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4551,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k4048 in k4045 in k4042 in a4036 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* a4022 in k4016 in k4265 in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_4023(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4023,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[4]);
t3=C_i_length(t2);
/* scrutinizer.scm:448: procedure-argument-types */
t4=((C_word*)((C_word*)t0)[3])[1];
f_4319(t4,t1,((C_word*)t0)[2],t3);}

/* pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3941(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3941,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3945,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3948,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3968,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3971,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t5=C_i_cdr(((C_word*)t0)[2]);
t6=t4;
f_3971(t6,C_i_pairp(t5));}
else{
t5=t4;
f_3971(t5,C_SCHEME_FALSE);}}

/* k3969 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3971(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3971,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3974,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* scrutinizer.scm:429: source-info->line */
t4=*((C_word*)lf[114]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[115],((C_word*)t0)[3]);}}

/* k3972 in k3969 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3974(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3974,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3980,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[113],((C_word*)t0)[2]);}}

/* k3978 in k3972 in k3969 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3980(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3980,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3983,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3981 in k3978 in k3972 in k3969 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3983(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3983,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3986,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[112],((C_word*)t0)[2]);}

/* k3984 in k3981 in k3978 in k3972 in k3969 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3966 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3968(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3946 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3948(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3948,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3951,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[111],((C_word*)t0)[4]);}

/* k3949 in k3946 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3951(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3951,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3954,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3964,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:434: fragment */
f_3864(t3,((C_word*)t0)[2]);}

/* k3962 in k3949 in k3946 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3964(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
t2=*((C_word*)lf[110]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3952 in k3949 in k3946 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3954,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3957,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[109],((C_word*)t0)[2]);}

/* k3955 in k3952 in k3949 in k3946 in k3943 in pname in call-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* pp-fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3918(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3918,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3926,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3928,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:422: with-output-to-string */
t5=*((C_word*)lf[108]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a3927 in pp-fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3928(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3928,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3936,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:424: fragment */
f_3864(t2,((C_word*)t0)[2]);}

/* k3934 in a3927 in pp-fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3936(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:424: pp */
t2=*((C_word*)lf[107]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3924 in pp-fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3926(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:421: string-chomp */
t2=*((C_word*)lf[106]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3864(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3864,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:413: build-expression-tree */
t4=*((C_word*)lf[105]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k3866 in fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3868,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3873,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3873(t5,((C_word*)t0)[2],t1,C_fix(0));}

/* walk in k3866 in fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3873(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3873,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t2))){
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_greater_or_equalp(t3,C_fix(3)))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[101]);}
else{
if(C_truep(C_i_listp(t2))){
t4=C_a_i_plus(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3900,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3908,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3912,a[2]=t2,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t8=C_i_length(t2);
/* scrutinizer.scm:418: min */
t9=*((C_word*)lf[104]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,C_fix(5),t8);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}}}

/* k3910 in walk in k3866 in fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3912(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:418: take */
t2=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3906 in walk in k3866 in fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* map */
t2=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3896 in walk in k3866 in fragment in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3900,3,t0,t1,t2);}
/* g751752758 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3873(t3,t1,t2,((C_word*)t0)[2]);}

/* location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3743(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3743,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3746,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[95]);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3784,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* open-output-string */
t6=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3809,a[2]=t3,a[3]=t6,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3809(t8,t1,t2);}}}

/* rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3809,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
/* scrutinizer.scm:409: location-name */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3743(t4,t1,t2);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3822,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t5=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3822(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3822,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[99],t1);}

/* k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3825(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3825,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3828,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3849,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* scrutinizer.scm:410: lname */
f_3746(t3,t4);}

/* k3847 in k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3849(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3826 in k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3828(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3828,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3831,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[98],((C_word*)t0)[4]);}

/* k3829 in k3826 in k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3831,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3834,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3841,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm:410: rec */
t5=((C_word*)((C_word*)t0)[2])[1];
f_3809(t5,t3,t4);}

/* k3839 in k3829 in k3826 in k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3841(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3832 in k3829 in k3826 in k3823 in k3820 in rec in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3782 in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3784,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3787,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[97],t1);}

/* k3785 in k3782 in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3787(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3787,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3790,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3800,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[3]);
/* scrutinizer.scm:405: lname */
f_3746(t3,t4);}

/* k3798 in k3785 in k3782 in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3788 in k3785 in k3782 in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3790(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3790,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3793,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[96],((C_word*)t0)[2]);}

/* k3791 in k3788 in k3785 in k3782 in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3793(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3746(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3746,NULL,2,t1,t2);}
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3753,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t4=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[94]);}}

/* k3751 in lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3753,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[93],t1);}

/* k3754 in k3751 in lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3756,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3759,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3769,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:401: real-name */
t4=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k3767 in k3754 in k3751 in lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3757 in k3754 in k3751 in lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3759(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3759,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3762,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3760 in k3757 in k3754 in k3751 in lname in location-name in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3762(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* report in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3729(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3729,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3737,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3741,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:397: location-name */
t6=((C_word*)((C_word*)t0)[2])[1];
f_3743(t6,t5,t2);}

/* k3739 in report in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3741(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:397: conc */
t2=*((C_word*)lf[92]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3735 in report in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3737(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:396: warning */
t2=*((C_word*)lf[91]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* single in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3648(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3648,NULL,5,t0,t1,t2,t3,t4);}
t5=C_eqp(lf[8],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[8]);}
else{
t6=C_i_length(t3);
if(C_truep(C_i_nequalp(C_fix(1),t6))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_car(t3));}
else{
if(C_truep(C_i_zerop(t6))){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3676,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3680,a[2]=t2,a[3]=t4,a[4]=t7,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t9=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3695,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3702,a[2]=t2,a[3]=t6,a[4]=t4,a[5]=t7,a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t9=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}}

/* k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3702,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3705,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[90],t1);}

/* k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3708,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3708(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3708,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3711,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[89],((C_word*)t0)[3]);}

/* k3709 in k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3711(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3711,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3714,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3712 in k3709 in k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3714(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3714,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3717,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[88],((C_word*)t0)[3]);}

/* k3715 in k3712 in k3709 in k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3717(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3717,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3720,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_nequalp(((C_word*)t0)[2],C_fix(1));
t4=(C_truep(t3)?lf[45]:lf[46]);
/* display */
t5=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t4,((C_word*)t0)[3]);}

/* k3718 in k3715 in k3712 in k3709 in k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3720,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3723,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3721 in k3718 in k3715 in k3712 in k3709 in k3706 in k3703 in k3700 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3723(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:390: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3693 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_car(((C_word*)t0)[2]));}

/* k3678 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3680,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3683,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[87],t1);}

/* k3681 in k3678 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3683(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3683,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3686,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3684 in k3681 in k3678 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3686,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3689,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[86],((C_word*)t0)[2]);}

/* k3687 in k3684 in k3681 in k3678 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3689(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3689,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3692,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3690 in k3687 in k3684 in k3681 in k3678 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:385: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3674 in single in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3676(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[17]);}

/* type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3308(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3308,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_memq(t3,lf[83]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=t3;
t7=C_eqp(t6,lf[77]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_i_memq(t2,lf[84]));}
else{
t8=C_eqp(t6,lf[33]);
if(C_truep(t8)){
if(C_truep(C_i_pairp(t2))){
t9=C_i_car(t2);
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_eqp(lf[33],t9));}
else{
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_SCHEME_FALSE);}}
else{
t9=C_eqp(t6,lf[73]);
if(C_truep(t9)){
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_i_memq(t2,lf[85]));}
else{
if(C_truep(C_i_pairp(t2))){
if(C_truep(C_i_pairp(t3))){
t10=C_i_car(t2);
t11=C_eqp(t10,lf[26]);
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3384,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t13=C_i_cdr(t2);
/* scrutinizer.scm:346: every */
t14=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t14+1)))(4,t14,t1,t12,t13);}
else{
t12=C_eqp(t10,lf[33]);
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_i_pairp(t13);
t15=(C_truep(t14)?C_i_cadr(t2):C_i_caddr(t2));
t16=C_i_cadr(t3);
t17=C_i_pairp(t16);
t18=(C_truep(t17)?C_i_cadr(t3):C_i_caddr(t3));
t19=C_i_cadr(t2);
t20=C_i_pairp(t19);
t21=(C_truep(t20)?C_i_cddr(t2):C_i_cdddr(t2));
t22=C_i_cadr(t3);
t23=C_i_pairp(t22);
t24=(C_truep(t23)?C_i_cddr(t3):C_i_cdddr(t3));
t25=C_SCHEME_UNDEFINED;
t26=(*a=C_VECTOR_TYPE|1,a[1]=t25,tmp=(C_word)a,a+=2,tmp);
t27=C_set_block_item(t26,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3415,a[2]=t26,a[3]=t24,a[4]=t21,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t28=((C_word*)t26)[1];
f_3415(t28,t1,t15,t18,C_fix(0),C_fix(0));}
else{
t13=C_SCHEME_UNDEFINED;
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,t13);}}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}
else{
t10=t1;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_SCHEME_FALSE);}}}}}}}

/* loop1 in type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3415(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3415,NULL,6,t0,t1,t2,t3,t4,t5);}
if(C_truep(C_i_nullp(t2))){
t6=C_i_nullp(t3);
t7=(C_truep(t6)?t6:C_i_greaterp(t5,C_fix(0)));
if(C_truep(t7)){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3436,a[2]=((C_word*)t0)[5],a[3]=t9,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_3436(t11,t1,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
if(C_truep(C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=C_i_car(t2);
t7=C_eqp(t6,lf[68]);
if(C_truep(t7)){
t8=C_i_cdr(t2);
/* scrutinizer.scm:367: loop1 */
t27=t1;
t28=t8;
t29=t3;
t30=C_fix(1);
t31=t5;
t1=t27;
t2=t28;
t3=t29;
t4=t30;
t5=t31;
goto loop;}
else{
t8=C_i_car(t3);
t9=C_eqp(t8,lf[68]);
if(C_truep(t9)){
t10=C_i_cdr(t3);
/* scrutinizer.scm:369: loop1 */
t27=t1;
t28=t2;
t29=t10;
t30=t4;
t31=C_fix(1);
t1=t27;
t2=t28;
t3=t29;
t4=t30;
t5=t31;
goto loop;}
else{
t10=C_i_car(t2);
t11=C_eqp(t10,lf[67]);
if(C_truep(t11)){
t12=C_i_cdr(t2);
/* scrutinizer.scm:371: loop1 */
t27=t1;
t28=t12;
t29=t3;
t30=C_fix(2);
t31=t5;
t1=t27;
t2=t28;
t3=t29;
t4=t30;
t5=t31;
goto loop;}
else{
t12=C_i_car(t3);
t13=C_eqp(t12,lf[67]);
if(C_truep(t13)){
t14=C_i_cdr(t3);
/* scrutinizer.scm:373: loop1 */
t27=t1;
t28=t2;
t29=t14;
t30=t4;
t31=C_fix(2);
t1=t27;
t2=t28;
t3=t29;
t4=t30;
t5=t31;
goto loop;}
else{
t14=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3550,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t15=C_i_car(t2);
t16=C_i_car(t3);
/* scrutinizer.scm:374: type<=? */
t17=((C_word*)((C_word*)t0)[5])[1];
f_3308(t17,t14,t15,t16);}}}}}}}

/* k3548 in loop1 in type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3550(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm:375: loop1 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3415(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop2 in loop1 in type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3436(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3436,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(lf[8],t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}
else{
if(C_truep(C_i_nullp(t3))){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_nullp(t2));}
else{
t5=C_eqp(lf[8],t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3464,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t2);
t8=C_i_car(t3);
/* scrutinizer.scm:362: type<=? */
t9=((C_word*)((C_word*)t0)[2])[1];
f_3308(t9,t6,t7,t8);}}}}

/* k3462 in loop2 in loop1 in type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3464(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm:363: loop2 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3436(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3383 in type<=? in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3384(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3384,3,t0,t1,t2);}
/* g637638 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_3308(t3,t1,t2,((C_word*)t0)[2]);}

/* match-results in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3253(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3253,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_not_pair_p(t3));}
else{
t4=C_eqp(lf[8],t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eqp(lf[8],t3);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
if(C_truep(C_i_nullp(t3))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_FALSE);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3287,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t2);
t8=C_i_car(t3);
/* scrutinizer.scm:333: match */
t9=((C_word*)((C_word*)t0)[2])[1];
f_2762(t9,t6,t7,t8);}}}}}

/* k3285 in match-results in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm:334: match-results */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3253(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3043(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3043,NULL,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[54]+1);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3049,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3108,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=((C_word*)t0)[3],a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t9=((C_word*)t7)[1];
f_3108(t9,t1,t2,t3,C_SCHEME_FALSE,C_SCHEME_FALSE);}

/* loop in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3108(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3108,NULL,6,t0,t1,t2,t3,t4,t5);}
t6=*((C_word*)lf[54]+1);
if(C_truep(C_i_nullp(t2))){
t7=t5;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=C_i_nullp(t3);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=C_i_car(t3);
t10=t1;
t11=t10;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_i_memq(t9,lf[82]));}}}
else{
if(C_truep(C_i_nullp(t3))){
t7=t4;
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=C_i_car(t2);
t9=t1;
t10=t9;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_i_memq(t8,lf[82]));}}
else{
t7=C_i_car(t2);
t8=C_eqp(lf[68],t7);
if(C_truep(t8)){
t9=C_i_cdr(t2);
/* scrutinizer.scm:319: loop */
t32=t1;
t33=t9;
t34=t3;
t35=C_SCHEME_TRUE;
t36=t5;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t9=C_i_car(t3);
t10=C_eqp(lf[68],t9);
if(C_truep(t10)){
t11=C_i_cdr(t3);
/* scrutinizer.scm:321: loop */
t32=t1;
t33=t2;
t34=t11;
t35=t4;
t36=C_SCHEME_TRUE;
t1=t32;
t2=t33;
t3=t34;
t4=t35;
t5=t36;
goto loop;}
else{
t11=C_i_car(t2);
t12=C_eqp(lf[67],t11);
if(C_truep(t12)){
t13=C_i_cdr(t2);
t14=f_2472(t13);
/* scrutinizer.scm:323: match-rest */
t15=((C_word*)t0)[3];
f_3049(t15,t1,t14,t3);}
else{
t13=C_i_car(t3);
t14=C_eqp(lf[67],t13);
if(C_truep(t14)){
t15=C_i_cdr(t3);
t16=f_2472(t15);
/* scrutinizer.scm:325: match-rest */
t17=((C_word*)t0)[3];
f_3049(t17,t1,t16,t2);}
else{
t15=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3216,a[2]=t5,a[3]=t4,a[4]=t1,a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=t2,tmp=(C_word)a,a+=8,tmp);
t16=C_i_car(t2);
t17=C_i_car(t3);
/* scrutinizer.scm:326: match */
t18=((C_word*)((C_word*)t0)[2])[1];
f_2762(t18,t15,t16,t17);}}}}}}}

/* k3214 in loop in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm:326: loop */
t4=((C_word*)((C_word*)t0)[5])[1];
f_3108(t4,((C_word*)t0)[4],t2,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_3049(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3049,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3055,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3067,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t4,t5);}

/* a3066 in match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3067(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3067,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3074,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3093,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:305: every */
t6=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,t2);}

/* a3092 in a3066 in match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3093,3,t0,t1,t2);}
/* g574575 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2762(t3,t1,((C_word*)t0)[2],t2);}

/* k3072 in a3066 in match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3074(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t2=C_i_cdr(((C_word*)t0)[6]);
t3=f_2472(t2);
/* scrutinizer.scm:306: match */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2762(t4,((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
/* scrutinizer.scm:306: match */
t2=((C_word*)((C_word*)t0)[4])[1];
f_2762(t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[8]);}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3054 in match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3061,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm:304: break */
t3=*((C_word*)lf[81]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,((C_word*)t0)[2]);}

/* a3060 in a3054 in match-rest in match-args in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_3061(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3061,3,t0,t1,t2);}
t3=*((C_word*)lf[58]+1);
/* g562563 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[67],t2);}

/* match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2771(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2771,NULL,4,t0,t1,t2,t3);}
t4=C_eqp(t2,t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eqp(t2,lf[8]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_eqp(t3,lf[8]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_eqp(t2,lf[72]);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
t8=C_eqp(t3,lf[72]);
if(C_truep(t8)){
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}
else{
t9=C_eqp(t2,lf[73]);
t10=(C_truep(t9)?C_i_memq(t3,lf[74]):C_SCHEME_FALSE);
if(C_truep(t10)){
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
t11=C_eqp(t3,lf[73]);
t12=(C_truep(t11)?C_i_memq(t2,lf[75]):C_SCHEME_FALSE);
if(C_truep(t12)){
t13=t1;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,t12);}
else{
t13=C_eqp(lf[33],t2);
if(C_truep(t13)){
if(C_truep(C_i_pairp(t3))){
t14=C_i_car(t3);
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_eqp(lf[33],t14));}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t14=C_eqp(lf[33],t3);
if(C_truep(t14)){
if(C_truep(C_i_pairp(t2))){
t15=C_i_car(t2);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_eqp(lf[33],t15));}
else{
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_SCHEME_FALSE);}}
else{
t15=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2858,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=t2,a[7]=t3,a[8]=((C_word*)t0)[5],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(t2))){
t16=C_i_car(t2);
t17=t15;
f_2858(t17,C_eqp(lf[26],t16));}
else{
t16=t15;
f_2858(t16,C_SCHEME_FALSE);}}}}}}}}}}}

/* k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2858(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2858,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2863,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm:285: any */
t4=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[7]))){
t3=C_i_car(((C_word*)t0)[7]);
t4=t2;
f_2877(t4,C_eqp(lf[26],t3));}
else{
t3=t2;
f_2877(t3,C_SCHEME_FALSE);}}}

/* k2875 in k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2877(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2877,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2882,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm:286: any */
t4=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[5],t2,t3);}
else{
t2=((C_word*)t0)[7];
if(C_truep((C_truep(C_eqp(t2,lf[76]))?C_SCHEME_TRUE:(C_truep(C_eqp(t2,lf[77]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_memq(((C_word*)t0)[6],lf[78]));}
else{
t3=((C_word*)t0)[7];
if(C_truep((C_truep(C_eqp(t3,lf[79]))?C_SCHEME_TRUE:(C_truep(C_eqp(t3,lf[77]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_memq(((C_word*)t0)[6],lf[80]));}
else{
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2914,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[7]))){
if(C_truep(C_i_pairp(((C_word*)t0)[6]))){
t5=C_i_car(((C_word*)t0)[7]);
t6=C_i_car(((C_word*)t0)[6]);
t7=t4;
f_2914(t7,C_eqp(t5,t6));}
else{
t5=t4;
f_2914(t5,C_SCHEME_FALSE);}}
else{
t5=t4;
f_2914(t5,C_SCHEME_FALSE);}}}}}

/* k2912 in k2875 in k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2914(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2914,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[7]);
t3=C_eqp(t2,lf[33]);
if(C_truep(t3)){
t4=f_2432(((C_word*)t0)[7]);
t5=(C_truep(t4)?C_i_caddr(((C_word*)t0)[7]):C_i_cadr(((C_word*)t0)[7]));
t6=f_2432(((C_word*)t0)[5]);
t7=(C_truep(t6)?C_i_caddr(((C_word*)t0)[5]):C_i_cadr(((C_word*)t0)[5]));
t8=f_2432(((C_word*)t0)[7]);
t9=(C_truep(t8)?C_i_cdddr(((C_word*)t0)[7]):C_i_cddr(((C_word*)t0)[7]));
t10=f_2432(((C_word*)t0)[5]);
t11=(C_truep(t10)?C_i_cdddr(((C_word*)t0)[5]):C_i_cddr(((C_word*)t0)[5]));
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2941,a[2]=t11,a[3]=t9,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:296: match-args */
t13=((C_word*)((C_word*)t0)[2])[1];
f_3043(t13,t12,t5,t7);}
else{
t4=C_eqp(t2,lf[39]);
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?C_i_equalp(((C_word*)t0)[7],((C_word*)t0)[5]):C_SCHEME_FALSE));}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2939 in k2912 in k2875 in k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2941(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* scrutinizer.scm:297: match-results */
t2=((C_word*)((C_word*)t0)[5])[1];
f_3253(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a2881 in k2875 in k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2882(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2882,3,t0,t1,t2);}
/* g531532 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2762(t3,t1,((C_word*)t0)[2],t2);}

/* a2862 in k2856 in match1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2863(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2863,3,t0,t1,t2);}
/* g523524 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_2762(t3,t1,t2,((C_word*)t0)[2]);}

/* match in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2762(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2762,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2766,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:272: match1 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2771(t5,t4,t2,t3);}

/* k2764 in match in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* merge-result-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2696(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2696,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t3;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t2);}
else{
t4=C_i_not_pair_p(t2);
t5=(C_truep(t4)?t4:C_i_not_pair_p(t3));
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[8]);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2725,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t7=C_i_car(t2);
t8=C_i_car(t3);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t7,t9);
t11=C_a_i_cons(&a,2,lf[26],t10);
/* scrutinizer.scm:269: simplify */
t12=((C_word*)((C_word*)t0)[2])[1];
f_1955(t12,t6,t11);}}}}

/* k2723 in merge-result-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2725(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2725,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2729,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
t4=C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm:270: merge-result-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2696(t5,t2,t3,t4);}

/* k2727 in k2723 in merge-result-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2729,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2494(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2494,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_END_OF_LIST);}
else{
t4=C_i_car(t3);
if(C_truep((C_truep(C_eqp(t4,lf[67]))?C_SCHEME_TRUE:(C_truep(C_eqp(t4,lf[68]))?C_SCHEME_TRUE:C_SCHEME_FALSE)))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[69]);}}}
else{
t4=C_i_car(t2);
t5=C_eqp(lf[67],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2529,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t3))){
t7=C_i_car(t3);
t8=t6;
f_2529(t8,C_eqp(lf[67],t7));}
else{
t7=t6;
f_2529(t7,C_SCHEME_FALSE);}}
else{
t6=C_i_car(t2);
t7=C_eqp(lf[68],t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2590,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t3))){
t9=C_i_car(t3);
t10=t8;
f_2590(t10,C_eqp(lf[68],t9));}
else{
t9=t8;
f_2590(t9,C_SCHEME_FALSE);}}
else{
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2654,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=C_i_car(t2);
t10=C_i_car(t3);
t11=C_a_i_cons(&a,2,t10,C_SCHEME_END_OF_LIST);
t12=C_a_i_cons(&a,2,t9,t11);
t13=C_a_i_cons(&a,2,lf[26],t12);
/* scrutinizer.scm:263: simplify */
t14=((C_word*)((C_word*)t0)[3])[1];
f_1955(t14,t8,t13);}}}}

/* k2652 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2658,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[4]);
t4=C_i_cdr(((C_word*)t0)[3]);
/* scrutinizer.scm:264: merge-argument-types */
t5=((C_word*)((C_word*)t0)[2])[1];
f_2494(t5,t2,t3,t4);}

/* k2656 in k2652 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2658(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2658,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k2588 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2590(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2590,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
t4=C_i_cadr(((C_word*)t0)[4]);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t3,t5);
t7=C_a_i_cons(&a,2,lf[26],t6);
/* scrutinizer.scm:260: simplify */
t8=((C_word*)((C_word*)t0)[2])[1];
f_1955(t8,t2,t7);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[71]);}}

/* k2599 in k2588 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2601,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2605,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2609,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_i_cddr(((C_word*)t0)[4]);
t5=C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm:261: merge-argument-types */
t6=((C_word*)((C_word*)t0)[2])[1];
f_2494(t6,t3,t4,t5);}

/* k2607 in k2599 in k2588 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k2603 in k2599 in k2588 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2605,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[68],t2));}

/* k2527 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2529(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2529,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2540,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cdr(((C_word*)t0)[5]);
t4=f_2472(t3);
t5=C_i_cdr(((C_word*)t0)[3]);
t6=f_2472(t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t4,t7);
t9=C_a_i_cons(&a,2,lf[26],t8);
/* scrutinizer.scm:253: simplify */
t10=((C_word*)((C_word*)t0)[2])[1];
f_1955(t10,t2,t9);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[70]);}}

/* k2538 in k2527 in merge-argument-types in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2540(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2540,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[67],t2));}

/* rest-type in ##compiler#scrutinize in k1247 in k1244 */
static C_word C_fcall f_2472(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_stack_check;
if(C_truep(C_i_nullp(t1))){
return(lf[8]);}
else{
t2=C_i_car(t1);
t3=C_eqp(lf[66],t2);
return((C_truep(t3)?lf[8]:C_i_car(t1)));}}

/* named? in ##compiler#scrutinize in k1247 in k1244 */
static C_word C_fcall f_2432(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_stack_check;
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_eqp(lf[33],t2);
if(C_truep(t3)){
t4=C_i_cadr(t1);
t5=C_i_nullp(t4);
if(C_truep(t5)){
return(C_i_not(t5));}
else{
t6=C_i_cadr(t1);
t7=C_i_pairp(t6);
return(C_i_not(t7));}}
else{
return(C_SCHEME_FALSE);}}
else{
return(C_SCHEME_FALSE);}}

/* simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1964(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1964,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1970,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* scrutinizer.scm:179: call/cc */
t4=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1970,3,t0,t1,t2);}
if(C_truep(C_i_pairp(((C_word*)t0)[8]))){
t3=C_i_car(((C_word*)t0)[8]);
t4=C_eqp(t3,lf[26]);
if(C_truep(t4)){
t5=C_i_length(((C_word*)t0)[8]);
if(C_truep(C_i_nequalp(C_fix(2),t5))){
t6=C_i_cadr(((C_word*)t0)[8]);
/* scrutinizer.scm:184: simplify */
t7=((C_word*)((C_word*)t0)[7])[1];
f_1955(t7,t1,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_2005,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=((C_word*)t0)[6],a[9]=t1,tmp=(C_word)a,a+=10,tmp);
t7=C_i_cdr(((C_word*)t0)[8]);
/* scrutinizer.scm:185: every */
t8=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,((C_word*)((C_word*)t0)[2])[1],t7);}}
else{
t5=C_eqp(t3,lf[33]);
if(C_truep(t5)){
t6=f_2432(((C_word*)t0)[8]);
t7=(C_truep(t6)?C_i_cadr(((C_word*)t0)[8]):C_SCHEME_FALSE);
t8=(C_truep(t7)?C_i_cdddr(((C_word*)t0)[8]):C_i_cddr(((C_word*)t0)[8]));
t9=(C_truep(t7)?C_a_i_list(&a,1,t7):C_SCHEME_END_OF_LIST);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_FALSE;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2370,a[2]=((C_word*)t0)[7],a[3]=t8,a[4]=t9,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t15=(C_truep(t7)?C_i_caddr(((C_word*)t0)[8]):C_i_cadr(((C_word*)t0)[8]));
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2376,a[2]=((C_word*)t0)[7],a[3]=t11,a[4]=t17,a[5]=t13,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_2376(t19,t14,t15);}
else{
t6=((C_word*)t0)[8];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}}
else{
t3=((C_word*)t0)[8];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop386 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2376(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2376,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2405,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g402403 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1955(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2403 in loop386 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2405,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop386399 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2376(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop386399 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2376(t6,((C_word*)t0)[3],t5);}}

/* k2368 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2370,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_eqp(lf[8],((C_word*)t0)[3]);
if(C_truep(t4)){
/* scrutinizer.scm:228: append */
t5=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t5+1)))(6,t5,((C_word*)t0)[5],lf[64],((C_word*)t0)[4],t2,lf[8]);}
else{
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2333,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t10,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_2333(t12,t3,((C_word*)t0)[3]);}}

/* loop409 in k2368 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2333(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2333,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2362,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g425426 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1955(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2360 in loop409 in k2368 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2362(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2362,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop409422 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2333(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop409422 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2333(t6,((C_word*)t0)[3],t5);}}

/* k2323 in k2368 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2325(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:228: append */
t2=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[64],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2005(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2005,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2011,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[9],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2108,tmp=(C_word)a,a+=2,tmp);
t4=C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm:186: any */
t5=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2119,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[9],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2251,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm:204: append-map */
t5=*((C_word*)lf[63]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t2,t3,t4);}}

/* a2250 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2251(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2251,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2255,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:206: simplify */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1955(t4,t3,t2);}

/* k2253 in a2250 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2255(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2255,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2261,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t1))){
t3=C_i_car(t1);
t4=t2;
f_2261(t4,C_eqp(lf[26],t3));}
else{
t3=t2;
f_2261(t3,C_SCHEME_FALSE);}}

/* k2259 in k2253 in a2250 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_cdr(((C_word*)t0)[3]));}
else{
t2=C_eqp(((C_word*)t0)[3],lf[17]);
if(C_truep(t2)){
/* scrutinizer.scm:210: return */
t3=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],lf[17]);}
else{
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_list(&a,1,((C_word*)t0)[3]));}}}

/* k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2161,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_2161(t6,t2,t1,C_SCHEME_END_OF_LIST);}

/* loop in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2161(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2161,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
/* scrutinizer.scm:214: reverse */
t4=*((C_word*)lf[62]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t4=C_i_car(t2);
t5=C_eqp(lf[8],t4);
if(C_truep(t5)){
/* scrutinizer.scm:215: return */
t6=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,lf[8]);}
else{
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2186,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2233,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t2);
/* scrutinizer.scm:216: any */
t9=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,t7,t8);}}}

/* a2232 in loop in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2233(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2233,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[3]);
/* g356357 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3308(t4,t1,t3,t2);}

/* k2184 in loop in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2186,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[6]);
/* scrutinizer.scm:217: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_2161(t3,((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2199,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:218: any */
t4=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}}

/* a2222 in k2184 in loop in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2223(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2223,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[3]);
/* g363364 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3308(t4,t1,t3,t2);}

/* k2197 in k2184 in loop in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2199,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
/* scrutinizer.scm:219: loop */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2161(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_car(((C_word*)t0)[5]);
t4=C_a_i_cons(&a,2,t3,((C_word*)t0)[2]);
/* scrutinizer.scm:220: loop */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2161(t5,((C_word*)t0)[3],t2,t4);}}

/* k2120 in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
t2=C_i_cdr(((C_word*)t0)[4]);
if(C_truep(C_i_equalp(t1,t2))){
t3=((C_word*)t0)[4];
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[54]+1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2142,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2149,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2151,tmp=(C_word)a,a+=2,tmp);
/* scrutinizer.scm:224: any */
t7=*((C_word*)lf[59]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,t1);}}

/* a2150 in k2120 in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2151(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2151,3,t0,t1,t2);}
t3=*((C_word*)lf[58]+1);
/* g378379 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,lf[8]);}

/* k2147 in k2120 in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* ##sys#append */
t2=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],lf[61],C_SCHEME_END_OF_LIST);}
else{
t2=((C_word*)t0)[2];
/* ##sys#append */
t3=*((C_word*)lf[60]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,C_SCHEME_END_OF_LIST);}}

/* k2140 in k2120 in k2117 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2142(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2142,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[26],t1);
/* scrutinizer.scm:224: simplify */
t3=((C_word*)((C_word*)t0)[3])[1];
f_1955(t3,((C_word*)t0)[2],t2);}

/* a2107 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2108(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2108,3,t0,t1,t2);}
t3=*((C_word*)lf[58]+1);
/* g323324 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[33],t2);}

/* k2009 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2011,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[33]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2016,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* scrutinizer.scm:188: reduce */
t4=*((C_word*)lf[57]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[6],t2,C_SCHEME_FALSE,t3);}}

/* a2015 in k2009 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2016(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2016,4,t0,t1,t2,t3);}
t4=f_2432(t2);
t5=(C_truep(t4)?C_i_cadr(t2):C_SCHEME_FALSE);
t6=(C_truep(t5)?C_i_caddr(t2):C_i_cadr(t2));
t7=(C_truep(t5)?C_i_cdddr(t2):C_i_cddr(t2));
t8=f_2432(t3);
t9=(C_truep(t8)?C_i_cadr(t3):C_SCHEME_FALSE);
t10=(C_truep(t9)?C_i_caddr(t3):C_i_cadr(t3));
t11=(C_truep(t9)?C_i_cdddr(t3):C_i_cddr(t3));
t12=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2042,a[2]=t10,a[3]=t6,a[4]=((C_word*)t0)[2],a[5]=t11,a[6]=t7,a[7]=((C_word*)t0)[3],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
if(C_truep(t9)){
t13=C_eqp(t5,t9);
t14=t12;
f_2042(t14,(C_truep(t13)?C_a_i_list(&a,1,t5):C_SCHEME_END_OF_LIST));}
else{
t13=t12;
f_2042(t13,C_SCHEME_END_OF_LIST);}}
else{
t13=t12;
f_2042(t13,C_SCHEME_END_OF_LIST);}}

/* k2040 in a2015 in k2009 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_2042(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2042,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2054,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=t1,a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* scrutinizer.scm:199: merge-argument-types */
t3=((C_word*)((C_word*)t0)[4])[1];
f_2494(t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2052 in k2040 in a2015 in k2009 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2054(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2054,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2050,a[2]=t2,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* scrutinizer.scm:200: merge-result-types */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2696(t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2048 in k2052 in k2040 in a2015 in k2009 in k2003 in a1969 in simplify1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_2050(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:196: append */
t2=*((C_word*)lf[55]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[56],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* simplify in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1955,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1959,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:175: simplify1 */
t4=((C_word*)((C_word*)t0)[2])[1];
f_1964(t4,t3,t2);}

/* k1957 in simplify in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=*((C_word*)lf[54]+1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1868(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1868,NULL,3,t0,t1,t2);}
t3=C_eqp(lf[8],t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,lf[50]);}
else{
t4=C_i_length(t2);
t5=*((C_word*)lf[44]+1);
t6=C_i_nequalp(t5,C_fix(1));
t7=(C_truep(t6)?lf[45]:lf[46]);
if(C_truep(C_i_zerop(t4))){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,lf[51]);}
else{
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1890,a[2]=t4,a[3]=t7,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t9=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,t8);}}}

/* k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1890(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1890,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1893,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1896,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[53],((C_word*)t0)[5]);}

/* k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1896(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1896,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1899,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1899(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1899,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1902,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[52],((C_word*)t0)[5]);}

/* k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1902(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1902,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1905,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1908,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1908(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1908,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1911,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1918,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1920,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1920(t11,t7,((C_word*)t0)[2]);}

/* loop276 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1920(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1920,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1949,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g292293 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1607(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1947 in loop276 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1949,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop276289 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1920(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop276289 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1920(t6,((C_word*)t0)[3],t5);}}

/* k1916 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1909 in k1906 in k1903 in k1900 in k1897 in k1894 in k1891 in k1888 in result-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1787(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1787,NULL,3,t0,t1,t2);}
t3=C_i_length(t2);
t4=*((C_word*)lf[44]+1);
t5=C_i_nequalp(t4,C_fix(1));
t6=(C_truep(t5)?lf[45]:lf[46]);
if(C_truep(C_i_zerop(t3))){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,lf[47]);}
else{
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1803,a[2]=t3,a[3]=t6,a[4]=t2,a[5]=((C_word*)t0)[2],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t8=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1803(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1803,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1806,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1806(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1806,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1809,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[49],((C_word*)t0)[5]);}

/* k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1812,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1815,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[48],((C_word*)t0)[5]);}

/* k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1815(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1815,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1818,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1818(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1818,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1821,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[4]);}

/* k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1821,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1824,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1831,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1833,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_1833(t11,t7,((C_word*)t0)[2]);}

/* loop238 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1833(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1833,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1862,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g254255 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1607(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1860 in loop238 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1862(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1862,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop238251 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1833(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop238251 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1833(t6,((C_word*)t0)[3],t5);}}

/* k1829 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1831(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1822 in k1819 in k1816 in k1813 in k1810 in k1807 in k1804 in k1801 in argument-string in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1824(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1607,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_eqp(t3,lf[8]);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[29]);}
else{
t5=C_eqp(t3,lf[30]);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,lf[31]);}
else{
if(C_truep(C_i_symbolp(t2))){
/* scrutinizer.scm:137: symbol->string */
t6=*((C_word*)lf[32]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t1,t2);}
else{
if(C_truep(C_i_pairp(t2))){
t6=C_i_car(t2);
t7=C_eqp(t6,lf[33]);
if(C_truep(t7)){
t8=C_i_cadr(t2);
t9=C_i_stringp(t8);
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t9)){
t11=t10;
f_1653(t11,t9);}
else{
t11=C_i_cadr(t2);
t12=t10;
f_1653(t12,C_i_symbolp(t11));}}
else{
t8=C_eqp(t6,lf[26]);
if(C_truep(t8)){
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1718,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t14=C_i_cdr(t2);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1724,a[2]=((C_word*)t0)[2],a[3]=t10,a[4]=t16,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_1724(t18,t13,t14);}
else{
t9=C_eqp(t6,lf[39]);
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1766,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t11=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,t10);}
else{
/* scrutinizer.scm:152: bomb */
t10=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t1,lf[42],t2);}}}}
else{
/* scrutinizer.scm:153: bomb */
t6=*((C_word*)lf[41]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t1,lf[43],t2);}}}}}

/* k1764 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1766(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1766,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1769,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[40],t1);}

/* k1767 in k1764 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1769(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1769,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1772,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k1770 in k1767 in k1764 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop200 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1724(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1724,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1753,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g216217 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1607(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1751 in loop200 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1753,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop200213 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1724(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop200213 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1724(t6,((C_word*)t0)[3],t5);}}

/* k1716 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1718(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:147: string-intersperse */
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,lf[38]);}

/* k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1653,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cadr(((C_word*)t0)[5]);
/* scrutinizer.scm:142: ->string */
t3=*((C_word*)lf[34]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1663,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t3=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1663,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1666,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[36],t1);}

/* k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1666(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1666,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1669,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1690,a[2]=((C_word*)t0)[5],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cadr(((C_word*)t0)[4]);
/* scrutinizer.scm:144: argument-string */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1787(t5,t3,t4);}

/* k1688 in k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1690(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1667 in k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1669,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1672,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[35],((C_word*)t0)[4]);}

/* k1670 in k1667 in k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1672,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1675,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1682,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_cddr(((C_word*)t0)[3]);
/* scrutinizer.scm:145: result-string */
t5=((C_word*)((C_word*)t0)[2])[1];
f_1868(t5,t3,t4);}

/* k1680 in k1670 in k1667 in k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1682(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1673 in k1670 in k1667 in k1664 in k1661 in k1651 in typename in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1675(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1566(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1566,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1570,a[2]=t2,a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* scrutinizer.scm:123: always-true1 */
t6=((C_word*)((C_word*)t0)[2])[1];
f_1534(3,t6,t5,t2);}

/* k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1570,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1573,a[2]=t1,a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1580,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t4=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}}

/* k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1580(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1580,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1583,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[28],t1);}

/* k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1583(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1583,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1586,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[5]);}

/* k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1586,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1589,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[27],((C_word*)t0)[4]);}

/* k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1592,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k1590 in k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1592,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[4]);}

/* k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1598,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1605,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:130: pp-fragment */
t4=((C_word*)((C_word*)t0)[3])[1];
f_3918(t4,t3,((C_word*)t0)[2]);}

/* k1603 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1605(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1596 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1598,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1601,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1599 in k1596 in k1593 in k1590 in k1587 in k1584 in k1581 in k1578 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:125: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1571 in k1568 in always-true in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* always-true1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1534(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1534,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1541,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(t2))){
t4=C_i_car(t2);
t5=t3;
f_1541(t5,C_eqp(lf[26],t4));}
else{
t4=t3;
f_1541(t4,C_SCHEME_FALSE);}}

/* k1539 in always-true1 in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1541(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[4]);
/* scrutinizer.scm:119: every */
t3=*((C_word*)lf[24]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1],t2);}
else{
t2=C_i_memq(((C_word*)t0)[4],lf[25]);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_SCHEME_FALSE:C_SCHEME_TRUE));}}

/* variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1461(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1461,NULL,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_1468,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],a[6]=t3,a[7]=t2,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1525,a[2]=t2,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:104: get */
t7=*((C_word*)lf[22]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t6,((C_word*)t0)[3],t2,lf[23]);}

/* k1523 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1525,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1532,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* scrutinizer.scm:105: ##sys#get */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],lf[21]);}
else{
t2=((C_word*)t0)[3];
f_1468(t2,C_SCHEME_FALSE);}}

/* k1530 in k1523 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1468(t2,C_i_not(t1));}

/* k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1468(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1468,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[8]);}
else{
t2=C_i_assq(((C_word*)t0)[7],((C_word*)t0)[6]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1475,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* g136137 */
t4=t3;
f_1475(t4,((C_word*)t0)[8],t2);}
else{
/* scrutinizer.scm:116: global-result */
t3=((C_word*)((C_word*)t0)[2])[1];
f_1374(t3,((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[4]);}}}

/* g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1475(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1475,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=C_eqp(lf[17],t3);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1485,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1489,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t5,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t7=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t5=C_i_cdr(t2);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_list(&a,1,t5));}}

/* k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1489(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1489,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[20],t1);}

/* k1490 in k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1492,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1495,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1505,a[2]=((C_word*)t0)[4],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* scrutinizer.scm:113: real-name */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1503 in k1490 in k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1505(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k1493 in k1490 in k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1495(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1495,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1498,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[18],((C_word*)t0)[2]);}

/* k1496 in k1493 in k1490 in k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1498(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1498,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1501,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1499 in k1496 in k1493 in k1490 in k1487 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:110: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1483 in g136 in k1466 in variable-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[8]);}

/* global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1374(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1374,NULL,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1378,a[2]=t1,a[3]=t2,a[4]=t3,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* scrutinizer.scm:83: ##sys#get */
t5=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,t2,lf[16]);}

/* k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1378(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1378,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1382,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* g100101 */
t3=t2;
f_1382(t3,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[8]);}}

/* g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1382(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1382,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,lf[7]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1392,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
t6=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1414,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_pairp(t2))){
t5=C_i_car(t2);
t6=t4;
f_1414(t6,C_eqp(t5,lf[7]));}
else{
t5=t4;
f_1414(t5,C_SCHEME_FALSE);}}}

/* k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_fcall f_1414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1414,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1417,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1421,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
t4=*((C_word*)lf[11]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,1,((C_word*)t0)[3]));}}

/* k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1421(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1421,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_1424,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[14],t1);}

/* k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1424(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1424,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1427,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k1425 in k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1427(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1427,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1430,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[13],((C_word*)t0)[3]);}

/* k1428 in k1425 in k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1430(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1430,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1433,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* display */
t4=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[3]);}

/* k1431 in k1428 in k1425 in k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1433(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1433,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1436,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[12],((C_word*)t0)[2]);}

/* k1434 in k1431 in k1428 in k1425 in k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1436(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1436,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1439,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1437 in k1434 in k1431 in k1428 in k1425 in k1422 in k1419 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1439(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:95: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1415 in k1412 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[8]);}

/* k1394 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1396,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1399,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[10],t1);}

/* k1397 in k1394 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1402,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
t3=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k1400 in k1397 in k1394 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1402,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1405,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k1403 in k1400 in k1397 in k1394 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1405,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1408,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
t3=*((C_word*)lf[9]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k1406 in k1403 in k1400 in k1397 in k1394 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1408(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* scrutinizer.scm:90: report */
t2=((C_word*)((C_word*)t0)[4])[1];
f_3729(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k1390 in g100 in k1376 in global-result in ##compiler#scrutinize in k1247 in k1244 */
static void C_ccall f_1392(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[8]);}

/* d in k1247 in k1244 */
static void C_ccall f_1251(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+6)){
C_save_and_reclaim((void*)tr3r,(void*)f_1251r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_1251r(t0,t1,t2,t3);}}

static void C_ccall f_1251r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(6);
if(C_truep(C_fudge(C_fix(13)))){
t4=*((C_word*)lf[1]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1261,a[2]=t3,a[3]=t2,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* display */
t6=*((C_word*)lf[4]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,lf[5],t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k1259 in d in k1247 in k1244 */
static void C_ccall f_1261(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1261,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1264,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
C_apply(6,0,t2,*((C_word*)lf[3]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1262 in k1259 in d in k1247 in k1244 */
static void C_ccall f_1264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[2]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[394] = {
{"toplevel:scrutinizer_scm",(void*)C_scrutinizer_toplevel},
{"f_1246:scrutinizer_scm",(void*)f_1246},
{"f_1249:scrutinizer_scm",(void*)f_1249},
{"f_5430:scrutinizer_scm",(void*)f_5430},
{"f_5434:scrutinizer_scm",(void*)f_5434},
{"f_5547:scrutinizer_scm",(void*)f_5547},
{"f_5437:scrutinizer_scm",(void*)f_5437},
{"f_5534:scrutinizer_scm",(void*)f_5534},
{"f_5537:scrutinizer_scm",(void*)f_5537},
{"f_5540:scrutinizer_scm",(void*)f_5540},
{"f_5443:scrutinizer_scm",(void*)f_5443},
{"f_5450:scrutinizer_scm",(void*)f_5450},
{"f_5452:scrutinizer_scm",(void*)f_5452},
{"f_5467:scrutinizer_scm",(void*)f_5467},
{"f_5479:scrutinizer_scm",(void*)f_5479},
{"f_5486:scrutinizer_scm",(void*)f_5486},
{"f_5489:scrutinizer_scm",(void*)f_5489},
{"f_5492:scrutinizer_scm",(void*)f_5492},
{"f_5495:scrutinizer_scm",(void*)f_5495},
{"f_5498:scrutinizer_scm",(void*)f_5498},
{"f_5501:scrutinizer_scm",(void*)f_5501},
{"f_5504:scrutinizer_scm",(void*)f_5504},
{"f_5507:scrutinizer_scm",(void*)f_5507},
{"f_5510:scrutinizer_scm",(void*)f_5510},
{"f_5473:scrutinizer_scm",(void*)f_5473},
{"f_5520:scrutinizer_scm",(void*)f_5520},
{"f_1269:scrutinizer_scm",(void*)f_1269},
{"f_4622:scrutinizer_scm",(void*)f_4622},
{"f_5374:scrutinizer_scm",(void*)f_5374},
{"f_5389:scrutinizer_scm",(void*)f_5389},
{"f_5382:scrutinizer_scm",(void*)f_5382},
{"f_5372:scrutinizer_scm",(void*)f_5372},
{"f_5240:scrutinizer_scm",(void*)f_5240},
{"f_5254:scrutinizer_scm",(void*)f_5254},
{"f_5256:scrutinizer_scm",(void*)f_5256},
{"f_5339:scrutinizer_scm",(void*)f_5339},
{"f_5269:scrutinizer_scm",(void*)f_5269},
{"f_5287:scrutinizer_scm",(void*)f_5287},
{"f_5295:scrutinizer_scm",(void*)f_5295},
{"f_5298:scrutinizer_scm",(void*)f_5298},
{"f_5327:scrutinizer_scm",(void*)f_5327},
{"f_5330:scrutinizer_scm",(void*)f_5330},
{"f_5333:scrutinizer_scm",(void*)f_5333},
{"f_5321:scrutinizer_scm",(void*)f_5321},
{"f_5301:scrutinizer_scm",(void*)f_5301},
{"f_5304:scrutinizer_scm",(void*)f_5304},
{"f_5307:scrutinizer_scm",(void*)f_5307},
{"f_5310:scrutinizer_scm",(void*)f_5310},
{"f_5313:scrutinizer_scm",(void*)f_5313},
{"f_5317:scrutinizer_scm",(void*)f_5317},
{"f_5243:scrutinizer_scm",(void*)f_5243},
{"f_5116:scrutinizer_scm",(void*)f_5116},
{"f_5202:scrutinizer_scm",(void*)f_5202},
{"f_5205:scrutinizer_scm",(void*)f_5205},
{"f_5208:scrutinizer_scm",(void*)f_5208},
{"f_5211:scrutinizer_scm",(void*)f_5211},
{"f_5214:scrutinizer_scm",(void*)f_5214},
{"f_5218:scrutinizer_scm",(void*)f_5218},
{"f_5119:scrutinizer_scm",(void*)f_5119},
{"f_5194:scrutinizer_scm",(void*)f_5194},
{"f_5144:scrutinizer_scm",(void*)f_5144},
{"f_5151:scrutinizer_scm",(void*)f_5151},
{"f_5154:scrutinizer_scm",(void*)f_5154},
{"f_5157:scrutinizer_scm",(void*)f_5157},
{"f_5160:scrutinizer_scm",(void*)f_5160},
{"f_5163:scrutinizer_scm",(void*)f_5163},
{"f_5166:scrutinizer_scm",(void*)f_5166},
{"f_5169:scrutinizer_scm",(void*)f_5169},
{"f_5172:scrutinizer_scm",(void*)f_5172},
{"f_5175:scrutinizer_scm",(void*)f_5175},
{"f_5125:scrutinizer_scm",(void*)f_5125},
{"f_5000:scrutinizer_scm",(void*)f_5000},
{"f_5094:scrutinizer_scm",(void*)f_5094},
{"f_5007:scrutinizer_scm",(void*)f_5007},
{"f_5047:scrutinizer_scm",(void*)f_5047},
{"f_5049:scrutinizer_scm",(void*)f_5049},
{"f_5043:scrutinizer_scm",(void*)f_5043},
{"f_5010:scrutinizer_scm",(void*)f_5010},
{"f_5032:scrutinizer_scm",(void*)f_5032},
{"f_5036:scrutinizer_scm",(void*)f_5036},
{"f_5013:scrutinizer_scm",(void*)f_5013},
{"f_5020:scrutinizer_scm",(void*)f_5020},
{"f_4906:scrutinizer_scm",(void*)f_4906},
{"f_4950:scrutinizer_scm",(void*)f_4950},
{"f_4953:scrutinizer_scm",(void*)f_4953},
{"f_4978:scrutinizer_scm",(void*)f_4978},
{"f_4956:scrutinizer_scm",(void*)f_4956},
{"f_4959:scrutinizer_scm",(void*)f_4959},
{"f_4962:scrutinizer_scm",(void*)f_4962},
{"f_4966:scrutinizer_scm",(void*)f_4966},
{"f_4927:scrutinizer_scm",(void*)f_4927},
{"f_4942:scrutinizer_scm",(void*)f_4942},
{"f_4924:scrutinizer_scm",(void*)f_4924},
{"f_4891:scrutinizer_scm",(void*)f_4891},
{"f_4717:scrutinizer_scm",(void*)f_4717},
{"f_4720:scrutinizer_scm",(void*)f_4720},
{"f_4723:scrutinizer_scm",(void*)f_4723},
{"f_4726:scrutinizer_scm",(void*)f_4726},
{"f_4732:scrutinizer_scm",(void*)f_4732},
{"f_4865:scrutinizer_scm",(void*)f_4865},
{"f_4861:scrutinizer_scm",(void*)f_4861},
{"f_4807:scrutinizer_scm",(void*)f_4807},
{"f_4814:scrutinizer_scm",(void*)f_4814},
{"f_4817:scrutinizer_scm",(void*)f_4817},
{"f_4820:scrutinizer_scm",(void*)f_4820},
{"f_4823:scrutinizer_scm",(void*)f_4823},
{"f_4833:scrutinizer_scm",(void*)f_4833},
{"f_4826:scrutinizer_scm",(void*)f_4826},
{"f_4829:scrutinizer_scm",(void*)f_4829},
{"f_4735:scrutinizer_scm",(void*)f_4735},
{"f_4740:scrutinizer_scm",(void*)f_4740},
{"f_4790:scrutinizer_scm",(void*)f_4790},
{"f_4753:scrutinizer_scm",(void*)f_4753},
{"f_4771:scrutinizer_scm",(void*)f_4771},
{"f_4653:scrutinizer_scm",(void*)f_4653},
{"f_4590:scrutinizer_scm",(void*)f_4590},
{"f_4319:scrutinizer_scm",(void*)f_4319},
{"f_4329:scrutinizer_scm",(void*)f_4329},
{"f_4352:scrutinizer_scm",(void*)f_4352},
{"f_4354:scrutinizer_scm",(void*)f_4354},
{"f_4426:scrutinizer_scm",(void*)f_4426},
{"f_4384:scrutinizer_scm",(void*)f_4384},
{"f_4345:scrutinizer_scm",(void*)f_4345},
{"f_4336:scrutinizer_scm",(void*)f_4336},
{"f_4277:scrutinizer_scm",(void*)f_4277},
{"f_3938:scrutinizer_scm",(void*)f_3938},
{"f_4267:scrutinizer_scm",(void*)f_4267},
{"f_4259:scrutinizer_scm",(void*)f_4259},
{"f_4255:scrutinizer_scm",(void*)f_4255},
{"f_4213:scrutinizer_scm",(void*)f_4213},
{"f_4220:scrutinizer_scm",(void*)f_4220},
{"f_4245:scrutinizer_scm",(void*)f_4245},
{"f_4223:scrutinizer_scm",(void*)f_4223},
{"f_4226:scrutinizer_scm",(void*)f_4226},
{"f_4229:scrutinizer_scm",(void*)f_4229},
{"f_4232:scrutinizer_scm",(void*)f_4232},
{"f_4235:scrutinizer_scm",(void*)f_4235},
{"f_4238:scrutinizer_scm",(void*)f_4238},
{"f_4241:scrutinizer_scm",(void*)f_4241},
{"f_4018:scrutinizer_scm",(void*)f_4018},
{"f_4037:scrutinizer_scm",(void*)f_4037},
{"f_4164:scrutinizer_scm",(void*)f_4164},
{"f_4206:scrutinizer_scm",(void*)f_4206},
{"f_4167:scrutinizer_scm",(void*)f_4167},
{"f_4170:scrutinizer_scm",(void*)f_4170},
{"f_4173:scrutinizer_scm",(void*)f_4173},
{"f_4176:scrutinizer_scm",(void*)f_4176},
{"f_4179:scrutinizer_scm",(void*)f_4179},
{"f_4182:scrutinizer_scm",(void*)f_4182},
{"f_4185:scrutinizer_scm",(void*)f_4185},
{"f_4188:scrutinizer_scm",(void*)f_4188},
{"f_4191:scrutinizer_scm",(void*)f_4191},
{"f_4194:scrutinizer_scm",(void*)f_4194},
{"f_4044:scrutinizer_scm",(void*)f_4044},
{"f_4063:scrutinizer_scm",(void*)f_4063},
{"f_4094:scrutinizer_scm",(void*)f_4094},
{"f_4101:scrutinizer_scm",(void*)f_4101},
{"f_4140:scrutinizer_scm",(void*)f_4140},
{"f_4104:scrutinizer_scm",(void*)f_4104},
{"f_4107:scrutinizer_scm",(void*)f_4107},
{"f_4110:scrutinizer_scm",(void*)f_4110},
{"f_4113:scrutinizer_scm",(void*)f_4113},
{"f_4116:scrutinizer_scm",(void*)f_4116},
{"f_4119:scrutinizer_scm",(void*)f_4119},
{"f_4122:scrutinizer_scm",(void*)f_4122},
{"f_4125:scrutinizer_scm",(void*)f_4125},
{"f_4128:scrutinizer_scm",(void*)f_4128},
{"f_4076:scrutinizer_scm",(void*)f_4076},
{"f_4047:scrutinizer_scm",(void*)f_4047},
{"f_4514:scrutinizer_scm",(void*)f_4514},
{"f_4522:scrutinizer_scm",(void*)f_4522},
{"f_4524:scrutinizer_scm",(void*)f_4524},
{"f_4551:scrutinizer_scm",(void*)f_4551},
{"f_4050:scrutinizer_scm",(void*)f_4050},
{"f_4023:scrutinizer_scm",(void*)f_4023},
{"f_3941:scrutinizer_scm",(void*)f_3941},
{"f_3945:scrutinizer_scm",(void*)f_3945},
{"f_3971:scrutinizer_scm",(void*)f_3971},
{"f_3974:scrutinizer_scm",(void*)f_3974},
{"f_3980:scrutinizer_scm",(void*)f_3980},
{"f_3983:scrutinizer_scm",(void*)f_3983},
{"f_3986:scrutinizer_scm",(void*)f_3986},
{"f_3968:scrutinizer_scm",(void*)f_3968},
{"f_3948:scrutinizer_scm",(void*)f_3948},
{"f_3951:scrutinizer_scm",(void*)f_3951},
{"f_3964:scrutinizer_scm",(void*)f_3964},
{"f_3954:scrutinizer_scm",(void*)f_3954},
{"f_3957:scrutinizer_scm",(void*)f_3957},
{"f_3918:scrutinizer_scm",(void*)f_3918},
{"f_3928:scrutinizer_scm",(void*)f_3928},
{"f_3936:scrutinizer_scm",(void*)f_3936},
{"f_3926:scrutinizer_scm",(void*)f_3926},
{"f_3864:scrutinizer_scm",(void*)f_3864},
{"f_3868:scrutinizer_scm",(void*)f_3868},
{"f_3873:scrutinizer_scm",(void*)f_3873},
{"f_3912:scrutinizer_scm",(void*)f_3912},
{"f_3908:scrutinizer_scm",(void*)f_3908},
{"f_3900:scrutinizer_scm",(void*)f_3900},
{"f_3743:scrutinizer_scm",(void*)f_3743},
{"f_3809:scrutinizer_scm",(void*)f_3809},
{"f_3822:scrutinizer_scm",(void*)f_3822},
{"f_3825:scrutinizer_scm",(void*)f_3825},
{"f_3849:scrutinizer_scm",(void*)f_3849},
{"f_3828:scrutinizer_scm",(void*)f_3828},
{"f_3831:scrutinizer_scm",(void*)f_3831},
{"f_3841:scrutinizer_scm",(void*)f_3841},
{"f_3834:scrutinizer_scm",(void*)f_3834},
{"f_3784:scrutinizer_scm",(void*)f_3784},
{"f_3787:scrutinizer_scm",(void*)f_3787},
{"f_3800:scrutinizer_scm",(void*)f_3800},
{"f_3790:scrutinizer_scm",(void*)f_3790},
{"f_3793:scrutinizer_scm",(void*)f_3793},
{"f_3746:scrutinizer_scm",(void*)f_3746},
{"f_3753:scrutinizer_scm",(void*)f_3753},
{"f_3756:scrutinizer_scm",(void*)f_3756},
{"f_3769:scrutinizer_scm",(void*)f_3769},
{"f_3759:scrutinizer_scm",(void*)f_3759},
{"f_3762:scrutinizer_scm",(void*)f_3762},
{"f_3729:scrutinizer_scm",(void*)f_3729},
{"f_3741:scrutinizer_scm",(void*)f_3741},
{"f_3737:scrutinizer_scm",(void*)f_3737},
{"f_3648:scrutinizer_scm",(void*)f_3648},
{"f_3702:scrutinizer_scm",(void*)f_3702},
{"f_3705:scrutinizer_scm",(void*)f_3705},
{"f_3708:scrutinizer_scm",(void*)f_3708},
{"f_3711:scrutinizer_scm",(void*)f_3711},
{"f_3714:scrutinizer_scm",(void*)f_3714},
{"f_3717:scrutinizer_scm",(void*)f_3717},
{"f_3720:scrutinizer_scm",(void*)f_3720},
{"f_3723:scrutinizer_scm",(void*)f_3723},
{"f_3695:scrutinizer_scm",(void*)f_3695},
{"f_3680:scrutinizer_scm",(void*)f_3680},
{"f_3683:scrutinizer_scm",(void*)f_3683},
{"f_3686:scrutinizer_scm",(void*)f_3686},
{"f_3689:scrutinizer_scm",(void*)f_3689},
{"f_3692:scrutinizer_scm",(void*)f_3692},
{"f_3676:scrutinizer_scm",(void*)f_3676},
{"f_3308:scrutinizer_scm",(void*)f_3308},
{"f_3415:scrutinizer_scm",(void*)f_3415},
{"f_3550:scrutinizer_scm",(void*)f_3550},
{"f_3436:scrutinizer_scm",(void*)f_3436},
{"f_3464:scrutinizer_scm",(void*)f_3464},
{"f_3384:scrutinizer_scm",(void*)f_3384},
{"f_3253:scrutinizer_scm",(void*)f_3253},
{"f_3287:scrutinizer_scm",(void*)f_3287},
{"f_3043:scrutinizer_scm",(void*)f_3043},
{"f_3108:scrutinizer_scm",(void*)f_3108},
{"f_3216:scrutinizer_scm",(void*)f_3216},
{"f_3049:scrutinizer_scm",(void*)f_3049},
{"f_3067:scrutinizer_scm",(void*)f_3067},
{"f_3093:scrutinizer_scm",(void*)f_3093},
{"f_3074:scrutinizer_scm",(void*)f_3074},
{"f_3055:scrutinizer_scm",(void*)f_3055},
{"f_3061:scrutinizer_scm",(void*)f_3061},
{"f_2771:scrutinizer_scm",(void*)f_2771},
{"f_2858:scrutinizer_scm",(void*)f_2858},
{"f_2877:scrutinizer_scm",(void*)f_2877},
{"f_2914:scrutinizer_scm",(void*)f_2914},
{"f_2941:scrutinizer_scm",(void*)f_2941},
{"f_2882:scrutinizer_scm",(void*)f_2882},
{"f_2863:scrutinizer_scm",(void*)f_2863},
{"f_2762:scrutinizer_scm",(void*)f_2762},
{"f_2766:scrutinizer_scm",(void*)f_2766},
{"f_2696:scrutinizer_scm",(void*)f_2696},
{"f_2725:scrutinizer_scm",(void*)f_2725},
{"f_2729:scrutinizer_scm",(void*)f_2729},
{"f_2494:scrutinizer_scm",(void*)f_2494},
{"f_2654:scrutinizer_scm",(void*)f_2654},
{"f_2658:scrutinizer_scm",(void*)f_2658},
{"f_2590:scrutinizer_scm",(void*)f_2590},
{"f_2601:scrutinizer_scm",(void*)f_2601},
{"f_2609:scrutinizer_scm",(void*)f_2609},
{"f_2605:scrutinizer_scm",(void*)f_2605},
{"f_2529:scrutinizer_scm",(void*)f_2529},
{"f_2540:scrutinizer_scm",(void*)f_2540},
{"f_2472:scrutinizer_scm",(void*)f_2472},
{"f_2432:scrutinizer_scm",(void*)f_2432},
{"f_1964:scrutinizer_scm",(void*)f_1964},
{"f_1970:scrutinizer_scm",(void*)f_1970},
{"f_2376:scrutinizer_scm",(void*)f_2376},
{"f_2405:scrutinizer_scm",(void*)f_2405},
{"f_2370:scrutinizer_scm",(void*)f_2370},
{"f_2333:scrutinizer_scm",(void*)f_2333},
{"f_2362:scrutinizer_scm",(void*)f_2362},
{"f_2325:scrutinizer_scm",(void*)f_2325},
{"f_2005:scrutinizer_scm",(void*)f_2005},
{"f_2251:scrutinizer_scm",(void*)f_2251},
{"f_2255:scrutinizer_scm",(void*)f_2255},
{"f_2261:scrutinizer_scm",(void*)f_2261},
{"f_2119:scrutinizer_scm",(void*)f_2119},
{"f_2161:scrutinizer_scm",(void*)f_2161},
{"f_2233:scrutinizer_scm",(void*)f_2233},
{"f_2186:scrutinizer_scm",(void*)f_2186},
{"f_2223:scrutinizer_scm",(void*)f_2223},
{"f_2199:scrutinizer_scm",(void*)f_2199},
{"f_2122:scrutinizer_scm",(void*)f_2122},
{"f_2151:scrutinizer_scm",(void*)f_2151},
{"f_2149:scrutinizer_scm",(void*)f_2149},
{"f_2142:scrutinizer_scm",(void*)f_2142},
{"f_2108:scrutinizer_scm",(void*)f_2108},
{"f_2011:scrutinizer_scm",(void*)f_2011},
{"f_2016:scrutinizer_scm",(void*)f_2016},
{"f_2042:scrutinizer_scm",(void*)f_2042},
{"f_2054:scrutinizer_scm",(void*)f_2054},
{"f_2050:scrutinizer_scm",(void*)f_2050},
{"f_1955:scrutinizer_scm",(void*)f_1955},
{"f_1959:scrutinizer_scm",(void*)f_1959},
{"f_1868:scrutinizer_scm",(void*)f_1868},
{"f_1890:scrutinizer_scm",(void*)f_1890},
{"f_1893:scrutinizer_scm",(void*)f_1893},
{"f_1896:scrutinizer_scm",(void*)f_1896},
{"f_1899:scrutinizer_scm",(void*)f_1899},
{"f_1902:scrutinizer_scm",(void*)f_1902},
{"f_1905:scrutinizer_scm",(void*)f_1905},
{"f_1908:scrutinizer_scm",(void*)f_1908},
{"f_1920:scrutinizer_scm",(void*)f_1920},
{"f_1949:scrutinizer_scm",(void*)f_1949},
{"f_1918:scrutinizer_scm",(void*)f_1918},
{"f_1911:scrutinizer_scm",(void*)f_1911},
{"f_1787:scrutinizer_scm",(void*)f_1787},
{"f_1803:scrutinizer_scm",(void*)f_1803},
{"f_1806:scrutinizer_scm",(void*)f_1806},
{"f_1809:scrutinizer_scm",(void*)f_1809},
{"f_1812:scrutinizer_scm",(void*)f_1812},
{"f_1815:scrutinizer_scm",(void*)f_1815},
{"f_1818:scrutinizer_scm",(void*)f_1818},
{"f_1821:scrutinizer_scm",(void*)f_1821},
{"f_1833:scrutinizer_scm",(void*)f_1833},
{"f_1862:scrutinizer_scm",(void*)f_1862},
{"f_1831:scrutinizer_scm",(void*)f_1831},
{"f_1824:scrutinizer_scm",(void*)f_1824},
{"f_1607:scrutinizer_scm",(void*)f_1607},
{"f_1766:scrutinizer_scm",(void*)f_1766},
{"f_1769:scrutinizer_scm",(void*)f_1769},
{"f_1772:scrutinizer_scm",(void*)f_1772},
{"f_1724:scrutinizer_scm",(void*)f_1724},
{"f_1753:scrutinizer_scm",(void*)f_1753},
{"f_1718:scrutinizer_scm",(void*)f_1718},
{"f_1653:scrutinizer_scm",(void*)f_1653},
{"f_1663:scrutinizer_scm",(void*)f_1663},
{"f_1666:scrutinizer_scm",(void*)f_1666},
{"f_1690:scrutinizer_scm",(void*)f_1690},
{"f_1669:scrutinizer_scm",(void*)f_1669},
{"f_1672:scrutinizer_scm",(void*)f_1672},
{"f_1682:scrutinizer_scm",(void*)f_1682},
{"f_1675:scrutinizer_scm",(void*)f_1675},
{"f_1566:scrutinizer_scm",(void*)f_1566},
{"f_1570:scrutinizer_scm",(void*)f_1570},
{"f_1580:scrutinizer_scm",(void*)f_1580},
{"f_1583:scrutinizer_scm",(void*)f_1583},
{"f_1586:scrutinizer_scm",(void*)f_1586},
{"f_1589:scrutinizer_scm",(void*)f_1589},
{"f_1592:scrutinizer_scm",(void*)f_1592},
{"f_1595:scrutinizer_scm",(void*)f_1595},
{"f_1605:scrutinizer_scm",(void*)f_1605},
{"f_1598:scrutinizer_scm",(void*)f_1598},
{"f_1601:scrutinizer_scm",(void*)f_1601},
{"f_1573:scrutinizer_scm",(void*)f_1573},
{"f_1534:scrutinizer_scm",(void*)f_1534},
{"f_1541:scrutinizer_scm",(void*)f_1541},
{"f_1461:scrutinizer_scm",(void*)f_1461},
{"f_1525:scrutinizer_scm",(void*)f_1525},
{"f_1532:scrutinizer_scm",(void*)f_1532},
{"f_1468:scrutinizer_scm",(void*)f_1468},
{"f_1475:scrutinizer_scm",(void*)f_1475},
{"f_1489:scrutinizer_scm",(void*)f_1489},
{"f_1492:scrutinizer_scm",(void*)f_1492},
{"f_1505:scrutinizer_scm",(void*)f_1505},
{"f_1495:scrutinizer_scm",(void*)f_1495},
{"f_1498:scrutinizer_scm",(void*)f_1498},
{"f_1501:scrutinizer_scm",(void*)f_1501},
{"f_1485:scrutinizer_scm",(void*)f_1485},
{"f_1374:scrutinizer_scm",(void*)f_1374},
{"f_1378:scrutinizer_scm",(void*)f_1378},
{"f_1382:scrutinizer_scm",(void*)f_1382},
{"f_1414:scrutinizer_scm",(void*)f_1414},
{"f_1421:scrutinizer_scm",(void*)f_1421},
{"f_1424:scrutinizer_scm",(void*)f_1424},
{"f_1427:scrutinizer_scm",(void*)f_1427},
{"f_1430:scrutinizer_scm",(void*)f_1430},
{"f_1433:scrutinizer_scm",(void*)f_1433},
{"f_1436:scrutinizer_scm",(void*)f_1436},
{"f_1439:scrutinizer_scm",(void*)f_1439},
{"f_1417:scrutinizer_scm",(void*)f_1417},
{"f_1396:scrutinizer_scm",(void*)f_1396},
{"f_1399:scrutinizer_scm",(void*)f_1399},
{"f_1402:scrutinizer_scm",(void*)f_1402},
{"f_1405:scrutinizer_scm",(void*)f_1405},
{"f_1408:scrutinizer_scm",(void*)f_1408},
{"f_1392:scrutinizer_scm",(void*)f_1392},
{"f_1251:scrutinizer_scm",(void*)f_1251},
{"f_1261:scrutinizer_scm",(void*)f_1261},
{"f_1264:scrutinizer_scm",(void*)f_1264},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
