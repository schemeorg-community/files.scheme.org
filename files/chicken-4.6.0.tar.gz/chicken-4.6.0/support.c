/* Generated from support.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: support.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -extend private-namespace.scm -no-trace -output-file support.c
   unit: support
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[503];
static double C_possibly_force_alignment;


/* from k3734 */
static C_word C_fcall stub189(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub189(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_wordstobytes(t0));
return C_r;}

/* from k3727 */
static C_word C_fcall stub185(C_word C_buf,C_word C_a0) C_regparm;
C_regparm static C_word C_fcall stub185(C_word C_buf,C_word C_a0){
C_word C_r=C_SCHEME_UNDEFINED,*C_a=(C_word*)C_buf;
int t0=(int )C_unfix(C_a0);
C_r=C_fix((C_word)C_bytestowords(t0));
return C_r;}

C_noret_decl(C_support_toplevel)
C_externexport void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3157)
static void C_ccall f_3157(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4190)
static void C_ccall f_4190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4193)
static void C_ccall f_4193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12574)
static void C_ccall f_12574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12578)
static void C_ccall f_12578(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12663)
static void C_ccall f_12663(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12584)
static void C_ccall f_12584(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12650)
static void C_ccall f_12650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12653)
static void C_ccall f_12653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12656)
static void C_ccall f_12656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12590)
static void C_ccall f_12590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12597)
static void C_ccall f_12597(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12599)
static void C_fcall f_12599(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12622)
static void C_ccall f_12622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12618)
static void C_ccall f_12618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12636)
static void C_ccall f_12636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12563)
static void C_ccall f_12563(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12552)
static void C_ccall f_12552(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12546)
static void C_ccall f_12546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12518)
static void C_ccall f_12518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_12518)
static void C_ccall f_12518r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_12522)
static void C_ccall f_12522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12497)
static void C_ccall f_12497(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12501)
static void C_ccall f_12501(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12464)
static void C_ccall f_12464(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12470)
static void C_ccall f_12470(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12431)
static void C_ccall f_12431(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12437)
static void C_ccall f_12437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12407)
static void C_ccall f_12407(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12338)
static void C_ccall f_12338(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12342)
static void C_ccall f_12342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12347)
static void C_fcall f_12347(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12351)
static void C_ccall f_12351(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12402)
static void C_ccall f_12402(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12381)
static void C_ccall f_12381(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12393)
static void C_ccall f_12393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12396)
static void C_ccall f_12396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12369)
static void C_ccall f_12369(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12305)
static void C_ccall f_12305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12315)
static void C_ccall f_12315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12318)
static void C_ccall f_12318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12299)
static void C_ccall f_12299(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12254)
static void C_ccall f_12254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_12261)
static void C_fcall f_12261(C_word t0,C_word t1) C_noret;
C_noret_decl(f_12276)
static void C_ccall f_12276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12280)
static void C_ccall f_12280(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12272)
static void C_ccall f_12272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12258)
static void C_ccall f_12258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12131)
static void C_ccall f_12131(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12140)
static void C_fcall f_12140(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12168)
static void C_ccall f_12168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12174)
static void C_ccall f_12174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12177)
static void C_ccall f_12177(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12180)
static void C_ccall f_12180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12183)
static void C_ccall f_12183(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12186)
static void C_ccall f_12186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12189)
static void C_ccall f_12189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12248)
static void C_ccall f_12248(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12192)
static void C_ccall f_12192(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12207)
static void C_ccall f_12207(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12210)
static void C_ccall f_12210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12218)
static void C_fcall f_12218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12228)
static void C_ccall f_12228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12231)
static void C_ccall f_12231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12213)
static void C_ccall f_12213(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12198)
static void C_ccall f_12198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12135)
static void C_ccall f_12135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12128)
static void C_ccall f_12128(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12110)
static void C_ccall f_12110(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12076)
static void C_ccall f_12076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_12100)
static void C_ccall f_12100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12096)
static void C_ccall f_12096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12055)
static void C_ccall f_12055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12061)
static void C_ccall f_12061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12065)
static void C_ccall f_12065(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12068)
static void C_ccall f_12068(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12071)
static void C_ccall f_12071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12043)
static void C_ccall f_12043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12047)
static void C_ccall f_12047(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11952)
static void C_ccall f_11952(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_11952)
static void C_ccall f_11952r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_11971)
static void C_ccall f_11971(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11996)
static void C_ccall f_11996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12000)
static void C_ccall f_12000(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12002)
static void C_fcall f_12002(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_12009)
static void C_ccall f_12009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12022)
static void C_ccall f_12022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12025)
static void C_ccall f_12025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12028)
static void C_ccall f_12028(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12031)
static void C_ccall f_12031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12034)
static void C_ccall f_12034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_12038)
static void C_ccall f_12038(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11955)
static void C_fcall f_11955(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11959)
static void C_ccall f_11959(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11965)
static void C_ccall f_11965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11946)
static void C_ccall f_11946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11887)
static void C_ccall f_11887r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11895)
static void C_ccall f_11895(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11922)
static void C_ccall f_11922(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11898)
static void C_ccall f_11898(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11901)
static void C_ccall f_11901(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11918)
static void C_ccall f_11918(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11904)
static void C_ccall f_11904(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11914)
static void C_ccall f_11914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11907)
static void C_ccall f_11907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11910)
static void C_ccall f_11910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11878)
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11872)
static void C_ccall f_11872(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11866)
static void C_ccall f_11866(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11854)
static void C_ccall f_11854(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11858)
static void C_ccall f_11858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11861)
static void C_ccall f_11861(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_11816)
static void C_ccall f_11816r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_11820)
static void C_ccall f_11820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f13809)
static void C_ccall f13809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11823)
static void C_ccall f_11823(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11830)
static void C_ccall f_11830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11774)
static void C_ccall f_11774(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11783)
static void C_fcall f_11783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11745)
static void C_ccall f_11745(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11755)
static void C_fcall f_11755(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11536)
static void C_ccall f_11536(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11740)
static void C_ccall f_11740(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11705)
static void C_fcall f_11705(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11711)
static void C_fcall f_11711(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11726)
static void C_ccall f_11726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11719)
static void C_fcall f_11719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11539)
static void C_fcall f_11539(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11573)
static void C_fcall f_11573(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11667)
static void C_ccall f_11667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_11679)
static void C_ccall f_11679(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11637)
static void C_ccall f_11637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11648)
static void C_ccall f_11648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11628)
static void C_ccall f_11628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11592)
static void C_ccall f_11592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11598)
static void C_ccall f_11598(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11602)
static void C_ccall f_11602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11397)
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11403)
static void C_fcall f_11403(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11496)
static void C_fcall f_11496(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11501)
static void C_fcall f_11501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11511)
static void C_ccall f_11511(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11464)
static void C_fcall f_11464(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11435)
static void C_fcall f_11435(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11440)
static void C_fcall f_11440(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11450)
static void C_ccall f_11450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11401)
static void C_ccall f_11401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_11028)
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_11227)
static void C_fcall f_11227(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11319)
static void C_fcall f_11319(C_word t0,C_word t1) C_noret;
C_noret_decl(f_11230)
static void C_ccall f_11230(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10707)
static void C_ccall f_10707(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_11022)
static void C_ccall f_11022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10719)
static void C_ccall f_10719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10729)
static void C_fcall f_10729(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10747)
static void C_ccall f_10747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10786)
static void C_fcall f_10786(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10751)
static void C_fcall f_10751(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10377)
static void C_ccall f_10377(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10701)
static void C_ccall f_10701(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10383)
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10393)
static void C_fcall f_10393(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10402)
static void C_fcall f_10402(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10414)
static void C_fcall f_10414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10426)
static void C_fcall f_10426(C_word t0,C_word t1) C_noret;
C_noret_decl(f_10432)
static void C_ccall f_10432(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10436)
static void C_fcall f_10436(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10332)
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10371)
static void C_ccall f_10371(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10338)
static void C_ccall f_10338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10342)
static void C_ccall f_10342(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10346)
static void C_fcall f_10346(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_10301)
static void C_ccall f_10301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10314)
static void C_ccall f_10314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_10270)
static void C_ccall f_10270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10283)
static void C_ccall f_10283(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9212)
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_10264)
static void C_ccall f_10264(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9218)
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9224)
static void C_fcall f_9224(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9253)
static void C_fcall f_9253(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9272)
static void C_fcall f_9272(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9291)
static void C_fcall f_9291(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9361)
static void C_fcall f_9361(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9380)
static void C_fcall f_9380(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9462)
static void C_fcall f_9462(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9501)
static void C_fcall f_9501(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9520)
static void C_fcall f_9520(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9539)
static void C_fcall f_9539(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9619)
static void C_fcall f_9619(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9704)
static void C_fcall f_9704(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9779)
static void C_ccall f_9779(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9818)
static void C_fcall f_9818(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9888)
static void C_ccall f_9888(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9821)
static void C_ccall f_9821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9783)
static void C_fcall f_9783(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9622)
static void C_ccall f_9622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9653)
static void C_fcall f_9653(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9542)
static void C_ccall f_9542(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9383)
static void C_ccall f_9383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9414)
static void C_fcall f_9414(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9294)
static void C_ccall f_9294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9325)
static void C_fcall f_9325(C_word t0,C_word t1) C_noret;
C_noret_decl(f_9154)
static void C_ccall f_9154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_9158)
static void C_ccall f_9158(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9169)
static void C_ccall f_9169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9175)
static void C_fcall f_9175(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9187)
static void C_ccall f_9187(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9193)
static void C_ccall f_9193(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9161)
static void C_ccall f_9161(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9073)
static void C_ccall f_9073(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_9085)
static void C_ccall f_9085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8) C_noret;
C_noret_decl(f_9092)
static void C_ccall f_9092(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9095)
static void C_ccall f_9095(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9098)
static void C_ccall f_9098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9101)
static void C_ccall f_9101(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9104)
static void C_ccall f_9104(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9107)
static void C_ccall f_9107(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9110)
static void C_ccall f_9110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9113)
static void C_ccall f_9113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9116)
static void C_ccall f_9116(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9119)
static void C_ccall f_9119(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9122)
static void C_ccall f_9122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9125)
static void C_ccall f_9125(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9128)
static void C_ccall f_9128(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9131)
static void C_ccall f_9131(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9134)
static void C_ccall f_9134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9137)
static void C_ccall f_9137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9140)
static void C_ccall f_9140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9143)
static void C_ccall f_9143(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9146)
static void C_ccall f_9146(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9149)
static void C_ccall f_9149(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_9079)
static void C_ccall f_9079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8965)
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8974)
static void C_ccall f_8974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8980)
static void C_fcall f_8980(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8988)
static C_word C_fcall f_8988(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_8969)
static void C_ccall f_8969(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8944)
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_8954)
static void C_ccall f_8954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8895)
static void C_ccall f_8895(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8901)
static void C_ccall f_8901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8942)
static void C_ccall f_8942(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8914)
static void C_ccall f_8914(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8858)
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8864)
static void C_ccall f_8864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8893)
static void C_ccall f_8893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8871)
static void C_fcall f_8871(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8874)
static void C_ccall f_8874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8817)
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8823)
static void C_ccall f_8823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8856)
static void C_ccall f_8856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8830)
static void C_fcall f_8830(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8833)
static void C_ccall f_8833(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8695)
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8724)
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8594)
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8600)
static void C_ccall f_8600(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8626)
static void C_fcall f_8626(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8640)
static void C_ccall f_8640(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8648)
static void C_ccall f_8648(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8369)
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_8568)
static void C_ccall f_8568(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8574)
static void C_ccall f_8574(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8449)
static void C_fcall f_8449(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8471)
static void C_ccall f_8471(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8489)
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8520)
static void C_ccall f_8520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8406)
static void C_fcall f_8406(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8428)
static void C_ccall f_8428(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8372)
static void C_fcall f_8372(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8401)
static void C_ccall f_8401(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8380)
static C_word C_fcall f_8380(C_word t0,C_word t1);
C_noret_decl(f_8300)
static void C_ccall f_8300(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8306)
static void C_ccall f_8306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8312)
static void C_fcall f_8312(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8316)
static void C_ccall f_8316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8363)
static void C_ccall f_8363(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8327)
static void C_ccall f_8327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8352)
static void C_ccall f_8352(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8063)
static void C_ccall f_8063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8157)
static void C_ccall f_8157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_8164)
static void C_ccall f_8164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8298)
static void C_ccall f_8298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8188)
static void C_fcall f_8188(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8265)
static void C_ccall f_8265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8222)
static void C_ccall f_8222(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8225)
static void C_fcall f_8225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_8241)
static void C_ccall f_8241(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8067)
static void C_ccall f_8067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8106)
static void C_ccall f_8106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8155)
static void C_ccall f_8155(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8110)
static void C_ccall f_8110(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8120)
static void C_ccall f_8120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8122)
static void C_fcall f_8122(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8134)
static void C_ccall f_8134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8140)
static void C_ccall f_8140(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8113)
static void C_ccall f_8113(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8070)
static void C_ccall f_8070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8076)
static void C_ccall f_8076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8089)
static void C_ccall f_8089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8081)
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7995)
static void C_ccall f_7995(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8001)
static void C_fcall f_8001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8028)
static void C_fcall f_8028(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_8057)
static void C_ccall f_8057(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_8022)
static void C_ccall f_8022(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7909)
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7915)
static void C_fcall f_7915(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7960)
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7989)
static void C_ccall f_7989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7949)
static void C_ccall f_7949(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7945)
static void C_ccall f_7945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7870)
static void C_ccall f_7870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7874)
static void C_ccall f_7874(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7877)
static void C_ccall f_7877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7880)
static void C_ccall f_7880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7836)
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7842)
static void C_fcall f_7842(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7856)
static void C_ccall f_7856(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7860)
static void C_ccall f_7860(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7437)
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_7787)
static void C_fcall f_7787(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7820)
static void C_ccall f_7820(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7800)
static void C_fcall f_7800(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7441)
static void C_ccall f_7441(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7449)
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7772)
static void C_ccall f_7772(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7778)
static void C_ccall f_7778(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7776)
static void C_ccall f_7776(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7612)
static void C_ccall f_7612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7719)
static void C_fcall f_7719(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7756)
static void C_ccall f_7756(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7746)
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7750)
static void C_ccall f_7750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7753)
static void C_ccall f_7753(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7616)
static void C_ccall f_7616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7670)
static void C_fcall f_7670(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7703)
static void C_ccall f_7703(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7683)
static void C_fcall f_7683(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7668)
static void C_ccall f_7668(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7619)
static void C_ccall f_7619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7645)
static void C_ccall f_7645(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7661)
static void C_ccall f_7661(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7653)
static void C_ccall f_7653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7637)
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7635)
static void C_ccall f_7635(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7563)
static void C_ccall f_7563(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7566)
static void C_ccall f_7566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7569)
static void C_ccall f_7569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7589)
static void C_ccall f_7589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7547)
static void C_ccall f_7547(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7539)
static void C_ccall f_7539(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7510)
static void C_ccall f_7510(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7500)
static void C_ccall f_7500(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7507)
static void C_ccall f_7507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7289)
static void C_ccall f_7289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6) C_noret;
C_noret_decl(f_7295)
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7307)
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7402)
static void C_fcall f_7402(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7431)
static void C_ccall f_7431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7311)
static void C_ccall f_7311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7314)
static void C_ccall f_7314(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7394)
static void C_ccall f_7394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7340)
static void C_fcall f_7340(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7344)
static void C_ccall f_7344(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7319)
static void C_ccall f_7319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7301)
static void C_ccall f_7301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7235)
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_7241)
static void C_fcall f_7241(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7267)
static void C_ccall f_7267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7271)
static void C_ccall f_7271(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6554)
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6560)
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6594)
static void C_fcall f_6594(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7052)
static void C_fcall f_7052(C_word t0,C_word t1) C_noret;
C_noret_decl(f_7170)
static void C_fcall f_7170(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7199)
static void C_ccall f_7199(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7168)
static void C_ccall f_7168(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7164)
static void C_ccall f_7164(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7124)
static void C_fcall f_7124(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7153)
static void C_ccall f_7153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7122)
static void C_ccall f_7122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7059)
static void C_ccall f_7059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7069)
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_7098)
static void C_ccall f_7098(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7063)
static void C_ccall f_7063(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6990)
static void C_fcall f_6990(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_7039)
static void C_ccall f_7039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7008)
static void C_ccall f_7008(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_7016)
static void C_ccall f_7016(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6933)
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6962)
static void C_ccall f_6962(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6931)
static void C_ccall f_6931(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6881)
static void C_fcall f_6881(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6910)
static void C_ccall f_6910(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6863)
static void C_ccall f_6863(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6807)
static void C_ccall f_6807(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6809)
static void C_fcall f_6809(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6838)
static void C_ccall f_6838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6754)
static void C_ccall f_6754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6756)
static void C_fcall f_6756(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6789)
static void C_ccall f_6789(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6769)
static void C_fcall f_6769(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6738)
static void C_ccall f_6738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6750)
static void C_ccall f_6750(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6746)
static void C_ccall f_6746(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6659)
static void C_fcall f_6659(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6688)
static void C_ccall f_6688(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6657)
static void C_ccall f_6657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6653)
static void C_ccall f_6653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6603)
static void C_fcall f_6603(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6632)
static void C_ccall f_6632(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6601)
static void C_ccall f_6601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5631)
static void C_ccall f_5631(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6549)
static void C_ccall f_6549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6552)
static void C_ccall f_6552(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5634)
static void C_fcall f_5634(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6509)
static void C_fcall f_6509(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6538)
static void C_ccall f_6538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6507)
static void C_ccall f_6507(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6247)
static void C_fcall f_6247(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6374)
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_6458)
static void C_ccall f_6458(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6430)
static void C_fcall f_6430(C_word t0,C_word t1) C_noret;
C_noret_decl(f_6437)
static void C_ccall f_6437(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6444)
static void C_ccall f_6444(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6434)
static void C_ccall f_6434(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6393)
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6422)
static void C_ccall f_6422(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6391)
static void C_ccall f_6391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6368)
static void C_ccall f_6368(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6330)
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6359)
static void C_ccall f_6359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6324)
static void C_ccall f_6324(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6273)
static void C_fcall f_6273(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6302)
static void C_ccall f_6302(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6267)
static void C_ccall f_6267(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6226)
static void C_ccall f_6226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6210)
static void C_ccall f_6210(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6206)
static void C_ccall f_6206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6140)
static void C_fcall f_6140(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6169)
static void C_ccall f_6169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6134)
static void C_ccall f_6134(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6050)
static void C_fcall f_6050(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_6079)
static void C_ccall f_6079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_6044)
static void C_ccall f_6044(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5952)
static void C_fcall f_5952(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5962)
static void C_fcall f_5962(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5991)
static void C_ccall f_5991(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5956)
static void C_ccall f_5956(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5919)
static void C_ccall f_5919(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5826)
static void C_ccall f_5826(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5848)
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5886)
static void C_ccall f_5886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5875)
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5834)
static void C_ccall f_5834(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5842)
static void C_ccall f_5842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5830)
static void C_ccall f_5830(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5767)
static void C_fcall f_5767(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5770)
static void C_ccall f_5770(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5777)
static void C_ccall f_5777(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5715)
static void C_fcall f_5715(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5744)
static void C_ccall f_5744(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5709)
static void C_ccall f_5709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5616)
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5601)
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5595)
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_5586)
static void C_ccall f_5586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5577)
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5568)
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5559)
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5550)
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5541)
static void C_ccall f_5541(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5535)
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5036)
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5533)
static void C_ccall f_5533(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5040)
static void C_fcall f_5040(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5045)
static void C_ccall f_5045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_5055)
static void C_ccall f_5055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5218)
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5228)
static void C_ccall f_5228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5244)
static void C_fcall f_5244(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5320)
static void C_fcall f_5320(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5360)
static void C_ccall f_5360(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5350)
static void C_ccall f_5350(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5323)
static void C_ccall f_5323(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5340)
static void C_ccall f_5340(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5326)
static void C_ccall f_5326(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5329)
static void C_ccall f_5329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5336)
static void C_ccall f_5336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5311)
static void C_ccall f_5311(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5301)
static void C_ccall f_5301(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5285)
static void C_ccall f_5285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5247)
static void C_ccall f_5247(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5262)
static void C_ccall f_5262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5231)
static void C_ccall f_5231(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5058)
static void C_ccall f_5058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5099)
static void C_fcall f_5099(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_fcall f_5133(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5167)
static void C_fcall f_5167(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5102)
static void C_ccall f_5102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5061)
static void C_ccall f_5061(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5089)
static void C_ccall f_5089(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5064)
static void C_ccall f_5064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5076)
static void C_ccall f_5076(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5067)
static void C_ccall f_5067(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4979)
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4986)
static void C_ccall f_4986(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5001)
static void C_fcall f_5001(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5030)
static void C_ccall f_5030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_ccall f_4999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4992)
static void C_ccall f_4992(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4949)
static void C_ccall f_4949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4955)
static void C_fcall f_4955(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4965)
static void C_ccall f_4965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4908)
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4915)
static void C_ccall f_4915(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4918)
static void C_fcall f_4918(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4922)
static void C_fcall f_4922(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4898)
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4889)
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4893)
static void C_ccall f_4893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...) C_noret;
C_noret_decl(f_4832)
static void C_ccall f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t6) C_noret;
C_noret_decl(f_4836)
static void C_ccall f_4836(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4866)
static void C_ccall f_4866(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4780)
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4784)
static void C_ccall f_4784(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4811)
static void C_ccall f_4811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4734)
static void C_ccall f_4734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5) C_noret;
C_noret_decl(f_4738)
static void C_ccall f_4738(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4760)
static void C_ccall f_4760(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_4716)
static void C_ccall f_4716r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_4720)
static void C_ccall f_4720(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4728)
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4698)
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4702)
static void C_ccall f_4702(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4445)
static void C_ccall f_4445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4607)
static void C_fcall f_4607(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4646)
static void C_ccall f_4646(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4657)
static void C_ccall f_4657(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4685)
static void C_ccall f_4685(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4453)
static void C_ccall f_4453(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4516)
static void C_fcall f_4516(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4530)
static void C_ccall f_4530(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4555)
static void C_ccall f_4555(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4566)
static void C_ccall f_4566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4594)
static void C_ccall f_4594(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4456)
static void C_ccall f_4456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4461)
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4475)
static void C_ccall f_4475(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4503)
static void C_ccall f_4503(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4449)
static void C_ccall f_4449(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4304)
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_4308)
static void C_ccall f_4308(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4312)
static void C_ccall f_4312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4301)
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4194)
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4203)
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_4288)
static void C_ccall f_4288r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_4294)
static void C_ccall f_4294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4240)
static void C_ccall f_4240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4272)
static void C_ccall f_4272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4286)
static void C_ccall f_4286(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4278)
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4266)
static void C_ccall f_4266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4209)
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4215)
static void C_ccall f_4215(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4226)
static void C_ccall f_4226(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4223)
static void C_ccall f_4223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4198)
static void C_ccall f_4198(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4093)
static void C_ccall f_4093(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4099)
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4176)
static void C_ccall f_4176(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4127)
static void C_fcall f_4127(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4165)
static void C_ccall f_4165(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4153)
static void C_ccall f_4153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4033)
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4049)
static void C_ccall f_4049(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4091)
static void C_ccall f_4091(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4055)
static void C_ccall f_4055(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3987)
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4031)
static void C_ccall f_4031(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3991)
static void C_fcall f_3991(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3957)
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3891)
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3905)
static void C_ccall f_3905(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3860)
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3866)
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3881)
static void C_ccall f_3881(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3797)
static void C_ccall f_3797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3811)
static void C_ccall f_3811(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3813)
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3785)
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3738)
static void C_ccall f_3738r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3754)
static void C_ccall f_3754(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3766)
static void C_fcall f_3766(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3731)
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3724)
static void C_ccall f_3724(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3668)
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3722)
static void C_ccall f_3722(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3672)
static void C_ccall f_3672(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3574)
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3590)
static void C_ccall f_3590(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3614)
static void C_fcall f_3614(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3653)
static void C_ccall f_3653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3621)
static void C_fcall f_3621(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3629)
static void C_ccall f_3629(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3586)
static void C_ccall f_3586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3530)
static void C_ccall f_3530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3536)
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3560)
static void C_ccall f_3560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3499)
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3522)
static void C_ccall f_3522(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_ccall f_3525(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3472)
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3494)
static void C_ccall f_3494(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3436)
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3442)
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3368)
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3392)
static void C_fcall f_3392(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3371)
static void C_fcall f_3371(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3379)
static void C_ccall f_3379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3383)
static void C_ccall f_3383(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3325)
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3331)
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3354)
static void C_ccall f_3354(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3322)
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3277)
static void C_ccall f_3277r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3281)
static void C_ccall f_3281(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3284)
static void C_fcall f_3284(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3287)
static void C_ccall f_3287(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3298)
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3290)
static void C_ccall f_3290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3293)
static void C_ccall f_3293(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2,...) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258r(C_word t0,C_word t1,C_word t2,C_word t4) C_noret;
C_noret_decl(f_3262)
static void C_ccall f_3262(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3275)
static void C_ccall f_3275(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3265)
static void C_ccall f_3265(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3268)
static void C_ccall f_3268(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...) C_noret;
C_noret_decl(f_3193)
static void C_ccall f_3193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t5) C_noret;
C_noret_decl(f_3203)
static void C_ccall f_3203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3218)
static void C_ccall f_3218(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_fcall f_3223(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3245)
static void C_ccall f_3245(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3206)
static void C_ccall f_3206(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3209)
static void C_ccall f_3209(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3212)
static void C_ccall f_3212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3166)
static void C_ccall f_3166r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3161)
static void C_ccall f_3161(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_12599)
static void C_fcall trf_12599(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12599(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12599(t0,t1,t2);}

C_noret_decl(trf_12347)
static void C_fcall trf_12347(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12347(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12347(t0,t1);}

C_noret_decl(trf_12261)
static void C_fcall trf_12261(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12261(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_12261(t0,t1);}

C_noret_decl(trf_12140)
static void C_fcall trf_12140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12140(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12140(t0,t1,t2,t3);}

C_noret_decl(trf_12218)
static void C_fcall trf_12218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_12218(t0,t1,t2);}

C_noret_decl(trf_12002)
static void C_fcall trf_12002(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_12002(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_12002(t0,t1,t2,t3);}

C_noret_decl(trf_11955)
static void C_fcall trf_11955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11955(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11955(t0,t1);}

C_noret_decl(trf_11783)
static void C_fcall trf_11783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11783(t0,t1,t2);}

C_noret_decl(trf_11755)
static void C_fcall trf_11755(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11755(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11755(t0,t1);}

C_noret_decl(trf_11705)
static void C_fcall trf_11705(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11705(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11705(t0,t1,t2,t3);}

C_noret_decl(trf_11711)
static void C_fcall trf_11711(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11711(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11711(t0,t1,t2);}

C_noret_decl(trf_11719)
static void C_fcall trf_11719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11719(t0,t1,t2);}

C_noret_decl(trf_11539)
static void C_fcall trf_11539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11539(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_11539(t0,t1,t2,t3);}

C_noret_decl(trf_11573)
static void C_fcall trf_11573(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11573(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11573(t0,t1);}

C_noret_decl(trf_11403)
static void C_fcall trf_11403(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11403(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11403(t0,t1,t2);}

C_noret_decl(trf_11496)
static void C_fcall trf_11496(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11496(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11496(t0,t1);}

C_noret_decl(trf_11501)
static void C_fcall trf_11501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11501(t0,t1,t2);}

C_noret_decl(trf_11464)
static void C_fcall trf_11464(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11464(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11464(t0,t1);}

C_noret_decl(trf_11435)
static void C_fcall trf_11435(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11435(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11435(t0,t1);}

C_noret_decl(trf_11440)
static void C_fcall trf_11440(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11440(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_11440(t0,t1,t2);}

C_noret_decl(trf_11227)
static void C_fcall trf_11227(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11227(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11227(t0,t1);}

C_noret_decl(trf_11319)
static void C_fcall trf_11319(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_11319(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_11319(t0,t1);}

C_noret_decl(trf_10729)
static void C_fcall trf_10729(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10729(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10729(t0,t1);}

C_noret_decl(trf_10786)
static void C_fcall trf_10786(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10786(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10786(t0,t1);}

C_noret_decl(trf_10751)
static void C_fcall trf_10751(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10751(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10751(t0,t1,t2);}

C_noret_decl(trf_10393)
static void C_fcall trf_10393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10393(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10393(t0,t1);}

C_noret_decl(trf_10402)
static void C_fcall trf_10402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10402(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10402(t0,t1);}

C_noret_decl(trf_10414)
static void C_fcall trf_10414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10414(t0,t1);}

C_noret_decl(trf_10426)
static void C_fcall trf_10426(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10426(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_10426(t0,t1);}

C_noret_decl(trf_10436)
static void C_fcall trf_10436(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10436(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10436(t0,t1,t2);}

C_noret_decl(trf_10346)
static void C_fcall trf_10346(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_10346(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_10346(t0,t1,t2);}

C_noret_decl(trf_9224)
static void C_fcall trf_9224(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9224(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9224(t0,t1,t2);}

C_noret_decl(trf_9253)
static void C_fcall trf_9253(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9253(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9253(t0,t1);}

C_noret_decl(trf_9272)
static void C_fcall trf_9272(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9272(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9272(t0,t1);}

C_noret_decl(trf_9291)
static void C_fcall trf_9291(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9291(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9291(t0,t1);}

C_noret_decl(trf_9361)
static void C_fcall trf_9361(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9361(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9361(t0,t1);}

C_noret_decl(trf_9380)
static void C_fcall trf_9380(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9380(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9380(t0,t1);}

C_noret_decl(trf_9462)
static void C_fcall trf_9462(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9462(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9462(t0,t1);}

C_noret_decl(trf_9501)
static void C_fcall trf_9501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9501(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9501(t0,t1);}

C_noret_decl(trf_9520)
static void C_fcall trf_9520(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9520(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9520(t0,t1);}

C_noret_decl(trf_9539)
static void C_fcall trf_9539(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9539(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9539(t0,t1);}

C_noret_decl(trf_9619)
static void C_fcall trf_9619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9619(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9619(t0,t1);}

C_noret_decl(trf_9704)
static void C_fcall trf_9704(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9704(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9704(t0,t1);}

C_noret_decl(trf_9818)
static void C_fcall trf_9818(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9818(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9818(t0,t1);}

C_noret_decl(trf_9783)
static void C_fcall trf_9783(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9783(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9783(t0,t1,t2);}

C_noret_decl(trf_9653)
static void C_fcall trf_9653(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9653(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9653(t0,t1);}

C_noret_decl(trf_9414)
static void C_fcall trf_9414(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9414(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9414(t0,t1);}

C_noret_decl(trf_9325)
static void C_fcall trf_9325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9325(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_9325(t0,t1);}

C_noret_decl(trf_9175)
static void C_fcall trf_9175(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_9175(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_9175(t0,t1,t2);}

C_noret_decl(trf_8980)
static void C_fcall trf_8980(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8980(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8980(t0,t1,t2);}

C_noret_decl(trf_8871)
static void C_fcall trf_8871(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8871(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8871(t0,t1);}

C_noret_decl(trf_8830)
static void C_fcall trf_8830(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8830(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8830(t0,t1);}

C_noret_decl(trf_8626)
static void C_fcall trf_8626(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8626(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8626(t0,t1);}

C_noret_decl(trf_8449)
static void C_fcall trf_8449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8449(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8449(t0,t1,t2,t3);}

C_noret_decl(trf_8489)
static void C_fcall trf_8489(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8489(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8489(t0,t1,t2,t3);}

C_noret_decl(trf_8406)
static void C_fcall trf_8406(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8406(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8406(t0,t1,t2,t3);}

C_noret_decl(trf_8372)
static void C_fcall trf_8372(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8372(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_8372(t0,t1,t2,t3);}

C_noret_decl(trf_8312)
static void C_fcall trf_8312(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8312(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8312(t0,t1);}

C_noret_decl(trf_8188)
static void C_fcall trf_8188(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8188(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8188(t0,t1);}

C_noret_decl(trf_8225)
static void C_fcall trf_8225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_8225(t0,t1);}

C_noret_decl(trf_8122)
static void C_fcall trf_8122(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8122(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8122(t0,t1,t2);}

C_noret_decl(trf_8001)
static void C_fcall trf_8001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8001(t0,t1,t2);}

C_noret_decl(trf_8028)
static void C_fcall trf_8028(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_8028(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_8028(t0,t1,t2);}

C_noret_decl(trf_7915)
static void C_fcall trf_7915(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7915(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7915(t0,t1,t2);}

C_noret_decl(trf_7960)
static void C_fcall trf_7960(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7960(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7960(t0,t1,t2);}

C_noret_decl(trf_7842)
static void C_fcall trf_7842(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7842(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7842(t0,t1,t2);}

C_noret_decl(trf_7787)
static void C_fcall trf_7787(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7787(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7787(t0,t1,t2,t3);}

C_noret_decl(trf_7800)
static void C_fcall trf_7800(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7800(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7800(t0,t1);}

C_noret_decl(trf_7449)
static void C_fcall trf_7449(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7449(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7449(t0,t1,t2,t3);}

C_noret_decl(trf_7719)
static void C_fcall trf_7719(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7719(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7719(t0,t1,t2);}

C_noret_decl(trf_7746)
static void C_fcall trf_7746(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7746(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7746(t0,t1,t2);}

C_noret_decl(trf_7670)
static void C_fcall trf_7670(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7670(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_7670(t0,t1,t2,t3);}

C_noret_decl(trf_7683)
static void C_fcall trf_7683(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7683(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7683(t0,t1);}

C_noret_decl(trf_7402)
static void C_fcall trf_7402(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7402(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7402(t0,t1,t2);}

C_noret_decl(trf_7340)
static void C_fcall trf_7340(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7340(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7340(t0,t1);}

C_noret_decl(trf_7241)
static void C_fcall trf_7241(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7241(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7241(t0,t1,t2);}

C_noret_decl(trf_6560)
static void C_fcall trf_6560(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6560(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6560(t0,t1,t2);}

C_noret_decl(trf_6594)
static void C_fcall trf_6594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6594(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6594(t0,t1);}

C_noret_decl(trf_7052)
static void C_fcall trf_7052(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7052(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_7052(t0,t1);}

C_noret_decl(trf_7170)
static void C_fcall trf_7170(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7170(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7170(t0,t1,t2);}

C_noret_decl(trf_7124)
static void C_fcall trf_7124(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7124(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7124(t0,t1,t2);}

C_noret_decl(trf_7069)
static void C_fcall trf_7069(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_7069(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_7069(t0,t1,t2);}

C_noret_decl(trf_6990)
static void C_fcall trf_6990(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6990(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_6990(t0,t1,t2,t3,t4);}

C_noret_decl(trf_6933)
static void C_fcall trf_6933(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6933(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6933(t0,t1,t2);}

C_noret_decl(trf_6881)
static void C_fcall trf_6881(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6881(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6881(t0,t1,t2);}

C_noret_decl(trf_6809)
static void C_fcall trf_6809(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6809(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6809(t0,t1,t2);}

C_noret_decl(trf_6756)
static void C_fcall trf_6756(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6756(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_6756(t0,t1,t2,t3);}

C_noret_decl(trf_6769)
static void C_fcall trf_6769(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6769(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6769(t0,t1);}

C_noret_decl(trf_6659)
static void C_fcall trf_6659(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6659(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6659(t0,t1,t2);}

C_noret_decl(trf_6603)
static void C_fcall trf_6603(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6603(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6603(t0,t1,t2);}

C_noret_decl(trf_5634)
static void C_fcall trf_5634(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5634(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5634(t0,t1,t2);}

C_noret_decl(trf_6509)
static void C_fcall trf_6509(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6509(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6509(t0,t1,t2);}

C_noret_decl(trf_6247)
static void C_fcall trf_6247(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6247(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6247(t0,t1);}

C_noret_decl(trf_6430)
static void C_fcall trf_6430(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6430(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_6430(t0,t1);}

C_noret_decl(trf_6393)
static void C_fcall trf_6393(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6393(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6393(t0,t1,t2);}

C_noret_decl(trf_6330)
static void C_fcall trf_6330(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6330(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6330(t0,t1,t2);}

C_noret_decl(trf_6273)
static void C_fcall trf_6273(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6273(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6273(t0,t1,t2);}

C_noret_decl(trf_6140)
static void C_fcall trf_6140(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6140(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6140(t0,t1,t2);}

C_noret_decl(trf_6050)
static void C_fcall trf_6050(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_6050(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_6050(t0,t1,t2);}

C_noret_decl(trf_5952)
static void C_fcall trf_5952(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5952(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5952(t0,t1);}

C_noret_decl(trf_5962)
static void C_fcall trf_5962(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5962(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5962(t0,t1,t2);}

C_noret_decl(trf_5848)
static void C_fcall trf_5848(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5848(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5848(t0,t1,t2);}

C_noret_decl(trf_5875)
static void C_fcall trf_5875(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5875(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5875(t0,t1,t2);}

C_noret_decl(trf_5767)
static void C_fcall trf_5767(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5767(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5767(t0,t1);}

C_noret_decl(trf_5715)
static void C_fcall trf_5715(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5715(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5715(t0,t1,t2);}

C_noret_decl(trf_5040)
static void C_fcall trf_5040(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5040(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5040(t0,t1);}

C_noret_decl(trf_5218)
static void C_fcall trf_5218(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5218(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5218(t0,t1,t2);}

C_noret_decl(trf_5244)
static void C_fcall trf_5244(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5244(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5244(t0,t1);}

C_noret_decl(trf_5320)
static void C_fcall trf_5320(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5320(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5320(t0,t1);}

C_noret_decl(trf_5099)
static void C_fcall trf_5099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5099(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5099(t0,t1);}

C_noret_decl(trf_5133)
static void C_fcall trf_5133(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5133(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5133(t0,t1);}

C_noret_decl(trf_5167)
static void C_fcall trf_5167(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5167(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_5167(t0,t1);}

C_noret_decl(trf_5001)
static void C_fcall trf_5001(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_5001(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_5001(t0,t1,t2);}

C_noret_decl(trf_4955)
static void C_fcall trf_4955(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4955(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4955(t0,t1,t2);}

C_noret_decl(trf_4918)
static void C_fcall trf_4918(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4918(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4918(t0,t1);}

C_noret_decl(trf_4922)
static void C_fcall trf_4922(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4922(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4922(t0,t1,t2);}

C_noret_decl(trf_4607)
static void C_fcall trf_4607(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4607(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4607(t0,t1,t2);}

C_noret_decl(trf_4516)
static void C_fcall trf_4516(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4516(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4516(t0,t1,t2);}

C_noret_decl(trf_4461)
static void C_fcall trf_4461(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4461(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4461(t0,t1,t2);}

C_noret_decl(trf_4099)
static void C_fcall trf_4099(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4099(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4099(t0,t1,t2);}

C_noret_decl(trf_4127)
static void C_fcall trf_4127(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4127(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4127(t0,t1);}

C_noret_decl(trf_3991)
static void C_fcall trf_3991(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3991(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3991(t0,t1);}

C_noret_decl(trf_3866)
static void C_fcall trf_3866(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3866(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3866(t0,t1,t2,t3);}

C_noret_decl(trf_3813)
static void C_fcall trf_3813(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3813(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3813(t0,t1,t2);}

C_noret_decl(trf_3766)
static void C_fcall trf_3766(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3766(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3766(t0,t1);}

C_noret_decl(trf_3592)
static void C_fcall trf_3592(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3592(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3592(t0,t1,t2);}

C_noret_decl(trf_3614)
static void C_fcall trf_3614(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3614(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3614(t0,t1);}

C_noret_decl(trf_3621)
static void C_fcall trf_3621(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3621(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3621(t0,t1);}

C_noret_decl(trf_3536)
static void C_fcall trf_3536(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3536(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3536(t0,t1,t2,t3);}

C_noret_decl(trf_3442)
static void C_fcall trf_3442(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3442(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3442(t0,t1,t2,t3);}

C_noret_decl(trf_3392)
static void C_fcall trf_3392(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3392(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3392(t0,t1,t2,t3);}

C_noret_decl(trf_3371)
static void C_fcall trf_3371(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3371(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3371(t0,t1);}

C_noret_decl(trf_3331)
static void C_fcall trf_3331(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3331(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3331(t0,t1,t2);}

C_noret_decl(trf_3284)
static void C_fcall trf_3284(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3284(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3284(t0,t1);}

C_noret_decl(trf_3223)
static void C_fcall trf_3223(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3223(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3223(t0,t1,t2);}

C_noret_decl(tr7)
static void C_fcall tr7(C_proc7 k) C_regparm C_noret;
C_regparm static void C_fcall tr7(C_proc7 k){
C_word t6=C_pick(0);
C_word t5=C_pick(1);
C_word t4=C_pick(2);
C_word t3=C_pick(3);
C_word t2=C_pick(4);
C_word t1=C_pick(5);
C_word t0=C_pick(6);
C_adjust_stack(-7);
(k)(7,t0,t1,t2,t3,t4,t5,t6);}

C_noret_decl(tr6)
static void C_fcall tr6(C_proc6 k) C_regparm C_noret;
C_regparm static void C_fcall tr6(C_proc6 k){
C_word t5=C_pick(0);
C_word t4=C_pick(1);
C_word t3=C_pick(2);
C_word t2=C_pick(3);
C_word t1=C_pick(4);
C_word t0=C_pick(5);
C_adjust_stack(-6);
(k)(6,t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr9)
static void C_fcall tr9(C_proc9 k) C_regparm C_noret;
C_regparm static void C_fcall tr9(C_proc9 k){
C_word t8=C_pick(0);
C_word t7=C_pick(1);
C_word t6=C_pick(2);
C_word t5=C_pick(3);
C_word t4=C_pick(4);
C_word t3=C_pick(5);
C_word t2=C_pick(6);
C_word t1=C_pick(7);
C_word t0=C_pick(8);
C_adjust_stack(-9);
(k)(9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr5r)
static void C_fcall tr5r(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5r(C_proc5 k){
int n;
C_word *a,t5;
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
n=C_rest_count(0);
a=C_alloc(n*3);
t5=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4,t5);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

C_noret_decl(tr3r)
static void C_fcall tr3r(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3r(C_proc3 k){
int n;
C_word *a,t3;
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
n=C_rest_count(0);
a=C_alloc(n*3);
t3=C_restore_rest(a,n);
(k)(t0,t1,t2,t3);}

C_noret_decl(tr4r)
static void C_fcall tr4r(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4r(C_proc4 k){
int n;
C_word *a,t4;
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
n=C_rest_count(0);
a=C_alloc(n*3);
t4=C_restore_rest(a,n);
(k)(t0,t1,t2,t3,t4);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_support_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_support_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("support_toplevel"));
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(5210)){
C_save(t1);
C_rereclaim2(5210*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,503);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\033too many optional arguments");
lf[2]=C_h_intern(&lf[2],30,"\010compilercompiler-cleanup-hook");
lf[3]=C_h_intern(&lf[3],26,"\010compilerdebugging-chicken");
lf[4]=C_h_intern(&lf[4],26,"\010compilerdisabled-warnings");
lf[5]=C_h_intern(&lf[5],13,"\010compilerbomb");
lf[6]=C_h_intern(&lf[6],5,"error");
lf[7]=C_h_intern(&lf[7],13,"string-append");
lf[8]=C_decode_literal(C_heaptop,"\376B\000\000\032[internal compiler error] ");
lf[9]=C_decode_literal(C_heaptop,"\376B\000\000\031[internal compiler error]");
lf[10]=C_h_intern(&lf[10],18,"\010compilerdebugging");
lf[11]=C_h_intern(&lf[11],19,"\003sysstandard-output");
lf[12]=C_h_intern(&lf[12],12,"flush-output");
lf[13]=C_h_intern(&lf[13],7,"newline");
lf[14]=C_h_intern(&lf[14],19,"\003syswrite-char/port");
lf[15]=C_h_intern(&lf[15],5,"write");
lf[16]=C_h_intern(&lf[16],5,"force");
lf[17]=C_h_intern(&lf[17],7,"display");
lf[18]=C_decode_literal(C_heaptop,"\376B\000\000\002: ");
lf[19]=C_h_intern(&lf[19],4,"quit");
lf[20]=C_h_intern(&lf[20],4,"exit");
lf[21]=C_h_intern(&lf[21],7,"fprintf");
lf[22]=C_decode_literal(C_heaptop,"\376B\000\000\010\012Error: ");
lf[23]=C_h_intern(&lf[23],18,"current-error-port");
lf[24]=C_h_intern(&lf[24],21,"\003syssyntax-error-hook");
lf[25]=C_h_intern(&lf[25],16,"print-call-chain");
lf[26]=C_h_intern(&lf[26],18,"\003syscurrent-thread");
lf[27]=C_decode_literal(C_heaptop,"\376B\000\000\025\012\011Expansion history:\012");
lf[28]=C_decode_literal(C_heaptop,"\376B\000\000\005\011~s~%");
lf[29]=C_h_intern(&lf[29],12,"\003sysfor-each");
lf[30]=C_decode_literal(C_heaptop,"\376B\000\000\032\012Syntax error (~a): ~a~%~%");
lf[31]=C_decode_literal(C_heaptop,"\376B\000\000\025\012Syntax error: ~a~%~%");
lf[32]=C_h_intern(&lf[32],12,"syntax-error");
lf[33]=C_h_intern(&lf[33],31,"\010compileremit-syntax-trace-info");
lf[34]=C_h_intern(&lf[34],9,"map-llist");
lf[35]=C_h_intern(&lf[35],24,"\010compilercheck-signature");
lf[36]=C_decode_literal(C_heaptop,"\376B\000\000@Arguments to inlined call of `~A\047 do not match parameter-list ~A");
lf[37]=C_h_intern(&lf[37],18,"\010compilerreal-name");
lf[38]=C_h_intern(&lf[38],13,"\010compilerposq");
lf[39]=C_h_intern(&lf[39],18,"\010compilerstringify");
lf[40]=C_h_intern(&lf[40],14,"symbol->string");
lf[41]=C_h_intern(&lf[41],17,"get-output-string");
lf[42]=C_h_intern(&lf[42],18,"open-output-string");
lf[43]=C_h_intern(&lf[43],18,"\010compilersymbolify");
lf[44]=C_h_intern(&lf[44],14,"string->symbol");
lf[45]=C_h_intern(&lf[45],26,"\010compilerbuild-lambda-list");
lf[46]=C_h_intern(&lf[46],29,"\010compilerstring->c-identifier");
lf[47]=C_h_intern(&lf[47],24,"\003sysstring->c-identifier");
lf[48]=C_h_intern(&lf[48],21,"\010compilerc-ify-string");
lf[49]=C_h_intern(&lf[49],16,"\003syslist->string");
lf[50]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\377\016");
lf[51]=C_h_intern(&lf[51],6,"append");
lf[52]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\377\016");
lf[53]=C_h_intern(&lf[53],16,"\003sysstring->list");
lf[54]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[55]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\0000\376\377\016");
lf[56]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\042\376\003\000\000\002\376\377\012\000\000\047\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000\077\376\377\016");
lf[57]=C_h_intern(&lf[57],28,"\010compilervalid-c-identifier\077");
lf[58]=C_h_intern(&lf[58],3,"any");
lf[59]=C_h_intern(&lf[59],8,"->string");
lf[60]=C_h_intern(&lf[60],14,"\010compilerwords");
lf[61]=C_h_intern(&lf[61],21,"\010compilerwords->bytes");
lf[62]=C_h_intern(&lf[62],34,"\010compilercheck-and-open-input-file");
lf[63]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[64]=C_h_intern(&lf[64],18,"current-input-port");
lf[65]=C_h_intern(&lf[65],15,"open-input-file");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000\024Can not open file ~s");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\031(~a) can not open file ~s");
lf[68]=C_h_intern(&lf[68],12,"file-exists\077");
lf[69]=C_h_intern(&lf[69],33,"\010compilerclose-checked-input-file");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\001-");
lf[71]=C_h_intern(&lf[71],16,"close-input-port");
lf[72]=C_h_intern(&lf[72],19,"\010compilerfold-inner");
lf[73]=C_h_intern(&lf[73],7,"reverse");
lf[74]=C_h_intern(&lf[74],28,"\010compilerfollow-without-loop");
lf[75]=C_h_intern(&lf[75],21,"\010compilersort-symbols");
lf[76]=C_h_intern(&lf[76],8,"string<\077");
lf[77]=C_h_intern(&lf[77],4,"sort");
lf[78]=C_h_intern(&lf[78],18,"\010compilerconstant\077");
lf[79]=C_h_intern(&lf[79],5,"quote");
lf[80]=C_h_intern(&lf[80],29,"\010compilercollapsable-literal\077");
lf[81]=C_h_intern(&lf[81],19,"\010compilerimmediate\077");
lf[82]=C_h_intern(&lf[82],20,"\010compilerbig-fixnum\077");
lf[83]=C_h_intern(&lf[83],23,"\010compilerbasic-literal\077");
lf[84]=C_h_intern(&lf[84],5,"every");
lf[85]=C_h_intern(&lf[85],12,"vector->list");
lf[86]=C_h_intern(&lf[86],32,"\010compilercanonicalize-begin-body");
lf[87]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[88]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[89]=C_h_intern(&lf[89],3,"let");
lf[90]=C_h_intern(&lf[90],6,"gensym");
lf[91]=C_h_intern(&lf[91],1,"t");
lf[92]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010\003sysvoid\376\377\016");
lf[93]=C_h_intern(&lf[93],21,"\010compilerstring->expr");
lf[94]=C_decode_literal(C_heaptop,"\376B\000\000\042cannot parse expression: ~s [~a]~%");
lf[95]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\016\004coreundefined\376\377\016");
lf[96]=C_h_intern(&lf[96],5,"begin");
lf[97]=C_h_intern(&lf[97],10,"\003sysappend");
lf[98]=C_h_intern(&lf[98],4,"read");
lf[99]=C_h_intern(&lf[99],6,"unfold");
lf[100]=C_h_intern(&lf[100],11,"eof-object\077");
lf[101]=C_h_intern(&lf[101],6,"values");
lf[102]=C_h_intern(&lf[102],22,"with-input-from-string");
lf[103]=C_h_intern(&lf[103],22,"with-exception-handler");
lf[104]=C_h_intern(&lf[104],30,"call-with-current-continuation");
lf[105]=C_h_intern(&lf[105],30,"\010compilerdecompose-lambda-list");
lf[106]=C_h_intern(&lf[106],25,"\003sysdecompose-lambda-list");
lf[107]=C_h_intern(&lf[107],21,"\010compilerllist-length");
lf[108]=C_h_intern(&lf[108],30,"\010compilerexpand-profile-lambda");
lf[109]=C_h_intern(&lf[109],29,"\010compilerprofile-lambda-index");
lf[110]=C_h_intern(&lf[110],28,"\010compilerprofile-lambda-list");
lf[111]=C_h_intern(&lf[111],33,"\010compilerprofile-info-vector-name");
lf[112]=C_h_intern(&lf[112],17,"\003sysprofile-entry");
lf[113]=C_h_intern(&lf[113],6,"lambda");
lf[114]=C_h_intern(&lf[114],5,"apply");
lf[115]=C_h_intern(&lf[115],16,"\003sysprofile-exit");
lf[116]=C_h_intern(&lf[116],16,"\003sysdynamic-wind");
lf[117]=C_h_intern(&lf[117],10,"alist-cons");
lf[118]=C_h_intern(&lf[118],37,"\010compilerinitialize-analysis-database");
lf[119]=C_h_intern(&lf[119],8,"internal");
lf[120]=C_h_intern(&lf[120],8,"\003sysput!");
lf[121]=C_h_intern(&lf[121],18,"\010compilerintrinsic");
lf[122]=C_h_intern(&lf[122],9,"\003syserror");
lf[123]=C_h_intern(&lf[123],26,"\010compilerinternal-bindings");
lf[124]=C_h_intern(&lf[124],26,"\010compilerfoldable-bindings");
lf[125]=C_h_intern(&lf[125],17,"\010compilerfoldable");
lf[126]=C_h_intern(&lf[126],8,"extended");
lf[127]=C_h_intern(&lf[127],17,"extended-bindings");
lf[128]=C_h_intern(&lf[128],8,"standard");
lf[129]=C_h_intern(&lf[129],17,"standard-bindings");
lf[130]=C_h_intern(&lf[130],12,"\010compilerget");
lf[131]=C_h_intern(&lf[131],18,"\003syshash-table-ref");
lf[132]=C_h_intern(&lf[132],16,"\010compilerget-all");
lf[133]=C_h_intern(&lf[133],10,"filter-map");
lf[134]=C_h_intern(&lf[134],13,"\010compilerput!");
lf[135]=C_h_intern(&lf[135],19,"\003syshash-table-set!");
lf[136]=C_h_intern(&lf[136],17,"\010compilercollect!");
lf[137]=C_h_intern(&lf[137],15,"\010compilercount!");
lf[138]=C_h_intern(&lf[138],17,"\010compilerget-list");
lf[139]=C_h_intern(&lf[139],17,"\010compilerget-line");
lf[140]=C_h_intern(&lf[140],24,"\003sysline-number-database");
lf[141]=C_h_intern(&lf[141],19,"\010compilerget-line-2");
lf[142]=C_h_intern(&lf[142],30,"\010compilerfind-lambda-container");
lf[143]=C_h_intern(&lf[143],12,"contained-in");
lf[144]=C_h_intern(&lf[144],37,"\010compilerdisplay-line-number-database");
lf[145]=C_h_intern(&lf[145],3,"cdr");
lf[146]=C_h_intern(&lf[146],23,"\003syshash-table-for-each");
lf[147]=C_h_intern(&lf[147],34,"\010compilerdisplay-analysis-database");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\005\011css=");
lf[149]=C_decode_literal(C_heaptop,"\376B\000\000\006\011refs=");
lf[150]=C_decode_literal(C_heaptop,"\376B\000\000\005\011val=");
lf[151]=C_decode_literal(C_heaptop,"\376B\000\000\006\011lval=");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\006\011pval=");
lf[153]=C_h_intern(&lf[153],7,"unknown");
lf[154]=C_h_intern(&lf[154],8,"captured");
lf[155]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010captured\376\001\000\000\003cpt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010assigned\376\001\000\000\003set\376\003\000\000\002\376\003\000\000\002\376\001\000\000\005box"
"ed\376\001\000\000\003box\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006global\376\001\000\000\003glo\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020assigned-locally\376\001\000\000\003stl\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\014contractable\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020standard-binding\376\001\000\000\003stb\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\006simple\376\001\000\000\003sim\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011inlinable\376\001\000\000\003inl\376\003\000\000\002\376\003\000\000\002\376\001\000\000\013collapsable\376"
"\001\000\000\003col\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011removable\376\001\000\000\003rem\376\003\000\000\002\376\003\000\000\002\376\001\000\000\010constant\376\001\000\000\003con\376\003\000\000\002\376\003\000\000\002"
"\376\001\000\000\015inline-target\376\001\000\000\003ilt\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020inline-transient\376\001\000\000\003itr\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011"
"undefined\376\001\000\000\003und\376\003\000\000\002\376\003\000\000\002\376\001\000\000\011replacing\376\001\000\000\003rpg\376\003\000\000\002\376\003\000\000\002\376\001\000\000\006unused\376\001\000\000\003uud\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\020extended-binding\376\001\000\000\003xtb\376\003\000\000\002\376\003\000\000\002\376\001\000\000\015inline-export\376\001\000\000\003ilx\376\003\000\000\002\376\003"
"\000\000\002\376\001\000\000\014customizable\376\001\000\000\003cst\376\003\000\000\002\376\003\000\000\002\376\001\000\000\025has-unused-parameters\376\001\000\000\003hup\376\003\000\000\002\376\003\000"
"\000\002\376\001\000\000\012boxed-rest\376\001\000\000\003bxr\376\377\016");
lf[156]=C_h_intern(&lf[156],4,"caar");
lf[157]=C_h_intern(&lf[157],5,"value");
lf[158]=C_h_intern(&lf[158],4,"cdar");
lf[159]=C_h_intern(&lf[159],11,"local-value");
lf[160]=C_h_intern(&lf[160],15,"potential-value");
lf[161]=C_h_intern(&lf[161],10,"replacable");
lf[162]=C_h_intern(&lf[162],10,"references");
lf[163]=C_h_intern(&lf[163],10,"call-sites");
lf[164]=C_decode_literal(C_heaptop,"\376B\000\000\020Illegal property");
lf[165]=C_h_intern(&lf[165],4,"home");
lf[166]=C_h_intern(&lf[166],8,"contains");
lf[167]=C_h_intern(&lf[167],8,"use-expr");
lf[168]=C_h_intern(&lf[168],12,"closure-size");
lf[169]=C_h_intern(&lf[169],14,"rest-parameter");
lf[170]=C_h_intern(&lf[170],18,"captured-variables");
lf[171]=C_h_intern(&lf[171],13,"explicit-rest");
lf[172]=C_h_intern(&lf[172],8,"assigned");
lf[173]=C_h_intern(&lf[173],5,"boxed");
lf[174]=C_h_intern(&lf[174],6,"global");
lf[175]=C_h_intern(&lf[175],12,"contractable");
lf[176]=C_h_intern(&lf[176],16,"standard-binding");
lf[177]=C_h_intern(&lf[177],16,"assigned-locally");
lf[178]=C_h_intern(&lf[178],11,"collapsable");
lf[179]=C_h_intern(&lf[179],9,"removable");
lf[180]=C_h_intern(&lf[180],9,"undefined");
lf[181]=C_h_intern(&lf[181],9,"replacing");
lf[182]=C_h_intern(&lf[182],6,"unused");
lf[183]=C_h_intern(&lf[183],6,"simple");
lf[184]=C_h_intern(&lf[184],9,"inlinable");
lf[185]=C_h_intern(&lf[185],13,"inline-export");
lf[186]=C_h_intern(&lf[186],21,"has-unused-parameters");
lf[187]=C_h_intern(&lf[187],16,"extended-binding");
lf[188]=C_h_intern(&lf[188],12,"customizable");
lf[189]=C_h_intern(&lf[189],8,"constant");
lf[190]=C_h_intern(&lf[190],10,"boxed-rest");
lf[191]=C_h_intern(&lf[191],11,"hidden-refs");
lf[192]=C_h_intern(&lf[192],34,"\010compilerdefault-standard-bindings");
lf[193]=C_h_intern(&lf[193],34,"\010compilerdefault-extended-bindings");
lf[194]=C_h_intern(&lf[194],5,"node\077");
lf[195]=C_h_intern(&lf[195],4,"node");
lf[196]=C_h_intern(&lf[196],10,"node-class");
lf[197]=C_h_intern(&lf[197],15,"node-class-set!");
lf[198]=C_h_intern(&lf[198],14,"\003sysblock-set!");
lf[199]=C_h_intern(&lf[199],15,"node-parameters");
lf[200]=C_h_intern(&lf[200],20,"node-parameters-set!");
lf[201]=C_h_intern(&lf[201],19,"node-subexpressions");
lf[202]=C_h_intern(&lf[202],24,"node-subexpressions-set!");
lf[203]=C_h_intern(&lf[203],9,"make-node");
lf[204]=C_h_intern(&lf[204],16,"\010compilervarnode");
lf[205]=C_h_intern(&lf[205],13,"\004corevariable");
lf[206]=C_h_intern(&lf[206],14,"\010compilerqnode");
lf[207]=C_h_intern(&lf[207],25,"\010compilerbuild-node-graph");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\016bad expression");
lf[209]=C_h_intern(&lf[209],15,"\004coreglobal-ref");
lf[210]=C_h_intern(&lf[210],2,"if");
lf[211]=C_h_intern(&lf[211],14,"\004coreundefined");
lf[212]=C_h_intern(&lf[212],8,"truncate");
lf[213]=C_h_intern(&lf[213],7,"warning");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\0006literal is out of range - will be truncated to integer");
lf[215]=C_h_intern(&lf[215],6,"fixnum");
lf[216]=C_h_intern(&lf[216],11,"number-type");
lf[217]=C_h_intern(&lf[217],6,"unzip1");
lf[218]=C_h_intern(&lf[218],11,"\004corelambda");
lf[219]=C_h_intern(&lf[219],14,"\004coreprimitive");
lf[220]=C_h_intern(&lf[220],11,"\004coreinline");
lf[221]=C_h_intern(&lf[221],13,"\004corecallunit");
lf[222]=C_h_intern(&lf[222],9,"\004coreproc");
lf[223]=C_h_intern(&lf[223],4,"set!");
lf[224]=C_h_intern(&lf[224],9,"\004coreset!");
lf[225]=C_h_intern(&lf[225],29,"\004coreforeign-callback-wrapper");
lf[226]=C_h_intern(&lf[226],5,"sixth");
lf[227]=C_h_intern(&lf[227],5,"fifth");
lf[228]=C_h_intern(&lf[228],20,"\004coreinline_allocate");
lf[229]=C_h_intern(&lf[229],8,"\004coreapp");
lf[230]=C_h_intern(&lf[230],9,"\004corecall");
lf[231]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\001\376\377\016");
lf[232]=C_h_intern(&lf[232],28,"\003syssymbol->qualified-string");
lf[233]=C_h_intern(&lf[233],7,"\003sysget");
lf[234]=C_h_intern(&lf[234],34,"\010compileralways-bound-to-procedure");
lf[235]=C_h_intern(&lf[235],15,"\004coreinline_ref");
lf[236]=C_h_intern(&lf[236],18,"\004coreinline_update");
lf[237]=C_h_intern(&lf[237],19,"\004coreinline_loc_ref");
lf[238]=C_h_intern(&lf[238],22,"\004coreinline_loc_update");
lf[239]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\006\000\376\377\016");
lf[240]=C_h_intern(&lf[240],1,"o");
lf[241]=C_decode_literal(C_heaptop,"\376B\000\000\033eliminated procedure checks");
lf[242]=C_h_intern(&lf[242],30,"\010compilerbuild-expression-tree");
lf[243]=C_h_intern(&lf[243],12,"\004coreclosure");
lf[244]=C_h_intern(&lf[244],4,"last");
lf[245]=C_h_intern(&lf[245],4,"list");
lf[246]=C_h_intern(&lf[246],7,"butlast");
lf[247]=C_h_intern(&lf[247],5,"cons*");
lf[248]=C_h_intern(&lf[248],9,"\004corebind");
lf[249]=C_h_intern(&lf[249],10,"\004coreunbox");
lf[250]=C_h_intern(&lf[250],16,"\004corelet_unboxed");
lf[251]=C_h_intern(&lf[251],8,"\004coreref");
lf[252]=C_h_intern(&lf[252],11,"\004coreupdate");
lf[253]=C_h_intern(&lf[253],13,"\004coreupdate_i");
lf[254]=C_h_intern(&lf[254],8,"\004corebox");
lf[255]=C_h_intern(&lf[255],9,"\004corecond");
lf[256]=C_h_intern(&lf[256],21,"\010compilerfold-boolean");
lf[257]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\005C_and\376\377\016");
lf[258]=C_h_intern(&lf[258],31,"\010compilerinline-lambda-bindings");
lf[259]=C_h_intern(&lf[259],8,"split-at");
lf[260]=C_h_intern(&lf[260],10,"fold-right");
lf[261]=C_h_intern(&lf[261],4,"take");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\012C_a_i_list");
lf[263]=C_h_intern(&lf[263],34,"\010compilercopy-node-tree-and-rename");
lf[264]=C_h_intern(&lf[264],9,"alist-ref");
lf[265]=C_h_intern(&lf[265],3,"eq\077");
lf[266]=C_h_intern(&lf[266],7,"\003sysmap");
lf[267]=C_h_intern(&lf[267],1,"f");
lf[268]=C_h_intern(&lf[268],4,"cons");
lf[269]=C_h_intern(&lf[269],16,"inline-transient");
lf[270]=C_h_intern(&lf[270],18,"\010compilertree-copy");
lf[271]=C_h_intern(&lf[271],19,"\010compilercopy-node!");
lf[272]=C_h_intern(&lf[272],20,"\010compilernode->sexpr");
lf[273]=C_h_intern(&lf[273],20,"\010compilersexpr->node");
lf[274]=C_h_intern(&lf[274],32,"\010compileremit-global-inline-file");
lf[275]=C_h_intern(&lf[275],5,"print");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[277]=C_h_intern(&lf[277],1,"i");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\0001the following procedures can be globally inlined:");
lf[279]=C_h_intern(&lf[279],12,"delete-file*");
lf[280]=C_decode_literal(C_heaptop,"\376B\000\000\015; END OF FILE");
lf[281]=C_h_intern(&lf[281],2,"pp");
lf[282]=C_decode_literal(C_heaptop,"\376B\000\000\027; GENERATED BY CHICKEN ");
lf[283]=C_decode_literal(C_heaptop,"\376B\000\000\006 FROM ");
lf[284]=C_h_intern(&lf[284],24,"\010compilersource-filename");
lf[285]=C_decode_literal(C_heaptop,"\376B\000\000\001\012");
lf[286]=C_h_intern(&lf[286],15,"chicken-version");
lf[287]=C_h_intern(&lf[287],19,"with-output-to-file");
lf[288]=C_h_intern(&lf[288],3,"yes");
lf[289]=C_h_intern(&lf[289],2,"no");
lf[290]=C_h_intern(&lf[290],24,"\010compilerinline-max-size");
lf[291]=C_h_intern(&lf[291],15,"\010compilerinline");
lf[292]=C_h_intern(&lf[292],22,"\010compilerinline-global");
lf[293]=C_h_intern(&lf[293],26,"\010compilervariable-visible\077");
lf[294]=C_h_intern(&lf[294],25,"\010compilerload-inline-file");
lf[295]=C_h_intern(&lf[295],20,"with-input-from-file");
lf[296]=C_h_intern(&lf[296],19,"\010compilermatch-node");
lf[297]=C_h_intern(&lf[297],1,"a");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\007matched");
lf[299]=C_h_intern(&lf[299],37,"\010compilerexpression-has-side-effects\077");
lf[300]=C_h_intern(&lf[300],24,"foreign-callback-stub-id");
lf[301]=C_h_intern(&lf[301],4,"find");
lf[302]=C_h_intern(&lf[302],22,"foreign-callback-stubs");
lf[303]=C_h_intern(&lf[303],28,"\010compilersimple-lambda-node\077");
lf[304]=C_h_intern(&lf[304],31,"\010compilerdump-undefined-globals");
lf[305]=C_h_intern(&lf[305],8,"keyword\077");
lf[306]=C_h_intern(&lf[306],29,"\010compilerdump-defined-globals");
lf[307]=C_h_intern(&lf[307],25,"\010compilerdump-global-refs");
lf[308]=C_h_intern(&lf[308],28,"\003systoplevel-definition-hook");
lf[309]=C_h_intern(&lf[309],22,"\010compilerhide-variable");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\042hiding nonexported module bindings");
lf[311]=C_h_intern(&lf[311],36,"\010compilercompute-database-statistics");
lf[312]=C_h_intern(&lf[312],29,"\010compilercurrent-program-size");
lf[313]=C_h_intern(&lf[313],30,"\010compileroriginal-program-size");
lf[314]=C_h_intern(&lf[314],33,"\010compilerprint-program-statistics");
lf[315]=C_decode_literal(C_heaptop,"\376B\000\000\027;   database entries: \011");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known call sites: \011");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\027;   global variables: \011");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\027;   known procedures: \011");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\042;   variables with known values: \011");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\032 \011original program size: \011");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\023;   program size: \011");
lf[322]=C_h_intern(&lf[322],1,"s");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\023program statistics:");
lf[324]=C_h_intern(&lf[324],35,"\010compilerpprint-expressions-to-file");
lf[325]=C_h_intern(&lf[325],17,"close-output-port");
lf[326]=C_h_intern(&lf[326],12,"pretty-print");
lf[327]=C_h_intern(&lf[327],19,"with-output-to-port");
lf[328]=C_h_intern(&lf[328],16,"open-output-file");
lf[329]=C_h_intern(&lf[329],19,"current-output-port");
lf[330]=C_h_intern(&lf[330],27,"\010compilerforeign-type-check");
lf[331]=C_h_intern(&lf[331],4,"char");
lf[332]=C_h_intern(&lf[332],13,"unsigned-char");
lf[333]=C_h_intern(&lf[333],6,"unsafe");
lf[334]=C_h_intern(&lf[334],25,"\003sysforeign-char-argument");
lf[335]=C_h_intern(&lf[335],3,"int");
lf[336]=C_h_intern(&lf[336],27,"\003sysforeign-fixnum-argument");
lf[337]=C_h_intern(&lf[337],5,"float");
lf[338]=C_h_intern(&lf[338],27,"\003sysforeign-flonum-argument");
lf[339]=C_h_intern(&lf[339],7,"pointer");
lf[340]=C_h_intern(&lf[340],26,"\003sysforeign-block-argument");
lf[341]=C_h_intern(&lf[341],15,"nonnull-pointer");
lf[342]=C_h_intern(&lf[342],8,"u8vector");
lf[343]=C_h_intern(&lf[343],34,"\003sysforeign-number-vector-argument");
lf[344]=C_h_intern(&lf[344],16,"nonnull-u8vector");
lf[345]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-u8vector\376\001\000\000\010u8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u16vector\376\001\000\000"
"\011u16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\020nonnull-s8vector\376\001\000\000\010s8vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-s16"
"vector\376\001\000\000\011s16vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-u32vector\376\001\000\000\011u32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000"
"\021nonnull-s32vector\376\001\000\000\011s32vector\376\003\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f32vector\376\001\000\000\011f32vector\376\003"
"\000\000\002\376\003\000\000\002\376\001\000\000\021nonnull-f64vector\376\001\000\000\011f64vector\376\377\016");
lf[346]=C_h_intern(&lf[346],7,"integer");
lf[347]=C_h_intern(&lf[347],28,"\003sysforeign-integer-argument");
lf[348]=C_h_intern(&lf[348],16,"unsigned-integer");
lf[349]=C_h_intern(&lf[349],37,"\003sysforeign-unsigned-integer-argument");
lf[350]=C_h_intern(&lf[350],9,"c-pointer");
lf[351]=C_h_intern(&lf[351],28,"\003sysforeign-pointer-argument");
lf[352]=C_h_intern(&lf[352],17,"nonnull-c-pointer");
lf[353]=C_h_intern(&lf[353],8,"c-string");
lf[354]=C_h_intern(&lf[354],17,"\003sysmake-c-string");
lf[355]=C_h_intern(&lf[355],27,"\003sysforeign-string-argument");
lf[356]=C_h_intern(&lf[356],16,"nonnull-c-string");
lf[357]=C_h_intern(&lf[357],6,"symbol");
lf[358]=C_h_intern(&lf[358],18,"\003syssymbol->string");
lf[359]=C_h_intern(&lf[359],3,"ref");
lf[360]=C_h_intern(&lf[360],8,"instance");
lf[361]=C_h_intern(&lf[361],12,"instance-ref");
lf[362]=C_h_intern(&lf[362],4,"this");
lf[363]=C_h_intern(&lf[363],8,"slot-ref");
lf[364]=C_h_intern(&lf[364],16,"nonnull-instance");
lf[365]=C_h_intern(&lf[365],5,"const");
lf[366]=C_h_intern(&lf[366],4,"enum");
lf[367]=C_h_intern(&lf[367],8,"function");
lf[368]=C_h_intern(&lf[368],27,"\010compilerforeign-type-table");
lf[369]=C_h_intern(&lf[369],17,"nonnull-c-string*");
lf[370]=C_h_intern(&lf[370],26,"nonnull-unsigned-c-string*");
lf[371]=C_h_intern(&lf[371],9,"c-string*");
lf[372]=C_h_intern(&lf[372],17,"unsigned-c-string");
lf[373]=C_h_intern(&lf[373],18,"unsigned-c-string*");
lf[374]=C_h_intern(&lf[374],13,"c-string-list");
lf[375]=C_h_intern(&lf[375],14,"c-string-list*");
lf[376]=C_h_intern(&lf[376],18,"unsigned-integer32");
lf[377]=C_h_intern(&lf[377],13,"unsigned-long");
lf[378]=C_h_intern(&lf[378],4,"long");
lf[379]=C_h_intern(&lf[379],9,"integer32");
lf[380]=C_h_intern(&lf[380],17,"nonnull-u16vector");
lf[381]=C_h_intern(&lf[381],16,"nonnull-s8vector");
lf[382]=C_h_intern(&lf[382],17,"nonnull-s16vector");
lf[383]=C_h_intern(&lf[383],17,"nonnull-u32vector");
lf[384]=C_h_intern(&lf[384],17,"nonnull-s32vector");
lf[385]=C_h_intern(&lf[385],17,"nonnull-f32vector");
lf[386]=C_h_intern(&lf[386],17,"nonnull-f64vector");
lf[387]=C_h_intern(&lf[387],9,"u16vector");
lf[388]=C_h_intern(&lf[388],8,"s8vector");
lf[389]=C_h_intern(&lf[389],9,"s16vector");
lf[390]=C_h_intern(&lf[390],9,"u32vector");
lf[391]=C_h_intern(&lf[391],9,"s32vector");
lf[392]=C_h_intern(&lf[392],9,"f32vector");
lf[393]=C_h_intern(&lf[393],9,"f64vector");
lf[394]=C_h_intern(&lf[394],22,"nonnull-scheme-pointer");
lf[395]=C_h_intern(&lf[395],12,"nonnull-blob");
lf[396]=C_h_intern(&lf[396],19,"nonnull-byte-vector");
lf[397]=C_h_intern(&lf[397],11,"byte-vector");
lf[398]=C_h_intern(&lf[398],4,"blob");
lf[399]=C_h_intern(&lf[399],14,"scheme-pointer");
lf[400]=C_h_intern(&lf[400],6,"double");
lf[401]=C_h_intern(&lf[401],6,"number");
lf[402]=C_h_intern(&lf[402],12,"unsigned-int");
lf[403]=C_h_intern(&lf[403],5,"short");
lf[404]=C_h_intern(&lf[404],14,"unsigned-short");
lf[405]=C_h_intern(&lf[405],4,"byte");
lf[406]=C_h_intern(&lf[406],13,"unsigned-byte");
lf[407]=C_h_intern(&lf[407],5,"int32");
lf[408]=C_h_intern(&lf[408],14,"unsigned-int32");
lf[409]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[410]=C_h_intern(&lf[410],36,"\010compilerforeign-type-convert-result");
lf[411]=C_h_intern(&lf[411],38,"\010compilerforeign-type-convert-argument");
lf[412]=C_h_intern(&lf[412],27,"\010compilerfinal-foreign-type");
lf[413]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[414]=C_h_intern(&lf[414],37,"\010compilerestimate-foreign-result-size");
lf[415]=C_h_intern(&lf[415],9,"integer64");
lf[416]=C_h_intern(&lf[416],4,"bool");
lf[417]=C_h_intern(&lf[417],4,"void");
lf[418]=C_h_intern(&lf[418],13,"scheme-object");
lf[419]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[420]=C_h_intern(&lf[420],46,"\010compilerestimate-foreign-result-location-size");
lf[421]=C_decode_literal(C_heaptop,"\376B\000\0005cannot compute size of location for foreign type `~S\047");
lf[422]=C_decode_literal(C_heaptop,"\376B\000\000\042foreign type `~S\047 refers to itself");
lf[423]=C_h_intern(&lf[423],30,"\010compilerfinish-foreign-result");
lf[424]=C_h_intern(&lf[424],17,"\003syspeek-c-string");
lf[425]=C_h_intern(&lf[425],25,"\003syspeek-nonnull-c-string");
lf[426]=C_h_intern(&lf[426],26,"\003syspeek-and-free-c-string");
lf[427]=C_h_intern(&lf[427],34,"\003syspeek-and-free-nonnull-c-string");
lf[428]=C_h_intern(&lf[428],17,"\003sysintern-symbol");
lf[429]=C_h_intern(&lf[429],22,"\003syspeek-c-string-list");
lf[430]=C_h_intern(&lf[430],31,"\003syspeek-and-free-c-string-list");
lf[431]=C_h_intern(&lf[431],17,"\003sysnull-pointer\077");
lf[432]=C_h_intern(&lf[432],3,"not");
lf[433]=C_h_intern(&lf[433],4,"make");
lf[434]=C_h_intern(&lf[434],3,"and");
lf[435]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\001\000\000\010instance\376\003\000\000\002\376\001\000\000\014instance-ref\376\377\016");
lf[436]=C_h_intern(&lf[436],28,"\010compilerscan-used-variables");
lf[437]=C_h_intern(&lf[437],28,"\010compilerscan-free-variables");
lf[438]=C_h_intern(&lf[438],11,"lset-adjoin");
lf[439]=C_h_intern(&lf[439],23,"\010compilerchop-separator");
lf[440]=C_h_intern(&lf[440],9,"substring");
lf[441]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000\134\376\003\000\000\002\376\377\012\000\000/\376\377\016");
lf[442]=C_h_intern(&lf[442],23,"\010compilerchop-extension");
lf[443]=C_h_intern(&lf[443],22,"\010compilerprint-version");
lf[444]=C_h_intern(&lf[444],6,"print*");
lf[445]=C_decode_literal(C_heaptop,"\376B\000\000\077(c)2008-2010 The Chicken Team\012(c)2000-2007 Felix L. Winkelmann\012");
lf[446]=C_h_intern(&lf[446],20,"\010compilerprint-usage");
lf[447]=C_decode_literal(C_heaptop,"\376B\000\030\373Usage: chicken FILENAME OPTION ...\012\012  `chicken\047 is the CHICKEN compiler.\012  "
"\012  FILENAME should be a complete source file name with extension, or \042-\042 for\012  s"
"tandard input. OPTION may be one of the following:\012\012  General options:\012\012    -hel"
"p                        display this text and exit\012    -version                "
"     display compiler version and exit\012    -release                     print re"
"lease number and exit\012    -verbose                     display information on co"
"mpilation progress\012\012  File and pathname options:\012\012    -output-file FILENAME     "
"   specifies output-filename, default is \047out.c\047\012    -include-path PATHNAME     "
"  specifies alternative path for included files\012    -to-stdout                  "
" write compiled file to stdout instead of file\012\012  Language options:\012\012    -featur"
"e SYMBOL              register feature identifier\012    -no-feature SYMBOL        "
"   disable built-in feature identifier\012\012  Syntax related options:\012\012    -case-ins"
"ensitive            don\047t preserve case of read symbols\012    -keyword-style STYLE"
"         allow alternative keyword syntax\012                                  (pre"
"fix, suffix or none)\012    -no-parentheses-synonyms     disables list delimiter sy"
"nonyms\012    -no-symbol-escape            disables support for escaped symbols\012   "
" -r5rs-syntax                 disables the Chicken extensions to\012               "
"                   R5RS syntax\012    -compile-syntax              macros are made "
"available at run-time\012    -emit-import-library MODULE  write compile-time module"
" information into\012                                  separate file\012    -emit-all-"
"import-libraries   emit import-libraries for all defined modules\012    -no-module-"
"registration      do not generate module registration code\012    -no-compiler-synt"
"ax          disable expansion of compiler-macros\012\012  Translation options:\012\012    -e"
"xplicit-use                do not use units \047library\047 and \047eval\047 by\012            "
"                      default\012    -check-syntax                stop compilation "
"after macro-expansion\012    -analyze-only                stop compilation after fi"
"rst analysis pass\012\012  Debugging options:\012\012    -no-warnings                 disabl"
"e warnings\012    -debug-level NUMBER          set level of available debugging inf"
"ormation\012    -no-trace                    disable tracing information\012    -profi"
"le                     executable emits profiling information \012    -profile-name"
" FILENAME       name of the generated profile information file\012    -accumulate-p"
"rofile          executable emits profiling information in\012                      "
"            append mode\012    -no-lambda-info              omit additional procedu"
"re-information\012    -scrutinize                  perform local flow analysis\012    "
"-types FILENAME              load additional type database\012\012  Optimization optio"
"ns:\012\012    -optimize-level NUMBER       enable certain sets of optimization option"
"s\012    -optimize-leaf-routines      enable leaf routine optimization\012    -lambda-"
"lift                 enable lambda-lifting\012    -no-usual-integrations       stan"
"dard procedures may be redefined\012    -unsafe                      disable all sa"
"fety checks\012    -local                       assume globals are only modified in"
" current\012                                  file\012    -block                      "
" enable block-compilation\012    -disable-interrupts          disable interrupts in"
" compiled code\012    -fixnum-arithmetic           assume all numbers are fixnums\012 "
"   -benchmark-mode              equivalent to \047block -optimize-level 4\012         "
"                         -debug-level 0 -fixnum-arithmetic -lambda-lift\012        "
"                          -inline -disable-interrupts\047\012    -disable-stack-overfl"
"ow-checks  disables detection of stack-overflows\012    -inline                    "
"  enable inlining\012    -inline-limit                set inlining threshold\012    -i"
"nline-global               enable cross-module inlining\012    -unboxing           "
"         use unboxed temporaries if possible\012    -emit-inline-file FILENAME   ge"
"nerate file with globally inlinable\012                                  procedures"
" (implies -inline -local)\012    -consult-inline-file FILENAME  explicitly load inl"
"ine file\012    -no-argc-checks              disable argument count checks\012    -no-"
"bound-checks             disable bound variable checks\012    -no-procedure-checks "
"        disable procedure call checks\012    -no-procedure-checks-for-usual-binding"
"s\012                                 disable procedure call checks only for usual\012"
"                                  bindings\012    -no-procedure-checks-for-toplevel"
"-bindings\012                                   disable procedure call checks for t"
"oplevel\012                                    bindings\012\012  Configuration options:\012\012"
"    -unit NAME                   compile file as a library unit\012    -uses NAME  "
"                 declare library unit as used.\012    -heap-size NUMBER            "
"specifies heap-size of compiled executable\012    -heap-initial-size NUMBER    spec"
"ifies heap-size at startup time\012    -heap-growth PERCENTAGE      specifies growt"
"h-rate of expanding heap\012    -heap-shrinkage PERCENTAGE   specifies shrink-rate "
"of contracting heap\012    -nursery NUMBER  -stack-size NUMBER\012                    "
"             specifies nursery size of compiled executable\012    -extend FILENAME "
"            load file before compilation commences\012    -prelude EXPRESSION      "
"    add expression to front of source file\012    -postlude EXPRESSION         add "
"expression to end of source file\012    -prologue FILENAME           include file b"
"efore main source file\012    -epilogue FILENAME           include file after main "
"source file\012    -dynamic                     compile as dynamically loadable cod"
"e\012    -require-extension NAME      require and import extension NAME\012    -static"
"-extension NAME       import extension NAME but link statically\012                "
"                  (if available)\012\012  Obscure options:\012\012    -debug MODES          "
"       display debugging output for the given modes\012    -raw                    "
"     do not generate implicit init- and exit code                           \012   "
" -emit-external-prototypes-first\012                                 emit prototype"
"s for callbacks before foreign\012                                  declarations\012  "
"  -ignore-repository           do not refer to repository for extensions\012    -se"
"tup-mode                  prefer the current directory when locating extensions\012"
);
lf[448]=C_h_intern(&lf[448],36,"\010compilermake-block-variable-literal");
lf[449]=C_h_intern(&lf[449],22,"block-variable-literal");
lf[450]=C_h_intern(&lf[450],32,"\010compilerblock-variable-literal\077");
lf[451]=C_h_intern(&lf[451],36,"\010compilerblock-variable-literal-name");
lf[452]=C_h_intern(&lf[452],27,"block-variable-literal-name");
lf[453]=C_h_intern(&lf[453],25,"\010compilermake-random-name");
lf[454]=C_h_intern(&lf[454],6,"random");
lf[455]=C_h_intern(&lf[455],15,"current-seconds");
lf[456]=C_h_intern(&lf[456],23,"\010compilerset-real-name!");
lf[457]=C_h_intern(&lf[457],24,"\010compilerreal-name-table");
lf[458]=C_decode_literal(C_heaptop,"\376B\000\000\004 in ");
lf[459]=C_h_intern(&lf[459],19,"\010compilerreal-name2");
lf[460]=C_h_intern(&lf[460],32,"\010compilerdisplay-real-name-table");
lf[461]=C_h_intern(&lf[461],28,"\010compilersource-info->string");
lf[462]=C_h_intern(&lf[462],4,"conc");
lf[463]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[464]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[465]=C_h_intern(&lf[465],11,"make-string");
lf[466]=C_h_intern(&lf[466],3,"max");
lf[467]=C_h_intern(&lf[467],26,"\010compilersource-info->line");
lf[468]=C_h_intern(&lf[468],12,"string-null\077");
lf[469]=C_h_intern(&lf[469],19,"\010compilerdump-nodes");
lf[470]=C_h_intern(&lf[470],23,"\010compilerread-info-hook");
lf[471]=C_h_intern(&lf[471],27,"\003syscurrent-source-filename");
lf[472]=C_decode_literal(C_heaptop,"\376B\000\000\001:");
lf[473]=C_h_intern(&lf[473],9,"list-info");
lf[474]=C_h_intern(&lf[474],25,"\010compilerread/source-info");
lf[475]=C_h_intern(&lf[475],8,"\003sysread");
lf[476]=C_h_intern(&lf[476],18,"\003sysuser-read-hook");
lf[477]=C_h_intern(&lf[477],15,"foreign-declare");
lf[478]=C_h_intern(&lf[478],7,"declare");
lf[479]=C_h_intern(&lf[479],34,"\010compilerscan-sharp-greater-string");
lf[480]=C_h_intern(&lf[480],18,"\003sysread-char/port");
lf[481]=C_decode_literal(C_heaptop,"\376B\000\000&unexpected end of `#> ... <#\047 sequence");
lf[482]=C_h_intern(&lf[482],6,"hidden");
lf[483]=C_h_intern(&lf[483],19,"\010compilervisibility");
lf[484]=C_h_intern(&lf[484],24,"\010compilerexport-variable");
lf[485]=C_h_intern(&lf[485],8,"exported");
lf[486]=C_h_intern(&lf[486],26,"\010compilerblock-compilation");
lf[487]=C_h_intern(&lf[487],22,"\010compilermark-variable");
lf[488]=C_h_intern(&lf[488],22,"\010compilervariable-mark");
lf[489]=C_h_intern(&lf[489],19,"\010compilerintrinsic\077");
lf[490]=C_h_intern(&lf[490],9,"foldable\077");
lf[491]=C_h_intern(&lf[491],33,"\010compilerload-identifier-database");
lf[492]=C_h_intern(&lf[492],7,"\004coredb");
lf[493]=C_h_intern(&lf[493],9,"read-file");
lf[494]=C_h_intern(&lf[494],21,"\010compilerverbose-mode");
lf[495]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[496]=C_decode_literal(C_heaptop,"\376B\000\000\034loading identifier database ");
lf[497]=C_h_intern(&lf[497],13,"make-pathname");
lf[498]=C_h_intern(&lf[498],15,"repository-path");
lf[499]=C_h_intern(&lf[499],27,"condition-property-accessor");
lf[500]=C_h_intern(&lf[500],3,"exn");
lf[501]=C_h_intern(&lf[501],7,"message");
lf[502]=C_h_intern(&lf[502],19,"condition-predicate");
C_register_lf2(lf,503,create_ptable());
t2=C_mutate(&lf[0] /* (set! c358 ...) */,lf[1]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3154,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t3);}

/* k3152 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3157,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k3155 in k3152 */
static void C_ccall f_3157(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word ab[55],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3157,2,t0,t1);}
t2=C_mutate((C_word*)lf[2]+1 /* (set! ##compiler#compiler-cleanup-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3161,tmp=(C_word)a,a+=2,tmp));
t3=C_set_block_item(lf[3] /* debugging-chicken */,0,C_SCHEME_END_OF_LIST);
t4=C_set_block_item(lf[4] /* disabled-warnings */,0,C_SCHEME_END_OF_LIST);
t5=C_mutate((C_word*)lf[5]+1 /* (set! ##compiler#bomb ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3166,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate((C_word*)lf[10]+1 /* (set! ##compiler#debugging ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3193,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate((C_word*)lf[19]+1 /* (set! quit ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3258,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate((C_word*)lf[24]+1 /* (set! ##sys#syntax-error-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3277,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate((C_word*)lf[32]+1 /* (set! syntax-error ...) */,*((C_word*)lf[24]+1));
t10=C_mutate((C_word*)lf[33]+1 /* (set! ##compiler#emit-syntax-trace-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3322,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[34]+1 /* (set! map-llist ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3325,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[35]+1 /* (set! ##compiler#check-signature ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3368,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[38]+1 /* (set! ##compiler#posq ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3436,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[39]+1 /* (set! ##compiler#stringify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3472,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[43]+1 /* (set! ##compiler#symbolify ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3499,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[45]+1 /* (set! ##compiler#build-lambda-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3530,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[46]+1 /* (set! ##compiler#string->c-identifier ...) */,*((C_word*)lf[47]+1));
t18=C_mutate((C_word*)lf[48]+1 /* (set! ##compiler#c-ify-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3574,tmp=(C_word)a,a+=2,tmp));
t19=C_mutate((C_word*)lf[57]+1 /* (set! ##compiler#valid-c-identifier? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3668,tmp=(C_word)a,a+=2,tmp));
t20=C_mutate((C_word*)lf[60]+1 /* (set! ##compiler#words ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3724,tmp=(C_word)a,a+=2,tmp));
t21=C_mutate((C_word*)lf[61]+1 /* (set! ##compiler#words->bytes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3731,tmp=(C_word)a,a+=2,tmp));
t22=C_mutate((C_word*)lf[62]+1 /* (set! ##compiler#check-and-open-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3738,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[69]+1 /* (set! ##compiler#close-checked-input-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3785,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[72]+1 /* (set! ##compiler#fold-inner ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3797,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[74]+1 /* (set! ##compiler#follow-without-loop ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3860,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[75]+1 /* (set! ##compiler#sort-symbols ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3891,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[78]+1 /* (set! ##compiler#constant? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3911,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[80]+1 /* (set! ##compiler#collapsable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3957,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[81]+1 /* (set! ##compiler#immediate? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3987,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[83]+1 /* (set! ##compiler#basic-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4033,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[86]+1 /* (set! ##compiler#canonicalize-begin-body ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4093,tmp=(C_word)a,a+=2,tmp));
t32=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4190,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:249: condition-predicate */
t33=*((C_word*)lf[502]+1);
((C_proc3)(void*)(*((C_word*)t33+1)))(3,t33,t32,lf[500]);}

/* k4188 in k3155 in k3152 */
static void C_ccall f_4190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4190,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4193,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:250: condition-property-accessor */
t3=*((C_word*)lf[499]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[500],lf[501]);}

/* k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word ab[177],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4193,2,t0,t1);}
t2=C_mutate((C_word*)lf[93]+1 /* (set! ##compiler#string->expr ...) */,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4194,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp));
t3=C_mutate((C_word*)lf[105]+1 /* (set! ##compiler#decompose-lambda-list ...) */,*((C_word*)lf[106]+1));
t4=C_mutate((C_word*)lf[107]+1 /* (set! ##compiler#llist-length ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4301,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate((C_word*)lf[108]+1 /* (set! ##compiler#expand-profile-lambda ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4304,tmp=(C_word)a,a+=2,tmp));
t6=C_SCHEME_TRUE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_mutate((C_word*)lf[118]+1 /* (set! ##compiler#initialize-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4445,a[2]=t7,tmp=(C_word)a,a+=3,tmp));
t9=C_mutate((C_word*)lf[130]+1 /* (set! ##compiler#get ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4698,tmp=(C_word)a,a+=2,tmp));
t10=C_mutate((C_word*)lf[132]+1 /* (set! ##compiler#get-all ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4716,tmp=(C_word)a,a+=2,tmp));
t11=C_mutate((C_word*)lf[134]+1 /* (set! ##compiler#put! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4734,tmp=(C_word)a,a+=2,tmp));
t12=C_mutate((C_word*)lf[136]+1 /* (set! ##compiler#collect! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4780,tmp=(C_word)a,a+=2,tmp));
t13=C_mutate((C_word*)lf[137]+1 /* (set! ##compiler#count! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4832,tmp=(C_word)a,a+=2,tmp));
t14=C_mutate((C_word*)lf[138]+1 /* (set! ##compiler#get-list ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4889,tmp=(C_word)a,a+=2,tmp));
t15=C_mutate((C_word*)lf[139]+1 /* (set! ##compiler#get-line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4898,tmp=(C_word)a,a+=2,tmp));
t16=C_mutate((C_word*)lf[141]+1 /* (set! ##compiler#get-line-2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4908,tmp=(C_word)a,a+=2,tmp));
t17=C_mutate((C_word*)lf[142]+1 /* (set! ##compiler#find-lambda-container ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4949,tmp=(C_word)a,a+=2,tmp));
t18=C_mutate((C_word*)lf[144]+1 /* (set! ##compiler#display-line-number-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4973,tmp=(C_word)a,a+=2,tmp));
t19=C_SCHEME_FALSE;
t20=(*a=C_VECTOR_TYPE|1,a[1]=t19,tmp=(C_word)a,a+=2,tmp);
t21=C_mutate((C_word*)lf[147]+1 /* (set! ##compiler#display-analysis-database ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5036,a[2]=t20,tmp=(C_word)a,a+=3,tmp));
t22=C_mutate((C_word*)lf[194]+1 /* (set! node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5535,tmp=(C_word)a,a+=2,tmp));
t23=C_mutate((C_word*)lf[196]+1 /* (set! node-class ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5541,tmp=(C_word)a,a+=2,tmp));
t24=C_mutate((C_word*)lf[197]+1 /* (set! node-class-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5550,tmp=(C_word)a,a+=2,tmp));
t25=C_mutate((C_word*)lf[199]+1 /* (set! node-parameters ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5559,tmp=(C_word)a,a+=2,tmp));
t26=C_mutate((C_word*)lf[200]+1 /* (set! node-parameters-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5568,tmp=(C_word)a,a+=2,tmp));
t27=C_mutate((C_word*)lf[201]+1 /* (set! node-subexpressions ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5577,tmp=(C_word)a,a+=2,tmp));
t28=C_mutate((C_word*)lf[202]+1 /* (set! node-subexpressions-set! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5586,tmp=(C_word)a,a+=2,tmp));
t29=C_mutate((C_word*)lf[203]+1 /* (set! make-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5595,tmp=(C_word)a,a+=2,tmp));
t30=C_mutate((C_word*)lf[204]+1 /* (set! ##compiler#varnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5601,tmp=(C_word)a,a+=2,tmp));
t31=C_mutate((C_word*)lf[206]+1 /* (set! ##compiler#qnode ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5616,tmp=(C_word)a,a+=2,tmp));
t32=C_mutate((C_word*)lf[207]+1 /* (set! ##compiler#build-node-graph ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5631,tmp=(C_word)a,a+=2,tmp));
t33=C_mutate((C_word*)lf[242]+1 /* (set! ##compiler#build-expression-tree ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_6554,tmp=(C_word)a,a+=2,tmp));
t34=C_mutate((C_word*)lf[256]+1 /* (set! ##compiler#fold-boolean ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7235,tmp=(C_word)a,a+=2,tmp));
t35=C_mutate((C_word*)lf[258]+1 /* (set! ##compiler#inline-lambda-bindings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7289,tmp=(C_word)a,a+=2,tmp));
t36=C_mutate((C_word*)lf[263]+1 /* (set! ##compiler#copy-node-tree-and-rename ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7437,tmp=(C_word)a,a+=2,tmp));
t37=C_mutate((C_word*)lf[270]+1 /* (set! ##compiler#tree-copy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7836,tmp=(C_word)a,a+=2,tmp));
t38=C_mutate((C_word*)lf[271]+1 /* (set! ##compiler#copy-node! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7870,tmp=(C_word)a,a+=2,tmp));
t39=C_mutate((C_word*)lf[272]+1 /* (set! ##compiler#node->sexpr ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7909,tmp=(C_word)a,a+=2,tmp));
t40=C_mutate((C_word*)lf[273]+1 /* (set! ##compiler#sexpr->node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7995,tmp=(C_word)a,a+=2,tmp));
t41=C_mutate((C_word*)lf[274]+1 /* (set! ##compiler#emit-global-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8063,tmp=(C_word)a,a+=2,tmp));
t42=C_mutate((C_word*)lf[294]+1 /* (set! ##compiler#load-inline-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8300,tmp=(C_word)a,a+=2,tmp));
t43=C_mutate((C_word*)lf[296]+1 /* (set! ##compiler#match-node ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8369,tmp=(C_word)a,a+=2,tmp));
t44=C_mutate((C_word*)lf[299]+1 /* (set! ##compiler#expression-has-side-effects? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8594,tmp=(C_word)a,a+=2,tmp));
t45=C_mutate((C_word*)lf[303]+1 /* (set! ##compiler#simple-lambda-node? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8695,tmp=(C_word)a,a+=2,tmp));
t46=C_mutate((C_word*)lf[304]+1 /* (set! ##compiler#dump-undefined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8817,tmp=(C_word)a,a+=2,tmp));
t47=C_mutate((C_word*)lf[306]+1 /* (set! ##compiler#dump-defined-globals ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8858,tmp=(C_word)a,a+=2,tmp));
t48=C_mutate((C_word*)lf[307]+1 /* (set! ##compiler#dump-global-refs ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8895,tmp=(C_word)a,a+=2,tmp));
t49=C_mutate((C_word*)lf[308]+1 /* (set! ##sys#toplevel-definition-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8944,tmp=(C_word)a,a+=2,tmp));
t50=C_mutate((C_word*)lf[311]+1 /* (set! ##compiler#compute-database-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8965,tmp=(C_word)a,a+=2,tmp));
t51=C_mutate((C_word*)lf[314]+1 /* (set! ##compiler#print-program-statistics ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9073,tmp=(C_word)a,a+=2,tmp));
t52=C_mutate((C_word*)lf[324]+1 /* (set! ##compiler#pprint-expressions-to-file ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9154,tmp=(C_word)a,a+=2,tmp));
t53=C_mutate((C_word*)lf[330]+1 /* (set! ##compiler#foreign-type-check ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9212,tmp=(C_word)a,a+=2,tmp));
t54=C_mutate((C_word*)lf[410]+1 /* (set! ##compiler#foreign-type-convert-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10270,tmp=(C_word)a,a+=2,tmp));
t55=C_mutate((C_word*)lf[411]+1 /* (set! ##compiler#foreign-type-convert-argument ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10301,tmp=(C_word)a,a+=2,tmp));
t56=C_mutate((C_word*)lf[412]+1 /* (set! ##compiler#final-foreign-type ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10332,tmp=(C_word)a,a+=2,tmp));
t57=C_mutate((C_word*)lf[414]+1 /* (set! ##compiler#estimate-foreign-result-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10377,tmp=(C_word)a,a+=2,tmp));
t58=C_mutate((C_word*)lf[420]+1 /* (set! ##compiler#estimate-foreign-result-location-size ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10707,tmp=(C_word)a,a+=2,tmp));
t59=C_mutate((C_word*)lf[423]+1 /* (set! ##compiler#finish-foreign-result ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11028,tmp=(C_word)a,a+=2,tmp));
t60=C_mutate((C_word*)lf[436]+1 /* (set! ##compiler#scan-used-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11397,tmp=(C_word)a,a+=2,tmp));
t61=C_mutate((C_word*)lf[437]+1 /* (set! ##compiler#scan-free-variables ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11536,tmp=(C_word)a,a+=2,tmp));
t62=C_mutate((C_word*)lf[439]+1 /* (set! ##compiler#chop-separator ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11745,tmp=(C_word)a,a+=2,tmp));
t63=C_mutate((C_word*)lf[442]+1 /* (set! ##compiler#chop-extension ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11774,tmp=(C_word)a,a+=2,tmp));
t64=C_mutate((C_word*)lf[443]+1 /* (set! ##compiler#print-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11816,tmp=(C_word)a,a+=2,tmp));
t65=C_mutate((C_word*)lf[446]+1 /* (set! ##compiler#print-usage ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11854,tmp=(C_word)a,a+=2,tmp));
t66=C_mutate((C_word*)lf[448]+1 /* (set! ##compiler#make-block-variable-literal ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11866,tmp=(C_word)a,a+=2,tmp));
t67=C_mutate((C_word*)lf[450]+1 /* (set! ##compiler#block-variable-literal? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11872,tmp=(C_word)a,a+=2,tmp));
t68=C_mutate((C_word*)lf[451]+1 /* (set! ##compiler#block-variable-literal-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11878,tmp=(C_word)a,a+=2,tmp));
t69=C_mutate((C_word*)lf[453]+1 /* (set! ##compiler#make-random-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11887,tmp=(C_word)a,a+=2,tmp));
t70=C_mutate((C_word*)lf[456]+1 /* (set! ##compiler#set-real-name! ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11946,tmp=(C_word)a,a+=2,tmp));
t71=C_mutate((C_word*)lf[37]+1 /* (set! ##compiler#real-name ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11952,tmp=(C_word)a,a+=2,tmp));
t72=C_mutate((C_word*)lf[459]+1 /* (set! ##compiler#real-name2 ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12043,tmp=(C_word)a,a+=2,tmp));
t73=C_mutate((C_word*)lf[460]+1 /* (set! ##compiler#display-real-name-table ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12055,tmp=(C_word)a,a+=2,tmp));
t74=C_mutate((C_word*)lf[461]+1 /* (set! ##compiler#source-info->string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12076,tmp=(C_word)a,a+=2,tmp));
t75=C_mutate((C_word*)lf[467]+1 /* (set! ##compiler#source-info->line ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12110,tmp=(C_word)a,a+=2,tmp));
t76=C_mutate((C_word*)lf[468]+1 /* (set! string-null? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12128,tmp=(C_word)a,a+=2,tmp));
t77=C_mutate((C_word*)lf[469]+1 /* (set! ##compiler#dump-nodes ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12131,tmp=(C_word)a,a+=2,tmp));
t78=C_mutate((C_word*)lf[470]+1 /* (set! ##compiler#read-info-hook ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12254,tmp=(C_word)a,a+=2,tmp));
t79=C_mutate((C_word*)lf[474]+1 /* (set! ##compiler#read/source-info ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12299,tmp=(C_word)a,a+=2,tmp));
t80=*((C_word*)lf[476]+1);
t81=C_mutate((C_word*)lf[476]+1 /* (set! ##sys#user-read-hook ...) */,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12305,a[2]=t80,tmp=(C_word)a,a+=3,tmp));
t82=C_mutate((C_word*)lf[479]+1 /* (set! ##compiler#scan-sharp-greater-string ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12338,tmp=(C_word)a,a+=2,tmp));
t83=C_mutate((C_word*)lf[82]+1 /* (set! ##compiler#big-fixnum? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12407,tmp=(C_word)a,a+=2,tmp));
t84=C_mutate((C_word*)lf[309]+1 /* (set! ##compiler#hide-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12431,tmp=(C_word)a,a+=2,tmp));
t85=C_mutate((C_word*)lf[484]+1 /* (set! ##compiler#export-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12464,tmp=(C_word)a,a+=2,tmp));
t86=C_mutate((C_word*)lf[293]+1 /* (set! ##compiler#variable-visible? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12497,tmp=(C_word)a,a+=2,tmp));
t87=C_mutate((C_word*)lf[487]+1 /* (set! ##compiler#mark-variable ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12518,tmp=(C_word)a,a+=2,tmp));
t88=C_mutate((C_word*)lf[488]+1 /* (set! ##compiler#variable-mark ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12546,tmp=(C_word)a,a+=2,tmp));
t89=C_mutate((C_word*)lf[489]+1 /* (set! ##compiler#intrinsic? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12552,tmp=(C_word)a,a+=2,tmp));
t90=C_mutate((C_word*)lf[490]+1 /* (set! foldable? ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12563,tmp=(C_word)a,a+=2,tmp));
t91=C_mutate((C_word*)lf[491]+1 /* (set! ##compiler#load-identifier-database ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12574,tmp=(C_word)a,a+=2,tmp));
t92=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t92+1)))(2,t92,C_SCHEME_UNDEFINED);}

/* ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12578,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1504: repository-path */
t4=*((C_word*)lf[498]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12578(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12578,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12584,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12663,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1505: make-pathname */
t4=*((C_word*)lf[497]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12661 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12663(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1505: file-exists? */
t2=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12584(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12584,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12590,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(*((C_word*)lf[494]+1))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12650,a[2]=t1,a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[496],t3);}
else{
t3=t2;
f_12590(2,t3,C_SCHEME_UNDEFINED);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k12648 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12650,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12653,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12651 in k12648 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12653,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12656,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[495],((C_word*)t0)[2]);}

/* k12654 in k12651 in k12648 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12590,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12597,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1514: read-file */
t3=*((C_word*)lf[493]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k12595 in k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12597(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12597,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12599,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_12599(t5,((C_word*)t0)[2],t1);}

/* loop3021 in k12595 in k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12599(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12599,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12636,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12618,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12622,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1513: ##sys#get */
t8=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t7,t5,lf[492]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12620 in loop3021 in k12595 in k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12622,2,t0,t1);}
t2=(C_truep(t1)?t1:C_SCHEME_END_OF_LIST);
t3=C_i_cdr(((C_word*)t0)[3]);
t4=C_a_i_list(&a,1,t3);
/* support.scm:1513: append */
t5=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[2],t2,t4);}

/* k12616 in loop3021 in k12595 in k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1511: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[492],t1);}

/* k12634 in loop3021 in k12595 in k12588 in k12582 in k12576 in ##compiler#load-identifier-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12599(t3,((C_word*)t0)[2],t2);}

/* foldable? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12563(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12563,3,t0,t1,t2);}
/* tweaks.scm:53: ##sys#get */
t3=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[125]);}

/* ##compiler#intrinsic? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12552(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12552,3,t0,t1,t2);}
/* tweaks.scm:53: ##sys#get */
t3=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,lf[121]);}

/* ##compiler#variable-mark in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12546(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12546,4,t0,t1,t2,t3);}
/* support.scm:1495: ##sys#get */
t4=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* ##compiler#mark-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12518(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr4r,(void*)f_12518r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_12518r(t0,t1,t2,t3,t4);}}

static void C_ccall f_12518r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a=C_alloc(5);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12522,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(t4))){
/* support.scm:1492: ##sys#put! */
t6=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t2,t3,C_SCHEME_TRUE);}
else{
t6=C_i_cdr(t4);
if(C_truep(C_i_nullp(t6))){
t7=C_i_car(t4);
/* support.scm:1492: ##sys#put! */
t8=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t1,t2,t3,t7);}
else{
/* ##sys#error */
t7=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,lf[0],t4);}}}

/* k12520 in ##compiler#mark-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1492: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#variable-visible? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12497(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12497,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12501,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1485: ##sys#get */
t4=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t2,lf[483]);}

/* k12499 in ##compiler#variable-visible? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12501(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_eqp(t1,lf[482]);
if(C_truep(t2)){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}
else{
t3=C_eqp(t1,lf[485]);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?C_SCHEME_TRUE:C_i_not(*((C_word*)lf[486]+1))));}}

/* ##compiler#export-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12464(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12464,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[485]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12470,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:50: ##sys#put! */
t5=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,lf[483],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* tweaks.scm:50: ##sys#put! */
t7=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[483],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k12468 in ##compiler#export-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12470(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[483],t1);}

/* ##compiler#hide-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12431(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12431,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,lf[482]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12437,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* tweaks.scm:50: ##sys#put! */
t5=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,lf[483],C_SCHEME_TRUE);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* tweaks.scm:50: ##sys#put! */
t7=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t1,t2,lf[483],t6);}
else{
/* ##sys#error */
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k12435 in ##compiler#hide-variable in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[483],t1);}

/* ##compiler#big-fixnum? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12407(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12407,3,t0,t1,t2);}
if(C_truep(C_fixnump(t2))){
if(C_truep(C_fudge(C_fix(3)))){
t3=C_fixnum_greaterp(t2,C_fix(1073741823));
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,(C_truep(t3)?t3:C_fixnum_lessp(t2,C_fix(-1073741824))));}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}

/* ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12338(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12338,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12342,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1447: open-output-string */
t4=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12342,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12347,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_12347(t5,((C_word*)t0)[2]);}

/* loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12347(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12347,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12351,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* read-char/port */
t3=*((C_word*)lf[480]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12351(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12351,2,t0,t1);}
if(C_truep(C_eofp(t1))){
/* support.scm:1450: quit */
t2=*((C_word*)lf[19]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[5],lf[481]);}
else{
switch(t1){
case C_make_character(10):
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12369,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1452: newline */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);
case C_make_character(60):
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12381,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* read-char/port */
t3=*((C_word*)lf[480]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);
default:
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12402,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,t1,((C_word*)t0)[3]);}}}

/* k12400 in k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12402(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1464: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12347(t2,((C_word*)t0)[2]);}

/* k12379 in k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12381(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12381,2,t0,t1);}
t2=C_eqp(C_make_character(35),t1);
if(C_truep(t2)){
/* support.scm:1457: get-output-string */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12393,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(60),((C_word*)t0)[3]);}}

/* k12391 in k12379 in k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12393,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12396,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12394 in k12391 in k12379 in k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1461: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12347(t2,((C_word*)t0)[2]);}

/* k12367 in k12349 in loop in k12340 in ##compiler#scan-sharp-greater-string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12369(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1453: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_12347(t2,((C_word*)t0)[2]);}

/* ##sys#user-read-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12305(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12305,4,t0,t1,t2,t3);}
t4=C_eqp(C_make_character(62),t2);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12315,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* read-char/port */
t6=*((C_word*)lf[480]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}
else{
/* support.scm:1444: old-hook */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t3);}}

/* k12313 in ##sys#user-read-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12318,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1442: scan-sharp-greater-string */
t3=*((C_word*)lf[479]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k12316 in k12313 in ##sys#user-read-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12318,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[477],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[478],t4));}

/* ##compiler#read/source-info in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12299(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12299,3,t0,t1,t2);}
/* support.scm:1432: ##sys#read */
t3=*((C_word*)lf[475]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[470]+1));}

/* ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12254(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_12254,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12258,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12261,a[2]=t1,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
t7=C_eqp(lf[473],t2);
if(C_truep(t7)){
t8=C_i_car(t3);
t9=t6;
f_12261(t9,C_i_symbolp(t8));}
else{
t8=t6;
f_12261(t8,C_SCHEME_FALSE);}}

/* k12259 in ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12261(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12261,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12272,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12276,a[2]=((C_word*)t0)[5],a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1426: conc */
t5=*((C_word*)lf[462]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[471]+1),lf[472],((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[5]);}}

/* k12274 in k12259 in ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12280,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* support.scm:1427: ##sys#hash-table-ref */
t4=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,*((C_word*)lf[140]+1),t3);}

/* k12278 in k12274 in k12259 in ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12280(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
/* support.scm:1425: alist-cons */
t3=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}
else{
/* support.scm:1425: alist-cons */
t2=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}}

/* k12270 in k12259 in ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1422: ##sys#hash-table-set! */
t2=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],*((C_word*)lf[140]+1),((C_word*)t0)[2],t1);}

/* k12256 in ##compiler#read-info-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12131(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12131,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12135,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12140,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_12140(t7,t3,C_fix(0),t2);}

/* loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12140(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12140,NULL,4,t0,t1,t2,t3);}
t4=t3;
t5=C_slot(t4,C_fix(1));
t6=t3;
t7=C_slot(t6,C_fix(2));
t8=t3;
t9=C_slot(t8,C_fix(3));
t10=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12168,a[2]=t5,a[3]=t7,a[4]=t9,a[5]=((C_word*)t0)[2],a[6]=t1,a[7]=t3,a[8]=t2,tmp=(C_word)a,a+=9,tmp);
/* support.scm:1403: make-string */
t11=*((C_word*)lf[465]+1);
((C_proc4)(void*)(*((C_word*)t11+1)))(4,t11,t10,t2,C_make_character(32));}

/* k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12168,2,t0,t1);}
t2=C_a_i_plus(&a,2,((C_word*)t0)[8],C_fix(2));
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_12174,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=t2,a[8]=((C_word*)t0)[5],a[9]=((C_word*)t0)[6],a[10]=((C_word*)t0)[7],tmp=(C_word)a,a+=11,tmp);
/* write-char/port */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(10),t3);}

/* k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12174,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12177,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12177(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12177,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_12180,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(60),((C_word*)t0)[3]);}

/* k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12180,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12183,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12183(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12183,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_12186,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],tmp=(C_word)a,a+=9,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[2]);}

/* k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12189,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[8],tmp=(C_word)a,a+=7,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12192,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* for-each */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a12247 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12248(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12248,3,t0,t1,t2);}
/* g28822883 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_12140(t3,t1,((C_word*)t0)[2],t2);}

/* k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12192(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12192,2,t0,t1);}
t2=C_block_size(((C_word*)t0)[3]);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12198,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_fixnum_greaterp(t2,C_fix(4)))){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12207,a[2]=t4,a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t6=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,C_make_character(91),t4);}
else{
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}}

/* k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12207(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12207,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],C_fix(4));
/* write */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k12208 in k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12210,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12213,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12218,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp));
t6=((C_word*)t4)[1];
f_12218(t6,t2,C_fix(5));}

/* doloop2889 in k12208 in k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12218,NULL,3,t0,t1,t2);}
if(C_truep(C_fixnum_greater_or_equal_p(t2,((C_word*)t0)[4]))){
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12228,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t5=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,C_make_character(32),t3);}}

/* k12226 in doloop2889 in k12208 in k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12231,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=C_slot(((C_word*)t0)[3],((C_word*)t0)[6]);
/* write */
t4=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* k12229 in k12226 in doloop2889 in k12208 in k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_fixnum_plus(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_12218(t3,((C_word*)t0)[2],t2);}

/* k12211 in k12208 in k12205 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12213(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(93),*((C_word*)lf[11]+1));}

/* k12196 in k12190 in k12187 in k12184 in k12181 in k12178 in k12175 in k12172 in k12166 in loop in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],C_make_character(62),*((C_word*)lf[11]+1));}

/* k12133 in ##compiler#dump-nodes in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1415: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* string-null? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12128(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12128,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_string_null_p(*((C_word*)lf[322]+1)));}

/* ##compiler#source-info->line in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12110(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12110,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t2));}
else{
if(C_truep(t2)){
/* support.scm:1387: ->string */
t3=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}}

/* ##compiler#source-info->string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_12076,3,t0,t1,t2);}
if(C_truep(C_i_listp(t2))){
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12096,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_12100,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=C_i_string_length(t3);
t8=C_a_i_minus(&a,2,C_fix(4),t7);
/* support.scm:1381: max */
t9=*((C_word*)lf[466]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,C_fix(0),t8);}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12098 in ##compiler#source-info->string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1381: make-string */
t2=*((C_word*)lf[465]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_make_character(32));}

/* k12094 in ##compiler#source-info->string in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1381: conc */
t2=*((C_word*)lf[462]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[4],((C_word*)t0)[3],lf[463],t1,lf[464],((C_word*)t0)[2]);}

/* ##compiler#display-real-name-table in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_12061,tmp=(C_word)a,a+=2,tmp);
/* support.scm:1372: ##sys#hash-table-for-each */
t3=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[457]+1));}

/* a12060 in ##compiler#display-real-name-table in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12061(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12061,4,t0,t1,t2,t3);}
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12065,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t4);}

/* k12063 in a12060 in ##compiler#display-real-name-table in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12065(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12065,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12068,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(9),((C_word*)t0)[3]);}

/* k12066 in k12063 in a12060 in ##compiler#display-real-name-table in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12068(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12068,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12071,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12069 in k12066 in k12063 in a12060 in ##compiler#display-real-name-table in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#real-name2 in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12043(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_12043,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_12047,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1368: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[457]+1),t2);}

/* k12045 in ##compiler#real-name2 in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12047(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:1369: real-name */
t2=*((C_word*)lf[37]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11952(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+8)){
C_save_and_reclaim((void*)tr3r,(void*)f_11952r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_11952r(t0,t1,t2,t3);}}

static void C_ccall f_11952r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word *a=C_alloc(8);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_11955,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11971,a[2]=t2,a[3]=t1,a[4]=t4,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1352: resolve */
f_11955(t5,t2);}

/* k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11971(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11971,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
if(C_truep(C_i_pairp(((C_word*)t0)[5]))){
t3=C_i_car(((C_word*)t0)[5]);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11996,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:1356: ##sys#symbol->qualified-string */
t5=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t1);}
else{
/* support.scm:1365: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],t1);}}
else{
/* support.scm:1353: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12000,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1357: get */
t3=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[5],((C_word*)t0)[2],lf[143]);}

/* k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12000(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12000,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12002,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_12002(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_12002(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_12002,NULL,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12009,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=t1,a[6]=t3,tmp=(C_word)a,a+=7,tmp);
/* support.scm:1359: resolve */
f_11955(t4,t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12009,2,t0,t1);}
t2=C_eqp(t1,((C_word*)t0)[6]);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[4]);}
else{
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12022,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[2],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* open-output-string */
t4=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12022,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12025,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k12023 in k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12025,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_12028,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[458],((C_word*)t0)[3]);}

/* k12026 in k12023 in k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12028(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12028,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_12031,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k12029 in k12026 in k12023 in k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12031,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_12034,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* get-output-string */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k12032 in k12029 in k12026 in k12023 in k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_12034,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_12038,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1363: get */
t3=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[143]);}

/* k12036 in k12032 in k12029 in k12026 in k12023 in k12020 in k12007 in loop in k11998 in k11994 in k11969 in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_12038(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1362: loop */
t2=((C_word*)((C_word*)t0)[4])[1];
f_12002(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* resolve in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11955(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11955,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11959,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1347: ##sys#hash-table-ref */
t4=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[457]+1),t2);}

/* k11957 in resolve in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11959(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11959,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11965,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1349: ##sys#hash-table-ref */
t3=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[457]+1),t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11963 in k11957 in resolve in ##compiler#real-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,(C_truep(t1)?t1:((C_word*)t0)[2]));}

/* ##compiler#set-real-name! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11946(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11946,4,t0,t1,t2,t3);}
/* support.scm:1343: ##sys#hash-table-set! */
t4=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[457]+1),t2,t3);}

/* ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11887(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_11887r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11887r(t0,t1,t2);}}

static void C_ccall f_11887r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(4);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11895,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t4=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11895(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11895,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11898,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11922,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t3))){
/* support.scm:1330: gensym */
t5=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_cdr(t3);
if(C_truep(C_i_nullp(t5))){
t6=C_i_car(t3);
/* display */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t2,t6,t1);}
else{
/* ##sys#error */
t6=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,lf[0],t3);}}}

/* k11920 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11922(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11898(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11898,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11901,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(45),((C_word*)t0)[2]);}

/* k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11901(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11901,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11904,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11918,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1331: current-seconds */
t4=*((C_word*)lf[455]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k11916 in k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11918(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11902 in k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11904(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11904,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11907,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11914,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1332: random */
t4=*((C_word*)lf[454]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_fix(1000));}

/* k11912 in k11902 in k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k11905 in k11902 in k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11907,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11910,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k11908 in k11905 in k11902 in k11899 in k11896 in k11893 in ##compiler#make-random-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1328: string->symbol */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#block-variable-literal-name in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11878(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11878,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[449],lf[452]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* ##compiler#block-variable-literal? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11872(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11872,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[449]));}

/* ##compiler#make-block-variable-literal in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11866(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11866,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,2,lf[449],t2));}

/* ##compiler#print-usage in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11854(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11854,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11858,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1186: print-version */
t3=*((C_word*)lf[443]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k11856 in ##compiler#print-usage in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11858,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11861,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1187: newline */
t3=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k11859 in k11856 in ##compiler#print-usage in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11861(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1188: display */
t2=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[447]);}

/* ##compiler#print-version in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11816(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_11816r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_11816r(t0,t1,t2);}}

static void C_ccall f_11816r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11820,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_nullp(t2))){
t4=t3;
f_11820(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=t3;
f_11820(2,t5,C_i_car(t2));}
else{
/* ##sys#error */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k11818 in ##compiler#print-version in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11820,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11823,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* support.scm:1182: print* */
t3=*((C_word*)lf[444]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[445]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f13809,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1183: chicken-version */
t4=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,C_SCHEME_TRUE);}}

/* f13809 in k11818 in ##compiler#print-version in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f13809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1183: print */
t2=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k11821 in k11818 in ##compiler#print-version in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11823(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11823,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11830,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:1183: chicken-version */
t3=*((C_word*)lf[286]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,C_SCHEME_TRUE);}

/* k11828 in k11821 in k11818 in ##compiler#print-version in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1183: print */
t2=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#chop-extension in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11774(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11774,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11783,a[2]=t6,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_11783(t8,t1,t4);}

/* loop in ##compiler#chop-extension in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_11783,NULL,3,t0,t1,t2);}
if(C_truep(C_i_zerop(t2))){
t3=((C_word*)t0)[3];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t3=C_i_string_ref(((C_word*)t0)[3],t2);
t4=C_eqp(C_make_character(46),t3);
if(C_truep(t4)){
/* support.scm:1175: substring */
t5=*((C_word*)lf[440]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,((C_word*)t0)[3],C_fix(0),t2);}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
/* support.scm:1176: loop */
t8=t1;
t9=t5;
t1=t8;
t2=t9;
goto loop;}}}

/* ##compiler#chop-separator in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11745(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11745,3,t0,t1,t2);}
t3=C_i_string_length(t2);
t4=C_a_i_minus(&a,2,t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11755,a[2]=t4,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_greaterp(t4,C_fix(0)))){
t6=C_i_string_ref(t2,t4);
t7=t5;
f_11755(t7,C_i_memq(t6,lf[441]));}
else{
t6=t5;
f_11755(t6,C_SCHEME_FALSE);}}

/* k11753 in ##compiler#chop-separator in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11755(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:1168: substring */
t2=*((C_word*)lf[440]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],C_fix(0),((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11536(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_11536,3,t0,t1,t2);}
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11539,a[2]=t10,a[3]=t8,a[4]=t6,a[5]=t4,tmp=(C_word)a,a+=6,tmp));
t12=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11705,a[2]=t8,tmp=(C_word)a,a+=3,tmp));
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11740,a[2]=t6,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:1158: walk */
t14=((C_word*)t8)[1];
f_11539(t14,t13,t2,C_SCHEME_END_OF_LIST);}

/* k11738 in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11740(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1159: values */
C_values(4,0,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* walkeach in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11705(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11705,NULL,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11711,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_11711(t7,t1,t2);}

/* loop2739 in walkeach in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11711(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11711,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11719,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11726,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g27462747 */
t6=t3;
f_11719(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11724 in loop2739 in walkeach in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11711(t3,((C_word*)t0)[2],t2);}

/* g2746 in loop2739 in walkeach in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11719,NULL,3,t0,t1,t2);}
/* support.scm:1156: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_11539(t3,t1,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11539(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11539,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[79]);
t11=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_11573,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t5,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t3,a[8]=t7,a[9]=t9,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(t10)){
t12=t11;
f_11573(t12,t10);}
else{
t12=C_eqp(t9,lf[211]);
if(C_truep(t12)){
t13=t11;
f_11573(t13,t12);}
else{
t13=C_eqp(t9,lf[219]);
if(C_truep(t13)){
t14=t11;
f_11573(t14,t13);}
else{
t14=C_eqp(t9,lf[222]);
t15=t11;
f_11573(t15,(C_truep(t14)?t14:C_eqp(t9,lf[235])));}}}}

/* k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11573(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11573,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[9],lf[205]);
if(C_truep(t2)){
t3=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_memq(t3,((C_word*)t0)[7]))){
t4=C_SCHEME_UNDEFINED;
t5=((C_word*)t0)[10];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_11592,a[2]=t3,a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm:1138: lset-adjoin */
t5=*((C_word*)lf[438]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[265]+1),((C_word*)((C_word*)t0)[6])[1],t3);}}
else{
t3=C_eqp(((C_word*)t0)[9],lf[223]);
if(C_truep(t3)){
t4=C_i_car(((C_word*)t0)[8]);
if(C_truep(C_i_memq(t4,((C_word*)t0)[7]))){
t5=C_i_car(((C_word*)t0)[4]);
/* support.scm:1144: walk */
t6=((C_word*)((C_word*)t0)[3])[1];
f_11539(t6,((C_word*)t0)[10],t5,((C_word*)t0)[7]);}
else{
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11628,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[10],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:1143: lset-adjoin */
t6=*((C_word*)lf[438]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,*((C_word*)lf[265]+1),((C_word*)((C_word*)t0)[6])[1],t4);}}
else{
t4=C_eqp(((C_word*)t0)[9],lf[89]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_11637,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t6=C_i_car(((C_word*)t0)[4]);
/* support.scm:1146: walk */
t7=((C_word*)((C_word*)t0)[3])[1];
f_11539(t7,t5,t6,((C_word*)t0)[7]);}
else{
t5=C_eqp(((C_word*)t0)[9],lf[218]);
if(C_truep(t5)){
t6=C_i_caddr(((C_word*)t0)[8]);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11667,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1149: decompose-lambda-list */
t8=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,((C_word*)t0)[10],t6,t7);}
else{
/* support.scm:1153: walkeach */
t6=((C_word*)((C_word*)t0)[2])[1];
f_11705(t6,((C_word*)t0)[10],((C_word*)t0)[4],((C_word*)t0)[7]);}}}}}}

/* a11666 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11667(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_11667,5,t0,t1,t2,t3,t4);}
t5=C_i_car(((C_word*)t0)[4]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11679,a[2]=t5,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1152: append */
t7=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,((C_word*)t0)[2]);}

/* k11677 in a11666 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11679(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1152: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11539(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11635 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11637,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11648,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1147: append */
t4=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k11646 in k11635 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:1147: walk */
t2=((C_word*)((C_word*)t0)[4])[1];
f_11539(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k11626 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t3=C_i_car(((C_word*)t0)[5]);
/* support.scm:1144: walk */
t4=((C_word*)((C_word*)t0)[4])[1];
f_11539(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k11590 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11592,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11598,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1139: variable-visible? */
t4=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k11596 in k11590 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11598(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11598,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11602,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:1140: lset-adjoin */
t3=*((C_word*)lf[438]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,*((C_word*)lf[265]+1),((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}}

/* k11600 in k11596 in k11590 in k11571 in walk in ##compiler#scan-free-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11397(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11397,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11401,a[2]=t5,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11403,a[2]=t3,a[3]=t5,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t10=((C_word*)t8)[1];
f_11403(t10,t6,t2);}

/* walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11403(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11403,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(t6,lf[205]);
t8=(C_truep(t7)?t7:C_eqp(t6,lf[223]));
if(C_truep(t8)){
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_car(t10);
t12=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11435,a[2]=t4,a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11464,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t11,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_memq(t11,((C_word*)t0)[2]))){
t14=C_i_memq(t11,((C_word*)((C_word*)t0)[3])[1]);
t15=t13;
f_11464(t15,C_i_not(t14));}
else{
t14=t13;
f_11464(t14,C_SCHEME_FALSE);}}
else{
t9=C_eqp(t6,lf[79]);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11496,a[2]=t4,a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t9)){
t11=t10;
f_11496(t11,t9);}
else{
t11=C_eqp(t6,lf[211]);
t12=t10;
f_11496(t12,(C_truep(t11)?t11:C_eqp(t6,lf[219])));}}}

/* k11494 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11496(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11496,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11501,a[2]=((C_word*)t0)[3],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_11501(t5,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* loop2679 in k11494 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11501,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11511,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g26862687 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11403(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11509 in loop2679 in k11494 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11511(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11501(t3,((C_word*)t0)[2],t2);}

/* k11462 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11464(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11464,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)((C_word*)t0)[3])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_11435(t4,t3);}
else{
t2=((C_word*)t0)[2];
f_11435(t2,C_SCHEME_UNDEFINED);}}

/* k11433 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11435(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11435,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_11440,a[2]=((C_word*)t0)[4],a[3]=t3,tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_11440(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop2659 in k11433 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11440(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11440,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11450,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
/* g26662667 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_11403(t5,t3,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k11448 in loop2659 in k11433 in walk in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_11440(t3,((C_word*)t0)[2],t2);}

/* k11399 in ##compiler#scan-used-variables in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)((C_word*)t0)[2])[1]);}

/* ##compiler#finish-foreign-result in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11028(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_11028,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[353]);
t6=(C_truep(t5)?t5:C_eqp(t4,lf[372]));
if(C_truep(t6)){
t7=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[79],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t3,t9);
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_cons(&a,2,lf[424],t10));}
else{
t7=C_eqp(t4,lf[356]);
if(C_truep(t7)){
t8=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,lf[79],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,t3,t10);
t12=t1;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_cons(&a,2,lf[425],t11));}
else{
t8=C_eqp(t4,lf[371]);
t9=(C_truep(t8)?t8:C_eqp(t4,lf[373]));
if(C_truep(t9)){
t10=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[79],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t3,t12);
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_a_i_cons(&a,2,lf[426],t13));}
else{
t10=C_eqp(t4,lf[369]);
t11=(C_truep(t10)?t10:C_eqp(t4,lf[370]));
if(C_truep(t11)){
t12=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,lf[79],t12);
t14=C_a_i_cons(&a,2,t13,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,t3,t14);
t16=t1;
((C_proc2)(void*)(*((C_word*)t16+1)))(2,t16,C_a_i_cons(&a,2,lf[427],t15));}
else{
t12=C_eqp(t4,lf[357]);
if(C_truep(t12)){
t13=C_a_i_cons(&a,2,C_fix(0),C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,lf[79],t13);
t15=C_a_i_cons(&a,2,t14,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,t3,t15);
t17=C_a_i_cons(&a,2,lf[424],t16);
t18=C_a_i_cons(&a,2,t17,C_SCHEME_END_OF_LIST);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[428],t18));}
else{
t13=C_eqp(t4,lf[374]);
if(C_truep(t13)){
t14=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t15=C_a_i_cons(&a,2,lf[79],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t3,t16);
t18=t1;
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_cons(&a,2,lf[429],t17));}
else{
t14=C_eqp(t4,lf[375]);
if(C_truep(t14)){
t15=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t16=C_a_i_cons(&a,2,lf[79],t15);
t17=C_a_i_cons(&a,2,t16,C_SCHEME_END_OF_LIST);
t18=C_a_i_cons(&a,2,t3,t17);
t19=t1;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_cons(&a,2,lf[430],t18));}
else{
t15=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11227,a[2]=t1,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t16=C_i_length(t2);
if(C_truep(C_i_nequalp(C_fix(3),t16))){
t17=C_i_car(t2);
t18=t15;
f_11227(t18,C_i_memq(t17,lf[435]));}
else{
t17=t15;
f_11227(t17,C_SCHEME_FALSE);}}
else{
t16=t15;
f_11227(t16,C_SCHEME_FALSE);}}}}}}}}}

/* k11225 in ##compiler#finish-foreign-result in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11227(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11227,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11230,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:1097: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_11319,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(((C_word*)t0)[3]))){
t3=C_i_length(((C_word*)t0)[3]);
if(C_truep(C_i_nequalp(C_fix(3),t3))){
t4=C_i_car(((C_word*)t0)[3]);
t5=t2;
f_11319(t5,C_eqp(lf[364],t4));}
else{
t4=t2;
f_11319(t4,C_SCHEME_FALSE);}}
else{
t3=t2;
f_11319(t3,C_SCHEME_FALSE);}}}

/* k11317 in k11225 in ##compiler#finish-foreign-result in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_11319(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_11319,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_caddr(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,lf[362],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[79],t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t4,t5);
t7=C_a_i_cons(&a,2,t2,t6);
t8=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[433],t7));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k11228 in k11225 in ##compiler#finish-foreign-result in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11230(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word ab[60],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11230,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[431],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[432],t7);
t9=C_i_caddr(((C_word*)t0)[3]);
t10=C_a_i_cons(&a,2,lf[362],C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[79],t10);
t12=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t11,t12);
t14=C_a_i_cons(&a,2,t9,t13);
t15=C_a_i_cons(&a,2,lf[433],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t8,t16);
t18=C_a_i_cons(&a,2,t1,t17);
t19=C_a_i_cons(&a,2,lf[434],t18);
t20=C_a_i_cons(&a,2,t19,C_SCHEME_END_OF_LIST);
t21=C_a_i_cons(&a,2,t4,t20);
t22=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t22+1)))(2,t22,C_a_i_cons(&a,2,lf[89],t21));}

/* ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10707(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10707,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10719,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_11022,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1058: follow-without-loop */
t5=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}

/* a11021 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_11022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_11022,2,t0,t1);}
/* support.scm:1079: quit */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[422],((C_word*)t0)[2]);}

/* a10718 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10719(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10719,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[331]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10729,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10729(t7,t5);}
else{
t7=C_eqp(t4,lf[335]);
if(C_truep(t7)){
t8=t6;
f_10729(t8,t7);}
else{
t8=C_eqp(t4,lf[403]);
if(C_truep(t8)){
t9=t6;
f_10729(t9,t8);}
else{
t9=C_eqp(t4,lf[416]);
if(C_truep(t9)){
t10=t6;
f_10729(t10,t9);}
else{
t10=C_eqp(t4,lf[404]);
if(C_truep(t10)){
t11=t6;
f_10729(t11,t10);}
else{
t11=C_eqp(t4,lf[332]);
if(C_truep(t11)){
t12=t6;
f_10729(t12,t11);}
else{
t12=C_eqp(t4,lf[402]);
if(C_truep(t12)){
t13=t6;
f_10729(t13,t12);}
else{
t13=C_eqp(t4,lf[378]);
if(C_truep(t13)){
t14=t6;
f_10729(t14,t13);}
else{
t14=C_eqp(t4,lf[377]);
if(C_truep(t14)){
t15=t6;
f_10729(t15,t14);}
else{
t15=C_eqp(t4,lf[405]);
if(C_truep(t15)){
t16=t6;
f_10729(t16,t15);}
else{
t16=C_eqp(t4,lf[406]);
if(C_truep(t16)){
t17=t6;
f_10729(t17,t16);}
else{
t17=C_eqp(t4,lf[350]);
if(C_truep(t17)){
t18=t6;
f_10729(t18,t17);}
else{
t18=C_eqp(t4,lf[339]);
if(C_truep(t18)){
t19=t6;
f_10729(t19,t18);}
else{
t19=C_eqp(t4,lf[352]);
if(C_truep(t19)){
t20=t6;
f_10729(t20,t19);}
else{
t20=C_eqp(t4,lf[348]);
if(C_truep(t20)){
t21=t6;
f_10729(t21,t20);}
else{
t21=C_eqp(t4,lf[346]);
if(C_truep(t21)){
t22=t6;
f_10729(t22,t21);}
else{
t22=C_eqp(t4,lf[337]);
if(C_truep(t22)){
t23=t6;
f_10729(t23,t22);}
else{
t23=C_eqp(t4,lf[353]);
if(C_truep(t23)){
t24=t6;
f_10729(t24,t23);}
else{
t24=C_eqp(t4,lf[357]);
if(C_truep(t24)){
t25=t6;
f_10729(t25,t24);}
else{
t25=C_eqp(t4,lf[399]);
if(C_truep(t25)){
t26=t6;
f_10729(t26,t25);}
else{
t26=C_eqp(t4,lf[394]);
if(C_truep(t26)){
t27=t6;
f_10729(t27,t26);}
else{
t27=C_eqp(t4,lf[407]);
if(C_truep(t27)){
t28=t6;
f_10729(t28,t27);}
else{
t28=C_eqp(t4,lf[408]);
if(C_truep(t28)){
t29=t6;
f_10729(t29,t28);}
else{
t29=C_eqp(t4,lf[379]);
if(C_truep(t29)){
t30=t6;
f_10729(t30,t29);}
else{
t30=C_eqp(t4,lf[376]);
if(C_truep(t30)){
t31=t6;
f_10729(t31,t30);}
else{
t31=C_eqp(t4,lf[372]);
if(C_truep(t31)){
t32=t6;
f_10729(t32,t31);}
else{
t32=C_eqp(t4,lf[373]);
if(C_truep(t32)){
t33=t6;
f_10729(t33,t32);}
else{
t33=C_eqp(t4,lf[370]);
if(C_truep(t33)){
t34=t6;
f_10729(t34,t33);}
else{
t34=C_eqp(t4,lf[356]);
if(C_truep(t34)){
t35=t6;
f_10729(t35,t34);}
else{
t35=C_eqp(t4,lf[371]);
if(C_truep(t35)){
t36=t6;
f_10729(t36,t35);}
else{
t36=C_eqp(t4,lf[369]);
if(C_truep(t36)){
t37=t6;
f_10729(t37,t36);}
else{
t37=C_eqp(t4,lf[374]);
t38=t6;
f_10729(t38,(C_truep(t37)?t37:C_eqp(t4,lf[375])));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k10727 in a10718 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10729(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10729,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[400]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[401]));
if(C_truep(t3)){
t4=((C_word*)t0)[5];
t5=C_i_foreign_fixnum_argumentp(C_fix(2));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub189(C_SCHEME_UNDEFINED,t5));}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10747,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm:1071: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[368]+1),((C_word*)t0)[2]);}
else{
t5=t4;
f_10747(2,t5,C_SCHEME_FALSE);}}}}

/* k10745 in k10727 in a10718 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10747,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10751,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g25572558 */
t3=t2;
f_10751(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[359]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10786,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_10786(t5,t3);}
else{
t5=C_eqp(t2,lf[341]);
if(C_truep(t5)){
t6=t4;
f_10786(t6,t5);}
else{
t6=C_eqp(t2,lf[339]);
if(C_truep(t6)){
t7=t4;
f_10786(t7,t6);}
else{
t7=C_eqp(t2,lf[350]);
if(C_truep(t7)){
t8=t4;
f_10786(t8,t7);}
else{
t8=C_eqp(t2,lf[352]);
t9=t4;
f_10786(t9,(C_truep(t8)?t8:C_eqp(t2,lf[367])));}}}}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
/* support.scm:1057: quit */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[421],t3);}}}

/* k10784 in k10745 in k10727 in a10718 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10786(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=C_i_foreign_fixnum_argumentp(C_fix(1));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
/* support.scm:1057: quit */
t4=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,lf[421],t3);}}

/* g2557 in k10745 in k10727 in a10718 in ##compiler#estimate-foreign-result-location-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10751(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10751,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1073: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1073: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10377(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10377,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10383,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10701,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1028: follow-without-loop */
t5=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}

/* a10700 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10701(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10701,2,t0,t1);}
/* support.scm:1053: quit */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[419],((C_word*)t0)[2]);}

/* a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10383(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10383,4,t0,t1,t2,t3);}
t4=t2;
t5=C_eqp(t4,lf[331]);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10393,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(t5)){
t7=t6;
f_10393(t7,t5);}
else{
t7=C_eqp(t4,lf[335]);
if(C_truep(t7)){
t8=t6;
f_10393(t8,t7);}
else{
t8=C_eqp(t4,lf[403]);
if(C_truep(t8)){
t9=t6;
f_10393(t9,t8);}
else{
t9=C_eqp(t4,lf[416]);
if(C_truep(t9)){
t10=t6;
f_10393(t10,t9);}
else{
t10=C_eqp(t4,lf[417]);
if(C_truep(t10)){
t11=t6;
f_10393(t11,t10);}
else{
t11=C_eqp(t4,lf[404]);
if(C_truep(t11)){
t12=t6;
f_10393(t12,t11);}
else{
t12=C_eqp(t4,lf[418]);
if(C_truep(t12)){
t13=t6;
f_10393(t13,t12);}
else{
t13=C_eqp(t4,lf[332]);
if(C_truep(t13)){
t14=t6;
f_10393(t14,t13);}
else{
t14=C_eqp(t4,lf[402]);
if(C_truep(t14)){
t15=t6;
f_10393(t15,t14);}
else{
t15=C_eqp(t4,lf[405]);
if(C_truep(t15)){
t16=t6;
f_10393(t16,t15);}
else{
t16=C_eqp(t4,lf[406]);
if(C_truep(t16)){
t17=t6;
f_10393(t17,t16);}
else{
t17=C_eqp(t4,lf[407]);
t18=t6;
f_10393(t18,(C_truep(t17)?t17:C_eqp(t4,lf[408])));}}}}}}}}}}}}

/* k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10393(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10393,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[353]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10402,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10402(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[356]);
if(C_truep(t4)){
t5=t3;
f_10402(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[350]);
if(C_truep(t5)){
t6=t3;
f_10402(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[352]);
if(C_truep(t6)){
t7=t3;
f_10402(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[357]);
if(C_truep(t7)){
t8=t3;
f_10402(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[371]);
if(C_truep(t8)){
t9=t3;
f_10402(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[369]);
if(C_truep(t9)){
t10=t3;
f_10402(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[4],lf[372]);
if(C_truep(t10)){
t11=t3;
f_10402(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[4],lf[373]);
if(C_truep(t11)){
t12=t3;
f_10402(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[4],lf[370]);
if(C_truep(t12)){
t13=t3;
f_10402(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[4],lf[374]);
t14=t3;
f_10402(t14,(C_truep(t13)?t13:C_eqp(((C_word*)t0)[4],lf[375])));}}}}}}}}}}}}

/* k10400 in k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10402(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10402,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(3));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[348]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_10414,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t4=t3;
f_10414(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[378]);
if(C_truep(t4)){
t5=t3;
f_10414(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[346]);
if(C_truep(t5)){
t6=t3;
f_10414(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[377]);
if(C_truep(t6)){
t7=t3;
f_10414(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[379]);
t8=t3;
f_10414(t8,(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[376])));}}}}}}

/* k10412 in k10400 in k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10414,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}
else{
t2=C_eqp(((C_word*)t0)[4],lf[337]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10426,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_10426(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[400]);
if(C_truep(t4)){
t5=t3;
f_10426(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[401]);
t6=t3;
f_10426(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[4],lf[415])));}}}}

/* k10424 in k10412 in k10400 in k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10426(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10426,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[4];
t3=C_i_foreign_fixnum_argumentp(C_fix(4));
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10432,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[2]))){
/* support.scm:1044: ##sys#hash-table-ref */
t3=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,*((C_word*)lf[368]+1),((C_word*)t0)[2]);}
else{
t3=t2;
f_10432(2,t3,C_SCHEME_FALSE);}}}

/* k10430 in k10424 in k10412 in k10400 in k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10432(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10432,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10436,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g24102411 */
t3=t2;
f_10436(t3,((C_word*)t0)[3],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=C_i_car(((C_word*)t0)[2]);
t3=C_eqp(t2,lf[359]);
if(C_truep(t3)){
if(C_truep(t3)){
t4=((C_word*)t0)[3];
t5=C_i_foreign_fixnum_argumentp(C_fix(3));
t6=t4;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,stub189(C_SCHEME_UNDEFINED,t5));}
else{
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_fix(0));}}
else{
t4=C_eqp(t2,lf[341]);
if(C_truep(t4)){
if(C_truep(t4)){
t5=((C_word*)t0)[3];
t6=C_i_foreign_fixnum_argumentp(C_fix(3));
t7=t5;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,stub189(C_SCHEME_UNDEFINED,t6));}
else{
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_fix(0));}}
else{
t5=C_eqp(t2,lf[339]);
if(C_truep(t5)){
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=C_i_foreign_fixnum_argumentp(C_fix(3));
t8=t6;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,stub189(C_SCHEME_UNDEFINED,t7));}
else{
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_fix(0));}}
else{
t6=C_eqp(t2,lf[350]);
if(C_truep(t6)){
if(C_truep(t6)){
t7=((C_word*)t0)[3];
t8=C_i_foreign_fixnum_argumentp(C_fix(3));
t9=t7;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,stub189(C_SCHEME_UNDEFINED,t8));}
else{
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_fix(0));}}
else{
t7=C_eqp(t2,lf[352]);
if(C_truep(t7)){
if(C_truep(t7)){
t8=((C_word*)t0)[3];
t9=C_i_foreign_fixnum_argumentp(C_fix(3));
t10=t8;
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,stub189(C_SCHEME_UNDEFINED,t9));}
else{
t8=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_fix(0));}}
else{
t8=C_eqp(t2,lf[367]);
if(C_truep(t8)){
if(C_truep(t8)){
t9=((C_word*)t0)[3];
t10=C_i_foreign_fixnum_argumentp(C_fix(3));
t11=t9;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,stub189(C_SCHEME_UNDEFINED,t10));}
else{
t9=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_fix(0));}}
else{
t9=C_eqp(t2,lf[360]);
if(C_truep(t9)){
if(C_truep(t9)){
t10=((C_word*)t0)[3];
t11=C_i_foreign_fixnum_argumentp(C_fix(3));
t12=t10;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,stub189(C_SCHEME_UNDEFINED,t11));}
else{
t10=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_fix(0));}}
else{
t10=C_eqp(t2,lf[361]);
if(C_truep(t10)){
if(C_truep(t10)){
t11=((C_word*)t0)[3];
t12=C_i_foreign_fixnum_argumentp(C_fix(3));
t13=t11;
((C_proc2)(void*)(*((C_word*)t13+1)))(2,t13,stub189(C_SCHEME_UNDEFINED,t12));}
else{
t11=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_fix(0));}}
else{
t11=C_eqp(t2,lf[364]);
if(C_truep(t11)){
t12=((C_word*)t0)[3];
t13=C_i_foreign_fixnum_argumentp(C_fix(3));
t14=t12;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,stub189(C_SCHEME_UNDEFINED,t13));}
else{
t12=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_fix(0));}}}}}}}}}}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_fix(0));}}}

/* g2410 in k10430 in k10424 in k10412 in k10400 in k10391 in a10382 in ##compiler#estimate-foreign-result-size in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10436(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10436,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1046: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1046: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#final-foreign-type in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10332(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_10332,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_10338,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10371,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:1015: follow-without-loop */
t5=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,t3,t4);}

/* a10370 in ##compiler#final-foreign-type in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10371(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10371,2,t0,t1);}
/* support.scm:1022: quit */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[413],((C_word*)t0)[2]);}

/* a10337 in ##compiler#final-foreign-type in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10338(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10338,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_10342,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_symbolp(t2))){
/* support.scm:1018: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[368]+1),t2);}
else{
t5=t4;
f_10342(2,t5,C_SCHEME_FALSE);}}

/* k10340 in a10337 in ##compiler#final-foreign-type in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10342(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10342,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10346,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g23002301 */
t3=t2;
f_10346(t3,((C_word*)t0)[3],t1);}
else{
t2=((C_word*)t0)[2];
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* g2300 in k10340 in a10337 in ##compiler#final-foreign-type in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_10346(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_10346,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:1020: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:1020: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* ##compiler#foreign-type-convert-argument in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10301(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10301,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10314,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1009: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[368]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10312 in ##compiler#foreign-type-convert-argument in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10314,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(1));
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-convert-result in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10270(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_10270,4,t0,t1,t2,t3);}
if(C_truep(C_i_symbolp(t3))){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_10283,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:1002: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[368]+1),t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k10281 in ##compiler#foreign-type-convert-result in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10283(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10283,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_vectorp(t1))){
t2=C_i_vector_ref(t1,C_fix(2));
t3=C_a_i_list(&a,2,t2,((C_word*)t0)[3]);
if(C_truep(t3)){
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=((C_word*)t0)[3];
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}
else{
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9212(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9212,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9218,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_10264,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:903: follow-without-loop */
t6=*((C_word*)lf[74]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t1,t3,t4,t5);}

/* a10263 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_10264(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_10264,2,t0,t1);}
/* support.scm:995: quit */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,lf[409],((C_word*)t0)[2]);}

/* a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9218(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9218,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9224,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp));
t7=((C_word*)t5)[1];
f_9224(t7,t1,t2);}

/* repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9224(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9224,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_eqp(t3,lf[331]);
t5=(C_truep(t4)?t4:C_eqp(t3,lf[332]));
if(C_truep(t5)){
if(C_truep(*((C_word*)lf[333]+1))){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,((C_word*)t0)[4]);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_cons(&a,2,lf[334],t6));}}
else{
t6=C_eqp(t3,lf[335]);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9253,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=t3,a[6]=t1,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t6)){
t8=t7;
f_9253(t8,t6);}
else{
t8=C_eqp(t3,lf[402]);
if(C_truep(t8)){
t9=t7;
f_9253(t9,t8);}
else{
t9=C_eqp(t3,lf[403]);
if(C_truep(t9)){
t10=t7;
f_9253(t10,t9);}
else{
t10=C_eqp(t3,lf[404]);
if(C_truep(t10)){
t11=t7;
f_9253(t11,t10);}
else{
t11=C_eqp(t3,lf[405]);
if(C_truep(t11)){
t12=t7;
f_9253(t12,t11);}
else{
t12=C_eqp(t3,lf[406]);
if(C_truep(t12)){
t13=t7;
f_9253(t13,t12);}
else{
t13=C_eqp(t3,lf[407]);
t14=t7;
f_9253(t14,(C_truep(t13)?t13:C_eqp(t3,lf[408])));}}}}}}}}

/* k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9253(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9253,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[336],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[337]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9272,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9272(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[400]);
t5=t3;
f_9272(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[401])));}}}

/* k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9272(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9272,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[338],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[339]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9291,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9291(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[397]);
if(C_truep(t4)){
t5=t3;
f_9291(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[398]);
t6=t3;
f_9291(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[399])));}}}}

/* k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9291(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9291,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9294,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm:913: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[341]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9361,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9361(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[394]);
if(C_truep(t4)){
t5=t3;
f_9361(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[395]);
t6=t3;
f_9361(t6,(C_truep(t5)?t5:C_eqp(((C_word*)t0)[5],lf[396])));}}}}

/* k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9361(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9361,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[340],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[342]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9380,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9380(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[387]);
if(C_truep(t4)){
t5=t3;
f_9380(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[388]);
if(C_truep(t5)){
t6=t3;
f_9380(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[389]);
if(C_truep(t6)){
t7=t3;
f_9380(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[390]);
if(C_truep(t7)){
t8=t3;
f_9380(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[391]);
if(C_truep(t8)){
t9=t3;
f_9380(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[392]);
t10=t3;
f_9380(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[5],lf[393])));}}}}}}}}

/* k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9380,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9383,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
/* support.scm:925: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[344]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9462,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9462(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[380]);
if(C_truep(t4)){
t5=t3;
f_9462(t5,t4);}
else{
t5=C_eqp(((C_word*)t0)[4],lf[381]);
if(C_truep(t5)){
t6=t3;
f_9462(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[382]);
if(C_truep(t6)){
t7=t3;
f_9462(t7,t6);}
else{
t7=C_eqp(((C_word*)t0)[4],lf[383]);
if(C_truep(t7)){
t8=t3;
f_9462(t8,t7);}
else{
t8=C_eqp(((C_word*)t0)[4],lf[384]);
if(C_truep(t8)){
t9=t3;
f_9462(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[4],lf[385]);
t10=t3;
f_9462(t10,(C_truep(t9)?t9:C_eqp(((C_word*)t0)[4],lf[386])));}}}}}}}}

/* k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9462(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9462,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_i_assq(((C_word*)t0)[5],lf[345]);
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[79],t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,t5,t6);
t8=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[343],t7));}}
else{
t2=C_eqp(((C_word*)t0)[4],lf[346]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9501,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9501(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[378]);
t5=t3;
f_9501(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[4],lf[379])));}}}

/* k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9501(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9501,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[347],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[348]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9520,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9520(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[376]);
t5=t3;
f_9520(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[377])));}}}

/* k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9520(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9520,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[6]);}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[349],t2));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[350]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9539,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9539(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[374]);
t5=t3;
f_9539(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[375])));}}}

/* k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9539(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9539,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9542,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm:945: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[352]);
if(C_truep(t2)){
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[351],t3));}
else{
t3=C_eqp(((C_word*)t0)[5],lf[353]);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9619,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t3)){
t5=t4;
f_9619(t5,t3);}
else{
t5=C_eqp(((C_word*)t0)[5],lf[371]);
if(C_truep(t5)){
t6=t4;
f_9619(t6,t5);}
else{
t6=C_eqp(((C_word*)t0)[5],lf[372]);
t7=t4;
f_9619(t7,(C_truep(t6)?t6:C_eqp(((C_word*)t0)[5],lf[373])));}}}}}

/* k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9619(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9619,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9622,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
/* support.scm:953: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[356]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9704,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t2)){
t4=t3;
f_9704(t4,t2);}
else{
t4=C_eqp(((C_word*)t0)[5],lf[369]);
t5=t3;
f_9704(t5,(C_truep(t4)?t4:C_eqp(((C_word*)t0)[5],lf[370])));}}}

/* k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9704(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9704,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(*((C_word*)lf[333]+1))){
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[354],t2));}
else{
t2=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[355],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,lf[354],t4));}}
else{
t2=C_eqp(((C_word*)t0)[5],lf[357]);
if(C_truep(t2)){
if(C_truep(*((C_word*)lf[333]+1))){
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[358],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_cons(&a,2,lf[354],t5));}
else{
t3=C_a_i_cons(&a,2,((C_word*)t0)[7],C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[358],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[355],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[354],t7));}}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9779,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_i_symbolp(((C_word*)t0)[3]))){
/* support.scm:969: ##sys#hash-table-ref */
t4=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,*((C_word*)lf[368]+1),((C_word*)t0)[3]);}
else{
t4=t3;
f_9779(2,t4,C_SCHEME_FALSE);}}}}

/* k9777 in k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9779(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9779,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9783,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
/* g22382239 */
t3=t2;
f_9783(t3,((C_word*)t0)[5],t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[4]))){
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[359]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9818,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t2,a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[3],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t3)){
t5=t4;
f_9818(t5,t3);}
else{
t5=C_eqp(t2,lf[339]);
if(C_truep(t5)){
t6=t4;
f_9818(t6,t5);}
else{
t6=C_eqp(t2,lf[367]);
t7=t4;
f_9818(t7,(C_truep(t6)?t6:C_eqp(t2,lf[350])));}}}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[3]);}}}

/* k9816 in k9777 in k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9818(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9818,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9821,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm:975: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(((C_word*)t0)[4],lf[360]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[4],lf[361]));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9888,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
/* support.scm:981: gensym */
t5=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t4=C_eqp(((C_word*)t0)[4],lf[364]);
if(C_truep(t4)){
t5=C_a_i_cons(&a,2,lf[362],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[79],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[6],t7);
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_cons(&a,2,lf[363],t8));}
else{
t5=C_eqp(((C_word*)t0)[4],lf[365]);
if(C_truep(t5)){
t6=C_i_cadr(((C_word*)t0)[3]);
/* support.scm:988: repeat */
t7=((C_word*)((C_word*)t0)[2])[1];
f_9224(t7,((C_word*)t0)[5],t6);}
else{
t6=C_eqp(((C_word*)t0)[4],lf[366]);
if(C_truep(t6)){
if(C_truep(*((C_word*)lf[333]+1))){
t7=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,((C_word*)t0)[6]);}
else{
t7=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[347],t7));}}
else{
t7=C_eqp(((C_word*)t0)[4],lf[341]);
t8=(C_truep(t7)?t7:C_eqp(((C_word*)t0)[4],lf[352]));
if(C_truep(t8)){
t9=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t10=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[351],t9));}
else{
t9=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,((C_word*)t0)[6]);}}}}}}}

/* k9886 in k9816 in k9777 in k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9888(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[51],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9888,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,lf[362],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[79],t5);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,((C_word*)t0)[3],t7);
t9=C_a_i_cons(&a,2,lf[363],t8);
t10=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,lf[79],t10);
t12=C_a_i_cons(&a,2,t11,C_SCHEME_END_OF_LIST);
t13=C_a_i_cons(&a,2,t9,t12);
t14=C_a_i_cons(&a,2,t1,t13);
t15=C_a_i_cons(&a,2,lf[210],t14);
t16=C_a_i_cons(&a,2,t15,C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t4,t16);
t18=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t18+1)))(2,t18,C_a_i_cons(&a,2,lf[89],t17));}

/* k9819 in k9816 in k9777 in k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9821,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[351],t5);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[79],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t6,t9);
t11=C_a_i_cons(&a,2,t1,t10);
t12=C_a_i_cons(&a,2,lf[210],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_cons(&a,2,lf[89],t14));}

/* g2238 in k9777 in k9702 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9783(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9783,NULL,3,t0,t1,t2);}
if(C_truep(C_i_vectorp(t2))){
t3=C_i_vector_ref(t2,C_fix(0));
/* support.scm:971: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}
else{
t3=t2;
/* support.scm:971: next */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}}

/* k9620 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[26],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9622,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9653,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[333]+1))){
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9653(t7,C_a_i_cons(&a,2,lf[354],t6));}
else{
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[355],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=t5;
f_9653(t9,C_a_i_cons(&a,2,lf[354],t8));}}

/* k9651 in k9620 in k9617 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9653(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9653,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[79],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[210],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[89],t9));}

/* k9540 in k9537 in k9518 in k9499 in k9460 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9542(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[42],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9542,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[351],t5);
t7=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,lf[79],t7);
t9=C_a_i_cons(&a,2,t8,C_SCHEME_END_OF_LIST);
t10=C_a_i_cons(&a,2,t6,t9);
t11=C_a_i_cons(&a,2,t1,t10);
t12=C_a_i_cons(&a,2,lf[210],t11);
t13=C_a_i_cons(&a,2,t12,C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,t4,t13);
t15=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,C_a_i_cons(&a,2,lf[89],t14));}

/* k9381 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9383,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9414,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[333]+1))){
t6=t5;
f_9414(t6,t1);}
else{
t6=C_a_i_cons(&a,2,((C_word*)t0)[2],C_SCHEME_END_OF_LIST);
t7=C_a_i_cons(&a,2,lf[79],t6);
t8=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,t7,t8);
t10=t5;
f_9414(t10,C_a_i_cons(&a,2,lf[343],t9));}}

/* k9412 in k9381 in k9378 in k9359 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9414(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9414,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[79],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[210],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[89],t9));}

/* k9292 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9294,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9325,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(*((C_word*)lf[333]+1))){
t6=t5;
f_9325(t6,t1);}
else{
t6=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t7=t5;
f_9325(t7,C_a_i_cons(&a,2,lf[340],t6));}}

/* k9323 in k9292 in k9289 in k9270 in k9251 in repeat in a9217 in ##compiler#foreign-type-check in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9325(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9325,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_SCHEME_FALSE,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[79],t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_cons(&a,2,t1,t4);
t6=C_a_i_cons(&a,2,((C_word*)t0)[4],t5);
t7=C_a_i_cons(&a,2,lf[210],t6);
t8=C_a_i_cons(&a,2,t7,C_SCHEME_END_OF_LIST);
t9=C_a_i_cons(&a,2,((C_word*)t0)[3],t8);
t10=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t10+1)))(2,t10,C_a_i_cons(&a,2,lf[89],t9));}

/* ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9154(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_9154,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9158,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
/* support.scm:884: open-output-file */
t5=*((C_word*)lf[328]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t3);}
else{
/* support.scm:884: current-output-port */
t5=*((C_word*)lf[329]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9158(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9158,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9161,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9169,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:885: with-output-to-port */
t4=*((C_word*)lf[327]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t1,t3);}

/* a9168 in k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9169,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9175,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_9175(t5,t1,((C_word*)t0)[2]);}

/* loop2019 in a9168 in k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_9175(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_9175,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9193,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9187,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:889: pretty-print */
t6=*((C_word*)lf[326]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k9185 in loop2019 in a9168 in k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9187(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:890: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k9191 in loop2019 in a9168 in k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9193(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_9175(t3,((C_word*)t0)[2],t2);}

/* k9159 in k9156 in ##compiler#pprint-expressions-to-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(((C_word*)t0)[4])){
/* support.scm:892: close-output-port */
t2=*((C_word*)lf[325]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9073(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_9073,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_9079,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_9085,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t3,t4);}

/* a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9085(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6,C_word t7,C_word t8){
C_word tmp;
C_word t9;
C_word t10;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr9,(void*)f_9085,9,t0,t1,t2,t3,t4,t5,t6,t7,t8);}
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9092,a[2]=t2,a[3]=t3,a[4]=t4,a[5]=t5,a[6]=t6,a[7]=t7,a[8]=t8,a[9]=t1,tmp=(C_word)a,a+=10,tmp);
/* support.scm:872: debugging */
t10=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t9,lf[322],lf[323]);}

/* k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9092(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9092,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_9095,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],tmp=(C_word)a,a+=11,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[321],t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[9];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9095(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9095,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9098,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],a[9]=((C_word*)t0)[10],tmp=(C_word)a,a+=10,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[4]);}

/* k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9098,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_9101,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],tmp=(C_word)a,a+=10,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[320],((C_word*)t0)[3]);}

/* k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9101(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9101,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9104,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9104(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9104,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9107,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9107(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9107,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_9110,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[319],t2);}

/* k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9113,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9113,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9116,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9116(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9116,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_9119,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[318],t2);}

/* k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9119(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9119,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9122,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9122,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9125,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9125(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9125,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_9128,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[317],t2);}

/* k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9128(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9128,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9131,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9131(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9131,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9134,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9134,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_9137,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[316],t2);}

/* k9135 in k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9137,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9140,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9138 in k9135 in k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9140,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9143,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(10),((C_word*)t0)[2]);}

/* k9141 in k9138 in k9135 in k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9143(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9143,2,t0,t1);}
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_9146,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[315],t2);}

/* k9144 in k9141 in k9138 in k9135 in k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9146(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9146,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_9149,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k9147 in k9144 in k9141 in k9138 in k9135 in k9132 in k9129 in k9126 in k9123 in k9120 in k9117 in k9114 in k9111 in k9108 in k9105 in k9102 in k9099 in k9096 in k9093 in k9090 in a9084 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9149(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* a9078 in ##compiler#print-program-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_9079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_9079,2,t0,t1);}
/* support.scm:871: compute-database-statistics */
t2=*((C_word*)lf[311]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* ##compiler#compute-database-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8965(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8965,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_fix(0);
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_fix(0);
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_fix(0);
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_fix(0);
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8969,a[2]=t10,a[3]=t12,a[4]=t8,a[5]=t4,a[6]=t6,a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t14=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8974,a[2]=t12,a[3]=t4,a[4]=t6,a[5]=t8,a[6]=t10,tmp=(C_word)a,a+=7,tmp);
/* support.scm:847: ##sys#hash-table-for-each */
t15=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t13,t14,t2);}

/* a8973 in ##compiler#compute-database-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8974(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8974,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8980,a[2]=t5,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp));
t7=((C_word*)t5)[1];
f_8980(t7,t1,t3);}

/* loop1946 in a8973 in ##compiler#compute-database-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8980(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(27);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8980,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8988,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_8988(C_a_i(&a,20),t3,t4);
t6=C_slot(t2,C_fix(1));
t9=t1;
t10=t6;
t1=t9;
t2=t10;
goto loop;}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g1953 in loop1946 in a8973 in ##compiler#compute-database-statistics in k4191 in k4188 in k3155 in k3152 */
static C_word C_fcall f_8988(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_stack_check;
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[6])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t4=C_i_car(t1);
t5=C_eqp(t4,lf[174]);
if(C_truep(t5)){
t6=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[5])[1],C_fix(1));
t7=C_mutate(((C_word *)((C_word*)t0)[5])+1,t6);
return(t7);}
else{
t6=C_eqp(t4,lf[157]);
if(C_truep(t6)){
t7=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[4])[1],C_fix(1));
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t7);
t9=C_i_cdr(t1);
t10=C_slot(t9,C_fix(1));
t11=C_eqp(lf[218],t10);
if(C_truep(t11)){
t12=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t13=C_mutate(((C_word *)((C_word*)t0)[3])+1,t12);
return(t13);}
else{
t12=C_SCHEME_UNDEFINED;
return(t12);}}
else{
t7=C_eqp(t4,lf[163]);
if(C_truep(t7)){
t8=C_i_cdr(t1);
t9=C_i_length(t8);
t10=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[2])[1],t9);
t11=C_mutate(((C_word *)((C_word*)t0)[2])+1,t10);
return(t11);}
else{
t8=C_SCHEME_UNDEFINED;
return(t8);}}}}

/* k8967 in ##compiler#compute-database-statistics in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8969(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:861: values */
C_values(9,0,((C_word*)t0)[7],*((C_word*)lf[312]+1),*((C_word*)lf[313]+1),((C_word*)((C_word*)t0)[6])[1],((C_word*)((C_word*)t0)[5])[1],((C_word*)((C_word*)t0)[4])[1],((C_word*)((C_word*)t0)[3])[1],((C_word*)((C_word*)t0)[2])[1]);}

/* ##sys#toplevel-definition-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8944(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_8944,6,t0,t1,t2,t3,t4,t5);}
t6=(C_truep(t5)?C_SCHEME_FALSE:C_i_not(t4));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8954,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:824: debugging */
t8=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t7,lf[240],lf[310],t2);}
else{
t7=C_SCHEME_UNDEFINED;
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}}

/* k8952 in ##sys#toplevel-definition-hook in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:825: hide-variable */
t2=*((C_word*)lf[309]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#dump-global-refs in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8895(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8895,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8901,tmp=(C_word)a,a+=2,tmp);
/* support.scm:810: ##sys#hash-table-for-each */
t4=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8900 in ##compiler#dump-global-refs in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8901(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8901,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8942,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* support.scm:812: keyword? */
t5=*((C_word*)lf[305]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8940 in a8900 in ##compiler#dump-global-refs in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8942(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8942,2,t0,t1);}
t2=(C_truep(t1)?C_SCHEME_FALSE:C_i_assq(lf[174],((C_word*)t0)[4]));
if(C_truep(t2)){
t3=C_i_assq(lf[162],((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8914,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=C_i_cdr(t3);
t6=C_i_length(t5);
t7=C_a_i_list(&a,2,((C_word*)t0)[2],t6);
/* support.scm:814: write */
t8=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t4,t7);}
else{
t5=C_a_i_list(&a,2,((C_word*)t0)[2],C_fix(0));
/* support.scm:814: write */
t6=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8912 in k8940 in a8900 in ##compiler#dump-global-refs in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8914(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:815: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-defined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8858(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8858,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8864,tmp=(C_word)a,a+=2,tmp);
/* support.scm:800: ##sys#hash-table-for-each */
t4=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8863 in ##compiler#dump-defined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8864(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8864,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8871,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8893,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:802: keyword? */
t6=*((C_word*)lf[305]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8891 in a8863 in ##compiler#dump-defined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_8871(t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[174],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_8871(t3,(C_truep(t2)?C_i_assq(lf[172],((C_word*)t0)[2]):C_SCHEME_FALSE));}}

/* k8869 in a8863 in ##compiler#dump-defined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8871(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8871,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8874,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:805: write */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8872 in k8869 in a8863 in ##compiler#dump-defined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:806: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#dump-undefined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8817(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8817,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8823,tmp=(C_word)a,a+=2,tmp);
/* support.scm:790: ##sys#hash-table-for-each */
t4=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t3,t2);}

/* a8822 in ##compiler#dump-undefined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8823(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8823,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8830,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8856,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:792: keyword? */
t6=*((C_word*)lf[305]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}

/* k8854 in a8822 in ##compiler#dump-undefined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
f_8830(t2,C_SCHEME_FALSE);}
else{
if(C_truep(C_i_assq(lf[174],((C_word*)t0)[2]))){
t2=C_i_assq(lf[172],((C_word*)t0)[2]);
t3=((C_word*)t0)[3];
f_8830(t3,C_i_not(t2));}
else{
t2=((C_word*)t0)[3];
f_8830(t2,C_SCHEME_FALSE);}}}

/* k8828 in a8822 in ##compiler#dump-undefined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8830(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8830,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8833,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:795: write */
t3=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8831 in k8828 in a8822 in ##compiler#dump-undefined-globals in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8833(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:796: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#simple-lambda-node? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8695,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(2));
t5=C_i_caddr(t4);
t6=C_i_pairp(t5);
t7=(C_truep(t6)?C_i_car(t5):C_SCHEME_FALSE);
if(C_truep(t7)){
if(C_truep(C_i_cadr(t4))){
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8724,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp));
t11=((C_word*)t9)[1];
f_8724(3,t11,t1,t2);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}

/* rec in ##compiler#simple-lambda-node? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8724,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=C_eqp(t4,lf[230]);
if(C_truep(t5)){
t6=t2;
t7=C_slot(t6,C_fix(3));
t8=C_i_car(t7);
t9=C_slot(t8,C_fix(1));
t10=C_eqp(lf[205],t9);
if(C_truep(t10)){
t11=C_slot(t8,C_fix(2));
t12=C_i_car(t11);
t13=C_eqp(((C_word*)t0)[3],t12);
if(C_truep(t13)){
t14=C_i_cdr(t7);
/* support.scm:782: every */
t15=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t15+1)))(4,t15,t1,((C_word*)((C_word*)t0)[2])[1],t14);}
else{
t14=t1;
((C_proc2)(void*)(*((C_word*)t14+1)))(2,t14,C_SCHEME_FALSE);}}
else{
t11=t1;
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_SCHEME_FALSE);}}
else{
t6=C_eqp(t4,lf[221]);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_SCHEME_FALSE);}
else{
t7=t2;
t8=C_slot(t7,C_fix(3));
/* support.scm:784: every */
t9=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t1,((C_word*)((C_word*)t0)[2])[1],t8);}}}

/* ##compiler#expression-has-side-effects? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8594(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8594,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8600,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_8600(3,t7,t1,t2);}

/* walk in ##compiler#expression-has-side-effects? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8600(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8600,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=C_eqp(t6,lf[205]);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8626,a[2]=t4,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t6,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t7)){
t9=t8;
f_8626(t9,t7);}
else{
t9=C_eqp(t6,lf[79]);
if(C_truep(t9)){
t10=t8;
f_8626(t10,t9);}
else{
t10=C_eqp(t6,lf[211]);
if(C_truep(t10)){
t11=t8;
f_8626(t11,t10);}
else{
t11=C_eqp(t6,lf[222]);
t12=t8;
f_8626(t12,(C_truep(t11)?t11:C_eqp(t6,lf[209])));}}}}

/* k8624 in walk in ##compiler#expression-has-side-effects? in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8626(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8626,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[218]);
if(C_truep(t2)){
t3=((C_word*)t0)[4];
t4=C_slot(t3,C_fix(2));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8640,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
/* support.scm:765: find */
t7=*((C_word*)lf[301]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[6],t6,*((C_word*)lf[302]+1));}
else{
t3=C_eqp(((C_word*)t0)[5],lf[210]);
if(C_truep(t3)){
if(C_truep(t3)){
/* support.scm:766: any */
t4=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_TRUE);}}
else{
t4=C_eqp(((C_word*)t0)[5],lf[89]);
if(C_truep(t4)){
/* support.scm:766: any */
t5=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[6],((C_word*)((C_word*)t0)[3])[1],((C_word*)t0)[2]);}
else{
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_TRUE);}}}}}

/* a8639 in k8624 in walk in ##compiler#expression-has-side-effects? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8640(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8640,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8648,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:765: foreign-callback-stub-id */
t4=*((C_word*)lf[300]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k8646 in a8639 in k8624 in walk in ##compiler#expression-has-side-effects? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8648(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_eqp(((C_word*)t0)[2],t1));}

/* ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8369(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[27],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_8369,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8372,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t14=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8406,a[2]=t10,a[3]=t8,tmp=(C_word)a,a+=4,tmp));
t15=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8449,a[2]=t10,a[3]=t12,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8568,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* support.scm:749: matchn */
t17=((C_word*)t12)[1];
f_8449(t17,t16,t2,t3);}

/* k8566 in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8568(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8568,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8574,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[3];
t4=C_slot(t3,C_fix(1));
t5=((C_word*)t0)[3];
t6=C_slot(t5,C_fix(2));
/* support.scm:752: debugging */
t7=*((C_word*)lf[10]+1);
((C_proc7)(void*)(*((C_word*)t7+1)))(7,t7,t2,lf[297],lf[298],t4,t6,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8572 in k8566 in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8574(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=((C_word*)((C_word*)t0)[3])[1];
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* matchn in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8449(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8449,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:738: resolve */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8372(t4,t1,t3,t2);}
else{
t4=t2;
t5=C_slot(t4,C_fix(1));
t6=C_i_car(t3);
t7=C_eqp(t5,t6);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8471,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t3,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
t9=t2;
t10=C_slot(t9,C_fix(2));
t11=C_i_cadr(t3);
/* support.scm:740: match1 */
t12=((C_word*)((C_word*)t0)[2])[1];
f_8406(t12,t8,t10,t11);}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}

/* k8469 in matchn in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8471(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8471,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[6];
t3=C_slot(t2,C_fix(3));
t4=C_i_cddr(((C_word*)t0)[5]);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8489,a[2]=((C_word*)t0)[3],a[3]=t6,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_8489(t8,((C_word*)t0)[2],t3,t4);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* loop in k8469 in matchn in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8489(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8489,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_nullp(t2));}
else{
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:744: resolve */
t4=((C_word*)((C_word*)t0)[4])[1];
f_8372(t4,t1,t3,t2);}
else{
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8520,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:746: matchn */
t7=((C_word*)((C_word*)t0)[2])[1];
f_8449(t7,t4,t5,t6);}}}}

/* k8518 in loop in k8469 in matchn in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:747: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8489(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* match1 in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8406(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_8406,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_not_pair_p(t3))){
/* support.scm:731: resolve */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8372(t4,t1,t3,t2);}
else{
if(C_truep(C_i_not_pair_p(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8428,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t5=C_i_car(t2);
t6=C_i_car(t3);
/* support.scm:733: match1 */
t8=t4;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}

/* k8426 in match1 in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8428(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[5]);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:733: match1 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_8406(t4,((C_word*)t0)[2],t2,t3);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* resolve in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8372(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8372,NULL,4,t0,t1,t2,t3);}
t4=C_i_assq(t2,((C_word*)((C_word*)t0)[3])[1]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8380,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* g17961797 */
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,f_8380(t5,t4));}
else{
if(C_truep(C_i_memq(t2,((C_word*)t0)[2]))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8401,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:726: alist-cons */
t6=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t2,t3,((C_word*)((C_word*)t0)[3])[1]);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_eqp(t2,t3));}}}

/* k8399 in resolve in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8401(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_TRUE);}

/* g1796 in resolve in ##compiler#match-node in k4191 in k4188 in k3155 in k3152 */
static C_word C_fcall f_8380(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_cdr(t1);
return(C_i_equalp(((C_word*)t0)[2],t2));}

/* ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8300(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8300,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8306,tmp=(C_word)a,a+=2,tmp);
/* support.scm:706: with-input-from-file */
t4=*((C_word*)lf[295]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8306,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8312,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8312(t5,t1);}

/* loop in a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8312(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8312,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8316,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:709: read */
t3=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k8314 in loop in a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8316,2,t0,t1);}
if(C_truep(C_eofp(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8352,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(t1);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8363,a[2]=t3,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(t1);
/* support.scm:714: sexpr->node */
t6=*((C_word*)lf[273]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}}

/* k8361 in k8314 in loop in a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8363(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8363,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8327,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:50: ##sys#put! */
t4=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[3],((C_word*)t0)[2],lf[292],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* tweaks.scm:50: ##sys#put! */
t6=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[3],((C_word*)t0)[2],lf[292],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}

/* k8325 in k8361 in k8314 in loop in a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[292],t1);}

/* k8350 in k8314 in loop in a8305 in ##compiler#load-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8352(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:715: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_8312(t2,((C_word*)t0)[2]);}

/* ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8063(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8063,4,t0,t1,t2,t3);}
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8067,a[2]=t2,a[3]=t7,a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8157,a[2]=t3,a[3]=t7,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
/* support.scm:669: ##sys#hash-table-for-each */
t10=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t8,t9,t3);}

/* a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8157(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_8157,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8164,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=t1,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* support.scm:671: variable-visible? */
t5=*((C_word*)lf[293]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8164,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(lf[159],((C_word*)t0)[7]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t2,a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[6],tmp=(C_word)a,a+=9,tmp);
t4=((C_word*)t0)[5];
/* tweaks.scm:53: ##sys#get */
t5=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,lf[292]);}
else{
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_FALSE);}}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8298,2,t0,t1);}
if(C_truep(C_i_structurep(t1,lf[195]))){
t2=((C_word*)t0)[8];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=C_i_assq(lf[157],((C_word*)t0)[7]);
t3=C_i_not(t2);
t4=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_8188,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[8],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t3)){
t5=t4;
f_8188(t5,t3);}
else{
t5=C_i_cdr(t2);
t6=C_eqp(lf[153],t5);
t7=t4;
f_8188(t7,C_i_not(t6));}}}

/* k8186 in k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8188(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8188,NULL,2,t0,t1);}
if(C_truep(t1)){
if(C_truep(C_i_assq(lf[184],((C_word*)t0)[8]))){
t2=C_i_cdr(((C_word*)t0)[7]);
t3=C_slot(t2,C_fix(2));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8265,a[2]=t3,a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* support.scm:680: get */
t5=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],((C_word*)t0)[5],lf[191]);}
else{
t4=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8263 in k8186 in k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8265,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_8222,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
t3=((C_word*)t0)[6];
/* tweaks.scm:53: ##sys#get */
t4=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,lf[291]);}}

/* k8220 in k8263 in k8186 in k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8222(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8222,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8225,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
t3=C_eqp(t1,lf[288]);
if(C_truep(t3)){
t4=t2;
f_8225(t4,C_SCHEME_TRUE);}
else{
t4=C_eqp(t1,lf[289]);
if(C_truep(t4)){
t5=t2;
f_8225(t5,C_SCHEME_FALSE);}
else{
t5=C_i_cadddr(((C_word*)t0)[2]);
t6=t2;
f_8225(t6,C_i_lessp(t5,*((C_word*)lf[290]+1)));}}}

/* k8223 in k8220 in k8263 in k8186 in k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)((C_word*)t0)[5])[1]);
t3=C_mutate(((C_word *)((C_word*)t0)[5])+1,t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8241,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t5=C_i_cdr(((C_word*)t0)[2]);
/* support.scm:687: node->sexpr */
t6=*((C_word*)lf[272]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k8239 in k8223 in k8220 in k8263 in k8186 in k8296 in k8162 in a8156 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8241(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8241,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=C_a_i_cons(&a,2,t2,((C_word*)((C_word*)t0)[3])[1]);
t4=C_mutate(((C_word *)((C_word*)t0)[3])+1,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8067,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8070,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(((C_word*)((C_word*)t0)[3])[1]))){
/* support.scm:690: delete-file* */
t3=*((C_word*)lf[279]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8106,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:691: with-output-to-file */
t4=*((C_word*)lf[287]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}}

/* a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8110,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8155,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:693: chicken-version */
t4=*((C_word*)lf[286]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k8153 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8155(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:693: print */
t2=*((C_word*)lf[275]+1);
((C_proc7)(void*)(*((C_word*)t2+1)))(7,t2,((C_word*)t0)[2],lf[282],t1,lf[283],*((C_word*)lf[284]+1),lf[285]);}

/* k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8110(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8110,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8113,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:699: reverse */
t4=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* k8118 in k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8120,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8122,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_8122(t5,((C_word*)t0)[2],t1);}

/* loop1732 in k8118 in k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8122(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8122,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8140,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8134,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:697: pp */
t6=*((C_word*)lf[281]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8132 in loop1732 in k8118 in k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:698: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k8138 in loop1732 in k8118 in k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8140(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_8122(t3,((C_word*)t0)[2],t2);}

/* k8111 in k8108 in a8105 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8113(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:700: print */
t2=*((C_word*)lf[275]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],lf[280]);}

/* k8068 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8070,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
/* support.scm:702: debugging */
t3=*((C_word*)lf[10]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[277],lf[278]);}
else{
t3=t2;
f_8076(2,t3,C_SCHEME_FALSE);}}

/* k8074 in k8068 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8076,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_8081,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_8089,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:703: sort-symbols */
t4=*((C_word*)lf[75]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)((C_word*)t0)[2])[1]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k8087 in k8074 in k8068 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* for-each */
t2=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a8080 in k8074 in k8068 in k8065 in ##compiler#emit-global-inline-file in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8081(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_8081,3,t0,t1,t2);}
t3=*((C_word*)lf[275]+1);
/* g17591760 */
t4=t3;
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,lf[276],t2);}

/* ##compiler#sexpr->node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7995(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7995,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_8001,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_8001(t6,t1,t2);}

/* walk in ##compiler#sexpr->node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8001,NULL,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=C_i_cadr(t2);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_8022,a[2]=t4,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_i_cddr(t2);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_8028,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t12,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t14=((C_word*)t12)[1];
f_8028(t14,t9,t10);}

/* loop1676 in walk in ##compiler#sexpr->node in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_8028(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_8028,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_8057,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16921693 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_8001(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k8055 in loop1676 in walk in ##compiler#sexpr->node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8057(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8057,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16761689 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8028(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16761689 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_8028(t6,((C_word*)t0)[3],t5);}}

/* k8020 in walk in ##compiler#sexpr->node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_8022(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_8022,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7909(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7909,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7915,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7915(t6,t1,t2);}

/* walk in ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7915(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7915,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(1));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7945,a[2]=t4,a[3]=t1,a[4]=t6,tmp=(C_word)a,a+=5,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7949,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t13=t2;
t14=C_slot(t13,C_fix(3));
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7960,a[2]=((C_word*)t0)[2],a[3]=t9,a[4]=t16,a[5]=t11,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_7960(t18,t12,t14);}

/* loop1641 in walk in ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7960(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7960,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7989,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g16571658 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7915(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7987 in loop1641 in walk in ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7989,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16411654 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7960(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop16411654 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7960(t6,((C_word*)t0)[3],t5);}}

/* k7947 in walk in ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7949(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k7943 in walk in ##compiler#node->sexpr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7945,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,((C_word*)t0)[2],t2));}

/* ##compiler#copy-node! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7870(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7870,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7874,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=t2;
t6=C_slot(t5,C_fix(1));
t7=t3;
t8=C_i_check_structure_2(t7,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t9=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t4,t7,C_fix(1),t6);}

/* k7872 in ##compiler#copy-node! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7874(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7874,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7877,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=((C_word*)t0)[2];
t4=C_slot(t3,C_fix(2));
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t5,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t7=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(2),t4);}

/* k7875 in k7872 in ##compiler#copy-node! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7877,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7880,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=((C_word*)t0)[2];
t4=C_slot(t3,C_fix(3));
t5=((C_word*)t0)[3];
t6=C_i_check_structure_2(t5,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t7=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t2,t5,C_fix(3),t4);}

/* k7878 in k7875 in k7872 in ##compiler#copy-node! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#tree-copy in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7836(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7836,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7842,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_7842(t6,t1,t2);}

/* rec in ##compiler#tree-copy in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7842(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
loop:
a=C_alloc(5);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7842,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7856,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:647: rec */
t7=t3;
t8=t4;
t1=t7;
t2=t8;
goto loop;}
else{
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7854 in rec in ##compiler#tree-copy in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7856(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7856,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7860,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:647: rec */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7842(t4,t2,t3);}

/* k7858 in k7854 in rec in ##compiler#tree-copy in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7860(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7860,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7437(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[16],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_7437,6,t0,t1,t2,t3,t4,t5);}
t6=C_SCHEME_END_OF_LIST;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7441,a[2]=t2,a[3]=t1,a[4]=t5,tmp=(C_word)a,a+=5,tmp);
t11=C_SCHEME_UNDEFINED;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_set_block_item(t12,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7787,a[2]=t7,a[3]=t12,a[4]=t9,tmp=(C_word)a,a+=5,tmp));
t14=((C_word*)t12)[1];
f_7787(t14,t10,t3,t4);}

/* loop1433 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7787(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7787,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[268]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7820,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g14521453 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7818 in loop1433 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7820(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7820,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7800,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_7800(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_7800(t5,t4);}}

/* k7798 in k7818 in loop1433 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7800(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop14331447 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7787(t5,((C_word*)t0)[2],t3,t4);}

/* k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7441(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7441,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7449,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
/* support.scm:642: walk */
t5=((C_word*)t3)[1];
f_7449(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7449(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word *a;
loop:
a=C_alloc(10);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_7449,NULL,4,t0,t1,t2,t3);}
t4=t2;
t5=C_slot(t4,C_fix(3));
t6=t2;
t7=C_slot(t6,C_fix(2));
t8=t2;
t9=C_slot(t8,C_fix(1));
t10=C_eqp(t9,lf[79]);
if(C_truep(t10)){
t11=t1;
t12=t11;
((C_proc2)(void*)(*((C_word*)t12+1)))(2,t12,C_a_i_record(&a,4,lf[195],t9,t7,C_SCHEME_END_OF_LIST));}
else{
t11=C_eqp(t9,lf[205]);
if(C_truep(t11)){
t12=C_i_car(t7);
t13=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7500,a[2]=t12,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t14=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7510,a[2]=t12,a[3]=((C_word*)t0)[3],a[4]=t13,tmp=(C_word)a,a+=5,tmp);
/* support.scm:610: get */
t15=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t15+1)))(5,t15,t14,((C_word*)t0)[3],t12,lf[175]);}
else{
t12=C_eqp(t9,lf[223]);
if(C_truep(t12)){
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7547,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t5,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t14=C_i_car(t7);
t15=t3;
/* support.scm:600: alist-ref */
t16=*((C_word*)lf[264]+1);
((C_proc6)(void*)(*((C_word*)t16+1)))(6,t16,t13,t14,t15,*((C_word*)lf[265]+1),t14);}
else{
t13=C_eqp(t9,lf[89]);
if(C_truep(t13)){
t14=C_i_car(t7);
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7563,a[2]=t3,a[3]=t14,a[4]=((C_word*)t0)[2],a[5]=t5,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t16=C_i_car(t5);
/* support.scm:619: walk */
t29=t15;
t30=t16;
t31=t3;
t1=t29;
t2=t30;
t3=t31;
goto loop;}
else{
t14=C_eqp(t9,lf[218]);
if(C_truep(t14)){
t15=C_i_caddr(t7);
t16=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7612,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t5,a[5]=((C_word*)t0)[2],a[6]=t7,tmp=(C_word)a,a+=7,tmp);
/* support.scm:626: decompose-lambda-list */
t17=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t17+1)))(4,t17,t1,t15,t16);}
else{
t15=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7772,a[2]=t5,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t9,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:641: tree-copy */
t16=*((C_word*)lf[270]+1);
((C_proc3)(void*)(*((C_word*)t16+1)))(3,t16,t15,t7);}}}}}}

/* k7770 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7772(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7772,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7776,a[2]=((C_word*)t0)[5],a[3]=t1,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7778,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t4=*((C_word*)lf[266]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a7777 in k7770 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7778(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7778,3,t0,t1,t2);}
/* g16051606 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7449(t3,t1,t2,((C_word*)t0)[2]);}

/* k7774 in k7770 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7776(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7776,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],((C_word*)t0)[2],t3,t1));}

/* a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7612(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7612,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7616,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t4,a[5]=t3,a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],a[8]=t1,a[9]=((C_word*)t0)[6],tmp=(C_word)a,a+=10,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7719,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7719(t13,t9,t2);}

/* loop1507 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7719(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7719,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7746,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7756,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g15231524 */
t6=t3;
f_7746(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7754 in loop1507 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7756(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7756,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15071520 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7719(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop15071520 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7719(t6,((C_word*)t0)[3],t5);}}

/* g1523 in loop1507 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7746(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7746,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7750,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:630: gensym */
t4=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}

/* k7748 in g1523 in loop1507 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7750,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7753,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:631: put! */
t3=*((C_word*)lf[134]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[269],C_SCHEME_TRUE);}

/* k7751 in k7748 in g1523 in loop1507 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7753(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[24],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7619,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=t1,a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7668,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7670,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_7670(t11,t7,((C_word*)t0)[2],t1);}

/* loop1534 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7670(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7670,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[268]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7703,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g15531554 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k7701 in loop1534 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7703(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7703,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7683,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_7683(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_7683(t5,t4);}}

/* k7681 in k7701 in loop1534 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7683(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop15341548 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7670(t5,((C_word*)t0)[2],t3,t4);}

/* k7666 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7668(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:634: append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_7645,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],tmp=(C_word)a,a+=10,tmp);
/* support.scm:637: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[267]);}

/* k7643 in k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7645(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7645,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[9]);
t3=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_7653,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[8],a[6]=t2,a[7]=t1,a[8]=((C_word*)t0)[9],tmp=(C_word)a,a+=9,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7661,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t5=((C_word*)t0)[2];
t6=((C_word*)t0)[6];
/* support.scm:600: alist-ref */
t7=*((C_word*)lf[264]+1);
((C_proc6)(void*)(*((C_word*)t7+1)))(6,t7,t4,t5,t6,*((C_word*)lf[265]+1),t5);}
else{
/* support.scm:638: build-lambda-list */
t5=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[4],((C_word*)t0)[3],C_SCHEME_FALSE);}}

/* k7659 in k7643 in k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7661(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:638: build-lambda-list */
t2=*((C_word*)lf[45]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7651 in k7643 in k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7653,2,t0,t1);}
t2=C_i_cadddr(((C_word*)t0)[8]);
t3=C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],t1,t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7635,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7637,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* map */
t6=*((C_word*)lf[266]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t4,t5,((C_word*)t0)[2]);}

/* a7636 in k7651 in k7643 in k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7637(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_7637,3,t0,t1,t2);}
/* g15811582 */
t3=((C_word*)((C_word*)t0)[3])[1];
f_7449(t3,t1,t2,((C_word*)t0)[2]);}

/* k7633 in k7651 in k7643 in k7617 in k7614 in a7611 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7635(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7635,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],lf[218],((C_word*)t0)[2],t1));}

/* k7561 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7563(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7563,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7566,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
/* support.scm:620: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[3]);}

/* k7564 in k7561 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7566,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7569,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* support.scm:621: alist-cons */
t3=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k7567 in k7564 in k7561 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7569,2,t0,t1);}
t2=C_a_i_list(&a,1,((C_word*)t0)[6]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7589,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=C_i_cadr(((C_word*)t0)[3]);
/* support.scm:624: walk */
t5=((C_word*)((C_word*)t0)[2])[1];
f_7449(t5,t3,t4,t1);}

/* k7587 in k7567 in k7564 in k7561 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7589,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[4],t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[89],((C_word*)t0)[2],t2));}

/* k7545 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7547(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7547,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7539,a[2]=t2,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[4]);
/* support.scm:616: walk */
t5=((C_word*)((C_word*)t0)[3])[1];
f_7449(t5,t3,t4,((C_word*)t0)[2]);}

/* k7537 in k7545 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7539(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7539,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[223],((C_word*)t0)[2],t2));}

/* k7508 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7510(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:611: put! */
t2=*((C_word*)lf[134]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],lf[175],C_SCHEME_FALSE);}
else{
t2=((C_word*)t0)[4];
f_7500(2,t2,C_SCHEME_UNDEFINED);}}

/* k7498 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7500(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7500,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_7507,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=((C_word*)t0)[3];
/* support.scm:600: alist-ref */
t4=*((C_word*)lf[264]+1);
((C_proc6)(void*)(*((C_word*)t4+1)))(6,t4,t2,((C_word*)t0)[2],t3,*((C_word*)lf[265]+1),((C_word*)t0)[2]);}

/* k7505 in k7498 in walk in k7439 in ##compiler#copy-node-tree-and-rename in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7507,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=C_a_i_list(&a,1,t1);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[205],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7289(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5,C_word t6){
C_word tmp;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr7,(void*)f_7289,7,t0,t1,t2,t3,t4,t5,t6);}
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7295,a[2]=t6,a[3]=t4,a[4]=t5,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* support.scm:577: decompose-lambda-list */
t8=*((C_word*)lf[105]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t1,t2,t7);}

/* a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7295(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7295,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7301,a[2]=t3,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7307,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t4,a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t5,t6);}

/* a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7307(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7307,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_7311,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t3,a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=t2,a[10]=t1,tmp=(C_word)a,a+=11,tmp);
if(C_truep(((C_word*)t0)[5])){
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7402,a[2]=t6,a[3]=t10,a[4]=t8,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_7402(t12,t4,((C_word*)t0)[3]);}
else{
t5=t4;
f_7311(2,t5,((C_word*)t0)[3]);}}

/* loop1386 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7402(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7402,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[90]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7431,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g14021403 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7429 in loop1386 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7431,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13861399 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7402(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13861399 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7402(t6,((C_word*)t0)[3],t5);}}

/* k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7311,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_7314,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)t0)[5])){
/* support.scm:583: copy-node-tree-and-rename */
t3=*((C_word*)lf[263]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}
else{
t3=t2;
f_7314(2,t3,((C_word*)t0)[4]);}}

/* k7312 in k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7314(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7314,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_7319,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7340,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t2,a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
if(C_truep(((C_word*)t0)[3])){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7394,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* support.scm:589: last */
t5=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[5]);}
else{
t4=t3;
f_7340(t4,t1);}}

/* k7392 in k7312 in k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[29],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7394,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
if(C_truep(C_i_nullp(((C_word*)t0)[4]))){
t3=C_a_i_list(&a,1,C_SCHEME_END_OF_LIST);
t4=C_a_i_record(&a,4,lf[195],lf[79],t3,C_SCHEME_END_OF_LIST);
t5=C_a_i_list(&a,2,t4,((C_word*)t0)[3]);
t6=((C_word*)t0)[2];
f_7340(t6,C_a_i_record(&a,4,lf[195],lf[89],t2,t5));}
else{
t3=C_i_length(((C_word*)t0)[4]);
t4=C_a_i_times(&a,2,C_fix(3),t3);
t5=C_a_i_list(&a,2,lf[262],t4);
t6=((C_word*)t0)[4];
t7=C_a_i_record(&a,4,lf[195],lf[228],t5,t6);
t8=C_a_i_list(&a,2,t7,((C_word*)t0)[3]);
t9=((C_word*)t0)[2];
f_7340(t9,C_a_i_record(&a,4,lf[195],lf[89],t2,t8));}}

/* k7338 in k7312 in k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7340(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7340,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7344,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* support.scm:595: take */
t3=*((C_word*)lf[261]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k7342 in k7338 in k7312 in k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7344(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:585: fold-right */
t2=*((C_word*)lf[260]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* a7318 in k7312 in k7309 in a7306 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7319(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[14],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_7319,5,t0,t1,t2,t3,t4);}
t5=C_a_i_list(&a,1,t2);
t6=C_a_i_list(&a,2,t3,t4);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_a_i_record(&a,4,lf[195],lf[89],t5,t6));}

/* a7300 in a7294 in ##compiler#inline-lambda-bindings in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7301,2,t0,t1);}
/* support.scm:580: split-at */
t2=*((C_word*)lf[259]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#fold-boolean in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7235(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_7235,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7241,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_7241(t7,t1,t3);}

/* fold in ##compiler#fold-boolean in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7241(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7241,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
C_apply(4,0,t1,((C_word*)t0)[3],t2);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7267,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=C_i_car(t2);
t6=C_i_cadr(t2);
/* support.scm:573: proc */
t7=((C_word*)t0)[3];
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t4,t5,t6);}}

/* k7265 in fold in ##compiler#fold-boolean in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7267,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7271,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:574: fold */
t4=((C_word*)((C_word*)t0)[2])[1];
f_7241(t4,t2,t3);}

/* k7269 in k7265 in fold in ##compiler#fold-boolean in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7271(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7271,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[220],lf[257],t2));}

/* ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6554(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_6554,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6560,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_6560(t6,t1,t2);}

/* walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6560(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6560,NULL,3,t0,t1,t2);}
t3=t2;
t4=C_slot(t3,C_fix(3));
t5=t2;
t6=C_slot(t5,C_fix(2));
t7=t2;
t8=C_slot(t7,C_fix(1));
t9=C_eqp(t8,lf[210]);
t10=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6594,a[2]=t6,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t8,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t9)){
t11=t10;
f_6594(t11,t9);}
else{
t11=C_eqp(t8,lf[254]);
t12=t10;
f_6594(t12,(C_truep(t11)?t11:C_eqp(t8,lf[255])));}}

/* k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6594(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word ab[25],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6594,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6601,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6603,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=t8,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_6603(t10,t6,((C_word*)t0)[3]);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[243]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6653,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6657,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6659,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6659(t12,t8,((C_word*)t0)[3]);}
else{
t3=C_eqp(((C_word*)t0)[5],lf[205]);
t4=(C_truep(t3)?t3:C_eqp(((C_word*)t0)[5],lf[209]));
if(C_truep(t4)){
t5=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_car(((C_word*)t0)[2]));}
else{
t5=C_eqp(((C_word*)t0)[5],lf[79]);
if(C_truep(t5)){
t6=C_i_car(((C_word*)t0)[2]);
t7=C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST);
t8=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_a_i_cons(&a,2,lf[79],t7));}
else{
t6=C_eqp(((C_word*)t0)[5],lf[89]);
if(C_truep(t6)){
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6738,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
t14=C_SCHEME_FALSE;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6754,a[2]=((C_word*)t0)[2],a[3]=t11,a[4]=t8,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t17=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6807,a[2]=t16,a[3]=((C_word*)t0)[4],a[4]=t13,a[5]=t15,tmp=(C_word)a,a+=6,tmp);
/* support.scm:545: butlast */
t18=*((C_word*)lf[246]+1);
((C_proc3)(void*)(*((C_word*)t18+1)))(3,t18,t17,((C_word*)t0)[3]);}
else{
t7=C_eqp(((C_word*)t0)[5],lf[218]);
if(C_truep(t7)){
t8=C_i_cadr(((C_word*)t0)[2]);
t9=(C_truep(t8)?lf[113]:lf[218]);
t10=C_i_caddr(((C_word*)t0)[2]);
t11=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6863,a[2]=t10,a[3]=t9,a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t12=C_i_car(((C_word*)t0)[3]);
/* support.scm:552: walk */
t13=((C_word*)((C_word*)t0)[4])[1];
f_6560(t13,t11,t12);}
else{
t8=C_eqp(((C_word*)t0)[5],lf[230]);
if(C_truep(t8)){
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6881,a[2]=((C_word*)t0)[4],a[3]=t10,a[4]=t14,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t16=((C_word*)t14)[1];
f_6881(t16,((C_word*)t0)[6],((C_word*)t0)[3]);}
else{
t9=C_eqp(((C_word*)t0)[5],lf[221]);
if(C_truep(t9)){
t10=C_i_car(((C_word*)t0)[2]);
t11=C_SCHEME_END_OF_LIST;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=C_SCHEME_FALSE;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6931,a[2]=t10,a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t16=C_SCHEME_UNDEFINED;
t17=(*a=C_VECTOR_TYPE|1,a[1]=t16,tmp=(C_word)a,a+=2,tmp);
t18=C_set_block_item(t17,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6933,a[2]=((C_word*)t0)[4],a[3]=t12,a[4]=t17,a[5]=t14,tmp=(C_word)a,a+=6,tmp));
t19=((C_word*)t17)[1];
f_6933(t19,t15,((C_word*)t0)[3]);}
else{
t10=C_eqp(((C_word*)t0)[5],lf[211]);
if(C_truep(t10)){
t11=((C_word*)t0)[6];
((C_proc2)(void*)(*((C_word*)t11+1)))(2,t11,C_a_i_list(&a,1,((C_word*)t0)[5]));}
else{
t11=C_eqp(((C_word*)t0)[5],lf[248]);
if(C_truep(t11)){
t12=C_i_car(((C_word*)t0)[2]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6990,a[2]=t14,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp));
t16=((C_word*)t14)[1];
f_6990(t16,((C_word*)t0)[6],t12,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);}
else{
t12=C_eqp(((C_word*)t0)[5],lf[249]);
t13=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7052,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
if(C_truep(t12)){
t14=t13;
f_7052(t14,t12);}
else{
t14=C_eqp(((C_word*)t0)[5],lf[251]);
if(C_truep(t14)){
t15=t13;
f_7052(t15,t14);}
else{
t15=C_eqp(((C_word*)t0)[5],lf[252]);
t16=t13;
f_7052(t16,(C_truep(t15)?t15:C_eqp(((C_word*)t0)[5],lf[253])));}}}}}}}}}}}}}

/* k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7052(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7052,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7059,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:562: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6560(t4,t2,t3);}
else{
t2=C_eqp(((C_word*)t0)[5],lf[228]);
t3=(C_truep(t2)?t2:C_eqp(((C_word*)t0)[5],lf[250]));
if(C_truep(t3)){
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7122,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7124,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_7124(t12,t8,((C_word*)t0)[3]);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7164,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7168,a[2]=((C_word*)t0)[4],a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7170,a[2]=((C_word*)t0)[2],a[3]=t6,a[4]=t11,a[5]=t8,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_7170(t13,t9,((C_word*)t0)[3]);}}}

/* loop1341 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7170(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7170,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7199,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13571358 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7197 in loop1341 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7199(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7199,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13411354 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7170(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13411354 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7170(t6,((C_word*)t0)[3],t5);}}

/* k7166 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7168(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:565: append */
t2=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7162 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7164(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7164,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* loop1318 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7124(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7124,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7153,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13341335 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7151 in loop1318 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7153,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13181331 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7124(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop13181331 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7124(t6,((C_word*)t0)[3],t5);}}

/* k7120 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:564: cons* */
t2=*((C_word*)lf[247]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k7057 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7059,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7063,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t7=C_i_cdr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_7069,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_7069(t11,t6,t7);}

/* loop1292 in k7057 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_7069(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_7069,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7098,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g13081309 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k7096 in loop1292 in k7057 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7098(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7098,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12921305 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7069(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12921305 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_7069(t6,((C_word*)t0)[3],t5);}}

/* k7061 in k7057 in k7050 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7063(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:562: cons* */
t2=*((C_word*)lf[247]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6990(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6990,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_zerop(t2))){
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_7008,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:559: reverse */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t4);}
else{
t5=C_a_i_minus(&a,2,t2,C_fix(1));
t6=C_i_cdr(t3);
t7=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_7039,a[2]=t6,a[3]=t5,a[4]=t1,a[5]=((C_word*)t0)[2],a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t8=C_i_car(t3);
/* support.scm:560: walk */
t9=((C_word*)((C_word*)t0)[3])[1];
f_6560(t9,t7,t8);}}

/* k7037 in loop in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7039,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* support.scm:560: loop */
t3=((C_word*)((C_word*)t0)[5])[1];
f_6990(t3,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k7006 in loop in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7008(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7008,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_7016,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* support.scm:559: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_6560(t4,t2,t3);}

/* k7014 in k7006 in loop in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_7016(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_7016,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[248],t3));}

/* loop1252 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6933(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6933,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6962,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g12681269 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6960 in loop1252 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6962(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6962,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12521265 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6933(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12521265 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6933(t6,((C_word*)t0)[3],t5);}}

/* k6929 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6931(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:554: cons* */
t2=*((C_word*)lf[247]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[221],((C_word*)t0)[2],t1);}

/* loop1229 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6881(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6881,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6910,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g12451246 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6908 in loop1229 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6910(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6910,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12291242 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6881(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12291242 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6881(t6,((C_word*)t0)[3],t5);}}

/* k6861 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6863(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6863,2,t0,t1);}
t2=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6805 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6807(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6807,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6809,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_6809(t5,((C_word*)t0)[2],t1);}

/* loop1206 in k6805 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6809(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6809,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6838,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g12221223 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6836 in loop1206 in k6805 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6838,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12061219 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6809(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop12061219 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6809(t6,((C_word*)t0)[3],t5);}}

/* k6752 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6754,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6756,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_6756(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop1180 in k6752 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6756(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6756,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=*((C_word*)lf[245]+1);
t7=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6789,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g11991200 */
t10=t6;
((C_proc4)(void*)(*((C_word*)t10+1)))(4,t10,t7,t8,t9);}
else{
t6=((C_word*)((C_word*)t0)[2])[1];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k6787 in loop1180 in k6752 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6789(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6789,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6769,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=t2,a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
if(C_truep(((C_word*)((C_word*)t0)[7])[1])){
t4=t3;
f_6769(t4,C_i_setslot(((C_word*)((C_word*)t0)[7])[1],C_fix(1),t2));}
else{
t4=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t5=t3;
f_6769(t5,t4);}}

/* k6767 in k6787 in loop1180 in k6752 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6769(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[7])+1,((C_word*)t0)[6]);
t3=C_slot(((C_word*)t0)[5],C_fix(1));
t4=C_slot(((C_word*)t0)[4],C_fix(1));
/* loop11801194 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_6756(t5,((C_word*)t0)[2],t3,t4);}

/* k6736 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6738,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6746,a[2]=((C_word*)t0)[4],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6750,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:546: last */
t4=*((C_word*)lf[244]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k6748 in k6736 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6750(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:546: walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_6560(t2,((C_word*)t0)[2],t1);}

/* k6744 in k6736 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6746(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6746,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[89],t3));}

/* loop1148 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6659(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6659,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6688,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g11641165 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6686 in loop1148 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6688(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6688,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11481161 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6659(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11481161 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6659(t6,((C_word*)t0)[3],t5);}}

/* k6655 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* ##sys#append */
t2=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST);}

/* k6651 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6653,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_cons(&a,2,lf[243],t2));}

/* loop1122 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6603(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6603,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6632,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g11381139 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_6560(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6630 in loop1122 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6632(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6632,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11221135 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6603(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop11221135 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6603(t6,((C_word*)t0)[3],t5);}}

/* k6599 in k6592 in walk in ##compiler#build-expression-tree in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6601,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5631(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5631,3,t0,t1,t2);}
t3=C_fix(0);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5634,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp));
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6549,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:529: walk */
t9=((C_word*)t6)[1];
f_5634(t9,t8,t2);}

/* k6547 in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6549,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6552,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:530: debugging */
t3=*((C_word*)lf[10]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,lf[240],lf[241],((C_word*)((C_word*)t0)[2])[1]);}

/* k6550 in k6547 in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6552(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5634(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word t87;
C_word t88;
C_word t89;
C_word t90;
C_word t91;
C_word t92;
C_word t93;
C_word t94;
C_word t95;
C_word t96;
C_word t97;
C_word t98;
C_word t99;
C_word t100;
C_word *a;
loop:
a=C_alloc(20);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_5634,NULL,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t1;
t4=t2;
t5=C_a_i_list(&a,1,t4);
t6=t3;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_a_i_record(&a,4,lf[195],lf[205],t5,C_SCHEME_END_OF_LIST));}
else{
if(C_truep(C_i_not_pair_p(t2))){
/* support.scm:464: bomb */
t3=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,lf[208],t2);}
else{
t3=C_i_car(t2);
if(C_truep(C_i_symbolp(t3))){
t4=C_i_car(t2);
t5=C_eqp(t4,lf[209]);
if(C_truep(t5)){
t6=C_i_cadr(t2);
t7=C_a_i_list(&a,1,t6);
t8=t1;
t9=t8;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_a_i_record(&a,4,lf[195],lf[209],t7,C_SCHEME_END_OF_LIST));}
else{
t6=C_eqp(t4,lf[210]);
t7=(C_truep(t6)?t6:C_eqp(t4,lf[211]));
if(C_truep(t7)){
t8=C_i_car(t2);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5709,a[2]=t8,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t14=C_i_cdr(t2);
t15=C_SCHEME_UNDEFINED;
t16=(*a=C_VECTOR_TYPE|1,a[1]=t15,tmp=(C_word)a,a+=2,tmp);
t17=C_set_block_item(t16,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5715,a[2]=((C_word*)t0)[3],a[3]=t10,a[4]=t16,a[5]=t12,tmp=(C_word)a,a+=6,tmp));
t18=((C_word*)t16)[1];
f_5715(t18,t13,t14);}
else{
t8=C_eqp(t4,lf[79]);
if(C_truep(t8)){
t9=C_i_cadr(t2);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5767,a[2]=t9,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_numberp(t9))){
t11=C_eqp(lf[215],*((C_word*)lf[216]+1));
if(C_truep(t11)){
t12=C_i_integerp(t9);
t13=t10;
f_5767(t13,C_i_not(t12));}
else{
t12=t10;
f_5767(t12,C_SCHEME_FALSE);}}
else{
t11=t10;
f_5767(t11,C_SCHEME_FALSE);}}
else{
t9=C_eqp(t4,lf[89]);
if(C_truep(t9)){
t10=C_i_cadr(t2);
t11=C_i_caddr(t2);
if(C_truep(C_i_nullp(t10))){
/* support.scm:483: walk */
t99=t1;
t100=t11;
t1=t99;
t2=t100;
goto loop;}
else{
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5826,a[2]=t2,a[3]=t11,a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* support.scm:484: unzip1 */
t13=*((C_word*)lf[217]+1);
((C_proc3)(void*)(*((C_word*)t13+1)))(3,t13,t12,t10);}}
else{
t10=C_eqp(t4,lf[113]);
t11=(C_truep(t10)?t10:C_eqp(t4,lf[218]));
if(C_truep(t11)){
t12=C_i_cadr(t2);
t13=C_a_i_list(&a,1,t12);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5919,a[2]=t13,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t15=C_i_caddr(t2);
/* support.scm:488: walk */
t99=t14;
t100=t15;
t1=t99;
t2=t100;
goto loop;}
else{
t12=C_eqp(t4,lf[219]);
if(C_truep(t12)){
t13=C_i_cadr(t2);
t14=C_i_car(t2);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5952,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t14,a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_pairp(t13))){
t16=C_i_car(t13);
t17=C_eqp(lf[79],t16);
if(C_truep(t17)){
t18=C_i_cadr(t13);
t19=t15;
f_5952(t19,C_a_i_list(&a,1,t18));}
else{
t18=t15;
f_5952(t18,C_a_i_list(&a,1,t13));}}
else{
t16=t15;
f_5952(t16,C_a_i_list(&a,1,t13));}}
else{
t13=C_eqp(t4,lf[220]);
t14=(C_truep(t13)?t13:C_eqp(t4,lf[221]));
if(C_truep(t14)){
t15=C_i_car(t2);
t16=C_i_cadr(t2);
t17=C_a_i_list(&a,1,t16);
t18=C_SCHEME_END_OF_LIST;
t19=(*a=C_VECTOR_TYPE|1,a[1]=t18,tmp=(C_word)a,a+=2,tmp);
t20=C_SCHEME_FALSE;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6044,a[2]=t17,a[3]=t15,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t23=C_i_cddr(t2);
t24=C_SCHEME_UNDEFINED;
t25=(*a=C_VECTOR_TYPE|1,a[1]=t24,tmp=(C_word)a,a+=2,tmp);
t26=C_set_block_item(t25,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6050,a[2]=((C_word*)t0)[3],a[3]=t19,a[4]=t25,a[5]=t21,tmp=(C_word)a,a+=6,tmp));
t27=((C_word*)t25)[1];
f_6050(t27,t22,t23);}
else{
t15=C_eqp(t4,lf[222]);
if(C_truep(t15)){
t16=C_i_cadr(t2);
t17=C_a_i_list(&a,2,t16,C_SCHEME_TRUE);
t18=t1;
t19=t18;
((C_proc2)(void*)(*((C_word*)t19+1)))(2,t19,C_a_i_record(&a,4,lf[195],lf[222],t17,C_SCHEME_END_OF_LIST));}
else{
t16=C_eqp(t4,lf[223]);
t17=(C_truep(t16)?t16:C_eqp(t4,lf[224]));
if(C_truep(t17)){
t18=C_i_cadr(t2);
t19=C_a_i_list(&a,1,t18);
t20=C_SCHEME_END_OF_LIST;
t21=(*a=C_VECTOR_TYPE|1,a[1]=t20,tmp=(C_word)a,a+=2,tmp);
t22=C_SCHEME_FALSE;
t23=(*a=C_VECTOR_TYPE|1,a[1]=t22,tmp=(C_word)a,a+=2,tmp);
t24=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6134,a[2]=t19,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t25=C_i_cddr(t2);
t26=C_SCHEME_UNDEFINED;
t27=(*a=C_VECTOR_TYPE|1,a[1]=t26,tmp=(C_word)a,a+=2,tmp);
t28=C_set_block_item(t27,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6140,a[2]=((C_word*)t0)[3],a[3]=t21,a[4]=t27,a[5]=t23,tmp=(C_word)a,a+=6,tmp));
t29=((C_word*)t27)[1];
f_6140(t29,t24,t25);}
else{
t18=C_eqp(t4,lf[225]);
if(C_truep(t18)){
t19=C_i_cadr(t2);
t20=C_i_cadr(t19);
t21=C_i_caddr(t2);
t22=C_i_cadr(t21);
t23=C_i_cadddr(t2);
t24=C_i_cadr(t23);
t25=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_6226,a[2]=t2,a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t24,a[6]=t22,a[7]=t20,tmp=(C_word)a,a+=8,tmp);
/* support.scm:507: fifth */
t26=*((C_word*)lf[227]+1);
((C_proc3)(void*)(*((C_word*)t26+1)))(3,t26,t25,t2);}
else{
t19=C_eqp(t4,lf[228]);
t20=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6247,a[2]=((C_word*)t0)[2],a[3]=t4,a[4]=((C_word*)t0)[3],a[5]=t1,a[6]=t2,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t19)){
t21=t20;
f_6247(t21,t19);}
else{
t21=C_eqp(t4,lf[235]);
if(C_truep(t21)){
t22=t20;
f_6247(t22,t21);}
else{
t22=C_eqp(t4,lf[236]);
if(C_truep(t22)){
t23=t20;
f_6247(t23,t22);}
else{
t23=C_eqp(t4,lf[237]);
t24=t20;
f_6247(t24,(C_truep(t23)?t23:C_eqp(t4,lf[238])));}}}}}}}}}}}}}}
else{
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6507,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6509,a[2]=((C_word*)t0)[3],a[3]=t5,a[4]=t10,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6509(t12,t8,t2);}}}}

/* loop1070 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6509(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6509,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6538,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g10861087 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6536 in loop1070 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6538,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10701083 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6509(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10701083 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6509(t6,((C_word*)t0)[3],t5);}}

/* k6505 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6507(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6507,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],lf[230],lf[239],t1));}

/* k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6247(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6247,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[6]);
t3=C_i_cadr(((C_word*)t0)[6]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6267,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t9=C_i_cddr(((C_word*)t0)[6]);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6273,a[2]=((C_word*)t0)[4],a[3]=t5,a[4]=t11,a[5]=t7,tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_6273(t13,t8,t9);}
else{
t2=C_eqp(((C_word*)t0)[3],lf[229]);
if(C_truep(t2)){
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6324,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t8=C_i_cdr(((C_word*)t0)[6]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6330,a[2]=((C_word*)t0)[4],a[3]=t4,a[4]=t10,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_6330(t12,t7,t8);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_6368,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6374,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[5],t3,t4);}}}

/* a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6374(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_6374,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6430,a[2]=t2,a[3]=t3,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6458,a[2]=t4,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t6=t2;
/* tweaks.scm:53: ##sys#get */
t7=*((C_word*)lf[233]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t5,t6,lf[234]);}

/* k6456 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6458(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6458,2,t0,t1);}
if(C_truep(t1)){
t2=C_a_i_plus(&a,2,((C_word*)((C_word*)t0)[3])[1],C_fix(1));
t3=C_mutate(((C_word *)((C_word*)t0)[3])+1,t2);
t4=((C_word*)t0)[2];
f_6430(t4,C_SCHEME_TRUE);}
else{
t2=((C_word*)t0)[2];
f_6430(t2,C_SCHEME_FALSE);}}

/* k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6430(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6430,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6434,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)t0)[3])){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_6437,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:523: real-name */
t4=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
/* support.scm:526: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6435 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6437(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6437,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6444,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=t1;
t4=((C_word*)t0)[4];
f_6434(2,t4,C_a_i_list(&a,2,((C_word*)t0)[3],t3));}
else{
/* support.scm:525: ##sys#symbol->qualified-string */
t3=*((C_word*)lf[232]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}}

/* k6442 in k6435 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6444(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6444,2,t0,t1);}
t2=((C_word*)t0)[3];
f_6434(2,t2,C_a_i_list(&a,2,((C_word*)t0)[2],t1));}

/* k6432 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6434(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[22],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6434,2,t0,t1);}
t2=C_a_i_list(&a,2,((C_word*)t0)[5],t1);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6391,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_6393,a[2]=((C_word*)t0)[3],a[3]=t4,a[4]=t9,a[5]=t6,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_6393(t11,t7,((C_word*)t0)[2]);}

/* loop1042 in k6432 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6393(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6393,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6422,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g10581059 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6420 in loop1042 in k6432 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6422(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6422,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10421055 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6393(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10421055 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6393(t6,((C_word*)t0)[3],t5);}}

/* k6389 in k6432 in k6428 in a6373 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6391,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],lf[230],((C_word*)t0)[2],t1));}

/* a6367 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6368(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6368,2,t0,t1);}
/* support.scm:515: get-line-2 */
t2=*((C_word*)lf[141]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,t1,((C_word*)t0)[2]);}

/* loop1000 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6330(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6330,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6359,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g10161017 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6357 in loop1000 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6359,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10001013 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6330(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10001013 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6330(t6,((C_word*)t0)[3],t5);}}

/* k6322 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6324(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6324,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],lf[230],lf[231],t1));}

/* loop972 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6273(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6273,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6302,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g988989 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6300 in loop972 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6302(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6302,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop972985 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6273(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop972985 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6273(t6,((C_word*)t0)[3],t5);}}

/* k6265 in k6245 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6267(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6267,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k6224 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[20],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6226,2,t0,t1);}
t2=C_i_cadr(t1);
t3=C_a_i_list(&a,4,((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6206,a[2]=t3,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_6210,a[2]=t4,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:508: sixth */
t6=*((C_word*)lf[226]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[2]);}

/* k6208 in k6224 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6210(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:508: walk */
t2=((C_word*)((C_word*)t0)[3])[1];
f_5634(t2,((C_word*)t0)[2],t1);}

/* k6204 in k6224 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6206,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[225],((C_word*)t0)[2],t2));}

/* loop926 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6140(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6140,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6169,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g942943 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6167 in loop926 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6169,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop926939 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6140(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop926939 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6140(t6,((C_word*)t0)[3],t5);}}

/* k6132 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6134(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6134,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],lf[223],((C_word*)t0)[2],t1));}

/* loop890 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_6050(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_6050,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_6079,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g906907 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k6077 in loop890 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6079,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop890903 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6050(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop890903 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_6050(t6,((C_word*)t0)[3],t5);}}

/* k6042 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_6044(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_6044,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k5950 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5952(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5952,NULL,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5956,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t7=C_i_cddr(((C_word*)t0)[3]);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5962,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_5962(t11,t6,t7);}

/* loop859 in k5950 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5962(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5962,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5991,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g875876 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5989 in loop859 in k5950 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5991(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5991,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop859872 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5962(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop859872 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5962(t6,((C_word*)t0)[3],t5);}}

/* k5954 in k5950 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5956(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5956,2,t0,t1);}
t2=((C_word*)t0)[4];
t3=((C_word*)t0)[3];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],((C_word*)t0)[2],t3,t1));}

/* k5917 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5919(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5919,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
t3=((C_word*)t0)[3];
t4=t3;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[113],((C_word*)t0)[2],t2));}

/* k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5826(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[21],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5826,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5830,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5834,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t8=C_i_cadr(((C_word*)t0)[2]);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5848,a[2]=t4,a[3]=t10,a[4]=t6,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp));
t12=((C_word*)t10)[1];
f_5848(t12,t7,t8);}

/* loop820 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5848(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5848,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5875,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5886,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g836837 */
t6=t3;
f_5875(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5884 in loop820 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5886,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop820833 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5848(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop820833 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5848(t6,((C_word*)t0)[3],t5);}}

/* g836 in loop820 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5875(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5875,NULL,3,t0,t1,t2);}
t3=C_i_cadr(t2);
/* support.scm:485: walk */
t4=((C_word*)((C_word*)t0)[2])[1];
f_5634(t4,t1,t3);}

/* k5832 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5834(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5834,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5842,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:486: walk */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5634(t3,t2,((C_word*)t0)[2]);}

/* k5840 in k5832 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5842,2,t0,t1);}
t2=C_a_i_list(&a,1,t1);
/* support.scm:485: append */
t3=*((C_word*)lf[51]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],((C_word*)t0)[2],t2);}

/* k5828 in k5824 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5830(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5830,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=((C_word*)t0)[2];
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[89],t3,t1));}

/* k5765 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5767(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5767,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5770,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:475: warning */
t3=*((C_word*)lf[213]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,lf[214],((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
t3=C_a_i_list(&a,1,((C_word*)t0)[2]);
t4=t2;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[79],t3,C_SCHEME_END_OF_LIST));}}

/* k5768 in k5765 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5770(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5770,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5777,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:477: truncate */
t3=*((C_word*)lf[212]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5775 in k5768 in k5765 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5777(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5777,2,t0,t1);}
t2=C_i_inexact_to_exact(t1);
t3=((C_word*)t0)[2];
t4=C_a_i_list(&a,1,t2);
t5=t3;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[195],lf[79],t4,C_SCHEME_END_OF_LIST));}

/* loop786 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5715(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5715,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5744,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
/* g802803 */
t5=((C_word*)((C_word*)t0)[2])[1];
f_5634(t5,t3,t4);}
else{
t3=((C_word*)((C_word*)t0)[3])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5742 in loop786 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5744(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5744,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop786799 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5715(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop786799 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5715(t6,((C_word*)t0)[3],t5);}}

/* k5707 in walk in ##compiler#build-node-graph in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5709,2,t0,t1);}
t2=((C_word*)t0)[3];
t3=t2;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_a_i_record(&a,4,lf[195],((C_word*)t0)[2],C_SCHEME_END_OF_LIST,t1));}

/* ##compiler#qnode in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5616(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5616,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[79],t3,C_SCHEME_END_OF_LIST));}

/* ##compiler#varnode in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5601(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5601,3,t0,t1,t2);}
t3=C_a_i_list(&a,1,t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_record(&a,4,lf[195],lf[205],t3,C_SCHEME_END_OF_LIST));}

/* make-node in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5595(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_5595,5,t0,t1,t2,t3,t4);}
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_record(&a,4,lf[195],t2,t3,t4));}

/* node-subexpressions-set! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5586(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5586,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t5=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(3),t3);}

/* node-subexpressions in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5577(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5577,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[195],lf[201]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(3)));}

/* node-parameters-set! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5568(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5568,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t5=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(2),t3);}

/* node-parameters in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5559(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5559,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[195],lf[199]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(2)));}

/* node-class-set! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5550(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5550,4,t0,t1,t2,t3);}
t4=C_i_check_structure_2(t2,lf[195],C_SCHEME_FALSE);
/* ##sys#block-set! */
t5=*((C_word*)lf[198]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t1,t2,C_fix(1),t3);}

/* node-class in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5541(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5541,3,t0,t1,t2);}
t3=C_i_check_structure_2(t2,lf[195],lf[196]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_block_ref(t2,C_fix(1)));}

/* node? in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5535(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5535,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_structurep(t2,lf[195]));}

/* ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5036(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5036,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5040,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t4=t3;
f_5040(t4,C_SCHEME_UNDEFINED);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5533,a[2]=t3,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* support.scm:394: append */
t5=*((C_word*)lf[51]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,*((C_word*)lf[192]+1),*((C_word*)lf[193]+1),*((C_word*)lf[123]+1));}}

/* k5531 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5533(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,t1);
t3=((C_word*)t0)[2];
f_5040(t3,t2);}

/* k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5040(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5040,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5045,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* support.scm:397: ##sys#hash-table-for-each */
t3=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5045(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_5045,4,t0,t1,t2,t3);}
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_SCHEME_FALSE;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_END_OF_LIST;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_SCHEME_END_OF_LIST;
t13=(*a=C_VECTOR_TYPE|1,a[1]=t12,tmp=(C_word)a,a+=2,tmp);
if(C_truep(C_i_memq(t2,((C_word*)((C_word*)t0)[2])[1]))){
t14=C_SCHEME_UNDEFINED;
t15=t1;
((C_proc2)(void*)(*((C_word*)t15+1)))(2,t15,t14);}
else{
t14=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5055,a[2]=t3,a[3]=t9,a[4]=t7,a[5]=t5,a[6]=t13,a[7]=t11,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
/* support.scm:405: write */
t15=*((C_word*)lf[15]+1);
((C_proc3)(void*)(*((C_word*)t15+1)))(3,t15,t14,t2);}}

/* k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[18],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5055,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5058,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],tmp=(C_word)a,a+=8,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5218,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t4,tmp=(C_word)a,a+=8,tmp));
t6=((C_word*)t4)[1];
f_5218(t6,t2,((C_word*)t0)[2]);}

/* loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5218(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5218,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|9,a[1]=(C_word)f_5228,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=t1,a[8]=((C_word*)t0)[7],a[9]=t2,tmp=(C_word)a,a+=10,tmp);
/* support.scm:409: caar */
t4=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,t2);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word ab[17],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5228,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5231,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[9],tmp=(C_word)a,a+=5,tmp);
t3=C_eqp(t1,lf[154]);
t4=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_5244,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],a[7]=((C_word*)t0)[8],a[8]=((C_word*)t0)[6],a[9]=t1,a[10]=((C_word*)t0)[9],a[11]=t2,tmp=(C_word)a,a+=12,tmp);
if(C_truep(t3)){
t5=t4;
f_5244(t5,t3);}
else{
t5=C_eqp(t1,lf[172]);
if(C_truep(t5)){
t6=t4;
f_5244(t6,t5);}
else{
t6=C_eqp(t1,lf[173]);
if(C_truep(t6)){
t7=t4;
f_5244(t7,t6);}
else{
t7=C_eqp(t1,lf[174]);
if(C_truep(t7)){
t8=t4;
f_5244(t8,t7);}
else{
t8=C_eqp(t1,lf[175]);
if(C_truep(t8)){
t9=t4;
f_5244(t9,t8);}
else{
t9=C_eqp(t1,lf[176]);
if(C_truep(t9)){
t10=t4;
f_5244(t10,t9);}
else{
t10=C_eqp(t1,lf[177]);
if(C_truep(t10)){
t11=t4;
f_5244(t11,t10);}
else{
t11=C_eqp(t1,lf[178]);
if(C_truep(t11)){
t12=t4;
f_5244(t12,t11);}
else{
t12=C_eqp(t1,lf[179]);
if(C_truep(t12)){
t13=t4;
f_5244(t13,t12);}
else{
t13=C_eqp(t1,lf[180]);
if(C_truep(t13)){
t14=t4;
f_5244(t14,t13);}
else{
t14=C_eqp(t1,lf[181]);
if(C_truep(t14)){
t15=t4;
f_5244(t15,t14);}
else{
t15=C_eqp(t1,lf[182]);
if(C_truep(t15)){
t16=t4;
f_5244(t16,t15);}
else{
t16=C_eqp(t1,lf[183]);
if(C_truep(t16)){
t17=t4;
f_5244(t17,t16);}
else{
t17=C_eqp(t1,lf[184]);
if(C_truep(t17)){
t18=t4;
f_5244(t18,t17);}
else{
t18=C_eqp(t1,lf[185]);
if(C_truep(t18)){
t19=t4;
f_5244(t19,t18);}
else{
t19=C_eqp(t1,lf[186]);
if(C_truep(t19)){
t20=t4;
f_5244(t20,t19);}
else{
t20=C_eqp(t1,lf[187]);
if(C_truep(t20)){
t21=t4;
f_5244(t21,t20);}
else{
t21=C_eqp(t1,lf[188]);
if(C_truep(t21)){
t22=t4;
f_5244(t22,t21);}
else{
t22=C_eqp(t1,lf[189]);
if(C_truep(t22)){
t23=t4;
f_5244(t23,t22);}
else{
t23=C_eqp(t1,lf[190]);
t24=t4;
f_5244(t24,(C_truep(t23)?t23:C_eqp(t1,lf[191])));}}}}}}}}}}}}}}}}}}}}

/* k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5244(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5244,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5247,a[2]=((C_word*)t0)[10],a[3]=t2,a[4]=((C_word*)t0)[11],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=C_eqp(((C_word*)t0)[9],lf[153]);
if(C_truep(t2)){
t3=C_mutate(((C_word *)((C_word*)t0)[8])+1,lf[153]);
t4=C_i_cdr(((C_word*)t0)[10]);
/* support.scm:430: loop */
t5=((C_word*)((C_word*)t0)[7])[1];
f_5218(t5,((C_word*)t0)[6],t4);}
else{
t3=C_eqp(((C_word*)t0)[9],lf[157]);
if(C_truep(t3)){
t4=C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[153]);
if(C_truep(t4)){
t5=C_i_cdr(((C_word*)t0)[10]);
/* support.scm:430: loop */
t6=((C_word*)((C_word*)t0)[7])[1];
f_5218(t6,((C_word*)t0)[6],t5);}
else{
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5285,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[8],tmp=(C_word)a,a+=6,tmp);
/* support.scm:417: cdar */
t6=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,((C_word*)t0)[10]);}}
else{
t4=C_eqp(((C_word*)t0)[9],lf[159]);
if(C_truep(t4)){
t5=C_eqp(((C_word*)((C_word*)t0)[8])[1],lf[153]);
if(C_truep(t5)){
t6=C_i_cdr(((C_word*)t0)[10]);
/* support.scm:430: loop */
t7=((C_word*)((C_word*)t0)[7])[1];
f_5218(t7,((C_word*)t0)[6],t6);}
else{
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5301,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:419: cdar */
t7=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[10]);}}
else{
t5=C_eqp(((C_word*)t0)[9],lf[160]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5311,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[10],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* support.scm:421: cdar */
t7=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t7+1)))(3,t7,t6,((C_word*)t0)[10]);}
else{
t6=C_eqp(((C_word*)t0)[9],lf[161]);
t7=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_5320,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[9],a[7]=((C_word*)t0)[10],a[8]=((C_word*)t0)[11],tmp=(C_word)a,a+=9,tmp);
if(C_truep(t6)){
t8=t7;
f_5320(t8,t6);}
else{
t8=C_eqp(((C_word*)t0)[9],lf[165]);
if(C_truep(t8)){
t9=t7;
f_5320(t9,t8);}
else{
t9=C_eqp(((C_word*)t0)[9],lf[166]);
if(C_truep(t9)){
t10=t7;
f_5320(t10,t9);}
else{
t10=C_eqp(((C_word*)t0)[9],lf[143]);
if(C_truep(t10)){
t11=t7;
f_5320(t11,t10);}
else{
t11=C_eqp(((C_word*)t0)[9],lf[167]);
if(C_truep(t11)){
t12=t7;
f_5320(t12,t11);}
else{
t12=C_eqp(((C_word*)t0)[9],lf[168]);
if(C_truep(t12)){
t13=t7;
f_5320(t13,t12);}
else{
t13=C_eqp(((C_word*)t0)[9],lf[169]);
if(C_truep(t13)){
t14=t7;
f_5320(t14,t13);}
else{
t14=C_eqp(((C_word*)t0)[9],lf[170]);
t15=t7;
f_5320(t15,(C_truep(t14)?t14:C_eqp(((C_word*)t0)[9],lf[171])));}}}}}}}}}}}}}

/* k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5320(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5320,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5323,a[2]=((C_word*)t0)[7],a[3]=t2,a[4]=((C_word*)t0)[8],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t4=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,C_make_character(9),t2);}
else{
t2=C_eqp(((C_word*)t0)[6],lf[162]);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5350,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* support.scm:426: cdar */
t4=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[7]);}
else{
t3=C_eqp(((C_word*)t0)[6],lf[163]);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5360,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[7],a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
/* support.scm:428: cdar */
t5=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,((C_word*)t0)[7]);}
else{
t4=C_i_car(((C_word*)t0)[7]);
/* support.scm:429: bomb */
t5=*((C_word*)lf[5]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,((C_word*)t0)[8],lf[164],t4);}}}}

/* k5358 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5360(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5218(t4,((C_word*)t0)[2],t3);}

/* k5348 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5350(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5218(t4,((C_word*)t0)[2],t3);}

/* k5321 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5323(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5323,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5326,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5340,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:424: caar */
t4=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}

/* k5338 in k5321 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5340(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
t2=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5326(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5326,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5329,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(61),((C_word*)t0)[3]);}

/* k5327 in k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5329,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5336,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:424: cdar */
t3=*((C_word*)lf[158]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5334 in k5327 in k5324 in k5321 in k5318 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k5309 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5311(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5218(t4,((C_word*)t0)[2],t3);}

/* k5299 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5301(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5218(t4,((C_word*)t0)[2],t3);}

/* k5283 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t4=((C_word*)((C_word*)t0)[3])[1];
f_5218(t4,((C_word*)t0)[2],t3);}

/* k5245 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5247(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5247,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5262,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* support.scm:413: caar */
t3=*((C_word*)lf[156]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k5260 in k5245 in k5242 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_i_assq(t1,lf[155]);
t3=C_i_cdr(t2);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* k5229 in k5226 in loop in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5231(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:430: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_5218(t3,((C_word*)t0)[2],t2);}

/* k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5058,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5061,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5099,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t4=C_eqp(((C_word*)((C_word*)t0)[4])[1],lf[153]);
t5=t3;
f_5099(t5,C_i_not(t4));}
else{
t4=t3;
f_5099(t4,C_SCHEME_FALSE);}}

/* k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5099(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5099,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5102,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[150],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[5])[1],lf[153]);
t4=t2;
f_5133(t4,C_i_not(t3));}
else{
t3=t2;
f_5133(t3,C_SCHEME_FALSE);}}}

/* k5131 in k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5133(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5133,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5136,a[2]=t2,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[151],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5167,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[3])[1])){
t3=C_eqp(((C_word*)((C_word*)t0)[2])[1],lf[153]);
t4=t2;
f_5167(t4,C_i_not(t3));}
else{
t3=t2;
f_5167(t3,C_SCHEME_FALSE);}}}

/* k5165 in k5131 in k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5167(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5167,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=*((C_word*)lf[11]+1);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5170,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
t4=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[152],t2);}
else{
t2=((C_word*)t0)[2];
f_5061(2,t2,C_SCHEME_UNDEFINED);}}

/* k5168 in k5165 in k5131 in k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5134 in k5131 in k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5136,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5100 in k5097 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5102,2,t0,t1);}
t2=((C_word*)((C_word*)t0)[4])[1];
t3=C_slot(t2,C_fix(1));
t4=((C_word*)((C_word*)t0)[4])[1];
t5=C_slot(t4,C_fix(2));
t6=C_a_i_cons(&a,2,t3,t5);
/* write */
t7=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[3],t6,((C_word*)t0)[2]);}

/* k5059 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5061(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5061,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5064,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5089,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[149],t3);}
else{
t3=t2;
f_5064(2,t3,C_SCHEME_UNDEFINED);}}

/* k5087 in k5059 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5089(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5062 in k5059 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5067,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t3=*((C_word*)lf[11]+1);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5076,a[2]=t3,a[3]=t2,a[4]=((C_word*)t0)[2],tmp=(C_word)a,a+=5,tmp);
/* display */
t5=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,lf[148],t3);}
else{
/* support.scm:439: newline */
t3=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,((C_word*)t0)[3]);}}

/* k5074 in k5062 in k5059 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5076(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_length(((C_word*)((C_word*)t0)[4])[1]);
/* write */
t3=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k5065 in k5062 in k5059 in k5056 in k5053 in a5044 in k5038 in ##compiler#display-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5067(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:439: newline */
t2=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4979,tmp=(C_word)a,a+=2,tmp);
/* support.scm:375: ##sys#hash-table-for-each */
t3=*((C_word*)lf[146]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t1,t2,*((C_word*)lf[140]+1));}

/* a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4979(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_4979,4,t0,t1,t2,t3);}
if(C_truep(t3)){
t4=*((C_word*)lf[11]+1);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4986,a[2]=t3,a[3]=t4,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* write */
t6=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t4);}
else{
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4986(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4986,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(32),((C_word*)t0)[3]);}

/* k4987 in k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4992,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5001,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_5001(t11,t7,((C_word*)t0)[2]);}

/* loop528 in k4987 in k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_5001(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_5001,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=*((C_word*)lf[145]+1);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_5030,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g544545 */
t6=t3;
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k5028 in loop528 in k4987 in k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_5030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5030,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop528541 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5001(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop528541 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_5001(t6,((C_word*)t0)[3],t5);}}

/* k4997 in k4987 in k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4990 in k4987 in k4984 in a4978 in ##compiler#display-line-number-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4992(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(10),((C_word*)t0)[2]);}

/* ##compiler#find-lambda-container in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4949(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4949,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4955,a[2]=t4,a[3]=t6,a[4]=t3,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_4955(t8,t1,t2);}

/* loop in ##compiler#find-lambda-container in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4955(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4955,NULL,3,t0,t1,t2);}
t3=C_eqp(t2,((C_word*)t0)[4]);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4965,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:371: get */
t5=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t4,((C_word*)t0)[2],t2,lf[143]);}}

/* k4963 in loop in ##compiler#find-lambda-container in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:372: loop */
t2=((C_word*)((C_word*)t0)[3])[1];
f_4955(t2,((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#get-line-2 in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4908(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4908,3,t0,t1,t2);}
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4915,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:363: ##sys#hash-table-ref */
t5=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t4,*((C_word*)lf[140]+1),t3);}

/* k4913 in ##compiler#get-line-2 in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4915(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4915,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4918,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=C_i_cdr(t1);
t4=t2;
f_4918(t4,C_i_assq(((C_word*)t0)[2],t3));}
else{
t3=t2;
f_4918(t3,C_SCHEME_FALSE);}}

/* k4916 in k4913 in ##compiler#get-line-2 in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4918(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4918,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4922,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* g507508 */
t3=t2;
f_4922(t3,((C_word*)t0)[3],t1);}
else{
/* support.scm:366: values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_FALSE);}}

/* g507 in k4916 in k4913 in ##compiler#get-line-2 in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4922(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4922,NULL,3,t0,t1,t2);}
t3=C_i_car(((C_word*)t0)[2]);
t4=C_i_cdr(t2);
/* support.scm:365: values */
C_values(4,0,t1,t3,t4);}

/* ##compiler#get-line in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4898(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4898,3,t0,t1,t2);}
t3=C_i_car(t2);
/* support.scm:359: get */
t4=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,*((C_word*)lf[140]+1),t3,t2);}

/* ##compiler#get-list in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4889(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4889,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4893,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:352: get */
t6=*((C_word*)lf[130]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t5,t2,t3,t4);}

/* k4891 in ##compiler#get-list in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* ##compiler#count! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4832(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,...){
C_word tmp;
C_word t5;
va_list v;
C_word *a,c2=c;
C_save_rest(t4,c2,5);
if(!C_demand(c*C_SIZEOF_PAIR+7)){
C_save_and_reclaim((void*)tr5r,(void*)f_4832r,5,t0,t1,t2,t3,t4);}
else{
a=C_alloc((c-5)*3);
t5=C_restore_rest(a,C_rest_count(0));
f_4832r(t0,t1,t2,t3,t4,t5);}}

static void C_ccall f_4832r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word *a=C_alloc(7);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4836,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm:343: ##sys#hash-table-ref */
t7=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k4834 in ##compiler#count! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4836(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4836,2,t0,t1);}
t2=C_i_pairp(((C_word*)t0)[6]);
t3=(C_truep(t2)?C_i_car(((C_word*)t0)[6]):C_fix(1));
if(C_truep(t1)){
t4=C_i_assq(((C_word*)t0)[5],t1);
if(C_truep(t4)){
t5=C_slot(t4,C_fix(1));
t6=C_a_i_plus(&a,2,t5,t3);
t7=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,C_i_setslot(t4,C_fix(1),t6));}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4866,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t6=C_slot(t1,C_fix(1));
/* support.scm:348: alist-cons */
t7=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t5,((C_word*)t0)[5],t3,t6);}}
else{
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[6]);
t5=C_a_i_list(&a,1,t4);
/* support.scm:349: ##sys#hash-table-set! */
t6=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t5);}}

/* k4864 in k4834 in ##compiler#count! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4866(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#collect! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4780(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4780,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4784,a[2]=t3,a[3]=t2,a[4]=t1,a[5]=t5,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm:335: ##sys#hash-table-ref */
t7=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k4782 in ##compiler#collect! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4784(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4784,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=C_slot(t2,C_fix(1));
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],t3);
t5=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_i_setslot(t2,C_fix(1),t4));}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4811,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t4=C_a_i_list(&a,1,((C_word*)t0)[5]);
t5=C_slot(t1,C_fix(1));
/* support.scm:339: alist-cons */
t6=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,t3,((C_word*)t0)[6],t4,t5);}}
else{
t2=C_a_i_list(&a,2,((C_word*)t0)[6],((C_word*)t0)[5]);
t3=C_a_i_list(&a,1,t2);
/* support.scm:340: ##sys#hash-table-set! */
t4=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t3);}}

/* k4809 in k4782 in ##compiler#collect! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#put! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4734(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4,C_word t5){
C_word tmp;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr6,(void*)f_4734,6,t0,t1,t2,t3,t4,t5);}
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4738,a[2]=t3,a[3]=t2,a[4]=t5,a[5]=t1,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
/* support.scm:327: ##sys#hash-table-ref */
t7=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t2,t3);}

/* k4736 in ##compiler#put! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4738(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4738,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[6],t1);
if(C_truep(t2)){
t3=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_setslot(t2,C_fix(1),((C_word*)t0)[4]));}
else{
if(C_truep(((C_word*)t0)[4])){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4760,a[2]=t1,a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
t4=C_slot(t1,C_fix(1));
/* support.scm:331: alist-cons */
t5=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t5+1)))(5,t5,t3,((C_word*)t0)[6],((C_word*)t0)[4],t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}
else{
if(C_truep(((C_word*)t0)[4])){
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],((C_word*)t0)[4]);
t3=C_a_i_list(&a,1,t2);
/* support.scm:332: ##sys#hash-table-set! */
t4=*((C_word*)lf[135]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],((C_word*)t0)[3],((C_word*)t0)[2],t3);}
else{
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}}

/* k4758 in k4736 in ##compiler#put! in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4760(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_setslot(((C_word*)t0)[2],C_fix(1),t1));}

/* ##compiler#get-all in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4716(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_4716r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_4716r(t0,t1,t2,t3,t4);}}

static void C_ccall f_4716r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word *a=C_alloc(4);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4720,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:321: ##sys#hash-table-ref */
t6=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k4718 in ##compiler#get-all in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4720(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4720,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4728,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* support.scm:323: filter-map */
t3=*((C_word*)lf[133]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_END_OF_LIST);}}

/* a4727 in k4718 in ##compiler#get-all in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4728(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4728,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_assq(t2,((C_word*)t0)[2]));}

/* ##compiler#get in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4698(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4698,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4702,a[2]=t1,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
/* support.scm:315: ##sys#hash-table-ref */
t6=*((C_word*)lf[131]+1);
((C_proc4)(void*)(*((C_word*)t6+1)))(4,t6,t5,t2,t3);}

/* k4700 in ##compiler#get in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4702(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_assq(((C_word*)t0)[3],t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,(C_truep(t2)?C_slot(t2,C_fix(1)):C_SCHEME_FALSE));}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4445,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4449,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)((C_word*)t0)[2])[1])){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4453,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4607,a[2]=t5,tmp=(C_word)a,a+=3,tmp));
t7=((C_word*)t5)[1];
f_4607(t7,t3,*((C_word*)lf[129]+1));}
else{
t3=C_set_block_item(((C_word*)t0)[2],0,C_SCHEME_FALSE);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* loop334 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4607(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4607,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4685,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4646,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_a_i_list(&a,1,lf[128]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4621,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* tweaks.scm:50: ##sys#put! */
t8=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t4,lf[121],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* tweaks.scm:50: ##sys#put! */
t10=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t5,t4,lf[121],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4619 in loop334 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[121],t1);}

/* k4644 in loop334 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4646(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4646,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[6],*((C_word*)lf[124]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4657,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:50: ##sys#put! */
t4=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],((C_word*)t0)[6],lf[125],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* tweaks.scm:50: ##sys#put! */
t6=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[5],((C_word*)t0)[6],lf[125],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4607(t3,((C_word*)t0)[2],t2);}}

/* k4655 in k4644 in loop334 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4657(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[125],t1);}

/* k4683 in loop334 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4685(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4607(t3,((C_word*)t0)[2],t2);}

/* k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4453(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4453,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4456,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4516,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4516(t6,t2,*((C_word*)lf[127]+1));}

/* loop378 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4516(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[19],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4516,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4594,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4555,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,a[6]=t4,tmp=(C_word)a,a+=7,tmp);
t6=C_a_i_list(&a,1,lf[126]);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4530,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t6))){
/* tweaks.scm:50: ##sys#put! */
t8=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t8+1)))(5,t8,t5,t4,lf[121],C_SCHEME_TRUE);}
else{
t8=C_i_cdr(t6);
if(C_truep(C_i_nullp(t8))){
t9=C_i_car(t6);
/* tweaks.scm:50: ##sys#put! */
t10=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t5,t4,lf[121],t9);}
else{
/* ##sys#error */
t9=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t7,lf[0],t6);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4528 in loop378 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4530(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[121],t1);}

/* k4553 in loop378 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4555(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4555,2,t0,t1);}
if(C_truep(C_i_memq(((C_word*)t0)[6],*((C_word*)lf[124]+1)))){
t2=C_a_i_list(&a,1,C_SCHEME_TRUE);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4566,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t2))){
/* tweaks.scm:50: ##sys#put! */
t4=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,((C_word*)t0)[5],((C_word*)t0)[6],lf[125],C_SCHEME_TRUE);}
else{
t4=C_i_cdr(t2);
if(C_truep(C_i_nullp(t4))){
t5=C_i_car(t2);
/* tweaks.scm:50: ##sys#put! */
t6=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t6+1)))(5,t6,((C_word*)t0)[5],((C_word*)t0)[6],lf[125],t5);}
else{
/* ##sys#error */
t5=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[0],t2);}}}
else{
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4516(t3,((C_word*)t0)[2],t2);}}

/* k4564 in k4553 in loop378 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[125],t1);}

/* k4592 in loop378 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4594(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4516(t3,((C_word*)t0)[2],t2);}

/* k4454 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4456,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4461,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_4461(t5,((C_word*)t0)[2],*((C_word*)lf[123]+1));}

/* loop421 in k4454 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_fcall f_4461(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[12],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4461,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4503,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_a_i_list(&a,1,lf[119]);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4475,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_nullp(t5))){
/* tweaks.scm:50: ##sys#put! */
t7=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,t3,t4,lf[121],C_SCHEME_TRUE);}
else{
t7=C_i_cdr(t5);
if(C_truep(C_i_nullp(t7))){
t8=C_i_car(t5);
/* tweaks.scm:50: ##sys#put! */
t9=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,t3,t4,lf[121],t8);}
else{
/* ##sys#error */
t8=*((C_word*)lf[122]+1);
((C_proc4)(void*)(*((C_word*)t8+1)))(4,t8,t6,lf[0],t5);}}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4473 in loop421 in k4454 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4475(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* tweaks.scm:50: ##sys#put! */
t2=*((C_word*)lf[120]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],((C_word*)t0)[2],lf[121],t1);}

/* k4501 in loop421 in k4454 in k4451 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4503(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_4461(t3,((C_word*)t0)[2],t2);}

/* k4447 in ##compiler#initialize-analysis-database in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4449(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_FALSE);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* ##compiler#expand-profile-lambda in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4304(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_4304,5,t0,t1,t2,t3,t4);}
t5=*((C_word*)lf[109]+1);
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4308,a[2]=t2,a[3]=t1,a[4]=t3,a[5]=t4,a[6]=t5,tmp=(C_word)a,a+=7,tmp);
/* support.scm:275: gensym */
t7=*((C_word*)lf[90]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k4306 in ##compiler#expand-profile-lambda in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4308(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4308,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4312,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
/* support.scm:276: alist-cons */
t3=*((C_word*)lf[117]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[6],((C_word*)t0)[2],*((C_word*)lf[110]+1));}

/* k4310 in k4306 in ##compiler#expand-profile-lambda in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word ab[100],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4312,2,t0,t1);}
t2=C_mutate((C_word*)lf[110]+1 /* (set! ##compiler#profile-lambda-list ...) */,t1);
t3=C_a_i_plus(&a,2,((C_word*)t0)[6],C_fix(1));
t4=C_mutate((C_word*)lf[109]+1 /* (set! ##compiler#profile-lambda-index ...) */,t3);
t5=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,lf[79],t5);
t7=C_a_i_cons(&a,2,*((C_word*)lf[111]+1),C_SCHEME_END_OF_LIST);
t8=C_a_i_cons(&a,2,t6,t7);
t9=C_a_i_cons(&a,2,lf[112],t8);
t10=C_a_i_cons(&a,2,t9,C_SCHEME_END_OF_LIST);
t11=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t10);
t12=C_a_i_cons(&a,2,lf[113],t11);
t13=C_a_i_cons(&a,2,((C_word*)t0)[5],C_SCHEME_END_OF_LIST);
t14=C_a_i_cons(&a,2,((C_word*)t0)[4],t13);
t15=C_a_i_cons(&a,2,lf[113],t14);
t16=C_a_i_cons(&a,2,((C_word*)t0)[3],C_SCHEME_END_OF_LIST);
t17=C_a_i_cons(&a,2,t15,t16);
t18=C_a_i_cons(&a,2,lf[114],t17);
t19=C_a_i_cons(&a,2,t18,C_SCHEME_END_OF_LIST);
t20=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t19);
t21=C_a_i_cons(&a,2,lf[113],t20);
t22=C_a_i_cons(&a,2,((C_word*)t0)[6],C_SCHEME_END_OF_LIST);
t23=C_a_i_cons(&a,2,lf[79],t22);
t24=C_a_i_cons(&a,2,*((C_word*)lf[111]+1),C_SCHEME_END_OF_LIST);
t25=C_a_i_cons(&a,2,t23,t24);
t26=C_a_i_cons(&a,2,lf[115],t25);
t27=C_a_i_cons(&a,2,t26,C_SCHEME_END_OF_LIST);
t28=C_a_i_cons(&a,2,C_SCHEME_END_OF_LIST,t27);
t29=C_a_i_cons(&a,2,lf[113],t28);
t30=C_a_i_cons(&a,2,t29,C_SCHEME_END_OF_LIST);
t31=C_a_i_cons(&a,2,t21,t30);
t32=C_a_i_cons(&a,2,t12,t31);
t33=C_a_i_cons(&a,2,lf[116],t32);
t34=C_a_i_cons(&a,2,t33,C_SCHEME_END_OF_LIST);
t35=C_a_i_cons(&a,2,((C_word*)t0)[3],t34);
t36=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t36+1)))(2,t36,C_a_i_cons(&a,2,lf[113],t35));}

/* ##compiler#llist-length in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4301(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4301,3,t0,t1,t2);}
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_u_i_length(t2));}

/* ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4194(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4194,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4198,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4203,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* call-with-current-continuation */
t5=*((C_word*)lf[104]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}

/* a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4203(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4203,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4209,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4234,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
t5=*((C_word*)lf[103]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t3,t4);}

/* a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4240,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a4287 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4288(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_4288r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_4288r(t0,t1,t2);}}

static void C_ccall f_4288r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4294,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k305309 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4293 in a4287 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4294,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4272,tmp=(C_word)a,a+=2,tmp);
/* support.scm:258: with-input-from-string */
t4=*((C_word*)lf[102]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,((C_word*)t0)[2],t3);}

/* a4271 in a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4272,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4278,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4286,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:260: read */
t4=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}

/* k4284 in a4271 in a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4286(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:260: unfold */
t2=*((C_word*)lf[99]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[3],*((C_word*)lf[100]+1),*((C_word*)lf[101]+1),((C_word*)t0)[2],t1);}

/* a4277 in a4271 in a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4278(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4278,3,t0,t1,t2);}
/* support.scm:260: read */
t3=*((C_word*)lf[98]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t1);}

/* k4242 in a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4244,2,t0,t1);}
if(C_truep(C_i_nullp(t1))){
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,lf[95]);}
else{
t2=C_i_cdr(t1);
if(C_truep(C_i_nullp(t2))){
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_i_car(t1));}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4266,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#append */
t4=*((C_word*)lf[97]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,t1,C_SCHEME_END_OF_LIST);}}}

/* k4264 in k4242 in a4239 in a4233 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4266,2,t0,t1);}
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,lf[96],t1));}

/* a4208 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4209(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4209,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4215,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* k305309 */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t3);}

/* a4214 in a4208 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4215(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4215,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4223,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4226,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:255: exn? */
t4=((C_word*)t0)[2];
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[3]);}

/* k4224 in a4214 in a4208 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4226(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* support.scm:256: exn-msg */
t2=((C_word*)t0)[4];
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}
else{
/* support.scm:257: ->string */
t2=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}}

/* k4221 in a4214 in a4208 in a4202 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:253: quit */
t2=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[94],((C_word*)t0)[2],t1);}

/* k4196 in ##compiler#string->expr in k4191 in k4188 in k3155 in k3152 */
static void C_ccall f_4198(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g307308 */
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_ccall f_4093(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4093,3,t0,t1,t2);}
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4099,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_4099(t6,t1,t2);}

/* loop in ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_fcall f_4099(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4099,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[87]);}
else{
t3=C_i_cdr(t2);
if(C_truep(C_i_nullp(t3))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_i_car(t2));}
else{
t4=C_i_car(t2);
t5=C_i_equalp(t4,lf[88]);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4127,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t5)){
t7=t6;
f_4127(t7,t5);}
else{
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4176,a[2]=t4,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:242: constant? */
t8=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}}}}

/* k4174 in loop in ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_ccall f_4176(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
f_4127(t3,t2);}
else{
t2=((C_word*)t0)[3];
f_4127(t2,C_i_equalp(((C_word*)t0)[2],lf[92]));}}

/* k4125 in loop in ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_fcall f_4127(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4127,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:244: loop */
t3=((C_word*)((C_word*)t0)[3])[1];
f_4099(t3,((C_word*)t0)[2],t2);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4165,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* support.scm:245: gensym */
t3=*((C_word*)lf[90]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,lf[91]);}}

/* k4163 in k4125 in loop in ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_ccall f_4165(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4165,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,t1,t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4153,a[2]=((C_word*)t0)[3],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[4]);
/* support.scm:246: loop */
t8=((C_word*)((C_word*)t0)[2])[1];
f_4099(t8,t6,t7);}

/* k4151 in k4163 in k4125 in loop in ##compiler#canonicalize-begin-body in k3155 in k3152 */
static void C_ccall f_4153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4153,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,((C_word*)t0)[3],t2);
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,lf[89],t3));}

/* ##compiler#basic-literal? in k3155 in k3152 */
static void C_ccall f_4033(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4033,3,t0,t1,t2);}
t3=C_i_nullp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_i_symbolp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4049,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:227: constant? */
t6=*((C_word*)lf[78]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t2);}}}

/* k4047 in ##compiler#basic-literal? in k3155 in k3152 */
static void C_ccall f_4049(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4049,2,t0,t1);}
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4055,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_vectorp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4091,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:228: vector->list */
t4=*((C_word*)lf[85]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,((C_word*)t0)[2]);}
else{
t3=t2;
f_4055(2,t3,C_SCHEME_FALSE);}}}

/* k4089 in k4047 in ##compiler#basic-literal? in k3155 in k3152 */
static void C_ccall f_4091(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:228: every */
t2=*((C_word*)lf[84]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[2],*((C_word*)lf[83]+1),t1);}

/* k4053 in k4047 in ##compiler#basic-literal? in k3155 in k3152 */
static void C_ccall f_4055(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4055,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* support.scm:230: basic-literal? */
t4=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t2,t3);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}}

/* k4068 in k4053 in k4047 in ##compiler#basic-literal? in k3155 in k3152 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
t2=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:231: basic-literal? */
t3=*((C_word*)lf[83]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* ##compiler#immediate? in k3155 in k3152 */
static void C_ccall f_3987(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3987,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3991,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_fixnump(t2))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4031,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:217: big-fixnum? */
t5=*((C_word*)lf[82]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}
else{
t4=t3;
f_3991(t4,C_SCHEME_FALSE);}}

/* k4029 in ##compiler#immediate? in k3155 in k3152 */
static void C_ccall f_4031(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3991(t2,C_i_not(t1));}

/* k3989 in ##compiler#immediate? in k3155 in k3152 */
static void C_fcall f_3991(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(C_truep(t1)){
t2=t1;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_eqp(C_SCHEME_UNDEFINED,((C_word*)t0)[2]);
if(C_truep(t2)){
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t3=C_i_nullp(((C_word*)t0)[2]);
if(C_truep(t3)){
t4=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_eofp(((C_word*)t0)[2]);
if(C_truep(t4)){
t5=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_charp(((C_word*)t0)[2]);
t6=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,(C_truep(t5)?t5:C_booleanp(((C_word*)t0)[2])));}}}}}

/* ##compiler#collapsable-literal? in k3155 in k3152 */
static void C_ccall f_3957(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3957,3,t0,t1,t2);}
t3=C_booleanp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_eofp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_i_numberp(t2);
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_i_symbolp(t2)));}}}}

/* ##compiler#constant? in k3155 in k3152 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3911,3,t0,t1,t2);}
t3=C_i_numberp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_charp(t2);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
t5=C_i_stringp(t2);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t6=C_booleanp(t2);
if(C_truep(t6)){
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t7=C_eofp(t2);
if(C_truep(t7)){
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,t7);}
else{
if(C_truep(C_i_pairp(t2))){
t8=C_i_car(t2);
t9=t1;
((C_proc2)(void*)(*((C_word*)t9+1)))(2,t9,C_eqp(lf[79],t8));}
else{
t8=t1;
((C_proc2)(void*)(*((C_word*)t8+1)))(2,t8,C_SCHEME_FALSE);}}}}}}}

/* ##compiler#sort-symbols in k3155 in k3152 */
static void C_ccall f_3891(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3891,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3897,tmp=(C_word)a,a+=2,tmp);
/* support.scm:196: sort */
t4=*((C_word*)lf[77]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t1,t2,t3);}

/* a3896 in ##compiler#sort-symbols in k3155 in k3152 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3897,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3905,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:196: symbol->string */
t5=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3903 in a3896 in ##compiler#sort-symbols in k3155 in k3152 */
static void C_ccall f_3905(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3905,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3909,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* support.scm:196: symbol->string */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3907 in k3903 in a3896 in ##compiler#sort-symbols in k3155 in k3152 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:196: string<? */
t2=*((C_word*)lf[76]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* ##compiler#follow-without-loop in k3155 in k3152 */
static void C_ccall f_3860(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3860,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3866,a[2]=t3,a[3]=t6,a[4]=t4,tmp=(C_word)a,a+=5,tmp));
t8=((C_word*)t6)[1];
f_3866(t8,t1,t2,C_SCHEME_END_OF_LIST);}

/* loop in ##compiler#follow-without-loop in k3155 in k3152 */
static void C_fcall f_3866(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3866,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_member(t2,t3))){
/* support.scm:192: abort */
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3881,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:193: proc */
t5=((C_word*)t0)[2];
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t1,t2,t4);}}

/* a3880 in loop in ##compiler#follow-without-loop in k3155 in k3152 */
static void C_ccall f_3881(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3881,3,t0,t1,t2);}
t3=C_a_i_cons(&a,2,((C_word*)t0)[4],((C_word*)t0)[3]);
/* support.scm:193: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3866(t4,t1,t2,t3);}

/* ##compiler#fold-inner in k3155 in k3152 */
static void C_ccall f_3797(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3797,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
if(C_truep(C_i_nullp(t4))){
t5=t3;
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t5);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3811,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:182: reverse */
t6=*((C_word*)lf[73]+1);
((C_proc3)(void*)(*((C_word*)t6+1)))(3,t6,t5,t3);}}

/* k3809 in ##compiler#fold-inner in k3155 in k3152 */
static void C_ccall f_3811(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3811,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3813,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3813(t5,((C_word*)t0)[2],t1);}

/* fold in k3809 in ##compiler#fold-inner in k3155 in k3152 */
static void C_fcall f_3813(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(6);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3813,NULL,3,t0,t1,t2);}
t3=C_i_cddr(t2);
if(C_truep(C_i_nullp(t3))){
t4=C_i_cadr(t2);
t5=C_i_car(t2);
t6=C_a_i_list(&a,2,t4,t5);
C_apply(4,0,t1,((C_word*)t0)[3],t6);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3842,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_i_cdr(t2);
/* support.scm:187: fold */
t10=t4;
t11=t5;
t1=t10;
t2=t11;
goto loop;}}

/* k3840 in fold in k3809 in ##compiler#fold-inner in k3155 in k3152 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_a_i_list(&a,2,t1,t2);
C_apply(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t3);}

/* ##compiler#close-checked-input-file in k3155 in k3152 */
static void C_ccall f_3785(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3785,4,t0,t1,t2,t3);}
if(C_truep(C_i_string_equal_p(t3,lf[70]))){
t4=C_SCHEME_UNDEFINED;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
/* support.scm:177: close-input-port */
t4=*((C_word*)lf[71]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t1,t2);}}

/* ##compiler#check-and-open-input-file in k3155 in k3152 */
static void C_ccall f_3738(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3738r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3738r(t0,t1,t2,t3);}}

static void C_ccall f_3738r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
if(C_truep(C_i_string_equal_p(t2,lf[63]))){
/* support.scm:171: current-input-port */
t4=*((C_word*)lf[64]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t1);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3754,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:172: file-exists? */
t5=*((C_word*)lf[68]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}}

/* k3752 in ##compiler#check-and-open-input-file in k3155 in k3152 */
static void C_ccall f_3754(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3754,2,t0,t1);}
if(C_truep(t1)){
/* support.scm:172: open-input-file */
t2=*((C_word*)lf[65]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=C_i_nullp(((C_word*)t0)[2]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3766,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t2)){
t4=t3;
f_3766(t4,t2);}
else{
t4=C_i_car(((C_word*)t0)[2]);
t5=t3;
f_3766(t5,C_i_not(t4));}}}

/* k3764 in k3752 in ##compiler#check-and-open-input-file in k3155 in k3152 */
static void C_fcall f_3766(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(t1)){
/* support.scm:173: quit */
t2=*((C_word*)lf[19]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[4],lf[66],((C_word*)t0)[3]);}
else{
t2=C_i_car(((C_word*)t0)[2]);
/* support.scm:174: quit */
t3=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,((C_word*)t0)[4],lf[67],t2,((C_word*)t0)[3]);}}

/* ##compiler#words->bytes in k3155 in k3152 */
static void C_ccall f_3731(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3731,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub189(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#words in k3155 in k3152 */
static void C_ccall f_3724(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3724,3,t0,t1,t2);}
t3=C_i_foreign_fixnum_argumentp(t2);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,stub185(C_SCHEME_UNDEFINED,t3));}

/* ##compiler#valid-c-identifier? in k3155 in k3152 */
static void C_ccall f_3668(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3668,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3672,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3722,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* support.scm:152: ->string */
t5=*((C_word*)lf[59]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3720 in ##compiler#valid-c-identifier? in k3155 in k3152 */
static void C_ccall f_3722(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3670 in ##compiler#valid-c-identifier? in k3155 in k3152 */
static void C_ccall f_3672(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[2],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3672,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=C_i_car(t1);
t3=C_u_i_char_alphabeticp(t2);
t4=(C_truep(t3)?t3:C_eqp(C_make_character(95),t2));
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3695,tmp=(C_word)a,a+=2,tmp);
t6=C_i_cdr(t1);
/* support.scm:156: any */
t7=*((C_word*)lf[58]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,((C_word*)t0)[2],t5,t6);}
else{
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* a3694 in k3670 in ##compiler#valid-c-identifier? in k3155 in k3152 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3695,3,t0,t1,t2);}
t3=C_u_i_char_alphabeticp(t2);
if(C_truep(t3)){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
t4=C_u_i_char_numericp(t2);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,(C_truep(t4)?t4:C_eqp(C_make_character(95),t2)));}}

/* ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3574(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3574,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3586,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3590,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* string->list */
t5=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t4,t2);}

/* k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3590(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3590,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3592(t5,((C_word*)t0)[2],t1);}

/* loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_fcall f_3592(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3592,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,lf[50]);}
else{
t3=C_i_car(t2);
t4=C_fix(C_character_code(t3));
t5=C_i_lessp(t4,C_fix(32));
t6=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3614,a[2]=t3,a[3]=t4,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(t5)){
t7=t6;
f_3614(t7,t5);}
else{
t7=C_i_greater_or_equalp(t4,C_fix(127));
t8=t6;
f_3614(t8,(C_truep(t7)?t7:C_i_memq(t3,lf[56])));}}}

/* k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_fcall f_3614(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3614,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3621,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_lessp(((C_word*)t0)[3],C_fix(8)))){
t3=t2;
f_3621(t3,lf[54]);}
else{
t3=C_i_lessp(((C_word*)t0)[3],C_fix(64));
t4=t2;
f_3621(t4,(C_truep(t3)?lf[55]:C_SCHEME_END_OF_LIST));}}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[5]);
/* support.scm:149: loop */
t4=((C_word*)((C_word*)t0)[4])[1];
f_3592(t4,t2,t3);}}

/* k3651 in k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3653,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* k3619 in k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_fcall f_3621(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3621,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3637,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* support.scm:147: number->string */
C_number_to_string(4,0,t3,((C_word*)t0)[2],C_fix(8));}

/* k3635 in k3619 in k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=*((C_word*)lf[53]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k3623 in k3619 in k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3629,a[2]=t1,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:148: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3592(t4,t2,t3);}

/* k3627 in k3623 in k3619 in k3612 in loop in k3588 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3629(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:143: append */
t2=*((C_word*)lf[51]+1);
((C_proc6)(void*)(*((C_word*)t2+1)))(6,t2,((C_word*)t0)[4],lf[52],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3584 in ##compiler#c-ify-string in k3155 in k3152 */
static void C_ccall f_3586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3586,2,t0,t1);}
t2=C_a_i_cons(&a,2,C_make_character(34),t1);
/* list->string */
t3=*((C_word*)lf[49]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,((C_word*)t0)[2],t2);}

/* ##compiler#build-lambda-list in k3155 in k3152 */
static void C_ccall f_3530(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3530,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_UNDEFINED;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_set_block_item(t6,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3536,a[2]=t6,a[3]=t4,tmp=(C_word)a,a+=4,tmp));
t8=((C_word*)t6)[1];
f_3536(t8,t1,t2,t3);}

/* loop in ##compiler#build-lambda-list in k3155 in k3152 */
static void C_fcall f_3536(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word *a;
loop:
a=C_alloc(8);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3536,NULL,4,t0,t1,t2,t3);}
t4=C_i_zerop(t3);
t5=(C_truep(t4)?t4:C_i_nullp(t2));
if(C_truep(t5)){
t6=((C_word*)t0)[3];
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,(C_truep(t6)?t6:C_SCHEME_END_OF_LIST));}
else{
t6=C_i_car(t2);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3560,a[2]=t6,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t8=C_i_cdr(t2);
t9=C_a_i_minus(&a,2,t3,C_fix(1));
/* support.scm:129: loop */
t12=t7;
t13=t8;
t14=t9;
t1=t12;
t2=t13;
t3=t14;
goto loop;}}

/* k3558 in loop in ##compiler#build-lambda-list in k3155 in k3152 */
static void C_ccall f_3560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3560,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#symbolify in k3155 in k3152 */
static void C_ccall f_3499(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3499,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_stringp(t2))){
/* support.scm:123: string->symbol */
t3=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3522,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t4=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* k3520 in ##compiler#symbolify in k3155 in k3152 */
static void C_ccall f_3522(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3522,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3525,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3523 in k3520 in ##compiler#symbolify in k3155 in k3152 */
static void C_ccall f_3525(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3525,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* get-output-string */
t3=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3526 in k3523 in k3520 in ##compiler#symbolify in k3155 in k3152 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:124: string->symbol */
t2=*((C_word*)lf[44]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* ##compiler#stringify in k3155 in k3152 */
static void C_ccall f_3472(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3472,3,t0,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=t2;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:118: symbol->string */
t3=*((C_word*)lf[40]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3491,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
t4=*((C_word*)lf[42]+1);
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}}

/* k3489 in ##compiler#stringify in k3155 in k3152 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3494,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
t3=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,((C_word*)t0)[2],t1);}

/* k3492 in k3489 in ##compiler#stringify in k3155 in k3152 */
static void C_ccall f_3494(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
t2=*((C_word*)lf[41]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* ##compiler#posq in k3155 in k3152 */
static void C_ccall f_3436(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3436,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3442,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3442(t7,t1,t3,C_fix(0));}

/* loop in ##compiler#posq in k3155 in k3152 */
static void C_fcall f_3442(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word *a;
loop:
a=C_alloc(4);
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3442,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_FALSE);}
else{
t4=C_i_car(t2);
t5=C_eqp(((C_word*)t0)[3],t4);
if(C_truep(t5)){
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,t3);}
else{
t6=C_i_cdr(t2);
t7=C_a_i_plus(&a,2,t3,C_fix(1));
/* support.scm:114: loop */
t9=t1;
t10=t6;
t11=t7;
t1=t9;
t2=t10;
t3=t11;
goto loop;}}}

/* ##compiler#check-signature in k3155 in k3152 */
static void C_ccall f_3368(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[10],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3368,5,t0,t1,t2,t3,t4);}
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3371,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=C_SCHEME_UNDEFINED;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_set_block_item(t7,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3392,a[2]=t7,a[3]=t5,tmp=(C_word)a,a+=4,tmp));
t9=((C_word*)t7)[1];
f_3392(t9,t1,t3,t4);}

/* loop in ##compiler#check-signature in k3155 in k3152 */
static void C_fcall f_3392(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word *a;
loop:
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3392,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t3))){
if(C_truep(C_i_nullp(t2))){
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}
else{
/* support.scm:102: err */
t4=((C_word*)t0)[3];
f_3371(t4,t1);}}
else{
t4=C_i_symbolp(t3);
if(C_truep(t4)){
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}
else{
if(C_truep(C_i_nullp(t2))){
/* support.scm:104: err */
t5=((C_word*)t0)[3];
f_3371(t5,t1);}
else{
t5=C_i_cdr(t2);
t6=C_i_cdr(t3);
/* support.scm:105: loop */
t8=t1;
t9=t5;
t10=t6;
t1=t8;
t2=t9;
t3=t10;
goto loop;}}}}

/* err in ##compiler#check-signature in k3155 in k3152 */
static void C_fcall f_3371(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3371,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3379,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* support.scm:99: real-name */
t3=*((C_word*)lf[37]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3377 in err in ##compiler#check-signature in k3155 in k3152 */
static void C_ccall f_3379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3379,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3383,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[2]);
/* support.scm:100: map-llist */
t4=*((C_word*)lf[34]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,*((C_word*)lf[37]+1),t3);}

/* k3381 in k3377 in err in ##compiler#check-signature in k3155 in k3152 */
static void C_ccall f_3383(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:98: quit */
t2=*((C_word*)lf[19]+1);
((C_proc5)(void*)(*((C_word*)t2+1)))(5,t2,((C_word*)t0)[3],lf[36],((C_word*)t0)[2],t1);}

/* map-llist in k3155 in k3152 */
static void C_ccall f_3325(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3325,4,t0,t1,t2,t3);}
t4=C_SCHEME_UNDEFINED;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_set_block_item(t5,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3331,a[2]=t5,a[3]=t2,tmp=(C_word)a,a+=4,tmp));
t7=((C_word*)t5)[1];
f_3331(t7,t1,t3);}

/* loop in map-llist in k3155 in k3152 */
static void C_fcall f_3331(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3331,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,C_SCHEME_END_OF_LIST);}
else{
if(C_truep(C_i_symbolp(t2))){
/* support.scm:93: proc */
t3=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,t2);}
else{
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3354,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(t2);
/* support.scm:94: proc */
t5=((C_word*)t0)[3];
((C_proc3)(void*)(*((C_word*)t5+1)))(3,t5,t3,t4);}}}

/* k3352 in loop in map-llist in k3155 in k3152 */
static void C_ccall f_3354(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3354,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3358,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cdr(((C_word*)t0)[3]);
/* support.scm:94: loop */
t4=((C_word*)((C_word*)t0)[2])[1];
f_3331(t4,t2,t3);}

/* k3356 in k3352 in loop in map-llist in k3155 in k3152 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_cons(&a,2,((C_word*)t0)[2],t1));}

/* ##compiler#emit-syntax-trace-info in k3155 in k3152 */
static void C_ccall f_3322(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3322,4,t0,t1,t2,t3);}
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_emit_syntax_trace_info(t2,t3,*((C_word*)lf[26]+1)));}

/* ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3277(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+9)){
C_save_and_reclaim((void*)tr3r,(void*)f_3277r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3277r(t0,t1,t2,t3);}}

static void C_ccall f_3277r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(9);
t4=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3281,a[2]=t4,a[3]=t5,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:72: current-error-port */
t7=*((C_word*)lf[23]+1);
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}

/* k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3281(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[6],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3281,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3284,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_symbolp(((C_word*)((C_word*)t0)[2])[1]))){
t3=((C_word*)((C_word*)t0)[2])[1];
t4=C_i_car(((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=C_i_cdr(((C_word*)((C_word*)t0)[3])[1]);
t7=C_mutate(((C_word *)((C_word*)t0)[3])+1,t6);
t8=t2;
f_3284(t8,t3);}
else{
t3=t2;
f_3284(t3,C_SCHEME_FALSE);}}

/* k3282 in k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_fcall f_3284(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3284,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3287,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
/* support.scm:79: fprintf */
t3=*((C_word*)lf[21]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[4],lf[30],t1,((C_word*)((C_word*)t0)[2])[1]);}
else{
/* support.scm:80: fprintf */
t3=*((C_word*)lf[21]+1);
((C_proc5)(void*)(*((C_word*)t3+1)))(5,t3,t2,((C_word*)t0)[4],lf[31],((C_word*)((C_word*)t0)[2])[1]);}}

/* k3285 in k3282 in k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3287(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3287,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3298,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* for-each */
t4=*((C_word*)lf[29]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)((C_word*)t0)[2])[1]);}

/* a3297 in k3285 in k3282 in k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3298(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3298,3,t0,t1,t2);}
t3=*((C_word*)lf[21]+1);
/* g7677 */
t4=t3;
((C_proc5)(void*)(*((C_word*)t4+1)))(5,t4,t1,((C_word*)t0)[2],lf[28],t2);}

/* k3288 in k3285 in k3282 in k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3293,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:82: print-call-chain */
t3=*((C_word*)lf[25]+1);
((C_proc6)(void*)(*((C_word*)t3+1)))(6,t3,t2,((C_word*)t0)[2],C_fix(0),*((C_word*)lf[26]+1),lf[27]);}

/* k3291 in k3288 in k3285 in k3282 in k3279 in ##sys#syntax-error-hook in k3155 in k3152 */
static void C_ccall f_3293(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:83: exit */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(70));}

/* quit in k3155 in k3152 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1,C_word t2,...){
C_word tmp;
C_word t3;
va_list v;
C_word *a,c2=c;
C_save_rest(t2,c2,3);
if(!C_demand(c*C_SIZEOF_PAIR+5)){
C_save_and_reclaim((void*)tr3r,(void*)f_3258r,3,t0,t1,t2);}
else{
a=C_alloc((c-3)*3);
t3=C_restore_rest(a,C_rest_count(0));
f_3258r(t0,t1,t2,t3);}}

static void C_ccall f_3258r(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word *a=C_alloc(5);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3262,a[2]=t2,a[3]=t3,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* support.scm:65: current-error-port */
t5=*((C_word*)lf[23]+1);
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* k3260 in quit in k3155 in k3152 */
static void C_ccall f_3262(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3262,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3265,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3275,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
/* support.scm:66: string-append */
t4=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t3,lf[22],((C_word*)t0)[2]);}

/* k3273 in k3260 in quit in k3155 in k3152 */
static void C_ccall f_3275(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_apply(6,0,((C_word*)t0)[4],*((C_word*)lf[21]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3263 in k3260 in quit in k3155 in k3152 */
static void C_ccall f_3265(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3265,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3268,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* support.scm:67: newline */
t3=*((C_word*)lf[13]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t2,((C_word*)t0)[2]);}

/* k3266 in k3263 in k3260 in quit in k3155 in k3152 */
static void C_ccall f_3268(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* support.scm:68: exit */
t2=*((C_word*)lf[20]+1);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],C_fix(1));}

/* ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3193(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,...){
C_word tmp;
C_word t4;
va_list v;
C_word *a,c2=c;
C_save_rest(t3,c2,4);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr4r,(void*)f_3193r,4,t0,t1,t2,t3);}
else{
a=C_alloc((c-4)*3);
t4=C_restore_rest(a,C_rest_count(0));
f_3193r(t0,t1,t2,t3,t4);}}

static void C_ccall f_3193r(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word *a=C_alloc(4);
if(C_truep(C_i_memq(t2,*((C_word*)lf[3]+1)))){
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3203,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* display */
t7=*((C_word*)lf[17]+1);
((C_proc4)(void*)(*((C_word*)t7+1)))(4,t7,t6,t3,t5);}
else{
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_SCHEME_FALSE);}}

/* k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3203,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3206,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3218,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* support.scm:58: display */
t4=*((C_word*)lf[17]+1);
((C_proc3)(void*)(*((C_word*)t4+1)))(3,t4,t3,lf[18]);}
else{
t3=t2;
f_3206(2,t3,C_SCHEME_UNDEFINED);}}

/* k3216 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3218(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3218,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3223,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3223(t5,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* loop31 in k3216 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_fcall f_3223(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[13],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3223,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3245,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=*((C_word*)lf[11]+1);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3242,a[2]=t5,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
/* support.scm:59: force */
t8=*((C_word*)lf[16]+1);
((C_proc3)(void*)(*((C_word*)t8+1)))(3,t8,t7,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3240 in loop31 in k3216 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write */
t2=*((C_word*)lf[15]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3233 in loop31 in k3216 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* write-char/port */
t2=*((C_word*)lf[14]+1);
((C_proc4)(void*)(*((C_word*)t2+1)))(4,t2,((C_word*)t0)[3],C_make_character(32),((C_word*)t0)[2]);}

/* k3243 in loop31 in k3216 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3245(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3223(t3,((C_word*)t0)[2],t2);}

/* k3204 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3206(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3206,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3209,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:60: newline */
t3=*((C_word*)lf[13]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3207 in k3204 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3209(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3209,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3212,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* support.scm:61: flush-output */
t3=*((C_word*)lf[12]+1);
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3210 in k3207 in k3204 in k3201 in ##compiler#debugging in k3155 in k3152 */
static void C_ccall f_3212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_TRUE);}

/* ##compiler#bomb in k3155 in k3152 */
static void C_ccall f_3166(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
if(!C_demand(c*C_SIZEOF_PAIR+4)){
C_save_and_reclaim((void*)tr2r,(void*)f_3166r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3166r(t0,t1,t2);}}

static void C_ccall f_3166r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word *a=C_alloc(4);
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3180,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* support.scm:49: string-append */
t5=*((C_word*)lf[7]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,lf[8],t4);}
else{
/* support.scm:50: error */
t3=*((C_word*)lf[6]+1);
((C_proc3)(void*)(*((C_word*)t3+1)))(3,t3,t1,lf[9]);}}

/* k3178 in ##compiler#bomb in k3155 in k3152 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
C_apply(5,0,((C_word*)t0)[2],*((C_word*)lf[6]+1),t1,t2);}

/* ##compiler#compiler-cleanup-hook in k3155 in k3152 */
static void C_ccall f_3161(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3161,2,t0,t1);}
t2=t1;
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[673] = {
{"toplevel:support_scm",(void*)C_support_toplevel},
{"f_3154:support_scm",(void*)f_3154},
{"f_3157:support_scm",(void*)f_3157},
{"f_4190:support_scm",(void*)f_4190},
{"f_4193:support_scm",(void*)f_4193},
{"f_12574:support_scm",(void*)f_12574},
{"f_12578:support_scm",(void*)f_12578},
{"f_12663:support_scm",(void*)f_12663},
{"f_12584:support_scm",(void*)f_12584},
{"f_12650:support_scm",(void*)f_12650},
{"f_12653:support_scm",(void*)f_12653},
{"f_12656:support_scm",(void*)f_12656},
{"f_12590:support_scm",(void*)f_12590},
{"f_12597:support_scm",(void*)f_12597},
{"f_12599:support_scm",(void*)f_12599},
{"f_12622:support_scm",(void*)f_12622},
{"f_12618:support_scm",(void*)f_12618},
{"f_12636:support_scm",(void*)f_12636},
{"f_12563:support_scm",(void*)f_12563},
{"f_12552:support_scm",(void*)f_12552},
{"f_12546:support_scm",(void*)f_12546},
{"f_12518:support_scm",(void*)f_12518},
{"f_12522:support_scm",(void*)f_12522},
{"f_12497:support_scm",(void*)f_12497},
{"f_12501:support_scm",(void*)f_12501},
{"f_12464:support_scm",(void*)f_12464},
{"f_12470:support_scm",(void*)f_12470},
{"f_12431:support_scm",(void*)f_12431},
{"f_12437:support_scm",(void*)f_12437},
{"f_12407:support_scm",(void*)f_12407},
{"f_12338:support_scm",(void*)f_12338},
{"f_12342:support_scm",(void*)f_12342},
{"f_12347:support_scm",(void*)f_12347},
{"f_12351:support_scm",(void*)f_12351},
{"f_12402:support_scm",(void*)f_12402},
{"f_12381:support_scm",(void*)f_12381},
{"f_12393:support_scm",(void*)f_12393},
{"f_12396:support_scm",(void*)f_12396},
{"f_12369:support_scm",(void*)f_12369},
{"f_12305:support_scm",(void*)f_12305},
{"f_12315:support_scm",(void*)f_12315},
{"f_12318:support_scm",(void*)f_12318},
{"f_12299:support_scm",(void*)f_12299},
{"f_12254:support_scm",(void*)f_12254},
{"f_12261:support_scm",(void*)f_12261},
{"f_12276:support_scm",(void*)f_12276},
{"f_12280:support_scm",(void*)f_12280},
{"f_12272:support_scm",(void*)f_12272},
{"f_12258:support_scm",(void*)f_12258},
{"f_12131:support_scm",(void*)f_12131},
{"f_12140:support_scm",(void*)f_12140},
{"f_12168:support_scm",(void*)f_12168},
{"f_12174:support_scm",(void*)f_12174},
{"f_12177:support_scm",(void*)f_12177},
{"f_12180:support_scm",(void*)f_12180},
{"f_12183:support_scm",(void*)f_12183},
{"f_12186:support_scm",(void*)f_12186},
{"f_12189:support_scm",(void*)f_12189},
{"f_12248:support_scm",(void*)f_12248},
{"f_12192:support_scm",(void*)f_12192},
{"f_12207:support_scm",(void*)f_12207},
{"f_12210:support_scm",(void*)f_12210},
{"f_12218:support_scm",(void*)f_12218},
{"f_12228:support_scm",(void*)f_12228},
{"f_12231:support_scm",(void*)f_12231},
{"f_12213:support_scm",(void*)f_12213},
{"f_12198:support_scm",(void*)f_12198},
{"f_12135:support_scm",(void*)f_12135},
{"f_12128:support_scm",(void*)f_12128},
{"f_12110:support_scm",(void*)f_12110},
{"f_12076:support_scm",(void*)f_12076},
{"f_12100:support_scm",(void*)f_12100},
{"f_12096:support_scm",(void*)f_12096},
{"f_12055:support_scm",(void*)f_12055},
{"f_12061:support_scm",(void*)f_12061},
{"f_12065:support_scm",(void*)f_12065},
{"f_12068:support_scm",(void*)f_12068},
{"f_12071:support_scm",(void*)f_12071},
{"f_12043:support_scm",(void*)f_12043},
{"f_12047:support_scm",(void*)f_12047},
{"f_11952:support_scm",(void*)f_11952},
{"f_11971:support_scm",(void*)f_11971},
{"f_11996:support_scm",(void*)f_11996},
{"f_12000:support_scm",(void*)f_12000},
{"f_12002:support_scm",(void*)f_12002},
{"f_12009:support_scm",(void*)f_12009},
{"f_12022:support_scm",(void*)f_12022},
{"f_12025:support_scm",(void*)f_12025},
{"f_12028:support_scm",(void*)f_12028},
{"f_12031:support_scm",(void*)f_12031},
{"f_12034:support_scm",(void*)f_12034},
{"f_12038:support_scm",(void*)f_12038},
{"f_11955:support_scm",(void*)f_11955},
{"f_11959:support_scm",(void*)f_11959},
{"f_11965:support_scm",(void*)f_11965},
{"f_11946:support_scm",(void*)f_11946},
{"f_11887:support_scm",(void*)f_11887},
{"f_11895:support_scm",(void*)f_11895},
{"f_11922:support_scm",(void*)f_11922},
{"f_11898:support_scm",(void*)f_11898},
{"f_11901:support_scm",(void*)f_11901},
{"f_11918:support_scm",(void*)f_11918},
{"f_11904:support_scm",(void*)f_11904},
{"f_11914:support_scm",(void*)f_11914},
{"f_11907:support_scm",(void*)f_11907},
{"f_11910:support_scm",(void*)f_11910},
{"f_11878:support_scm",(void*)f_11878},
{"f_11872:support_scm",(void*)f_11872},
{"f_11866:support_scm",(void*)f_11866},
{"f_11854:support_scm",(void*)f_11854},
{"f_11858:support_scm",(void*)f_11858},
{"f_11861:support_scm",(void*)f_11861},
{"f_11816:support_scm",(void*)f_11816},
{"f_11820:support_scm",(void*)f_11820},
{"f13809:support_scm",(void*)f13809},
{"f_11823:support_scm",(void*)f_11823},
{"f_11830:support_scm",(void*)f_11830},
{"f_11774:support_scm",(void*)f_11774},
{"f_11783:support_scm",(void*)f_11783},
{"f_11745:support_scm",(void*)f_11745},
{"f_11755:support_scm",(void*)f_11755},
{"f_11536:support_scm",(void*)f_11536},
{"f_11740:support_scm",(void*)f_11740},
{"f_11705:support_scm",(void*)f_11705},
{"f_11711:support_scm",(void*)f_11711},
{"f_11726:support_scm",(void*)f_11726},
{"f_11719:support_scm",(void*)f_11719},
{"f_11539:support_scm",(void*)f_11539},
{"f_11573:support_scm",(void*)f_11573},
{"f_11667:support_scm",(void*)f_11667},
{"f_11679:support_scm",(void*)f_11679},
{"f_11637:support_scm",(void*)f_11637},
{"f_11648:support_scm",(void*)f_11648},
{"f_11628:support_scm",(void*)f_11628},
{"f_11592:support_scm",(void*)f_11592},
{"f_11598:support_scm",(void*)f_11598},
{"f_11602:support_scm",(void*)f_11602},
{"f_11397:support_scm",(void*)f_11397},
{"f_11403:support_scm",(void*)f_11403},
{"f_11496:support_scm",(void*)f_11496},
{"f_11501:support_scm",(void*)f_11501},
{"f_11511:support_scm",(void*)f_11511},
{"f_11464:support_scm",(void*)f_11464},
{"f_11435:support_scm",(void*)f_11435},
{"f_11440:support_scm",(void*)f_11440},
{"f_11450:support_scm",(void*)f_11450},
{"f_11401:support_scm",(void*)f_11401},
{"f_11028:support_scm",(void*)f_11028},
{"f_11227:support_scm",(void*)f_11227},
{"f_11319:support_scm",(void*)f_11319},
{"f_11230:support_scm",(void*)f_11230},
{"f_10707:support_scm",(void*)f_10707},
{"f_11022:support_scm",(void*)f_11022},
{"f_10719:support_scm",(void*)f_10719},
{"f_10729:support_scm",(void*)f_10729},
{"f_10747:support_scm",(void*)f_10747},
{"f_10786:support_scm",(void*)f_10786},
{"f_10751:support_scm",(void*)f_10751},
{"f_10377:support_scm",(void*)f_10377},
{"f_10701:support_scm",(void*)f_10701},
{"f_10383:support_scm",(void*)f_10383},
{"f_10393:support_scm",(void*)f_10393},
{"f_10402:support_scm",(void*)f_10402},
{"f_10414:support_scm",(void*)f_10414},
{"f_10426:support_scm",(void*)f_10426},
{"f_10432:support_scm",(void*)f_10432},
{"f_10436:support_scm",(void*)f_10436},
{"f_10332:support_scm",(void*)f_10332},
{"f_10371:support_scm",(void*)f_10371},
{"f_10338:support_scm",(void*)f_10338},
{"f_10342:support_scm",(void*)f_10342},
{"f_10346:support_scm",(void*)f_10346},
{"f_10301:support_scm",(void*)f_10301},
{"f_10314:support_scm",(void*)f_10314},
{"f_10270:support_scm",(void*)f_10270},
{"f_10283:support_scm",(void*)f_10283},
{"f_9212:support_scm",(void*)f_9212},
{"f_10264:support_scm",(void*)f_10264},
{"f_9218:support_scm",(void*)f_9218},
{"f_9224:support_scm",(void*)f_9224},
{"f_9253:support_scm",(void*)f_9253},
{"f_9272:support_scm",(void*)f_9272},
{"f_9291:support_scm",(void*)f_9291},
{"f_9361:support_scm",(void*)f_9361},
{"f_9380:support_scm",(void*)f_9380},
{"f_9462:support_scm",(void*)f_9462},
{"f_9501:support_scm",(void*)f_9501},
{"f_9520:support_scm",(void*)f_9520},
{"f_9539:support_scm",(void*)f_9539},
{"f_9619:support_scm",(void*)f_9619},
{"f_9704:support_scm",(void*)f_9704},
{"f_9779:support_scm",(void*)f_9779},
{"f_9818:support_scm",(void*)f_9818},
{"f_9888:support_scm",(void*)f_9888},
{"f_9821:support_scm",(void*)f_9821},
{"f_9783:support_scm",(void*)f_9783},
{"f_9622:support_scm",(void*)f_9622},
{"f_9653:support_scm",(void*)f_9653},
{"f_9542:support_scm",(void*)f_9542},
{"f_9383:support_scm",(void*)f_9383},
{"f_9414:support_scm",(void*)f_9414},
{"f_9294:support_scm",(void*)f_9294},
{"f_9325:support_scm",(void*)f_9325},
{"f_9154:support_scm",(void*)f_9154},
{"f_9158:support_scm",(void*)f_9158},
{"f_9169:support_scm",(void*)f_9169},
{"f_9175:support_scm",(void*)f_9175},
{"f_9187:support_scm",(void*)f_9187},
{"f_9193:support_scm",(void*)f_9193},
{"f_9161:support_scm",(void*)f_9161},
{"f_9073:support_scm",(void*)f_9073},
{"f_9085:support_scm",(void*)f_9085},
{"f_9092:support_scm",(void*)f_9092},
{"f_9095:support_scm",(void*)f_9095},
{"f_9098:support_scm",(void*)f_9098},
{"f_9101:support_scm",(void*)f_9101},
{"f_9104:support_scm",(void*)f_9104},
{"f_9107:support_scm",(void*)f_9107},
{"f_9110:support_scm",(void*)f_9110},
{"f_9113:support_scm",(void*)f_9113},
{"f_9116:support_scm",(void*)f_9116},
{"f_9119:support_scm",(void*)f_9119},
{"f_9122:support_scm",(void*)f_9122},
{"f_9125:support_scm",(void*)f_9125},
{"f_9128:support_scm",(void*)f_9128},
{"f_9131:support_scm",(void*)f_9131},
{"f_9134:support_scm",(void*)f_9134},
{"f_9137:support_scm",(void*)f_9137},
{"f_9140:support_scm",(void*)f_9140},
{"f_9143:support_scm",(void*)f_9143},
{"f_9146:support_scm",(void*)f_9146},
{"f_9149:support_scm",(void*)f_9149},
{"f_9079:support_scm",(void*)f_9079},
{"f_8965:support_scm",(void*)f_8965},
{"f_8974:support_scm",(void*)f_8974},
{"f_8980:support_scm",(void*)f_8980},
{"f_8988:support_scm",(void*)f_8988},
{"f_8969:support_scm",(void*)f_8969},
{"f_8944:support_scm",(void*)f_8944},
{"f_8954:support_scm",(void*)f_8954},
{"f_8895:support_scm",(void*)f_8895},
{"f_8901:support_scm",(void*)f_8901},
{"f_8942:support_scm",(void*)f_8942},
{"f_8914:support_scm",(void*)f_8914},
{"f_8858:support_scm",(void*)f_8858},
{"f_8864:support_scm",(void*)f_8864},
{"f_8893:support_scm",(void*)f_8893},
{"f_8871:support_scm",(void*)f_8871},
{"f_8874:support_scm",(void*)f_8874},
{"f_8817:support_scm",(void*)f_8817},
{"f_8823:support_scm",(void*)f_8823},
{"f_8856:support_scm",(void*)f_8856},
{"f_8830:support_scm",(void*)f_8830},
{"f_8833:support_scm",(void*)f_8833},
{"f_8695:support_scm",(void*)f_8695},
{"f_8724:support_scm",(void*)f_8724},
{"f_8594:support_scm",(void*)f_8594},
{"f_8600:support_scm",(void*)f_8600},
{"f_8626:support_scm",(void*)f_8626},
{"f_8640:support_scm",(void*)f_8640},
{"f_8648:support_scm",(void*)f_8648},
{"f_8369:support_scm",(void*)f_8369},
{"f_8568:support_scm",(void*)f_8568},
{"f_8574:support_scm",(void*)f_8574},
{"f_8449:support_scm",(void*)f_8449},
{"f_8471:support_scm",(void*)f_8471},
{"f_8489:support_scm",(void*)f_8489},
{"f_8520:support_scm",(void*)f_8520},
{"f_8406:support_scm",(void*)f_8406},
{"f_8428:support_scm",(void*)f_8428},
{"f_8372:support_scm",(void*)f_8372},
{"f_8401:support_scm",(void*)f_8401},
{"f_8380:support_scm",(void*)f_8380},
{"f_8300:support_scm",(void*)f_8300},
{"f_8306:support_scm",(void*)f_8306},
{"f_8312:support_scm",(void*)f_8312},
{"f_8316:support_scm",(void*)f_8316},
{"f_8363:support_scm",(void*)f_8363},
{"f_8327:support_scm",(void*)f_8327},
{"f_8352:support_scm",(void*)f_8352},
{"f_8063:support_scm",(void*)f_8063},
{"f_8157:support_scm",(void*)f_8157},
{"f_8164:support_scm",(void*)f_8164},
{"f_8298:support_scm",(void*)f_8298},
{"f_8188:support_scm",(void*)f_8188},
{"f_8265:support_scm",(void*)f_8265},
{"f_8222:support_scm",(void*)f_8222},
{"f_8225:support_scm",(void*)f_8225},
{"f_8241:support_scm",(void*)f_8241},
{"f_8067:support_scm",(void*)f_8067},
{"f_8106:support_scm",(void*)f_8106},
{"f_8155:support_scm",(void*)f_8155},
{"f_8110:support_scm",(void*)f_8110},
{"f_8120:support_scm",(void*)f_8120},
{"f_8122:support_scm",(void*)f_8122},
{"f_8134:support_scm",(void*)f_8134},
{"f_8140:support_scm",(void*)f_8140},
{"f_8113:support_scm",(void*)f_8113},
{"f_8070:support_scm",(void*)f_8070},
{"f_8076:support_scm",(void*)f_8076},
{"f_8089:support_scm",(void*)f_8089},
{"f_8081:support_scm",(void*)f_8081},
{"f_7995:support_scm",(void*)f_7995},
{"f_8001:support_scm",(void*)f_8001},
{"f_8028:support_scm",(void*)f_8028},
{"f_8057:support_scm",(void*)f_8057},
{"f_8022:support_scm",(void*)f_8022},
{"f_7909:support_scm",(void*)f_7909},
{"f_7915:support_scm",(void*)f_7915},
{"f_7960:support_scm",(void*)f_7960},
{"f_7989:support_scm",(void*)f_7989},
{"f_7949:support_scm",(void*)f_7949},
{"f_7945:support_scm",(void*)f_7945},
{"f_7870:support_scm",(void*)f_7870},
{"f_7874:support_scm",(void*)f_7874},
{"f_7877:support_scm",(void*)f_7877},
{"f_7880:support_scm",(void*)f_7880},
{"f_7836:support_scm",(void*)f_7836},
{"f_7842:support_scm",(void*)f_7842},
{"f_7856:support_scm",(void*)f_7856},
{"f_7860:support_scm",(void*)f_7860},
{"f_7437:support_scm",(void*)f_7437},
{"f_7787:support_scm",(void*)f_7787},
{"f_7820:support_scm",(void*)f_7820},
{"f_7800:support_scm",(void*)f_7800},
{"f_7441:support_scm",(void*)f_7441},
{"f_7449:support_scm",(void*)f_7449},
{"f_7772:support_scm",(void*)f_7772},
{"f_7778:support_scm",(void*)f_7778},
{"f_7776:support_scm",(void*)f_7776},
{"f_7612:support_scm",(void*)f_7612},
{"f_7719:support_scm",(void*)f_7719},
{"f_7756:support_scm",(void*)f_7756},
{"f_7746:support_scm",(void*)f_7746},
{"f_7750:support_scm",(void*)f_7750},
{"f_7753:support_scm",(void*)f_7753},
{"f_7616:support_scm",(void*)f_7616},
{"f_7670:support_scm",(void*)f_7670},
{"f_7703:support_scm",(void*)f_7703},
{"f_7683:support_scm",(void*)f_7683},
{"f_7668:support_scm",(void*)f_7668},
{"f_7619:support_scm",(void*)f_7619},
{"f_7645:support_scm",(void*)f_7645},
{"f_7661:support_scm",(void*)f_7661},
{"f_7653:support_scm",(void*)f_7653},
{"f_7637:support_scm",(void*)f_7637},
{"f_7635:support_scm",(void*)f_7635},
{"f_7563:support_scm",(void*)f_7563},
{"f_7566:support_scm",(void*)f_7566},
{"f_7569:support_scm",(void*)f_7569},
{"f_7589:support_scm",(void*)f_7589},
{"f_7547:support_scm",(void*)f_7547},
{"f_7539:support_scm",(void*)f_7539},
{"f_7510:support_scm",(void*)f_7510},
{"f_7500:support_scm",(void*)f_7500},
{"f_7507:support_scm",(void*)f_7507},
{"f_7289:support_scm",(void*)f_7289},
{"f_7295:support_scm",(void*)f_7295},
{"f_7307:support_scm",(void*)f_7307},
{"f_7402:support_scm",(void*)f_7402},
{"f_7431:support_scm",(void*)f_7431},
{"f_7311:support_scm",(void*)f_7311},
{"f_7314:support_scm",(void*)f_7314},
{"f_7394:support_scm",(void*)f_7394},
{"f_7340:support_scm",(void*)f_7340},
{"f_7344:support_scm",(void*)f_7344},
{"f_7319:support_scm",(void*)f_7319},
{"f_7301:support_scm",(void*)f_7301},
{"f_7235:support_scm",(void*)f_7235},
{"f_7241:support_scm",(void*)f_7241},
{"f_7267:support_scm",(void*)f_7267},
{"f_7271:support_scm",(void*)f_7271},
{"f_6554:support_scm",(void*)f_6554},
{"f_6560:support_scm",(void*)f_6560},
{"f_6594:support_scm",(void*)f_6594},
{"f_7052:support_scm",(void*)f_7052},
{"f_7170:support_scm",(void*)f_7170},
{"f_7199:support_scm",(void*)f_7199},
{"f_7168:support_scm",(void*)f_7168},
{"f_7164:support_scm",(void*)f_7164},
{"f_7124:support_scm",(void*)f_7124},
{"f_7153:support_scm",(void*)f_7153},
{"f_7122:support_scm",(void*)f_7122},
{"f_7059:support_scm",(void*)f_7059},
{"f_7069:support_scm",(void*)f_7069},
{"f_7098:support_scm",(void*)f_7098},
{"f_7063:support_scm",(void*)f_7063},
{"f_6990:support_scm",(void*)f_6990},
{"f_7039:support_scm",(void*)f_7039},
{"f_7008:support_scm",(void*)f_7008},
{"f_7016:support_scm",(void*)f_7016},
{"f_6933:support_scm",(void*)f_6933},
{"f_6962:support_scm",(void*)f_6962},
{"f_6931:support_scm",(void*)f_6931},
{"f_6881:support_scm",(void*)f_6881},
{"f_6910:support_scm",(void*)f_6910},
{"f_6863:support_scm",(void*)f_6863},
{"f_6807:support_scm",(void*)f_6807},
{"f_6809:support_scm",(void*)f_6809},
{"f_6838:support_scm",(void*)f_6838},
{"f_6754:support_scm",(void*)f_6754},
{"f_6756:support_scm",(void*)f_6756},
{"f_6789:support_scm",(void*)f_6789},
{"f_6769:support_scm",(void*)f_6769},
{"f_6738:support_scm",(void*)f_6738},
{"f_6750:support_scm",(void*)f_6750},
{"f_6746:support_scm",(void*)f_6746},
{"f_6659:support_scm",(void*)f_6659},
{"f_6688:support_scm",(void*)f_6688},
{"f_6657:support_scm",(void*)f_6657},
{"f_6653:support_scm",(void*)f_6653},
{"f_6603:support_scm",(void*)f_6603},
{"f_6632:support_scm",(void*)f_6632},
{"f_6601:support_scm",(void*)f_6601},
{"f_5631:support_scm",(void*)f_5631},
{"f_6549:support_scm",(void*)f_6549},
{"f_6552:support_scm",(void*)f_6552},
{"f_5634:support_scm",(void*)f_5634},
{"f_6509:support_scm",(void*)f_6509},
{"f_6538:support_scm",(void*)f_6538},
{"f_6507:support_scm",(void*)f_6507},
{"f_6247:support_scm",(void*)f_6247},
{"f_6374:support_scm",(void*)f_6374},
{"f_6458:support_scm",(void*)f_6458},
{"f_6430:support_scm",(void*)f_6430},
{"f_6437:support_scm",(void*)f_6437},
{"f_6444:support_scm",(void*)f_6444},
{"f_6434:support_scm",(void*)f_6434},
{"f_6393:support_scm",(void*)f_6393},
{"f_6422:support_scm",(void*)f_6422},
{"f_6391:support_scm",(void*)f_6391},
{"f_6368:support_scm",(void*)f_6368},
{"f_6330:support_scm",(void*)f_6330},
{"f_6359:support_scm",(void*)f_6359},
{"f_6324:support_scm",(void*)f_6324},
{"f_6273:support_scm",(void*)f_6273},
{"f_6302:support_scm",(void*)f_6302},
{"f_6267:support_scm",(void*)f_6267},
{"f_6226:support_scm",(void*)f_6226},
{"f_6210:support_scm",(void*)f_6210},
{"f_6206:support_scm",(void*)f_6206},
{"f_6140:support_scm",(void*)f_6140},
{"f_6169:support_scm",(void*)f_6169},
{"f_6134:support_scm",(void*)f_6134},
{"f_6050:support_scm",(void*)f_6050},
{"f_6079:support_scm",(void*)f_6079},
{"f_6044:support_scm",(void*)f_6044},
{"f_5952:support_scm",(void*)f_5952},
{"f_5962:support_scm",(void*)f_5962},
{"f_5991:support_scm",(void*)f_5991},
{"f_5956:support_scm",(void*)f_5956},
{"f_5919:support_scm",(void*)f_5919},
{"f_5826:support_scm",(void*)f_5826},
{"f_5848:support_scm",(void*)f_5848},
{"f_5886:support_scm",(void*)f_5886},
{"f_5875:support_scm",(void*)f_5875},
{"f_5834:support_scm",(void*)f_5834},
{"f_5842:support_scm",(void*)f_5842},
{"f_5830:support_scm",(void*)f_5830},
{"f_5767:support_scm",(void*)f_5767},
{"f_5770:support_scm",(void*)f_5770},
{"f_5777:support_scm",(void*)f_5777},
{"f_5715:support_scm",(void*)f_5715},
{"f_5744:support_scm",(void*)f_5744},
{"f_5709:support_scm",(void*)f_5709},
{"f_5616:support_scm",(void*)f_5616},
{"f_5601:support_scm",(void*)f_5601},
{"f_5595:support_scm",(void*)f_5595},
{"f_5586:support_scm",(void*)f_5586},
{"f_5577:support_scm",(void*)f_5577},
{"f_5568:support_scm",(void*)f_5568},
{"f_5559:support_scm",(void*)f_5559},
{"f_5550:support_scm",(void*)f_5550},
{"f_5541:support_scm",(void*)f_5541},
{"f_5535:support_scm",(void*)f_5535},
{"f_5036:support_scm",(void*)f_5036},
{"f_5533:support_scm",(void*)f_5533},
{"f_5040:support_scm",(void*)f_5040},
{"f_5045:support_scm",(void*)f_5045},
{"f_5055:support_scm",(void*)f_5055},
{"f_5218:support_scm",(void*)f_5218},
{"f_5228:support_scm",(void*)f_5228},
{"f_5244:support_scm",(void*)f_5244},
{"f_5320:support_scm",(void*)f_5320},
{"f_5360:support_scm",(void*)f_5360},
{"f_5350:support_scm",(void*)f_5350},
{"f_5323:support_scm",(void*)f_5323},
{"f_5340:support_scm",(void*)f_5340},
{"f_5326:support_scm",(void*)f_5326},
{"f_5329:support_scm",(void*)f_5329},
{"f_5336:support_scm",(void*)f_5336},
{"f_5311:support_scm",(void*)f_5311},
{"f_5301:support_scm",(void*)f_5301},
{"f_5285:support_scm",(void*)f_5285},
{"f_5247:support_scm",(void*)f_5247},
{"f_5262:support_scm",(void*)f_5262},
{"f_5231:support_scm",(void*)f_5231},
{"f_5058:support_scm",(void*)f_5058},
{"f_5099:support_scm",(void*)f_5099},
{"f_5133:support_scm",(void*)f_5133},
{"f_5167:support_scm",(void*)f_5167},
{"f_5170:support_scm",(void*)f_5170},
{"f_5136:support_scm",(void*)f_5136},
{"f_5102:support_scm",(void*)f_5102},
{"f_5061:support_scm",(void*)f_5061},
{"f_5089:support_scm",(void*)f_5089},
{"f_5064:support_scm",(void*)f_5064},
{"f_5076:support_scm",(void*)f_5076},
{"f_5067:support_scm",(void*)f_5067},
{"f_4973:support_scm",(void*)f_4973},
{"f_4979:support_scm",(void*)f_4979},
{"f_4986:support_scm",(void*)f_4986},
{"f_4989:support_scm",(void*)f_4989},
{"f_5001:support_scm",(void*)f_5001},
{"f_5030:support_scm",(void*)f_5030},
{"f_4999:support_scm",(void*)f_4999},
{"f_4992:support_scm",(void*)f_4992},
{"f_4949:support_scm",(void*)f_4949},
{"f_4955:support_scm",(void*)f_4955},
{"f_4965:support_scm",(void*)f_4965},
{"f_4908:support_scm",(void*)f_4908},
{"f_4915:support_scm",(void*)f_4915},
{"f_4918:support_scm",(void*)f_4918},
{"f_4922:support_scm",(void*)f_4922},
{"f_4898:support_scm",(void*)f_4898},
{"f_4889:support_scm",(void*)f_4889},
{"f_4893:support_scm",(void*)f_4893},
{"f_4832:support_scm",(void*)f_4832},
{"f_4836:support_scm",(void*)f_4836},
{"f_4866:support_scm",(void*)f_4866},
{"f_4780:support_scm",(void*)f_4780},
{"f_4784:support_scm",(void*)f_4784},
{"f_4811:support_scm",(void*)f_4811},
{"f_4734:support_scm",(void*)f_4734},
{"f_4738:support_scm",(void*)f_4738},
{"f_4760:support_scm",(void*)f_4760},
{"f_4716:support_scm",(void*)f_4716},
{"f_4720:support_scm",(void*)f_4720},
{"f_4728:support_scm",(void*)f_4728},
{"f_4698:support_scm",(void*)f_4698},
{"f_4702:support_scm",(void*)f_4702},
{"f_4445:support_scm",(void*)f_4445},
{"f_4607:support_scm",(void*)f_4607},
{"f_4621:support_scm",(void*)f_4621},
{"f_4646:support_scm",(void*)f_4646},
{"f_4657:support_scm",(void*)f_4657},
{"f_4685:support_scm",(void*)f_4685},
{"f_4453:support_scm",(void*)f_4453},
{"f_4516:support_scm",(void*)f_4516},
{"f_4530:support_scm",(void*)f_4530},
{"f_4555:support_scm",(void*)f_4555},
{"f_4566:support_scm",(void*)f_4566},
{"f_4594:support_scm",(void*)f_4594},
{"f_4456:support_scm",(void*)f_4456},
{"f_4461:support_scm",(void*)f_4461},
{"f_4475:support_scm",(void*)f_4475},
{"f_4503:support_scm",(void*)f_4503},
{"f_4449:support_scm",(void*)f_4449},
{"f_4304:support_scm",(void*)f_4304},
{"f_4308:support_scm",(void*)f_4308},
{"f_4312:support_scm",(void*)f_4312},
{"f_4301:support_scm",(void*)f_4301},
{"f_4194:support_scm",(void*)f_4194},
{"f_4203:support_scm",(void*)f_4203},
{"f_4234:support_scm",(void*)f_4234},
{"f_4288:support_scm",(void*)f_4288},
{"f_4294:support_scm",(void*)f_4294},
{"f_4240:support_scm",(void*)f_4240},
{"f_4272:support_scm",(void*)f_4272},
{"f_4286:support_scm",(void*)f_4286},
{"f_4278:support_scm",(void*)f_4278},
{"f_4244:support_scm",(void*)f_4244},
{"f_4266:support_scm",(void*)f_4266},
{"f_4209:support_scm",(void*)f_4209},
{"f_4215:support_scm",(void*)f_4215},
{"f_4226:support_scm",(void*)f_4226},
{"f_4223:support_scm",(void*)f_4223},
{"f_4198:support_scm",(void*)f_4198},
{"f_4093:support_scm",(void*)f_4093},
{"f_4099:support_scm",(void*)f_4099},
{"f_4176:support_scm",(void*)f_4176},
{"f_4127:support_scm",(void*)f_4127},
{"f_4165:support_scm",(void*)f_4165},
{"f_4153:support_scm",(void*)f_4153},
{"f_4033:support_scm",(void*)f_4033},
{"f_4049:support_scm",(void*)f_4049},
{"f_4091:support_scm",(void*)f_4091},
{"f_4055:support_scm",(void*)f_4055},
{"f_4070:support_scm",(void*)f_4070},
{"f_3987:support_scm",(void*)f_3987},
{"f_4031:support_scm",(void*)f_4031},
{"f_3991:support_scm",(void*)f_3991},
{"f_3957:support_scm",(void*)f_3957},
{"f_3911:support_scm",(void*)f_3911},
{"f_3891:support_scm",(void*)f_3891},
{"f_3897:support_scm",(void*)f_3897},
{"f_3905:support_scm",(void*)f_3905},
{"f_3909:support_scm",(void*)f_3909},
{"f_3860:support_scm",(void*)f_3860},
{"f_3866:support_scm",(void*)f_3866},
{"f_3881:support_scm",(void*)f_3881},
{"f_3797:support_scm",(void*)f_3797},
{"f_3811:support_scm",(void*)f_3811},
{"f_3813:support_scm",(void*)f_3813},
{"f_3842:support_scm",(void*)f_3842},
{"f_3785:support_scm",(void*)f_3785},
{"f_3738:support_scm",(void*)f_3738},
{"f_3754:support_scm",(void*)f_3754},
{"f_3766:support_scm",(void*)f_3766},
{"f_3731:support_scm",(void*)f_3731},
{"f_3724:support_scm",(void*)f_3724},
{"f_3668:support_scm",(void*)f_3668},
{"f_3722:support_scm",(void*)f_3722},
{"f_3672:support_scm",(void*)f_3672},
{"f_3695:support_scm",(void*)f_3695},
{"f_3574:support_scm",(void*)f_3574},
{"f_3590:support_scm",(void*)f_3590},
{"f_3592:support_scm",(void*)f_3592},
{"f_3614:support_scm",(void*)f_3614},
{"f_3653:support_scm",(void*)f_3653},
{"f_3621:support_scm",(void*)f_3621},
{"f_3637:support_scm",(void*)f_3637},
{"f_3625:support_scm",(void*)f_3625},
{"f_3629:support_scm",(void*)f_3629},
{"f_3586:support_scm",(void*)f_3586},
{"f_3530:support_scm",(void*)f_3530},
{"f_3536:support_scm",(void*)f_3536},
{"f_3560:support_scm",(void*)f_3560},
{"f_3499:support_scm",(void*)f_3499},
{"f_3522:support_scm",(void*)f_3522},
{"f_3525:support_scm",(void*)f_3525},
{"f_3528:support_scm",(void*)f_3528},
{"f_3472:support_scm",(void*)f_3472},
{"f_3491:support_scm",(void*)f_3491},
{"f_3494:support_scm",(void*)f_3494},
{"f_3436:support_scm",(void*)f_3436},
{"f_3442:support_scm",(void*)f_3442},
{"f_3368:support_scm",(void*)f_3368},
{"f_3392:support_scm",(void*)f_3392},
{"f_3371:support_scm",(void*)f_3371},
{"f_3379:support_scm",(void*)f_3379},
{"f_3383:support_scm",(void*)f_3383},
{"f_3325:support_scm",(void*)f_3325},
{"f_3331:support_scm",(void*)f_3331},
{"f_3354:support_scm",(void*)f_3354},
{"f_3358:support_scm",(void*)f_3358},
{"f_3322:support_scm",(void*)f_3322},
{"f_3277:support_scm",(void*)f_3277},
{"f_3281:support_scm",(void*)f_3281},
{"f_3284:support_scm",(void*)f_3284},
{"f_3287:support_scm",(void*)f_3287},
{"f_3298:support_scm",(void*)f_3298},
{"f_3290:support_scm",(void*)f_3290},
{"f_3293:support_scm",(void*)f_3293},
{"f_3258:support_scm",(void*)f_3258},
{"f_3262:support_scm",(void*)f_3262},
{"f_3275:support_scm",(void*)f_3275},
{"f_3265:support_scm",(void*)f_3265},
{"f_3268:support_scm",(void*)f_3268},
{"f_3193:support_scm",(void*)f_3193},
{"f_3203:support_scm",(void*)f_3203},
{"f_3218:support_scm",(void*)f_3218},
{"f_3223:support_scm",(void*)f_3223},
{"f_3242:support_scm",(void*)f_3242},
{"f_3235:support_scm",(void*)f_3235},
{"f_3245:support_scm",(void*)f_3245},
{"f_3206:support_scm",(void*)f_3206},
{"f_3209:support_scm",(void*)f_3209},
{"f_3212:support_scm",(void*)f_3212},
{"f_3166:support_scm",(void*)f_3166},
{"f_3180:support_scm",(void*)f_3180},
{"f_3161:support_scm",(void*)f_3161},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
