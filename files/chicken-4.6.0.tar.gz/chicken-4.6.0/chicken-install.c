/* Generated from chicken-install.scm by the CHICKEN compiler
   http://www.call-with-current-continuation.org
   2010-09-13 00:50
   Version 4.5.0 
   linux-unix-gnu-x86 [ manyargs dload ptables ]
   compiled 2010-05-25 on hd-t1179cl (Linux)
   command line: chicken-install.scm -optimize-level 2 -include-path . -include-path ./ -inline -ignore-repository -no-warnings -no-lambda-info -local -no-trace -output-file chicken-install.c
   used units: library eval srfi_1 posix data_structures utils regex ports extras srfi_13 files chicken_syntax
*/

#include "chicken.h"

static C_PTABLE_ENTRY *create_ptable(void);
C_noret_decl(C_library_toplevel)
C_externimport void C_ccall C_library_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_eval_toplevel)
C_externimport void C_ccall C_eval_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_1_toplevel)
C_externimport void C_ccall C_srfi_1_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_posix_toplevel)
C_externimport void C_ccall C_posix_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_data_structures_toplevel)
C_externimport void C_ccall C_data_structures_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_utils_toplevel)
C_externimport void C_ccall C_utils_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_regex_toplevel)
C_externimport void C_ccall C_regex_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_ports_toplevel)
C_externimport void C_ccall C_ports_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_extras_toplevel)
C_externimport void C_ccall C_extras_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_srfi_13_toplevel)
C_externimport void C_ccall C_srfi_13_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_files_toplevel)
C_externimport void C_ccall C_files_toplevel(C_word c,C_word d,C_word k) C_noret;
C_noret_decl(C_chicken_syntax_toplevel)
C_externimport void C_ccall C_chicken_syntax_toplevel(C_word c,C_word d,C_word k) C_noret;

static C_TLS C_word lf[355];
static double C_possibly_force_alignment;


C_noret_decl(C_toplevel)
C_externexport void C_ccall C_toplevel(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1279)
static void C_ccall f_1279(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1282)
static void C_ccall f_1282(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1285)
static void C_ccall f_1285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1288)
static void C_ccall f_1288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1291)
static void C_ccall f_1291(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1294)
static void C_ccall f_1294(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1297)
static void C_ccall f_1297(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1300)
static void C_ccall f_1300(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1303)
static void C_ccall f_1303(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1306)
static void C_ccall f_1306(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1309)
static void C_ccall f_1309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1312)
static void C_ccall f_1312(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1315)
static void C_ccall f_1315(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1318)
static void C_ccall f_1318(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1321)
static void C_ccall f_1321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1328)
static void C_ccall f_1328(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1331)
static void C_ccall f_1331(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1334)
static void C_ccall f_1334(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1359)
static void C_ccall f_1359(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5190)
static void C_ccall f_5190(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5186)
static void C_ccall f_5186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2180)
static void C_ccall f_2180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5100)
static void C_ccall f_5100(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5114)
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5153)
static void C_ccall f_5153(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_5172)
static void C_ccall f_5172r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_5178)
static void C_ccall f_5178(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5159)
static void C_ccall f_5159(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5170)
static void C_ccall f_5170(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4166)
static void C_ccall f_4166(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5097)
static void C_ccall f_5097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4169)
static void C_ccall f_4169(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4174)
static void C_fcall f_4174(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_4317)
static void C_fcall f_4317(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4885)
static void C_fcall f_4885(C_word t0,C_word t1) C_noret;
C_noret_decl(f_5037)
static void C_ccall f_5037(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4995)
static void C_ccall f_4995(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4999)
static void C_fcall f_4999(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5011)
static void C_ccall f_5011(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4950)
static void C_ccall f_4950(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4973)
static void C_ccall f_4973(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4982)
static void C_ccall f_4982(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4989)
static void C_ccall f_4989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4976)
static void C_ccall f_4976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4954)
static void C_ccall f_4954(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5601)
static void C_ccall f5601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4934)
static void C_ccall f_4934(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4894)
static void C_ccall f_4894(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4926)
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4900)
static void C_ccall f_4900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5596)
static void C_ccall f5596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4917)
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4911)
static void C_ccall f_4911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4907)
static void C_ccall f_4907(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5591)
static void C_ccall f5591(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4858)
static void C_ccall f_4858(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5586)
static void C_ccall f5586(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4800)
static void C_ccall f_4800(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5581)
static void C_ccall f5581(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4692)
static void C_ccall f_4692(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4707)
static void C_ccall f_4707(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5576)
static void C_ccall f5576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4654)
static void C_ccall f_4654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4669)
static void C_ccall f_4669(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5571)
static void C_ccall f5571(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4618)
static void C_ccall f_4618(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4621)
static void C_ccall f_4621(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5566)
static void C_ccall f5566(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4589)
static void C_ccall f_4589(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1842)
static void C_ccall f_1842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1848)
static void C_ccall f_1848(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1853)
static void C_fcall f_1853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1880)
static void C_ccall f_1880(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1861)
static void C_fcall f_1861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1877)
static void C_ccall f_1877(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1869)
static void C_ccall f_1869(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1873)
static void C_ccall f_1873(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4592)
static void C_ccall f_4592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4560)
static void C_ccall f_4560(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4553)
static void C_ccall f_4553(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5559)
static void C_ccall f5559(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4485)
static void C_ccall f_4485(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4502)
static void C_ccall f_4502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4513)
static void C_ccall f_4513(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4509)
static void C_ccall f_4509(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4492)
static void C_ccall f_4492(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5554)
static void C_ccall f5554(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4448)
static void C_ccall f_4448(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4452)
static void C_ccall f_4452(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5549)
static void C_ccall f5549(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4415)
static void C_ccall f_4415(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4379)
static void C_ccall f_4379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4336)
static void C_ccall f_4336(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4329)
static void C_ccall f_4329(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f5544)
static void C_ccall f5544(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1731)
static void C_ccall f_1731(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1387)
static void C_ccall f_1387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1727)
static void C_ccall f_1727(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1409)
static void C_ccall f_1409(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1411)
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1712)
static void C_ccall f_1712(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1419)
static void C_fcall f_1419(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1423)
static void C_ccall f_1423(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1619)
static void C_fcall f_1619(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1686)
static void C_ccall f_1686(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1646)
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1653)
static void C_ccall f_1653(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1613)
static void C_ccall f_1613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1609)
static void C_ccall f_1609(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1530)
static void C_fcall f_1530(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1595)
static void C_ccall f_1595(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1557)
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1588)
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1561)
static void C_ccall f_1561(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1564)
static void C_ccall f_1564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1575)
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1569)
static void C_ccall f_1569(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1524)
static void C_ccall f_1524(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1520)
static void C_ccall f_1520(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1502)
static void C_ccall f_1502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1454)
static void C_ccall f_1454(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1457)
static void C_ccall f_1457(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1460)
static void C_ccall f_1460(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1463)
static void C_ccall f_1463(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1466)
static void C_ccall f_1466(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1469)
static void C_ccall f_1469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1472)
static void C_ccall f_1472(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1396)
static void C_ccall f_1396(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1389)
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4199)
static void C_fcall f_4199(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4234)
static void C_ccall f_4234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4299)
static void C_ccall f_4299(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4250)
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4285)
static void C_ccall f_4285(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4248)
static void C_ccall f_4248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4244)
static void C_ccall f_4244(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4202)
static void C_ccall f_4202(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4219)
static void C_ccall f_4219(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4205)
static void C_ccall f_4205(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4216)
static void C_ccall f_4216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4212)
static void C_ccall f_4212(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3174)
static void C_ccall f_3174(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3592)
static void C_ccall f_3592(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3180)
static void C_ccall f_3180(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3186)
static void C_ccall f_3186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3189)
static void C_ccall f_3189(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3584)
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3196)
static void C_ccall f_3196(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3200)
static void C_ccall f_3200(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3202)
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3557)
static void C_ccall f_3557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3210)
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3541)
static void C_ccall f_3541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3525)
static void C_fcall f_3525(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3528)
static void C_ccall f_3528(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3531)
static void C_ccall f_3531(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3217)
static void C_ccall f_3217(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3220)
static void C_ccall f_3220(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3223)
static void C_ccall f_3223(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3491)
static void C_ccall f_3491(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3502)
static void C_ccall f_3502(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3229)
static void C_ccall f_3229(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3480)
static void C_ccall f_3480(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3474)
static void C_ccall f_3474(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3467)
static void C_ccall f_3467(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3431)
static void C_ccall f_3431(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3440)
static void C_ccall f_3440(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3456)
static void C_ccall f_3456(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3450)
static void C_ccall f_3450(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3445)
static void C_ccall f_3445(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3230)
static void C_fcall f_3230(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3234)
static void C_ccall f_3234(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3248)
static void C_ccall f_3248(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3013)
static void C_fcall f_3013(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3021)
static void C_ccall f_3021(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3024)
static void C_ccall f_3024(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3027)
static void C_ccall f_3027(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3030)
static void C_ccall f_3030(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3033)
static void C_ccall f_3033(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3036)
static void C_ccall f_3036(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3039)
static void C_ccall f_3039(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3154)
static void C_ccall f_3154(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3059)
static void C_ccall f_3059(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3129)
static void C_ccall f_3129(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3132)
static void C_ccall f_3132(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3145)
static void C_ccall f_3145(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3135)
static void C_ccall f_3135(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3138)
static void C_ccall f_3138(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3062)
static void C_ccall f_3062(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3114)
static void C_ccall f_3114(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3117)
static void C_ccall f_3117(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3120)
static void C_ccall f_3120(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3123)
static void C_ccall f_3123(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3066)
static void C_ccall f_3066(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3096)
static void C_ccall f_3096(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3099)
static void C_ccall f_3099(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3102)
static void C_ccall f_3102(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3105)
static void C_ccall f_3105(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3070)
static void C_ccall f_3070(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3082)
static void C_ccall f_3082(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3078)
static void C_ccall f_3078(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3252)
static void C_ccall f_3252(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3258)
static void C_ccall f_3258(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3375)
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3399)
static void C_ccall f_3399(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3411)
static void C_ccall f_3411r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3417)
static void C_ccall f_3417(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3405)
static void C_ccall f_3405(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3381)
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3387)
static void C_ccall f_3387(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3391)
static void C_ccall f_3391(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3394)
static void C_ccall f_3394(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3397)
static void C_ccall f_3397(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3370)
static void C_ccall f_3370(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3266)
static void C_ccall f_3266(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3358)
static void C_ccall f_3358(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3364)
static void C_ccall f_3364(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3272)
static void C_ccall f_3272(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3276)
static void C_ccall f_3276(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3297)
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3321)
static void C_ccall f_3321(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3333)
static void C_ccall f_3333r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3339)
static void C_ccall f_3339(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3327)
static void C_ccall f_3327(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3303)
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3309)
static void C_ccall f_3309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3313)
static void C_ccall f_3313(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3316)
static void C_ccall f_3316(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3319)
static void C_ccall f_3319(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3292)
static void C_ccall f_3292(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3288)
static void C_ccall f_3288(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3277)
static void C_fcall f_3277(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3259)
static void C_fcall f_3259(C_word t0,C_word t1) C_noret;
C_noret_decl(f_3235)
static void C_ccall f_3235(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3239)
static void C_ccall f_3239(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3242)
static void C_ccall f_3242(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3976)
static void C_ccall f_3976(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3972)
static void C_ccall f_3972(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3613)
static void C_ccall f_3613(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3616)
static void C_ccall f_3616(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3619)
static void C_ccall f_3619(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3622)
static void C_ccall f_3622(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3625)
static void C_ccall f_3625(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3965)
static void C_ccall f_3965(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3847)
static void C_ccall f_3847(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3853)
static void C_fcall f_3853(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3952)
static void C_ccall f_3952(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3861)
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3865)
static void C_ccall f_3865(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3873)
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3911)
static void C_ccall f_3911(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_3939)
static void C_ccall f_3939r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_3945)
static void C_ccall f_3945(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3917)
static void C_ccall f_3917(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3933)
static void C_ccall f_3933(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3879)
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3885)
static void C_ccall f_3885(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3893)
static void C_ccall f_3893(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3897)
static void C_ccall f_3897(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3900)
static void C_ccall f_3900(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3903)
static void C_ccall f_3903(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3906)
static void C_ccall f_3906(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3909)
static void C_ccall f_3909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3868)
static void C_ccall f_3868(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3842)
static void C_ccall f_3842(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3628)
static void C_ccall f_3628(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3631)
static void C_ccall f_3631(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3719)
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3726)
static void C_ccall f_3726(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3729)
static void C_ccall f_3729(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3740)
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_3798)
static void C_fcall f_3798(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3825)
static C_word C_fcall f_3825(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3748)
static void C_ccall f_3748(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3754)
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3781)
static C_word C_fcall f_3781(C_word *a,C_word t0,C_word t1);
C_noret_decl(f_3752)
static void C_ccall f_3752(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3734)
static void C_ccall f_3734(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3695)
static void C_ccall f_3695(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3697)
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3705)
static void C_ccall f_3705(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3709)
static void C_ccall f_3709(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3634)
static void C_ccall f_3634(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3637)
static void C_ccall f_3637(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3656)
static void C_ccall f_3656(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3662)
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_3674)
static void C_ccall f_3674(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3680)
static void C_ccall f_3680(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3640)
static void C_ccall f_3640(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3654)
static void C_ccall f_3654(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3650)
static void C_ccall f_3650(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3643)
static void C_ccall f_3643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5163)
static void C_ccall f_5163(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5120)
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_5126)
static void C_ccall f_5126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5151)
static void C_ccall f_5151(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5130)
static void C_ccall f_5130(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5147)
static void C_ccall f_5147(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5133)
static void C_ccall f_5133(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5136)
static void C_ccall f_5136(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5103)
static void C_ccall f_5103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5106)
static void C_ccall f_5106(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5112)
static void C_ccall f_5112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_5109)
static void C_ccall f_5109(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4129)
static void C_fcall f_4129(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4139)
static void C_ccall f_4139(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4152)
static void C_ccall f_4152(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4108)
static void C_fcall f_4108(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4112)
static void C_ccall f_4112(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4115)
static void C_ccall f_4115(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4086)
static void C_fcall f_4086(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4103)
static void C_ccall f_4103(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4090)
static void C_ccall f_4090(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3978)
static void C_fcall f_3978(C_word t0,C_word t1) C_noret;
C_noret_decl(f_4011)
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4070)
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4076)
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4015)
static void C_ccall f_4015(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4029)
static void C_fcall f_4029(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_4058)
static void C_ccall f_4058(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4009)
static void C_ccall f_4009(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3996)
static void C_ccall f_3996(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_4002)
static void C_ccall f_4002(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3999)
static void C_ccall f_3999(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3981)
static void C_ccall f_3981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_3989)
static void C_ccall f_3989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3993)
static void C_ccall f_3993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_3594)
static void C_fcall f_3594(C_word t0) C_noret;
C_noret_decl(f_3601)
static void C_ccall f_3601(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2486)
static void C_fcall f_2486(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2490)
static void C_ccall f_2490(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2760)
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2805)
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2809)
static void C_ccall f_2809(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2812)
static void C_ccall f_2812(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2799)
static void C_ccall f_2799(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1814)
static void C_ccall f_1814(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1797)
static void C_fcall f_1797(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1804)
static void C_ccall f_1804(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1794)
static void C_ccall f_1794(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1790)
static void C_fcall f_1790(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2323)
static void C_fcall f_2323(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2325)
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2393)
static void C_ccall f_2393(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2341)
static void C_ccall f_2341(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2379)
static void C_ccall f_2379(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2344)
static void C_fcall f_2344(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2355)
static void C_ccall f_2355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_1821)
static void C_ccall f_1821(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2349)
static void C_ccall f_2349(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2191)
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2284)
static void C_ccall f_2284(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,...) C_noret;
C_noret_decl(f_2303)
static void C_ccall f_2303r(C_word t0,C_word t1,C_word t3) C_noret;
C_noret_decl(f_2309)
static void C_ccall f_2309(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2290)
static void C_ccall f_2290(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2298)
static void C_ccall f_2298(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2197)
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2203)
static void C_ccall f_2203(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2213)
static void C_fcall f_2213(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2225)
static void C_fcall f_2225(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2237)
static void C_fcall f_2237(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2240)
static void C_ccall f_2240(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2243)
static void C_ccall f_2243(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2228)
static void C_ccall f_2228(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2216)
static void C_ccall f_2216(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2186)
static void C_ccall f_2186(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2785)
static void C_ccall f_2785(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2838)
static void C_ccall f_2838(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2493)
static void C_ccall f_2493(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2501)
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2523)
static void C_ccall f_2523(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2529)
static void C_ccall f_2529(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2724)
static void C_ccall f_2724(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2532)
static void C_ccall f_2532(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2535)
static void C_ccall f_2535(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2876)
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2911)
static void C_fcall f_2911(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2966)
static void C_ccall f_2966(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2940)
static void C_ccall f_2940(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2924)
static void C_ccall f_2924(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2886)
static void C_ccall f_2886(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2854)
static void C_fcall f_2854(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2538)
static void C_ccall f_2538(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2541)
static void C_ccall f_2541(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2552)
static void C_ccall f_2552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3) C_noret;
C_noret_decl(f_2557)
static void C_ccall f_2557(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2659)
static void C_ccall f_2659(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2661)
static void C_fcall f_2661(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2671)
static void C_fcall f_2671(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2655)
static void C_ccall f_2655(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2643)
static void C_ccall f_2643(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2636)
static void C_ccall f_2636(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2564)
static void C_ccall f_2564(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2416)
static void C_fcall f_2416(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2469)
static void C_ccall f_2469(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2476)
static void C_ccall f_2476(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2414)
static void C_ccall f_2414(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2406)
static void C_ccall f_2406(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2630)
static void C_ccall f_2630(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2570)
static void C_ccall f_2570(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2573)
static void C_ccall f_2573(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2617)
static void C_ccall f_2617(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2576)
static void C_ccall f_2576(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2584)
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_2596)
static void C_ccall f_2596(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2602)
static void C_ccall f_2602(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2579)
static void C_ccall f_2579(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2546)
static void C_ccall f_2546(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1970)
static void C_ccall f_1970(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1975)
static void C_fcall f_1975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4) C_noret;
C_noret_decl(f_2031)
static void C_fcall f_2031(C_word t0,C_word t1) C_noret;
C_noret_decl(f_2137)
static void C_ccall f_2137(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2034)
static void C_ccall f_2034(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2051)
static void C_ccall f_2051(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2126)
static void C_ccall f_2126(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2122)
static void C_ccall f_2122(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2111)
static void C_ccall f_2111(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2097)
static void C_ccall f_2097(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2064)
static void C_ccall f_2064(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2075)
static void C_ccall f_2075(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2079)
static void C_ccall f_2079(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2071)
static void C_ccall f_2071(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2018)
static void C_ccall f_2018(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2025)
static void C_ccall f_2025(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1989)
static void C_ccall f_1989(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1993)
static void C_ccall f_1993(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_2747)
static void C_ccall f_2747(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1893)
static void C_fcall f_1893(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1943)
static void C_ccall f_1943(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1903)
static void C_fcall f_1903(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1909)
static void C_ccall f_1909(C_word c,C_word t0,C_word t1) C_noret;
C_noret_decl(f_1823)
static C_word C_fcall f_1823(C_word t0,C_word t1);
C_noret_decl(f_1733)
static void C_fcall f_1733(C_word t0,C_word t1) C_noret;
C_noret_decl(f_1741)
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2) C_noret;
C_noret_decl(f_1748)
static void C_ccall f_1748(C_word c,C_word t0,C_word t1) C_noret;

C_noret_decl(trf_4174)
static void C_fcall trf_4174(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4174(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_4174(t0,t1,t2,t3);}

C_noret_decl(trf_4317)
static void C_fcall trf_4317(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4317(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4317(t0,t1);}

C_noret_decl(trf_4885)
static void C_fcall trf_4885(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4885(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4885(t0,t1);}

C_noret_decl(trf_4999)
static void C_fcall trf_4999(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4999(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4999(t0,t1,t2);}

C_noret_decl(trf_1853)
static void C_fcall trf_1853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1853(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1853(t0,t1,t2);}

C_noret_decl(trf_1861)
static void C_fcall trf_1861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1861(t0,t1,t2);}

C_noret_decl(trf_1411)
static void C_fcall trf_1411(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1411(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1411(t0,t1,t2);}

C_noret_decl(trf_1419)
static void C_fcall trf_1419(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1419(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1419(t0,t1,t2);}

C_noret_decl(trf_1619)
static void C_fcall trf_1619(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1619(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1619(t0,t1,t2);}

C_noret_decl(trf_1646)
static void C_fcall trf_1646(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1646(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1646(t0,t1,t2);}

C_noret_decl(trf_1530)
static void C_fcall trf_1530(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1530(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1530(t0,t1,t2);}

C_noret_decl(trf_1557)
static void C_fcall trf_1557(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1557(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1557(t0,t1,t2);}

C_noret_decl(trf_1389)
static void C_fcall trf_1389(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1389(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1389(t0,t1,t2);}

C_noret_decl(trf_4199)
static void C_fcall trf_4199(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4199(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4199(t0,t1);}

C_noret_decl(trf_4250)
static void C_fcall trf_4250(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4250(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4250(t0,t1,t2);}

C_noret_decl(trf_3202)
static void C_fcall trf_3202(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3202(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3202(t0,t1,t2,t3);}

C_noret_decl(trf_3210)
static void C_fcall trf_3210(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3210(void *dummy){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
f_3210(t0,t1,t2,t3);}

C_noret_decl(trf_3525)
static void C_fcall trf_3525(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3525(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3525(t0,t1);}

C_noret_decl(trf_3230)
static void C_fcall trf_3230(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3230(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3230(t0,t1,t2);}

C_noret_decl(trf_3013)
static void C_fcall trf_3013(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3013(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3013(t0,t1);}

C_noret_decl(trf_3277)
static void C_fcall trf_3277(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3277(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3277(t0,t1);}

C_noret_decl(trf_3259)
static void C_fcall trf_3259(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3259(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3259(t0,t1);}

C_noret_decl(trf_3853)
static void C_fcall trf_3853(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3853(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3853(t0,t1,t2);}

C_noret_decl(trf_3861)
static void C_fcall trf_3861(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3861(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3861(t0,t1,t2);}

C_noret_decl(trf_3798)
static void C_fcall trf_3798(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3798(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3798(t0,t1,t2);}

C_noret_decl(trf_3754)
static void C_fcall trf_3754(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3754(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3754(t0,t1,t2);}

C_noret_decl(trf_3662)
static void C_fcall trf_3662(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3662(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_3662(t0,t1,t2);}

C_noret_decl(trf_4129)
static void C_fcall trf_4129(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4129(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4129(t0,t1);}

C_noret_decl(trf_4108)
static void C_fcall trf_4108(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4108(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4108(t0,t1,t2);}

C_noret_decl(trf_4086)
static void C_fcall trf_4086(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4086(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_4086(t0,t1);}

C_noret_decl(trf_3978)
static void C_fcall trf_3978(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3978(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_3978(t0,t1);}

C_noret_decl(trf_4029)
static void C_fcall trf_4029(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_4029(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_4029(t0,t1,t2);}

C_noret_decl(trf_3594)
static void C_fcall trf_3594(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_3594(void *dummy){
C_word t0=C_pick(0);
C_adjust_stack(-1);
f_3594(t0);}

C_noret_decl(trf_2486)
static void C_fcall trf_2486(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2486(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2486(t0,t1);}

C_noret_decl(trf_2760)
static void C_fcall trf_2760(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2760(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2760(t0,t1,t2);}

C_noret_decl(trf_1797)
static void C_fcall trf_1797(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1797(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1797(t0,t1);}

C_noret_decl(trf_1790)
static void C_fcall trf_1790(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1790(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1790(t0,t1);}

C_noret_decl(trf_2323)
static void C_fcall trf_2323(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2323(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2323(t0,t1);}

C_noret_decl(trf_2325)
static void C_fcall trf_2325(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2325(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2325(t0,t1,t2);}

C_noret_decl(trf_2344)
static void C_fcall trf_2344(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2344(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2344(t0,t1);}

C_noret_decl(trf_2213)
static void C_fcall trf_2213(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2213(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2213(t0,t1);}

C_noret_decl(trf_2225)
static void C_fcall trf_2225(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2225(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2225(t0,t1);}

C_noret_decl(trf_2237)
static void C_fcall trf_2237(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2237(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2237(t0,t1);}

C_noret_decl(trf_2501)
static void C_fcall trf_2501(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2501(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2501(t0,t1,t2);}

C_noret_decl(trf_2911)
static void C_fcall trf_2911(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2911(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2911(t0,t1);}

C_noret_decl(trf_2854)
static void C_fcall trf_2854(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2854(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2854(t0,t1);}

C_noret_decl(trf_2661)
static void C_fcall trf_2661(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2661(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2661(t0,t1,t2);}

C_noret_decl(trf_2671)
static void C_fcall trf_2671(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2671(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2671(t0,t1);}

C_noret_decl(trf_2416)
static void C_fcall trf_2416(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2416(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2416(t0,t1,t2);}

C_noret_decl(trf_2584)
static void C_fcall trf_2584(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2584(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_2584(t0,t1,t2);}

C_noret_decl(trf_1975)
static void C_fcall trf_1975(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1975(void *dummy){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
f_1975(t0,t1,t2,t3,t4);}

C_noret_decl(trf_2031)
static void C_fcall trf_2031(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_2031(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_2031(t0,t1);}

C_noret_decl(trf_1893)
static void C_fcall trf_1893(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1893(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1893(t0,t1);}

C_noret_decl(trf_1903)
static void C_fcall trf_1903(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1903(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1903(t0,t1);}

C_noret_decl(trf_1733)
static void C_fcall trf_1733(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1733(void *dummy){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
f_1733(t0,t1);}

C_noret_decl(trf_1741)
static void C_fcall trf_1741(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall trf_1741(void *dummy){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
f_1741(t0,t1,t2);}

C_noret_decl(tr5)
static void C_fcall tr5(C_proc5 k) C_regparm C_noret;
C_regparm static void C_fcall tr5(C_proc5 k){
C_word t4=C_pick(0);
C_word t3=C_pick(1);
C_word t2=C_pick(2);
C_word t1=C_pick(3);
C_word t0=C_pick(4);
C_adjust_stack(-5);
(k)(5,t0,t1,t2,t3,t4);}

C_noret_decl(tr4)
static void C_fcall tr4(C_proc4 k) C_regparm C_noret;
C_regparm static void C_fcall tr4(C_proc4 k){
C_word t3=C_pick(0);
C_word t2=C_pick(1);
C_word t1=C_pick(2);
C_word t0=C_pick(3);
C_adjust_stack(-4);
(k)(4,t0,t1,t2,t3);}

C_noret_decl(tr3)
static void C_fcall tr3(C_proc3 k) C_regparm C_noret;
C_regparm static void C_fcall tr3(C_proc3 k){
C_word t2=C_pick(0);
C_word t1=C_pick(1);
C_word t0=C_pick(2);
C_adjust_stack(-3);
(k)(3,t0,t1,t2);}

C_noret_decl(tr2)
static void C_fcall tr2(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2(C_proc2 k){
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
(k)(2,t0,t1);}

C_noret_decl(tr2r)
static void C_fcall tr2r(C_proc2 k) C_regparm C_noret;
C_regparm static void C_fcall tr2r(C_proc2 k){
int n;
C_word *a,t2;
C_word t1=C_pick(0);
C_word t0=C_pick(1);
C_adjust_stack(-2);
n=C_rest_count(0);
a=C_alloc(n*3);
t2=C_restore_rest(a,n);
(k)(t0,t1,t2);}

/* toplevel */
static C_TLS int toplevel_initialized=0;
C_main_entry_point
C_noret_decl(toplevel_trampoline)
static void C_fcall toplevel_trampoline(void *dummy) C_regparm C_noret;
C_regparm static void C_fcall toplevel_trampoline(void *dummy){
C_toplevel(2,C_SCHEME_UNDEFINED,C_restore);}

void C_ccall C_toplevel(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(toplevel_initialized) C_kontinue(t1,C_SCHEME_UNDEFINED);
else C_toplevel_entry(C_text("toplevel"));
C_resize_stack(131072);
C_check_nursery_minimum(3);
if(!C_demand(3)){
C_save(t1);
C_reclaim((void*)toplevel_trampoline,NULL);}
toplevel_initialized=1;
if(!C_demand_2(1484)){
C_save(t1);
C_rereclaim2(1484*sizeof(C_word), 1);
t1=C_restore;}
a=C_alloc(3);
C_initialize_lf(lf,355);
lf[1]=C_decode_literal(C_heaptop,"\376B\000\000\012modules.db");
lf[3]=C_decode_literal(C_heaptop,"\376B\000\000\016setup.defaults");
lf[15]=C_h_intern(&lf[15],4,"http");
lf[33]=C_h_intern(&lf[33],5,"print");
lf[34]=C_decode_literal(C_heaptop,"\376B\000\000\021resolving alias `");
lf[35]=C_decode_literal(C_heaptop,"\376B\000\000\006\047 to: ");
lf[38]=C_h_intern(&lf[38],7,"chicken");
lf[39]=C_h_intern(&lf[39],15,"chicken-version");
lf[40]=C_h_intern(&lf[40],7,"version");
lf[41]=C_h_intern(&lf[41],8,"->string");
lf[42]=C_decode_literal(C_heaptop,"\376B\000\000\0050.0.0");
lf[43]=C_h_intern(&lf[43],21,"extension-information");
lf[44]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[45]=C_h_intern(&lf[45],24,"\003syscore-library-modules");
lf[51]=C_h_intern(&lf[51],7,"reverse");
lf[52]=C_h_intern(&lf[52],10,"alist-cons");
lf[53]=C_decode_literal(C_heaptop,"\376B\000\000\007chicken");
lf[54]=C_h_intern(&lf[54],5,"error");
lf[55]=C_h_intern(&lf[55],13,"string-append");
lf[56]=C_decode_literal(C_heaptop,"\376B\000\000JYour CHICKEN version is not recent enough to use this extension - version ");
lf[57]=C_decode_literal(C_heaptop,"\376B\000\000\025 or newer is required");
lf[58]=C_h_intern(&lf[58],20,"setup-api#version>=\077");
lf[59]=C_h_intern(&lf[59],7,"warning");
lf[60]=C_decode_literal(C_heaptop,"\376B\000\0007invalid dependency syntax in extension meta information");
lf[61]=C_h_intern(&lf[61],7,"depends");
lf[62]=C_h_intern(&lf[62],5,"needs");
lf[63]=C_h_intern(&lf[63],12,"test-depends");
lf[64]=C_h_intern(&lf[64],6,"append");
lf[65]=C_h_intern(&lf[65],26,"setup-api#remove-extension");
lf[66]=C_decode_literal(C_heaptop,"\376B\000\000)removing previously installed extension `");
lf[67]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[68]=C_decode_literal(C_heaptop,"\376B\000\000\012 upgrade: ");
lf[69]=C_h_intern(&lf[69],18,"string-intersperse");
lf[70]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[71]=C_h_intern(&lf[71],6,"unzip1");
lf[72]=C_h_intern(&lf[72],10,"yes-or-no\077");
lf[73]=C_decode_literal(C_heaptop,"\376B\000\000\002no");
lf[74]=C_h_intern(&lf[74],6,"\000abort");
lf[75]=C_h_intern(&lf[75],21,"setup-api#abort-setup");
lf[76]=C_h_intern(&lf[76],18,"string-concatenate");
lf[77]=C_decode_literal(C_heaptop,"\376B\000\000:The following installed extensions are outdated, because `");
lf[78]=C_decode_literal(C_heaptop,"\376B\000\000\033\047 requires later versions:\012");
lf[79]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\0000\012Do you want to replace the existing extensions\077\376\377\016");
lf[80]=C_decode_literal(C_heaptop,"\376B\000\000\003\077\077\077");
lf[81]=C_h_intern(&lf[81],4,"conc");
lf[82]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[83]=C_decode_literal(C_heaptop,"\376B\000\000\002 (");
lf[84]=C_decode_literal(C_heaptop,"\376B\000\000\004 -> ");
lf[85]=C_decode_literal(C_heaptop,"\376B\000\000\001)");
lf[86]=C_decode_literal(C_heaptop,"\376B\000\000\012 missing: ");
lf[87]=C_decode_literal(C_heaptop,"\376B\000\000\002, ");
lf[89]=C_decode_literal(C_heaptop,"\376B\000\000\033checking dependencies for `");
lf[90]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[91]=C_decode_literal(C_heaptop,"\376B\000\000)extension is not targeted for this system");
lf[92]=C_h_intern(&lf[92],8,"platform");
lf[93]=C_h_intern(&lf[93],8,"feature\077");
lf[94]=C_h_intern(&lf[94],3,"and");
lf[95]=C_h_intern(&lf[95],5,"every");
lf[96]=C_h_intern(&lf[96],2,"or");
lf[97]=C_h_intern(&lf[97],3,"any");
lf[98]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[99]=C_h_intern(&lf[99],3,"not");
lf[100]=C_decode_literal(C_heaptop,"\376B\000\000\033invalid `platform\047 property");
lf[101]=C_decode_literal(C_heaptop,"\376B\000\000\027checking platform for `");
lf[102]=C_decode_literal(C_heaptop,"\376B\000\000\005\047 ...");
lf[103]=C_h_intern(&lf[103],20,"with-input-from-file");
lf[104]=C_h_intern(&lf[104],4,"read");
lf[105]=C_decode_literal(C_heaptop,"\376B\000\000\013extension `");
lf[106]=C_decode_literal(C_heaptop,"\376B\000\000\024\047 has no .meta file ");
lf[107]=C_decode_literal(C_heaptop,"\376B\000\000!- assuming it has no dependencies");
lf[108]=C_h_intern(&lf[108],12,"file-exists\077");
lf[109]=C_h_intern(&lf[109],13,"make-pathname");
lf[110]=C_decode_literal(C_heaptop,"\376B\000\000\004meta");
lf[111]=C_h_intern(&lf[111],6,"delete");
lf[112]=C_h_intern(&lf[112],3,"eq\077");
lf[113]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[114]=C_h_intern(&lf[114],9,"condition");
lf[115]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[116]=C_decode_literal(C_heaptop,"\376B\000\000\023TCP connect timeout");
lf[117]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[118]=C_decode_literal(C_heaptop,"\376B\000\000\023HTTP protocol error");
lf[119]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[120]=C_h_intern(&lf[120],19,"print-error-message");
lf[121]=C_decode_literal(C_heaptop,"\376B\000\000\015Server error:");
lf[122]=C_h_intern(&lf[122],5,"abort");
lf[123]=C_h_intern(&lf[123],3,"exn");
lf[124]=C_h_intern(&lf[124],20,"setup-download-error");
lf[125]=C_h_intern(&lf[125],10,"http-fetch");
lf[126]=C_h_intern(&lf[126],3,"net");
lf[127]=C_h_intern(&lf[127],33,"setup-download#retrieve-extension");
lf[128]=C_h_intern(&lf[128],8,"\000version");
lf[129]=C_h_intern(&lf[129],12,"\000destination");
lf[130]=C_h_intern(&lf[130],6,"\000tests");
lf[131]=C_h_intern(&lf[131],9,"\000username");
lf[132]=C_h_intern(&lf[132],9,"\000password");
lf[133]=C_h_intern(&lf[133],6,"\000trunk");
lf[134]=C_h_intern(&lf[134],11,"\000proxy-host");
lf[135]=C_h_intern(&lf[135],11,"\000proxy-port");
lf[136]=C_h_intern(&lf[136],17,"current-directory");
lf[137]=C_h_intern(&lf[137],22,"with-exception-handler");
lf[138]=C_h_intern(&lf[138],30,"call-with-current-continuation");
lf[139]=C_h_intern(&lf[139],9,"transport");
lf[140]=C_decode_literal(C_heaptop,"\376B\000\000\027missing transport entry");
lf[141]=C_h_intern(&lf[141],8,"location");
lf[142]=C_decode_literal(C_heaptop,"\376B\000\000\026missing location entry");
lf[143]=C_h_intern(&lf[143],5,"local");
lf[144]=C_h_intern(&lf[144],18,"absolute-pathname\077");
lf[145]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[146]=C_decode_literal(C_heaptop,"\376B\000\000\014 located at ");
lf[147]=C_decode_literal(C_heaptop,"\376B\000\000\036extension or version not found");
lf[148]=C_decode_literal(C_heaptop,"\376B\000\000\016retrieving ...");
lf[150]=C_h_intern(&lf[150],26,"setup-api#remove-directory");
lf[151]=C_h_intern(&lf[151],34,"setup-download#temporary-directory");
lf[152]=C_decode_literal(C_heaptop,"\376B\000\000\007mapped ");
lf[153]=C_decode_literal(C_heaptop,"\376B\000\000\004 to ");
lf[154]=C_h_intern(&lf[154],5,"lset=");
lf[155]=C_h_intern(&lf[155],17,"delete-duplicates");
lf[156]=C_h_intern(&lf[156],8,"string=\077");
lf[157]=C_h_intern(&lf[157],4,"find");
lf[158]=C_h_intern(&lf[158],10,"append-map");
lf[160]=C_decode_literal(C_heaptop,"\376B\000\000/shell command terminated with nonzero exit code");
lf[161]=C_h_intern(&lf[161],6,"system");
lf[162]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[163]=C_decode_literal(C_heaptop,"\376B\000\000\001\042");
lf[165]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[166]=C_h_intern(&lf[166],7,"sprintf");
lf[168]=C_h_intern(&lf[168],12,"string-match");
lf[169]=C_decode_literal(C_heaptop,"\376B\000\000\016(.+)\134:([0-9]+)");
lf[170]=C_h_intern(&lf[170],25,"\003sysimplicit-exit-handler");
lf[171]=C_h_intern(&lf[171],4,"exit");
lf[172]=C_h_intern(&lf[172],18,"current-error-port");
lf[173]=C_h_intern(&lf[173],7,"newline");
lf[174]=C_decode_literal(C_heaptop,"\376B\000\000B`-deploy\047 only makes sense in combination with `-prefix DIRECTORY`");
lf[175]=C_h_intern(&lf[175],19,"setup-api#copy-file");
lf[176]=C_h_intern(&lf[176],15,"repository-path");
lf[177]=C_h_intern(&lf[177],5,"write");
lf[178]=C_h_intern(&lf[178],19,"with-output-to-file");
lf[179]=C_h_intern(&lf[179],8,"string<\077");
lf[180]=C_h_intern(&lf[180],14,"symbol->string");
lf[181]=C_h_intern(&lf[181],4,"sort");
lf[182]=C_h_intern(&lf[182],18,"\003sysmodule-exports");
lf[183]=C_h_intern(&lf[183],5,"value");
lf[184]=C_h_intern(&lf[184],6,"syntax");
lf[185]=C_h_intern(&lf[185],6,"print*");
lf[186]=C_decode_literal(C_heaptop,"\376B\000\000\001 ");
lf[187]=C_h_intern(&lf[187],15,"\003sysmodule-name");
lf[188]=C_h_intern(&lf[188],16,"\003sysmodule-table");
lf[189]=C_decode_literal(C_heaptop,"\376B\000\000\023generating database");
lf[190]=C_h_intern(&lf[190],20,"\003syswarnings-enabled");
lf[191]=C_h_intern(&lf[191],17,"get-output-string");
lf[192]=C_h_intern(&lf[192],19,"\003syswrite-char/port");
lf[193]=C_h_intern(&lf[193],7,"display");
lf[194]=C_decode_literal(C_heaptop,"\376B\000\000\027Failed to import from `");
lf[195]=C_h_intern(&lf[195],18,"open-output-string");
lf[196]=C_h_intern(&lf[196],6,"import");
lf[197]=C_h_intern(&lf[197],4,"eval");
lf[198]=C_h_intern(&lf[198],14,"string->symbol");
lf[199]=C_h_intern(&lf[199],16,"\003sysdynamic-wind");
lf[200]=C_decode_literal(C_heaptop,"\376B\000\000\034loading import libraries ...");
lf[201]=C_h_intern(&lf[201],6,"regexp");
lf[202]=C_decode_literal(C_heaptop,"\376B\000\000\034.*/([^/]+)\134.import\134.(scm|so)");
lf[203]=C_h_intern(&lf[203],26,"create-temporary-directory");
lf[204]=C_h_intern(&lf[204],4,"glob");
lf[205]=C_decode_literal(C_heaptop,"\376B\000\000\012*.import.*");
lf[206]=C_decode_literal(C_heaptop,"\376B\000\000\023~a -s run.scm ~a ~a");
lf[207]=C_decode_literal(C_heaptop,"\376B\000\000$\012nevertheless trying to continue ...");
lf[208]=C_decode_literal(C_heaptop,"\376B\000\000\007testing");
lf[209]=C_decode_literal(C_heaptop,"\376B\000\000\014 extension `");
lf[210]=C_decode_literal(C_heaptop,"\376B\000\000\011\047 failed:");
lf[211]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[212]=C_decode_literal(C_heaptop,"\376B\000\000\015tests/run.scm");
lf[213]=C_h_intern(&lf[213],10,"directory\077");
lf[214]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[215]=C_decode_literal(C_heaptop,"\376B\000\000\005tests");
lf[216]=C_decode_literal(C_heaptop,"\376B\000\000\012installing");
lf[217]=C_decode_literal(C_heaptop,"\376B\000\000\002  ");
lf[218]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[219]=C_decode_literal(C_heaptop,"\376B\000\000\034-e \042(setup-error-handling)\042 ");
lf[220]=C_decode_literal(C_heaptop,"\376B\000\000\027 -e \042(sudo-install #t)\042");
lf[221]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[222]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(keep-intermediates #t)\042");
lf[223]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[224]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[225]=C_decode_literal(C_heaptop,"\376B\000\000\035 -e \042(setup-install-mode #f)\042");
lf[226]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(host-extension #t)\042");
lf[227]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[228]=C_decode_literal(C_heaptop,"\376B\000\000\032 -e \042(deployment-mode #t)\042");
lf[229]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[230]=C_decode_literal(C_heaptop,"\376B\000\000\006 -bnq ");
lf[231]=C_decode_literal(C_heaptop,"\376B\000\0009-e \042(require-library setup-api)\042 -e \042(import setup-api)\042 ");
lf[232]=C_h_intern(&lf[232],19,"setup-api#shellpath");
lf[233]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[234]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[235]=C_decode_literal(C_heaptop,"\376B\000\000\031 -e \042(extra-nonfeatures \047");
lf[236]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[237]=C_decode_literal(C_heaptop,"\376B\000\000\002)\042");
lf[238]=C_decode_literal(C_heaptop,"\376B\000\000\026 -e \042(extra-features \047");
lf[239]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[240]=C_decode_literal(C_heaptop,"\376B\000\000\004\134\042)\042");
lf[241]=C_h_intern(&lf[241],18,"normalize-pathname");
lf[242]=C_h_intern(&lf[242],4,"unix");
lf[243]=C_decode_literal(C_heaptop,"\376B\000\000\033 -e \042(destination-prefix \134\042");
lf[244]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[245]=C_h_intern(&lf[245],17,"\003syspeek-c-string");
lf[246]=C_h_intern(&lf[246],22,"setup-api#sudo-install");
lf[247]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042))\042");
lf[248]=C_decode_literal(C_heaptop,"\376B\000\000\005\134\042 \134\042");
lf[249]=C_decode_literal(C_heaptop,"\376B\000\000$-e \042(extension-name-and-version \047(\134\042");
lf[250]=C_decode_literal(C_heaptop,"\376B\000\000\014-setup-mode ");
lf[251]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[252]=C_decode_literal(C_heaptop,"\376B\000\000\036changing current directory to ");
lf[253]=C_decode_literal(C_heaptop,"\376B\000\000\031installing for target ...");
lf[254]=C_decode_literal(C_heaptop,"\376B\000\000\005xcopy");
lf[255]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[256]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[257]=C_decode_literal(C_heaptop,"\376B\000\000\001*");
lf[258]=C_decode_literal(C_heaptop,"\376B\000\000\047copying sources for target installation");
lf[259]=C_decode_literal(C_heaptop,"\376B\000\000\013installing ");
lf[260]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[261]=C_decode_literal(C_heaptop,"\376B\000\000\026aborting installation.");
lf[262]=C_decode_literal(C_heaptop,"\376B\000\000\203You specified `-no-install\047, but this extension has dependencies that are r"
"equired for building.\012Do you still want to install them\077");
lf[263]=C_h_intern(&lf[263],4,"iota");
lf[264]=C_h_intern(&lf[264],5,"assoc");
lf[265]=C_h_intern(&lf[265],7,"\003sysmap");
lf[266]=C_h_intern(&lf[266],2,"pp");
lf[267]=C_decode_literal(C_heaptop,"\376B\000\000\016install order:");
lf[268]=C_h_intern(&lf[268],16,"topological-sort");
lf[269]=C_decode_literal(C_heaptop,"\376B\000\000;no default location defined - please use `-location\047 option");
lf[270]=C_decode_literal(C_heaptop,"\376B\000\000=no default transport defined - please use `-transport\047 option");
lf[271]=C_decode_literal(C_heaptop,"\376B\000\000\001.");
lf[272]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[273]=C_h_intern(&lf[273],13,"pathname-file");
lf[274]=C_decode_literal(C_heaptop,"\376B\000\000\033no setup-scripts to process");
lf[275]=C_decode_literal(C_heaptop,"\376B\000\000\007*.setup");
lf[276]=C_decode_literal(C_heaptop,"\376B\000\000\036invalid entry in defaults file");
lf[277]=C_decode_literal(C_heaptop,"\376B\000\000$\047 does not match setup-API version (");
lf[278]=C_decode_literal(C_heaptop,"\376B\000\000\026version of installed `");
lf[279]=C_h_intern(&lf[279],6,"server");
lf[280]=C_h_intern(&lf[280],3,"map");
lf[281]=C_h_intern(&lf[281],8,"split-at");
lf[282]=C_h_intern(&lf[282],2,"->");
lf[283]=C_h_intern(&lf[283],10,"list-index");
lf[284]=C_h_intern(&lf[284],5,"alias");
lf[285]=C_h_intern(&lf[285],7,"string\077");
lf[286]=C_h_intern(&lf[286],9,"read-file");
lf[287]=C_h_intern(&lf[287],12,"chicken-home");
lf[288]=C_decode_literal(C_heaptop,"\376B\000\000\005-help");
lf[289]=C_decode_literal(C_heaptop,"\376B\000\007\002usage: chicken-install [OPTION | EXTENSION[:VERSION]] ...\012\012  -h   -help    "
"                show this message and exit\012  -v   -version                 show "
"version and exit\012       -force                   don\047t ask, install even if vers"
"ions don\047t match\012  -k   -keep                    keep temporary files\012  -l   -lo"
"cation LOCATION       install from given location instead of default\012  -t   -tra"
"nsport TRANSPORT     use given transport instead of default\012       -proxy HOST[:"
"PORT]       download via HTTP proxy\012  -s   -sudo                    use sudo(1) "
"for filesystem operations\012  -r   -retrieve                only retrieve egg into"
" current directory, don\047t install\012  -n   -no-install              do not install"
", just build (implies `-keep\047)\012  -p   -prefix PREFIX           change installati"
"on prefix to PREFIX\012       -host                    when cross-compiling, compil"
"e extension only for host\012       -target                  when cross-compiling, "
"compile extension only for target\012       -test                    run included t"
"est-cases, if available\012       -username USER           set username for transpo"
"rts that require this\012       -password PASS           set password for transport"
"s that require this\012  -i   -init DIRECTORY          initialize empty alternative"
" repository\012  -u   -update-db               update export database\012       -repos"
"itory              print path used for egg installation\012       -deploy          "
"        build extensions for deployment\012       -trunk                   build tr"
"unk instead of tagged version (only local)\012  -D   -feature FEATURE         featu"
"res to pass to sub-invocations of `csc\047\012       -debug                   enable f"
"ull display of error message information\012       -keep-going              continu"
"e installation even if dependency fails");
lf[290]=C_decode_literal(C_heaptop,"\376B\000\000\013-repository");
lf[291]=C_decode_literal(C_heaptop,"\376B\000\000\006-force");
lf[292]=C_decode_literal(C_heaptop,"\376B\000\000\002-k");
lf[293]=C_decode_literal(C_heaptop,"\376B\000\000\005-keep");
lf[294]=C_decode_literal(C_heaptop,"\376B\000\000\002-s");
lf[295]=C_decode_literal(C_heaptop,"\376B\000\000\005-sudo");
lf[296]=C_decode_literal(C_heaptop,"\376B\000\000\002-r");
lf[297]=C_decode_literal(C_heaptop,"\376B\000\000\011-retrieve");
lf[298]=C_decode_literal(C_heaptop,"\376B\000\000\002-l");
lf[299]=C_decode_literal(C_heaptop,"\376B\000\000\011-location");
lf[300]=C_decode_literal(C_heaptop,"\376B\000\000\002-t");
lf[301]=C_decode_literal(C_heaptop,"\376B\000\000\012-transport");
lf[302]=C_decode_literal(C_heaptop,"\376B\000\000\002-p");
lf[303]=C_decode_literal(C_heaptop,"\376B\000\000\007-prefix");
lf[304]=C_decode_literal(C_heaptop,"\376B\000\000\002-n");
lf[305]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-install");
lf[306]=C_decode_literal(C_heaptop,"\376B\000\000\002-v");
lf[307]=C_decode_literal(C_heaptop,"\376B\000\000\010-version");
lf[308]=C_decode_literal(C_heaptop,"\376B\000\000\002-u");
lf[309]=C_decode_literal(C_heaptop,"\376B\000\000\012-update-db");
lf[310]=C_decode_literal(C_heaptop,"\376B\000\000\002-i");
lf[311]=C_decode_literal(C_heaptop,"\376B\000\000\005-init");
lf[312]=C_decode_literal(C_heaptop,"\376B\000\000\004copy");
lf[313]=C_decode_literal(C_heaptop,"\376B\000\000\005cp -r");
lf[314]=C_decode_literal(C_heaptop,"\376B\000\000\010~a ~a ~a");
lf[315]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376B\000\000\014setup-api.so\376\003\000\000\002\376B\000\000\023setup-api.import.so\376\003\000\000\002\376B\000\000\021setup-download.so\376\003"
"\000\000\002\376B\000\000\030setup-download.import.so\376\003\000\000\002\376B\000\000\021chicken.import.so\376\003\000\000\002\376B\000\000\021lolevel.imp"
"ort.so\376\003\000\000\002\376B\000\000\020srfi-1.import.so\376\003\000\000\002\376B\000\000\020srfi-4.import.so\376\003\000\000\002\376B\000\000\031data-structu"
"res.import.so\376\003\000\000\002\376B\000\000\017ports.import.so\376\003\000\000\002\376B\000\000\017files.import.so\376\003\000\000\002\376B\000\000\017posix.i"
"mport.so\376\003\000\000\002\376B\000\000\021srfi-13.import.so\376\003\000\000\002\376B\000\000\021srfi-69.import.so\376\003\000\000\002\376B\000\000\020extras.i"
"mport.so\376\003\000\000\002\376B\000\000\017regex.import.so\376\003\000\000\002\376B\000\000\021srfi-14.import.so\376\003\000\000\002\376B\000\000\015tcp.import"
".so\376\003\000\000\002\376B\000\000\021foreign.import.so\376\003\000\000\002\376B\000\000\020scheme.import.so\376\003\000\000\002\376B\000\000\021srfi-18.import"
".so\376\003\000\000\002\376B\000\000\017utils.import.so\376\003\000\000\002\376B\000\000\015csi.import.so\376\003\000\000\002\376B\000\000\021irregex.import.so\376\003"
"\000\000\002\376B\000\000\010types.db\376\377\016");
lf[316]=C_decode_literal(C_heaptop,"\376B\000\000\032copying required files to ");
lf[317]=C_decode_literal(C_heaptop,"\376B\000\000\004 ...");
lf[318]=C_decode_literal(C_heaptop,"\376B\000\000\006-proxy");
lf[319]=C_decode_literal(C_heaptop,"\376B\000\000\002-D");
lf[320]=C_decode_literal(C_heaptop,"\376B\000\000\010-feature");
lf[321]=C_decode_literal(C_heaptop,"\376B\000\000\013-no-feature");
lf[322]=C_decode_literal(C_heaptop,"\376B\000\000\005-test");
lf[323]=C_decode_literal(C_heaptop,"\376B\000\000\005-host");
lf[324]=C_decode_literal(C_heaptop,"\376B\000\000\007-target");
lf[325]=C_decode_literal(C_heaptop,"\376B\000\000\006-debug");
lf[326]=C_decode_literal(C_heaptop,"\376B\000\000\007-deploy");
lf[327]=C_decode_literal(C_heaptop,"\376B\000\000\011-username");
lf[328]=C_decode_literal(C_heaptop,"\376B\000\000\006-trunk");
lf[329]=C_decode_literal(C_heaptop,"\376B\000\000\013-keep-going");
lf[330]=C_decode_literal(C_heaptop,"\376B\000\000\011-password");
lf[331]=C_h_intern(&lf[331],6,"string");
lf[332]=C_h_intern(&lf[332],4,"memq");
lf[333]=C_decode_literal(C_heaptop,"\376\003\000\000\002\376\377\012\000\000h\376\003\000\000\002\376\377\012\000\000k\376\003\000\000\002\376\377\012\000\000l\376\003\000\000\002\376\377\012\000\000t\376\003\000\000\002\376\377\012\000\000s\376\003\000\000\002\376\377\012\000\000p\376\003\000\000\002\376\377\012\000\000r\376\003\000"
"\000\002\376\377\012\000\000n\376\003\000\000\002\376\377\012\000\000v\376\003\000\000\002\376\377\012\000\000i\376\003\000\000\002\376\377\012\000\000u\376\003\000\000\002\376\377\012\000\000D\376\377\016");
lf[334]=C_h_intern(&lf[334],16,"\003sysstring->list");
lf[335]=C_h_intern(&lf[335],9,"substring");
lf[336]=C_decode_literal(C_heaptop,"\376B\000\000\005setup");
lf[337]=C_decode_literal(C_heaptop,"\376B\000\000\000");
lf[338]=C_h_intern(&lf[338],18,"pathname-directory");
lf[339]=C_h_intern(&lf[339],18,"pathname-extension");
lf[340]=C_decode_literal(C_heaptop,"\376B\000\000\002-h");
lf[341]=C_decode_literal(C_heaptop,"\376B\000\000\006--help");
lf[342]=C_h_intern(&lf[342],24,"get-environment-variable");
lf[343]=C_decode_literal(C_heaptop,"\376B\000\000\012http_proxy");
lf[344]=C_decode_literal(C_heaptop,"\376B\000\000\014([^:]+):(.+)");
lf[345]=C_h_intern(&lf[345],22,"command-line-arguments");
lf[346]=C_h_intern(&lf[346],17,"register-feature!");
lf[347]=C_h_intern(&lf[347],15,"chicken-install");
lf[348]=C_h_intern(&lf[348],14,"\000cross-chicken");
lf[349]=C_decode_literal(C_heaptop,"\376B\000\000\003bin");
lf[350]=C_decode_literal(C_heaptop,"\376B\000\000\016CHICKEN_PREFIX");
lf[351]=C_h_intern(&lf[351],11,"\003sysrequire");
lf[352]=C_h_intern(&lf[352],18,"chicken-ffi-syntax");
lf[353]=C_h_intern(&lf[353],9,"setup-api");
lf[354]=C_h_intern(&lf[354],14,"setup-download");
C_register_lf2(lf,355,create_ptable());
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1279,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_library_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1277 */
static void C_ccall f_1279(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1279,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1282,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_eval_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1280 in k1277 */
static void C_ccall f_1282(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1282,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1285,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_1_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1283 in k1280 in k1277 */
static void C_ccall f_1285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1285,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_posix_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1288,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1291,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_data_structures_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1291(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1291,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1294,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_utils_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1294(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1294,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1297,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_regex_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1297(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1297,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1300,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_ports_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1300(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1300,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_extras_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1303(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1303,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1306,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_srfi_13_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1306(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1306,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1309,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_files_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1312,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
C_chicken_syntax_toplevel(2,C_SCHEME_UNDEFINED,t2);}

/* k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1312(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1312,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1315,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,lf[354]);}

/* k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1315(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1315,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1318,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,lf[353]);}

/* k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1318(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1318,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1321,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#require */
((C_proc3)C_retrieve_symbol_proc(lf[351]))(3,*((C_word*)lf[351]+1),t2,lf[352]);}

/* k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1321,2,t0,t1);}
t2=C_mutate(&lf[0] /* (set! main#constant161 ...) */,lf[1]);
t3=C_mutate(&lf[2] /* (set! main#constant164 ...) */,lf[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1328,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),t4,lf[350]);}

/* k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1328(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1328,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1331,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,t1,lf[349]);}
else{
t3=t2;
f_1331(2,t3,C_SCHEME_FALSE);}}

/* k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1331(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1331,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1334,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(t1)){
t3=t2;
f_1334(2,t3,t1);}
else{
/* ##sys#peek-c-string */
t3=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_mpointer(&a,(void*)C_INSTALL_BIN_HOME),C_fix(0));}}

/* k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1334(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1334,2,t0,t1);}
t2=C_mutate(&lf[4] /* (set! main#*program-path* ...) */,t1);
t3=lf[5] /* main#*keep* */ =C_SCHEME_FALSE;;
t4=lf[6] /* main#*force* */ =C_SCHEME_FALSE;;
t5=lf[7] /* main#*run-tests* */ =C_SCHEME_FALSE;;
t6=lf[8] /* main#*retrieve-only* */ =C_SCHEME_FALSE;;
t7=lf[9] /* main#*no-install* */ =C_SCHEME_FALSE;;
t8=lf[10] /* main#*username* */ =C_SCHEME_FALSE;;
t9=lf[11] /* main#*password* */ =C_SCHEME_FALSE;;
t10=lf[12] /* main#*default-sources* */ =C_SCHEME_END_OF_LIST;;
t11=lf[13] /* main#*default-location* */ =C_SCHEME_FALSE;;
t12=C_mutate(&lf[14] /* (set! main#*default-transport* ...) */,lf[15]);
t13=C_mutate(&lf[16] /* (set! main#*windows-shell* ...) */,C_mk_bool(C_WINDOWS_SHELL));
t14=lf[17] /* main#*proxy-host* */ =C_SCHEME_FALSE;;
t15=lf[18] /* main#*proxy-port* */ =C_SCHEME_FALSE;;
t16=lf[19] /* main#*running-test* */ =C_SCHEME_FALSE;;
t17=lf[20] /* main#*mappings* */ =C_SCHEME_END_OF_LIST;;
t18=lf[21] /* main#*deploy* */ =C_SCHEME_FALSE;;
t19=lf[22] /* main#*trunk* */ =C_SCHEME_FALSE;;
t20=lf[23] /* main#*csc-features* */ =C_SCHEME_END_OF_LIST;;
t21=lf[24] /* main#*csc-nonfeatures* */ =C_SCHEME_END_OF_LIST;;
t22=lf[25] /* main#*prefix* */ =C_SCHEME_FALSE;;
t23=lf[26] /* main#*aliases* */ =C_SCHEME_END_OF_LIST;;
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1359,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* feature? */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t24,lf[348]);}

/* k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1359(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1359,2,t0,t1);}
t2=C_mutate(&lf[27] /* (set! main#*cross-chicken* ...) */,t1);
t3=C_mutate(&lf[28] /* (set! main#*host-extension* ...) */,C_retrieve2(lf[27],"main#*cross-chicken*"));
t4=C_mutate(&lf[29] /* (set! main#*target-extension* ...) */,C_retrieve2(lf[27],"main#*cross-chicken*"));
t5=lf[30] /* main#*debug-setup* */ =C_SCHEME_FALSE;;
t6=lf[31] /* main#*keep-going* */ =C_SCHEME_FALSE;;
t7=C_mutate(&lf[32] /* (set! main#resolve-location ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1733,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[36] /* (set! main#deps ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1823,tmp=(C_word)a,a+=2,tmp));
t9=C_mutate(&lf[37] /* (set! main#ext-version ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1893,tmp=(C_word)a,a+=2,tmp));
t10=lf[46] /* main#*eggs+dirs+vers* */ =C_SCHEME_END_OF_LIST;;
t11=lf[47] /* main#*dependencies* */ =C_SCHEME_END_OF_LIST;;
t12=lf[48] /* main#*checked* */ =C_SCHEME_END_OF_LIST;;
t13=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5186,a[2]=t13,tmp=(C_word)a,a+=3,tmp);
t15=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5190,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* ##sys#peek-c-string */
t16=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t16+1)))(4,t16,t15,C_mpointer(&a,(void*)C_CSI_PROGRAM),C_fix(0));}

/* k5188 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5190(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],C_retrieve2(lf[4],"main#*program-path*"),t1);}

/* k5184 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),((C_word*)t0)[2],t1);}

/* k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2180,2,t0,t1);}
t2=C_mutate(&lf[49] /* (set! main#*csi* ...) */,t1);
t3=C_mutate(&lf[50] /* (set! main#retrieve ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_2486,tmp=(C_word)a,a+=2,tmp));
t4=C_mutate(&lf[149] /* (set! main#cleanup ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3594,tmp=(C_word)a,a+=2,tmp));
t5=C_mutate(&lf[88] /* (set! main#apply-mappings ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3978,tmp=(C_word)a,a+=2,tmp));
t6=C_mutate(&lf[159] /* (set! main#$system ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4086,tmp=(C_word)a,a+=2,tmp));
t7=C_mutate(&lf[164] /* (set! main#command ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4108,tmp=(C_word)a,a+=2,tmp));
t8=C_mutate(&lf[167] /* (set! main#setup-proxy ...) */,(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4129,tmp=(C_word)a,a+=2,tmp));
t9=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5100,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* register-feature! */
((C_proc3)C_retrieve_symbol_proc(lf[346]))(3,*((C_word*)lf[346]+1),t9,lf[347]);}

/* k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5100(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5100,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5103,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5114,tmp=(C_word)a,a+=2,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[138]+1)))(3,*((C_word*)lf[138]+1),t2,t3);}

/* a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5114(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5114,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5120,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5153,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5153(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5153,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_5159,tmp=(C_word)a,a+=2,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5172,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a5171 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5172(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_5172r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_5172r(t0,t1,t2);}}

static void C_ccall f_5172r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5178,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k11861190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5177 in a5171 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5178(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5178,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5159(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5159,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5163,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5170,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* command-line-arguments */
((C_proc2)C_retrieve_symbol_proc(lf[345]))(2,*((C_word*)lf[345]+1),t3);}

/* k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5170(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5170,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4166,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* regexp */
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t4,lf[344]);}

/* k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4166(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4166,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4169,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5097,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* get-environment-variable */
((C_proc3)C_retrieve_symbol_proc(lf[342]))(3,*((C_word*)lf[342]+1),t3,lf[343]);}

/* k5095 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#setup-proxy */
f_4129(((C_word*)t0)[2],t1);}

/* k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4169(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4169,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4174,a[2]=((C_word*)t0)[4],a[3]=t3,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_4174(t5,((C_word*)t0)[3],((C_word*)t0)[2],C_SCHEME_END_OF_LIST);}

/* loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4174(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4174,NULL,4,t0,t1,t2,t3);}
if(C_truep(C_i_nullp(t2))){
t4=(C_truep(C_retrieve2(lf[21],"main#*deploy*"))?C_i_not(C_retrieve2(lf[25],"main#*prefix*")):C_SCHEME_FALSE);
if(C_truep(t4)){
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t1,lf[174]);}
else{
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t5=t1;
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3613,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3972,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3976,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t8);}
else{
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4199,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1387,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1731,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* chicken-home */
((C_proc2)C_retrieve_symbol_proc(lf[287]))(2,*((C_word*)lf[287]+1),t7);}}}
else{
t4=C_i_car(t2);
t5=C_i_string_equal_p(t4,lf[288]);
t6=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_4317,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[4],a[4]=t3,a[5]=((C_word*)t0)[3],a[6]=t2,a[7]=t4,a[8]=t1,tmp=(C_word)a,a+=9,tmp);
if(C_truep(t5)){
t7=t6;
f_4317(t7,t5);}
else{
t7=C_i_string_equal_p(t4,lf[340]);
t8=t6;
f_4317(t8,(C_truep(t7)?t7:C_i_string_equal_p(t4,lf[341])));}}}

/* k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4317(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word t35;
C_word t36;
C_word t37;
C_word t38;
C_word t39;
C_word t40;
C_word t41;
C_word t42;
C_word t43;
C_word t44;
C_word t45;
C_word t46;
C_word t47;
C_word t48;
C_word t49;
C_word t50;
C_word t51;
C_word t52;
C_word t53;
C_word t54;
C_word t55;
C_word t56;
C_word t57;
C_word t58;
C_word t59;
C_word t60;
C_word t61;
C_word t62;
C_word t63;
C_word t64;
C_word t65;
C_word t66;
C_word t67;
C_word t68;
C_word t69;
C_word t70;
C_word t71;
C_word t72;
C_word t73;
C_word t74;
C_word t75;
C_word t76;
C_word t77;
C_word t78;
C_word t79;
C_word t80;
C_word t81;
C_word t82;
C_word t83;
C_word t84;
C_word t85;
C_word t86;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4317,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[8];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5544,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[289]);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[290]))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4329,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4336,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t3);}
else{
if(C_truep(C_i_string_equal_p(((C_word*)t0)[7],lf[291]))){
t2=lf[6] /* main#*force* */ =C_SCHEME_TRUE;;
t3=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4174(t4,((C_word*)t0)[8],t3,((C_word*)t0)[4]);}
else{
t2=C_i_string_equal_p(((C_word*)t0)[7],lf[292]);
t3=(C_truep(t2)?t2:C_i_string_equal_p(((C_word*)t0)[7],lf[293]));
if(C_truep(t3)){
t4=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t5=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t6=((C_word*)((C_word*)t0)[5])[1];
f_4174(t6,((C_word*)t0)[8],t5,((C_word*)t0)[4]);}
else{
t4=C_i_string_equal_p(((C_word*)t0)[7],lf[294]);
t5=(C_truep(t4)?t4:C_i_string_equal_p(((C_word*)t0)[7],lf[295]));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4379,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* setup-api#sudo-install */
((C_proc3)C_retrieve_symbol_proc(lf[246]))(3,*((C_word*)lf[246]+1),t6,C_SCHEME_TRUE);}
else{
t6=C_i_string_equal_p(((C_word*)t0)[7],lf[296]);
t7=(C_truep(t6)?t6:C_i_string_equal_p(((C_word*)t0)[7],lf[297]));
if(C_truep(t7)){
t8=lf[8] /* main#*retrieve-only* */ =C_SCHEME_TRUE;;
t9=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t10=((C_word*)((C_word*)t0)[5])[1];
f_4174(t10,((C_word*)t0)[8],t9,((C_word*)t0)[4]);}
else{
t8=C_i_string_equal_p(((C_word*)t0)[7],lf[298]);
t9=(C_truep(t8)?t8:C_i_string_equal_p(((C_word*)t0)[7],lf[299]));
if(C_truep(t9)){
t10=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4415,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t11=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t11))){
t12=t10;
f_4415(2,t12,C_SCHEME_UNDEFINED);}
else{
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5549,a[2]=t10,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t12,lf[289]);}}
else{
t10=C_i_string_equal_p(((C_word*)t0)[7],lf[300]);
t11=(C_truep(t10)?t10:C_i_string_equal_p(((C_word*)t0)[7],lf[301]));
if(C_truep(t11)){
t12=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4448,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t13=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t13))){
t14=t12;
f_4448(2,t14,C_SCHEME_UNDEFINED);}
else{
t14=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5554,a[2]=t12,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t14,lf[289]);}}
else{
t12=C_i_string_equal_p(((C_word*)t0)[7],lf[302]);
t13=(C_truep(t12)?t12:C_i_string_equal_p(((C_word*)t0)[7],lf[303]));
if(C_truep(t13)){
t14=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4485,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t15=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t15))){
t16=t14;
f_4485(2,t16,C_SCHEME_UNDEFINED);}
else{
t16=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5559,a[2]=t14,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t16,lf[289]);}}
else{
t14=C_i_string_equal_p(((C_word*)t0)[7],lf[304]);
t15=(C_truep(t14)?t14:C_i_string_equal_p(((C_word*)t0)[7],lf[305]));
if(C_truep(t15)){
t16=lf[5] /* main#*keep* */ =C_SCHEME_TRUE;;
t17=lf[9] /* main#*no-install* */ =C_SCHEME_TRUE;;
t18=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t19=((C_word*)((C_word*)t0)[5])[1];
f_4174(t19,((C_word*)t0)[8],t18,((C_word*)t0)[4]);}
else{
t16=C_i_string_equal_p(((C_word*)t0)[7],lf[306]);
t17=(C_truep(t16)?t16:C_i_string_equal_p(((C_word*)t0)[7],lf[307]));
if(C_truep(t17)){
t18=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4553,a[2]=((C_word*)t0)[8],tmp=(C_word)a,a+=3,tmp);
t19=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4560,a[2]=t18,tmp=(C_word)a,a+=3,tmp);
/* chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[39]))(2,*((C_word*)lf[39]+1),t19);}
else{
t18=C_i_string_equal_p(((C_word*)t0)[7],lf[308]);
t19=(C_truep(t18)?t18:C_i_string_equal_p(((C_word*)t0)[7],lf[309]));
if(C_truep(t19)){
t20=C_set_block_item(((C_word*)t0)[3],0,C_SCHEME_TRUE);
t21=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t22=((C_word*)((C_word*)t0)[5])[1];
f_4174(t22,((C_word*)t0)[8],t21,((C_word*)t0)[4]);}
else{
t20=C_i_string_equal_p(((C_word*)t0)[7],lf[310]);
t21=(C_truep(t20)?t20:C_i_string_equal_p(((C_word*)t0)[7],lf[311]));
if(C_truep(t21)){
t22=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4589,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[8],tmp=(C_word)a,a+=4,tmp);
t23=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t23))){
t24=t22;
f_4589(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5566,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t24,lf[289]);}}
else{
if(C_truep(C_i_string_equal_p(lf[318],((C_word*)t0)[7]))){
t22=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4618,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t23=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t23))){
t24=t22;
f_4618(2,t24,C_SCHEME_UNDEFINED);}
else{
t24=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5571,a[2]=t22,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t24,lf[289]);}}
else{
t22=C_i_string_equal_p(lf[319],((C_word*)t0)[7]);
t23=(C_truep(t22)?t22:C_i_string_equal_p(lf[320],((C_word*)t0)[7]));
if(C_truep(t23)){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4654,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4654(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5576,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t26,lf[289]);}}
else{
if(C_truep(C_i_string_equal_p(lf[321],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4692,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4692(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5581,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t26,lf[289]);}}
else{
if(C_truep(C_i_string_equal_p(lf[322],((C_word*)t0)[7]))){
t24=lf[7] /* main#*run-tests* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[323],((C_word*)t0)[7]))){
t24=lf[29] /* main#*target-extension* */ =C_SCHEME_FALSE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[324],((C_word*)t0)[7]))){
t24=lf[28] /* main#*host-extension* */ =C_SCHEME_FALSE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[325],((C_word*)t0)[7]))){
t24=lf[30] /* main#*debug-setup* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[326],((C_word*)t0)[7]))){
t24=lf[21] /* main#*deploy* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[327],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4800,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4800(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5586,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t26,lf[289]);}}
else{
if(C_truep(C_i_string_equal_p(lf[328],((C_word*)t0)[7]))){
t24=lf[22] /* main#*trunk* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[329],((C_word*)t0)[7]))){
t24=lf[31] /* main#*keep-going* */ =C_SCHEME_TRUE;;
t25=C_i_cdr(((C_word*)t0)[6]);
/* loop1027 */
t26=((C_word*)((C_word*)t0)[5])[1];
f_4174(t26,((C_word*)t0)[8],t25,((C_word*)t0)[4]);}
else{
if(C_truep(C_i_string_equal_p(lf[330],((C_word*)t0)[7]))){
t24=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4858,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[8],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t25=C_i_cdr(((C_word*)t0)[6]);
if(C_truep(C_i_pairp(t25))){
t26=t24;
f_4858(2,t26,C_SCHEME_UNDEFINED);}
else{
t26=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5591,a[2]=t24,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t26,lf[289]);}}
else{
t24=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4885,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[8],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t25=C_i_string_length(((C_word*)t0)[7]);
if(C_truep(C_i_positivep(t25))){
t26=C_i_string_ref(((C_word*)t0)[7],C_fix(0));
t27=t24;
f_4885(t27,C_eqp(C_make_character(45),t26));}
else{
t26=t24;
f_4885(t26,C_SCHEME_FALSE);}}}}}}}}}}}}}}}}}}}}}}}}}}}

/* k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4885(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4885,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_string_length(((C_word*)t0)[7]);
if(C_truep(C_i_greaterp(t2,C_fix(2)))){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4894,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4934,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* substring */
((C_proc4)C_retrieve_proc(*((C_word*)lf[335]+1)))(4,*((C_word*)lf[335]+1),t4,((C_word*)t0)[7],C_fix(1));}
else{
t3=((C_word*)t0)[5];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5601,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t4,lf[289]);}}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_5037,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[3],tmp=(C_word)a,a+=8,tmp);
/* pathname-extension */
((C_proc3)C_retrieve_symbol_proc(lf[339]))(3,*((C_word*)lf[339]+1),t2,((C_word*)t0)[7]);}}

/* k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5037(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5037,2,t0,t1);}
if(C_truep(C_i_equalp(lf[336],t1))){
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4950,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4995,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* string-match */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}}

/* k4993 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4995(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4995,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4999,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
/* g11811182 */
t3=t2;
f_4999(t3,((C_word*)t0)[3],t1);}
else{
t2=C_i_cdr(((C_word*)t0)[6]);
t3=C_a_i_cons(&a,2,((C_word*)t0)[2],((C_word*)t0)[4]);
/* loop1027 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4174(t4,((C_word*)t0)[3],t2,t3);}}

/* g1181 in k4993 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4999(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4999,NULL,3,t0,t1,t2);}
t3=C_i_cdr(((C_word*)t0)[4]);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_5011,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t5=C_i_cadr(t2);
t6=C_i_caddr(t2);
/* alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),t4,t5,t6,((C_word*)t0)[2]);}

/* k5009 in g1181 in k4993 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5011(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop1027 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4174(t2,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4950(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4950,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4954,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=t1,a[6]=((C_word*)t0)[6],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4973,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* pathname-directory */
((C_proc3)C_retrieve_symbol_proc(lf[338]))(3,*((C_word*)lf[338]+1),t3,((C_word*)t0)[2]);}

/* k4971 in k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4973(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4973,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4976,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4982,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
/* absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t3,t1);}
else{
/* current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t2);}}

/* k4980 in k4971 in k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4982(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4982,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[5];
t3=C_a_i_list(&a,2,t2,lf[337]);
/* alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),((C_word*)t0)[4],((C_word*)t0)[3],t3,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4989,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t2);}}

/* k4987 in k4980 in k4971 in k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4974 in k4971 in k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4976,2,t0,t1);}
t2=C_a_i_list(&a,2,t1,lf[337]);
/* alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),((C_word*)t0)[3],((C_word*)t0)[2],t2,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));}

/* k4952 in k4948 in k5035 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4954(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4954,2,t0,t1);}
t2=C_mutate(&lf[46] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=C_i_cdr(((C_word*)t0)[6]);
t4=C_a_i_cons(&a,2,((C_word*)t0)[5],((C_word*)t0)[4]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[3])[1];
f_4174(t5,((C_word*)t0)[2],t3,t4);}

/* f5601 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4932 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4934(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string->list */
t2=C_retrieve(lf[334]);
((C_proc3)(void*)(*((C_word*)t2+1)))(3,t2,((C_word*)t0)[2],t1);}

/* k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4894(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4894,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4900,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4926,tmp=(C_word)a,a+=2,tmp);
/* every */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t2,t3,t1);}

/* a4925 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4926(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4926,3,t0,t1,t2);}
t3=*((C_word*)lf[332]+1);
/* g11561157 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,lf[333]);}

/* k4898 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4900,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4907,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4911,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_4917,tmp=(C_word)a,a+=2,tmp);
/* map */
t5=*((C_word*)lf[265]+1);
((C_proc4)(void*)(*((C_word*)t5+1)))(4,t5,t3,t4,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[5];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f5596,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[289]);}}

/* f5596 in k4898 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* a4916 in k4898 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4917(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4917,3,t0,t1,t2);}
t3=*((C_word*)lf[331]+1);
/* g11751176 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,C_make_character(45),t2);}

/* k4909 in k4898 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[3]);
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1,t2);}

/* k4905 in k4898 in k4892 in k4883 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4907(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop1027 */
t2=((C_word*)((C_word*)t0)[4])[1];
f_4174(t2,((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* f5591 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5591(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4856 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4858(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[11] /* (set! main#*password* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4174(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f5586 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5586(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4798 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4800(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[10] /* (set! main#*username* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4174(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f5581 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5581(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4690 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4692(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4692,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4707,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[198]+1)))(3,*((C_word*)lf[198]+1),t2,t3);}

/* k4705 in k4690 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4707(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4707,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[24],"main#*csc-nonfeatures*"));
t3=C_mutate(&lf[24] /* (set! main#*csc-nonfeatures* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4174(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f5576 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4652 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4654,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4669,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[198]+1)))(3,*((C_word*)lf[198]+1),t2,t3);}

/* k4667 in k4652 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4669(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4669,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_retrieve2(lf[23],"main#*csc-features*"));
t3=C_mutate(&lf[23] /* (set! main#*csc-features* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4174(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* f5571 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5571(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4616 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4618(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4618,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4621,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* main#setup-proxy */
f_4129(t2,t3);}

/* k4619 in k4616 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4621(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4174(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* f5566 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5566(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4589(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4589,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4592,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1842,a[2]=t2,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t4);}

/* k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1842,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[16],"main#*windows-shell*"))?lf[312]:lf[313]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1848,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t3,lf[316],((C_word*)t0)[3],lf[317]);}

/* k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1848(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1848,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1853,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp));
t5=((C_word*)t3)[1];
f_1853(t5,((C_word*)t0)[2],lf[315]);}

/* loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1853,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1861,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1880,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g323324 */
t6=t3;
f_1861(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1878 in loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1880(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1853(t3,((C_word*)t0)[2],t2);}

/* g323 in loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1861,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1869,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1877,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t4,((C_word*)t0)[2],t2);}

/* k1875 in g323 in loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1877(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),((C_word*)t0)[2],t1);}

/* k1867 in g323 in loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1869(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1869,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1873,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),t2,((C_word*)t0)[2]);}

/* k1871 in k1867 in g323 in loop316 in k1846 in k1840 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1873(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1873,2,t0,t1);}
/* main#command */
f_4108(((C_word*)t0)[4],lf[314],C_a_i_list(&a,3,((C_word*)t0)[3],((C_word*)t0)[2],t1));}

/* k4590 in k4587 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(0));}

/* k4558 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4560(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k4551 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4553(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(0));}

/* f5559 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5559(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4483 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4485(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4485,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4492,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_4502,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=t2,tmp=(C_word)a,a+=8,tmp);
/* absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t4,t2);}

/* k4500 in k4483 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4502,2,t0,t1);}
if(C_truep(t1)){
t2=C_mutate(&lf[25] /* (set! main#*prefix* ...) */,((C_word*)t0)[7]);
t3=C_i_cddr(((C_word*)t0)[6]);
/* loop1027 */
t4=((C_word*)((C_word*)t0)[5])[1];
f_4174(t4,((C_word*)t0)[4],t3,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4509,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4513,a[2]=((C_word*)t0)[7],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t3);}}

/* k4511 in k4500 in k4483 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4513(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k4507 in k4500 in k4483 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4509(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* normalize-pathname */
((C_proc3)C_retrieve_symbol_proc(lf[241]))(3,*((C_word*)lf[241]+1),((C_word*)t0)[2],t1);}

/* k4490 in k4483 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4492(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[25] /* (set! main#*prefix* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4174(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f5554 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5554(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4446 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4448(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4448,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4452,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[198]+1)))(3,*((C_word*)lf[198]+1),t2,t3);}

/* k4450 in k4446 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4452(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[14] /* (set! main#*default-transport* ...) */,t1);
t3=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_4174(t4,((C_word*)t0)[3],t3,((C_word*)t0)[2]);}

/* f5549 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5549(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k4413 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4415(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[5]);
t3=C_mutate(&lf[13] /* (set! main#*default-location* ...) */,t2);
t4=C_i_cddr(((C_word*)t0)[5]);
/* loop1027 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_4174(t5,((C_word*)t0)[3],t4,((C_word*)t0)[2]);}

/* k4377 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cdr(((C_word*)t0)[5]);
/* loop1027 */
t3=((C_word*)((C_word*)t0)[4])[1];
f_4174(t3,((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k4334 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4336(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),((C_word*)t0)[2],t1);}

/* k4327 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4329(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(0));}

/* f5544 in k4315 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f5544(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(0));}

/* k1729 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1731(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[2],"main#constant164"));}

/* k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1389,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1396,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1727,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
/* file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t4,t1);}

/* k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1727(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1727,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1409,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],tmp=(C_word)a,a+=4,tmp);
/* read-file */
((C_proc3)C_retrieve_symbol_proc(lf[286]))(3,*((C_word*)lf[286]+1),t2,((C_word*)t0)[3]);}
else{
t2=((C_word*)t0)[2];
f_4199(t2,C_i_pairp(C_retrieve2(lf[12],"main#*default-sources*")));}}

/* k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1409(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1409,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1411,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_1411(t5,((C_word*)t0)[2],t1);}

/* loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1411(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1411,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1419,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1712,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g194195 */
t6=t3;
f_1419(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1710 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1712(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_1411(t3,((C_word*)t0)[2],t2);}

/* g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1419(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1419,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1423,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=t2,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
if(C_truep(C_i_positivep(t4))){
t5=t3;
f_1423(2,t5,C_SCHEME_UNDEFINED);}
else{
/* broken183 */
t5=((C_word*)t0)[2];
f_1389(t5,t3,t2);}}
else{
/* broken183 */
t4=((C_word*)t0)[2];
f_1389(t4,t3,t2);}}

/* k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1423(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word t18;
C_word t19;
C_word t20;
C_word t21;
C_word t22;
C_word t23;
C_word t24;
C_word t25;
C_word t26;
C_word t27;
C_word t28;
C_word t29;
C_word t30;
C_word t31;
C_word t32;
C_word t33;
C_word t34;
C_word ab[19],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1423,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=C_eqp(t2,lf[40]);
if(C_truep(t3)){
t4=C_i_cdr(((C_word*)t0)[4]);
if(C_truep(C_i_pairp(t4))){
t5=C_i_cadr(((C_word*)t0)[4]);
if(C_truep(C_i_nequalp(t5,C_fix(1)))){
t6=C_SCHEME_UNDEFINED;
t7=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}
else{
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1454,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t6);}}
else{
/* broken183 */
t5=((C_word*)t0)[2];
f_1389(t5,((C_word*)t0)[3],((C_word*)t0)[4]);}}
else{
t4=C_eqp(t2,lf[279]);
if(C_truep(t4)){
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1502,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t6=C_i_cdr(((C_word*)t0)[4]);
t7=C_a_i_list(&a,1,t6);
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t5,C_retrieve2(lf[12],"main#*default-sources*"),t7);}
else{
t5=C_eqp(t2,lf[280]);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1520,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t7=C_SCHEME_END_OF_LIST;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1524,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
t12=C_i_cdr(((C_word*)t0)[4]);
t13=C_SCHEME_UNDEFINED;
t14=(*a=C_VECTOR_TYPE|1,a[1]=t13,tmp=(C_word)a,a+=2,tmp);
t15=C_set_block_item(t14,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1530,a[2]=t8,a[3]=t14,a[4]=t10,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t16=((C_word*)t14)[1];
f_1530(t16,t11,t12);}
else{
t6=C_eqp(t2,lf[284]);
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1609,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_END_OF_LIST;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_SCHEME_FALSE;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1613,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
t13=C_i_cdr(((C_word*)t0)[4]);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1619,a[2]=t9,a[3]=t15,a[4]=t11,a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[2],tmp=(C_word)a,a+=7,tmp));
t17=((C_word*)t15)[1];
f_1619(t17,t12,t13);}
else{
/* broken183 */
t7=((C_word*)t0)[2];
f_1389(t7,((C_word*)t0)[3],((C_word*)t0)[4]);}}}}}

/* loop259 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1619(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1619,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1646,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1686,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g275276 */
t6=t3;
f_1646(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1684 in loop259 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1686(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1686,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop259272 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1619(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop259272 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1619(t6,((C_word*)t0)[3],t5);}}

/* g275 in loop259 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1646(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1646,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1653,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_i_listp(t2))){
t4=C_i_length(t2);
if(C_truep(C_i_nequalp(C_fix(2),t4))){
/* every */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t3,*((C_word*)lf[285]+1),t2);}
else{
t5=t3;
f_1653(2,t5,C_SCHEME_FALSE);}}
else{
t4=t3;
f_1653(2,t4,C_SCHEME_FALSE);}}

/* k1651 in g275 in loop259 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1653(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1653,2,t0,t1);}
if(C_truep(t1)){
t2=C_i_car(((C_word*)t0)[5]);
t3=C_i_cadr(((C_word*)t0)[5]);
t4=((C_word*)t0)[4];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_a_i_cons(&a,2,t2,t3));}
else{
/* broken183 */
t2=((C_word*)t0)[3];
f_1389(t2,((C_word*)t0)[4],((C_word*)t0)[2]);}}

/* k1611 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],C_retrieve2(lf[26],"main#*aliases*"),t1);}

/* k1607 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1609(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[26] /* (set! main#*aliases* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1530(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1530,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1557,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_1595,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g234235 */
t6=t3;
f_1557(t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k1593 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1595(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1595,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop218231 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1530(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop218231 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_1530(t6,((C_word*)t0)[3],t5);}}

/* g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1557(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1557,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_1561,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1588,tmp=(C_word)a,a+=2,tmp);
/* list-index */
((C_proc4)C_retrieve_symbol_proc(lf[283]))(4,*((C_word*)lf[283]+1),t3,t4,t2);}

/* a1587 in g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1588(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_1588,3,t0,t1,t2);}
t3=*((C_word*)lf[112]+1);
/* g243244 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,lf[282],t2);}

/* k1559 in g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1561(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1561,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1564,a[2]=((C_word*)t0)[4],a[3]=t1,a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(t1)){
t3=t2;
f_1564(2,t3,C_SCHEME_UNDEFINED);}
else{
/* broken183 */
t3=((C_word*)t0)[3];
f_1389(t3,t2,((C_word*)t0)[2]);}}

/* k1562 in k1559 in g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1569,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_1575,tmp=(C_word)a,a+=2,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a1574 in k1562 in k1559 in g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1575(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_1575,4,t0,t1,t2,t3);}
t4=C_i_cdr(t3);
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,C_a_i_cons(&a,2,t2,t4));}

/* a1568 in k1562 in k1559 in g234 in loop218 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1569(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1569,2,t0,t1);}
/* split-at */
((C_proc4)C_retrieve_symbol_proc(lf[281]))(4,*((C_word*)lf[281]+1),t1,((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k1522 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1524(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],C_retrieve2(lf[20],"main#*mappings*"),t1);}

/* k1518 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1520(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[20] /* (set! main#*mappings* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1500 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-sources* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1454(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1454,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1457,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[278],t1);}

/* k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1457(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1457,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1460,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,C_retrieve2(lf[2],"main#constant164"),((C_word*)t0)[2]);}

/* k1458 in k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1460(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1460,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1463,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[277],((C_word*)t0)[2]);}

/* k1461 in k1458 in k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1463(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1463,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1466,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,C_fix(1),((C_word*)t0)[2]);}

/* k1464 in k1461 in k1458 in k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1466(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1466,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1469,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* write-char/port */
t3=C_retrieve(lf[192]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(41),((C_word*)t0)[2]);}

/* k1467 in k1464 in k1461 in k1458 in k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1469,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1472,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t2,((C_word*)t0)[2]);}

/* k1470 in k1467 in k1464 in k1461 in k1458 in k1455 in k1452 in k1421 in g194 in loop187 in k1407 in k1725 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1472(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(((C_word*)t0)[3]);
/* error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),((C_word*)t0)[2],t1,t2);}

/* k1394 in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1396(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_4199(t2,C_i_pairp(C_retrieve2(lf[12],"main#*default-sources*")));}

/* broken in k1385 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1389(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1389,NULL,3,t0,t1,t2);}
/* error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t1,lf[276],((C_word*)t0)[2],t2);}

/* k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4199(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4199,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4202,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_nullp(((C_word*)t0)[2]))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4234,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* glob */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),t3,lf[275]);}
else{
t3=t2;
f_4202(2,t3,C_SCHEME_UNDEFINED);}}

/* k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4234,2,t0,t1);}
if(C_truep(C_i_pairp(t1))){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4244,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_END_OF_LIST;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4248,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4250,a[2]=t4,a[3]=t9,a[4]=t6,tmp=(C_word)a,a+=5,tmp));
t11=((C_word*)t9)[1];
f_4250(t11,t7,t1);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4299,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[274]);}}

/* k4297 in k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4299(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* loop1044 in k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4250(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4250,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_slot(t2,C_fix(0));
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4285,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* pathname-file */
((C_proc3)C_retrieve_symbol_proc(lf[273]))(3,*((C_word*)lf[273]+1),t4,t3);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4283 in loop1044 in k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4285(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4285,2,t0,t1);}
t2=C_a_i_list(&a,2,lf[271],lf[272]);
t3=C_a_i_cons(&a,2,t1,t2);
t4=C_a_i_cons(&a,2,t3,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t5=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10441057 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_4250(t8,((C_word*)t0)[3],t7);}
else{
t5=C_mutate(((C_word *)((C_word*)t0)[2])+1,t4);
t6=C_mutate(((C_word *)((C_word*)t0)[6])+1,t4);
t7=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop10441057 */
t8=((C_word*)((C_word*)t0)[4])[1];
f_4250(t8,((C_word*)t0)[3],t7);}}

/* k4246 in k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));}

/* k4242 in k4232 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4244(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[46] /* (set! main#*eggs+dirs+vers* ...) */,t1);
t3=((C_word*)t0)[2];
f_4202(2,t3,t2);}

/* k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4202(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4202,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4205,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_4205(2,t3,C_SCHEME_UNDEFINED);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4219,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[14],"main#*default-transport*"))){
if(C_truep(C_retrieve2(lf[13],"main#*default-location*"))){
t4=C_SCHEME_UNDEFINED;
t5=t2;
f_4205(2,t5,t4);}
else{
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t2,lf[269]);}}
else{
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t3,lf[270]);}}}

/* k4217 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4219(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_retrieve2(lf[13],"main#*default-location*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_4205(2,t3,t2);}
else{
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),((C_word*)t0)[2],lf[269]);}}

/* k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4205(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4205,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4212,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4216,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),t3,((C_word*)t0)[2]);}

/* k4214 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#apply-mappings */
f_3978(((C_word*)t0)[2],t1);}

/* k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4212(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4212,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3174,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* main#retrieve */
f_2486(t3,t1);}

/* k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3174(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3174,2,t0,t1);}
if(C_truep(C_retrieve2(lf[8],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3180,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3592,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* topological-sort */
((C_proc4)C_retrieve_symbol_proc(lf[268]))(4,*((C_word*)lf[268]+1),t3,C_retrieve2(lf[47],"main#*dependencies*"),*((C_word*)lf[156]+1));}}

/* k3590 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3592(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),((C_word*)t0)[2],t1);}

/* k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3180(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3180,2,t0,t1);}
t2=C_i_length(t1);
t3=C_retrieve2(lf[6],"main#*force*");
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3186,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t3,tmp=(C_word)a,a+=6,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t4,lf[267]);}

/* k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3186,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3189,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* pp */
((C_proc3)C_retrieve_symbol_proc(lf[266]))(3,*((C_word*)lf[266]+1),t2,((C_word*)t0)[2]);}

/* k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3189(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3189,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3196,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3584,tmp=(C_word)a,a+=2,tmp);
/* map */
t4=*((C_word*)lf[265]+1);
((C_proc4)(void*)(*((C_word*)t4+1)))(4,t4,t2,t3,((C_word*)t0)[2]);}

/* a3583 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3584(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3584,3,t0,t1,t2);}
t3=*((C_word*)lf[264]+1);
/* g818819 */
t4=t3;
((C_proc4)C_retrieve_proc(t4))(4,t4,t1,t2,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));}

/* k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3196(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3196,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3200,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* iota */
((C_proc5)C_retrieve_symbol_proc(lf[263]))(5,*((C_word*)lf[263]+1),t2,((C_word*)t0)[3],((C_word*)t0)[3],C_fix(-1));}

/* k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3200(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3200,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3202,a[2]=t3,a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_3202(t5,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3202(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3202,NULL,4,t0,t1,t2,t3);}
t4=C_i_pairp(t2);
t5=(C_truep(t4)?C_i_pairp(t3):C_SCHEME_FALSE);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3210,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3557,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t3,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t8=C_slot(t2,C_fix(0));
t9=C_slot(t3,C_fix(0));
/* g685686 */
t10=t6;
f_3210(t10,t7,t8,t9);}
else{
t6=C_SCHEME_UNDEFINED;
t7=t1;
((C_proc2)(void*)(*((C_word*)t7+1)))(2,t7,t6);}}

/* k3555 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_slot(((C_word*)t0)[5],C_fix(1));
t3=C_slot(((C_word*)t0)[4],C_fix(1));
t4=((C_word*)((C_word*)t0)[3])[1];
f_3202(t4,((C_word*)t0)[2],t2,t3);}

/* g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3210(C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3210,NULL,4,t0,t1,t2,t3);}
t4=C_i_greaterp(t3,C_fix(1));
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3217,a[2]=t1,a[3]=t3,a[4]=t4,a[5]=t2,tmp=(C_word)a,a+=6,tmp);
t6=(C_truep(((C_word*)t0)[3])?C_SCHEME_FALSE:(C_truep(t4)?C_i_nequalp(t3,((C_word*)t0)[2]):C_SCHEME_FALSE));
if(C_truep(t6)){
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3525,a[2]=t5,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[9],"main#*no-install*"))){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3541,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* yes-or-no? */
((C_proc5)C_retrieve_symbol_proc(lf[72]))(5,*((C_word*)lf[72]+1),t8,lf[262],lf[74],C_retrieve(lf[75]));}
else{
t8=t7;
f_3525(t8,C_SCHEME_FALSE);}}
else{
t7=t5;
f_3217(2,t7,C_SCHEME_UNDEFINED);}}

/* k3539 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_3525(t2,C_i_not(t1));}

/* k3523 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3525(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3525,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3528,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[261]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
f_3217(2,t3,t2);}}

/* k3526 in k3523 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3528(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3528,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3531,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* main#cleanup */
f_3594(t2);}

/* k3529 in k3526 in k3523 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3531(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}

/* k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3217(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3217,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3220,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
t3=C_i_car(((C_word*)t0)[5]);
t4=C_i_caddr(((C_word*)t0)[5]);
/* print */
((C_proc7)C_retrieve_proc(*((C_word*)lf[33]+1)))(7,*((C_word*)lf[33]+1),t2,lf[259],t3,C_make_character(58),t4,lf[260]);}

/* k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3220(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3220,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3223,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[29],"main#*target-extension*"))){
if(C_truep(C_retrieve2(lf[28],"main#*host-extension*"))){
/* create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[203]))(2,*((C_word*)lf[203]+1),t2);}
else{
t3=t2;
f_3223(2,t3,C_SCHEME_FALSE);}}
else{
t3=t2;
f_3223(2,t3,C_SCHEME_FALSE);}}

/* k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3223(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3223,2,t0,t1);}
t2=C_i_cadr(((C_word*)t0)[5]);
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3229,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],a[7]=((C_word*)t0)[5],tmp=(C_word)a,a+=8,tmp);
if(C_truep(t1)){
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3491,a[2]=t2,a[3]=t1,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t4,lf[258]);}
else{
t4=t3;
f_3229(2,t4,C_SCHEME_UNDEFINED);}}

/* k3489 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3491(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3491,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[16],"main#*windows-shell*"))?lf[254]:lf[255]);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3502,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t3,((C_word*)t0)[2],lf[257]);}

/* k3500 in k3489 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3502(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3502,2,t0,t1);}
/* main#command */
f_4108(((C_word*)t0)[4],lf[256],C_a_i_list(&a,3,((C_word*)t0)[3],t1,((C_word*)t0)[2]));}

/* k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3229(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3229,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3230,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[6],a[4]=((C_word*)t0)[7],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3431,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=(C_truep(C_retrieve2(lf[29],"main#*target-extension*"))?C_retrieve2(lf[28],"main#*host-extension*"):C_SCHEME_FALSE);
if(C_truep(t4)){
t5=C_SCHEME_FALSE;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_SCHEME_FALSE;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3467,a[2]=t8,a[3]=t6,a[4]=t12,a[5]=t10,tmp=(C_word)a,a+=6,tmp);
t14=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3474,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t15=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3480,a[2]=t12,a[3]=t10,a[4]=t8,a[5]=t6,tmp=(C_word)a,a+=6,tmp);
/* ##sys#dynamic-wind */
t16=*((C_word*)lf[199]+1);
((C_proc5)(void*)(*((C_word*)t16+1)))(5,t16,t3,t13,t14,t15);}
else{
/* setup700 */
t5=t2;
f_3230(t5,t3,((C_word*)t0)[2]);}}

/* a3479 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3480(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3480,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[21],"main#*deploy*"));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[25],"main#*prefix*"));
t4=C_mutate(&lf[21] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(&lf[25] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* a3473 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3474(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3474,2,t0,t1);}
/* setup700 */
t2=((C_word*)t0)[3];
f_3230(t2,t1,((C_word*)t0)[2]);}

/* a3466 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3467(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3467,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,C_retrieve2(lf[21],"main#*deploy*"));
t3=C_mutate(((C_word *)((C_word*)t0)[4])+1,C_retrieve2(lf[25],"main#*prefix*"));
t4=C_mutate(&lf[21] /* (set! main#*deploy* ...) */,((C_word*)((C_word*)t0)[3])[1]);
t5=C_mutate(&lf[25] /* (set! main#*prefix* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t6=t1;
((C_proc2)(void*)(*((C_word*)t6+1)))(2,t6,C_SCHEME_UNDEFINED);}

/* k3429 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3431(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3431,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[29],"main#*target-extension*"))?C_retrieve2(lf[28],"main#*host-extension*"):C_SCHEME_FALSE);
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3440,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[253]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3438 in k3429 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3440(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3440,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3445,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3450,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3456,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t9=*((C_word*)lf[199]+1);
((C_proc5)(void*)(*((C_word*)t9+1)))(5,t9,((C_word*)t0)[2],t6,t7,t8);}

/* a3455 in k3438 in k3429 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3456(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3456,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[28],"main#*host-extension*"));
t3=C_mutate(&lf[28] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3449 in k3438 in k3429 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3450(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3450,2,t0,t1);}
/* setup700 */
t2=((C_word*)t0)[3];
f_3230(t2,t1,((C_word*)t0)[2]);}

/* a3444 in k3438 in k3429 in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3445(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3445,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve2(lf[28],"main#*host-extension*"));
t3=C_mutate(&lf[28] /* (set! main#*host-extension* ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3230(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3230,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3234,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=t2,tmp=(C_word)a,a+=7,tmp);
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t3,lf[252],t2);}

/* k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3234(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3234,2,t0,t1);}
t2=C_retrieve(lf[136]);
t3=((C_word*)t0)[6];
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3235,a[2]=t2,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3248,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#dynamic-wind */
t7=*((C_word*)lf[199]+1);
((C_proc5)(void*)(*((C_word*)t7+1)))(5,t7,((C_word*)t0)[2],t5,t6,t5);}

/* a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3248(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3248,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3252,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_greaterp(((C_word*)t0)[2],C_fix(1));
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3013,a[2]=t4,a[3]=t2,a[4]=t3,tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[27],"main#*cross-chicken*"))){
t6=C_retrieve2(lf[28],"main#*host-extension*");
t7=t5;
f_3013(t7,(C_truep(t6)?lf[250]:lf[251]));}
else{
t6=t5;
f_3013(t6,lf[250]);}}

/* k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3013(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3013,NULL,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[30],"main#*debug-setup*"))?lf[218]:lf[219]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3021,a[2]=((C_word*)t0)[2],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[3],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t3);}

/* k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3021(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3021,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3024,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[249],t1);}

/* k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3024(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3024,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3027,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,t3,((C_word*)t0)[2]);}

/* k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3027(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3027,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3030,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[248],((C_word*)t0)[2]);}

/* k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3030(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3030,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3033,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_caddr(((C_word*)t0)[3]);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,t3,((C_word*)t0)[2]);}

/* k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3033(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3033,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3036,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[247],((C_word*)t0)[2]);}

/* k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3036(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3036,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3039,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t2,((C_word*)t0)[2]);}

/* k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3039(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3039,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_3154,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],tmp=(C_word)a,a+=8,tmp);
/* setup-api#sudo-install */
((C_proc2)C_retrieve_symbol_proc(lf[246]))(2,*((C_word*)lf[246]+1),t2);}

/* k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3154(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3154,2,t0,t1);}
t2=(C_truep(t1)?lf[220]:lf[221]);
t3=(C_truep(C_retrieve2(lf[5],"main#*keep*"))?lf[222]:lf[223]);
t4=(C_truep(C_retrieve2(lf[9],"main#*no-install*"))?(C_truep(((C_word*)t0)[7])?lf[224]:lf[225]):lf[224]);
t5=(C_truep(C_retrieve2(lf[28],"main#*host-extension*"))?lf[226]:lf[227]);
t6=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3059,a[2]=((C_word*)t0)[2],a[3]=t5,a[4]=t4,a[5]=t3,a[6]=t2,a[7]=((C_word*)t0)[3],a[8]=((C_word*)t0)[4],a[9]=((C_word*)t0)[5],a[10]=((C_word*)t0)[6],tmp=(C_word)a,a+=11,tmp);
t7=(C_truep(C_retrieve2(lf[27],"main#*cross-chicken*"))?C_i_not(C_retrieve2(lf[28],"main#*host-extension*")):C_SCHEME_FALSE);
if(C_truep(t7)){
t8=C_retrieve2(lf[25],"main#*prefix*");
if(C_truep(t8)){
t9=t6;
f_3059(2,t9,t8);}
else{
/* ##sys#peek-c-string */
t9=*((C_word*)lf[245]+1);
((C_proc4)(void*)(*((C_word*)t9+1)))(4,t9,t6,C_mpointer(&a,(void*)C_TARGET_PREFIX),C_fix(0));}}
else{
t8=C_retrieve2(lf[25],"main#*prefix*");
t9=t6;
f_3059(2,t9,t8);}}

/* k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3059(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3059,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|10,a[1]=(C_word)f_3062,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=((C_word*)t0)[8],a[9]=((C_word*)t0)[9],a[10]=((C_word*)t0)[10],tmp=(C_word)a,a+=11,tmp);
if(C_truep(t1)){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3129,a[2]=t1,a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t3);}
else{
t3=t2;
f_3062(2,t3,lf[244]);}}

/* k3127 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3129(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3129,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3132,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[243],t1);}

/* k3130 in k3127 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3132(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3132,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3135,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3145,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* normalize-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[241]))(4,*((C_word*)lf[241]+1),t3,((C_word*)t0)[2],lf[242]);}

/* k3143 in k3130 in k3127 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3145(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k3133 in k3130 in k3127 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3135(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3135,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3138,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[240],((C_word*)t0)[2]);}

/* k3136 in k3133 in k3130 in k3127 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3138(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3062(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[15],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3062,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|11,a[1]=(C_word)f_3066,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],tmp=(C_word)a,a+=12,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[23],"main#*csc-features*")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3114,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t3);}
else{
t3=t2;
f_3066(2,t3,lf[239]);}}

/* k3112 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3114(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3114,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3117,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[238],t1);}

/* k3115 in k3112 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3117(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3117,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3120,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[177]+1)))(4,*((C_word*)lf[177]+1),t2,C_retrieve2(lf[23],"main#*csc-features*"),((C_word*)t0)[2]);}

/* k3118 in k3115 in k3112 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3120(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3120,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3123,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[237],((C_word*)t0)[2]);}

/* k3121 in k3118 in k3115 in k3112 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3123(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3066(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3066,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|12,a[1]=(C_word)f_3070,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],tmp=(C_word)a,a+=13,tmp);
if(C_truep(C_i_pairp(C_retrieve2(lf[24],"main#*csc-nonfeatures*")))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3096,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t3);}
else{
t3=t2;
f_3070(2,t3,lf[236]);}}

/* k3094 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3096(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3096,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3099,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[235],t1);}

/* k3097 in k3094 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3099(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3099,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3102,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* write */
((C_proc4)C_retrieve_proc(*((C_word*)lf[177]+1)))(4,*((C_word*)lf[177]+1),t2,C_retrieve2(lf[24],"main#*csc-nonfeatures*"),((C_word*)t0)[2]);}

/* k3100 in k3097 in k3094 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3102(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3102,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3105,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[234],((C_word*)t0)[2]);}

/* k3103 in k3100 in k3097 in k3094 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3105(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k3068 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3070(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[17],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3070,2,t0,t1);}
t2=(C_truep(C_retrieve2(lf[21],"main#*deploy*"))?lf[228]:lf[229]);
t3=(*a=C_CLOSURE_TYPE|13,a[1]=(C_word)f_3078,a[2]=t2,a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],a[7]=((C_word*)t0)[6],a[8]=((C_word*)t0)[7],a[9]=((C_word*)t0)[8],a[10]=((C_word*)t0)[9],a[11]=((C_word*)t0)[10],a[12]=((C_word*)t0)[11],a[13]=((C_word*)t0)[12],tmp=(C_word)a,a+=14,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3082,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
t6=C_i_car(((C_word*)t0)[2]);
/* make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t4,t5,t6,lf[233]);}

/* k3080 in k3068 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3082(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#shellpath */
((C_proc3)C_retrieve_symbol_proc(lf[232]))(3,*((C_word*)lf[232]+1),((C_word*)t0)[2],t1);}

/* k3076 in k3068 in k3064 in k3060 in k3057 in k3152 in k3037 in k3034 in k3031 in k3028 in k3025 in k3022 in k3019 in k3011 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3078(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* conc */
((C_proc18)C_retrieve_symbol_proc(lf[81]))(18,*((C_word*)lf[81]+1),((C_word*)t0)[13],C_retrieve2(lf[49],"main#*csi*"),lf[230],((C_word*)t0)[12],lf[231],((C_word*)t0)[11],((C_word*)t0)[10],((C_word*)t0)[9],((C_word*)t0)[8],((C_word*)t0)[7],((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],C_make_character(32),t1);}

/* k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3252(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3252,2,t0,t1);}
t2=C_i_car(((C_word*)t0)[4]);
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3258,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,a[5]=((C_word*)t0)[4],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t3,lf[217],t1);}

/* k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3258(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3258,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3259,a[2]=((C_word*)t0)[6],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3266,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
if(C_truep(C_retrieve2(lf[31],"main#*keep-going*"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3370,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3375,a[2]=t2,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[138]+1)))(3,*((C_word*)lf[138]+1),t4,t5);}
else{
/* tmp715722 */
t4=t2;
f_3259(t4,t3);}}

/* a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3375(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3375,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3381,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3399,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a3398 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3399(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3399,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3405,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3411,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3410 in a3398 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3411(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3411r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3411r(t0,t1,t2);}}

static void C_ccall f_3411r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3417,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k723727 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3416 in a3410 in a3398 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3417(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3417,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3404 in a3398 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3405(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3405,2,t0,t1);}
/* tmp715722 */
t2=((C_word*)t0)[2];
f_3259(t2,t1);}

/* a3380 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3381(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3381,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3387,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k723727 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3386 in a3380 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3387(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3387,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3391,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[33]+1)))(6,*((C_word*)lf[33]+1),t2,lf[216],lf[209],((C_word*)t0)[2],lf[210]);}

/* k3389 in a3386 in a3380 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3391(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3391,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3394,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),t2,((C_word*)t0)[2]);}

/* k3392 in k3389 in a3386 in a3380 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3394(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3394,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3397,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[207]);}

/* k3395 in k3392 in k3389 in a3386 in a3380 in a3374 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3397(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3368 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3370(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g725726 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3266(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3266,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3272,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_retrieve2(lf[7],"main#*run-tests*"))){
if(C_truep(((C_word*)t0)[2])){
t3=t2;
f_3272(2,t3,C_SCHEME_FALSE);}
else{
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3358,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t3,lf[215]);}}
else{
t3=t2;
f_3272(2,t3,C_SCHEME_FALSE);}}

/* k3356 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3358(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3358,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3364,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* directory? */
((C_proc3)C_retrieve_symbol_proc(lf[213]))(3,*((C_word*)lf[213]+1),t2,lf[214]);}
else{
t2=((C_word*)t0)[2];
f_3272(2,t2,C_SCHEME_FALSE);}}

/* k3362 in k3356 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3364(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),((C_word*)t0)[2],lf[212]);}
else{
t2=((C_word*)t0)[2];
f_3272(2,t2,C_SCHEME_FALSE);}}

/* k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3272(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3272,2,t0,t1);}
if(C_truep(t1)){
t2=lf[19] /* main#*running-test* */ =C_SCHEME_TRUE;;
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3276,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* current-directory */
((C_proc3)C_retrieve_symbol_proc(lf[136]))(3,*((C_word*)lf[136]+1),t3,lf[211]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3276(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[14],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3276,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3277,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3288,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[31],"main#*keep-going*"))){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3292,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3297,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[138]+1)))(3,*((C_word*)lf[138]+1),t4,t5);}
else{
/* tmp738745 */
t4=t2;
f_3277(t4,t3);}}

/* a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3297(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3297,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3303,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3321,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a3320 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3321(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3321,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3327,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3333,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3332 in a3320 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3333(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3333r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3333r(t0,t1,t2);}}

static void C_ccall f_3333r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3339,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k746750 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3338 in a3332 in a3320 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3339(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3339,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3326 in a3320 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3327(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3327,2,t0,t1);}
/* tmp738745 */
t2=((C_word*)t0)[2];
f_3277(t2,t1);}

/* a3302 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3303(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3303,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3309,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k746750 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3308 in a3302 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3309,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3313,a[2]=((C_word*)t0)[3],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[33]+1)))(6,*((C_word*)lf[33]+1),t2,lf[208],lf[209],((C_word*)t0)[2],lf[210]);}

/* k3311 in a3308 in a3302 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3313(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3313,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3316,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),t2,((C_word*)t0)[2]);}

/* k3314 in k3311 in a3308 in a3302 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3316(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3316,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3319,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[207]);}

/* k3317 in k3314 in k3311 in a3308 in a3302 in a3296 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3319(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}

/* k3290 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3292(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g748749 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k3286 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3288(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=lf[19] /* main#*running-test* */ =C_SCHEME_FALSE;;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* tmp738 in k3274 in k3270 in k3264 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3277(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3277,NULL,2,t0,t1);}
t2=C_i_caddr(((C_word*)t0)[3]);
/* main#command */
f_4108(t1,lf[206],C_a_i_list(&a,3,C_retrieve2(lf[49],"main#*csi*"),((C_word*)t0)[2],t2));}

/* tmp715 in k3256 in k3250 in a3247 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3259(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3259,NULL,2,t0,t1);}
/* main#$system */
f_4086(t1,((C_word*)t0)[2]);}

/* swap702 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3235(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3235,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3239,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* g703704707 */
t3=((C_word*)t0)[2];
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k3237 in swap702 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3239(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3239,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3242,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* g703704707 */
t3=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t3))(3,t3,t2,((C_word*)((C_word*)t0)[4])[1]);}

/* k3240 in k3237 in swap702 in k3232 in setup in k3227 in k3221 in k3218 in k3215 in g685 in loop675 in k3198 in k3194 in k3187 in k3184 in k3178 in k3172 in k4210 in k4203 in k4200 in k4197 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3242(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(((C_word *)((C_word*)t0)[4])+1,((C_word*)t0)[3]);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* k3974 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3976(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,lf[205]);}

/* k3970 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3972(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* glob */
((C_proc3)C_retrieve_symbol_proc(lf[204]))(3,*((C_word*)lf[204]+1),((C_word*)t0)[2],t1);}

/* k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3613(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3613,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3616,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* create-temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[203]))(2,*((C_word*)lf[203]+1),t2);}

/* k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3616(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3616,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3619,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),t2,t1,C_retrieve2(lf[0],"main#constant161"));}

/* k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3619(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3619,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3622,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* regexp */
((C_proc3)C_retrieve_symbol_proc(lf[201]))(3,*((C_word*)lf[201]+1),t2,lf[202]);}

/* k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3622(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3622,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3625,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[200]);}

/* k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3625(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[21],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3625,2,t0,t1);}
t2=C_SCHEME_FALSE;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3628,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],tmp=(C_word)a,a+=5,tmp);
t7=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3842,a[2]=t3,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t8=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3847,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3965,a[2]=t5,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#dynamic-wind */
t10=*((C_word*)lf[199]+1);
((C_proc5)(void*)(*((C_word*)t10+1)))(5,t10,t6,t7,t8,t9);}

/* a3964 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3965(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3965,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[190]));
t3=C_mutate((C_word*)lf[190]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3847(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3847,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3853,a[2]=t3,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp));
t5=((C_word*)t3)[1];
f_3853(t5,t1,((C_word*)t0)[2]);}

/* loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3853(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3853,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3861,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3952,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t5=C_slot(t2,C_fix(0));
/* g845846 */
t6=t3;
f_3861(t6,t4,t5);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3950 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3952(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3853(t3,((C_word*)t0)[2],t2);}

/* g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3861(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3861,NULL,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3865,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* string-match */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t3,((C_word*)t0)[2],t2);}

/* k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3865(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3865,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3868,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3873,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[138]+1)))(3,*((C_word*)lf[138]+1),t2,t3);}

/* a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3873(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3873,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3879,a[2]=t2,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3911,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a3910 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3911(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3911,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3917,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3939,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a3938 in a3910 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3939(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_3939r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_3939r(t0,t1,t2);}}

static void C_ccall f_3939r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3945,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k849853 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3944 in a3938 in a3910 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3945(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3945,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a3916 in a3910 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3917(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3917,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3933,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* string->symbol */
((C_proc3)C_retrieve_proc(*((C_word*)lf[198]+1)))(3,*((C_word*)lf[198]+1),t2,t3);}

/* k3931 in a3916 in a3910 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3933(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3933,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
t3=C_a_i_cons(&a,2,lf[196],t2);
/* eval */
((C_proc3)C_retrieve_symbol_proc(lf[197]))(3,*((C_word*)lf[197]+1),((C_word*)t0)[2],t3);}

/* a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3879(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3879,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3885,a[2]=((C_word*)t0)[3],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* k849853 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3885(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3885,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3893,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
/* current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[172]))(2,*((C_word*)lf[172]+1),t2);}

/* k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3893(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3893,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3897,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* open-output-string */
((C_proc2)C_retrieve_symbol_proc(lf[195]))(2,*((C_word*)lf[195]+1),t2);}

/* k3895 in k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3897(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3897,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_3900,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,lf[194],t1);}

/* k3898 in k3895 in k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3900(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3900,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3903,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
/* display */
((C_proc4)C_retrieve_proc(*((C_word*)lf[193]+1)))(4,*((C_word*)lf[193]+1),t2,((C_word*)t0)[2],((C_word*)t0)[3]);}

/* k3901 in k3898 in k3895 in k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3903(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3903,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3906,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* write-char/port */
t3=C_retrieve(lf[192]);
((C_proc4)(void*)(*((C_word*)t3+1)))(4,t3,t2,C_make_character(39),((C_word*)t0)[2]);}

/* k3904 in k3901 in k3898 in k3895 in k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3906(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3906,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3909,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* get-output-string */
((C_proc3)C_retrieve_symbol_proc(lf[191]))(3,*((C_word*)lf[191]+1),t2,((C_word*)t0)[2]);}

/* k3907 in k3904 in k3901 in k3898 in k3895 in k3891 in a3884 in a3878 in a3872 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print-error-message */
((C_proc5)C_retrieve_symbol_proc(lf[120]))(5,*((C_word*)lf[120]+1),((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3866 in k3863 in g845 in loop838 in a3846 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3868(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g851852 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* a3841 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3842(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3842,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[3])+1,C_retrieve(lf[190]));
t3=C_mutate((C_word*)lf[190]+1 /* (set! ##sys#warnings-enabled ...) */,((C_word*)((C_word*)t0)[2])[1]);
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,C_SCHEME_UNDEFINED);}

/* k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3628(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3628,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3631,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[189]);}

/* k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3631(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3631,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3634,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3695,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3719,tmp=(C_word)a,a+=2,tmp);
/* append-map */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t3,t4,C_retrieve(lf[188]));}

/* a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3719(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_3719,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3726,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* ##sys#module-name */
((C_proc3)C_retrieve_symbol_proc(lf[187]))(3,*((C_word*)lf[187]+1),t4,t3);}

/* k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3726(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3726,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3729,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* print* */
((C_proc4)C_retrieve_proc(*((C_word*)lf[185]+1)))(4,*((C_word*)lf[185]+1),t2,lf[186],t1);}

/* k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3729(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3729,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3734,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3740,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3740(C_word c,C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[17],*a=ab;
if(c!=5) C_bad_argc_2(c,5,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr5,(void*)f_3740,5,t0,t1,t2,t3,t4);}
t5=C_SCHEME_END_OF_LIST;
t6=(*a=C_VECTOR_TYPE|1,a[1]=t5,tmp=(C_word)a,a+=2,tmp);
t7=C_SCHEME_FALSE;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3748,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t10=C_SCHEME_UNDEFINED;
t11=(*a=C_VECTOR_TYPE|1,a[1]=t10,tmp=(C_word)a,a+=2,tmp);
t12=C_set_block_item(t11,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3798,a[2]=t6,a[3]=t11,a[4]=t8,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp));
t13=((C_word*)t11)[1];
f_3798(t13,t9,t4);}

/* loop889 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3798(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3798,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3825,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3825(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop889902 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop889902 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g905 in loop889 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static C_word C_fcall f_3825(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_car(t1);
return(C_a_i_list(&a,3,t2,lf[184],((C_word*)t0)[2]));}

/* k3746 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3748,2,t0,t1);}
t2=C_SCHEME_END_OF_LIST;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_SCHEME_FALSE;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3752,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t7=C_SCHEME_UNDEFINED;
t8=(*a=C_VECTOR_TYPE|1,a[1]=t7,tmp=(C_word)a,a+=2,tmp);
t9=C_set_block_item(t8,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3754,a[2]=t3,a[3]=t8,a[4]=t5,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp));
t10=((C_word*)t8)[1];
f_3754(t10,t6,((C_word*)t0)[2]);}

/* loop913 in k3746 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3754(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(15);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_3754,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3781,a[2]=((C_word*)t0)[5],tmp=(C_word)a,a+=3,tmp);
t4=C_slot(t2,C_fix(0));
t5=f_3781(C_a_i(&a,9),t3,t4);
t6=C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[4])[1])){
t7=C_i_setslot(((C_word*)((C_word*)t0)[4])[1],C_fix(1),t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop913926 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}
else{
t7=C_mutate(((C_word *)((C_word*)t0)[2])+1,t6);
t8=C_mutate(((C_word *)((C_word*)t0)[4])+1,t6);
t9=C_slot(t2,C_fix(1));
/* loop913926 */
t15=t1;
t16=t9;
t1=t15;
t2=t16;
goto loop;}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* g929 in loop913 in k3746 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static C_word C_fcall f_3781(C_word *a,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_stack_check;
t2=C_i_car(t1);
return(C_a_i_list(&a,3,t2,lf[183],((C_word*)t0)[2]));}

/* k3750 in k3746 in a3739 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3752(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* a3733 in k3727 in k3724 in a3718 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3734(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3734,2,t0,t1);}
/* ##sys#module-exports */
((C_proc3)C_retrieve_symbol_proc(lf[182]))(3,*((C_word*)lf[182]+1),t1,((C_word*)t0)[2]);}

/* k3693 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3695(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[2],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3695,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3697,tmp=(C_word)a,a+=2,tmp);
/* sort */
((C_proc4)C_retrieve_symbol_proc(lf[181]))(4,*((C_word*)lf[181]+1),((C_word*)t0)[2],t1,t2);}

/* a3696 in k3693 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3697(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3697,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3705,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t5=C_i_car(t2);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[180]+1)))(3,*((C_word*)lf[180]+1),t4,t5);}

/* k3703 in a3696 in k3693 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3705(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3705,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3709,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* symbol->string */
((C_proc3)C_retrieve_proc(*((C_word*)lf[180]+1)))(3,*((C_word*)lf[180]+1),t2,t3);}

/* k3707 in k3703 in a3696 in k3693 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3709(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string<? */
((C_proc4)C_retrieve_proc(*((C_word*)lf[179]+1)))(4,*((C_word*)lf[179]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3634(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3634,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_3637,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[173]+1)))(2,*((C_word*)lf[173]+1),t2);}

/* k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3637(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3637,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3640,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3656,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* with-output-to-file */
((C_proc4)C_retrieve_symbol_proc(lf[178]))(4,*((C_word*)lf[178]+1),t2,((C_word*)t0)[3],t3);}

/* a3655 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3656(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3656,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3662,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_3662(t5,t1,((C_word*)t0)[2]);}

/* loop940 in a3655 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3662(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3662,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3680,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3674,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* write */
((C_proc3)C_retrieve_proc(*((C_word*)lf[177]+1)))(3,*((C_word*)lf[177]+1),t5,t4);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k3672 in loop940 in a3655 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3674(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* newline */
((C_proc2)C_retrieve_proc(*((C_word*)lf[173]+1)))(2,*((C_word*)lf[173]+1),((C_word*)t0)[2]);}

/* k3678 in loop940 in a3655 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3680(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_3662(t3,((C_word*)t0)[2],t2);}

/* k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3640(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3640,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3643,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3650,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3654,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* repository-path */
((C_proc2)C_retrieve_symbol_proc(lf[176]))(2,*((C_word*)lf[176]+1),t4);}

/* k3652 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3654(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[0],"main#constant161"));}

/* k3648 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3650(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#copy-file */
((C_proc4)C_retrieve_symbol_proc(lf[175]))(4,*((C_word*)lf[175]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k3641 in k3638 in k3635 in k3632 in k3629 in k3626 in k3623 in k3620 in k3617 in k3614 in k3611 in loop in k4167 in k4164 in k5168 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k5161 in a5158 in a5152 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5163(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#cleanup */
f_3594(((C_word*)t0)[2]);}

/* a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5120(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_5120,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5126,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k11861190 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5126,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5130,a[2]=((C_word*)t0)[2],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5151,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[172]))(2,*((C_word*)lf[172]+1),t3);}

/* k5149 in a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5151(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* newline */
((C_proc3)C_retrieve_proc(*((C_word*)lf[173]+1)))(3,*((C_word*)lf[173]+1),((C_word*)t0)[2],t1);}

/* k5128 in a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5130(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5130,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5133,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_5147,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
/* current-error-port */
((C_proc2)C_retrieve_symbol_proc(lf[172]))(2,*((C_word*)lf[172]+1),t3);}

/* k5145 in k5128 in a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5147(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print-error-message */
((C_proc4)C_retrieve_symbol_proc(lf[120]))(4,*((C_word*)lf[120]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k5131 in k5128 in a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5133(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5133,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5136,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* main#cleanup */
f_3594(t2);}

/* k5134 in k5131 in k5128 in a5125 in a5119 in a5113 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5136(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(C_retrieve2(lf[19],"main#*running-test*"))){
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(2));}
else{
/* exit */
((C_proc3)C_retrieve_symbol_proc(lf[171]))(3,*((C_word*)lf[171]+1),((C_word*)t0)[2],C_fix(1));}}

/* k5101 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5103,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5106,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* g11881189 */
t3=t1;
((C_proc2)C_retrieve_proc(t3))(2,t3,t2);}

/* k5104 in k5101 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5106(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_5106,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5109,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_5112,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* ##sys#implicit-exit-handler */
((C_proc2)C_retrieve_symbol_proc(lf[170]))(2,*((C_word*)lf[170]+1),t3);}

/* k5110 in k5104 in k5101 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k5107 in k5104 in k5101 in k5098 in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_5109(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}

/* main#setup-proxy in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4129(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4129,NULL,2,t1,t2);}
if(C_truep(C_i_stringp(t2))){
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4139,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* string-match */
((C_proc4)C_retrieve_symbol_proc(lf[168]))(4,*((C_word*)lf[168]+1),t3,lf[169],t2);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4137 in main#setup-proxy in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4139(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4139,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_cadr(t3);
t5=C_mutate(&lf[17] /* (set! main#*proxy-host* ...) */,t4);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4152,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t7=C_i_caddr(t3);
/* string->number */
C_string_to_number(3,0,t6,t7);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_UNDEFINED);}}

/* k4150 in k4137 in main#setup-proxy in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4152(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_mutate(&lf[18] /* (set! main#*proxy-port* ...) */,t1);
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}

/* main#command in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4108(C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4108,NULL,3,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4112,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
C_apply(5,0,t4,*((C_word*)lf[166]+1),t2,t3);}

/* k4110 in main#command in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4112(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4112,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4115,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),t2,lf[165],t1);}

/* k4113 in k4110 in main#command in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4115(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#$system */
f_4086(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* main#$system in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4086(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4086,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4090,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4103,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[16],"main#*windows-shell*"))){
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,lf[162],t2,lf[163]);}
else{
t5=t2;
/* system */
((C_proc3)C_retrieve_symbol_proc(lf[161]))(3,*((C_word*)lf[161]+1),t3,t5);}}

/* k4101 in main#$system in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4103(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* system */
((C_proc3)C_retrieve_symbol_proc(lf[161]))(3,*((C_word*)lf[161]+1),((C_word*)t0)[2],t1);}

/* k4088 in main#$system in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4090(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
if(C_truep(C_i_zerop(t1))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
/* error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),((C_word*)t0)[3],lf[160],t1,((C_word*)t0)[2]);}}

/* main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3978(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[13],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3978,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|1,a[1]=(C_word)f_3981,tmp=(C_word)a,a+=2,tmp);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_3996,a[2]=t3,a[3]=t2,a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4009,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_4011,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
/* append-map */
((C_proc4)C_retrieve_symbol_proc(lf[158]))(4,*((C_word*)lf[158]+1),t5,t6,t2);}

/* a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4011(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4011,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4015,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4070,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* find */
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t3,t4,C_retrieve2(lf[20],"main#*mappings*"));}

/* a4069 in a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4070(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4070,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_4076,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(t2);
/* find */
((C_proc4)C_retrieve_symbol_proc(lf[157]))(4,*((C_word*)lf[157]+1),t1,t3,t4);}

/* a4075 in a4069 in a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4076(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word *a;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_4076,3,t0,t1,t2);}
/* g976977 */
t3=((C_word*)t0)[3];
f_3981(4,t3,t1,((C_word*)t0)[2],t2);}

/* k4013 in a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4015(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4015,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=t1;
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=C_i_cdr(t3);
t9=C_SCHEME_UNDEFINED;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_set_block_item(t10,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_4029,a[2]=t5,a[3]=t10,a[4]=t7,tmp=(C_word)a,a+=5,tmp));
t12=((C_word*)t10)[1];
f_4029(t12,t2,t8);}
else{
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_a_i_list(&a,1,((C_word*)t0)[2]));}}

/* loop983 in k4013 in a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_4029(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_4029,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=C_retrieve(lf[41]);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_4058,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t5=C_slot(t2,C_fix(0));
/* g9991000 */
t6=t3;
((C_proc3)C_retrieve_proc(t6))(3,t6,t4,t5);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k4056 in loop983 in k4013 in a4010 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4058(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_4058,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop983996 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4029(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop983996 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_4029(t6,((C_word*)t0)[3],t5);}}

/* k4007 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4009(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* delete-duplicates */
((C_proc4)C_retrieve_symbol_proc(lf[155]))(4,*((C_word*)lf[155]+1),((C_word*)t0)[2],t1,*((C_word*)lf[156]+1));}

/* k3994 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3996(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3996,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3999,a[2]=t1,a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_4002,a[2]=((C_word*)t0)[3],a[3]=t2,a[4]=t1,a[5]=((C_word*)t0)[4],tmp=(C_word)a,a+=6,tmp);
/* lset= */
((C_proc5)C_retrieve_symbol_proc(lf[154]))(5,*((C_word*)lf[154]+1),t3,((C_word*)t0)[2],((C_word*)t0)[3],t1);}

/* k4000 in k3994 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_4002(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[5];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[4]);}
else{
/* print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[33]+1)))(6,*((C_word*)lf[33]+1),((C_word*)t0)[3],lf[152],((C_word*)t0)[2],lf[153],((C_word*)t0)[4]);}}

/* k3997 in k3994 in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3999(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,((C_word*)t0)[2]);}

/* same? in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3981(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_3981,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3989,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t4,t2);}

/* k3987 in same? in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_3989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_3993,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}

/* k3991 in k3987 in same? in main#apply-mappings in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_i_string_equal_p(((C_word*)t0)[2],t1));}

/* main#cleanup in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_3594(C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_3594,NULL,1,t1);}
if(C_truep(C_retrieve2(lf[5],"main#*keep*"))){
t2=C_SCHEME_UNDEFINED;
t3=t1;
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_3601,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
/* setup-download#temporary-directory */
((C_proc2)C_retrieve_symbol_proc(lf[151]))(2,*((C_word*)lf[151]+1),t2);}}

/* k3599 in main#cleanup in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_3601(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* setup-api#remove-directory */
((C_proc3)C_retrieve_symbol_proc(lf[150]))(3,*((C_word*)lf[150]+1),((C_word*)t0)[2],t1);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2486(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2486,NULL,2,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2490,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[148]);}

/* k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2490(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2490,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2493,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2760,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2760(t6,t2,((C_word*)t0)[2]);}

/* loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2760(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2760,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2838,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_assoc(t4,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2785,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* delete */
((C_proc5)C_retrieve_symbol_proc(lf[111]))(5,*((C_word*)lf[111]+1),t6,t5,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"),*((C_word*)lf[112]+1));}
else{
t6=C_i_pairp(t4);
t7=(C_truep(t6)?C_i_car(t4):t4);
t8=C_i_pairp(t4);
t9=(C_truep(t8)?C_i_cdr(t4):C_SCHEME_FALSE);
t10=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2799,a[2]=t9,a[3]=t7,tmp=(C_word)a,a+=4,tmp);
t11=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2805,a[2]=t7,tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t3,t10,t11);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* a2804 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2805(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[6],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2805,4,t0,t1,t2,t3);}
t4=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2809,a[2]=t1,a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[2],tmp=(C_word)a,a+=6,tmp);
if(C_truep(t2)){
t5=t4;
f_2809(2,t5,C_SCHEME_UNDEFINED);}
else{
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),t4,lf[147]);}}

/* k2807 in a2804 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2809(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2809,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2812,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],tmp=(C_word)a,a+=6,tmp);
/* print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[33]+1)))(6,*((C_word*)lf[33]+1),t2,lf[145],((C_word*)t0)[5],lf[146],((C_word*)t0)[4]);}

/* k2810 in k2807 in a2804 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2812(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2812,2,t0,t1);}
t2=C_a_i_list(&a,3,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));
t4=C_mutate(&lf[46] /* (set! main#*eggs+dirs+vers* ...) */,t3);
t5=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}

/* a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2799(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[18],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2799,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2323,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
t3=(C_truep(C_retrieve2(lf[13],"main#*default-location*"))?C_retrieve2(lf[14],"main#*default-transport*"):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1790,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1794,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1797,a[2]=t4,a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=C_eqp(C_retrieve2(lf[14],"main#*default-transport*"),lf[143]);
if(C_truep(t7)){
t8=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1814,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* absolute-pathname? */
((C_proc3)C_retrieve_symbol_proc(lf[144]))(3,*((C_word*)lf[144]+1),t8,C_retrieve2(lf[13],"main#*default-location*"));}
else{
t8=t6;
f_1797(t8,C_SCHEME_FALSE);}}
else{
t4=C_retrieve2(lf[12],"main#*default-sources*");
t5=t2;
f_2323(t5,t4);}}

/* k1812 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1814(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1797(t2,C_i_not(t1));}

/* k1795 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1797(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1797,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1804,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t2);}
else{
t2=C_retrieve2(lf[13],"main#*default-location*");
t3=((C_word*)t0)[2];
f_1790(t3,C_a_i_cons(&a,2,t2,C_SCHEME_END_OF_LIST));}}

/* k1802 in k1795 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1804(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* make-pathname */
((C_proc4)C_retrieve_symbol_proc(lf[109]))(4,*((C_word*)lf[109]+1),((C_word*)t0)[2],t1,C_retrieve2(lf[13],"main#*default-location*"));}

/* k1792 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1794(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1794,2,t0,t1);}
t2=((C_word*)t0)[2];
f_1790(t2,C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST));}

/* k1788 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1790(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1790,NULL,2,t0,t1);}
t2=C_a_i_cons(&a,2,lf[141],t1);
t3=C_a_i_cons(&a,2,C_retrieve2(lf[14],"main#*default-transport*"),C_SCHEME_END_OF_LIST);
t4=C_a_i_cons(&a,2,lf[139],t3);
t5=C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST);
t6=C_a_i_cons(&a,2,t2,t5);
t7=((C_word*)t0)[2];
f_2323(t7,C_a_i_cons(&a,2,t6,C_SCHEME_END_OF_LIST));}

/* k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2323(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2323,NULL,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2325,a[2]=t3,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2325(t5,((C_word*)t0)[2],t1);}

/* trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2325(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2325,NULL,3,t0,t1,t2);}
if(C_truep(C_i_nullp(t2))){
/* values */
C_values(4,0,t1,C_SCHEME_FALSE,lf[113]);}
else{
t3=C_i_car(t2);
t4=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2341,a[2]=t1,a[3]=t3,a[4]=((C_word*)t0)[2],a[5]=t2,a[6]=((C_word*)t0)[3],a[7]=((C_word*)t0)[4],tmp=(C_word)a,a+=8,tmp);
t5=C_i_assq(lf[141],t3);
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2393,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t5)){
t7=C_i_cadr(t5);
/* main#resolve-location */
f_1733(t4,t7);}
else{
/* error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t6,lf[142],t3);}}}

/* k2391 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2393(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_i_cadr(t1);
/* main#resolve-location */
f_1733(((C_word*)t0)[2],t2);}

/* k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2341(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2341,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|8,a[1]=(C_word)f_2344,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],a[8]=t1,tmp=(C_word)a,a+=9,tmp);
t3=C_i_assq(lf[139],((C_word*)t0)[3]);
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2379,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
if(C_truep(t3)){
t5=t2;
f_2344(t5,C_i_cadr(t3));}
else{
/* error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t4,lf[140],((C_word*)t0)[3]);}}

/* k2377 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2379(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_2344(t2,C_i_cadr(t1));}

/* k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2344(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2344,NULL,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2349,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],a[4]=((C_word*)t0)[8],a[5]=t1,tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2355,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2354 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2355(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2355,4,t0,t1,t2,t3);}
if(C_truep(t2)){
/* values */
C_values(4,0,t1,t2,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_1821,a[2]=t1,a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
/* delete */
((C_proc5)C_retrieve_symbol_proc(lf[111]))(5,*((C_word*)lf[111]+1),t4,((C_word*)t0)[2],C_retrieve2(lf[12],"main#*default-sources*"),*((C_word*)lf[112]+1));}}

/* k1819 in a2354 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1821(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word *a;
t2=C_mutate(&lf[12] /* (set! main#*default-sources* ...) */,t1);
t3=C_i_cdr(((C_word*)t0)[4]);
/* trying-sources410 */
t4=((C_word*)((C_word*)t0)[3])[1];
f_2325(t4,((C_word*)t0)[2],t3);}

/* a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2349(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2349,2,t0,t1);}
t2=((C_word*)t0)[5];
t3=((C_word*)t0)[4];
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2186,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t5=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2191,a[2]=((C_word*)t0)[2],a[3]=t3,a[4]=t2,a[5]=((C_word*)t0)[3],tmp=(C_word)a,a+=6,tmp);
/* call-with-current-continuation */
((C_proc3)C_retrieve_proc(*((C_word*)lf[138]+1)))(3,*((C_word*)lf[138]+1),t4,t5);}

/* a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2191(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[10],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2191,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2197,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t4=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2284,a[2]=t2,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],a[5]=((C_word*)t0)[4],a[6]=((C_word*)t0)[5],tmp=(C_word)a,a+=7,tmp);
/* with-exception-handler */
((C_proc4)C_retrieve_symbol_proc(lf[137]))(4,*((C_word*)lf[137]+1),t1,t3,t4);}

/* a2283 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2284(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[9],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2284,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2290,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2303,a[2]=((C_word*)t0)[2],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,t1,t2,t3);}

/* a2302 in a2283 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2303(C_word c,C_word t0,C_word t1,...){
C_word tmp;
C_word t2;
va_list v;
C_word *a,c2=c;
C_save_rest(t1,c2,2);
C_check_for_interrupt;
if(!C_demand(c*C_SIZEOF_PAIR+3)){
C_save_and_reclaim((void*)tr2r,(void*)f_2303r,2,t0,t1);}
else{
a=C_alloc((c-2)*3);
t2=C_restore_rest(a,C_rest_count(0));
f_2303r(t0,t1,t2);}}

static void C_ccall f_2303r(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word *a=C_alloc(3);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2309,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k383387 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2308 in a2302 in a2283 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2309(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2309,2,t0,t1);}
C_apply_values(3,0,t1,((C_word*)t0)[2]);}

/* a2289 in a2283 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2290(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[7],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2290,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2298,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=t1,tmp=(C_word)a,a+=7,tmp);
if(C_truep(C_retrieve2(lf[8],"main#*retrieve-only*"))){
/* current-directory */
((C_proc2)C_retrieve_symbol_proc(lf[136]))(2,*((C_word*)lf[136]+1),t2);}
else{
t3=t2;
f_2298(2,t3,C_SCHEME_FALSE);}}

/* k2296 in a2289 in a2283 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2298(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-download#retrieve-extension */
((C_proc21)C_retrieve_symbol_proc(lf[127]))(21,*((C_word*)lf[127]+1),((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],lf[128],((C_word*)t0)[2],lf[129],t1,lf[130],C_retrieve2(lf[7],"main#*run-tests*"),lf[131],C_retrieve2(lf[10],"main#*username*"),lf[132],C_retrieve2(lf[11],"main#*password*"),lf[133],C_retrieve2(lf[22],"main#*trunk*"),lf[134],C_retrieve2(lf[17],"main#*proxy-host*"),lf[135],C_retrieve2(lf[18],"main#*proxy-port*"));}

/* a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2197(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2197,3,t0,t1,t2);}
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2203,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* k383387 */
t4=((C_word*)t0)[2];
((C_proc3)C_retrieve_proc(t4))(3,t4,t1,t3);}

/* a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2203(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2203,2,t0,t1);}
t2=C_i_structurep(((C_word*)t0)[2],lf[114]);
t3=(C_truep(t2)?C_slot(((C_word*)t0)[2],C_fix(1)):C_SCHEME_FALSE);
t4=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2213,a[2]=t3,a[3]=((C_word*)t0)[2],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
if(C_truep(t3)){
t5=C_i_memv(lf[123],t3);
t6=t4;
f_2213(t6,(C_truep(t5)?C_i_memv(lf[126],t3):C_SCHEME_FALSE));}
else{
t5=t4;
f_2213(t5,C_SCHEME_FALSE);}}

/* k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2213(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2213,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2216,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[116]);}
else{
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2225,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_memv(lf[123],((C_word*)t0)[2]);
t4=t2;
f_2225(t4,(C_truep(t3)?C_i_memv(lf[125],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2225(t3,C_SCHEME_FALSE);}}}

/* k2223 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2225(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2225,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2228,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t2,lf[118]);}
else{
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2237,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
if(C_truep(((C_word*)t0)[2])){
t3=C_i_memv(lf[123],((C_word*)t0)[2]);
t4=t2;
f_2237(t4,(C_truep(t3)?C_i_memv(lf[124],((C_word*)t0)[2]):C_SCHEME_FALSE));}
else{
t3=t2;
f_2237(t3,C_SCHEME_FALSE);}}}

/* k2235 in k2223 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2237(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2237,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[3];
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2240,a[2]=t2,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc3)C_retrieve_proc(*((C_word*)lf[33]+1)))(3,*((C_word*)lf[33]+1),t3,lf[121]);}
else{
t2=((C_word*)t0)[3];
/* abort */
((C_proc3)C_retrieve_symbol_proc(lf[122]))(3,*((C_word*)lf[122]+1),((C_word*)t0)[2],t2);}}

/* k2238 in k2235 in k2223 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2240(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2240,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2243,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* print-error-message */
((C_proc3)C_retrieve_symbol_proc(lf[120]))(3,*((C_word*)lf[120]+1),t2,((C_word*)t0)[2]);}

/* k2241 in k2238 in k2235 in k2223 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2243(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[119]);}

/* k2226 in k2223 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2228(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[117]);}

/* k2214 in k2211 in a2202 in a2196 in a2190 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2216(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* values */
C_values(4,0,((C_word*)t0)[2],C_SCHEME_FALSE,lf[115]);}

/* k2184 in a2348 in k2342 in k2339 in trying-sources in k2321 in a2798 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2186(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* g385386 */
t2=t1;
((C_proc2)C_retrieve_proc(t2))(2,t2,((C_word*)t0)[2]);}

/* k2783 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2785(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2785,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[5],t1);
t3=C_mutate(&lf[46] /* (set! main#*eggs+dirs+vers* ...) */,t2);
t4=C_slot(((C_word*)t0)[4],C_fix(1));
t5=((C_word*)((C_word*)t0)[3])[1];
f_2760(t5,((C_word*)t0)[2],t4);}

/* k2836 in loop461 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2838(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2760(t3,((C_word*)t0)[2],t2);}

/* k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2493(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2493,2,t0,t1);}
if(C_truep(C_retrieve2(lf[8],"main#*retrieve-only*"))){
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}
else{
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2501,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_2501(t5,((C_word*)t0)[2],C_retrieve2(lf[46],"main#*eggs+dirs+vers*"));}}

/* loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2501(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word *a;
loop:
a=C_alloc(12);
C_check_for_interrupt;
if(!C_stack_probe(a)){
C_save_and_reclaim((void*)trf_2501,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2747,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
if(C_truep(C_i_member(t5,C_retrieve2(lf[48],"main#*checked*")))){
t6=C_slot(t2,C_fix(1));
t15=t1;
t16=t6;
t1=t15;
t2=t16;
goto loop;}
else{
t6=C_i_car(t4);
t7=C_a_i_cons(&a,2,t6,C_retrieve2(lf[48],"main#*checked*"));
t8=C_mutate(&lf[48] /* (set! main#*checked* ...) */,t7);
t9=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2523,a[2]=t3,a[3]=t4,tmp=(C_word)a,a+=4,tmp);
t10=C_i_cadr(t4);
t11=C_i_car(t4);
/* make-pathname */
((C_proc5)C_retrieve_symbol_proc(lf[109]))(5,*((C_word*)lf[109]+1),t9,t10,t11,lf[110]);}}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2523(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2523,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2529,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=((C_word*)t0)[3],tmp=(C_word)a,a+=5,tmp);
/* file-exists? */
((C_proc3)C_retrieve_symbol_proc(lf[108]))(3,*((C_word*)lf[108]+1),t2,t1);}

/* k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2529(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2529,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2532,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
/* with-input-from-file */
((C_proc4)C_retrieve_symbol_proc(lf[103]))(4,*((C_word*)lf[103]+1),t2,((C_word*)t0)[2],*((C_word*)lf[104]+1));}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2724,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t3=C_i_car(((C_word*)t0)[4]);
/* string-append */
((C_proc6)C_retrieve_proc(*((C_word*)lf[55]+1)))(6,*((C_word*)lf[55]+1),t2,lf[105],t3,lf[106],lf[107]);}}

/* k2722 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2724(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* warning */
((C_proc3)C_retrieve_symbol_proc(lf[59]))(3,*((C_word*)lf[59]+1),((C_word*)t0)[2],t1);}

/* k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2532(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2532,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2535,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t1,tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,lf[101],t3,lf[102]);}

/* k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2535(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2535,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2538,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
t4=((C_word*)t0)[4];
t5=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2854,a[2]=t3,tmp=(C_word)a,a+=3,tmp);
if(C_truep(C_retrieve2(lf[27],"main#*cross-chicken*"))){
t6=C_SCHEME_UNDEFINED;
t7=t2;
f_2538(2,t7,t6);}
else{
t6=C_i_assq(lf[92],t4);
if(C_truep(t6)){
t7=C_i_cadr(t6);
t8=C_SCHEME_UNDEFINED;
t9=(*a=C_VECTOR_TYPE|1,a[1]=t8,tmp=(C_word)a,a+=2,tmp);
t10=C_set_block_item(t9,0,(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2876,a[2]=t3,a[3]=t6,a[4]=t9,a[5]=t5,tmp=(C_word)a,a+=6,tmp));
t11=((C_word*)t9)[1];
f_2876(3,t11,t2,t7);}
else{
t7=t2;
f_2538(2,t7,C_SCHEME_FALSE);}}}

/* loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2876(C_word c,C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[8],*a=ab;
if(c!=3) C_bad_argc_2(c,3,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr3,(void*)f_2876,3,t0,t1,t2);}
if(C_truep(C_i_symbolp(t2))){
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2886,a[2]=((C_word*)t0)[5],a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* feature? */
((C_proc3)C_retrieve_symbol_proc(lf[93]))(3,*((C_word*)lf[93]+1),t3,t2);}
else{
if(C_truep(C_i_listp(t2))){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2911,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=t2,a[6]=((C_word*)t0)[5],a[7]=t1,tmp=(C_word)a,a+=8,tmp);
t4=C_i_car(t2);
t5=C_eqp(lf[99],t4);
if(C_truep(t5)){
t6=C_i_cdr(t2);
t7=t3;
f_2911(t7,C_i_pairp(t6));}
else{
t6=t3;
f_2911(t6,C_SCHEME_FALSE);}}
else{
t3=C_i_cadr(((C_word*)t0)[3]);
/* error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),t1,lf[100],((C_word*)t0)[2],t3);}}}

/* k2909 in loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2911(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2911,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2924,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t3=C_i_cadr(((C_word*)t0)[5]);
/* loop581 */
t4=((C_word*)((C_word*)t0)[4])[1];
f_2876(3,t4,t2,t3);}
else{
t2=C_i_car(((C_word*)t0)[5]);
t3=C_eqp(lf[94],t2);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2940,a[2]=((C_word*)t0)[7],a[3]=((C_word*)t0)[6],tmp=(C_word)a,a+=4,tmp);
t5=C_i_cdr(((C_word*)t0)[5]);
/* every */
((C_proc4)C_retrieve_symbol_proc(lf[95]))(4,*((C_word*)lf[95]+1),t4,((C_word*)((C_word*)t0)[4])[1],t5);}
else{
t4=C_i_car(((C_word*)t0)[5]);
t5=C_eqp(lf[96],t4);
if(C_truep(t5)){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2966,a[2]=((C_word*)t0)[6],a[3]=((C_word*)t0)[7],tmp=(C_word)a,a+=4,tmp);
t7=C_i_cdr(((C_word*)t0)[5]);
/* any */
((C_proc4)C_retrieve_symbol_proc(lf[97]))(4,*((C_word*)lf[97]+1),t6,((C_word*)((C_word*)t0)[4])[1],t7);}
else{
t6=C_i_cadr(((C_word*)t0)[3]);
/* error */
((C_proc5)C_retrieve_proc(*((C_word*)lf[54]+1)))(5,*((C_word*)lf[54]+1),((C_word*)t0)[7],lf[98],((C_word*)t0)[2],t6);}}}}

/* k2964 in k2909 in loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2966(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* fail579 */
t2=((C_word*)t0)[2];
f_2854(t2,((C_word*)t0)[3]);}}

/* k2938 in k2909 in loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2940(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
/* fail579 */
t2=((C_word*)t0)[3];
f_2854(t2,((C_word*)t0)[2]);}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* k2922 in k2909 in loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2924(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}
else{
/* fail579 */
t2=((C_word*)t0)[2];
f_2854(t2,((C_word*)t0)[3]);}}

/* k2884 in loop in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2886(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,t1);}
else{
/* fail579 */
t2=((C_word*)t0)[2];
f_2854(t2,((C_word*)t0)[3]);}}

/* fail in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2854(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2854,NULL,2,t0,t1);}
/* error */
((C_proc4)C_retrieve_proc(*((C_word*)lf[54]+1)))(4,*((C_word*)lf[54]+1),t1,lf[91],((C_word*)t0)[2]);}

/* k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2538(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2538,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2541,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_car(((C_word*)t0)[3]);
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t2,lf[89],t3,lf[90]);}

/* k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2541(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[6],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2541,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2546,a[2]=((C_word*)t0)[4],tmp=(C_word)a,a+=3,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2552,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* ##sys#call-with-values */
C_call_with_values(4,0,((C_word*)t0)[2],t2,t3);}

/* a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2552(C_word c,C_word t0,C_word t1,C_word t2,C_word t3){
C_word tmp;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[8],*a=ab;
if(c!=4) C_bad_argc_2(c,4,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr4,(void*)f_2552,4,t0,t1,t2,t3);}
t4=t2;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2557,a[2]=t3,a[3]=t1,a[4]=((C_word*)t0)[2],a[5]=t5,tmp=(C_word)a,a+=6,tmp);
/* main#apply-mappings */
f_3978(t6,((C_word*)t5)[1]);}

/* k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2557(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word ab[16],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2557,2,t0,t1);}
t2=C_mutate(((C_word *)((C_word*)t0)[5])+1,t1);
t3=C_i_car(((C_word*)t0)[4]);
t4=C_SCHEME_END_OF_LIST;
t5=(*a=C_VECTOR_TYPE|1,a[1]=t4,tmp=(C_word)a,a+=2,tmp);
t6=C_SCHEME_FALSE;
t7=(*a=C_VECTOR_TYPE|1,a[1]=t6,tmp=(C_word)a,a+=2,tmp);
t8=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2655,a[2]=((C_word*)t0)[5],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[2],a[5]=((C_word*)t0)[3],a[6]=t3,tmp=(C_word)a,a+=7,tmp);
t9=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2659,a[2]=t8,a[3]=t5,a[4]=t7,tmp=(C_word)a,a+=5,tmp);
/* append */
((C_proc4)C_retrieve_proc(*((C_word*)lf[64]+1)))(4,*((C_word*)lf[64]+1),t9,((C_word*)((C_word*)t0)[5])[1],((C_word*)t0)[2]);}

/* k2657 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2659(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2659,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2661,a[2]=((C_word*)t0)[3],a[3]=t3,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp));
t5=((C_word*)t3)[1];
f_2661(t5,((C_word*)t0)[2],t1);}

/* loop521 in k2657 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2661(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[10],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2661,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2671,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
if(C_truep(C_i_pairp(t4))){
t5=C_i_car(t4);
t6=t3;
f_2671(t6,C_a_i_cons(&a,2,t5,C_SCHEME_END_OF_LIST));}
else{
t5=t3;
f_2671(t5,C_a_i_cons(&a,2,t4,C_SCHEME_END_OF_LIST));}}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2669 in loop521 in k2657 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2671(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word *a;
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t2=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop521534 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2661(t5,((C_word*)t0)[3],t4);}
else{
t2=C_mutate(((C_word *)((C_word*)t0)[2])+1,t1);
t3=C_mutate(((C_word *)((C_word*)t0)[6])+1,t1);
t4=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop521534 */
t5=((C_word*)((C_word*)t0)[4])[1];
f_2661(t5,((C_word*)t0)[3],t4);}}

/* k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2655(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[18],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2655,2,t0,t1);}
t2=C_a_i_cons(&a,2,((C_word*)t0)[6],t1);
t3=C_a_i_cons(&a,2,t2,C_retrieve2(lf[47],"main#*dependencies*"));
t4=C_mutate(&lf[47] /* (set! main#*dependencies* ...) */,t3);
t5=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2564,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],tmp=(C_word)a,a+=5,tmp);
if(C_truep(C_i_pairp(((C_word*)((C_word*)t0)[2])[1]))){
t6=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2636,a[2]=((C_word*)t0)[2],a[3]=t5,tmp=(C_word)a,a+=4,tmp);
t7=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2643,a[2]=t6,tmp=(C_word)a,a+=3,tmp);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t7,((C_word*)((C_word*)t0)[2])[1],lf[87]);}
else{
t6=t5;
f_2564(2,t6,C_SCHEME_UNDEFINED);}}

/* k2641 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2643(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[2],lf[86],t1);}

/* k2634 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2636(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#retrieve */
f_2486(((C_word*)t0)[3],((C_word*)((C_word*)t0)[2])[1]);}

/* k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2564(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word t17;
C_word ab[34],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2564,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2570,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],tmp=(C_word)a,a+=4,tmp);
if(C_truep(C_i_pairp(((C_word*)t0)[3]))){
t3=C_retrieve2(lf[6],"main#*force*");
if(C_truep(t3)){
t4=t2;
f_2570(2,t4,t3);}
else{
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2630,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
t5=((C_word*)t0)[3];
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2406,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
t7=C_i_car(((C_word*)t0)[2]);
t8=C_a_i_list(&a,3,lf[77],t7,lf[78]);
t9=C_SCHEME_END_OF_LIST;
t10=(*a=C_VECTOR_TYPE|1,a[1]=t9,tmp=(C_word)a,a+=2,tmp);
t11=C_SCHEME_FALSE;
t12=(*a=C_VECTOR_TYPE|1,a[1]=t11,tmp=(C_word)a,a+=2,tmp);
t13=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2414,a[2]=t8,a[3]=t6,tmp=(C_word)a,a+=4,tmp);
t14=C_SCHEME_UNDEFINED;
t15=(*a=C_VECTOR_TYPE|1,a[1]=t14,tmp=(C_word)a,a+=2,tmp);
t16=C_set_block_item(t15,0,(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2416,a[2]=t10,a[3]=t15,a[4]=t12,tmp=(C_word)a,a+=5,tmp));
t17=((C_word*)t15)[1];
f_2416(t17,t13,t5);}}
else{
t3=t2;
f_2570(2,t3,C_SCHEME_FALSE);}}

/* loop435 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2416(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2416,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2476,a[2]=((C_word*)t0)[2],a[3]=t1,a[4]=((C_word*)t0)[3],a[5]=t2,a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_slot(t2,C_fix(0));
t5=C_i_car(t4);
t6=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2469,a[2]=t5,a[3]=t3,a[4]=t4,tmp=(C_word)a,a+=5,tmp);
t7=C_i_car(t4);
/* extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t6,t7);}
else{
t3=((C_word*)((C_word*)t0)[2])[1];
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2467 in loop435 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2469(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word *a;
t2=C_i_assq(lf[40],t1);
t3=(C_truep(t2)?C_i_cadr(t2):lf[80]);
t4=C_i_cdr(((C_word*)t0)[4]);
/* conc */
((C_proc10)C_retrieve_symbol_proc(lf[81]))(10,*((C_word*)lf[81]+1),((C_word*)t0)[3],lf[82],((C_word*)t0)[2],lf[83],t3,lf[84],t4,lf[85],C_make_character(10));}

/* k2474 in loop435 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2476(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2476,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,C_SCHEME_END_OF_LIST);
if(C_truep(((C_word*)((C_word*)t0)[6])[1])){
t3=C_i_setslot(((C_word*)((C_word*)t0)[6])[1],C_fix(1),t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop435448 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2416(t6,((C_word*)t0)[3],t5);}
else{
t3=C_mutate(((C_word *)((C_word*)t0)[2])+1,t2);
t4=C_mutate(((C_word *)((C_word*)t0)[6])+1,t2);
t5=C_slot(((C_word*)t0)[5],C_fix(1));
/* loop435448 */
t6=((C_word*)((C_word*)t0)[4])[1];
f_2416(t6,((C_word*)t0)[3],t5);}}

/* k2412 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2414(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1,lf[79]);}

/* k2404 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2406(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* string-concatenate */
((C_proc3)C_retrieve_symbol_proc(lf[76]))(3,*((C_word*)lf[76]+1),((C_word*)t0)[2],t1);}

/* k2628 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2630(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* yes-or-no? */
((C_proc6)C_retrieve_symbol_proc(lf[72]))(6,*((C_word*)lf[72]+1),((C_word*)t0)[2],t1,lf[73],lf[74],C_retrieve(lf[75]));}

/* k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2570(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2570,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2573,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* unzip1 */
((C_proc3)C_retrieve_symbol_proc(lf[71]))(3,*((C_word*)lf[71]+1),t2,((C_word*)t0)[2]);}
else{
t2=C_SCHEME_UNDEFINED;
t3=((C_word*)t0)[3];
((C_proc2)(void*)(*((C_word*)t3+1)))(2,t3,t2);}}

/* k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2573(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2573,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2576,a[2]=t1,a[3]=((C_word*)t0)[2],tmp=(C_word)a,a+=4,tmp);
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2617,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* string-intersperse */
((C_proc4)C_retrieve_symbol_proc(lf[69]))(4,*((C_word*)lf[69]+1),t3,t1,lf[70]);}

/* k2615 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2617(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* print */
((C_proc4)C_retrieve_proc(*((C_word*)lf[33]+1)))(4,*((C_word*)lf[33]+1),((C_word*)t0)[2],lf[68],t1);}

/* k2574 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2576(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2576,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2579,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
t3=C_SCHEME_UNDEFINED;
t4=(*a=C_VECTOR_TYPE|1,a[1]=t3,tmp=(C_word)a,a+=2,tmp);
t5=C_set_block_item(t4,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2584,a[2]=t4,tmp=(C_word)a,a+=3,tmp));
t6=((C_word*)t4)[1];
f_2584(t6,t2,((C_word*)t0)[2]);}

/* loop551 in k2574 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2584(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[9],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2584,NULL,3,t0,t1,t2);}
if(C_truep(C_i_pairp(t2))){
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2602,a[2]=t1,a[3]=((C_word*)t0)[2],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_slot(t2,C_fix(0));
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2596,a[2]=t4,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc5)C_retrieve_proc(*((C_word*)lf[33]+1)))(5,*((C_word*)lf[33]+1),t5,lf[66],t4,lf[67]);}
else{
t3=C_SCHEME_UNDEFINED;
t4=t1;
((C_proc2)(void*)(*((C_word*)t4+1)))(2,t4,t3);}}

/* k2594 in loop551 in k2574 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2596(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#remove-extension */
((C_proc3)C_retrieve_symbol_proc(lf[65]))(3,*((C_word*)lf[65]+1),((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2600 in loop551 in k2574 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2602(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2584(t3,((C_word*)t0)[2],t2);}

/* k2577 in k2574 in k2571 in k2568 in k2562 in k2653 in k2555 in a2551 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2579(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#retrieve */
f_2486(((C_word*)t0)[3],((C_word*)t0)[2]);}

/* a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2546(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[3],*a=ab;
if(c!=2) C_bad_argc_2(c,2,t0);
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2546,2,t0,t1);}
t2=((C_word*)t0)[2];
t3=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1970,a[2]=t1,tmp=(C_word)a,a+=3,tmp);
t4=f_1823(lf[61],t2);
t5=f_1823(lf[62],t2);
if(C_truep(C_retrieve2(lf[7],"main#*run-tests*"))){
t6=f_1823(lf[63],t2);
/* append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t3,t4,t5,t6);}
else{
/* append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[64]+1)))(5,*((C_word*)lf[64]+1),t3,t4,t5,C_SCHEME_END_OF_LIST);}}

/* k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1970(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1970,2,t0,t1);}
t2=C_SCHEME_UNDEFINED;
t3=(*a=C_VECTOR_TYPE|1,a[1]=t2,tmp=(C_word)a,a+=2,tmp);
t4=C_set_block_item(t3,0,(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1975,a[2]=t3,tmp=(C_word)a,a+=3,tmp));
t5=((C_word*)t3)[1];
f_1975(t5,((C_word*)t0)[2],t1,C_SCHEME_END_OF_LIST,C_SCHEME_END_OF_LIST);}

/* loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1975(C_word t0,C_word t1,C_word t2,C_word t3,C_word t4){
C_word tmp;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word t9;
C_word t10;
C_word t11;
C_word t12;
C_word t13;
C_word t14;
C_word t15;
C_word t16;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1975,NULL,5,t0,t1,t2,t3,t4);}
if(C_truep(C_i_nullp(t2))){
t5=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1989,a[2]=t4,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),t5,t3);}
else{
t5=C_i_car(t2);
t6=C_i_cdr(t2);
t7=C_i_symbolp(t5);
t8=(C_truep(t7)?t7:C_i_stringp(t5));
if(C_truep(t8)){
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2018,a[2]=t5,a[3]=t4,a[4]=t6,a[5]=t1,a[6]=((C_word*)t0)[2],a[7]=t3,tmp=(C_word)a,a+=8,tmp);
/* main#ext-version */
f_1893(t9,t5);}
else{
t9=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2031,a[2]=t5,a[3]=t4,a[4]=t3,a[5]=t6,a[6]=t1,a[7]=((C_word*)t0)[2],tmp=(C_word)a,a+=8,tmp);
if(C_truep(C_i_listp(t5))){
t10=C_i_length(t5);
if(C_truep(C_i_nequalp(C_fix(2),t10))){
t11=C_i_car(t5);
t12=C_i_stringp(t11);
if(C_truep(t12)){
t13=t9;
f_2031(t13,t12);}
else{
t13=C_i_car(t5);
t14=t9;
f_2031(t14,C_i_symbolp(t13));}}
else{
t11=t9;
f_2031(t11,C_SCHEME_FALSE);}}
else{
t10=t9;
f_2031(t10,C_SCHEME_FALSE);}}}}

/* k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_2031(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[8],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_2031,NULL,2,t0,t1);}
if(C_truep(t1)){
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2034,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=C_i_car(((C_word*)t0)[2]);
/* main#ext-version */
f_1893(t2,t3);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2137,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* warning */
((C_proc4)C_retrieve_symbol_proc(lf[59]))(4,*((C_word*)lf[59]+1),t2,lf[60],((C_word*)t0)[2]);}}

/* k2135 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2137(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop348 */
t2=((C_word*)((C_word*)t0)[6])[1];
f_1975(t2,((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2]);}

/* k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2034(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word t8;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2034,2,t0,t1);}
t2=t1;
if(C_truep(t2)){
t3=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2122,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2126,a[2]=t1,a[3]=t3,tmp=(C_word)a,a+=4,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t4,t5);}
else{
t3=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2051,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],a[6]=((C_word*)t0)[4],tmp=(C_word)a,a+=7,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,t4);}}

/* k2049 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2051(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2051,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* loop348 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1975(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k2124 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2126(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* setup-api#version>=? */
((C_proc4)C_retrieve_symbol_proc(lf[58]))(4,*((C_word*)lf[58]+1),((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2122(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[12],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2122,2,t0,t1);}
if(C_truep(t1)){
/* loop348 */
t2=((C_word*)((C_word*)t0)[7])[1];
f_1975(t2,((C_word*)t0)[6],((C_word*)t0)[5],((C_word*)t0)[4],((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|7,a[1]=(C_word)f_2064,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=((C_word*)t0)[4],a[5]=((C_word*)t0)[5],a[6]=((C_word*)t0)[6],a[7]=((C_word*)t0)[7],tmp=(C_word)a,a+=8,tmp);
t3=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_2111,a[2]=((C_word*)t0)[2],a[3]=t2,tmp=(C_word)a,a+=4,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,t4);}}

/* k2109 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2111(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2111,2,t0,t1);}
t2=C_i_string_equal_p(lf[53],t1);
t3=(C_truep(t2)?C_i_not(C_retrieve2(lf[6],"main#*force*")):C_SCHEME_FALSE);
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_2097,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
t5=C_i_cadr(((C_word*)t0)[2]);
/* string-append */
((C_proc5)C_retrieve_proc(*((C_word*)lf[55]+1)))(5,*((C_word*)lf[55]+1),t4,lf[56],t5,lf[57]);}
else{
t4=((C_word*)t0)[3];
f_2064(2,t4,C_SCHEME_UNDEFINED);}}

/* k2095 in k2109 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2097(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* error */
((C_proc3)C_retrieve_proc(*((C_word*)lf[54]+1)))(3,*((C_word*)lf[54]+1),((C_word*)t0)[2],t1);}

/* k2062 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2064(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word ab[11],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2064,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|5,a[1]=(C_word)f_2071,a[2]=((C_word*)t0)[4],a[3]=((C_word*)t0)[5],a[4]=((C_word*)t0)[6],a[5]=((C_word*)t0)[7],tmp=(C_word)a,a+=6,tmp);
t3=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2075,a[2]=((C_word*)t0)[2],a[3]=((C_word*)t0)[3],a[4]=t2,tmp=(C_word)a,a+=5,tmp);
t4=C_i_car(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t3,t4);}

/* k2073 in k2062 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2075(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[5],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2075,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|4,a[1]=(C_word)f_2079,a[2]=((C_word*)t0)[3],a[3]=t1,a[4]=((C_word*)t0)[4],tmp=(C_word)a,a+=5,tmp);
t3=C_i_cadr(((C_word*)t0)[2]);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,t3);}

/* k2077 in k2073 in k2062 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2079(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* alist-cons */
((C_proc5)C_retrieve_symbol_proc(lf[52]))(5,*((C_word*)lf[52]+1),((C_word*)t0)[4],((C_word*)t0)[3],t1,((C_word*)t0)[2]);}

/* k2069 in k2062 in k2120 in k2032 in k2029 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2071(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* loop348 */
t2=((C_word*)((C_word*)t0)[5])[1];
f_1975(t2,((C_word*)t0)[4],((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2016 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2018(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2018,2,t0,t1);}
if(C_truep(t1)){
t2=((C_word*)t0)[7];
/* loop348 */
t3=((C_word*)((C_word*)t0)[6])[1];
f_1975(t3,((C_word*)t0)[5],((C_word*)t0)[4],t2,((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|6,a[1]=(C_word)f_2025,a[2]=((C_word*)t0)[3],a[3]=((C_word*)t0)[4],a[4]=((C_word*)t0)[5],a[5]=((C_word*)t0)[6],a[6]=((C_word*)t0)[7],tmp=(C_word)a,a+=7,tmp);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,((C_word*)t0)[2]);}}

/* k2023 in k2016 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2025(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_2025,2,t0,t1);}
t2=C_a_i_cons(&a,2,t1,((C_word*)t0)[6]);
/* loop348 */
t3=((C_word*)((C_word*)t0)[5])[1];
f_1975(t3,((C_word*)t0)[4],((C_word*)t0)[3],t2,((C_word*)t0)[2]);}

/* k1987 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1989(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)tr2,(void*)f_1989,2,t0,t1);}
t2=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1993,a[2]=t1,a[3]=((C_word*)t0)[3],tmp=(C_word)a,a+=4,tmp);
/* reverse */
((C_proc3)C_retrieve_proc(*((C_word*)lf[51]+1)))(3,*((C_word*)lf[51]+1),t2,((C_word*)t0)[2]);}

/* k1991 in k1987 in loop in k1968 in a2545 in k2539 in k2536 in k2533 in k2530 in k2527 in k2521 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1993(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* values */
C_values(4,0,((C_word*)t0)[3],((C_word*)t0)[2],t1);}

/* k2745 in loop496 in k2491 in k2488 in main#retrieve in k2178 in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_2747(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word *a;
t2=C_slot(((C_word*)t0)[4],C_fix(1));
t3=((C_word*)((C_word*)t0)[3])[1];
f_2501(t3,((C_word*)t0)[2],t2);}

/* main#ext-version in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1893(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word t7;
C_word ab[7],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1893,NULL,2,t1,t2);}
t3=C_eqp(t2,lf[38]);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1903,a[2]=t2,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
if(C_truep(t3)){
t5=t4;
f_1903(t5,t3);}
else{
t5=C_i_equalp(t2,lf[44]);
if(C_truep(t5)){
t6=t4;
f_1903(t6,t5);}
else{
t6=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1943,a[2]=t4,tmp=(C_word)a,a+=3,tmp);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t6,t2);}}}

/* k1941 in main#ext-version in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1943(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
t2=((C_word*)t0)[2];
f_1903(t2,C_i_member(t1,C_retrieve(lf[45])));}

/* k1901 in main#ext-version in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1903(C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1903,NULL,2,t0,t1);}
if(C_truep(t1)){
/* chicken-version */
((C_proc2)C_retrieve_symbol_proc(lf[39]))(2,*((C_word*)lf[39]+1),((C_word*)t0)[3]);}
else{
t2=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1909,a[2]=((C_word*)t0)[3],tmp=(C_word)a,a+=3,tmp);
/* extension-information */
((C_proc3)C_retrieve_symbol_proc(lf[43]))(3,*((C_word*)lf[43]+1),t2,((C_word*)t0)[2]);}}

/* k1907 in k1901 in main#ext-version in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1909(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word *a;
if(C_truep(t1)){
t2=((C_word*)t0)[2];
t3=t1;
t4=C_i_assq(lf[40],t3);
if(C_truep(t4)){
t5=C_i_cadr(t4);
/* ->string */
((C_proc3)C_retrieve_symbol_proc(lf[41]))(3,*((C_word*)lf[41]+1),t2,t5);}
else{
t5=t2;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,lf[42]);}}
else{
t2=((C_word*)t0)[2];
((C_proc2)(void*)(*((C_word*)t2+1)))(2,t2,C_SCHEME_FALSE);}}

/* main#deps in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static C_word C_fcall f_1823(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_stack_check;
t3=C_i_assq(t1,t2);
if(C_truep(t3)){
t4=C_i_cdr(t3);
return((C_truep(t4)?t4:C_SCHEME_END_OF_LIST));}
else{
return(C_SCHEME_END_OF_LIST);}}

/* main#resolve-location in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1733(C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word t6;
C_word ab[3],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1733,NULL,2,t1,t2);}
t3=C_i_assoc(t2,C_retrieve2(lf[26],"main#*aliases*"));
if(C_truep(t3)){
t4=(*a=C_CLOSURE_TYPE|2,a[1]=(C_word)f_1741,a[2]=t2,tmp=(C_word)a,a+=3,tmp);
/* g294295 */
t5=t4;
f_1741(t5,t1,t3);}
else{
t4=t2;
t5=t1;
((C_proc2)(void*)(*((C_word*)t5+1)))(2,t5,t4);}}

/* g294 in main#resolve-location in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_fcall f_1741(C_word t0,C_word t1,C_word t2){
C_word tmp;
C_word t3;
C_word t4;
C_word t5;
C_word ab[4],*a=ab;
C_check_for_interrupt;
if(!C_stack_probe(&a)){
C_save_and_reclaim((void*)trf_1741,NULL,3,t0,t1,t2);}
t3=C_i_cdr(t2);
t4=(*a=C_CLOSURE_TYPE|3,a[1]=(C_word)f_1748,a[2]=t3,a[3]=t1,tmp=(C_word)a,a+=4,tmp);
/* print */
((C_proc6)C_retrieve_proc(*((C_word*)lf[33]+1)))(6,*((C_word*)lf[33]+1),t4,lf[34],((C_word*)t0)[2],lf[35],t3);}

/* k1746 in g294 in main#resolve-location in k1357 in k1332 in k1329 in k1326 in k1319 in k1316 in k1313 in k1310 in k1307 in k1304 in k1301 in k1298 in k1295 in k1292 in k1289 in k1286 in k1283 in k1280 in k1277 */
static void C_ccall f_1748(C_word c,C_word t0,C_word t1){
C_word tmp;
C_word t2;
C_word *a;
/* main#resolve-location */
f_1733(((C_word*)t0)[3],((C_word*)t0)[2]);}

#ifdef C_ENABLE_PTABLES
static C_PTABLE_ENTRY ptable[437] = {
{"toplevel:chicken_install_scm",(void*)C_toplevel},
{"f_1279:chicken_install_scm",(void*)f_1279},
{"f_1282:chicken_install_scm",(void*)f_1282},
{"f_1285:chicken_install_scm",(void*)f_1285},
{"f_1288:chicken_install_scm",(void*)f_1288},
{"f_1291:chicken_install_scm",(void*)f_1291},
{"f_1294:chicken_install_scm",(void*)f_1294},
{"f_1297:chicken_install_scm",(void*)f_1297},
{"f_1300:chicken_install_scm",(void*)f_1300},
{"f_1303:chicken_install_scm",(void*)f_1303},
{"f_1306:chicken_install_scm",(void*)f_1306},
{"f_1309:chicken_install_scm",(void*)f_1309},
{"f_1312:chicken_install_scm",(void*)f_1312},
{"f_1315:chicken_install_scm",(void*)f_1315},
{"f_1318:chicken_install_scm",(void*)f_1318},
{"f_1321:chicken_install_scm",(void*)f_1321},
{"f_1328:chicken_install_scm",(void*)f_1328},
{"f_1331:chicken_install_scm",(void*)f_1331},
{"f_1334:chicken_install_scm",(void*)f_1334},
{"f_1359:chicken_install_scm",(void*)f_1359},
{"f_5190:chicken_install_scm",(void*)f_5190},
{"f_5186:chicken_install_scm",(void*)f_5186},
{"f_2180:chicken_install_scm",(void*)f_2180},
{"f_5100:chicken_install_scm",(void*)f_5100},
{"f_5114:chicken_install_scm",(void*)f_5114},
{"f_5153:chicken_install_scm",(void*)f_5153},
{"f_5172:chicken_install_scm",(void*)f_5172},
{"f_5178:chicken_install_scm",(void*)f_5178},
{"f_5159:chicken_install_scm",(void*)f_5159},
{"f_5170:chicken_install_scm",(void*)f_5170},
{"f_4166:chicken_install_scm",(void*)f_4166},
{"f_5097:chicken_install_scm",(void*)f_5097},
{"f_4169:chicken_install_scm",(void*)f_4169},
{"f_4174:chicken_install_scm",(void*)f_4174},
{"f_4317:chicken_install_scm",(void*)f_4317},
{"f_4885:chicken_install_scm",(void*)f_4885},
{"f_5037:chicken_install_scm",(void*)f_5037},
{"f_4995:chicken_install_scm",(void*)f_4995},
{"f_4999:chicken_install_scm",(void*)f_4999},
{"f_5011:chicken_install_scm",(void*)f_5011},
{"f_4950:chicken_install_scm",(void*)f_4950},
{"f_4973:chicken_install_scm",(void*)f_4973},
{"f_4982:chicken_install_scm",(void*)f_4982},
{"f_4989:chicken_install_scm",(void*)f_4989},
{"f_4976:chicken_install_scm",(void*)f_4976},
{"f_4954:chicken_install_scm",(void*)f_4954},
{"f5601:chicken_install_scm",(void*)f5601},
{"f_4934:chicken_install_scm",(void*)f_4934},
{"f_4894:chicken_install_scm",(void*)f_4894},
{"f_4926:chicken_install_scm",(void*)f_4926},
{"f_4900:chicken_install_scm",(void*)f_4900},
{"f5596:chicken_install_scm",(void*)f5596},
{"f_4917:chicken_install_scm",(void*)f_4917},
{"f_4911:chicken_install_scm",(void*)f_4911},
{"f_4907:chicken_install_scm",(void*)f_4907},
{"f5591:chicken_install_scm",(void*)f5591},
{"f_4858:chicken_install_scm",(void*)f_4858},
{"f5586:chicken_install_scm",(void*)f5586},
{"f_4800:chicken_install_scm",(void*)f_4800},
{"f5581:chicken_install_scm",(void*)f5581},
{"f_4692:chicken_install_scm",(void*)f_4692},
{"f_4707:chicken_install_scm",(void*)f_4707},
{"f5576:chicken_install_scm",(void*)f5576},
{"f_4654:chicken_install_scm",(void*)f_4654},
{"f_4669:chicken_install_scm",(void*)f_4669},
{"f5571:chicken_install_scm",(void*)f5571},
{"f_4618:chicken_install_scm",(void*)f_4618},
{"f_4621:chicken_install_scm",(void*)f_4621},
{"f5566:chicken_install_scm",(void*)f5566},
{"f_4589:chicken_install_scm",(void*)f_4589},
{"f_1842:chicken_install_scm",(void*)f_1842},
{"f_1848:chicken_install_scm",(void*)f_1848},
{"f_1853:chicken_install_scm",(void*)f_1853},
{"f_1880:chicken_install_scm",(void*)f_1880},
{"f_1861:chicken_install_scm",(void*)f_1861},
{"f_1877:chicken_install_scm",(void*)f_1877},
{"f_1869:chicken_install_scm",(void*)f_1869},
{"f_1873:chicken_install_scm",(void*)f_1873},
{"f_4592:chicken_install_scm",(void*)f_4592},
{"f_4560:chicken_install_scm",(void*)f_4560},
{"f_4553:chicken_install_scm",(void*)f_4553},
{"f5559:chicken_install_scm",(void*)f5559},
{"f_4485:chicken_install_scm",(void*)f_4485},
{"f_4502:chicken_install_scm",(void*)f_4502},
{"f_4513:chicken_install_scm",(void*)f_4513},
{"f_4509:chicken_install_scm",(void*)f_4509},
{"f_4492:chicken_install_scm",(void*)f_4492},
{"f5554:chicken_install_scm",(void*)f5554},
{"f_4448:chicken_install_scm",(void*)f_4448},
{"f_4452:chicken_install_scm",(void*)f_4452},
{"f5549:chicken_install_scm",(void*)f5549},
{"f_4415:chicken_install_scm",(void*)f_4415},
{"f_4379:chicken_install_scm",(void*)f_4379},
{"f_4336:chicken_install_scm",(void*)f_4336},
{"f_4329:chicken_install_scm",(void*)f_4329},
{"f5544:chicken_install_scm",(void*)f5544},
{"f_1731:chicken_install_scm",(void*)f_1731},
{"f_1387:chicken_install_scm",(void*)f_1387},
{"f_1727:chicken_install_scm",(void*)f_1727},
{"f_1409:chicken_install_scm",(void*)f_1409},
{"f_1411:chicken_install_scm",(void*)f_1411},
{"f_1712:chicken_install_scm",(void*)f_1712},
{"f_1419:chicken_install_scm",(void*)f_1419},
{"f_1423:chicken_install_scm",(void*)f_1423},
{"f_1619:chicken_install_scm",(void*)f_1619},
{"f_1686:chicken_install_scm",(void*)f_1686},
{"f_1646:chicken_install_scm",(void*)f_1646},
{"f_1653:chicken_install_scm",(void*)f_1653},
{"f_1613:chicken_install_scm",(void*)f_1613},
{"f_1609:chicken_install_scm",(void*)f_1609},
{"f_1530:chicken_install_scm",(void*)f_1530},
{"f_1595:chicken_install_scm",(void*)f_1595},
{"f_1557:chicken_install_scm",(void*)f_1557},
{"f_1588:chicken_install_scm",(void*)f_1588},
{"f_1561:chicken_install_scm",(void*)f_1561},
{"f_1564:chicken_install_scm",(void*)f_1564},
{"f_1575:chicken_install_scm",(void*)f_1575},
{"f_1569:chicken_install_scm",(void*)f_1569},
{"f_1524:chicken_install_scm",(void*)f_1524},
{"f_1520:chicken_install_scm",(void*)f_1520},
{"f_1502:chicken_install_scm",(void*)f_1502},
{"f_1454:chicken_install_scm",(void*)f_1454},
{"f_1457:chicken_install_scm",(void*)f_1457},
{"f_1460:chicken_install_scm",(void*)f_1460},
{"f_1463:chicken_install_scm",(void*)f_1463},
{"f_1466:chicken_install_scm",(void*)f_1466},
{"f_1469:chicken_install_scm",(void*)f_1469},
{"f_1472:chicken_install_scm",(void*)f_1472},
{"f_1396:chicken_install_scm",(void*)f_1396},
{"f_1389:chicken_install_scm",(void*)f_1389},
{"f_4199:chicken_install_scm",(void*)f_4199},
{"f_4234:chicken_install_scm",(void*)f_4234},
{"f_4299:chicken_install_scm",(void*)f_4299},
{"f_4250:chicken_install_scm",(void*)f_4250},
{"f_4285:chicken_install_scm",(void*)f_4285},
{"f_4248:chicken_install_scm",(void*)f_4248},
{"f_4244:chicken_install_scm",(void*)f_4244},
{"f_4202:chicken_install_scm",(void*)f_4202},
{"f_4219:chicken_install_scm",(void*)f_4219},
{"f_4205:chicken_install_scm",(void*)f_4205},
{"f_4216:chicken_install_scm",(void*)f_4216},
{"f_4212:chicken_install_scm",(void*)f_4212},
{"f_3174:chicken_install_scm",(void*)f_3174},
{"f_3592:chicken_install_scm",(void*)f_3592},
{"f_3180:chicken_install_scm",(void*)f_3180},
{"f_3186:chicken_install_scm",(void*)f_3186},
{"f_3189:chicken_install_scm",(void*)f_3189},
{"f_3584:chicken_install_scm",(void*)f_3584},
{"f_3196:chicken_install_scm",(void*)f_3196},
{"f_3200:chicken_install_scm",(void*)f_3200},
{"f_3202:chicken_install_scm",(void*)f_3202},
{"f_3557:chicken_install_scm",(void*)f_3557},
{"f_3210:chicken_install_scm",(void*)f_3210},
{"f_3541:chicken_install_scm",(void*)f_3541},
{"f_3525:chicken_install_scm",(void*)f_3525},
{"f_3528:chicken_install_scm",(void*)f_3528},
{"f_3531:chicken_install_scm",(void*)f_3531},
{"f_3217:chicken_install_scm",(void*)f_3217},
{"f_3220:chicken_install_scm",(void*)f_3220},
{"f_3223:chicken_install_scm",(void*)f_3223},
{"f_3491:chicken_install_scm",(void*)f_3491},
{"f_3502:chicken_install_scm",(void*)f_3502},
{"f_3229:chicken_install_scm",(void*)f_3229},
{"f_3480:chicken_install_scm",(void*)f_3480},
{"f_3474:chicken_install_scm",(void*)f_3474},
{"f_3467:chicken_install_scm",(void*)f_3467},
{"f_3431:chicken_install_scm",(void*)f_3431},
{"f_3440:chicken_install_scm",(void*)f_3440},
{"f_3456:chicken_install_scm",(void*)f_3456},
{"f_3450:chicken_install_scm",(void*)f_3450},
{"f_3445:chicken_install_scm",(void*)f_3445},
{"f_3230:chicken_install_scm",(void*)f_3230},
{"f_3234:chicken_install_scm",(void*)f_3234},
{"f_3248:chicken_install_scm",(void*)f_3248},
{"f_3013:chicken_install_scm",(void*)f_3013},
{"f_3021:chicken_install_scm",(void*)f_3021},
{"f_3024:chicken_install_scm",(void*)f_3024},
{"f_3027:chicken_install_scm",(void*)f_3027},
{"f_3030:chicken_install_scm",(void*)f_3030},
{"f_3033:chicken_install_scm",(void*)f_3033},
{"f_3036:chicken_install_scm",(void*)f_3036},
{"f_3039:chicken_install_scm",(void*)f_3039},
{"f_3154:chicken_install_scm",(void*)f_3154},
{"f_3059:chicken_install_scm",(void*)f_3059},
{"f_3129:chicken_install_scm",(void*)f_3129},
{"f_3132:chicken_install_scm",(void*)f_3132},
{"f_3145:chicken_install_scm",(void*)f_3145},
{"f_3135:chicken_install_scm",(void*)f_3135},
{"f_3138:chicken_install_scm",(void*)f_3138},
{"f_3062:chicken_install_scm",(void*)f_3062},
{"f_3114:chicken_install_scm",(void*)f_3114},
{"f_3117:chicken_install_scm",(void*)f_3117},
{"f_3120:chicken_install_scm",(void*)f_3120},
{"f_3123:chicken_install_scm",(void*)f_3123},
{"f_3066:chicken_install_scm",(void*)f_3066},
{"f_3096:chicken_install_scm",(void*)f_3096},
{"f_3099:chicken_install_scm",(void*)f_3099},
{"f_3102:chicken_install_scm",(void*)f_3102},
{"f_3105:chicken_install_scm",(void*)f_3105},
{"f_3070:chicken_install_scm",(void*)f_3070},
{"f_3082:chicken_install_scm",(void*)f_3082},
{"f_3078:chicken_install_scm",(void*)f_3078},
{"f_3252:chicken_install_scm",(void*)f_3252},
{"f_3258:chicken_install_scm",(void*)f_3258},
{"f_3375:chicken_install_scm",(void*)f_3375},
{"f_3399:chicken_install_scm",(void*)f_3399},
{"f_3411:chicken_install_scm",(void*)f_3411},
{"f_3417:chicken_install_scm",(void*)f_3417},
{"f_3405:chicken_install_scm",(void*)f_3405},
{"f_3381:chicken_install_scm",(void*)f_3381},
{"f_3387:chicken_install_scm",(void*)f_3387},
{"f_3391:chicken_install_scm",(void*)f_3391},
{"f_3394:chicken_install_scm",(void*)f_3394},
{"f_3397:chicken_install_scm",(void*)f_3397},
{"f_3370:chicken_install_scm",(void*)f_3370},
{"f_3266:chicken_install_scm",(void*)f_3266},
{"f_3358:chicken_install_scm",(void*)f_3358},
{"f_3364:chicken_install_scm",(void*)f_3364},
{"f_3272:chicken_install_scm",(void*)f_3272},
{"f_3276:chicken_install_scm",(void*)f_3276},
{"f_3297:chicken_install_scm",(void*)f_3297},
{"f_3321:chicken_install_scm",(void*)f_3321},
{"f_3333:chicken_install_scm",(void*)f_3333},
{"f_3339:chicken_install_scm",(void*)f_3339},
{"f_3327:chicken_install_scm",(void*)f_3327},
{"f_3303:chicken_install_scm",(void*)f_3303},
{"f_3309:chicken_install_scm",(void*)f_3309},
{"f_3313:chicken_install_scm",(void*)f_3313},
{"f_3316:chicken_install_scm",(void*)f_3316},
{"f_3319:chicken_install_scm",(void*)f_3319},
{"f_3292:chicken_install_scm",(void*)f_3292},
{"f_3288:chicken_install_scm",(void*)f_3288},
{"f_3277:chicken_install_scm",(void*)f_3277},
{"f_3259:chicken_install_scm",(void*)f_3259},
{"f_3235:chicken_install_scm",(void*)f_3235},
{"f_3239:chicken_install_scm",(void*)f_3239},
{"f_3242:chicken_install_scm",(void*)f_3242},
{"f_3976:chicken_install_scm",(void*)f_3976},
{"f_3972:chicken_install_scm",(void*)f_3972},
{"f_3613:chicken_install_scm",(void*)f_3613},
{"f_3616:chicken_install_scm",(void*)f_3616},
{"f_3619:chicken_install_scm",(void*)f_3619},
{"f_3622:chicken_install_scm",(void*)f_3622},
{"f_3625:chicken_install_scm",(void*)f_3625},
{"f_3965:chicken_install_scm",(void*)f_3965},
{"f_3847:chicken_install_scm",(void*)f_3847},
{"f_3853:chicken_install_scm",(void*)f_3853},
{"f_3952:chicken_install_scm",(void*)f_3952},
{"f_3861:chicken_install_scm",(void*)f_3861},
{"f_3865:chicken_install_scm",(void*)f_3865},
{"f_3873:chicken_install_scm",(void*)f_3873},
{"f_3911:chicken_install_scm",(void*)f_3911},
{"f_3939:chicken_install_scm",(void*)f_3939},
{"f_3945:chicken_install_scm",(void*)f_3945},
{"f_3917:chicken_install_scm",(void*)f_3917},
{"f_3933:chicken_install_scm",(void*)f_3933},
{"f_3879:chicken_install_scm",(void*)f_3879},
{"f_3885:chicken_install_scm",(void*)f_3885},
{"f_3893:chicken_install_scm",(void*)f_3893},
{"f_3897:chicken_install_scm",(void*)f_3897},
{"f_3900:chicken_install_scm",(void*)f_3900},
{"f_3903:chicken_install_scm",(void*)f_3903},
{"f_3906:chicken_install_scm",(void*)f_3906},
{"f_3909:chicken_install_scm",(void*)f_3909},
{"f_3868:chicken_install_scm",(void*)f_3868},
{"f_3842:chicken_install_scm",(void*)f_3842},
{"f_3628:chicken_install_scm",(void*)f_3628},
{"f_3631:chicken_install_scm",(void*)f_3631},
{"f_3719:chicken_install_scm",(void*)f_3719},
{"f_3726:chicken_install_scm",(void*)f_3726},
{"f_3729:chicken_install_scm",(void*)f_3729},
{"f_3740:chicken_install_scm",(void*)f_3740},
{"f_3798:chicken_install_scm",(void*)f_3798},
{"f_3825:chicken_install_scm",(void*)f_3825},
{"f_3748:chicken_install_scm",(void*)f_3748},
{"f_3754:chicken_install_scm",(void*)f_3754},
{"f_3781:chicken_install_scm",(void*)f_3781},
{"f_3752:chicken_install_scm",(void*)f_3752},
{"f_3734:chicken_install_scm",(void*)f_3734},
{"f_3695:chicken_install_scm",(void*)f_3695},
{"f_3697:chicken_install_scm",(void*)f_3697},
{"f_3705:chicken_install_scm",(void*)f_3705},
{"f_3709:chicken_install_scm",(void*)f_3709},
{"f_3634:chicken_install_scm",(void*)f_3634},
{"f_3637:chicken_install_scm",(void*)f_3637},
{"f_3656:chicken_install_scm",(void*)f_3656},
{"f_3662:chicken_install_scm",(void*)f_3662},
{"f_3674:chicken_install_scm",(void*)f_3674},
{"f_3680:chicken_install_scm",(void*)f_3680},
{"f_3640:chicken_install_scm",(void*)f_3640},
{"f_3654:chicken_install_scm",(void*)f_3654},
{"f_3650:chicken_install_scm",(void*)f_3650},
{"f_3643:chicken_install_scm",(void*)f_3643},
{"f_5163:chicken_install_scm",(void*)f_5163},
{"f_5120:chicken_install_scm",(void*)f_5120},
{"f_5126:chicken_install_scm",(void*)f_5126},
{"f_5151:chicken_install_scm",(void*)f_5151},
{"f_5130:chicken_install_scm",(void*)f_5130},
{"f_5147:chicken_install_scm",(void*)f_5147},
{"f_5133:chicken_install_scm",(void*)f_5133},
{"f_5136:chicken_install_scm",(void*)f_5136},
{"f_5103:chicken_install_scm",(void*)f_5103},
{"f_5106:chicken_install_scm",(void*)f_5106},
{"f_5112:chicken_install_scm",(void*)f_5112},
{"f_5109:chicken_install_scm",(void*)f_5109},
{"f_4129:chicken_install_scm",(void*)f_4129},
{"f_4139:chicken_install_scm",(void*)f_4139},
{"f_4152:chicken_install_scm",(void*)f_4152},
{"f_4108:chicken_install_scm",(void*)f_4108},
{"f_4112:chicken_install_scm",(void*)f_4112},
{"f_4115:chicken_install_scm",(void*)f_4115},
{"f_4086:chicken_install_scm",(void*)f_4086},
{"f_4103:chicken_install_scm",(void*)f_4103},
{"f_4090:chicken_install_scm",(void*)f_4090},
{"f_3978:chicken_install_scm",(void*)f_3978},
{"f_4011:chicken_install_scm",(void*)f_4011},
{"f_4070:chicken_install_scm",(void*)f_4070},
{"f_4076:chicken_install_scm",(void*)f_4076},
{"f_4015:chicken_install_scm",(void*)f_4015},
{"f_4029:chicken_install_scm",(void*)f_4029},
{"f_4058:chicken_install_scm",(void*)f_4058},
{"f_4009:chicken_install_scm",(void*)f_4009},
{"f_3996:chicken_install_scm",(void*)f_3996},
{"f_4002:chicken_install_scm",(void*)f_4002},
{"f_3999:chicken_install_scm",(void*)f_3999},
{"f_3981:chicken_install_scm",(void*)f_3981},
{"f_3989:chicken_install_scm",(void*)f_3989},
{"f_3993:chicken_install_scm",(void*)f_3993},
{"f_3594:chicken_install_scm",(void*)f_3594},
{"f_3601:chicken_install_scm",(void*)f_3601},
{"f_2486:chicken_install_scm",(void*)f_2486},
{"f_2490:chicken_install_scm",(void*)f_2490},
{"f_2760:chicken_install_scm",(void*)f_2760},
{"f_2805:chicken_install_scm",(void*)f_2805},
{"f_2809:chicken_install_scm",(void*)f_2809},
{"f_2812:chicken_install_scm",(void*)f_2812},
{"f_2799:chicken_install_scm",(void*)f_2799},
{"f_1814:chicken_install_scm",(void*)f_1814},
{"f_1797:chicken_install_scm",(void*)f_1797},
{"f_1804:chicken_install_scm",(void*)f_1804},
{"f_1794:chicken_install_scm",(void*)f_1794},
{"f_1790:chicken_install_scm",(void*)f_1790},
{"f_2323:chicken_install_scm",(void*)f_2323},
{"f_2325:chicken_install_scm",(void*)f_2325},
{"f_2393:chicken_install_scm",(void*)f_2393},
{"f_2341:chicken_install_scm",(void*)f_2341},
{"f_2379:chicken_install_scm",(void*)f_2379},
{"f_2344:chicken_install_scm",(void*)f_2344},
{"f_2355:chicken_install_scm",(void*)f_2355},
{"f_1821:chicken_install_scm",(void*)f_1821},
{"f_2349:chicken_install_scm",(void*)f_2349},
{"f_2191:chicken_install_scm",(void*)f_2191},
{"f_2284:chicken_install_scm",(void*)f_2284},
{"f_2303:chicken_install_scm",(void*)f_2303},
{"f_2309:chicken_install_scm",(void*)f_2309},
{"f_2290:chicken_install_scm",(void*)f_2290},
{"f_2298:chicken_install_scm",(void*)f_2298},
{"f_2197:chicken_install_scm",(void*)f_2197},
{"f_2203:chicken_install_scm",(void*)f_2203},
{"f_2213:chicken_install_scm",(void*)f_2213},
{"f_2225:chicken_install_scm",(void*)f_2225},
{"f_2237:chicken_install_scm",(void*)f_2237},
{"f_2240:chicken_install_scm",(void*)f_2240},
{"f_2243:chicken_install_scm",(void*)f_2243},
{"f_2228:chicken_install_scm",(void*)f_2228},
{"f_2216:chicken_install_scm",(void*)f_2216},
{"f_2186:chicken_install_scm",(void*)f_2186},
{"f_2785:chicken_install_scm",(void*)f_2785},
{"f_2838:chicken_install_scm",(void*)f_2838},
{"f_2493:chicken_install_scm",(void*)f_2493},
{"f_2501:chicken_install_scm",(void*)f_2501},
{"f_2523:chicken_install_scm",(void*)f_2523},
{"f_2529:chicken_install_scm",(void*)f_2529},
{"f_2724:chicken_install_scm",(void*)f_2724},
{"f_2532:chicken_install_scm",(void*)f_2532},
{"f_2535:chicken_install_scm",(void*)f_2535},
{"f_2876:chicken_install_scm",(void*)f_2876},
{"f_2911:chicken_install_scm",(void*)f_2911},
{"f_2966:chicken_install_scm",(void*)f_2966},
{"f_2940:chicken_install_scm",(void*)f_2940},
{"f_2924:chicken_install_scm",(void*)f_2924},
{"f_2886:chicken_install_scm",(void*)f_2886},
{"f_2854:chicken_install_scm",(void*)f_2854},
{"f_2538:chicken_install_scm",(void*)f_2538},
{"f_2541:chicken_install_scm",(void*)f_2541},
{"f_2552:chicken_install_scm",(void*)f_2552},
{"f_2557:chicken_install_scm",(void*)f_2557},
{"f_2659:chicken_install_scm",(void*)f_2659},
{"f_2661:chicken_install_scm",(void*)f_2661},
{"f_2671:chicken_install_scm",(void*)f_2671},
{"f_2655:chicken_install_scm",(void*)f_2655},
{"f_2643:chicken_install_scm",(void*)f_2643},
{"f_2636:chicken_install_scm",(void*)f_2636},
{"f_2564:chicken_install_scm",(void*)f_2564},
{"f_2416:chicken_install_scm",(void*)f_2416},
{"f_2469:chicken_install_scm",(void*)f_2469},
{"f_2476:chicken_install_scm",(void*)f_2476},
{"f_2414:chicken_install_scm",(void*)f_2414},
{"f_2406:chicken_install_scm",(void*)f_2406},
{"f_2630:chicken_install_scm",(void*)f_2630},
{"f_2570:chicken_install_scm",(void*)f_2570},
{"f_2573:chicken_install_scm",(void*)f_2573},
{"f_2617:chicken_install_scm",(void*)f_2617},
{"f_2576:chicken_install_scm",(void*)f_2576},
{"f_2584:chicken_install_scm",(void*)f_2584},
{"f_2596:chicken_install_scm",(void*)f_2596},
{"f_2602:chicken_install_scm",(void*)f_2602},
{"f_2579:chicken_install_scm",(void*)f_2579},
{"f_2546:chicken_install_scm",(void*)f_2546},
{"f_1970:chicken_install_scm",(void*)f_1970},
{"f_1975:chicken_install_scm",(void*)f_1975},
{"f_2031:chicken_install_scm",(void*)f_2031},
{"f_2137:chicken_install_scm",(void*)f_2137},
{"f_2034:chicken_install_scm",(void*)f_2034},
{"f_2051:chicken_install_scm",(void*)f_2051},
{"f_2126:chicken_install_scm",(void*)f_2126},
{"f_2122:chicken_install_scm",(void*)f_2122},
{"f_2111:chicken_install_scm",(void*)f_2111},
{"f_2097:chicken_install_scm",(void*)f_2097},
{"f_2064:chicken_install_scm",(void*)f_2064},
{"f_2075:chicken_install_scm",(void*)f_2075},
{"f_2079:chicken_install_scm",(void*)f_2079},
{"f_2071:chicken_install_scm",(void*)f_2071},
{"f_2018:chicken_install_scm",(void*)f_2018},
{"f_2025:chicken_install_scm",(void*)f_2025},
{"f_1989:chicken_install_scm",(void*)f_1989},
{"f_1993:chicken_install_scm",(void*)f_1993},
{"f_2747:chicken_install_scm",(void*)f_2747},
{"f_1893:chicken_install_scm",(void*)f_1893},
{"f_1943:chicken_install_scm",(void*)f_1943},
{"f_1903:chicken_install_scm",(void*)f_1903},
{"f_1909:chicken_install_scm",(void*)f_1909},
{"f_1823:chicken_install_scm",(void*)f_1823},
{"f_1733:chicken_install_scm",(void*)f_1733},
{"f_1741:chicken_install_scm",(void*)f_1741},
{"f_1748:chicken_install_scm",(void*)f_1748},
{NULL,NULL}};
#endif

static C_PTABLE_ENTRY *create_ptable(void){
#ifdef C_ENABLE_PTABLES
return ptable;
#else
return NULL;
#endif
}
/* end of file */
